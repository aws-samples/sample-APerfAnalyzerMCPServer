#!/usr/bin/env python3
# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Refresh EC2 pricing data for us-east-1 from the AWS public bulk pricing API.

Downloads the AmazonEC2 us-east-1 region index, filters to Linux/Shared/OnDemand,
and writes a slim JSON file at resources/ec2_pricing_us_east_1.json.

Behaviour: silent overwrite (option A). Run periodically to refresh.

Usage:
    python scripts/refresh_pricing.py
    python scripts/refresh_pricing.py --dry-run    # report what would change
    python scripts/refresh_pricing.py --verbose    # print progress

No AWS credentials required — uses public HTTPS endpoints.

The actual fetch/filter/write logic lives in src/pricing_refresh.py, shared with the
pricing_status MCP tool -- this script is a thin CLI wrapper around refresh_sync().
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.pricing_refresh import _print_report, refresh_sync


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dry-run", action="store_true", help="Report what would change without writing the file"
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    try:
        result = refresh_sync(dry_run=args.dry_run)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    _print_report(result, verbose=args.verbose)
    return 0


if __name__ == "__main__":
    sys.exit(main())
