# Case Study: Python EKS Latency Investigation

## Environment

| Parameter | Value |
|---|---|
| Cloud | AWS / Amazon EKS |
| Region | (anonymized) |
| Instance | storage-optimized NVMe, 4 vCPU |
| Scheduling | Spot instances via Karpenter |
| OS | Amazon Linux 2023, kernel 6.12.63 |
| Language | Python 3.12 (upgraded from 3.9 during investigation) |
| Framework | Flask 1.x → Flask 2.x, Gunicorn gthread workers |
| Database | MongoDB (PyMongo 3.11 → 4.x) |
| Cache | Valkey/Redis via valkey-glide |
| Observability | ElasticAPM (custom fork), Fluent-bit → CloudWatch |
| Service mesh | Istio (Envoy sidecar) |
| Load balancer | AWS ALB |

---

## Presenting Problem

Customer reported intermittent high latency on a Python/Flask application running on EKS.
Symptoms: CPU utilization stuck at ~23% across 7 nodes with only 3 nodes actually receiving
load. External API calls showed "twice as long" processing time. Periodic iowait spikes
visible in monitoring.

---

## Investigation Timeline and Findings

### Phase 1: Initial aperf Run (no profiling)

First run captured system-level metrics only. Key observations:
- CPU avg 23% but 3 of 7 nodes handling all traffic
- No iowait, no disk saturation, no TCP errors
- Gunicorn workers showing extreme imbalance (3 workers at 35%+ CPU, 4 at <2%)

**Diagnosis:** Not a CPU or disk problem. Network/scheduling issue.

### Phase 2: With --profile (on-CPU flamegraph)

Flamegraph revealed (47,515 samples, Python 3.9):
- `SSL_CTX_load_verify_locations` → `X509_load_cert_crl_file_ex` at **4.4% CPU**
  (SSLContext rebuilt on every HTTPS request — critical finding)
- `_cbson_decode_all` BSON deserialization visible
- Worker imbalance persists — 3 workers at 35%+ CPU

**Root causes identified:**
1. SSLContext being created per-request (4.4% CPU wasted)
2. PyMongo 3.11 C extension BSON decode overhead
3. Worker imbalance from ALB/Envoy persistent connection affinity
4. `tcp_max_syn_backlog=512` (too low for 57-thread workers)
5. `tcp_keepalive_time=7200s` (stale connections in K8s)

### Phase 3: After Infrastructure Changes

New run (Python 3.12, new node pool, 2 pods per node):
- SSL/TLS CPU: **0.2%** (down from 4.4% — 95% reduction, SSLContext fix confirmed)
- System CPU: **0.89%** (down from 2.02% — 55% reduction)
- NEW top hotspot: `filters_dsl DynamicFilter.evaluate` at **22.5% CPU**
- NEW: `botocore._make_api_call` at **6.3% CPU** (AWS SDK calls on hot path)
- NEW: `elasticapm capture_span + iter_stack_frames` at **5.5% CPU**
- `tcp_max_syn_backlog` fixed to 4096 (confirmed in sysctl)
- Worker imbalance: still present (3-4 of 14 workers carrying 77% load)
- `tcp_keepalive_time`: still 7200s (not yet fixed)

**New root causes revealed by Python 3.12 upgrade:**
- DSL filter expression tree rebuilt per-request (`Expression.__init__` in flamegraph)
- Inline AWS SDK calls (botocore) on every request — AppConfig/Secrets Manager
- APM stack frame capture overhead (`iter_stack_frames`)
- lmongo ODM full document deserialization (`Document.from_mongo`)
- PyMongo 4.x CSOT wrapper overhead (1.2% — acceptable upgrade cost)

### Phase 4: Off-CPU Run (iowait investigation)

Customer captured two simultaneous recordings:
1. `off-cpu-aperf_record_20260518-182723`: off-CPU profiling + standard aperf
2. `no-off-cpu-aperf_record_20260518-183042`: standard on-CPU only

**Off-CPU run showed iowait=20% for one second at t+30s.**

Second-by-second vmstat analysis revealed:

| Second | nr_dirty | pgpgout/s | iowait | Interpretation |
|---|---|---|---|---|
| t+00 to t+28 | 571-574MB | ~44/s | 0.0% | Slow accumulation |
| t+29 | 474MB | 98,600/s | 1.51% | Flush STARTS |
| t+30 | 46MB | 442,020/s | 20.0% | BURST PEAK — 428MB in 1s |
| t+31 | 1MB | 46,196/s | 4.29% | Flush tail |
| t+32+ | ~280KB | 52/s | 0.0% | Normal |

**Root cause:** `vm.dirty_expire_centisecs=3000` (30 seconds). The kernel's dirty_ratio
threshold (20% = 6.4GB on this 32GB node) is never reached because dirty pages only
accumulate to ~574MB. The only flush mechanism that actually fires is the expiry timer,
which dumps everything at once every 30 seconds.

**Source of dirty pages:** Fluent-bit disk buffering (`storage.type=filesystem`),
container runtime logs to `/var/log/pods/`, and any application file writes accumulate
in the page cache and generate the 574MB dirty page baseline.

**Standard run showed iowait=0.05%** because the recording was taken 3 minutes after
the flush had already completed and pages had not yet re-accumulated to trigger again.

---

## Complete Fix Set (Consolidated DaemonSet)

All fixes are node-level sysctl changes applied via DaemonSet initContainer.
**Fully compatible with Spot instances and Karpenter** — no instance-type dependencies.

```yaml
initContainers:
  - name: sysctl-tuning
    image: busybox:1.35
    securityContext:
      privileged: true
    command:
      - sh
      - -c
      - |
        # Dirty page writeback: smooth continuous flush
        # Converts 20% iowait burst every 30s to continuous <1% iowait
        sysctl -w vm.dirty_background_ratio=1
        sysctl -w vm.dirty_expire_centisecs=500
        sysctl -w vm.dirty_writeback_centisecs=200
        sysctl -w vm.dirty_ratio=10

        # TCP keepalive: detect dead connections in 60 seconds
        # Prevents stale connection latency on pod restarts
        sysctl -w net.ipv4.tcp_keepalive_time=60
        sysctl -w net.ipv4.tcp_keepalive_intvl=10
        sysctl -w net.ipv4.tcp_keepalive_probes=3

        # Memory pressure reduction
        sysctl -w vm.swappiness=1

        # SYN backlog for burst resilience
        sysctl -w net.ipv4.tcp_max_syn_backlog=4096
```

---

## Worker Imbalance: ALB/Envoy Connection Affinity

**Pattern:** ALB and Envoy (Istio sidecar) maintain persistent keepalive connection pools.
With Gunicorn gthread workers, each persistent connection is accepted by one worker and
all subsequent requests on that connection go to the same worker for its lifetime.
Result: 3-4 workers handle 70-80% of load, others are idle.

**This is not an instance-type issue.** The same pattern appears on any instance type.
On Spot with Karpenter, all replacement nodes will exhibit the same pattern until fixed.

**Fix:**
```yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: your-app
spec:
  host: your-app
  trafficPolicy:
    connectionPool:
      http:
        maxRequestsPerConnection: 1  # breaks connection-to-worker binding
    loadBalancer:
      simple: LEAST_REQUEST
```

---

## ElasticAPM Overhead

APM instrumentation overhead (`iter_stack_frames`) at 5.5% of CPU samples.
Three environment variables recover this with zero code changes:

```
ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION=50ms
ELASTIC_APM_TRANSACTION_SAMPLE_RATE=0.1
ELASTIC_APM_STACK_TRACE_LIMIT=50
```

---

## Off-CPU vs Standard Profiling: When to Use Each

| Bottleneck type | Standard aperf --profile | Off-CPU aperf | Best tool |
|---|---|---|---|
| CPU-bound hotspots | Yes | Yes | Either |
| SSL/TLS rebuild | Yes (via flamegraph) | Yes | Either |
| Dirty page burst (iowait) | No (timing-dependent) | Yes | Off-CPU (must run during burst) |
| Worker imbalance | Yes (process table) | Yes | Either |
| Stale TCP connections | Yes (sysctl) | Yes | Either |
| Blocking per-request calls | No | Partial | ElasticAPM traces or bpftrace |
| ALB/Envoy connection affinity | Yes (process imbalance) | Yes | Either |

**Key insight from this case:** The off-CPU run captured the dirty page flush event by
coincidence (the recording happened to include t+30s when the burst fired). The standard
run was 3 minutes later and missed it entirely. For intermittent iowait spikes, run both
simultaneously and compare.

---

## What Off-CPU Profiling Does NOT Catch

The `update()` method caching fix (100ms per-request saving) was invisible in both
flamegraphs. The thread was off-CPU (blocked on network wait) during the 100ms — no
CPU samples were taken. To find this pattern:

- **ElasticAPM transaction timeline**: the `update()` span would appear as 100ms on
  every transaction — immediately obvious in the waterfall view
- **bpftrace off-CPU**: `@offcpu_us[python]: 100ms` per request cycle, clearly above
  background infrastructure noise
- **The double-checked locking fix applied by customer** (TTL-based cache on the update
  method) was the right solution and saved 100ms per request

---

## Python Version and Dependency Notes

### Python 3.9 → 3.12 Impact on Flamegraph

Python 3.12 with the specializing adaptive interpreter shows dramatically different
flamegraph profiles:

| Function | Python 3.9 (3.10) | Python 3.12/3.14 |
|---|---|---|
| `_PyEval_EvalFrameDefault` | 147% aggregate | <1% (replaced by specializations) |
| `call_function` | 59% | Not present (removed in 3.11+) |
| `_PyFunction_Vectorcall` | 140% | 12% |
| `_TAIL_CALL_*` functions | Not present | Visible (LLVM specializations) |

This makes cross-version comparisons of flamegraphs misleading if naively compared.
The total interpreter overhead is lower in 3.12/3.14 but appears as different symbols.

### Graviton Migration Blockers

From `pyproject.toml` analysis:
- **Hard blockers:** `ujson==1.35` (no arm64 wheel), `netifaces==0.10.9` (abandoned, fps-mongo dep), `maxminddb==1.5.2` (no arm64 wheel)
- **Resolved:** Python 3.9→3.12, PyMongo 3.11→4.x
- **Medium risk:** `valkey-glide-sync==2.3.1` (Rust/cffi, verify wheel), `confluent-kafka==2.14.0` (needs librdkafka), `python-snappy==0.7.3` (needs libsnappy-dev)

For Karpenter Spot pool with Graviton nodes: test in a separate node group with label
selector before enabling Graviton in the pool. Missing arm64 wheels cause pod startup
failures, not runtime errors.

---

## Metrics Summary Across Runs

| Metric | Run 1 (c5a.xlarge, py3.9) | Run 2 (i7i.2xlarge, py3.12) | Run 3 (i7i.xlarge, py3.12) |
|---|---|---|---|
| CPU avg | 23.01% | 23.42% | 22.01-22.62% |
| SSL/TLS CPU | 4.4% | 0.2% | 0.8-0.9% |
| BSON decode CPU | 0.25% | 0.1% | 0.1% |
| iowait avg | 0.09% | 0.10% | 0.05-0.27% |
| iowait MAX | 0% | 0% | 20% (off-cpu run) |
| System CPU | 2.02% | 0.89% | 0.93-1.16% |
| filters_dsl CPU | hidden | 22.5% | 22.5% |
| botocore CPU | hidden | 6.3% | 6.3% |
| APM overhead | hidden | 5.5% | 5.5% |
| tcp_max_syn_backlog | 512 | 4096 | 2048 |
| tcp_keepalive_time | 7200s | 7200s | 7200s |
| dirty_background_ratio | 10% | n/a | 10% |
| dirty_expire_centisecs | 3000 | n/a | 3000 |

---

*Last updated: 2026-05-18 | Source: aperf runs off-cpu-182723, no-off-cpu-183042, 20260504-222035*
