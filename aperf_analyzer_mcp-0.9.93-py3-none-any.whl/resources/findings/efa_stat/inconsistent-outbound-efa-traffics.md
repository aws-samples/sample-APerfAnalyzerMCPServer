---
rule_name: Inconsistent Outbound EFA Traffics
data_type: efa_stat
data_key: tx_bytes
template: time_series_stat_run_comparison
condition: "abs(delta_avg(tx_bytes)) > 0.1"
base_score: Critical
score_sign: negative
requires_comparison: true
aperf_message: "The average numbers of bytes transmitted by EFA are different. Verify if this is the expected behavior."
source: src/analytics/rules/efa_stat.rs:44
---

# Inconsistent Outbound EFA Traffics

## What fired

The **average** of `tx_bytes` in this run differs from the same average in the **base run** by **more
than 10%** in either direction. `abs: true`, so an increase and a decrease of the same magnitude score
identically.

Base score `Critical` (**−256**). **Comparison-only rule** — it cannot fire on a single-run report, and it
never fires *on* the base run (the template skips it).

**This is a validity finding, not a performance finding.** It does not say outbound EFA traffic is too
high or too low. It says **the two runs did not transmit the same amount of data over EFA, so they are not
comparable** — and every other cross-run conclusion in the report is suspect until that is explained.
Treat it as a **gate**.

This is the transmit-side twin of `Inconsistent Inbound EFA Traffics`. The mechanics are identical; the
diagnostic value differs, and that difference is the point of this playbook.

## Reasoning

`tx_bytes` is the number of bytes transmitted by the EFA device — a cumulative hardware counter read from
the EFA driver, per EFA device, since instance launch or driver reset (`data-descriptions.ts`;
`desired: "depends"`, `defaultUnit: "Count"`).

**Why 10% on transmitted bytes is `Critical`.** aperf's comparison mode answers "what changed between run
A and run B", and that question only has an answer if both runs did the same work. For an EFA workload the
volume of data pushed onto the fabric is a direct proxy for work performed. If run B transmitted 30% less,
any apparent speed-up may simply be less work, and any regression may be more work. The finding flags that
**the experimental control was broken** — the same job aperf's other `Critical` comparison rules do
(`Inconsistent Physical Memory`, `Inconsistent Number of CPUs`, `Kernel Version Mismatch`,
`JVM Version Comparison`). None of them describe a degradation; all of them invalidate the measurement.

**Why outbound is the more attributable side.** This is the substantive difference from the inbound rule:

- **Transmission is a local decision.** What a node *sends* is chosen by that node's application and
  middleware. What it *receives* is chosen by its peers. So a change in `tx_bytes` is attributable to
  something on **this** host — its code, its middleware configuration, its rank's share of the work —
  while a change in `rx_bytes` may be entirely caused by other nodes.
- **It reflects the send-side protocol choice directly.** Eager vs rendezvous thresholds, chunk sizes,
  pipelining depth, and collective algorithm all determine how many bytes this node puts on the wire for
  the same logical message. A middleware or provider change shows up here first.
- **It includes retransmission.** Bytes the fabric had to resend are transmitted bytes. Compare with
  `retrans_bytes`: a `tx_bytes` increase matched by a `retrans_bytes` increase is **network trouble, not
  extra work** — the single most useful disambiguation available on the transmit side, and one with no
  clean equivalent inbound.
- **It is the side that hits ceilings.** Send-side volume is what interacts with fabric capacity and, if
  traffic falls back to TCP, with ENA bandwidth and PPS allowances. An outbound difference is therefore
  more likely than an inbound one to have a resource explanation.

**Why inbound and outbound are separate rules.** Both firing together points at a symmetric change —
different problem size, node count, or run duration. **Only outbound firing is the more diagnostic case**:
this node's send behaviour changed while its receive volume did not, which points at a send-side protocol
or algorithm change, a change in this rank's share of the work, or retransmission.

**Plausible causes, ordered by how often they are the real answer:**

1. **The runs did different amounts of work.** Different input, problem size, iteration count, batch
   size, dataset, or duration. Most firings.
2. **Different job geometry.** A different rank, node, or ranks-per-node count changes how much any one
   node transmits even for identical total work.
3. **The recordings came from different nodes of the job.** In asymmetric jobs (a root rank, a parameter
   server, an unbalanced decomposition) different nodes legitimately transmit different volumes. Then the
   comparison is invalid whatever the runs did.
4. **A send-side protocol or middleware change.** A different libfabric provider, MPI implementation,
   NCCL version, eager/rendezvous threshold, or collective algorithm changes transmitted bytes for the
   same logical work. **This is the cause outbound catches better than inbound.**
5. **Retransmission.** Higher `retrans_bytes` / `retrans_pkts` inflates `tx_bytes` with no change in
   application traffic. Nitro v4+ only. Check this before concluding "more work".
6. **Fallback off EFA.** If EFA was unavailable or misconfigured in one run, traffic went over TCP/ENA and
   `tx_bytes` collapses. A drop in EFA transmit bytes with a rise in `ena_stat` `tx_bytes` is the
   fingerprint — a real configuration defect, not merely a comparison problem.
7. **A different EFA device count.** The stat comes from the auto-generated **`average`** series on
   multi-device instances, so comparing a 1-device instance with a 4-device one compares a total against a
   per-device mean.
8. **Phase-mix differences.** `Stat::Average` is a mean of per-interval deltas — a rate — so duration alone
   should not move it, but a long idle startup or truncated teardown dilutes the mean.
9. **Genuinely the thing under test.** If the change was *meant* to reduce transmitted bytes — a better
   decomposition, gradient compression, a smarter collective, message aggregation — this finding is the
   intended result and "verify if this is the expected behavior" is answered "yes". **Common; do not report
   it as a defect.**

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run_name} ({value}) is {delta_ratio_string} {base_run_name} ({base_value}).
```

Both placeholders are **run names**, not metric names. Example:

```
The average in run_b (2.31M) is 18.75% greater than run_a (1.94M).
```

Four things to know:

1. **Values use K/M/G/T suffixes** (`formatted_number_string`) and are **truncated**, not rounded, to two
   decimals. `2.31M` is anything from 2,310,000 to 2,319,999.
2. **The ratio shown is signed; the score uses the absolute value.** `abs: true` applies only to the
   comparison and the score. **The description is the only place the direction appears** — read it.
3. **`equal to`** appears only when the stats are exactly equal, in which case the rule cannot fire. You
   will never see it here.
4. **If the base-run average is 0, the ratio is substituted with `1.0`** ("treat the current stat as 100%
   larger"), *regardless of the current value's size*. So `100.00% greater than run_a (0)` means **the
   base run transmitted nothing over EFA** — categorical, not proportional, and a much stronger statement
   than the number implies.

Score math — `compute_finding_score(abs_ratio, 0.1, −256)`, general branch, `delta = ratio/0.1`:

| abs(ratio) | meaning | score |
|---|---|---|
| 0.10 | at the threshold — does **not** fire (`Greater`, not `GreaterEqual`) | — |
| 0.11 | 11% different | **−281.60** |
| 0.125 | 12.5% | **−320.00** |
| 0.15 | 15% | **−384.00** |
| 0.20 | 20% | **−512.00** |
| 0.25 | 25% | **−640.00** |
| 0.50 | 50% | **−1280.00** |
| 1.00 | 100% (2×), **or base run = 0** | **−2560.00** |
| 2.00 | 3× | **−5120.00** |
| 5.00 | 6× | **−12800.00** |
| 10.00 | 11× | **−25600.00** |

**The score is unbounded and monotonic** — larger really does mean a larger discrepancy, so it is worth
ranking on within the comparison-validity family. But at `Critical` × the ratio it reaches five figures
and will dominate a score-ordered findings list. **A high score means "the comparison is badly broken",
not "the system is badly broken".** Note too that the base-run-zero substitution caps at ratio 1.0
(−2560.00), scoring *lower* than a 2× difference despite being the more categorical one.

## Interpretation

Start with direction and pairing:

| Observation | Reading |
|---|---|
| Both outbound **and** inbound fired | **Symmetric scale change.** Different problem size, node count, or run length. Check the experiment setup first |
| Only **outbound** fired | **This node's send behaviour changed.** A send-side protocol/algorithm change, a change in this rank's share of the work, or retransmission. The more attributable case — the cause is local to this host |
| Description says **`greater than`** | This run transmitted more. Either more work, **retransmission**, or a chattier send path (eager/rendezvous, chunking, collective algorithm) |
| Description says **`less than`** | This run transmitted less. Either less work, a fallback off EFA, aggregation/compression, or a truncated run |
| Base value shown as **`0`** with `100.00% greater` | **The base run transmitted nothing over EFA.** Verify EFA worked at all in the base run before anything else |
| Difference just over 10% | Near the tripwire. Check run duration and sample count first |
| Difference over 100% | Materially different work. Stop and fix the experiment |

Then localize:

| Evidence | Reading |
|---|---|
| `retrans_bytes` / `retrans_pkts` up in step with `tx_bytes` | **The extra bytes are retransmission, not work.** The most valuable transmit-side check; Nitro v4+. Read manually |
| `retrans_timeout_events` non-zero | Timeouts "resulted in a network path change" — the fabric rerouted mid-run, contaminating the comparison |
| `impaired_remote_conn_events` non-zero | A remote connection was rate-limited ("reduced throughput rate limit") — a network-side cause for a transmit difference |
| `unresponsive_remote_events` non-zero | A peer stopped responding; volume differences follow |
| `ena_stat` `tx_bytes` moves in the opposite direction | **Traffic fell back off EFA onto TCP/ENA.** A real configuration defect — chase this first |
| `tx_bytes`/`tx_pkts` (mean packet size) shifted | The **message pattern** changed, not just volume — points at eager/rendezvous thresholds, chunk size, or collective algorithm |
| `send_bytes`, `send_wrs`, `avg_bytes_per_send_wr` differ | The difference is in two-sided send traffic — consistent with a workload or geometry change |
| `rdma_write_bytes`, `rdma_read_bytes`, `rdma_write_wrs`, `rdma_read_wrs` differ | The difference is in one-sided traffic — a middleware or algorithm change |
| `Unused RDMA Read` / `Unused RDMA Write` fired in one run only | **The runs used different transfer primitives.** Sufficient explanation for a byte-count difference at identical logical work |
| `EFA Errors` fired in one run only | EFA setup or operation failed there; the byte difference is a *symptom*. Investigate that first |
| EFA device count differs between runs | The stat is a per-device **average** — incomparable by construction |
| `Inconsistent Number of CPUs` / `Kernel Version Mismatch` / `Inconsistent Physical Memory` also fired | The runs differ in hardware or OS. **Fix those first**; this is one symptom of a broader mismatch |
| `Inconsistent Outbound Network Traffic` (`netstat`) also fired | Total IP transmit volume differs too — corroborates a genuine workload difference rather than an EFA-specific one |
| Run durations differ substantially | `Stat::Average` is a rate, so duration alone should not move it — unless the phase mix differs |
| Recording came from a different rank/node | **Asymmetric jobs differ per node.** The comparison is invalid regardless |

**Known false positives — a large share of firings:**

- **The change under test was supposed to change communication volume** (compression, aggregation, a
  better decomposition). The rule cannot know intent; that is why it says "verify".
- **Retransmission inflating one run's `tx_bytes`** while application traffic is identical. The
  transmit-side classic.
- **Different EFA device counts** — the `average` series makes values structurally incomparable.
- **Recordings from different nodes of an asymmetric job.**
- **Short runs.** The first sample is forced to 0 and few samples make a noisy mean; just over 10% on a
  10-sample run is not evidence.
- **Different phase mix** — a long idle startup dilutes the mean at identical steady-state throughput.
- **Base run with zero EFA traffic** — the ratio-1.0 substitution reads as an ordinary 100% difference.
- **The base run is the wrong baseline.** aperf picks it by ordering, not by intent; if the base run is the
  odd one out, every comparison finding reads backwards.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `retrans_bytes`, `retrans_pkts`, `retrans_timeout_events` | `efa_stat` | **Do this first on the transmit side.** Whether the extra bytes are retransmission rather than work (Nitro v4+). **No rules fire on these** — read manually |
| `tx_bytes` series **shape** in both runs | `efa_stat` | Whether the difference is a uniform rate change (different work) or confined to a phase (different mix). The mean hides both |
| `rx_bytes` | `efa_stat` | Whether the change is symmetric. See `Inconsistent Inbound EFA Traffics` |
| `tx_pkts`, `rx_pkts` | `efa_stat` | Bytes-per-packet — a mean-size shift means a message-pattern change |
| `send_bytes`, `send_wrs`, `avg_bytes_per_send_wr` | `efa_stat` | Whether two-sided send traffic accounts for the difference |
| `rdma_write_bytes`, `rdma_read_bytes`, `rdma_write_wrs`, `rdma_read_wrs` | `efa_stat` | Whether one-sided traffic accounts for it. See `Unused RDMA Read`/`Write` |
| `impaired_remote_conn_events`, `unresponsive_remote_events` | `efa_stat` | Whether a peer or path degraded mid-run. Read manually |
| `cmds_err`, `create_qp_err`, `reg_mr_err`, `alloc_mr_err`, `no_completion_cmds` | `efa_stat` | Whether EFA setup partially failed in one run. See `EFA Errors` |
| `lifespan` | `efa_stat` | Seconds since device init/reset — a much smaller value means a driver reset near the recording |
| EFA device count | `efa_stat` series list / `systeminfo` | **Whether the `average` series is comparable at all** |
| `tx_bytes`, `tx_cnt`, and the four allowance counters | `ena_stat` | **The fallback check** — EFA transmit down while ENA transmit up means traffic left the fabric, and may then hit ENA allowances |
| `IpExt:OutOctets`, `IpExt:InOctets` | `netstat` | Total IP traffic in both runs. See `Inconsistent Outbound Network Traffic` |
| `Kernel Version`, `CPUs`, instance type | `systeminfo` | Whether the runs are comparable at all |
| `MemTotal` | `meminfo` | Same. See `Inconsistent Physical Memory` |
| `aggregate`, `idle`, `system` | `cpu_utilization` | Whether the work difference also shows in CPU — corroborates "different amount of work" |
| Run duration, sample count, `--interval`/`--period` | run metadata / `aperf_stats` | Whether the means rest on comparable sampling. **No analytical rules — read manually** |
| On-CPU profile in both runs | `perf_profile` | Whether the same code paths and middleware ran. Requires `--profile`. **No analytical rules** |
| Per-process/rank set | `processes` | Whether the same ranks with the same geometry ran. **No analytical rules — read manually** |

## Guidance

Ordered. **This is a gate: resolve it before trusting any other comparative finding in the report.**

1. **Read the direction and the pairing.** The description states `greater than` or `less than` (the score
   does not — `abs: true`). Then check whether `Inconsistent Inbound EFA Traffics` also fired:
   - **Both fired** ⇒ symmetric scale change; go to step 4 (experiment setup).
   - **Only outbound** ⇒ this node's send behaviour changed. Go to step 2, then step 5.

2. **Check retransmission before concluding "more work" — the transmit-side-specific step.** Compare
   `retrans_bytes` and `retrans_pkts` across the runs. If they moved in step with `tx_bytes`, the extra
   bytes are the fabric resending, not the application sending more, and the finding is a **network**
   observation. Also read `retrans_timeout_events` (path changes), `impaired_remote_conn_events` (remote
   rate limiting), and `unresponsive_remote_events`.

3. **Check whether the base run transmitted nothing.** `100.00% greater than <base> (0)` is the ratio-1.0
   substitution: the base run put no bytes on the fabric. Verify EFA was working there before drawing any
   other conclusion.

4. **Verify the two runs were supposed to do the same work.** Input size, iteration count, batch size,
   dataset, duration, rank count, node count, ranks-per-node, and **which node was recorded**. This is the
   cause in most firings and it is a setup problem. If the change under test was *meant* to change
   transmitted volume (compression, aggregation, a better decomposition), the finding is the intended
   result — say so and close it.

5. **Check for a send-side protocol change.** Derive mean packet size (`tx_bytes`/`tx_pkts`) in both runs
   and compare `send_wrs` / `avg_bytes_per_send_wr` and the RDMA counters. A shift in message size or in
   which primitives are used points at eager/rendezvous thresholds, chunk size, pipelining, collective
   algorithm, or a different libfabric/MPI/NCCL version — all of which change transmitted bytes for
   identical logical work.

6. **Check for fallback off EFA — the case that is a real defect.** Compare `ena_stat` `tx_bytes`. **EFA
   transmit down while ENA transmit up means traffic left the fabric** for TCP. Confirm with `EFA Errors`
   and the setup-error counters. Then check the ENA allowance counters, because TCP fallback can push the
   instance into bandwidth or PPS shaping — a second-order failure worth catching.

7. **Confirm the runs are structurally comparable.** Check the **EFA device count** in each (the stat is
   the cross-device `average`). Then check whether `Inconsistent Number of CPUs`,
   `Kernel Version Mismatch`, or `Inconsistent Physical Memory` fired; if so, **fix those first**.

8. **Look at the series shape, not the mean.** A uniform rate difference means different work; a difference
   confined to one phase means a different phase mix, which the mean misrepresents and which re-windowing
   may salvage.

9. **Rule out sampling artifacts.** Short runs, differing `--interval`/`--period`, and the forced-zero
   first sample all move the mean.

10. **Do not rank this against performance findings by score.** It can reach five figures and top the list.
    Report it as a **validity gate** — "the runs are not comparable, here is why" — then report performance
    findings qualified by whether the comparison held.

11. **Re-run the comparison with matched runs** if a performance comparison was the goal. A comparison
    across runs that did different work cannot be repaired by reasoning about it.

## Priority and execution risk

**Priority: P0 — Blocking** for any HPC/ML throughput or scaling comparison.

**Execution risk: R0 — Read-only** to resolve; **R4 — Infrastructure change** to act on a fabric fallback.

Scored **`Critical` (−256)**, comparator **`Greater`** — exactly 10.00% does not fire.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `|avg(tx_bytes) delta| > 10%` versus the base run.

```
STEP 0 — Does EFA data exist in BOTH runs?
  IF one run lacks efa_stat entirely
  THEN → "No EFA metrics available"; rule returned early, NO finding (P0, R4)
       → one run had no fabric. Verify manually; silence is not parity.
  ELSE continue.

STEP 1 — Parse the observed values.
  Format: The avg in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).
  IF exactly `100.00% greater than`
  THEN → AMBIGUOUS: zero base forces the ratio to 1.0 (P2, R0)
       → a zero base means the run TRANSMITTED nothing over EFA — check
         `Unused RDMA Write` and treat as a fabric/config failure, not a delta

STEP 2 — Compare against INBOUND EFA. For collectives these should track closely.
  IF inbound and outbound moved together, similar magnitude
  THEN → a scale or problem-size change (P0, R0)
  IF outbound moved but inbound did NOT
  THEN → asymmetric: suspect a broadcast/scatter phase difference, or this rank
         became a sender bottleneck (P1, R0)
       → in a balanced collective, a large asymmetry is itself suspicious:
         verify the job actually completed the same phases in both runs
  IF outbound FELL sharply while inbound held
  THEN → the local rank could not transmit: check `High SRD Resource Utilization`
         and `EFA Errors` for a send-side ceiling or error path (P1, R4)
       → verify: after relieving the send-side ceiling, tx_bytes should rise back
         toward the inbound magnitude and this finding should stop firing. If
         `EFA Errors` was the cause, its counters should return to zero

STEP 3 — Check for a fabric FALLBACK to TCP.
  IF outbound EFA bytes are much LOWER
  AND `netstat` outbound is much HIGHER
  THEN → the workload fell back from EFA/SRD to TCP over ENA (P0, R4)
       → concrete causes: libfabric provider not selected, EFA device permissions,
         peers outside the placement group, security-group rules blocking EFA
         (EFA requires an all-traffic self-referencing rule), driver mismatch
       → verify: `Unused RDMA Write` should also fire; ENA outbound allowance
         findings may now appear because traffic moved onto the ENA path

STEP 4 — Check the ABSOLUTE averages, then size the delta.
  This rule shares `time_series_stat_run_comparison` with the netstat gates and has
  NO absolute floor (time_series_stat_run_comparison_rule.rs:97-110), so a trivial
  absolute change on a near-idle fabric produces a large ratio. At Score::Critical
  the base score is -256, making the inflation 128x that of the netstat gates,
  which were observed firing at -61.91 on 2.4 kB/s of idle background traffic.
  IF both `avg(tx_bytes)` values are small relative to the fabric's capability
  THEN → NOISE. The fabric was not carrying the job in either run (P3, R0)
       → verify: `Unused RDMA Read` / `Unused RDMA Write`, then `p50` versus `avg`
       → DERIVED from the shared template, not observed — no EFA interface was
         available to test it. The netstat equivalent WAS observed
  IF |delta| is 10-25%  → rank count, collective algorithm, or topology choice (P1, R0)
  IF |delta| is 25-100% → different problem size or decomposition (P0, R4)
    → verify: re-record both runs at matched rank and node count; the delta
      should fall below 10% and this finding should stop firing
  IF |delta| > 100%     → different job, or fallback per STEP 3 (P0, R4)
    → verify: STEP 3 first. With no netstat rise, confirm job identity from the
      launcher rather than attributing the delta to the host

STEP 5 — What survives?
  VALID  : configuration findings, `EFA Errors`
  VOID   : throughput, scaling efficiency, per-rank cost, the statistical table
           for EFA rate metrics
  CAUTION: tx_bytes is summed across EFA DEVICES; a differing number of attached
           EFA interfaces changes the total for identical logical traffic

INSUFFICIENT DATA
  IF the base run lacks `tx_bytes` → rule returned early, NO finding (P0, R0)
```

## Runtime-specific consequences

As with inbound, **Python is the only target runtime commonly present on EFA**, acting as an orchestrator over
native collectives (NCCL, MPI). The byte movement is in native libraries; the interpreter is not on the data
path.

The send side is where a **provider misselection** shows up most clearly: a job that cannot *transmit* over EFA
falls back immediately and visibly, whereas receive-side problems can be masked by peers retrying. So when
exactly one direction of the EFA pair fires, **outbound is the more likely to indicate a configuration fault
rather than a workload difference.**

Confirm provider selection explicitly (R0): `NCCL_DEBUG=INFO` should name the EFA/`ofi` provider, and
`fi_info -p efa` should list the device on both hosts. A silent fallback leaves the Python process looking
identical while moving all traffic onto TCP — which is precisely the STEP 3 signature.

## Architecture-specific considerations

EFA collection is architecture-neutral — aperf reads `/sys/class/infiniband` regardless of CPU
(`src/data/efa_stat.rs:26`–`:46`, silently returning empty when the directory is absent). Architecture matters
here for what surrounds the fabric.

Confirm architecture from `pmu_config.json` ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before reading the delta.

| Observed | Reading | Action |
|---|---|---|
| EFA traffic delta, architectures identical | Normal fabric-parity question | Follow the tree above |
| EFA traffic delta, architectures **differ** | EFA-capable instance types differ across families in fabric bandwidth and adapter count; the delta may be a platform ceiling | Verify both instance types are EFA-enabled and equivalently provisioned (P0, R4) |
| EFA absent on one side entirely | The instance type is not EFA-enabled, or EFA was not attached | Not an application finding (P1, R4) |

**The collective-communication library is the architecture-specific configuration request that matters here.**
NCCL, its arm64 equivalents, and the libfabric EFA provider must all be built and selected for the target
platform. When they are not, traffic silently falls back to TCP — which is exactly the highest-value cause in
the tree above, and it becomes *more* likely immediately after an architecture migration because the fabric
stack is rebuilt.

Manual checks, none of them visible to aperf: `fi_info -p efa` (is the provider present for this
architecture?), `NCCL_DEBUG=INFO` (which transport was actually selected?), and confirmation that the MPI or
collective library was compiled for the target architecture rather than installed from a mismatched binary.

**Python is the runtime that matters** for this finding class, since HPC and ML launchers are almost always
Python; its native extensions (the MPI bindings, the collective library wrappers) are architecture-specific
wheels and are the most likely component to have fallen back to a generic build
([ARCHITECTURE.md](../ARCHITECTURE.md) §5.3).

## Verification

Match rank count, problem size, and placement group; re-run and confirm the finding disappears. If EFA transmit
stays low while netstat egress is high, the fabric is being bypassed — pursue that as the finding.

## Do not

- **Do not read this as a performance problem.** It says the runs are not comparable. `Critical` here is
  about measurement validity, not system health.
- **Do not conclude "this run did more work" from a higher `tx_bytes` without checking `retrans_bytes`.**
  Retransmitted bytes are transmitted bytes.
- **Do not read the score as severity of a defect.** It scales linearly with the discrepancy and can reach
  five figures.
- **Do not take the direction from the score.** `abs: true` makes it direction-blind; only the description
  says `greater than` or `less than`.
- **Do not read `100.00% greater than <base> (0)` as a 2× difference.** It is the base-stat-zero
  substitution: the base run transmitted nothing over EFA.
- **Do not trust other comparative findings until this is explained.** A run that did less work looks
  faster on every rate metric.
- **Do not compare instances with different EFA device counts.** The stat is a cross-device average.
- **Do not compare recordings from different nodes of an asymmetric job.**
- **Do not act on a difference just over 10% from a short run.**
- **Do not overlook the fallback case.** EFA transmit down with ENA transmit up is a genuine configuration
  defect hiding inside a comparison finding — and it can trigger ENA allowance breaches downstream.
- **Do not assume the base run is the correct baseline.** aperf picks it by ordering.
- **Do not report this as a defect when reduced communication was the goal.**

## References

- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — base run from
  `get_base_run_name()`, base run skipped, `original_delta_ratio = 0.0` if equal, **`1.0` if the base stat
  is 0**, else `(cur − base)/base`; `abs` applied to the comparison and score only; description shows the
  **signed** ratio.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Critical = −256`,
  `src/analytics/mod.rs:147`.
- Formatting: `delta_ratio_to_percentage_string` and `formatted_number_string`,
  `src/computations/mod.rs:162` and `:176` — K/M/G/T suffixes, values **truncated** to 2 decimals.
- Delta processing: `add_accumulative_data_point` at `src/data/efa_stat.rs:243`; aggregation is
  `time_series_data_processor_with_average_aggregate!`, and `stats_series_idx`
  (`src/data/common/time_series_data_processor.rs:312`) selects the **`average`** series on multi-device
  instances.
- Metric semantics: `tx_bytes`, `tx_pkts`, `retrans_bytes`, `retrans_pkts`, `retrans_timeout_events`,
  `impaired_remote_conn_events`, `unresponsive_remote_events` in
  `src/report_frontend/src/definitions/data-descriptions.ts` (the last five "Available on Nitro v4 and
  later instances", `desired: "lower"`).
- Related playbooks: `inconsistent-inbound-efa-traffics.md`, `efa-errors.md`,
  `unused-rdma-read.md`, `unused-rdma-write.md`,
  `../netstat/inconsistent-outbound-network-traffic.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`, `../systeminfo/kernel-version-mismatch.md`,
  `../meminfo/inconsistent-physical-memory.md`.
- [Monitor an EFA](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-working-monitor.html)
- [Elastic Fabric Adapter](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa.html)
