---
rule_name: Inconsistent Inbound EFA Traffics
data_type: efa_stat
data_key: rx_bytes
template: time_series_stat_run_comparison
condition: "abs(delta_avg(rx_bytes)) > 0.1"
base_score: Critical
score_sign: negative
requires_comparison: true
aperf_message: "The average numbers of bytes received by EFA are different. Verify if this is the expected behavior."
source: src/analytics/rules/efa_stat.rs:34
---

# Inconsistent Inbound EFA Traffics

## What fired

The **average** of `rx_bytes` in this run differs from the same average in the **base run** by **more
than 10%** in either direction. `abs: true`, so an increase and a decrease of the same magnitude score
identically.

Base score `Critical` (**−256**), aperf's most severe score. **Comparison-only rule** — it cannot fire
on a single-run report, and it never fires *on* the base run (the template skips it).

**This is a validity finding, not a performance finding.** It does not say inbound EFA traffic is too
high or too low. It says **the two runs did not receive the same amount of data over EFA, so they are not
comparable** — and every other cross-run conclusion in the report is suspect until that is explained.
That is why it carries `Critical` weight despite describing no degradation: it invalidates the comparison
itself.

Treat it as a **gate**. Resolve it before reading any other comparative finding.

## Reasoning

`rx_bytes` is the number of bytes received by the EFA device — a cumulative hardware counter read from
the EFA driver, per EFA device, counting since instance launch or driver reset (`data-descriptions.ts`;
`desired: "depends"`, `defaultUnit: "Count"`).

**Why a 10% difference in received bytes is `Critical`.** aperf's comparison mode exists to answer "what
changed between run A and run B". That question only has an answer if both runs did the *same work*. For
a tightly-coupled EFA workload — HPC solvers, distributed training, anything using libfabric/MPI/NCCL —
the volume of data received over the fabric is one of the most direct proxies for how much work the run
actually performed. If run B received 30% fewer bytes than run A, then:

- Any latency or throughput improvement in run B may simply be **less work**, not better performance.
- Any regression may be **more work**, not worse performance.
- Per-second rates, CPU efficiency, and cache metrics are all being compared across different workloads.

So the rule is doing something aperf's other comparison rules also do (`Inconsistent Physical Memory`,
`Inconsistent Number of CPUs`, `Kernel Version Mismatch`, `JVM Version Comparison` — all `Critical`):
**flagging that the experimental control was broken.** These findings are not about the system; they are
about the measurement.

**Why 10% specifically.** It is tight enough to catch real workload differences (a different input size,
a different rank count, a truncated run) and loose enough to tolerate normal run-to-run variance in a
workload that genuinely does the same thing. It is a *tripwire*, not a diagnosis — a run-length
difference of a few percent will not trip it, a different problem size will.

**Why inbound and outbound are separate rules.** `Inconsistent Outbound EFA Traffics` fires on
`tx_bytes`. The two firing together points at a symmetric change (different problem size, different
node count, different run duration). **Only one firing is the more interesting signal**: it means the
communication *pattern* changed shape, not just its scale — for example a change in collective algorithm,
in rank-to-node mapping, or in which node this recording came from within the job.

**The plausible causes, ordered by how often they are the real answer:**

1. **The runs did different amounts of work.** Different input, problem size, iteration count, batch
   size, dataset, or duration. By far the most common cause and usually an oversight in how the
   experiment was set up.
2. **Different job geometry.** A different number of ranks, nodes, or ranks-per-node changes how much
   data any single node receives, even for identical total work.
3. **The two recordings came from different nodes of the job.** In a job with asymmetric communication
   (a root rank, a parameter server, an unbalanced decomposition) node A and node B legitimately receive
   different volumes. Comparing them is meaningless regardless of the runs.
4. **Different run durations.** `Stat::Average` is a mean over per-interval deltas, so it is a *rate* and
   is largely duration-independent — but a run that includes a long idle startup or teardown phase dilutes
   the mean. A short run also has fewer samples and a noisier mean, and the first sample is forced to 0.
5. **A different middleware or transport path.** A change in libfabric provider, MPI implementation,
   NCCL version, protocol thresholds, or collective algorithm changes both the byte count and the message
   pattern for the same logical work. Chunking and pipelining choices in particular can move total bytes
   substantially.
6. **Fallback off EFA.** If EFA was unavailable, misconfigured, or partially initialized in one run,
   traffic went over TCP/ENA instead and `rx_bytes` collapses. Check `ena_stat` in both runs — a drop in
   EFA bytes with a rise in ENA bytes is the fingerprint, and it is a real and serious configuration
   defect, not just a comparison problem.
7. **A different EFA device count.** The stat is read from the auto-generated **`average`** series when
   the instance has more than one EFA device. Comparing a 1-device instance to a 4-device instance
   compares a total against a per-device mean — a large apparent difference with no change in traffic.
8. **Failure or retransmission in one run.** Heavy `retrans_bytes`, `impaired_remote_conn_events`, or
   `unresponsive_remote_events` inflate or deflate byte counts and indicate the fabric itself behaved
   differently.
9. **Genuinely the thing you were testing.** If the change under test was *meant* to reduce
   communication volume — a better decomposition, gradient compression, a smarter collective — then this
   finding is the intended result and the message's "verify if this is the expected behavior" is answered
   "yes". **This is a real and common case; do not report it as a defect.**

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run_name} ({value}) is {delta_ratio_string} {base_run_name} ({base_value}).
```

Both `{run_name}` and `{base_run_name}` are **run names**, not metric names — unlike
`time_series_stat_intra_run_comparison`, where both placeholders are metrics. Example:

```
The average in run_b (1.24M) is 34.20% less than run_a (1.88M).
```

Four things to know about that line:

1. **The values are formatted with K/M/G/T** (`formatted_number_string`), and truncated — not rounded —
   to two decimals. `1.24M` could be anything from 1,240,000 to 1,249,999.
2. **The ratio shown is signed; the score uses the absolute value.** `abs: true` applies to the
   comparison and the score only. So the description tells you the *direction* (`greater than` /
   `less than`) while the score does not. Read the direction from the text, always.
3. **`equal to`** appears only when the two stats are exactly equal — in which case the ratio is 0 and
   the rule cannot fire. You will never see it on this finding.
4. **If the base-run average is 0, the ratio is substituted with `1.0`** ("treat the current stat as 100%
   larger"), *regardless of how large the current value is*. So a description reading `100.00% greater
   than run_a (0)` means **the base run received no EFA traffic at all** — a categorical difference, not
   a 2× one. That is a much stronger statement than the number suggests.

Score math — `compute_finding_score(abs_ratio, 0.1, −256)`, general branch, `delta = ratio/0.1`:

| abs(ratio) | meaning | score |
|---|---|---|
| 0.10 | at the threshold — does **not** fire (`Greater`, not `GreaterEqual`) | — |
| 0.11 | 11% different | **−281.60** |
| 0.125 | 12.5% | **−320.00** |
| 0.15 | 15% | **−384.00** |
| 0.20 | 20% | **−512.00** |
| 0.25 | 25% | **−640.00** |
| 0.50 | 50% | **−1280.00** |
| 1.00 | 100% (2×), **or base run = 0** | **−2560.00** |
| 2.00 | 3× | **−5120.00** |
| 5.00 | 6× | **−12800.00** |
| 10.00 | 11× | **−25600.00** |

**The score is unbounded and grows linearly with the difference.** It is genuinely monotonic here — a
larger score really does mean a larger discrepancy — so it *is* worth ranking on, unlike the flat-score
rules. But note the magnitudes: at `Critical` × 10, a run-comparison finding can reach five figures and
will dominate a score-ordered findings list, drowning out real performance findings. **A high score here
means "the comparison is badly broken", not "the system is badly broken".**

Also note the base-run-zero substitution caps at ratio `1.0` → −2560.00. A base run with zero EFA traffic
scores *lower* than a run that differs by 2×, even though it is the more categorical difference.

## Interpretation

Start with direction and pairing:

| Observation | Reading |
|---|---|
| Both inbound **and** outbound fired | **A symmetric change in scale.** Different problem size, node count, or run length. Look at the experiment setup first, not the system |
| Only **inbound** fired | **The communication pattern changed shape.** Receive volume moved without send volume — a different collective algorithm, a different rank/node mapping, a different recording node, or a receive-side fallback. The more diagnostic case |
| Description says **`less than`** | This run received less. Either it did less work, or EFA traffic fell back to TCP/ENA, or the run was truncated |
| Description says **`greater than`** | This run received more. Either more work, more retransmission, or a chattier communication path |
| Base value shown as **`0`** with `100.00% greater` | **The base run had no EFA inbound traffic.** Categorical, not proportional — the base run probably did not use EFA at all. Verify EFA was working in the base run before anything else |
| Difference just over 10% | Near the tripwire. Check run duration and sample count before treating it as real |
| Difference over 100% | The runs are doing materially different work. Stop and fix the experiment |

Then localize:

| Evidence | Reading |
|---|---|
| `ena_stat` `rx_bytes` moves in the opposite direction | **Traffic fell back off EFA onto TCP/ENA.** A real configuration defect, not just a comparison problem — chase this first |
| `EFA Errors` fired in one run only | EFA initialization or operation failed in that run; the byte difference is a *symptom*. Investigate that finding first |
| `recv_bytes` / `recv_wrs` differ proportionally | The difference is in two-sided messaging volume — consistent with a workload/geometry change |
| `rdma_write_recv_bytes` / `rdma_read_resp_bytes` differ | The difference is in one-sided traffic — consistent with a middleware or algorithm change |
| `Unused RDMA Read` / `Unused RDMA Write` fired in one run only | **The runs used different transfer primitives.** A middleware or provider change, and a sufficient explanation for a byte-count difference |
| `retrans_bytes`, `retrans_pkts` much higher in one run | Fabric-level retransmission inflating byte counts (Nitro v4+). Read manually — no rules fire on these |
| `impaired_remote_conn_events`, `unresponsive_remote_events` non-zero | The fabric degraded during one run; the comparison is contaminated by a network event |
| `rx_drops` differs | Receive-side drops differ; the runs did not see the same delivery quality |
| EFA device count differs between runs | **The stat is a per-device average.** Different device counts make the numbers incomparable by construction |
| `Inconsistent Number of CPUs` or `Kernel Version Mismatch` also fired | The runs differ in hardware or OS too. **Fix those first** — this finding is one symptom of a broader mismatch |
| `Inconsistent Physical Memory` also fired | Same: different instance shapes. Not an EFA problem |
| Run durations differ substantially | `Stat::Average` is a rate, so duration alone should not move it — unless the phase mix differs (idle startup, teardown) |
| Recording came from a different rank/node | **Asymmetric jobs legitimately differ per node.** The comparison is invalid no matter what the runs did |

**Known false positives — a large share of firings:**

- **The change under test was supposed to reduce (or increase) communication.** Then the finding is the
  intended result. The rule cannot know your intent, which is exactly why the message says "verify if
  this is the expected behavior".
- **Different EFA device counts** between the compared instances — the `average` series makes the values
  structurally incomparable.
- **Recordings from different nodes of an asymmetric job.**
- **Short runs.** The first sample of every metric is forced to 0 and few samples make a noisy mean; a
  difference just over 10% on a 10-sample run is not evidence.
- **Different phase mix.** A run with a long idle startup dilutes the average even at identical steady-
  state throughput. Compare the *shape* of the series, not just the mean.
- **Base run with zero EFA traffic.** The ratio-1.0 substitution makes this look like an ordinary 100%
  difference when it is categorical.
- **Retransmission inflating one run's counters** — the application-level traffic may be identical.
- **The base run is the wrong baseline.** aperf picks the base run by ordering, not by intent; if the
  base run is the odd one out, every comparison finding in the report reads backwards.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `rx_bytes` series **shape** in both runs | `efa_stat` | **Do this first.** Whether the difference is a uniform rate change (different work) or a phase difference (different mix). The mean hides both |
| `tx_bytes` | `efa_stat` | Whether the change is symmetric. See `Inconsistent Outbound EFA Traffics` |
| `rx_pkts`, `tx_pkts` | `efa_stat` | Bytes-per-packet — a change in mean size means a message-pattern change, not just volume |
| `recv_bytes`, `recv_wrs`, `avg_bytes_per_recv_wr` | `efa_stat` | Whether two-sided receive traffic accounts for the difference |
| `rdma_write_recv_bytes`, `rdma_read_resp_bytes` | `efa_stat` | Whether one-sided (target-side) traffic accounts for it. **No rules fire on these** — read manually |
| `rx_drops` | `efa_stat` | Delivery quality difference (`desired: "lower"`) |
| `retrans_bytes`, `retrans_pkts`, `retrans_timeout_events` | `efa_stat` | Whether one run's bytes are inflated by SRD retransmission (Nitro v4+). Read manually |
| `impaired_remote_conn_events`, `unresponsive_remote_events` | `efa_stat` | Whether the fabric degraded mid-run, contaminating the comparison. Read manually |
| `cmds_err`, `create_qp_err`, `reg_mr_err`, `alloc_mr_err` | `efa_stat` | Whether EFA setup partially failed in one run. See `EFA Errors` |
| `lifespan` | `efa_stat` | Seconds since device init/reset — a much smaller value means a driver reset near the recording |
| EFA device count | `efa_stat` series list / `systeminfo` | **Whether the `average` series is comparable at all** |
| `rx_bytes`, `tx_bytes`, `rx_cnt`, `tx_cnt` | `ena_stat` | **The fallback check** — EFA bytes down while ENA bytes up means traffic left the fabric |
| `IpExt:InOctets`, `IpExt:OutOctets` | `netstat` | Total IP traffic in both runs. See `Inconsistent Inbound Network Traffic` |
| `Kernel Version`, `CPUs`, instance type | `systeminfo` | Whether the runs are comparable at all. See `Kernel Version Mismatch`, `Inconsistent Number of CPUs` |
| `MemTotal` | `meminfo` | Same. See `Inconsistent Physical Memory` |
| `aggregate`, `idle`, `system` | `cpu_utilization` | Whether the work difference shows up in CPU too — corroborates "different amount of work" |
| Run duration, sample count, `--interval`/`--period` | run metadata / `aperf_stats` | Whether the means rest on comparable sampling. **No analytical rules — read manually** |
| On-CPU profile in both runs | `perf_profile` | Whether the same code paths ran. Requires `--profile`. **No analytical rules** |
| Per-process/rank set | `processes` | Whether the same ranks with the same geometry ran. **No analytical rules — read manually** |

## Guidance

Ordered. **This is a gate: resolve it before trusting any other comparative finding in the report.**

1. **Read the direction and the pairing before anything else.** The description states `greater than` or
   `less than` (the score does not — `abs: true`). Then check whether
   `Inconsistent Outbound EFA Traffics` also fired:
   - **Both fired** ⇒ symmetric scale change. Go to step 3 (experiment setup).
   - **Only inbound** ⇒ the communication pattern changed shape. Go to step 4.

2. **Check whether the base run had zero EFA traffic.** A description reading `100.00% greater than
   <base> (0)` is the ratio-1.0 substitution, meaning the base run received *nothing* over EFA. That is
   categorical: verify EFA was actually working in the base run before drawing any other conclusion.

3. **Verify the two runs were supposed to do the same work.** Input size, iteration count, batch size,
   dataset, duration, rank count, node count, ranks-per-node, and **which node the recording came from**.
   This is the cause in most firings, and it is a setup problem, not a system problem. If the change under
   test was *meant* to change communication volume, the finding is the intended result — say so and close
   it.

4. **Check for fallback off EFA — the one case that is a real defect.** Compare `ena_stat` `rx_bytes`
   across the runs. **EFA bytes down while ENA bytes up means traffic left the fabric** and is running over
   TCP instead. Confirm with `EFA Errors` and the setup-error counters (`create_qp_err`, `reg_mr_err`,
   `alloc_mr_err`, `cmds_err`). This is worth fixing regardless of the comparison.

5. **Confirm the two runs are structurally comparable.** Check the **EFA device count** in each — the stat
   is the cross-device `average`, so a 1-device and a 4-device instance are not comparable by construction.
   Then check whether `Inconsistent Number of CPUs`, `Kernel Version Mismatch`, or
   `Inconsistent Physical Memory` also fired; if so, **fix those first** — this finding is a symptom of a
   broader mismatch, not an independent problem.

6. **Look at the series shape, not the mean.** A uniform rate difference across the whole run means
   different work. A difference concentrated in one phase means a different phase mix (long startup,
   truncated teardown, a stall) — which the mean misrepresents. This distinction determines whether the
   comparison can be salvaged by re-windowing.

7. **Rule out sampling artifacts.** Short runs, differing `--interval`/`--period`, and the forced-zero
   first sample all move the mean. A difference just over 10% on a short run is not evidence.

8. **Check whether the transfer primitives changed.** If `Unused RDMA Read` or `Unused RDMA Write` fired
   in one run only, the middleware or provider changed and byte counts legitimately differ for identical
   logical work. Same if bytes-per-packet (`rx_bytes`/`rx_pkts`) shifted.

9. **Rule out fabric events.** Much higher `retrans_bytes`, `impaired_remote_conn_events`, or
   `unresponsive_remote_events` in one run means the network misbehaved and the byte counts reflect
   retransmission, not application traffic.

10. **Do not rank this finding against performance findings by score.** At `Critical` × the ratio it can
    reach five figures and will top a score-ordered list. Report it as a **validity gate** — "the runs are
    not comparable, here is why" — and only then report the performance findings, qualified by whether the
    comparison held.

11. **Once explained, re-run the comparison with matched runs** if the goal was a performance comparison.
    A comparison across runs that did different work cannot be repaired by reasoning about it.

## Priority and execution risk

**Priority: P0 — Blocking** for any HPC/ML throughput comparison. A collective-communication workload whose
inbound EFA byte count differs did not run the same problem.

**Execution risk: R0 — Read-only** to resolve (match the job configuration and re-run). Acting on what it
reveals is typically **R4 — Infrastructure change** (placement groups, instance count, fabric configuration).

Scored **`Critical` (−256)** — 128× the netstat equivalent, and the comparator is **`Greater`, not
`GreaterEqual`**, so a delta of exactly 10.00% does *not* fire here while it would on netstat.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `|avg(rx_bytes) delta| > 10%` versus the base run.

```
STEP 0 — Does EFA data exist in BOTH runs?
  EFA is collected only when /sys/class/infiniband is non-empty — HPC-capable
  instance types with the EFA driver installed and an EFA interface attached.
  IF one run lacks efa_stat entirely
  THEN → "No EFA metrics available". The rule returned early: NO finding (P0, R4)
       → this is a bigger problem than a traffic delta: one run had no fabric at all
       → verify manually; absence of this finding does NOT mean parity
  ELSE continue.

STEP 1 — Parse the observed values.
  Format: The avg in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).
  T/G/M/K at 2 dp. Score: >10% -> -256 and up; 100% -> -2560.

  IF the delta reads exactly `100.00% greater than`
  THEN → AMBIGUOUS: base_stat == 0.0 forces the ratio to 1.0 (P2, R0)
       → if the base value is 0, the base run did NO RDMA receive at all:
         the fabric was idle or unused, not half-loaded
       → cross-check `Unused RDMA Read` / `Unused RDMA Write`

STEP 2 — Size the delta against collective-communication expectations.
  FIRST check the ABSOLUTE averages. This rule shares
  `time_series_stat_run_comparison` with the netstat gates and has NO absolute
  floor (time_series_stat_run_comparison_rule.rs:97-110), so a trivial absolute
  change on a near-idle fabric yields a large ratio and a large score. At
  Score::Critical the base score is -256, so the inflation is 128x worse here than
  for the netstat gates, which fired at -61.91 on 2.4 kB/s of idle background
  traffic on a test host.
  IF both `avg(rx_bytes)` values are small relative to the fabric's capability
     (idle or barely-used EFA, not a running collective)
  THEN → NOISE, not a workload difference. The fabric was not carrying the job in
         either run (P3, R0)
       → verify: cross-check `Unused RDMA Read` / `Unused RDMA Write`. If either
         fired, the fabric was unused and this delta is meaningless
       → verify: `p50` versus `avg`, and `max` versus `p90` — a single burst moves
         `avg` alone
       → this is DERIVED from the shared template, not observed: no EFA interface
         was available to test it. The netstat equivalent WAS observed
  IF |delta| is 10-25%
  THEN → suspect a different RANK COUNT, a different collective algorithm choice,
         or ring-vs-tree topology selection by the MPI/NCCL runtime (P1, R0)
       → these change bytes-on-the-wire for the SAME logical problem
  IF |delta| is 25-100%
  THEN → different problem size, different parallel decomposition, or a different
         number of nodes (P0, R4)
       → verify: re-record both runs at the SAME rank and node count. The delta
         should collapse below 10% and this finding should stop firing — if it
         persists at matched geometry, the cause is not decomposition
  IF |delta| > 100%
  THEN → a different job entirely, or a fabric fallback (see STEP 3) (P0, R4)
       → verify: STEP 3 first. If netstat did NOT rise, confirm the job identity
         from the launcher before attributing the delta to anything on the host

STEP 3 — Check for a fabric FALLBACK, the highest-value cause.
  IF inbound EFA bytes are much LOWER in the compared run
  AND `netstat` inbound is much HIGHER
  THEN → traffic fell back from EFA/SRD to TCP over ENA (P0, R4)
       → this is a MAJOR regression with a concrete cause, not a load difference
       → likely: libfabric/EFA provider not selected, missing EFA device
         permissions, peers outside the placement group, or a driver version change
       → verify: `Unused RDMA Read`/`Unused RDMA Write` should also fire
  IF EFA bytes fell with NO corresponding netstat rise
  THEN → the job genuinely communicated less: smaller problem or fewer ranks (P0, R0)

STEP 4 — Check symmetry with OUTBOUND EFA.
  IF both directions moved proportionally
  THEN → a scale or problem-size change (P0, R0)
  IF only inbound moved
  THEN → asymmetric collective pattern: suspect a gather/reduce-heavy phase
         difference, or one rank acting as a bottleneck (P1, R0)

STEP 5 — What survives?
  VALID  : configuration findings (THP, ENA Express state), EFA ERROR counters
           (`EFA Errors` — errors are errors regardless of volume)
  VOID   : all HPC throughput comparisons, per-rank efficiency, scaling efficiency
           claims, the statistical table for EFA rate metrics
  CAUTION: rx_bytes is summed across EFA DEVICES. A run with more EFA interfaces
           attached reports more bytes for the same logical traffic

INSUFFICIENT DATA
  IF the base run lacks `rx_bytes`
  THEN → rule returned early; NO finding produced (P0, R0)
```

## Runtime-specific consequences

EFA workloads are overwhelmingly C/C++/Fortran MPI and Python-driven ML. Of the four target runtimes, **only
Python is commonly relevant here**, and its role is as an orchestrator rather than the data path:

| Runtime | Typical role on EFA | What to check |
|---|---|---|
| **Python** | PyTorch/JAX driving NCCL or MPI; the byte movement happens in native libraries, not the interpreter | `NCCL_DEBUG=INFO` to confirm the EFA provider was selected. A silent fallback to TCP is the classic cause of STEP 3, and the Python process looks identical either way |
| **Java** | Rare on EFA. Some analytics frameworks over TCP only | If Java is present with EFA, the fabric is probably unused by it — expect `Unused RDMA` findings |
| **.NET** | Effectively absent from EFA workloads | Not applicable |
| **Perl** | Not applicable | — |

**The Python-specific trap:** `processes` shows only a truncated `comm` (`python3`) for a distributed training
job, and only the top 16 by CPU. A multi-process training run may show several `python3` entries with no
indication of rank or role. **aperf cannot tell you which rank is which** — correlate with the job scheduler's
logs instead.

## Architecture-specific considerations

EFA collection is architecture-neutral — aperf reads `/sys/class/infiniband` regardless of CPU
(`src/data/efa_stat.rs:26`–`:46`, silently returning empty when the directory is absent). Architecture matters
here for what surrounds the fabric.

Confirm architecture from `pmu_config.json` ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before reading the delta.

| Observed | Reading | Action |
|---|---|---|
| EFA traffic delta, architectures identical | Normal fabric-parity question | Follow the tree above |
| EFA traffic delta, architectures **differ** | EFA-capable instance types differ across families in fabric bandwidth and adapter count; the delta may be a platform ceiling | Verify both instance types are EFA-enabled and equivalently provisioned (P0, R4) |
| EFA absent on one side entirely | The instance type is not EFA-enabled, or EFA was not attached | Not an application finding (P1, R4) |

**The collective-communication library is the architecture-specific configuration request that matters here.**
NCCL, its arm64 equivalents, and the libfabric EFA provider must all be built and selected for the target
platform. When they are not, traffic silently falls back to TCP — which is exactly the highest-value cause in
the tree above, and it becomes *more* likely immediately after an architecture migration because the fabric
stack is rebuilt.

Manual checks, none of them visible to aperf: `fi_info -p efa` (is the provider present for this
architecture?), `NCCL_DEBUG=INFO` (which transport was actually selected?), and confirmation that the MPI or
collective library was compiled for the target architecture rather than installed from a mismatched binary.

**Python is the runtime that matters** for this finding class, since HPC and ML launchers are almost always
Python; its native extensions (the MPI bindings, the collective library wrappers) are architecture-specific
wheels and are the most likely component to have fallen back to a generic build
([ARCHITECTURE.md](../ARCHITECTURE.md) §5.3).

## Verification

Match rank count, problem size, and placement group; re-run and confirm the finding disappears. If EFA bytes
remain low while netstat traffic is high, the fabric is being bypassed — that is the actual finding, and it is
worth more than the comparison you were originally attempting.

## Do not

- **Do not read this as a performance problem.** It says the runs are not comparable. `Critical` here is
  about measurement validity, not system health.
- **Do not read the score as severity of a defect.** It scales linearly with the discrepancy and can reach
  five figures, dominating a score-ordered list. Larger means "more broken comparison", not "worse
  system".
- **Do not take the direction from the score.** `abs: true` means the score is direction-blind; only the
  description states `greater than` or `less than`.
- **Do not read `100.00% greater than <base> (0)` as a 2× difference.** It is the base-stat-zero
  substitution: the base run had no EFA traffic at all.
- **Do not trust other comparative findings until this is explained.** A run that did less work will look
  faster on every rate metric.
- **Do not compare instances with different EFA device counts.** The stat is a cross-device average.
- **Do not compare recordings from different nodes of an asymmetric job.**
- **Do not act on a difference just over 10% from a short run.** The first sample is forced to 0 and few
  samples make a noisy mean.
- **Do not overlook the fallback case.** EFA bytes down with ENA bytes up is a genuine configuration
  defect hiding inside a comparison finding.
- **Do not assume the base run is the correct baseline.** aperf picks it by ordering; if the base run is
  the anomaly, every comparison finding reads backwards.
- **Do not report this as a defect when reduced communication was the goal.** The rule asks you to verify
  intent; "yes, expected" is a complete resolution.

## References

- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — base run from
  `get_base_run_name()`, base run skipped, `original_delta_ratio = 0.0` if equal, **`1.0` if the base stat
  is 0**, else `(cur − base)/base`; `abs` applied to the comparison and score only; description shows the
  **signed** ratio.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Critical = −256`,
  `src/analytics/mod.rs:147`.
- Formatting: `delta_ratio_to_percentage_string` and `formatted_number_string`,
  `src/computations/mod.rs:162` and `:176` — K/M/G/T suffixes, values **truncated** to 2 decimals.
- Delta processing: `add_accumulative_data_point` at `src/data/efa_stat.rs:243`; aggregation is
  `time_series_data_processor_with_average_aggregate!`, and `stats_series_idx`
  (`src/data/common/time_series_data_processor.rs:312`) selects the **`average`** series on multi-device
  instances.
- Metric semantics: `rx_bytes`, `rx_pkts`, `rx_drops`, `retrans_bytes`, `impaired_remote_conn_events` in
  `src/report_frontend/src/definitions/data-descriptions.ts`.
- Related playbooks: `inconsistent-outbound-efa-traffics.md`, `efa-errors.md`,
  `unused-rdma-read.md`, `unused-rdma-write.md`,
  `../netstat/inconsistent-inbound-network-traffic.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`, `../systeminfo/kernel-version-mismatch.md`,
  `../meminfo/inconsistent-physical-memory.md`.
- [Monitor an EFA](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-working-monitor.html)
- [Elastic Fabric Adapter](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa.html)
