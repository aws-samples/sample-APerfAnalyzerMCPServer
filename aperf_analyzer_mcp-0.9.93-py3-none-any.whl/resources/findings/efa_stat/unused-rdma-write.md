---
rule_name: Unused RDMA Write
data_type: efa_stat
data_key: rdma_write_wrs
template: time_series_stat_threshold
condition: "max(rdma_write_wrs) == 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "No RDMA write operations were completed. Verify that this is the expected behavior."
source: src/analytics/rules/efa_stat.rs:25
---

# Unused RDMA Write

## What fired

The **max** of `rdma_write_wrs` was **equal to 0.0** — not a single RDMA write working request completed
in any interval of the recording.

Base score `Concerning` (**−1**), the mildest negative score aperf defines. Single-run rule. With an
`Equal` comparator against a threshold of 0 the score is **always exactly −1.00**.

This is the twin of `Unused RDMA Read`, and the same framing applies: it is a **capability-usage
observation**, not a degradation signal. EFA is present and reporting, but the one-sided *push*
primitive was never used. The message asks the right question — *"Verify that this is the expected
behavior"* — and for many workloads the answer is "yes".

The logic is sound: `rdma_write_wrs` is a genuine cumulative counter, so the delta processing it goes
through is correct, and `max == 0` really does mean the counter never advanced during the run.

**The one asymmetry with the read rule that matters:** RDMA *write* is the primitive most middleware
adopts first, so its absence is a somewhat stronger signal than a missing read. If a workload uses EFA
at all and has any one-sided transfer in it, writes are usually the ones present. Zero writes therefore
points more often at "this is not an RDMA workload" or "this node is purely a target" than at a
deliberate design choice.

## The processing caveat

`efa_stat` shares `ena_stat`'s time-series machinery — `time_series_data_processor_with_average_aggregate!`
(`src/data/efa_stat.rs:216`) — and every metric goes through `add_accumulative_data_point` (`:243`). For
`ena_stat` that treatment is a **defect**, because several of its metrics are gauges. Here it is
**correct**: `rdma_write_wrs` is a monotonic counter read from `/sys/class/infiniband/*/hw_counters/`, so
storing per-interval differences is what a rate rule wants. Four processing behaviours nevertheless change
how you read `max == 0`, and one of them can produce a spurious firing.

| Behaviour | Source | Effect on this finding |
|---|---|---|
| First accumulative sample forced to 0 (`ignore_first_accumulative_value: true`) | `time_series_data_processor.rs:73`, taken at `:218` | **The one real hazard.** A run with 1–2 usable samples yields `max == 0` regardless of what the workload did. Check the sample count before believing "never" |
| Decreasing samples **dropped, not clamped** — `return None` at `:214`, early return at `:150` | `time_series_data_processor.rs:189`–`:224` | A driver reset zeroes the counter; the decrease creates a **gap**, not a negative value. It cannot manufacture a false `max == 0` alone, but it can hide the interval in which writes happened |
| All-zero series compressed to first and last point only | `compress_all_zero_time_series_metric`, `:410`–`:427` | **A useful fingerprint.** When this rule fires the chart shows exactly **two points at zero**, not a flat line across every sample. That shape *is* the confirmation, not missing data |
| Auto-generated `average` aggregate **removed** when a metric has exactly 2 series | `stats_series_idx`, `:312`–`:319` | On a single-EFA-device instance the stat comes from the device's own series. The cross-device-average caveat applies only with **≥3 series** — i.e. 2+ EFA devices |

The dropped-decrease path emits one aggregated warning at the end of processing:

```
efa_stat.rdma_write_wrs.<device>: skipped N data points due to unexpected decrease of accumulative data.
```

If that line is in the aperf log for this metric, a reset happened and the run's coverage is broken.

**One derived-metric hazard worth knowing.** `avg_bytes_per_rdma_write_wr` is not collected; it is computed
in `src/data/efa_stat.rs:279` as `rdma_write_bytes / rdma_write_wrs` per device per interval, added with
plain **`add_data_point`** (not accumulative), and set to **`0.0` when the request count is zero**. So when
this finding fires, `avg_bytes_per_rdma_write_wr` is a flat zero too — that is arithmetic, not evidence.
Worse, when `add_accumulative_data_point` returns `None` for a dropped decrease the loop `continue`s at
`:249`, so that interval's bookkeeping is skipped and a **stale operand** is used for the average. Never
diagnose from `avg_bytes_per_*_wr` alone.

## Reasoning

`rdma_write_wrs` is "The number of completed RDMA write working requests." (`data-descriptions.ts`,
`desired: "depends"` — aperf declines to say whether higher is better, which is why the rule only asks.)

**What RDMA write is, and why zero is worth a question.** EFA offers three transfer families:

1. **Send/receive (two-sided)** — `send_wrs` / `recv_wrs`. Both sides post work; the receiver must have a
   buffer posted. Classic message passing, and the default for MPI point-to-point.
2. **RDMA write (one-sided, push)** — `rdma_write_wrs`. The initiator writes straight into the remote
   node's registered memory. **The remote CPU is not involved at all.**
3. **RDMA read (one-sided, pull)** — `rdma_read_wrs`. The initiator fetches from remote memory.

RDMA write is the workhorse of one-sided transfer and the primitive that most cleanly matches how
distributed workloads move data:

- **It removes the remote CPU from the receive path.** With send/receive the receiving side must post
  buffers, be scheduled, and drain a completion queue. With a write it does none of that — the data
  simply appears. For a workload with many ranks per node this is the difference between receive-side CPU
  scaling with message rate and not scaling at all.
- **It removes a synchronization point.** Two-sided messaging couples sender and receiver progress; a
  slow receiver back-pressures the sender. One-sided writes decouple them, which is why they matter most
  in workloads with load imbalance — the common case in real HPC and distributed training.
- **It is what large transfers want.** For bulk data the per-message software cost of two-sided messaging
  dominates; a write moves the bytes with a single work request and no remote participation.
- **It maps onto the natural shape of most parallel codes.** Halo/ghost-cell exchange, gradient
  distribution, pipeline-parallel activations, and put-based PGAS models (SHMEM, UPC, `MPI_Put`) are all
  push-shaped. If the workload is one of these and writes are zero, the push is being emulated in
  software with two-sided messages.

Legitimate reasons for zero, and they are common:

- **The middleware does not issue RDMA write.** The most frequent cause by a wide margin. Libfabric
  providers, MPI implementations, NCCL, and framework collectives choose primitives internally; several
  paths use send/receive plus read, or eager messaging only. **The application often has no say.**
- **The workload is pull-shaped.** If nodes fetch data on demand rather than pushing it — remote
  key-value stores, distributed hash tables, irregular graph traversal — RDMA read is the right primitive
  and zero writes is correct. Check whether `Unused RDMA Read` fired: if it did not, this is exactly the
  shape you are looking at.
- **Messages are small.** Below the provider's RDMA threshold, eager send/receive wins and no one-sided
  operation is issued at all.
- **Collectives only.** A workload communicating solely through `MPI_Allreduce`, `MPI_Alltoall`, or NCCL
  collectives delegates every transfer decision to the library.
- **This node is only a write *target*.** RDMA write is one-sided: the **initiator's** counter advances.
  A node whose memory is written by others shows zero `rdma_write_wrs` while `rdma_write_recv_bytes`
  moves. That asymmetry is the key disambiguation and it is visible in the same report.
- **Not an RDMA workload.** EFA can be present on an instance whose traffic is ordinary TCP/IP. Then both
  this and `Unused RDMA Read` fire and neither is actionable.
- **The recording missed the phase** that writes — a checkpoint, a scatter, an output stage.

**Why `Concerning` (−1) is the right weight.** The question is free to ask, frequently answered
"expected", and there is no measured harm. Treat it as a prompt, never a defect.

## Reading the description

`time_series_stat_threshold` emits:

```
The {stat} in {run_name} is {value}.
```

For this rule:

```
The max in aperf_record is 0.
```

Note what is **absent**: the template includes **neither the comparator nor the threshold**. You must
know from the rule that the condition was `max == 0`; the description alone reads as a bare fact.

Three properties of the value:

1. **`Stat::Max` over the whole run.** The strongest form of "never" — not an average that rounded down,
   but no interval anywhere with a non-zero delta.
2. **It is the max of per-interval deltas**, with the first sample forced to 0 — so `max == 0` says "the
   counter never advanced *during the recording*", not "zero since boot".
3. Stats come from `stats_series_idx`. With one EFA device the aggregate is removed and the device's own
   series is used; with **two or more** devices the stat is the auto-generated **`average` series**, where
   a max of 0 means the cross-device mean never moved — which for a non-negative counter still implies no
   device advanced.

Score math — `compute_finding_score(0.0, 0.0, −1)` takes the `threshold == 0.0` branch at
`src/analytics/mod.rs:170`, which returns `rule_score` unchanged when `value < 1.0`. That branch returns
**before** the `value == 0.0 ⇒ 2 × rule_score` amplification at `:180` can be reached, so there is no
doubling:

| value | score |
|---|---|
| 0.0 (the only possible value) | **−1.00** |

**Always −1.00.** Nothing to rank and nothing recoverable from the number. The finding will sit at the very
bottom of a score-ordered report — below every real problem, which is the correct place for it.

## Interpretation

The question is only "is this expected", and three checks answer it:

| Evidence | Reading |
|---|---|
| `rdma_write_recv_bytes` **non-zero** | **This node is an RDMA write *target*.** Others are writing into its memory; the counter that moves for that is the receive-bytes counter, not `rdma_write_wrs`. Entirely expected — the fastest "not a problem" answer |
| `rdma_read_wrs` non-zero, writes zero | **A pull-shaped workload.** Fetching rather than pushing. Normal for remote-store / irregular-access designs |
| `send_wrs` / `recv_wrs` dominant, both RDMA counters zero | **Two-sided messaging only.** The most actionable case: remote CPUs are in the receive path for every message when the hardware could bypass them |
| All EFA counters ~zero | **EFA present but unused.** Neither this nor `Unused RDMA Read` is actionable; ask instead why an EFA instance runs an EFA-free workload |
| `avg_bytes_per_send_wr` **large** | **Large two-sided transfers** — the single best candidate for conversion to one-sided writes |
| `avg_bytes_per_send_wr` small | Small messages; libraries prefer eager send/receive below their RDMA threshold. Expected |
| `send_wrs` very high with high `system` CPU | Receive-side software cost is real and measurable — the cost RDMA write removes |
| Fewer than ~5 samples in the run | **The finding may be an artifact** of the forced-zero first sample. Not evidence of anything |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Unused RDMA Read` **also fired** | **Neither one-sided primitive was used.** Either not an RDMA workload, or middleware that only does send/receive. Read the two findings as one observation |
| `Unused RDMA Read` did **not** fire | Reads used, writes not — the pull-shaped case. Usually deliberate |
| `EFA Errors` also fired | **Investigate that first.** If `create_qp_err`, `reg_mr_err`, `alloc_mr_err`, or `rdma_write_wr_err` are non-zero, zero writes may be a *consequence* of a broken RDMA path rather than a design choice — a far more serious finding. The most important interaction |
| `Inconsistent Inbound/Outbound EFA Traffics` fired | The compared runs move different amounts of data; check they exercised the same code path before drawing conclusions about primitives |
| `retrans_pkts`, `retrans_timeout_events` non-zero | SRD retransmission on the EFA fabric — separate problem, but it confirms EFA *is* carrying traffic |
| `system` CPU high (`cpu_utilization`) | Two-sided receive processing burns CPU. The strongest supporting evidence that one-sided writes would help |
| `Underutilized CPU` | Idle CPU in a tightly-coupled workload usually means waiting on communication and synchronization — what one-sided writes decouple |
| No `efa_stat` section at all | The rule cannot fire. Absence of the finding is not evidence of RDMA write usage |

**Known false positives — most firings are in this category:**

- **The middleware chooses the primitives.** Libfabric/MPI/NCCL decide; the application often cannot emit
  an RDMA write even if it wanted to. The most common cause.
- **This node is a write *target*, not an initiator.** Check `rdma_write_recv_bytes`.
- **The workload is legitimately pull-shaped** (reads used instead). Not a defect.
- **Small messages** below the library's RDMA threshold, and **collective-only** communication.
- **The recording missed the phase** that writes.
- **EFA present but not used at all** — noise alongside `Unused RDMA Read`.
- **RDMA setup errors** — zero writes because the path is broken. A different and worse finding; check
  `EFA Errors`.
- **Short recording.** The first sample of every metric is forced to 0, so a 1–2 sample run can yield
  `max == 0` on a workload that does write.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `rdma_write_recv_bytes` | `efa_stat` | **Do this first.** Non-zero ⇒ this node is a write *target*, and zero initiator writes is exactly right. **No rule fires on it** — read manually |
| `rdma_read_wrs`, `rdma_read_bytes`, `rdma_read_resp_bytes` | `efa_stat` | Whether one-sided transfer is used in the pull direction. See `Unused RDMA Read` |
| `send_wrs`, `recv_wrs`, `send_bytes`, `recv_bytes` | `efa_stat` | **The comparison that matters**: heavy two-sided traffic with zero one-sided writes is the actionable shape |
| `avg_bytes_per_send_wr`, `avg_bytes_per_recv_wr` | `efa_stat` | Message size. Derived as `bytes/wrs` with plain `add_data_point`, **not** deltified; see the caveat section |
| `rdma_write_wr_err`, `rdma_read_wr_err` | `efa_stat` | Whether RDMA operations are *failing* rather than absent. Covered by `EFA Errors` |
| `create_qp_err`, `reg_mr_err`, `alloc_mr_err`, `alloc_pd_err`, `create_ah_err` | `efa_stat` | **Whether the RDMA path could be set up at all.** Non-zero reframes this finding entirely |
| `tx_bytes`, `rx_bytes`, `tx_pkts`, `rx_pkts` | `efa_stat` | Whether EFA is carrying traffic at all |
| `retrans_pkts`, `retrans_bytes`, `retrans_timeout_events`, `impaired_remote_conn_events`, `unresponsive_remote_events` | `efa_stat` | SRD fabric health (Nitro v4+). **No rules fire on these** — read manually |
| `lifespan` | `efa_stat` | Seconds since device init/reset — a small value means a reset near the recording, and lost coverage |
| Sample count / recording length | run metadata / `aperf_stats` | Whether `max == 0` rests on enough samples. **No analytical rules — read manually** |
| Instance type, EFA device count | `systeminfo` / `efa_stat` series list | Whether this is an EFA-capable type, and whether the stat is a per-device series or the cross-device `average` |
| `system`, `idle`, `aggregate` | `cpu_utilization` | Receive-side CPU cost and communication wait — the costs one-sided writes remove. See `Underutilized CPU` |
| On-CPU profile | `perf_profile` | Whether time goes into libfabric/MPI progress and receive paths. Requires `--profile`. **No analytical rules** |
| Per-process activity | `processes` | Which ranks are communicating. **No analytical rules — read manually** |

## Guidance

Ordered. **Step 1 usually closes the finding**; step 2 is the one case where it is serious.

1. **Check `rdma_write_recv_bytes` first.** RDMA write is one-sided: only the *initiator's*
   `rdma_write_wrs` advances. Non-zero receive-bytes means this node is a write **target**, zero
   initiator writes is correct, and the finding is closed.

2. **Check whether RDMA setup failed.** Read `create_qp_err`, `reg_mr_err`, `alloc_mr_err`,
   `alloc_pd_err`, `create_ah_err`, and `rdma_write_wr_err` (see `EFA Errors`). **Zero writes because the
   RDMA path could not be established is a much more serious finding than zero writes by design** — and
   this rule cannot distinguish the two.

3. **Ignore the score** (a constant −1.00) and **check the sample count**. A short run plus the
   forced-zero first sample can produce `max == 0` on a workload that does write.

4. **Establish the workload's communication shape.** Compare `send_wrs`/`recv_wrs` against
   `rdma_read_wrs`, and read `avg_bytes_per_send_wr`:
   - **Reads used, writes not** ⇒ pull-shaped design. Usually correct; note it and move on.
   - **Only send/receive with large messages** ⇒ the actionable case. Every message is costing remote CPU
     and a synchronization point that a write would eliminate.
   - **Only send/receive with small messages** ⇒ expected; eager messaging is the right choice below the
     library's RDMA threshold.
   - **All EFA counters near zero** ⇒ EFA unused entirely; do not chase RDMA write.

5. **Quantify the cost of not using writes before recommending them.** The benefit is receive-side CPU
   and decoupled progress, so look for the symptom: high `system` CPU alongside a high `recv_wrs` rate, or
   `Underutilized CPU` with ranks waiting on communication. **If neither symptom is present, the finding
   is informational** — there is no measured harm to fix.

6. **Check whether the choice is even yours.** Libfabric, MPI, NCCL, and framework collectives pick
   primitives internally. Read the profile to identify the middleware in the path. If the library does not
   emit RDMA write, remediation is a provider/library configuration question — or nothing at all.

7. **If two-sided transfer is dominant and the cost is real, evaluate converting the bulk path to writes:**
   convert the largest, most regular transfers first (halo exchange, gradient distribution, pipeline
   activations — all already push-shaped); register the target memory **once** and reuse the registration,
   since per-transfer registration is why naive conversions disappoint (watch `reg_mr_err`,
   `alloc_mr_err`); prefer put-based APIs (`MPI_Put`, SHMEM) over hand-rolled verbs where the provider
   supports them; and keep the completion semantics honest — **writes decouple sender and receiver, so the
   application must supply its own notification of data readiness.** That is the real work of converting.

8. **If zero writes is expected, record that.** The rule asks you to "verify that this is the expected
   behavior"; a documented "yes — pull-shaped workload" or "yes — target node" is a complete resolution.

## Priority and execution risk

**Priority: P4 — Informational** by default. This is a question about capability usage, not a measured
problem. The mildest score aperf emits, and for many workloads the answer is "expected".

It escalates in two situations. **P1** when `EFA Errors` also fired on a setup counter, because then zero
writes is a *symptom of a broken RDMA path* and the real finding is the error. **P2** — a step above the
read twin — when heavy two-sided traffic with large messages coincides with high `system` CPU or
`Underutilized CPU`: writes are the primitive middleware adopts first, so their absence alongside a
measurable receive-side cost is the strongest actionable form this finding takes.

**Execution risk: R0 — Read-only** for the whole diagnosis: `rdma_write_recv_bytes`, the setup-error
counters, the send/receive counters and the sample count are all reads of the existing report. Acting is
**R1** for re-recording over the write-heavy phase, **R2** for a libfabric provider or MPI protocol-threshold
change, and **R3 — Application change** for converting a bulk two-sided path to one-sided writes, because
the application must then carry its own data-readiness notification.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `max(rdma_write_wrs) == 0.0` over the whole recording.

```
STEP 0 — Is "never" resting on enough samples?
  The first accumulative sample is forced to 0, so a 1-2 sample run yields max == 0
  regardless of what the workload did.
  IF the run has fewer than ~5 usable samples
  THEN → the finding is a SAMPLING ARTIFACT: no conclusion available (P4, R1)
       → re-record with a longer window or a shorter --interval
       → verify: on the longer run, either rdma_write_wrs moves (finding was
         spurious) or max == 0 persists on many samples (finding is real)
  IF the aperf log carries "skipped N data points due to unexpected decrease"
     for rdma_write_wrs
  THEN → a driver reset dropped intervals; coverage is broken (P3, R1)
       → cross-check `lifespan` against the workload's age
       → verify: re-record without a reset in the window; the warning should vanish
  ELSE continue to STEP 1.

STEP 1 — Is this node a write TARGET rather than an initiator?
  RDMA write is one-sided: only the INITIATOR's rdma_write_wrs advances.
  IF rdma_write_recv_bytes is non-zero
  THEN → other nodes are writing INTO this node's memory. Zero initiator writes is
         EXACTLY correct. NO finding to act on — close it (P4, R0)
  IF rdma_read_resp_bytes is non-zero but rdma_write_recv_bytes is zero
  THEN → this node is a READ target only. Still target-side, still expected, but
         the peers are pulling rather than pushing (P4, R0)
  ELSE continue to STEP 2.

STEP 2 — Could the RDMA path be built at all?
  IF any of create_qp_err, create_cq_err, create_ah_err, reg_mr_err, alloc_mr_err,
     alloc_pd_err, alloc_ucontext_err, mmap_err is non-zero
  THEN → zero writes is a CONSEQUENCE of a failed RDMA setup, not a design choice.
         This finding is the symptom; `EFA Errors` is the cause (P1, R0)
       → efa-errors.md, see that playbook
  IF rdma_write_wr_err is non-zero
  THEN → writes were ATTEMPTED and FAILED. Far more serious than "unused" (P1, R0)
       → efa-errors.md, see that playbook
  IF tx_bytes and rx_bytes are both near zero
  THEN → EFA is attached but carrying no traffic at all (P2, R1)
       → check whether traffic fell back to TCP: read ena_stat tx_bytes/rx_bytes
       → verify: after fixing provider selection, EFA bytes rise and ENA bytes fall
  ELSE continue to STEP 3.

STEP 3 — What primitives DID the workload use?
  IF rdma_read_wrs is non-zero
  THEN → PULL-SHAPED design. One-sided transfer is in use, just in the fetch
         direction. Usually deliberate and correct (P4, R0)
  IF send_wrs / recv_wrs dominate and BOTH rdma counters are zero
  THEN → go to STEP 4 to size the cost before recommending anything
  IF `Unused RDMA Read` also fired and all EFA counters are near zero
  THEN → not an RDMA workload. Both findings are noise together (P4, R0)
       → the real question is why an EFA instance runs an EFA-free workload
  ELSE continue to STEP 4.

STEP 4 — Size the cost of two-sided-only messaging.
  The benefit of a write is removing the remote CPU from the receive path, so the
  cost of NOT using one must be visible as receive-side CPU or communication wait.
  IF avg_bytes_per_send_wr is LARGE (bulk transfers)
  AND `system` CPU is high with a high recv_wrs rate
  THEN → the STRONGEST actionable form of this finding: bulk two-sided transfers
         paying remote CPU per message (P2, R3)
       → convert the largest, most regular transfers first: halo exchange,
         gradient distribution, pipeline activations — already push-shaped
       → register target memory ONCE; per-transfer registration is why naive
         conversions disappoint (watch reg_mr_err, alloc_mr_err)
       → the application must supply its own data-readiness notification: writes
         decouple sender and receiver. That is the real work
       → verify: receive-side `system` CPU falls and end-to-end time improves;
         rdma_write_wrs becomes non-zero on the next recording
  IF avg_bytes_per_send_wr is large but CPU shows NO receive-side cost
  AND `Underutilized CPU` did not fire
  THEN → no measured harm to fix. INFORMATIONAL (P4, R0)
  IF avg_bytes_per_send_wr is SMALL
  THEN → eager messaging below the provider's RDMA threshold. EXPECTED (P4, R0)
  IF `Underutilized CPU` fired with ranks waiting on communication
  THEN → load imbalance coupled through two-sided messaging. Writes decouple
         sender and receiver progress, which is the specific fix here (P2, R3)
       → verify: idle time falls and the imbalance shortens after decoupling
  ELSE continue to STEP 5.

STEP 5 — Is the choice even yours?
  IF the profile shows libfabric / MPI / NCCL / a framework collective in the path
  THEN → the LIBRARY picks the primitive; the application often cannot emit a write
         (P4, R2)
       → remediation is a provider or protocol-threshold setting, or nothing
       → verify: change the provider/threshold, re-record, and check whether
         rdma_write_wrs becomes non-zero. If it does not, the library will not
         emit writes on this path and the finding is permanent and benign
  ELSE → document "yes, expected" and close. The rule asked a question and it has
         an answer (P4, R0)

STEP 6 — What survives?
  VALID  : every other finding in the report. This rule measures capability usage,
           not health, and contaminates nothing
  VOID   : any claim that RDMA write is unavailable, broken, or unsupported — this
           finding cannot distinguish "not used" from "could not be used"
  CAUTION: avg_bytes_per_rdma_write_wr is a flat zero by construction whenever this
           fires (0.0 substituted when the request count is zero). It is not
           evidence. With 2+ EFA devices the stat is a cross-device average

INSUFFICIENT DATA
  IF the report has no efa_stat section
  THEN → prepare_data_collector returned IgnoredDataPreparationError
         ("No EFA metrics available") and the rule COULD NOT FIRE (P4, R0)
       → absence of this finding is NOT evidence that RDMA write was used
```

## Runtime-specific consequences

EFA workloads are overwhelmingly C/C++/Fortran MPI and Python-driven ML. Of the four target runtimes,
**only Python is commonly relevant**, and its role is as an orchestrator, never as the data path.

| Runtime | Typical role on EFA | What to check |
|---|---|---|
| **Python** | PyTorch/JAX driving NCCL or MPI; every working request is issued by native libraries below the interpreter | `NCCL_DEBUG=INFO` and `FI_LOG_LEVEL=info` to see which provider and protocol were selected. **Zero writes in a training job is the more surprising of the two twins** — collective libraries are usually write-shaped, so it points at a fallback path or an unselected provider |
| **Java** | Rare on EFA; analytics frameworks use TCP | If Java is present with EFA attached, the fabric is probably unused by it — expect both `Unused RDMA` findings and treat them as one observation |
| **.NET** | Effectively absent from EFA workloads | Not applicable |
| **Perl** | Not applicable | — |

**The Python-specific trap:** `processes` shows a truncated `comm` (`python3`) with no rank or role, and
only the top entries by CPU. A distributed training job appears as several indistinguishable `python3`
processes. **aperf cannot tell you which rank is which** — and since one-sided counters are per-initiator,
knowing which rank this recording came from is exactly what STEP 1 needs. Correlate with the job
scheduler's logs.

## Architecture-specific considerations

EFA collection is architecture-neutral: aperf reads `/sys/class/infiniband` regardless of CPU
(`src/data/efa_stat.rs:26`–`:46`), and when the directory is absent it emits only a `debug!` line — **not**
a warning, deliberately, because "which is a common case, users should not see any warning messages"
(`:33`–`:35`). So on a non-EFA instance you get silence, not a diagnostic.

Confirm architecture from `pmu_config.json` ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before drawing
conclusions about primitive availability.

| Observed | Reading | Action |
|---|---|---|
| Zero writes, x86_64 EFA instance (`p5`, `hpc6a`, `c5n`, `c6in`) | The mature libfabric/NCCL path, where writes are normally the primitive in use. Zero writes here is **more suspicious than a missing read** | Follow the tree; suspect provider selection before design (P2, R2) |
| Zero writes, arm64 EFA instance (`hpc7g`, `c7gn`, `c8gn`) | Same hardware capability, but the **software stack is the variable**: libfabric, the AWS OFI NCCL plugin, and the MPI build must all be compiled for arm64 | Confirm with `fi_info -p efa` that the provider is present for this architecture (P2, R2) |
| Zero writes **immediately after an architecture migration** | The highest-value case. The fabric stack was rebuilt, and a generic or fallback build is the likeliest reason one-sided operations disappeared | Compare against the pre-migration report; check the provider actually loaded (P1, R2) |
| Zero writes with **`EFA Errors`** on any architecture | Architecture is irrelevant — the path failed. Read `efa-errors.md` | (P1, R0) |

**The one architecture-specific action that matters here** is verifying the collective and fabric libraries
were built for the target platform rather than installed from a mismatched binary — the same concern that
[ARCHITECTURE.md](../ARCHITECTURE.md) §5.3 raises for native extensions. None of it is visible to aperf:
`fi_info -p efa`, `ldd` on the MPI and NCCL plugin libraries, and the kernel driver version all have to be
read out of band.

## Verification

**Predict before you check.** The finding closes one of three ways, and each has a different prediction:

1. **Target-node case** — predict `rdma_write_recv_bytes` is non-zero and `rdma_write_wrs` is a flat
   two-point zero series. If the receive-bytes counter is *also* zero, this is not the target case and the
   prediction failed; go back to STEP 2.
2. **Broken-path case** — predict at least one setup-error counter is non-zero and `tx_bytes`/`rx_bytes`
   are depressed. Confirm in `ena_stat` that the traffic reappeared on TCP. If EFA bytes are healthy, the
   errors were probes and the path is fine.
3. **Middleware case** — predict that changing the provider or protocol threshold and re-recording either
   makes `rdma_write_wrs` non-zero or leaves it at zero permanently. **Both outcomes are informative**: the
   second converts the finding from open question to documented "the library will not emit writes here".

For a conversion (STEP 4), verify on **receive-side `system` CPU and end-to-end time**, not bandwidth: the
benefit of a write is removing the remote CPU from the receive path, so the receiver's CPU is the metric
that must move. Watch for the failure mode too — a conversion that adds per-transfer memory registration
trades one cost for another, so `reg_mr_err` and `alloc_mr_err` must stay at zero and the registration
count must not scale with message count. And expect the two-point all-zero chart to become a populated
series; that visual change is the cheapest confirmation that writes are now being issued.

**Do not close this finding on the absence of evidence.** A run with too few samples, a driver reset
mid-window, or a recording that missed the write-heavy phase all produce `max == 0` without meaning it.

## Do not

- **Do not treat this as a defect.** It is a question. `Concerning` (−1) is the mildest score aperf has,
  and for most workloads the answer is "expected".
- **Do not conclude RDMA write is broken or unavailable from this finding alone.** A failing RDMA path
  produces the same zero — check `EFA Errors` and the setup-error counters.
- **Do not forget the finding is initiator-side.** A node whose memory others write shows zero
  `rdma_write_wrs` and non-zero `rdma_write_recv_bytes`. Check that first.
- **Do not read the score as severity.** It is a constant −1.00; the `threshold == 0.0` branch returns
  before any amplification.
- **Do not expect the description to state the condition.** `time_series_stat_threshold` omits the
  comparator and threshold; the condition is `max == 0`.
- **Do not read `max == 0` as "the counter is zero since boot".** Values are per-interval deltas with the
  first sample forced to 0.
- **Do not read the two-point chart as missing data.** An all-zero series is compressed to its first and
  last timestamps by design — that shape is the confirmation.
- **Do not diagnose from `avg_bytes_per_rdma_write_wr`.** It is derived, substitutes `0.0` when the request
  count is zero, and uses a stale operand after a dropped decrease.
- **Do not recommend converting to RDMA write without the symptom.** Without receive-side CPU cost or
  communication wait to point at, the conversion buys nothing and adds real synchronization work.
- **Do not blame the application when the middleware chooses the primitives.**
- **Do not act on a very short recording**, or on one whose log shows skipped decreasing samples.
- **Do not conflate this with `Unused RDMA Read`.** They fire independently, and both firing together
  means something different from either alone.

## References

- Rule: `src/analytics/rules/efa_stat.rs:25` — `time_series_stat_threshold!` with `Stat::Max`,
  `Comparator::Equal`, `threshold: 0.0`, `Score::Concerning`.
- Rule template: `src/analytics/rule_templates/time_series_stat_threshold_rule.rs` — description is
  `format!("The {} in {} is {}.", stat, run_name, formatted_number_string(metric_stat))`, with **no**
  comparator or threshold.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `threshold == 0.0` branch at
  `:170` returns `rule_score` for `value < 1.0`, **before** the `value == 0.0` doubling at `:180`.
  `Score::Concerning = −1`, `:150`.
- Collection: `src/data/efa_stat.rs:26`–`:46` reads `/sys/class/infiniband/*/hw_counters/` and
  `.../ports/<port>/hw_counters/`, naming series `<hardware>` and `<hardware>/<port>`; a missing directory
  yields only `debug!("No EFA metrics found")` (`:35`), and an empty map yields
  `PDError::IgnoredDataPreparationError("No EFA metrics available")` (`:170`).
- Delta processing: `add_accumulative_data_point` at `src/data/efa_stat.rs:243`;
  `ignore_first_accumulative_value: true` (`time_series_data_processor.rs:73`, taken at `:218`);
  decreasing samples return `None` at `:214` and are **dropped** (early return at `:150`), counted and
  logged once at `:297`–`:302`.
- All-zero compression: `compress_all_zero_time_series_metric`, `time_series_data_processor.rs:410`–`:427`
  — first and last data point only. Stats series selection: `stats_series_idx`, `:312`–`:319`, which
  **removes** the auto-generated aggregate when a metric has exactly 2 series.
- Derived metric: `avg_bytes_per_rdma_write_wr` is computed at `src/data/efa_stat.rs:279` as
  `rdma_write_bytes / rdma_write_wrs` via plain `add_data_point`, `0.0` when the count is zero, and the
  `continue` at `:249` skips its bookkeeping on a dropped decrease.
- Metric semantics: `rdma_write_wrs`, `rdma_write_bytes`, `rdma_write_recv_bytes`, `rdma_read_wrs`,
  `avg_bytes_per_rdma_write_wr` in `src/report_frontend/src/definitions/data-descriptions.ts`
  (`efa_stat` block, all `desired: "depends"`).
- Related playbooks: `unused-rdma-read.md`, `efa-errors.md`,
  `inconsistent-inbound-efa-traffics.md`, `inconsistent-outbound-efa-traffics.md`,
  `../cpu_utilization/underutilized-cpu.md`.
- [Monitor an EFA](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-working-monitor.html)
- [Elastic Fabric Adapter](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa.html)
- [Get started with EFA and MPI](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-start.html)
