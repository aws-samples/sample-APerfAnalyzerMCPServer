---
rule_name: Unused RDMA Read
data_type: efa_stat
data_key: rdma_read_wrs
template: time_series_stat_threshold
condition: "max(rdma_read_wrs) == 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "No RDMA read operations were completed. Verify that this is the expected behavior."
source: src/analytics/rules/efa_stat.rs:16
---

# Unused RDMA Read

## What fired

The **max** of `rdma_read_wrs` was **equal to 0.0** — not a single RDMA read working request completed
in any interval of the recording.

Base score `Concerning` (**−1**), the mildest negative score aperf defines. Single-run rule. With an
`Equal` comparator against a threshold of 0 the score is **always exactly −1.00**.

Unlike most aperf findings this is not a degradation signal. It is a **capability-usage observation**:
EFA is present and the report contains EFA data, but one of its two one-sided transfer primitives was
never used. The message says exactly the right thing — *"Verify that this is the expected behavior"* —
because for a great many legitimate workloads the answer is "yes, expected".

Unlike the `ena_stat` mode rules, **the logic here is sound.** `rdma_read_wrs` is a genuine cumulative
counter, so the delta processing it goes through is appropriate, and `max == 0` really does mean the
counter never advanced.

## The processing caveat

`efa_stat` shares `ena_stat`'s time-series machinery — `time_series_data_processor_with_average_aggregate!`
(`src/data/efa_stat.rs:216`) — and every metric goes through `add_accumulative_data_point`
(`:243`). For `ena_stat` that treatment is a **defect**, because several of its metrics are gauges. Here
it is **correct**: `rdma_read_wrs` really is a monotonic counter read from
`/sys/class/infiniband/*/hw_counters/`, so storing per-interval differences is exactly what a rate rule
wants. There is no defect to work around. There are four processing behaviours that change how you read
`max == 0`, and one of them is the reason a firing can be spurious.

| Behaviour | Source | Effect on this finding |
|---|---|---|
| First accumulative sample forced to 0 (`ignore_first_accumulative_value: true`) | `time_series_data_processor.rs:73`, taken at `:218` | **The one real hazard.** A run with 1–2 usable samples can show `max == 0` on a workload that does issue reads. Check the sample count before believing "never" |
| Decreasing samples **dropped, not clamped** — `return None` at `:214`, early return at `:150` | `time_series_data_processor.rs:189`–`:224` | A driver reset zeroes the counter; the resulting decrease creates a **gap**, not a negative value. Cannot manufacture a false `max == 0` on its own, but it can hide the interval in which reads happened |
| All-zero series compressed to first and last point only | `compress_all_zero_time_series_metric`, `:410`–`:427` | **A useful fingerprint.** When this rule fires the chart shows exactly **two points at zero**, not a flat line across every sample. That two-point shape *is* the confirmation, not missing data |
| Auto-generated `average` aggregate **removed** when a metric has exactly 2 series | `stats_series_idx`, `:312`–`:319` | On a single-EFA-device instance the stat comes from the device's own series. The cross-device-average caveat only applies with **≥3 series** — i.e. 2+ EFA devices |

The dropped-decrease path emits one aggregated warning at the end of processing:

```
efa_stat.rdma_read_wrs.<device>: skipped N data points due to unexpected decrease of accumulative data.
```

If that line is in the aperf log for this metric, a reset happened and the run's coverage is broken.

**One derived-metric hazard worth knowing.** `avg_bytes_per_rdma_read_wr` is not collected; it is computed
in `src/data/efa_stat.rs:279` as `rdma_read_bytes / rdma_read_wrs` per device per interval, added with
plain **`add_data_point`** (not accumulative), and set to **`0.0` when the request count is zero**. So when
this finding fires, `avg_bytes_per_rdma_read_wr` is a flat zero too — that is arithmetic, not evidence.
Worse, when `add_accumulative_data_point` returns `None` for a dropped decrease the loop `continue`s at
`:249`, so that interval's bookkeeping is skipped and a **stale operand** is used for the average. Never
diagnose from `avg_bytes_per_*_wr` alone.

## Reasoning

`rdma_read_wrs` is "The number of completed RDMA read working requests." (`data-descriptions.ts`,
`desired: "depends"` — note aperf itself declines to say whether higher or lower is better, which is
precisely why this rule only asks a question.)

**What RDMA read is, and why its absence is worth a question.** EFA supports three families of transfer
primitive:

1. **Send/receive (two-sided)** — `send_wrs` / `recv_wrs`. Both sides post work: the sender sends, the
   receiver must have posted a receive buffer. This is the classic message-passing model and what MPI
   point-to-point operations use by default.
2. **RDMA write (one-sided, push)** — `rdma_write_wrs`. The initiator writes directly into the remote
   node's registered memory. The remote CPU is not involved.
3. **RDMA read (one-sided, pull)** — `rdma_read_wrs`. The initiator *fetches* from the remote node's
   registered memory. Again the remote CPU is not involved.

The one-sided operations are the reason EFA exists for tightly-coupled workloads: they remove the
remote CPU from the data path entirely, eliminating the synchronization and the receive-side software
cost that two-sided messaging requires. A workload doing large transfers through send/receive is paying
CPU on both ends for something the hardware could do unilaterally.

**Why RDMA *read* specifically is the more commonly missing one, and the more interesting question:**

- **Write is easier to adopt.** Push semantics map naturally onto "I have produced data, here it is" and
  most libraries reach for write first. Read requires the initiator to know what it wants and where it
  lives, which needs a bit more coordination.
- **Read is the primitive that eliminates a round trip.** Fetching remote data with send/receive costs a
  request message, remote CPU wake-up, and a response message. An RDMA read is one operation with no
  remote CPU involvement. So in a workload with a *pull* access pattern — irregular graph traversal, a
  distributed hash table, a remote key-value or parameter store, on-demand halo exchange, work-stealing
  from a remote queue — RDMA read is exactly the right tool and its complete absence suggests the pull
  pattern is being emulated in software.
- **Read latency is the metric it improves.** Because it removes remote CPU scheduling from the path, an
  RDMA read has far more predictable latency than a request/response pair — the tail in particular.

Legitimate reasons for zero, and they are common:

- **The workload is push-only by design.** Producers know where their data goes. Stencil/halo exchanges,
  all-to-all collectives, and pipeline-parallel model training are naturally write-shaped.
- **The middleware does not issue RDMA read.** This is the single most common cause. Libfabric providers,
  MPI implementations, NCCL, and framework collectives choose their own primitives; many use send/recv
  and RDMA write and never emit a read. **The application has no direct say.**
- **Message sizes are small.** Below a provider-specific threshold, eager send/receive beats setting up
  a one-sided operation, so the library will not use RDMA at all.
- **Collectives only.** A workload whose communication is entirely `MPI_Allreduce`, `MPI_Alltoall`,
  `NCCL AllReduce` etc. delegates all transfer decisions to the library.
- **Not an RDMA workload at all.** EFA can be present on an instance whose traffic is ordinary TCP/IP.
  Then both this finding and `Unused RDMA Write` fire and neither is actionable.
- **The recording window missed the phase** that uses reads — a checkpoint restore, a data-load stage, a
  gather at the end.
- **Only the other side initiates.** RDMA read is one-sided: the *initiator's* counter advances. On a
  pure "target" node — one whose memory is read by others — `rdma_read_wrs` stays at zero while
  `rdma_read_resp_bytes` moves. That asymmetry is the key disambiguation and it is checkable in the same
  report.

**Why `Concerning` (−1) is the right weight.** It costs nothing to raise the question, the answer is
frequently "expected", and there is no measured harm. Treat it as a prompt, never as a defect.

## Reading the description

`time_series_stat_threshold` emits:

```
The {stat} in {run_name} is {value}.
```

For this rule:

```
The max in aperf_record is 0.
```

Note what is **absent**: the template includes **neither the comparator nor the threshold**. You must
know from the rule that the condition was `max == 0`. The description on its own reads like a bare fact.

Three properties of the value:

1. **`Stat::Max` over the whole run.** The strongest possible form of "never": not an average that
   rounded to zero, but no interval anywhere with a non-zero delta.
2. **It is the max of per-interval deltas**, with the first sample forced to 0 — so `max == 0` says "the
   counter never advanced *during the recording*", not "the counter is zero since boot".
3. Stats come from `stats_series_idx`. With one EFA device the aggregate is removed and the device's own
   series is used; with **two or more** devices the stat is the auto-generated **`average` series**, where
   a max of 0 means the cross-device mean never moved — which for a non-negative counter still implies no
   device advanced.

Score math — `compute_finding_score(0.0, 0.0, −1)` takes the `threshold == 0.0` branch at
`src/analytics/mod.rs:170`, which returns `rule_score` unchanged when `value < 1.0`. That branch returns
**before** the `value == 0.0 ⇒ 2 × rule_score` amplification at `:180` can be reached, so there is no
doubling:

| value | score |
|---|---|
| 0.0 (the only possible value) | **−1.00** |

**Always −1.00.** Nothing to rank and nothing recoverable from the number. This is one of the few aperf
rules whose score is a constant, and it means the finding will sit at the very bottom of a score-ordered
report — below every real problem, which is the correct place for it.

## Interpretation

The question is only ever "is this expected", and the answer comes from three checks:

| Evidence | Reading |
|---|---|
| `rdma_read_resp_bytes` **non-zero** | **This node is an RDMA read *target*.** Other nodes are reading its memory; the counter that moves for that is the response counter, not `rdma_read_wrs`. Entirely expected — the clearest "not a problem" answer available |
| `rdma_write_wrs` non-zero, reads zero | **A push-only workload.** Normal and often optimal. The question worth asking is whether any *pull* pattern is being emulated with send/receive round trips |
| `send_wrs` / `recv_wrs` dominant, both RDMA counters zero | **Two-sided messaging only.** The most actionable case: one-sided transfer is available and unused, so remote CPUs are in the data path unnecessarily |
| All EFA counters ~zero | **EFA is present but unused.** Neither this finding nor `Unused RDMA Write` is actionable; the interesting question is why an EFA-enabled instance is not using it |
| `avg_bytes_per_send_wr` small | Messages are small; libraries prefer eager send/receive below their RDMA threshold. Expected |
| `avg_bytes_per_send_wr` large | **Large two-sided transfers.** These are the ones one-sided operations help most |
| Fewer than ~5 samples in the run | **The finding may be an artifact** of the forced-zero first sample. Not evidence of anything |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Unused RDMA Write` **also fired** | **Neither one-sided primitive was used.** Either not an RDMA workload, or middleware that only does send/receive. Read the two findings as one observation, not two |
| `Unused RDMA Write` did **not** fire | Write is used, read is not — the classic push-only shape. See the table above |
| `EFA Errors` also fired | **Investigate that first.** If RDMA setup is failing (`create_qp_err`, `reg_mr_err`, `alloc_mr_err`), zero reads may be a *consequence* of a broken RDMA path rather than a design choice. The single most important interaction for this finding |
| `Inconsistent Inbound/Outbound EFA Traffics` fired | The runs are not comparable; check whether the compared runs even exercised the same code path |
| `retrans_pkts`, `retrans_timeout_events` non-zero | SRD-level retransmission on the EFA path — a separate problem, but it means EFA *is* carrying traffic |
| `Underutilized CPU` | Idle CPU in an HPC workload usually means waiting on communication. One-sided transfer is one way to cut that wait |
| `system` CPU high (`cpu_utilization`) | Two-sided messaging burns remote CPU in the receive path; a hint that one-sided operations would help |
| No `efa_stat` section at all | The rule cannot fire. Absence of the finding is not evidence of RDMA read usage |

**Known false positives — most firings are in this category:**

- **The workload is legitimately push-only or two-sided.** By far the most common case. Not a defect.
- **This node is a read *target*, not an initiator.** Check `rdma_read_resp_bytes`. One-sided operations
  only advance the initiator's counter.
- **The middleware chooses the primitives.** Libfabric/MPI/NCCL decide; the application often cannot
  emit an RDMA read even if it wanted to.
- **Small messages** below the library's RDMA threshold, and **collective-only** communication.
- **The recording missed the phase** that uses reads.
- **EFA present but not used at all** — then this is noise alongside `Unused RDMA Write`.
- **RDMA setup errors** — zero reads because the path is broken, which is a different and worse finding.
  Check `EFA Errors`.
- **Short recording.** The first sample of every metric is forced to 0, so a 1–2 sample run can produce
  `max == 0` even on a workload that does use reads.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `rdma_read_resp_bytes` | `efa_stat` | **Do this first.** Non-zero ⇒ this node is a read *target* and zero initiator reads is exactly right. The fastest way to close the finding. **No rule fires on it** — read manually |
| `rdma_write_wrs`, `rdma_write_bytes` | `efa_stat` | Whether one-sided transfer is used at all. See `Unused RDMA Write` |
| `rdma_write_recv_bytes` | `efa_stat` | Whether other nodes are writing into this node's memory — the other "target-side" counter. Read manually |
| `send_wrs`, `recv_wrs`, `send_bytes`, `recv_bytes` | `efa_stat` | **The comparison that matters**: heavy two-sided traffic with zero one-sided operations is the actionable shape |
| `avg_bytes_per_send_wr`, `avg_bytes_per_recv_wr` | `efa_stat` | Message size — large two-sided messages are the best candidates for conversion to one-sided. Derived, not collected; see the caveat section |
| `rdma_read_wr_err`, `rdma_write_wr_err` | `efa_stat` | Whether RDMA operations are *failing* rather than absent. Covered by `EFA Errors` |
| `create_qp_err`, `reg_mr_err`, `alloc_mr_err`, `create_ah_err` | `efa_stat` | **Whether the RDMA path could even be set up.** Non-zero reframes this finding entirely. See `EFA Errors` |
| `tx_bytes`, `rx_bytes`, `tx_pkts`, `rx_pkts` | `efa_stat` | Whether EFA is carrying traffic at all |
| `retrans_pkts`, `retrans_timeout_events`, `impaired_remote_conn_events`, `unresponsive_remote_events` | `efa_stat` | SRD health on the EFA fabric (Nitro v4+). **No rules fire on these** — read manually |
| `lifespan` | `efa_stat` | Seconds since device init/reset — a small value means a reset near the recording, and lost coverage |
| Sample count / recording length | run metadata / `aperf_stats` | Whether `max == 0` rests on enough samples. **No analytical rules — read manually** |
| EFA device count | `efa_stat` series list / `systeminfo` | Whether the stat is a per-device series or the cross-device `average` |
| `idle`, `system`, `aggregate` | `cpu_utilization` | Communication wait and receive-side CPU cost — the things one-sided transfer reduces. See `Underutilized CPU` |
| On-CPU profile | `perf_profile` | Whether time goes into libfabric/MPI progress loops. Requires `--profile`. **No analytical rules** |
| Per-process activity | `processes` | Which ranks/processes are communicating. **No analytical rules — read manually** |

## Guidance

Ordered. **Step 1 usually closes the finding**, and step 2 is the one case where it is serious.

1. **Check `rdma_read_resp_bytes` first.** RDMA read is one-sided: only the *initiator's* `rdma_read_wrs`
   advances. If this node's response-bytes counter is non-zero, it is a read **target**, zero initiator
   reads is exactly correct, and the finding is closed.

2. **Check whether RDMA setup failed.** Read `create_qp_err`, `reg_mr_err`, `alloc_mr_err`,
   `create_ah_err`, and `rdma_read_wr_err` (and see `EFA Errors`). **Zero reads because the RDMA path
   could not be established is a much more serious finding than zero reads by design** — and this rule
   cannot distinguish the two.

3. **Ignore the score** (a constant −1.00) and **check the sample count**. A short run plus the forced-zero
   first sample can produce `max == 0` on a workload that does read.

4. **Establish what the workload's communication actually looks like.** Compare `send_wrs`/`recv_wrs`
   against `rdma_write_wrs`, and read `avg_bytes_per_send_wr`:
   - **Write used, read not** ⇒ push-only design. Normally fine; go to step 5.
   - **Only send/receive, large messages** ⇒ the actionable case. One-sided transfer is available and
     unused, so remote CPUs are in the data path for no reason.
   - **Only send/receive, small messages** ⇒ expected; libraries use eager messaging below their RDMA
     threshold.
   - **All EFA counters near zero** ⇒ EFA is unused entirely. Ask why an EFA-enabled instance is running
     an EFA-free workload; do not chase RDMA read.

5. **Ask whether the workload has a *pull* access pattern at all.** RDMA read pays off when a node needs
   data it does not know it will need in advance — irregular graph traversal, distributed hash tables,
   remote parameter or key-value stores, on-demand halo fetch, remote work-stealing. **If the data flow
   is genuinely push-shaped, zero reads is the correct answer and the finding is informational.** This is
   the judgement the rule is asking you to make.

6. **Check whether the choice is even yours.** Libfabric, MPI, NCCL, and framework collectives select
   primitives internally. Read the profile to see which middleware is in the path. If the library does
   not emit RDMA read, the remediation is a library/provider configuration question, not an application
   one — and possibly nothing at all.

7. **If the pull pattern is real and reads are absent, evaluate converting it:** replace request/response
   round trips with a one-sided read where the initiator can locate the data; register the target memory
   **once** and reuse the registration (registration cost is why naive conversions disappoint — watch
   `reg_mr_err` and `alloc_mr_err`); confirm the provider supports and enables RDMA read on this instance
   generation; and measure the **latency distribution**, not just bandwidth, because the benefit
   concentrates in the tail.

8. **If zero reads is expected, record that.** The rule asks you to "verify that this is the expected
   behavior"; a documented "yes — push-only workload" or "yes — target node" is a complete resolution and
   stops the finding recurring as a question.

## Priority and execution risk

**Priority: P4 — Informational** by default. This is a question about capability usage, not a measured
problem. The mildest score aperf emits, and for most workloads the answer is "expected".

It escalates in exactly one situation: **P1** when `EFA Errors` also fired on a setup counter, because then
zero reads is a *symptom of a broken RDMA path* and the real finding is the error. It is **P3** when the
workload has a genuine pull-shaped access pattern being emulated with send/receive round trips and there is
a measurable latency tail to point at.

**Execution risk: R0 — Read-only** for the entire diagnosis: every disambiguating check
(`rdma_read_resp_bytes`, the setup-error counters, the send/receive counters, the sample count) is a read of
the existing report. Acting is **R1** at most for re-recording over the phase that uses reads, and **R2**
for changing a libfabric provider setting or an MPI protocol threshold. Converting an application's
request/response path to one-sided reads is **R3 — Application change**: it moves the completion and
data-readiness semantics into the application, which is the real work.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `max(rdma_read_wrs) == 0.0` over the whole recording.

```
STEP 0 — Is "never" resting on enough samples?
  The first accumulative sample is forced to 0, so a 1-2 sample run yields max == 0
  regardless of what the workload did.
  IF the run has fewer than ~5 usable samples
  THEN → the finding is a SAMPLING ARTIFACT: no conclusion available (P4, R1)
       → re-record with a longer window or a shorter --interval
       → verify: on the longer run, either rdma_read_wrs moves (finding was
         spurious) or max == 0 persists on many samples (finding is real)
  IF the aperf log carries "skipped N data points due to unexpected decrease"
     for rdma_read_wrs
  THEN → a driver reset dropped intervals; coverage is broken (P3, R1)
       → cross-check `lifespan` against the workload's age
       → verify: re-record without a reset in the window; the warning should vanish
  ELSE continue to STEP 1.

STEP 1 — Is this node a read TARGET rather than an initiator?
  RDMA read is one-sided: only the INITIATOR's rdma_read_wrs advances.
  IF rdma_read_resp_bytes is non-zero
  THEN → this node's memory is being read by others. Zero initiator reads is
         EXACTLY correct. NO finding to act on — close it (P4, R0)
  IF rdma_write_recv_bytes is non-zero but rdma_read_resp_bytes is zero
  THEN → this node is a WRITE target only. Still target-side, still expected,
         but the peers are pushing rather than pulling (P4, R0)
  ELSE continue to STEP 2.

STEP 2 — Could the RDMA path be built at all?
  IF any of create_qp_err, create_cq_err, create_ah_err, reg_mr_err, alloc_mr_err,
     alloc_pd_err, alloc_ucontext_err, mmap_err is non-zero
  THEN → zero reads is a CONSEQUENCE of a failed RDMA setup, not a design choice.
         This finding is the symptom; `EFA Errors` is the cause (P1, R0)
       → efa-errors.md, see that playbook
  IF rdma_read_wr_err is non-zero
  THEN → reads were ATTEMPTED and FAILED. Far more serious than "unused" (P1, R0)
       → efa-errors.md, see that playbook
  IF tx_bytes and rx_bytes are both near zero
  THEN → EFA is attached but carrying no traffic at all (P2, R1)
       → check whether traffic fell back to TCP: read ena_stat tx_bytes/rx_bytes
       → verify: after fixing provider selection, EFA bytes rise and ENA bytes fall
  ELSE continue to STEP 3.

STEP 3 — What primitives DID the workload use?
  IF rdma_write_wrs is non-zero
  THEN → PUSH-ONLY design. One-sided transfer is in use, just in one direction.
         Normally correct (P4, R0)
       → go to STEP 4 only if a pull pattern is being emulated
  IF send_wrs / recv_wrs dominate and BOTH rdma counters are zero
  AND avg_bytes_per_send_wr is large (bulk transfers)
  THEN → the ACTIONABLE case: large two-sided transfers with no one-sided
         operations, so remote CPUs sit in the data path (P3, R3)
       → quantify first: high `system` CPU with a high recv_wrs rate, or
         `Underutilized CPU` from communication wait
       → verify: after converting the bulk path, receive-side `system` CPU falls
         and end-to-end time improves; rdma_read_wrs or rdma_write_wrs becomes
         non-zero on the next recording
  IF send_wrs / recv_wrs dominate and avg_bytes_per_send_wr is small
  THEN → eager messaging below the provider's RDMA threshold. EXPECTED (P4, R0)
  IF `Unused RDMA Write` also fired and all EFA counters are near zero
  THEN → not an RDMA workload. Both findings are noise together (P4, R0)
       → the real question is why an EFA instance runs an EFA-free workload
  ELSE continue to STEP 4.

STEP 4 — Is there a PULL-shaped access pattern being emulated?
  RDMA read wins when a node fetches data it did not know it would need.
  IF the workload does irregular graph traversal, distributed hash table lookups,
     remote parameter/key-value reads, on-demand halo fetch, or work-stealing
  AND there is a measurable latency tail to point at
  THEN → a real conversion candidate (P3, R3)
       → register target memory ONCE; per-transfer registration is why naive
         conversions disappoint (watch reg_mr_err, alloc_mr_err)
       → verify: measure the LATENCY DISTRIBUTION before and after, not bandwidth.
         The p99 should fall; mean throughput may not move at all
  IF the data flow is genuinely push-shaped (stencil, all-to-all, pipeline)
  THEN → zero reads is the CORRECT answer. Informational only (P4, R0)
  ELSE continue to STEP 5.

STEP 5 — Is the choice even yours?
  IF the profile shows libfabric / MPI / NCCL / a framework collective in the path
  THEN → the LIBRARY picks the primitive; the application often cannot emit a read
         (P4, R2)
       → remediation is a provider or protocol-threshold setting, or nothing
       → verify: change the provider/threshold, re-record, and check whether
         rdma_read_wrs becomes non-zero. If it does not, the library will not
         emit reads on this path and the finding is permanent and benign
  ELSE → document "yes, expected" and close. The rule asked a question and it has
         an answer (P4, R0)

STEP 6 — What survives?
  VALID  : every other finding in the report. This rule measures capability usage,
           not health, and contaminates nothing
  VOID   : any claim that RDMA read is unavailable, broken, or unsupported — this
           finding cannot distinguish "not used" from "could not be used"
  CAUTION: avg_bytes_per_rdma_read_wr is a flat zero by construction whenever this
           fires (0.0 substituted when the request count is zero). It is not
           evidence. With 2+ EFA devices the stat is a cross-device average

INSUFFICIENT DATA
  IF the report has no efa_stat section
  THEN → prepare_data_collector returned IgnoredDataPreparationError
         ("No EFA metrics available") and the rule COULD NOT FIRE (P4, R0)
       → absence of this finding is NOT evidence that RDMA read was used
```

## Runtime-specific consequences

EFA workloads are overwhelmingly C/C++/Fortran MPI and Python-driven ML. Of the four target runtimes,
**only Python is commonly relevant**, and its role is as an orchestrator, never as the data path.

| Runtime | Typical role on EFA | What to check |
|---|---|---|
| **Python** | PyTorch/JAX driving NCCL or MPI; every working request is issued by native libraries below the interpreter | `NCCL_DEBUG=INFO` and `FI_LOG_LEVEL=info` to see which provider and which protocol were selected. Collective libraries are overwhelmingly write- and send-shaped, so zero reads is the **normal** result for a training job |
| **Java** | Rare on EFA; analytics frameworks use TCP | If Java is present with EFA attached, the fabric is probably unused by it — expect both `Unused RDMA` findings and treat them as one observation |
| **.NET** | Effectively absent from EFA workloads | Not applicable |
| **Perl** | Not applicable | — |

**The Python-specific trap:** `processes` shows a truncated `comm` (`python3`) with no rank or role, and
only the top entries by CPU. A distributed training job appears as several indistinguishable `python3`
processes. **aperf cannot tell you which rank is which** — and since one-sided counters are per-initiator,
knowing which rank this recording came from is exactly what STEP 1 needs. Correlate with the job
scheduler's logs.

## Architecture-specific considerations

EFA collection is architecture-neutral: aperf reads `/sys/class/infiniband` regardless of CPU
(`src/data/efa_stat.rs:26`–`:46`), and when the directory is absent it emits only a `debug!` line — **not**
a warning, deliberately, because "which is a common case, users should not see any warning messages"
(`:33`–`:35`). So on a non-EFA instance you get silence, not a diagnostic.

Confirm architecture from `pmu_config.json` ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before drawing
conclusions about primitive availability.

| Observed | Reading | Action |
|---|---|---|
| Zero reads, x86_64 EFA instance (`p5`, `hpc6a`, `c5n`, `c6in`) | The mature libfabric/NCCL path. Zero reads almost certainly reflects middleware choice | Follow the tree; expect "expected" (P4, R0) |
| Zero reads, arm64 EFA instance (`hpc7g`, `c7gn`, `c8gn`) | Same hardware capability, but the **software stack is the variable**: libfabric, the AWS OFI NCCL plugin, and the MPI build must all be compiled for arm64 | Confirm with `fi_info -p efa` that the provider is present for this architecture (P2, R2) |
| Zero reads **immediately after an architecture migration** | The highest-value case. The fabric stack was rebuilt, and a generic or fallback build is the likeliest reason one-sided operations disappeared | Compare against the pre-migration report; check the provider actually loaded (P1, R2) |
| Zero reads with **`EFA Errors`** on any architecture | Architecture is irrelevant — the path failed. Read `efa-errors.md` | (P1, R0) |

**The one architecture-specific action that matters here** is verifying the collective and fabric libraries
were built for the target platform rather than installed from a mismatched binary — the same concern that
[ARCHITECTURE.md](../ARCHITECTURE.md) §5.3 raises for native extensions. None of it is visible to aperf:
`fi_info -p efa`, `ldd` on the MPI and NCCL plugin libraries, and the kernel driver version all have to be
read out of band.

## Verification

**Predict before you check.** The finding closes one of three ways, and each has a different prediction:

1. **Target-node case** — predict `rdma_read_resp_bytes` is non-zero and `rdma_read_wrs` is a flat
   two-point zero series. If the response counter is *also* zero, this is not the target case and the
   prediction failed; go back to STEP 2.
2. **Broken-path case** — predict at least one setup-error counter is non-zero and `tx_bytes`/`rx_bytes`
   are depressed. Confirm in `ena_stat` that the traffic reappeared on TCP. If EFA bytes are healthy, the
   errors were probes and the path is fine.
3. **Middleware case** — predict that changing the provider or protocol threshold and re-recording either
   makes `rdma_read_wrs` non-zero or leaves it at zero permanently. **Both outcomes are informative**: the
   second one converts the finding from open question to documented "the library will not emit reads here".

For a conversion (STEP 3 or STEP 4), verify on **latency distribution and receive-side CPU**, not
bandwidth: one-sided reads remove remote CPU scheduling from the path, so the p99 moves before the mean
does. And expect the two-point all-zero chart to become a populated series — that visual change is the
cheapest confirmation that reads are now being issued.

**Do not close this finding on the absence of evidence.** A run with too few samples, a driver reset
mid-window, or a recording that missed the read-heavy phase all produce `max == 0` without meaning it.

## Do not

- **Do not treat this as a defect.** It is a question. `Concerning` (−1) is the mildest score aperf has,
  and for most workloads the answer is "expected".
- **Do not conclude RDMA read is unavailable or broken from this finding alone.** Check `EFA Errors` and
  the setup-error counters — a failing RDMA path produces the same zero.
- **Do not forget the finding is initiator-side.** A node whose memory others read shows zero
  `rdma_read_wrs` and non-zero `rdma_read_resp_bytes`. Check that before anything else.
- **Do not read the score as severity.** It is a constant −1.00; the `threshold == 0.0` branch returns
  before any amplification.
- **Do not expect the description to state the condition.** `time_series_stat_threshold` omits the
  comparator and threshold; the condition is `max == 0`.
- **Do not read `max == 0` as "the counter is zero since boot".** Values are per-interval deltas with the
  first sample forced to 0; it means the counter never advanced *during the recording*.
- **Do not read the two-point chart as missing data.** An all-zero series is compressed to its first and
  last timestamps by design — that shape is the confirmation.
- **Do not diagnose from `avg_bytes_per_rdma_read_wr`.** It is derived, substitutes `0.0` when the request
  count is zero, and uses a stale operand after a dropped decrease.
- **Do not recommend RDMA read for a push-shaped workload.** Write and send/receive are the right
  primitives for many designs, and forcing a read pattern adds coordination for no gain.
- **Do not blame the application when the middleware chooses the primitives.** Libfabric/MPI/NCCL decide.
- **Do not act on a very short recording**, or on one whose log shows skipped decreasing samples.
- **Do not conflate this with `Unused RDMA Write`.** They fire independently, and the combination of both
  means something different from either alone.

## References

- Rule: `src/analytics/rules/efa_stat.rs:16` — `time_series_stat_threshold!` with `Stat::Max`,
  `Comparator::Equal`, `threshold: 0.0`, `Score::Concerning`.
- Rule template: `src/analytics/rule_templates/time_series_stat_threshold_rule.rs` — description is
  `format!("The {} in {} is {}.", stat, run_name, formatted_number_string(metric_stat))`, with **no**
  comparator or threshold.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `threshold == 0.0` branch at
  `:170` returns `rule_score` for `value < 1.0`, **before** the `value == 0.0` doubling at `:180`.
  `Score::Concerning = −1`, `:150`.
- Collection: `src/data/efa_stat.rs:26`–`:46` reads `/sys/class/infiniband/*/hw_counters/` and
  `.../ports/<port>/hw_counters/`, naming series `<hardware>` and `<hardware>/<port>`; a missing directory
  yields only `debug!("No EFA metrics found")` (`:35`), and an empty map yields
  `PDError::IgnoredDataPreparationError("No EFA metrics available")` (`:170`).
- Delta processing: `add_accumulative_data_point` at `src/data/efa_stat.rs:243`;
  `ignore_first_accumulative_value: true` (`time_series_data_processor.rs:73`, taken at `:218`);
  decreasing samples return `None` at `:214` and are **dropped** (early return at `:150`), counted and
  logged once at `:297`–`:302`.
- All-zero compression: `compress_all_zero_time_series_metric`, `time_series_data_processor.rs:410`–`:427`
  — first and last data point only. Stats series selection: `stats_series_idx`, `:312`–`:319`, which
  **removes** the auto-generated aggregate when a metric has exactly 2 series.
- Derived metric: `avg_bytes_per_rdma_read_wr` is computed at `src/data/efa_stat.rs:279` as
  `rdma_read_bytes / rdma_read_wrs` via plain `add_data_point`, `0.0` when the count is zero, and the
  `continue` at `:249` skips its bookkeeping on a dropped decrease.
- Metric semantics: `rdma_read_wrs`, `rdma_read_bytes`, `rdma_read_resp_bytes`, `rdma_write_wrs`,
  `avg_bytes_per_rdma_read_wr` in `src/report_frontend/src/definitions/data-descriptions.ts`
  (`efa_stat` block, all `desired: "depends"`).
- Related playbooks: `unused-rdma-write.md`, `efa-errors.md`,
  `inconsistent-inbound-efa-traffics.md`, `inconsistent-outbound-efa-traffics.md`,
  `../cpu_utilization/underutilized-cpu.md`.
- [Monitor an EFA](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-working-monitor.html)
- [Elastic Fabric Adapter](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa.html)
- [Get started with EFA and MPI](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-start.html)
