---
rule_name: EFA Errors
data_type: efa_stat
data_key: ^*_err$
template: time_series_data_point_threshold_multi_metric
condition: "any(metric matching ^*_err$) >= 1.0"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "One or more errors occurred in EFA driver. Click the info button to learn more about the error"
source: src/analytics/rules/efa_stat.rs:54
---

# EFA Errors

## What fired

**At least one** data point of **at least one** `efa_stat` metric whose name matches `^*_err$` was
**greater than or equal to 1.0** — an error counter advanced during the recording.

Base score `Poor` (**−16**). Single-run rule. This is the **only multi-metric rule in `efa_stat`**: it
scans every matching metric independently and **emits a separate finding per metric that fired**, keyed on
that metric's name (`insert_finding(run_name, metric_name, …)`). So a report can contain several
`EFA Errors` findings at once, and **which metric each one is attached to is the entire diagnostic
content** — the shared message says nothing about *what* failed.

The message tells you to "click the info button to learn more about the error". That is not a formality: the
twelve error counters mean twelve very different things across three failure layers, each with a different
remediation. This playbook makes that per-metric mapping explicit.

## The pattern actually works — verified empirically

The pattern `^*_err$` looks malformed: `*` normally needs something to repeat. It was worth checking whether
it silently matches nothing, because `time_series_matched_metric_names`
(`src/data/common/processed_data_accessor.rs:133`–`:154`) compiles it with `Regex::new` and **returns an
empty `Vec` on compile error** — a broken pattern would make the rule silently dead, with no warning.

Probed through the Rust `regex` crate directly. Result: **it compiles and behaves usefully**, byte-for-byte
equivalent in behaviour to `_err$` and to `^.*_err$` — `^*` is a zero-width repeat of the anchor, so the
anchor is **vestigial** and the pattern is effectively unanchored suffix matching.

| tested against | matches? |
|---|---|
| `rdma_write_wr_err`, `rdma_read_wr_err`, `cmds_err`, `alloc_pd_err`, `alloc_mr_err`, `reg_mr_err`, `get_dma_mr_err`, `alloc_ucontext_err`, `create_qp_err`, `create_cq_err`, `create_ah_err`, `mmap_err` | **yes — all twelve** |
| `tx_bytes`, `rx_drops`, `retrans_pkts` | no |
| bare `_err` | yes |
| bare `err` | no |

So the rule covers **all twelve `efa_stat` error counters** and matches nothing spurious. No defect here —
but an important negative result to have confirmed rather than assumed, and a fragile construction worth
re-testing on any aperf version bump. Note the scope: this rule runs on `efa_stat` only. The ENA driver has
its own `*_err` counters (`tx_dma_mapping_err`, `tx_prepare_ctx_err`, `rx_dma_mapping_err`) and **no rule
fires on them** — read those manually in `ena_stat`.

## Reasoning

The twelve counters fall into **three layers**, and knowing which layer fired is the first and most important
step:

### Layer 1 — Data-path errors (operations that failed after setup succeeded)

Two counters, `rdma_write_wr_err` and `rdma_read_wr_err`: "the number of RDMA write/read operations that had
local or remote errors" (`data-descriptions.ts`).

These mean the RDMA path was established and then **individual transfers failed**. Causes split into *local*
(bad address or length, memory region deregistered while in flight, protection-domain or key mismatch,
queue-pair moved to an error state) and *remote* (the peer's memory region gone, remote access rights
insufficient, peer queue-pair torn down, peer node failed). In MPI/NCCL workloads a work-request error
usually surfaces as an abort or a hang rather than a silent retry, so these correlate with visible
application failures. **Most severe in practice** — data movement broke, not just slow setup.

### Layer 2 — Resource setup errors (the RDMA path could not be built)

| metric | resource | meaning |
|---|---|---|
| `alloc_ucontext_err` | user context | "created when an application opens the EFA device; failures prevent the application from accessing EFA resources" — the earliest possible failure |
| `alloc_pd_err` | protection domain | "groups related RDMA resources for access control; allocation failures prevent creation of new queue pairs and memory regions" |
| `alloc_mr_err`, `reg_mr_err`, `get_dma_mr_err` | memory regions | regions "must be registered with the EFA device before they can be used for RDMA operations"; registration "maps user-space memory for direct device access"; the DMA variant is "used for kernel-level RDMA operations". Failures "block data transfer setup" |
| `create_qp_err`, `create_cq_err` | queue pair, completion queue | QPs are "the fundamental communication endpoints for RDMA"; CQs "receive notifications when RDMA operations finish". Failures "prevent establishing new RDMA connections" and "setting up the completion notification path" |
| `create_ah_err` | address handle | "store the routing information needed to reach a remote EFA endpoint; failures prevent establishing communication with that peer" |
| `mmap_err` | device mapping | "the driver uses mmap to map device registers and queues into user-space; failures prevent the application from directly accessing EFA hardware resources" |

These are **allocation and creation failures**, and they share a small set of root causes:

- **Device resource exhaustion.** Queue pairs, completion queues, address handles, and memory regions are
  finite per EFA device. Too many ranks per node, too many peers, or a leak (resources created per operation
  instead of once) exhausts them. `create_ah_err` in particular scales with **peer count** — one address
  handle per remote endpoint — so it appears as jobs scale out.
- **Memory registration limits.** `reg_mr_err` / `alloc_mr_err` / `get_dma_mr_err` are the classic
  `ulimit -l` (max locked memory) failure. RDMA requires pinned memory; if the limit is not raised (commonly
  `unlimited` for EFA workloads) registration fails once the application's buffer set grows. Also hit by
  registering huge buffers, or registering per-transfer instead of once.
- **Permissions, device access, and version skew.** `alloc_ucontext_err` and `mmap_err` point at the
  process not being able to open or map the device — missing group membership, a container without the EFA
  device passed through, or SELinux/AppArmor. A userspace `libfabric`/`rdma-core` built against a different
  EFA kernel driver than the one loaded is the other classic, and it fails **several** of these counters at
  once.
- **Fallback, not failure.** Some middleware **probes** capabilities at startup: it attempts an allocation,
  accepts failure, and falls back. A small count in the first interval or two, with the workload running
  normally, is often exactly this. **This is the most common benign explanation** and it is why `Poor` (−16)
  rather than `Critical` is the right base weight.

### Layer 3 — Control-plane errors

The single counter here, `cmds_err`, is the "number of admin commands that completed with an error status.
Command errors indicate the EFA device rejected or failed to execute a control-plane operation such as
resource allocation or configuration." It is the **device's own view** of the failures in layer 2 — the
admin command that carried out the allocation returned an error — so it usually rises **alongside** a
layer-2 counter and corroborates it. Its companions (which have no rule) complete the picture:
`submitted_cmds` vs `completed_cmds` reveals "how many commands were lost or timed out",
`no_completion_cmds` indicates "device hang or communication failure on the control plane", and a gap in
`keep_alive_rcvd` "triggers a device reset". **`cmds_err` rising with `no_completion_cmds` is a
device-health signal, not an application one** — read those three manually.

**Why `Poor` (−16) and not `Critical`.** A single error in a capability probe is harmless; a stream of
work-request errors is a broken job. The rule cannot tell them apart from the counter alone, so it picks a
weight in between — serious enough to demand a look, not severe enough to top the report on its own. The
**per-data-point score scaling** below is what separates the two cases, and unusually for aperf it does so
meaningfully.

## Reading the description

`time_series_data_point_threshold_multi_metric` — the regex-matching variant of
`time_series_data_point_threshold`, sharing its format string — emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
  ⇒ At least one data point in aperf_record is 4 (greater than or equal to the threshold of 1).
```

Five things to know:

1. **The metric name is not in the description.** It is the finding's **key**, shown in the report next to
   the metric it belongs to. Without knowing which of the twelve fired, the finding is unactionable — so
   always read the key, not just the text. (Unlike `time_series_stat_threshold`, this template *does* name
   the comparator and the threshold, so the condition itself is unambiguous.)
2. **The value is the *worst single interval*, not the total.** The template scans every data point and
   keeps the one with the largest `abs(score)`; because the test is `>=`, ties resolve to the **later**
   point. So `is 4` means "in the worst interval, four errors occurred" — the run total is higher.
3. **It is a per-interval delta**, via `add_accumulative_data_point` (`src/data/efa_stat.rs:243`) with the
   first sample forced to 0. Correct for cumulative counters — and it means errors that occurred **before
   the recording started** are invisible and the first sample can never fire. **A setup failure at
   application launch is very likely to be missed entirely** if aperf started after it.
4. **Decreasing samples are skipped.** A driver reset zeroes the counters; the resulting decrease returns
   `None` at `time_series_data_processor.rs:214` and produces a **gap**, not a negative spike. One
   aggregated `warn!` names the metric and the count. Check `lifespan` for a reset near the recording.
5. **Fractional values are possible.** The rule iterates **all** series including the auto-generated
   `average` series on multi-device instances. On a 4-device instance, 6 errors spread across devices gives
   an `average` delta of 1.5 — a **fractional error count**, meaningless as a count, appearing as `is 1.5`
   (one error on one device gives `average` 0.25, which does not fire, while that device's own series gives
   1.0, which does). On a **single**-device instance the aggregate is removed entirely (`stats_series_idx`,
   `:312`–`:319`), so fractional values cannot occur.

Score math — `compute_finding_score(value, 1.0, −16)`. Threshold is 1.0, **not** 0, so the general branch
applies and there is **no zero trap**:

| worst-interval value | score |
|---|---|
| 1 | **−16.00** |
| 1.5 (an `average`-series artifact) | −24.00 |
| 2 / 3 / 5 | −32.00 / −48.00 / −80.00 |
| 10 / 50 | −160.00 / −800.00 |
| 100 / 1000 | −1600.00 / −16000.00 |

Recovery: `worst-interval count = |score| / 16`. **The score is unbounded and linear in that count, which
makes it genuinely informative here** — unlike the flat-score `ena_stat` mode rules, the constant −1.00 of
the two `Unused RDMA` rules, or the 5%-bounded `High SRD Resource Utilization`. −16 is one error in one
interval (very likely a probe); −1600 is a hundred in a single interval (a broken path). **Rank on it within
this rule** — but not against the run-comparison rules, which start at −256 × the ratio and reach five
figures for a measurement-validity problem, not a real failure.

## Interpretation

**Read the metric key first — it determines everything:**

| Metric that fired | Layer | Reading |
|---|---|---|
| `rdma_write_wr_err`, `rdma_read_wr_err` | data path | **The most serious case.** The RDMA path worked and then transfers failed. Expect visible application errors, aborts, or hangs. Local causes: bad address/length, MR deregistered in flight, key/PD mismatch, QP in error state. Remote causes: peer MR gone, insufficient access rights, peer QP torn down, peer node failed |
| `create_ah_err` | setup | **Scales with peer count** — one address handle per remote endpoint. Appears as jobs scale out. Points at AH exhaustion or an unreachable/misconfigured peer |
| `create_qp_err`, `create_cq_err` | setup | Connection endpoints, and the completion-notification path that accompanies them, could not be created. Too many ranks/peers per node, or QP/CQ exhaustion |
| `reg_mr_err`, `alloc_mr_err`, `get_dma_mr_err` | setup | **The `ulimit -l` classic.** RDMA needs pinned memory; an unraised locked-memory limit is the usual cause. Also: registering per-transfer instead of once, or registering oversized buffers |
| `alloc_pd_err` | setup | Protection domains exhausted — blocks *all* downstream QP and MR creation. Rare, and severe when real |
| `alloc_ucontext_err`, `mmap_err` | setup | **The earliest failures**: the application could not open the EFA device, or could not map its registers and queues into user space. Permissions, container device passthrough, driver/library mismatch, plus memory limits for `mmap_err` |
| `cmds_err` | control plane | The **device's** view of a failed admin command. Almost always corroborates a layer-2 counter. Alone, with `no_completion_cmds`, it is a device-health signal |

Then read the shape:

| Evidence | Reading |
|---|---|
| Errors only in the **first one or two intervals**, workload running fine | **Capability probing with fallback.** The most common benign case. Middleware attempts an allocation, accepts failure, uses another path. Confirm the workload's EFA traffic is normal |
| Errors **sustained across the run**, flat | Real and ongoing: an exhausted limit or a broken peer |
| Errors **increasing over time** | **Resource leak.** Resources being created per operation rather than once. The clearest actionable pattern |
| Errors in a **burst mid-run** | Correlate with the timestamp — a scale-out event, a peer failure, a memory-pressure spike, or a driver reset |
| **Multiple setup counters firing together** | Points at one shared root cause: version skew, locked-memory limits, or device exhaustion — not several independent bugs |
| `tx_bytes` / `rx_bytes` **near zero** in the same run | **EFA never worked.** The setup errors are fatal, not cosmetic. Check `ena_stat` — traffic almost certainly fell back to TCP |
| `tx_bytes` / `rx_bytes` **normal** | EFA is working despite the errors; they are probes, transient, or affecting only part of the workload |
| Value is **fractional** (e.g. 1.5), or `lifespan` is much smaller than the workload's age | The two artifact readings: a fractional count is an `average`-series artifact on a multi-device instance (read the per-device series), and a short `lifespan` means **a driver reset happened** — counters restarted, earlier errors are lost, decreases were skipped |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Unused RDMA Read` **and/or** `Unused RDMA Write` | **The critical interaction.** Zero RDMA operations *plus* setup errors means the RDMA path was never established — the "unused" findings are a *consequence*, not a design choice. Read them together |
| `Inconsistent Inbound/Outbound EFA Traffics` | Errors in one run explain the traffic difference. **This finding is the cause; that one is the symptom.** Fix here |
| `ena_stat` bytes elevated while EFA bytes collapsed, with or without an `ena_stat` allowance finding | **Traffic fell back to TCP.** The performance loss is real and large for a latency-sensitive workload, and the extra volume can breach ENA bandwidth/PPS/tracking allowances — a second-order failure caused by the EFA errors |
| `retrans_pkts`, `impaired_remote_conn_events`, `unresponsive_remote_events` non-zero | Fabric or peer trouble. Combined with `rdma_*_wr_err` or `create_ah_err`, it points at a **remote** cause rather than a local one |
| `no_completion_cmds` non-zero alongside `cmds_err`, or gaps in `keep_alive_rcvd` | **"Device hang or communication failure on the control plane"**, and "a gap in these messages triggers a device reset" — device health rather than application configuration, and an explanation for counter discontinuities. Read manually |
| Memory pressure findings (`meminfo`, `vmstat`) | Registration failures under memory pressure are plausible; pinned memory competes with everything else |
| `Underutilized CPU` | Ranks idle waiting on communication that is failing or falling back |

**Known false positives:**

- **Capability probing** — middleware deliberately attempts an allocation, tolerates failure, and falls
  back. One or two errors at startup with a healthy workload is the single most common firing. Related:
  **one error in a long run** (real, logged, and almost certainly not why the workload is slow) and
  **benign per-peer AH churn** in a workload with short-lived connections.
- **Fractional values from the `average` series** on multi-device instances — a count that cannot be a
  count — and **counter discontinuities after a driver reset**, where the decrease is skipped so what
  remains may mislead.
- **Errors that predate the recording** are invisible (first sample forced to 0) — so **absence of this
  finding does not mean no errors occurred.** This is the more dangerous direction of the artifact.
- **Multiple findings from one root cause** counted as multiple problems. Several setup counters firing
  together is usually *one* cause.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **Which** `*_err` metric the finding is keyed on | `efa_stat` | **Do this first.** The layer and the root-cause family. The description does not contain it |
| The error metric's **series shape** | `efa_stat` | Startup-only (probe) vs sustained (real) vs increasing (leak) vs burst (event). The single most informative check after the metric name |
| `tx_bytes`, `rx_bytes`, `tx_pkts`, `rx_pkts` | `efa_stat` | **Whether EFA works at all despite the errors.** Near-zero means the setup errors were fatal |
| `submitted_cmds` vs `completed_cmds`, `no_completion_cmds`, `keep_alive_rcvd` | `efa_stat` | Control-plane health: "how many commands were lost or timed out", "device hang or communication failure on the control plane", and a keep-alive gap that "triggers a device reset" and explains counter discontinuities. **No rules fire** — read manually |
| `lifespan`, and the **other** `*_err` counters | `efa_stat` | Seconds since device init/reset — a small value means a reset near the recording; and whether several error counters fired together (one shared root cause) or one in isolation |
| `rdma_write_wrs`, `rdma_read_wrs`, `send_wrs`, `recv_wrs` | `efa_stat` | Whether any operations succeeded. See `Unused RDMA Read`/`Write` |
| `retrans_pkts`, `retrans_timeout_events`, `impaired_remote_conn_events`, `unresponsive_remote_events`, `rx_drops` | `efa_stat` | Whether the cause is **remote** — a degraded path, a failed peer (Nitro v4+), or receive-side loss. **No rules fire** — read manually |
| EFA device count | `efa_stat` series list / `systeminfo` | Whether a fractional value is an `average`-series artifact, and whether errors are on one device or all |
| `tx_bytes`, `rx_bytes` and the four allowance counters; `tx_dma_mapping_err`, `tx_prepare_ctx_err`, `rx_dma_mapping_err` | `ena_stat` | **The fallback check** — EFA down and ENA up means traffic went to TCP, possibly then hitting allowances. The three driver-level *ENA* error counters sit alongside them and **no rules fire on those** — read them manually |
| `MemAvailable`, `MemTotal` (`meminfo`); `pgmajfault`, `pgfault` (`vmstat`) | `meminfo`, `vmstat` | Memory pressure behind registration failures — pinned memory competes with everything else. See `Reduced Memory Availability`, `Major Page Faults Detected` |
| Locked-memory limit (`ulimit -l`), kernel driver and `rdma-core`/`libfabric` versions | out of band | **The two most common root causes for the MR counters and for version skew.** aperf does not collect these |
| Instance type, EFA support, Nitro generation (`systeminfo`); rank/peer count and ranks per node (job launcher, `processes`) | `systeminfo`, `processes` | Whether the Nitro v4+ counters exist, what the device/resource limits are, and whether AH/QP/CQ exhaustion is plausible at this job width. **No analytical rules for `processes` — read manually** |
| `idle`, `system`, `aggregate` (`cpu_utilization`); application and MPI/NCCL logs (out of band) | `cpu_utilization`, out of band | Whether ranks are stalled on failing communication (see `Underutilized CPU`), and where a work-request error became an abort or a hang |

## Guidance

Ordered. **Step 1 is not optional** — without the metric name this finding has no content.

1. **Identify which `*_err` metric the finding is keyed on**, and place it in a layer: **data path**
   (`rdma_*_wr_err`), **setup** (the nine `alloc_*`/`create_*`/`reg_*`/`get_*`/`mmap` counters), or **control
   plane** (`cmds_err`). The layer determines everything that follows. If several findings fired, list them
   all before diagnosing — they usually share one root cause.

2. **Read the series shape.** Startup-only ⇒ almost certainly capability probing with fallback (benign).
   Sustained ⇒ real. **Increasing ⇒ a resource leak**, the most actionable pattern. A mid-run burst ⇒ correlate
   the timestamp with a scale-out, a peer failure, or memory pressure.

3. **Establish whether EFA is working at all.** Read `tx_bytes` and `rx_bytes`. Non-zero and healthy ⇒ the
   errors are probes or partial. Near-zero ⇒ **the setup errors are fatal**; check `ena_stat` for the TCP
   fallback and treat this as the report's primary finding.

4. **Use the score to triage within this rule, discount fractional values, and rule out a driver reset.**
   The score is linear in the worst-interval count — `|score| / 16` — and **unusually for aperf it is worth
   trusting**, though never against the run-comparison rules' five-figure scores. A non-integer count is an
   `average`-series artifact; read the per-device series. Then check `lifespan`, `keep_alive_rcvd` gaps, and
   `no_completion_cmds`: a reset zeroes counters and the decrease is skipped, so the surviving data can
   mislead in either direction.

5. **Then work the layer-specific cause**, which **STEP 3 of the decision tree carries in full** with a
   verification for each: `rdma_*_wr_err` ⇒ separate local from remote; the three MR counters ⇒ `ulimit -l`,
   then per-transfer registration, then memory pressure; `create_ah_err` ⇒ peer count; `create_qp_err` /
   `create_cq_err` ⇒ ranks per node; `alloc_pd_err` ⇒ PD exhaustion blocking everything downstream;
   `alloc_ucontext_err` / `mmap_err` ⇒ device access; `cmds_err` ⇒ corroboration, or device health when it
   is alone with `no_completion_cmds`. **When several setup counters fired together, check version skew
   first** — a userspace `libfabric`/`rdma-core` built against a different EFA kernel driver than the loaded
   one produces exactly that pattern, and one fix resolves all of the findings.

6. **Re-read the other `efa_stat` findings in this light.** If `Unused RDMA Read`/`Write` fired alongside setup
   errors, the RDMA path was never established and those findings are **consequences**, not design choices —
   report them together with this one as the cause. Same for `Inconsistent Inbound/Outbound EFA Traffics`: if
   errors occurred in only one run, this finding explains that one, so fix here, not there.

7. **Quantify the fallback cost.** If traffic moved to TCP, a latency-sensitive workload loses most of what
   EFA provides, and the extra TCP volume can push the instance into ENA bandwidth, PPS, or
   connection-tracking allowances. Check those counters.

8. **Do not assume the absence of this finding means no errors.** The first sample is forced to 0 and
   pre-recording errors are invisible, so **a setup failure at application launch is very likely to be
   missed** if aperf started afterwards. Confirm out of band when the workload shows symptoms.

## Priority and execution risk

**Priority: P2 — Investigate** by default. `Poor` (−16) is deliberately mid-scale because the rule cannot
distinguish a harmless capability probe from a broken data path, and the benign case is the more common one.

It moves in both directions, driven by the layer and the shape:

- **P0 — Blocking** when a data-path counter (`rdma_*_wr_err`) fired *and* `tx_bytes`/`rx_bytes` collapsed,
  or when setup errors coincide with either `Unused RDMA` finding: the fabric is not carrying the workload
  and every EFA-derived conclusion in the report is about a degraded path.
- **P1 — Urgent** for a sustained or increasing series on any counter (a leak or an exhaustion that worsens
  as the job scales) and for `alloc_pd_err`, which blocks all downstream resource creation.
- **P4 — Informational** for one or two errors confined to the first intervals with healthy EFA traffic:
  capability probing with fallback, working as designed.

**Execution risk: R0 — Read-only** for the whole diagnosis: the metric key, the series shape, the byte
counters, `lifespan`, and the `ena_stat` fallback check are all reads of the existing report. The
remediations span the range. **R1** for re-recording from before application launch so the startup failures
are captured. **R2** for raising `ulimit -l`, adjusting ranks per node, or spreading peers across devices.
**R3 — Application change** for fixing a registration leak or moving registration out of the per-transfer
path. **R4 — Infrastructure change** for a driver/`libfabric`/`rdma-core` version alignment, container
device passthrough, or a placement-group change — and note that a version alignment usually resolves
*several* of these findings at once, which is what makes it worth the risk tier.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one data point of an `efa_stat` metric matching `^*_err$` was `>= 1.0`.

```
STEP 0 — WHICH metric is the finding keyed on, and is the value real?
  The description does NOT name the metric. One finding is emitted per matching
  metric, so list every EFA Errors finding in the report before diagnosing any.
  IF the value is FRACTIONAL (e.g. 1.5)
  THEN → an average-series artifact on a multi-device instance: a count that
         cannot be a count (P2, R0)
       → read the per-device series for real numbers, and note whether the errors
         are on one device or all
  IF lifespan is much smaller than the workload's age, OR the aperf log carries
     "skipped N data points due to unexpected decrease" for this metric
  THEN → a DRIVER RESET happened. Counters restarted and the decrease became a
         gap, so the surviving data misleads in either direction (P1, R1)
       → check keep_alive_rcvd for gaps: "a gap triggers a device reset"
       → verify: re-record without a reset in the window; the warning should vanish
         and lifespan should exceed the recording length
  IF the key is rdma_write_wr_err or rdma_read_wr_err
  THEN → LAYER 1, data path. Operations failed AFTER setup succeeded (P1, R0)
       → go to STEP 1
  IF the key is one of alloc_ucontext_err, alloc_pd_err, alloc_mr_err, reg_mr_err,
     get_dma_mr_err, create_qp_err, create_cq_err, create_ah_err, mmap_err
  THEN → LAYER 2, resource setup. The RDMA path could not be built (P2, R0)
       → go to STEP 2
  IF the key is cmds_err ALONE
  THEN → LAYER 3, control plane. The device rejected an admin command (P2, R0)
       → read submitted_cmds vs completed_cmds, no_completion_cmds, keep_alive_rcvd
       → with no_completion_cmds non-zero this is DEVICE HEALTH, not application
         configuration (P1, R4)
       → verify: a device reset or replacement clears no_completion_cmds; lifespan
         restarts at the reset
  IF cmds_err fired WITH a layer-2 counter
  THEN → corroboration, not a separate problem. Diagnose the layer-2 counter
       → go to STEP 2
  IF SEVERAL setup counters fired together
  THEN → ONE shared root cause, not several bugs (P1, R4)
       → suspect version skew: userspace libfabric/rdma-core built against a
         different EFA kernel driver than the one loaded
       → verify: align the driver and userspace versions; ALL of these findings
         should disappear together on the next recording
  ELSE continue to STEP 1.

STEP 1 — Is EFA carrying traffic at all?
  This decides whether the errors are cosmetic or fatal, and it is the highest-value
  branch in the tree.
  IF tx_bytes and rx_bytes are near ZERO
  AND ena_stat tx_bytes/rx_bytes are ELEVATED
  THEN → TRAFFIC FELL BACK TO TCP. The errors are FATAL, not probes. For a
         latency-sensitive workload this is most of EFA's value lost (P0, R4)
       → likely: provider not selected, missing device permissions, container
         passthrough, peers outside the placement group, or a driver version change
       → the extra TCP volume can breach ENA bandwidth/PPS/tracking allowances —
         check those counters for second-order failures
       → verify: after the fix, EFA bytes rise, ENA bytes fall, and this finding
         stops firing. Confirm with fi_info -p efa and NCCL_DEBUG=INFO out of band
  IF tx_bytes / rx_bytes are near zero with NO ena_stat rise
  THEN → the fabric is idle and nothing took its place: the job may be hung on
         failed communication (P0, R0)
       → cross-check `Underutilized CPU` and the application logs
  IF tx_bytes / rx_bytes are NORMAL
  THEN → EFA works despite the errors: probes, transient, or partial (P3, R0)
       → go to STEP 2
  ELSE continue to STEP 2.

STEP 2 — What SHAPE does the error series have?
  IF errors appear ONLY in the first one or two intervals and the workload is healthy
  THEN → CAPABILITY PROBING WITH FALLBACK, the most common benign case.
         Working as designed — INFORMATIONAL (P4, R0)
       → note which allocation was probed; it tells you what the middleware wanted
  IF the series is INCREASING over the run
  THEN → a RESOURCE LEAK: resources created per operation instead of once.
         The clearest actionable pattern in this rule (P1, R3)
       → verify: after hoisting the allocation out of the per-operation path, the
         series flattens and the score stops growing with run length
  IF the series is SUSTAINED but flat
  THEN → a steady-state failure: an exhausted limit rather than a leak (P1, R0)
       → go to STEP 3
  IF the errors are a BURST mid-run
  THEN → correlate the timestamp with a scale-out event, a peer failure, a memory
         pressure spike, or a driver reset (P2, R0)
       → verify: the burst should align with an event in the job launcher or
         application log; if nothing aligns, suspect the fabric (see STEP 3 remote)
  ELSE continue to STEP 3.

STEP 3 — Work the layer-specific cause.
  IF the key is reg_mr_err, alloc_mr_err, or get_dma_mr_err
  THEN → the ulimit -l CLASSIC: RDMA needs pinned memory (P1, R2)
       → check the locked-memory limit first (typically unlimited for EFA), then
         per-transfer registration, then memory pressure in meminfo and vmstat
       → verify: raise the limit, re-record, and confirm the counter stays at zero
         while the registered-buffer set is the same size or larger
  IF the key is create_ah_err
  THEN → address handles are ONE PER REMOTE ENDPOINT, so this scales with job
         width and appears as the job scales out (P1, R2)
       → count the peers; check for AH churn on short-lived connections
       → verify: the counter should scale with peer count. If it does not, the
         cause is an unreachable or misconfigured peer rather than exhaustion
  IF the key is create_qp_err, create_cq_err, or alloc_pd_err
  THEN → per-device resource exhaustion: too many ranks per node. Protection
         domains are the rare and severe case, blocking ALL downstream QP and MR
         creation (P1, R2) — for alloc_pd_err specifically (P1, R3)
       → reduce ranks per node, or spread ranks across EFA devices
       → verify: at a lower rank-per-node count the counter returns to zero; if not,
         the resource is being leaked (STEP 2) rather than exhausted. For
         alloc_pd_err, expect create_qp_err and reg_mr_err to fall silent once PD
         allocation succeeds — they are downstream of it
  IF the key is alloc_ucontext_err or mmap_err
  THEN → DEVICE ACCESS, the earliest possible failure: the process could not open
         or map the EFA device. Check group membership, container passthrough,
         SELinux/AppArmor, and driver/library version match (P1, R4)
       → verify: the application should be able to open the device out of band
         (fi_info -p efa, same user, same container)
  IF the key is rdma_write_wr_err or rdma_read_wr_err
  THEN → separate LOCAL from REMOTE before acting (P0, R3)
       → LOCAL: memory regions deregistered in flight, bad addresses or lengths,
         protection-domain or key mismatches, queue pairs driven to an error state
       → REMOTE: read unresponsive_remote_events, impaired_remote_conn_events,
         retrans_timeout_events, and the PEERS' own aperf reports
       → a work-request error usually surfaces as an abort or a hang: correlate
         with the application and MPI/NCCL logs
       → verify: the fix must hold at the SAME scale and message pattern that
         produced the error; a smaller run proves nothing
  ELSE continue to STEP 4.

STEP 4 — What survives?
  VALID  : this finding itself, and every non-EFA finding in the report. Errors are
           errors regardless of traffic volume
  VOID   : any EFA throughput or latency conclusion from a run where traffic fell
           back to TCP; any reading of `Unused RDMA Read`/`Unused RDMA Write` as a
           design choice when setup errors are present — they are CONSEQUENCES
  CAUTION: the value is the WORST INTERVAL, not the run total. Fractional values
           are average-series artifacts. Absence of this finding does NOT mean no
           errors: pre-recording failures are invisible
  CONFOUNDED: ena_stat allowance findings in a fallback run — the TCP volume that
           breached them exists BECAUSE EFA failed, so they are second-order

INSUFFICIENT DATA
  IF the report has no efa_stat section
  THEN → prepare_data_collector returned IgnoredDataPreparationError
         ("No EFA metrics available") and the rule COULD NOT FIRE (P2, R0)
  IF aperf started AFTER the application launched
  THEN → setup failures at launch are invisible: the first sample is forced to 0
         and pre-recording errors never appear (P1, R1)
       → re-record from before launch; confirm out of band meanwhile
       → verify: on the earlier-started run the counters either fire (the failure
         was real and was being missed) or stay at zero across the launch window
```

## Runtime-specific consequences

EFA workloads are overwhelmingly C/C++/Fortran MPI and Python-driven ML. Of the four target runtimes, **only
Python is commonly relevant**, and it is relevant in a specific and dangerous way: it hides the failure.

| Runtime | Typical role on EFA | What to check |
|---|---|---|
| **Python** | PyTorch/JAX driving NCCL or MPI. Every allocation that produces these counters happens in native libraries below the interpreter | **`NCCL_DEBUG=INFO` and `FI_LOG_LEVEL=warn` are the only way to see the fallback.** A training job whose EFA setup failed and fell back to TCP runs to completion, just slower — no exception, no traceback, nothing in the Python layer. This finding may be the **only** signal |
| **Java** | Rare on EFA; analytics frameworks use TCP | If Java is present with EFA attached, error counters are more likely to be probe artifacts from a co-resident MPI process than anything Java did |
| **.NET** | Effectively absent from EFA workloads | Not applicable |
| **Perl** | Not applicable | — |

**The Python-specific trap, and it matters more here than in any other `efa_stat` finding:** memory
registration failures (`reg_mr_err`, `alloc_mr_err`) are the counter most often driven by a Python-level
choice, because the buffers being registered are framework tensors. A training loop that allocates fresh
communication buffers per step drives per-transfer registration, which is exactly the leak in STEP 2 — and in
Python it looks like ordinary tensor allocation, not a resource leak. Look for buffer reuse (a pinned-memory
pool, a persistent communication buffer) before concluding the limit is too low. Second trap: `processes`
shows only a truncated `comm` (`python3`) and only the top entries by CPU, so a distributed job appears as
several indistinguishable processes — **aperf cannot tell you which rank hit the error.** Correlate with the
job scheduler's logs.

## Architecture-specific considerations

EFA collection is architecture-neutral: aperf reads `/sys/class/infiniband` regardless of CPU
(`src/data/efa_stat.rs:26`–`:46`), and when the directory is absent it emits only a `debug!` line — **not** a
warning, deliberately, because "which is a common case, users should not see any warning messages"
(`:33`–`:35`). Architecture matters here for the *cause*, not the collection: every one of the twelve
counters is driven by a userspace/kernel software stack that has to be built for the platform. Confirm
architecture from `pmu_config.json` ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before diagnosing.

| Observed | Reading | Action |
|---|---|---|
| Setup errors, x86_64 EFA instance (`p5`, `hpc6a`, `c5n`, `c6in`) | The mature stack. Suspect limits and exhaustion (`ulimit -l`, ranks per node, peer count) before version skew | Follow STEP 3 (P1, R2) |
| Setup errors, arm64 EFA instance (`hpc7g`, `c7gn`, `c8gn`) | Same hardware capability, but libfabric, the AWS OFI NCCL plugin, and the MPI build must **all** be compiled for arm64 | Verify each with `fi_info -p efa` and `ldd`; a generic build is the likely cause (P1, R4) |
| **Several** setup counters together, **immediately after an architecture migration** | The single highest-value pattern in this playbook. The fabric stack was rebuilt, and a mismatched or fallback build produces failures across counters at once | Align driver and userspace versions for the target architecture; expect all the findings to clear together (P0, R4) |
| `alloc_ucontext_err` / `mmap_err` on any architecture | Device access, not architecture: permissions, container passthrough, SELinux/AppArmor | (P1, R4) |
| Nitro v4+ remote counters absent (`retrans_*`, `impaired_remote_conn_events`) | Not an architecture question — an instance-generation one. You cannot rule out a remote cause on older generations | Note the limitation; do not read absence as evidence (P2, R0) |

**The architecture-specific checks that matter here are all out of band**, and aperf collects none of them:
`fi_info -p efa` (is the provider present and loaded for this architecture?), `ldd` on the MPI and NCCL
plugin libraries (are they the platform builds?), the EFA kernel driver version against the installed
`rdma-core`/`libfabric` version (the version-skew check), and `ulimit -l` for the calling process. The Python
native-extension concern in [ARCHITECTURE.md](../ARCHITECTURE.md) §5.3 applies directly: a wheel installed
for the wrong platform is a common way to end up with a mismatched fabric stack.

## Verification

**Every remediation in this playbook has a prediction attached, and the predictions differ by layer.** State
yours before you change anything.

- **Version skew** (several setup counters at once) — predict that aligning the driver and userspace versions
  makes **all** of those findings disappear together on the next recording. If only some clear, the diagnosis
  was wrong and the remainder are independent causes.
- **Locked-memory limit** (`reg_mr_err`, `alloc_mr_err`, `get_dma_mr_err`) — predict the counter stays at zero
  while the registered-buffer set is the **same size or larger**. Re-testing with a smaller set proves nothing.
- **Resource leak** (an increasing series) — predict the series **flattens**, not merely that it drops. A
  leak fixed by raising a limit still grows; a leak fixed properly stops growing with run length. The
  discriminator against **endpoint exhaustion** (`create_qp_err`, `create_cq_err`, `create_ah_err`) is that
  exhaustion scales with rank or peer count: if reducing ranks per node does not clear it, it is a leak.
- **Data-path errors** (`rdma_*_wr_err`) — predict the fix holds at the **same scale and message pattern** that
  produced the error. A smaller reproduction is not evidence: both the local causes (in-flight deregistration,
  key mismatch) and the remote ones (peer teardown, failed node) are scale-dependent.
- **Fallback to TCP** — predict EFA bytes rise **and** ENA bytes fall. Only one of the two moving means the
  traffic went somewhere else again, and confirm out of band with `fi_info -p efa` and `NCCL_DEBUG=INFO`.

**Two things to check on every verification run, regardless of layer.** First, start aperf **before the
application launches** — the first sample is forced to 0, so a recording that begins mid-run cannot see the
setup failures you are trying to confirm are gone. Second, confirm `lifespan` exceeds the recording length, so
no driver reset silently dropped intervals from the window. **And treat absence of this finding on the
verification run as weak evidence**: it is consistent with the fix working and equally consistent with the
recording having missed the failure. Pair it with a positive signal — EFA bytes at the expected level, RDMA
operation counters non-zero, and no fallback traffic on `ena_stat`.

## Do not

- **Do not act on this finding without reading the metric key.** The twelve counters span three failure layers
  with different remediations, and the description does not name the metric.
- **Do not treat every firing as a failure.** Middleware capability probing with fallback is the most common
  cause; one or two errors at startup with a healthy workload is usually benign.
- **Do not read the value as a total.** It is the **worst single interval**, selected by largest `abs(score)`
  with `>=`, so ties resolve to the later point; the run total is higher.
- **Do not treat a fractional count as real.** It is an `average`-series artifact on a multi-device instance —
  and it cannot occur at all on a single-device instance, where the aggregate is removed.
- **Do not conclude "no errors" from the absence of this finding.** Pre-recording errors are invisible, the
  first sample can never fire, and after a driver reset the decreasing samples are skipped rather than
  producing a negative spike — the gap hides whatever preceded it.
- **Do not count several setup counters as several problems.** They usually share one root cause — version
  skew, locked-memory limits, or device resource exhaustion.
- **Do not read `Unused RDMA Read`/`Write` as design choices when setup errors are present.** They are
  consequences of a broken path.
- **Do not compare this score against the run-comparison findings' scores.** Those reach five figures for a
  measurement-validity problem, not a failure. Within this rule, though, the score is linear and worth ranking
  on.
- **Do not stop at the EFA layer when EFA bytes collapsed.** The traffic went somewhere — usually TCP over
  ENA — and that path has its own ceilings.
- **Do not verify a fix at a smaller scale than the one that broke.** Peer count, rank count, and buffer-set
  size are the variables these counters respond to.
- **Do not expect this rule to cover ENA driver errors.** `tx_dma_mapping_err`, `tx_prepare_ctx_err`, and
  `rx_dma_mapping_err` live in `ena_stat` and **no rule fires on them**.

## References

- Rule: `src/analytics/rules/efa_stat.rs:54` — `time_series_data_point_threshold_multi_metric!` with
  `pattern: "^*_err$"`, `Comparator::GreaterEqual`, `threshold: 1.0`, `Score::Poor`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — the multi-metric
  macro sets `regex_matching: true` (the single-metric one sets `false`); the worst data point is selected by
  largest `abs(compute_finding_score(...))` with `>=` (ties resolve to the later point), the sign is restored
  afterwards, and the finding is keyed on **`metric_name`**, so one finding is emitted per matching metric.
- Pattern resolution: `time_series_matched_metric_names`,
  `src/data/common/processed_data_accessor.rs:133`–`:154` — compiles with `Regex::new` and returns an
  **empty `Vec` on compile error**. Verified empirically that `^*_err$` compiles, behaves identically to
  `_err$` (the `^*` anchor is vestigial), and matches all twelve `efa_stat` error counters and nothing else.
  Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — general branch (threshold is 1.0, so
  **no zero trap** and no `value == 0.0` doubling); `Score::Poor = −16`, `:148`.
- Delta processing: `add_accumulative_data_point` at `src/data/efa_stat.rs:243`, first sample forced to 0
  (`ignore_first_accumulative_value: true`, `time_series_data_processor.rs:73`, taken at `:218`); decreasing
  samples return `None` at `:214` and are **dropped** (early return at `:150`), counted and logged once at
  `:297`–`:302`; aggregation is `time_series_data_processor_with_average_aggregate!` (`efa_stat.rs:216`),
  which is why fractional values appear — except on a single-device instance, where `stats_series_idx`
  (`:312`–`:319`) removes the aggregate.
- Collection: `src/data/efa_stat.rs:26`–`:46` reads `/sys/class/infiniband/*/hw_counters/` and
  `.../ports/<port>/hw_counters/`, naming series `<hardware>` and `<hardware>/<port>`; a missing directory
  yields only `debug!("No EFA metrics found")` (`:35`), an empty map
  `PDError::IgnoredDataPreparationError("No EFA metrics available")` (`:170`).
- Metric semantics: all twelve `*_err` counters plus `submitted_cmds`, `completed_cmds`,
  `no_completion_cmds`, `keep_alive_rcvd`, and `lifespan` in
  `src/report_frontend/src/definitions/data-descriptions.ts` (`efa_stat` block, all `desired: "lower"`).
- Related playbooks: `unused-rdma-read.md`, `unused-rdma-write.md`,
  `inconsistent-inbound-efa-traffics.md`, `inconsistent-outbound-efa-traffics.md`,
  `../meminfo/reduced-memory-availability.md`, `../vmstat/major-page-faults-detected.md`,
  `../cpu_utilization/underutilized-cpu.md`.
- [Elastic Fabric Adapter](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa.html) and
  [Monitor an EFA](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-working-monitor.html)
- [EFA troubleshooting](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/efa-troubleshooting.html)
