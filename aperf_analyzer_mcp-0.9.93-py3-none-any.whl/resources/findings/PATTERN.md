# Playbook Pattern

The authoring contract for a **tier-2** playbook, extracted from the 8 validity-gate
playbooks written in batch 1, piloted on `cpu_utilization/underutilized-cpu.md`, applied to
the rest of `cpu_utilization` in batch 2, and generalized until **all 51 followed it**.

[SCHEMA.md](SCHEMA.md) defines tier 1 — the 8 sections and 10 frontmatter keys every one of
the 51 playbooks already has. This document does not replace it. It defines the 5 sections
tier 2 adds, the grammar of the decision tree, and the executable half that keeps the
"Reading the description" section honest.

**Normativity, in order.** Where these disagree, the earlier wins:

1. [tools/check_playbooks.py](tools/check_playbooks.py) — it runs, so it is the real
   contract. Every rule below that can be mechanically checked is checked there.
2. This document — for judgement that cannot be linted (what belongs in a table, when a
   branch is worth having).
3. [SCHEMA.md](SCHEMA.md) — the tier-1 baseline.

Run before committing any playbook:

```
python3 tools/check_playbooks.py             # structure, registry agreement, links
python3 tools/test_aperf_desc.py             # the description parsers still match aperf
python3 tools/test_aperf_rightsize.py        # the sizing recipe still matches the collection loop
python3 tools/test_aperf_ena_allowance.py    # the ENA allowance quantifier and its aggregate artifact
python3 tools/test_aperf_perf_stat.py        # the perf_stat ratio recipes and multiplexing model
python3 tools/test_aperf_memory_hierarchy.py # the cache/TLB ratio recipes and their PMU pairings
python3 tools/test_aperf_statistical.py      # the statistical-findings port, differentially vs the real TypeScript
```

`test_aperf_statistical.py` is the one suite that will skip rather than fail: its load-bearing
check needs `node` to run aperf's own TypeScript, and it prints a `SKIPPED` line naming what
went unchecked when `node` is absent. **Read that line** — a bare `OK` from it on a host without
`node` means the port was pinned only by the hand-written cases.

---

## 1. Tiers

| Tier | Sections | Which findings | Count today |
|---|---|---|---|
| **1** | 8 | Authored before batch 1; correct but shallow — no value-keyed branching | 0 |
| **2** | 13 | Full prescriptive depth: decision tree, priority/risk, architecture, verification | 51 |

Tier 1 is not a defect class; it was a stage, and the tree has now cleared it: the batch tasks
promoted tier-1 playbooks to tier 2 one data type at a time until none were left. A tier-1
playbook must never *lose* content on promotion — the 5 new sections are additive. Any future
playbook (a new aperf rule) starts at tier 1 and should be promoted before it ships.

The lint infers a playbook's tier from the presence of `## Decision tree` and applies the
matching section contract. There is no tier field in frontmatter, deliberately: a playbook
that has a tree but is missing `Verification` is an error, not a third tier.

### 1.1 What promotion actually costs

The pilot (`cpu_utilization/underutilized-cpu.md`) is the reference. Adding the 5 sections
was the smaller half of the work; three existing sections had to be **rewritten**, because
tier 1 states conclusions the tree then has to branch on:

| Section | Why it changes on promotion |
|---|---|
| `Reading the description` | Tier 1 typically names the format string. Tier 2 needs the score table, every alternate description form, and the traps (truncation, forced-zero sample) — because the tree's STEP 1 parses values and every later branch reads them. |
| `Do not` | Tier-1 bullets are generic. Each new tree branch that a reader could invert becomes a bullet: the pilot went 6 → 11, and 4 of the 5 new ones restate a specific branch's failure mode. |
| `References` | Every line number the tree cites must appear here. The pilot went 5 → 15 entries, most of them source citations the tree depends on. |

`What fired`, `Reasoning`, `Interpretation`, and `Corroborating data` usually survive intact.
Budget promotion as roughly half new sections, half rewriting the description-reading and
reference apparatus underneath them.

---

## 2. Frontmatter

Ten keys, in exactly this order, in every playbook of either tier:

```yaml
---
rule_name: Underutilized CPU          # EXACT string from aperf's finding JSON — the join key
data_type: cpu_utilization            # aperf data type
data_key: idle                        # metric, key-value key, or profiler name
template: time_series_stat_threshold  # one of the 10 names in INDEX.md
condition: "avg(idle) > 50.0"         # the literal firing condition
base_score: Critical                  # Score enum name
score_sign: negative                  # negative | positive | neutral
requires_comparison: false            # true if the rule needs >= 2 runs
aperf_message: "CPU utilization might not be maximized."
source: src/analytics/rules/cpu_utilization.rs:25
---
```

Order is part of the contract, not a style preference: it makes a diff between two
playbooks show content changes rather than key shuffling.

Rules the lint enforces:

- Every value must **agree byte-for-byte with `FINDINGS_REGISTRY.json`** for that
  `rule_name`. The registry is generated from source; the playbook is hand-written, so
  the playbook is what drifts.
- `source` must be `path:line` (or `frontend-computed` for statistical findings), and the
  line must resolve to a non-blank line in the pinned aperf tree.
- The H1 immediately after the frontmatter must equal `rule_name` exactly.
- Filename stem must equal the registry's `slug`.

---

## 3. Section order

Tier 2 is tier 1 with 5 sections spliced in after `Guidance` and before `Do not`:

| # | Section | Tier | Answers |
|---|---|---|---|
| 1 | `What fired` | 1 | The mechanical condition, and what the score does and does not mean |
| — | *(optional evidence section)* | either | See §3.1 |
| 2 | `Reasoning` | 1 | Why this is a performance signal, physically |
| 3 | `Reading the description` | 1 | How to get numbers out of the finding (§5) |
| 4 | `Interpretation` | 1 | What ranges mean; the false positives |
| 5 | `Corroborating data` | 1 | Which other data confirms or refutes |
| 6 | `Guidance` | 1 | Ordered steps, each gating the next |
| 7 | **`Priority and execution risk`** | **2** | How urgent, how dangerous to act (§4) |
| 8 | **`Decision tree`** | **2** | The branch on observed values (§6) |
| 9 | **`Runtime-specific consequences`** | **2** | .NET / Python / Java / Perl (§7) |
| 10 | **`Architecture-specific considerations`** | **2** | Intel / AMD / arm64 (§8) |
| 11 | **`Verification`** | **2** | What re-running proves (§9) |
| 12 | `Do not` | 1 | Wrong conclusions to head off |
| 13 | `References` | 1 | Source, upstream guide, external docs |

`Runtime-specific consequences` is the canonical heading. Batch 1 used three variants
(`Runtime-specific notes`, and one with a trailing clause); these were normalized. When a
finding's runtime story is mostly a *gap* — as with `JVM Version Comparison`, where only
Java has a gate at all — say that in the body's first line, not in the heading.

### 3.1 The optional evidence section

A playbook may insert exactly one extra section immediately after `What fired`, when a
behavioural claim was established by *running* aperf rather than by reading it, or when
aperf's own advice points at data aperf cannot produce. Its title must start with one of:

- `The processing defect — ...` — the rule is buggy or cannot fire as documented
- `The processing caveat — ...` — the rule fires, but on something other than it appears
- `The pattern actually works — ...` — a suspected defect that turned out to be fine
- `The collection gap — ...` — aperf's guidance names data aperf does not collect

The position is fixed at index 1 so a reader hits the caveat before the reasoning that
would otherwise mislead them. Seven playbooks use it today — four `processing defect`, one
`processing caveat`, one `pattern actually works`, one `collection gap`.

**The `collection gap` stem earns its place because the gap is not discoverable from the
report.** `Decreased User-Space CPU Utilization` is the case that produced it: aperf's own
optimization guide tells the reader to do off-CPU profiling, and `--profile` runs
`perf record -e cpu-clock` (`src/data/perf_profile.rs:136`), which samples only running
threads. An agent that trusts the guide will recommend a re-record that cannot produce the
data. Java is the exception — `--profile-java` passes `--wall 100ms` to async-profiler
(`src/data/java_profile.rs:81`), so wall-clock samples do cover blocked threads. When a
finding's decisive evidence is something aperf cannot collect, say so **before** the
guidance that depends on it, and name the out-of-band tool.

---

## 4. `Priority and execution risk`

Three claims and a fixed footer. Vocabulary is defined once in
[GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) §2–§3; never redefine a level here.

````markdown
**Priority: P0 — Blocking** <scope of the claim, and the condition under which it drops>.

**Execution risk: R4 — Infrastructure change** <to resolve>. <Separately, the risk of acting
on what it reveals, which is usually different>.

<One paragraph on what the SCORE does and does not tell you — the trap specific to this rule.>

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).
````

(The two links are relative to the playbook's `<data_type>/` directory, hence `../`.)

Requirements:

1. **Priority is conditional, not a constant.** Every batch-1 gate states a second
   priority for a second situation (`P0` when it reflects hardware, `P1` when it reflects
   configuration). A single unconditional `Pn` usually means the situations were not
   separated yet.
2. **Two risks, not one.** The risk of *resolving* the finding and the risk of *acting on
   what it reveals* differ, often by four levels: `Kernel Version Mismatch` is R4 to fix
   and R5 to act on. Conflating them is how a read-only investigation turns into an
   unvalidated production change.
3. **Say what the score is worth.** For a non-amplifying template, say the score is flat
   and that magnitude lives only in the strings. For an amplifying one, say the score
   carries the value and nothing else — not a severity.
4. **Name the comparator when it is surprising.** `Greater` vs `GreaterEqual` decides
   whether exactly-at-threshold fires. The EFA gates and the netstat gates test the same
   thing with different comparators.
5. The footer is byte-exact, and it is the last line of the section.

---

## 5. `Reading the description`

The most mechanical section, and the one most worth getting exactly right: everything
downstream branches on what this section extracts.

Shape:

1. Name the template, then quote its **literal format string** in a fence, with `{}`
   placeholders as they appear in the Rust `format!`.
2. Quote one **concrete** example, using plausible run names.
3. A numbered list — batch 1 settled on five items — of what a reader would otherwise get
   wrong: units, truncation, direction, what is absent from the text.
4. **The score treatment**, which is entirely determined by the template:
   - **Amplifying** (`time_series_stat_threshold`, `time_series_data_point_threshold`
     ±`_multi_metric`, `time_series_stat_run_comparison`,
     `time_series_stat_intra_run_comparison`): show the `compute_finding_score` call with
     this rule's actual arguments, name the branch, and give a table of value → score
     across the range a reader will actually see.
   - **Non-amplifying** (`key_value_key_expected`, `key_value_key_run_comparison`,
     `profile_stack_frame_threshold`, `profile_metadata_expected`,
     `profile_metadata_comparison`, `multi_data_rule`): state that
     **`compute_finding_score` is never called and no score table applies**. The lint
     greps for this claim, because a score table on a flat rule is a real authoring error
     that invents magnitude.
5. Every other description **form** the template can emit. Missing keys, absent metadata,
   and zero baselines all produce different sentences at the same severity, and a tree
   that only handles the common form silently mis-routes the others.
6. **For the 13 `time_series_stat_run_comparison` rules, an absolute-magnitude branch
   BEFORE the percentage branch.** The template compares `|(cur - base) / base|` to
   `delta_ratio` and has **no absolute floor**
   (`time_series_stat_run_comparison_rule.rs:97-110`), so on a metric whose value is near
   zero, a meaningless absolute change produces an arbitrarily large ratio and therefore an
   arbitrarily large score. This is not a corner case: on two **idle** runs recorded 16
   seconds apart on one host, `Inconsistent Inbound Network Traffic` fired at **−61.91** off
   2.4 kB/s, and `Decreased User-Space CPU Utilization` fired at **−72.98** because
   `avg(user)` went 0.94% → 0.51% — a 0.43 percentage-point change on a machine that was
   90% idle in both runs. Both scores exceeded every genuine finding in the report. A tree
   that sizes the delta only in percent routes these to "materially different work" or
   "genuine blocking", which is wrong in both cases. **Size the absolute values first, and
   say what floor makes the ratio meaningful for that metric.**

**Do not hand-derive the parse.** [tools/aperf_desc.py](tools/aperf_desc.py) already
implements every format string, every formatter, and the score inverse:

```python
import sys; sys.path.insert(0, "tools")
from aperf_desc import parse_description, compute_finding_score, value_from_score, SCORE

p = parse_description("The average in flask_run_02 is 86.92.", "time_series_stat_threshold")
p["value"]                                          # 86.92 (truncated, from the text)
value_from_score(-445.05461168773354, 50.0, SCORE["Critical"])
                                                    # (28.76…, 86.9247…) — full precision
```

Three properties of that module every playbook author needs:

- **`f64_to_fixed_2` truncates.** A displayed `999.99` can be anything below `1000.0`.
  Never write "the value was exactly X" from description text.
- **The score is more precise than the description**, so `value_from_score` is the better
  reading — but it returns a *tuple*, because the ratio branch is many-to-one. At ratio 2
  there are three preimages (`0.0`, `threshold/2`, `2×threshold`). Disambiguate with the
  description's own wording or the metric's bounds.
- **A `100.00% greater than X (0)` reading is a substitution, not a doubling.** Both
  comparison templates hardcode a delta ratio of 1.0 when the base stat is zero.
  `base_stat_was_zero()` detects it. Every comparison playbook needs this branch.

### 5.1 Emit a number, not a judgement

aperf's `message` field is always a judgement — `CPU utilization might not be maximized.`,
`The code is consuming more CPU time.` A playbook that routes to a *better-argued judgement*
has not finished the job. **Ask what quantity the reader would act on, and whether the report
already contains its inputs.** Usually it does, and the playbook's job is the arithmetic.

`Underutilized CPU` is the worked case: the finding says utilization "might not be maximized",
while the report holds `avg(total)`, `max(total)`, and `CPUs` — enough to say *"32 of 64 vCPUs
suffices, a 50% reduction."* [tools/aperf_rightsize.py](tools/aperf_rightsize.py) computes it,
`tools/test_aperf_rightsize.py` pins it.

**Put the arithmetic in a module, not in prose, once it needs more than one correction.** That
recipe needs four, each of which silently changes the answer:

| Correction | Get it wrong and | 
|---|---|
| peak is `max(total)`, never `100 − min(idle)` | the forced zero makes `min(idle)` 0.00, so peak reads 100% on an idle machine |
| `p99` == `max` for n ≤ 100 (`floor(q×n)`) | you cite a tail statistic that is one 1-second sample |
| `true_avg = reported × n/(n−1)` | the average understates by ~10% at the default `--period 10` |
| x86 SMT halves the physical cores | you size to a core count that does not exist |

Prose cannot enforce these; a module with tests can. The test that matters **simulates aperf's
collection loop** and checks the corrections recover the injected load — self-consistency
would have passed all four mistakes above.

The same discipline applies to a rule's own threshold. Inverting the forced-zero correction
showed `Underutilized CPU` needs a *true* `avg(idle)` above **55%** to fire at the default
period, so it is silent on a machine genuinely at 45–49% utilization: **the absence of a
finding was not evidence, and only the arithmetic revealed that.**

---

## 6. `Decision tree`

The section that makes a playbook prescriptive rather than descriptive.

An `Entry condition:` line, then exactly one fenced block:

```
STEP 1 — <Imperative title stating what this step decides.>
  <Optional context lines, indent 2.>

  IF <condition on an observed value>
  AND <corroborating condition from another data type>
  THEN → <conclusion> (P<n>, R<n>)
       → verify: <what re-reading or re-running should show>
  IF <next condition>
  THEN → <conclusion> (P<n>, R<n>)
  ELSE <fall through>

STEP 2 — <...>

STEP n — What survives?
  VALID      : <findings still readable>
  CONFOUNDED : <readable but cause unclear>   # comparison gates only
  CAUTION    : <readable with a stated caveat>
  VOID       : <findings that mean nothing now>

INSUFFICIENT DATA
  IF <the rule could not fire, or the data is absent>
  THEN → <what the silence does and does not prove> (P<n>, R<n>)
```

### 6.1 Grammar

| Element | Rule |
|---|---|
| `Entry condition:` | One line before the fence. States what firing means, so no branch has to. |
| Fences | Exactly one. Two fences make the leaf census non-reproducible. |
| `STEP n — Title` | Consecutive from 0 or 1. Start at 0 when step 0 is a data-existence gate. |
| Indentation | **Load-bearing.** A branch starts at indent ≤ 2; every continuation is deeper. This is how the lint tells a wrapped line from a new leaf. |
| `→` | Introduces an action or a conclusion. |
| `(Pn, Rn)` | On every action leaf. `P0–P4`, `R0–R5`. |
| `→ verify:` | On every leaf with `R ≥ 1` that is not a dead end (§6.2). |
| Final step | Must be `What survives?`. |
| Survive labels | From `VALID`, `VOID`, `CAUTION`, `CONFOUNDED`. `VALID` and `VOID` are required. |
| `INSUFFICIENT DATA` | Required, after the last step. |

### 6.2 Which leaves need `→ verify:`

A leaf prescribing a change (`R ≥ 1`) must say how to confirm it worked. Two exemptions:

- **Dead ends** — the action is "stop, re-run matched", so there is nothing in the current
  report to verify. Recognized by `STOP`, `NO finding`, `incomparable`, `COULD NOT FIRE`,
  or `VOID` in the leaf.
- **Routing leaves** — the leaf only forwards to another step or document, and so carries
  no `(Pn, Rn)` at all.

The lint reports every other unverified action leaf as a **warning**, not an error: it is a
backlog, not a defect. The backlog is currently **empty** — all 327 action leaves across the
51 tier-2 playbooks (out of 1,108 leaves total) carry a `verify:`. Keep it that way: a new
playbook that lands warnings is unfinished, even though the lint exits `OK`.

Writing the verify line is where a weak branch shows itself. Three of the eleven backfilled
here could not be verified by re-reading the report at all — the honest answer was "re-record
matched", which is a *different* prescription than the leaf originally implied. One
(`meminfo` STEP 2) turned out to be misclassified: it was marked `R1` while doing nothing but
routing to the next step, so its risk moved to `R0` and the remediation risk now lives in the
step that actually identifies the reservation.

### 6.3 Authoring rules

Beyond [GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) §4:

1. **Branch on the value; the finding's existence is the entry condition.**
2. **Step 0 is a data-existence gate whenever the data type is optional.** `java_profile`,
   `efa_stat`, and `perf_stat` can all be absent, and the rule's *silence* then proves
   nothing. This is the worst failure mode for a validity gate and it needs its own step.
3. **The zero-baseline branch is mandatory for every comparison template** (§5).
4. **A step that requires data aperf does not collect must say so and say where to get
   it.** `Instance Type` is collected but never compared; the kernel command line is not
   collected at all. Mark these `MANDATORY manual check:` in the step title.
5. **`What survives?` is about the rest of the report, not this finding.** It is what makes
   a validity gate actionable: the reader needs to know which of the other 50 findings
   they may still believe.
6. **Percentile branches are unsound at default geometry.** At `--interval 1 --period 10`,
   `p90`/`p99`/`p99_9`/`max` are the same element. Route to `INSUFFICIENT DATA` rather
   than onto noise.

---

## 7. `Runtime-specific consequences`

Scope is **.NET, Python, Java, Perl**. Lead with one or two sentences naming the *mechanism*
by which this finding reaches a runtime at all, then a four-row table:

```markdown
| Runtime | <what the finding changes for it> | <what to check, or the consequence> |
|---|---|---|
| **.NET** | … | … |
| **Python** | … | … |
| **Java** | … | … |
| **Perl** | … | … |
```

- **Name the unknown-runtime case.** aperf does not report the language; it is inferred
  from `processes` names ([GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) §1.3). A tree that assumes
  a runtime is guessing.
- **Say when a runtime is irrelevant, and why.** On the EFA gates, Python is an
  orchestrator and the bytes move in native collectives — that is the useful statement,
  not four padded rows.
- **Prefer auto-scaling behaviour over flags.** The finding usually matters because the
  runtime silently re-derives a default from something that changed (core count, total
  memory, page size). That is what makes an apparent regression pure sizing.

---

## 8. `Architecture-specific considerations`

Scope is **Intel, AMD, arm64**, against the eight PMU profiles in
[ARCHITECTURE.md](ARCHITECTURE.md) §2.

Cover, where each applies:

1. **Whether the finding can fire at all.** 15 `perf_stat` findings depend on a metric that
   exists only in some profiles. `High Code Sparsity` exists on two of eight; both stall
   findings are dead on `amd` generic. The registry's `architectures` array per finding is
   authoritative; `architecture_note` carries the caveat.
2. **Whether the metric means the same thing.** `stall-backend-pkc` and `l3-mpki` are
   *redefined* per profile, so a cross-architecture comparison of the same finding compares
   different quantities. This is worse than a missing metric, because it looks valid.
3. **Counter mode.** Grouped is the default (`src/data_collection.rs:379`);
   `--ungroup-pmu-events` opts out. Grouped runs about twice the counters, so a run with a
   better `mux_counter_schedule_rate` may simply have been recorded ungrouped — a
   collection artifact, not a better run.
4. **Architecture-specific build and config variants**, when the workload has them. The
   exemplar class is `microsoft/onnxruntime` vs `amd/ZenDNN-onnxruntime`: same framework,
   different tuned build, and picking the wrong one is an R3 finding invisible to every
   aperf metric.
5. **The silent case.** aperf has no architecture field. When `CPUs` and `MemTotal` match
   across an Intel→Graviton migration, no gate fires at all
   ([GATES.md](GATES.md) §"The two gaps"). Whenever this finding could be read across an
   architecture change, say so.

---

## 9. `Verification`

Short and falsifiable: one paragraph, no table. State the change, then what re-running aperf
should show, then what it means if the finding *persists*. If nothing in aperf can confirm
it, say that plainly — [GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) §4 requires a leaf that cannot
be verified to admit it.

---

## 10. Density

Tier-2 targets, measured across all 51 files. The lint warns outside these ranges:

| Measure | Range | Observed |
|---|---|---|
| Total lines | 350–600 | 402–600 |
| Table blocks | 5–14 | 5–12 |
| `Do not` bullets | 8–14 | 8–14 |
| `References` bullets | 8–16 | 8–16 |

These describe what adequate coverage happened to cost; they are not a target to pad
toward. A finding with a genuinely simple story should be short and trip the warning, and
the warning should then be ignored. What is *not* optional is the section set.

**Batch 2 pushed the upper bound, and it is worth knowing why.** The `cpu_utilization`
findings crowded the 600-line ceiling first (batches 3 and 4 have since joined them there),
because each one carries a large *shared*
substrate — the forced-zero first sample, the `total = 100 − idle` derivation, the
sample-count recovery `n = 100 / (100 − (avg(total) + avg(idle)))`, and the geometry-mismatch
bounds — that every tree needs and that no single file can own. Where a fact belongs to one
finding, cite it once and cross-reference; `increased-io-wait-time.md` and the two user-space
files both point at `consistent-cpu-utilization.md` for the sample-count derivation rather
than restating it. Length that comes from re-deriving a neighbour's arithmetic is padding;
length that comes from a branch the reader would otherwise get wrong is not.

`References` must include the rule source (`rules/*.rs:line`), the rule template, the
score formula when the score is amplified, the upstream guide in
`optimization-guides.ts` when one exists, and external documentation for every claim about
runtime or architecture behaviour.

---

## 11. Authoring checklist

Ordered — each step depends on the previous:

1. **Read the rule in the Rust source.** Never author from the rule name. Confirm metric,
   stat, comparator, threshold, score, and message against `src/analytics/rules/*.rs`.
2. **Confirm the registry entry matches**, and copy frontmatter from it.
3. **Read the template** in `src/analytics/rule_templates/` for every description form it
   can emit, including the early-return paths that produce *no* finding.
4. **Check `aperf_desc.py` parses your example descriptions.** Add a case to
   `test_aperf_desc.py` if the form is not covered.
5. **Compute the score table with `compute_finding_score`**, do not multiply by hand.
6. **Check the architecture constraint** in the registry and
   [ARCHITECTURE.md](ARCHITECTURE.md) §2 before claiming the finding fires anywhere.
7. **Write the decision tree first, then the prose around it.** The tree is what forces you
   to discover which values you actually cannot obtain; writing `Interpretation` first tends
   to produce branches that assume data aperf does not collect.
8. **Write a `verify:` on every `R ≥ 1` leaf as you write the leaf**, not afterwards. If you
   cannot state one, the branch is not yet a prescription — either it is a dead end (say so,
   in the words §6.2 recognizes) or its risk level is wrong.
9. Write the 13 sections in order, rewriting the three that §1.1 says promotion touches.
10. **Run both tools.** Fix every error; the warning backlog should stay empty.
11. **Update `INDEX.md` and `PATTERN.md` §1/§10 if the promotion changed a count**, and
    re-run the lint's link check.

---

## 12. What this pattern does not cover

- **Statistical findings** are frontend-computed and have no `rule_name` join key. They
  are triaged as a class in [statistical/README.md](statistical/README.md).
- **Cross-finding precedence** is not in any playbook by design. A playbook states its own
  priority; the ordering *between* findings lives in [GATES.md](GATES.md), because it is a
  property of the report and not of any one finding.
- **Delivery format.** Whether the MCP returns a playbook verbatim or re-feeds it to a
  model is open ([GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) §5). The pattern is written to
  serve both: the tree is readable as prose and parseable by its grammar.
