# Finding Playbook Schema

Contract for every `<data_type>/<rule-slug>.md` file in this tree. The MCP loads these
verbatim as prescriptive instructions when the matching finding appears in a run.

A playbook is **executable instructions for an agent**, not prose for a human to skim.
Write it so that an agent holding only (a) this file and (b) the aperf run directory can
carry out the investigation without guessing.

> **This document defines the tier-1 baseline** — the 8 sections and 10 frontmatter keys that
> every one of the 51 playbooks has. Findings promoted to full prescriptive depth add 5 more
> sections and follow [PATTERN.md](PATTERN.md), which is the contract for **tier 2**. Neither
> document is normative where it disagrees with [tools/check_playbooks.py](tools/check_playbooks.py),
> which enforces both tiers and is what actually runs. See PATTERN.md §1 for the tier model
> and §1.1 for which of the sections below get rewritten on promotion.

## Required structure

````markdown
---
rule_name: Underutilized CPU          # EXACT string from aperf's finding JSON — the join key
data_type: cpu_utilization            # aperf data type / <data_type>_findings variable
data_key: idle                        # metric, key-value key, or profiler name
template: time_series_stat_threshold  # which rule template emitted it
condition: "avg(idle) > 50.0"         # the literal firing condition
base_score: Critical                  # Score enum name
score_sign: negative                  # negative | positive | neutral
requires_comparison: false            # true if the rule needs >= 2 runs
aperf_message: "CPU utilization might not be maximized."   # aperf's own generic advice
source: src/analytics/rules/cpu_utilization.rs:25
---

# Underutilized CPU

## What fired
Plain statement of the mechanical condition. No interpretation.

## Reasoning
Why aperf's authors consider this a performance signal. The causal chain from the
observation to real impact. This is the "reasoning behind the finding" — it must be
grounded in what the metric physically measures, not restated from the rule name.

## Reading the description
How to parse the observed values out of the finding's `description` string, including
the exact format emitted by this template, and what the `score` magnitude implies.

## Interpretation
What the value ranges actually mean. Where the finding is a true positive vs a
false positive. Explicit false-positive conditions — this matters more than the
remediation, because acting on a misread finding wastes the user's time.

## Corroborating data
Which other aperf data types/metrics confirm or refute this finding, and what
each one would show under each competing hypothesis. Reference real metric names
that exist in aperf output.

## Guidance
Prescriptive, ordered steps. Each step states: what to check, in which data, and
what conclusion each outcome supports. On promotion to tier 2, the five sections
defined in PATTERN.md §3 are spliced in immediately after this one — the decision
tree keyed on observed values lives there, not here.

## Do not
Common wrong conclusions to avoid for this specific finding.

## References
Upstream aperf guides and authoritative external docs.
````

## Rules

1. **`rule_name` must match byte-for-byte.** It is the join key. A typo silently
   disables the playbook.
2. **Never invent thresholds.** Every number in the frontmatter comes from the Rust
   source. Numbers introduced in `Guidance` as action thresholds must be labelled as
   guidance, distinct from aperf's firing threshold.
3. **State false positives.** Every rule has them. `Unused RDMA Read` on a workload that
   legitimately never issues RDMA reads is noise, not a finding.
4. **Distinguish sustained from transient.** `time_series_data_point_threshold` fires on a
   *single* data point. Guidance must direct the agent to check whether the condition
   persists before recommending remediation.
5. **Distinguish single-run from comparison.** When `requires_comparison: true`, the
   finding describes a *difference between runs*, not an absolute problem. The remediation
   is often "explain the difference", not "optimize the metric".

   **Verified against real reports, with one exception.** Reporting the same archive as a
   single-run report and as a 2-run comparison produced 11 and 14 findings respectively, and
   the three that appeared only on the pair were exactly the three `requires_comparison:
   true` rules among them — no violations in either direction.

   The exception is **`JVM Version Comparison`**, which is `requires_comparison: true` yet
   **was observed firing at the full −256 on a single-run report.** Its
   `profile_metadata_comparison` template tests `base_values.is_empty()` and, when
   `should_exist` is set, emits before it ever reaches the other-runs loop
   (`profile_metadata_comparison_rule.rs:92`–`:109`, loop at `:111`). So the flag describes
   the rule's *comparison* path correctly while a second, absence path fires with one run
   and a `message` that falsely claims a cross-run difference. Read
   [java_profile/jvm-version-comparison.md](java_profile/jvm-version-comparison.md) STEP 0.

   **Consequence for consumers:** `requires_comparison: true` means "do not expect this on
   a single-run report", not "this cannot appear on one". Treat it as a strong default with
   that one documented exception, rather than an invariant to rely on.
6. **Reference metrics that exist.** Cross-references must use real aperf metric names,
   verified against `data-descriptions.ts` or the report output.
7. **Positive findings still need playbooks.** `Consistent CPU Utilization` and
   `ENA Express Enabled with UDP` are confirmations — the guidance is what they let you
   rule out, and what they do *not* prove.

## Slug derivation

`rule_name` → filename: lowercase, spaces → `-`, drop characters outside `[a-z0-9-]`,
collapse repeats. Authoritative mapping lives in `FINDINGS_REGISTRY.json`; the MCP should
read that rather than re-deriving.
