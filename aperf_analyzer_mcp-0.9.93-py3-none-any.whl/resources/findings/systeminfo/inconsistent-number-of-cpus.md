---
rule_name: Inconsistent Number of CPUs
data_type: systeminfo
data_key: CPUs
template: key_value_key_run_comparison
condition: "value != base_run value"
base_score: Critical
score_sign: negative
requires_comparison: true
aperf_message: "Different amount of CPU resources could result in significant performance discrepancy."
source: src/analytics/rules/systeminfo.rs:18
---

# Inconsistent Number of CPUs

## What fired

The `CPUs` value in this run is **not identical** to the base run's. `CPUs` is `sys.cpus().len()` from the
`sysinfo` crate — the number of logical CPUs the OS sees — stored as a **string** and compared as a string
(`value != base_value`).

Base score `Critical` (**−256**). **The score is flat: 4 vCPUs versus 96 scores exactly the same as 4 versus 8.**
Comparison-only.

**This is the strongest validity gate in aperf.** vCPU count is the denominator of nearly every derived metric
in the report, and on EC2 it is coupled to memory, network bandwidth, and EBS bandwidth. When it differs, **the
two runs were not the same machine**, and essentially nothing in the comparison means what it appears to mean.

## Reasoning

**Why vCPU count invalidates more than any other single difference.** Almost every metric in an aperf report is
either per-CPU, aggregated across CPUs, or normalized by CPU capacity:

- **`cpu_utilization`** is a percentage of available CPU time. The `aggregate` series is the total across all
  CPUs, so **"77% aggregate" on 8 vCPUs and "77% aggregate" on 64 vCPUs describe workloads that differ by 8× in
  absolute CPU consumption.** Every rule in that data type — `Underutilized CPU` included — becomes a statement
  about a different-sized machine.
- **`perf_stat`** counters are summed across CPUs. Instructions, cycles, and cache references scale with core
  count; IPC survives normalization but cache-miss *rates* do not, because last-level cache size scales with the
  instance.
- **`processes`** shows the top-16 by resource usage — a thread pool sized to `nproc` behaves entirely
  differently at 4 versus 64.
- **`interrupts`**, per-queue `ena_stat` series, and softirq distribution all have one entry per CPU: **the
  series count itself differs**, so aperf's `MaxSeries` and aggregate selections pick from different-sized sets.
- **Lock contention and scaling behaviour** are non-linear in core count. A workload that scales cleanly to 8
  threads may collapse at 64. This is the failure mode a CPU-count mismatch most often hides.

**On EC2, vCPU count is never the only thing that changed.** Instance sizes scale vCPU, memory, network
allowance, and EBS bandwidth together. So this finding almost always travels with `Inconsistent Physical Memory`,
and it silently changes the **ceilings** that the `ena_stat` allowance rules test against. **A run that hits
`bw_out_allowance_exceeded` on a smaller instance and not on a larger one has produced a difference caused by
instance size, not by code.** That coupling is why this finding should be resolved before any throughput or
bandwidth conclusion is drawn.

**Why exact string comparison, and what it costs.** The value is `total_cpus.to_string()`, compared as text.
Since it is produced by the same code path in both runs, formatting is consistent and the comparison behaves
exactly like an integer comparison in practice. The real cost is elsewhere: **the template does not compute a
ratio, so the score is flat.** `"4"` versus `"8"` and `"4"` versus `"96"` both yield −256. The magnitude —
which is the whole story here — exists only in the description text.

**What "CPUs" counts, and the SMT subtlety that matters most.** `sysinfo`'s `cpus().len()` counts **logical**
CPUs. On x86 EC2 instances with hyper-threading, that is 2 per physical core; on Graviton it is 1 per core. So
**`"8"` on an x86 instance (4 physical cores) and `"8"` on a Graviton instance (8 physical cores) are the same
string — this rule stays silent — while the actual compute available differs substantially.** The inverse also
holds: comparing a 16-vCPU x86 instance against a 16-vCPU Graviton instance fires nothing here, yet the
architectures, cache hierarchies, and `perf_stat` counter semantics all differ. **`Instance Type` is the field
that settles this, not `CPUs`.**

**Offline CPUs and CPU-set restrictions produce a difference with no hardware change.** `cpus().len()` reflects
what the OS sees. Taking CPUs offline (`/sys/devices/system/cpu/cpuN/online`), a `maxcpus=`/`nr_cpus=` boot
parameter, or an isolation setup can change the count on identical hardware. **A small difference — 63 versus 64,
or 30 versus 32 — is much more likely to be an offline CPU or a boot-parameter difference than an instance-size
change**, because EC2 vCPU counts step in powers of two. That distinction determines whether you re-run or fix
the host image.

**The container blind spot, and it is a large one.** `sysinfo` reports the **host's** CPU count. A workload
confined by `cpuset` or a CFS quota (`cpu.max`, `--cpus`) can have 2 CPUs of effective capacity while `CPUs`
reads `64` in both runs. **Two runs with completely different effective CPU budgets will not fire this rule**,
and aperf collects no cgroup data at all. Conversely, `cpu_utilization` percentages will look small and
confusing because they are computed against the host's full capacity. This is the one case where the absence of
this finding is actively misleading.

**The "key missing" branch is a different problem at the same score.** If the key is absent from the compared
run, the template emits a different sentence — "The key CPUs does not exist in …" — with the same −256. For
`CPUs` that means `systeminfo` collection failed, not that the hardware differs. If the key is missing from the
*base* run, the rule **returns early and produces nothing**, so silence is not proof of a match.

## Reading the description

`key_value_key_run_comparison` emits one of two descriptions.

**Values differ:**

```
The value of {key} in {run} ("{value}") is different from {base_run} ("{base_value}").
```

Concretely:

```
The value of CPUs in aperf_record_new ("16") is different from aperf_record_base ("64").
```

**Key missing from the compared run:**

```
The key CPUs does not exist in aperf_record_new, while its value in aperf_record_base is "64".
```

Five things to know:

1. **The counts are quoted strings** because the value is stored as text. `"16"` is 16 logical CPUs.
2. **The description is the complete evidence.** Both counts appear verbatim; nothing is formatted or truncated.
3. **There is no ratio, no percentage, and no direction** in the finding itself. Compute the ratio yourself — it
   is the number that matters and the score does not contain it.
4. **The score is flat −256.** This template inserts the rule's score directly; **`compute_finding_score` is
   never called, so no score table applies.** 4-versus-8 and 4-versus-96 are indistinguishable by score.
5. **A missing key produces the second sentence form** at the same severity — a collection failure, not a
   hardware difference.

**How to read the two counts:**

| Relationship | Example | Likely cause |
|---|---|---|
| **Exact power-of-two multiple** | 16 → 32, 8 → 64 | **Different instance size.** Expect `Inconsistent Physical Memory` too |
| **Same count, different `Instance Type`** | rule silent | **Not caught by this rule** — check `Instance Type` for an architecture or family change |
| **Small non-power-of-two difference** | 63 → 64, 30 → 32 | **Offline CPU, `maxcpus=`/`nr_cpus=`, or isolation** on identical hardware. Fix the host image |
| **Factor of 2 with same `Instance Type`** | 32 → 64 on the same type | SMT disabled in one run (`nosmt`, or SMT off in the AMI), or half the CPUs offline |
| One count is `0` or absurd | — | Collection problem; treat as a data-integrity issue |

## Interpretation

**First, settle whether the hardware differs:**

| Evidence | Reading |
|---|---|
| **`Instance Type` differs** | **Different machines.** The clearest resolution. Nothing else needs establishing — re-run on matched instances |
| `Instance Type` identical, counts differ | **Same hardware, different visible CPUs** — offline CPUs, `maxcpus=`/`nr_cpus=`, `nosmt`, or isolation. A host-image defect, not a hardware mismatch |
| `AMI ID` differs | Likely the source of a boot-parameter or SMT difference |
| `Instance ID` differs | Different physical instances — expected in most comparisons, but relevant if they should have been the same host |
| **The "key does not exist" form** | **A collection failure**, not a hardware difference |

**Then check the coupled differences — this is where the damage is:**

| Also fired / observed | Reading |
|---|---|
| **`Inconsistent Physical Memory`** | **Confirms an instance-size change.** Memory and vCPU scale together. The comparison is not salvageable |
| **Any `ena_stat` allowance finding** (`bw_in/out_allowance_exceeded`, `pps_allowance_exceeded`, `conntrack_allowance_exceeded`) | **The ceilings themselves differ between the runs.** A throttle on the smaller instance is an artifact of size, not a workload property |
| `Inconsistent Inbound/Outbound Network Traffic` | Expected: different sizes have different bandwidth. **Not a load-generator problem** |
| `Kernel Version Mismatch` | A second, independent confound. Two variables at once |
| `Underutilized CPU` | **Meaningless across different core counts** — the aggregate percentage has a different denominator. Fix this first |
| High `system` or `softirq` CPU on one run | Interrupt and softirq work spreads across a different number of CPUs |
| `perf_stat` cache or TLB rules | Cache sizes scale with instance size; those findings are unreliable |
| `processes` top-16 differs structurally | Thread pools sized to `nproc` behave differently |
| Statistical (delta-vs-base) findings | **All of them compare different-sized machines** |

**Then judge scaling behaviour — the substantive question hiding behind the artifact:**

| Observation | Reading |
|---|---|
| Larger run shows **lower** aggregate utilization at the same throughput | Expected: same work spread over more CPUs. Not an improvement |
| Larger run shows **the same throughput** as the smaller one | **The workload does not scale.** A genuine finding — but establish it deliberately, not by accident |
| Larger run shows **higher** `system` CPU per unit work | Contention or lock scaling problems that appear only at higher core counts |
| Smaller run hits a network or EBS allowance | The ceiling, not the code, limited it |

**Known false positives — none in the strict sense.** The rule reports an exact, verified fact. What varies is
whether it was intended:

- **A deliberate scaling experiment** — comparing two sizes on purpose. The finding is correct and is confirming
  your independent variable; read absolute values per run rather than deltas.
- **A stale or mis-selected base run** captured on a different instance size. Cheapest thing to rule out.
- **Fleet autoscaling or a spot-capacity substitution** handing you a different size than requested.
- **An offline CPU** on otherwise identical hardware — a real difference, but a host-configuration one.

**Three blind spots, all of which make silence misleading:**

- **Container and cgroup CPU limits are invisible.** `cpuset`/`cpu.max` restrictions do not change `CPUs`, so
  two runs with wildly different effective CPU budgets fire nothing. **aperf collects no cgroup data.**
- **Equal counts can mean unequal compute.** 16 vCPUs of x86 (8 physical cores, SMT) versus 16 vCPUs of Graviton
  (16 physical cores) fires nothing. `Instance Type` is the only field that catches it.
- **A base run missing the key suppresses the rule entirely** — the template returns early with `debug!`.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`Instance Type`** | `systeminfo` | **Do this first.** Settles hardware-difference versus host-configuration difference in one look, and catches equal-count/unequal-compute cases this rule misses |
| **`AMI ID`** | `systeminfo` | Boot-parameter, SMT, and kernel differences usually track the image |
| `Instance ID`, `Hostname`, `Region` | `systeminfo` | Whether the runs are from different instances at all |
| **`Kernel Version` / `Kernel Version Mismatch`** | `systeminfo` | A second confound; also the source of `nosmt`/`maxcpus=` differences |
| **`MemTotal` / `Inconsistent Physical Memory`** | `meminfo` | **Confirms an instance-size change** — memory and vCPU scale together on EC2 |
| **`aggregate`, `idle`, `system`, `softirq`, `user`, per-CPU series** | `cpu_utilization` | **The series *count* differs between runs.** Aggregate percentages have different denominators — every comparison here is invalid |
| `Underutilized CPU` and other `cpu_utilization` findings | `cpu_utilization` | **Discount all of them** until CPU counts match |
| Instructions, cycles, IPC, cache and TLB counters | `perf_stat` | Sums scale with core count; cache sizes scale with instance size |
| **All allowance counters** (`bw_in/out_allowance_exceeded`, `pps_allowance_exceeded`, `conntrack_allowance_exceeded`, `linklocal_allowance_exceeded`) | `ena_stat` | **The ceilings differ between the runs.** Throttling on the smaller instance is a size artifact |
| Per-queue `rx_bytes`/`tx_bytes` series count | `ena_stat` | Queue count tracks vCPU count, so the series sets differ |
| `IpExt:InOctets`, `IpExt:OutOctets` | `netstat` | Traffic differences explained by bandwidth allowance, not the harness |
| Per-CPU interrupt counts | `interrupts` | **One series per CPU** — the series sets differ structurally. **No analytical rules — read manually** |
| Top-16 by CPU and memory | `processes` | Thread pools sized to `nproc` behave differently. **No analytical rules — read manually** |
| NUMA node layout and distances | `numastat` | Larger instances have more NUMA nodes, changing memory locality. **No analytical rules — read manually** |
| `kernel.sched_*`, isolation and affinity settings | `sysctl` | Scheduler tuning that varies with core count. **No analytical rules — read manually** |
| Kernel command line (`maxcpus=`, `nr_cpus=`, `nosmt`, `isolcpus=`) | out of band | **Not collected by aperf** — the usual explanation for a non-power-of-two difference |
| Offline CPU state (`/sys/devices/system/cpu/*/online`) | out of band | Not collected. Explains identical-hardware differences |
| cgroup/container CPU limits (`cpuset`, `cpu.max`) | out of band | **Not collected, and invisible to this rule.** Different effective budgets fire nothing |
| Thread-pool and concurrency configuration | out of band | Whether the application sized itself to `nproc` |

## Guidance

Ordered. **Steps 1–3 close essentially every firing.**

1. **Read `Instance Type` for both runs.** If it differs, the machines differ and the investigation is over —
   re-run on matched instances. If it is identical while `CPUs` differs, this is a **host-configuration
   difference** (offline CPUs, `maxcpus=`/`nr_cpus=`, `nosmt`, isolation), which is a host-image defect to fix
   rather than a hardware mismatch.

2. **Compute the ratio yourself.** The score is flat −256 and carries no magnitude. An exact power-of-two
   multiple points at an instance-size change; a small non-power-of-two difference (63 vs 64) points at an
   offline CPU or a boot parameter.

3. **Confirm the base run is the one you meant, and that its `systeminfo` is populated.** A stale base run from a
   different instance size is the most common cause; a base run missing the key suppresses the rule entirely, so
   silence proves nothing.

4. **Discount every `cpu_utilization` finding immediately.** Aggregate utilization is a percentage of a different
   denominator in each run — `Underutilized CPU` in particular is not interpretable across different core counts.
   The per-CPU series sets differ too, so the graphs are not visually comparable either.

5. **Re-examine every network and storage conclusion.** Instance size sets bandwidth, PPS, and connection-tracking
   allowances. **A throttle counter firing on the smaller instance is an artifact of size, not a property of the
   workload** — and per aperf's own network guidance, IO bottlenecks mask CPU gains, so the CPU findings are
   suspect too.

6. **Check for coupled findings and treat them as one story.** `Inconsistent Physical Memory` alongside this
   confirms an instance-size change. `Kernel Version Mismatch` adds an independent second variable.

7. **If the size difference was deliberate, read the report as a scaling study.** Compare absolute throughput per
   run, not deltas: same throughput at 4× the vCPUs is a real and important finding about scaling — but establish
   it on purpose, with the confounds acknowledged.

8. **If it was not deliberate, pin the instance type and re-run.** No analysis recovers a valid code comparison
   across different core counts.

9. **Verify cgroup and container CPU limits out of band.** This is the case where *absence* of the finding
   misleads: `cpuset`/`cpu.max` restrictions are invisible here, so two runs with different effective CPU budgets
   fire nothing while `cpu_utilization` percentages look small and confusing.

10. **Beware equal counts with unequal compute.** 16 x86 vCPUs (8 physical cores with SMT) versus 16 Graviton
    vCPUs (16 physical cores) fires nothing here. `Instance Type` is the only field that catches it, and
    `perf_stat` counters are not comparable across architectures at all.

## Priority and execution risk

**Priority: P0 — Blocking.** This is the most fatal gate in the tree. vCPU count sets the parallelism ceiling,
the per-vCPU network and EBS allowances, the JVM/CLR GC ergonomics, and the denominator of every aggregate
utilization percentage. No analysis recovers a clean comparison across differing vCPU counts.

**Execution risk: R4 — Infrastructure change.** The remediation is to re-run on matched instances. There is no
R0–R3 path; nothing about the workload can be tuned to make the comparison valid.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: the finding fired, i.e. the `CPUs` strings are not byte-identical.

```
STEP 1 — Was this deliberate?
  IF you are intentionally testing scale-up/scale-down
  THEN → the finding is confirming your independent variable (P4, R0)
       → read the report as a SCALING study; see STEP 5 for what is legitimately comparable
  ELSE continue.

STEP 2 — Parse both values from the description.
  Format: The value of CPUs in {run} ("{n}") is different from {base} ("{m}").
  Compute ratio = n / m. The score gives you NOTHING here: it is a flat -256
  whether the ratio is 1.03 or 64.

  IF the description is instead:
     The key CPUs does not exist in {run}, while its value in {base} is "{m}".
  THEN → systeminfo collection failed in the compared run, not a hardware change (P1, R0)
       → verify: check whether ANY systeminfo key is present for that run
       → this is a collection defect, not a capacity difference

STEP 3 — Is the ratio a recognisable instance-size step?
  IF ratio is exactly 2, 4, 8, ... (or 1/2, 1/4, ...)
  THEN → a size change within a family (large -> xlarge -> 2xlarge) (P0, R4)
       → expect throughput to scale sub-linearly and per-unit metrics to shift
       → verify: re-record at MATCHED size. This gate must stop firing before any
         cross-run number is read; there is no correction factor that recovers a
         comparison across a changed denominator
  IF ratio is NOT a power of two (e.g. 16 vs 12, 96 vs 64)
  THEN → likely a FAMILY change, not a size change (P0, R4)
       → check `Instance Type` manually — architecture may differ silently
       → verify: STEP 4. Confirm family and architecture from `Instance Type`
         before re-recording, since matching vCPU count alone does not make two
         different families comparable
  IF ratio is very close to 1 (e.g. 64 vs 63)
  THEN → suspect CPU offlining, isolation, or a boot parameter (`nr_cpus`, `maxcpus`,
         `isolcpus`), not a different instance (P1, R1)
       → verify: check per-CPU series in `cpu_utilization` — an offlined CPU is absent,
         an isolated one is present but idle. aperf does not collect the kernel cmdline.

STEP 4 — MANDATORY manual check: `Instance Type`.
  aperf collects it and NO rule compares it.
  IF `Instance Type` differs in family or suffix (m6i -> m7g)
  THEN → architecture likely differs. STOP: perf_stat counters are incomparable
         in MEANING, not just value (P0, R4)
  IF `Instance Type` is IDENTICAL but CPUs differ
  THEN → the same instance type reported different vCPU counts: container/cgroup
         confusion, CPU hotplug, or a boot-parameter difference (P1, R1)
       → note aperf reads HOST-level /proc, so a cgroup-capped container still
         reports the host's CPUs; a differing count means the HOST differed
       → verify: after removing the offlining or boot parameter, `CPUs` should
         match and this gate should stop firing. Confirm in `cpu_utilization` that
         the per-CPU series count now matches between runs — that is the direct
         evidence, since `CPUs` is a single static key

STEP 5 — What survives, if the change was intended (scaling study)?
  VALID    : configuration findings (THP, ENA Express state, tiered compilation),
             per-unit efficiency (IPC, cache miss RATES), saturation flags
  VOID     : all aggregate cpu_utilization findings (the denominator changed),
             absolute counter comparisons, the entire statistical findings table
             for rates, ENA allowance comparisons (per-vCPU ceilings changed)
  CAUTION  : `Underutilized CPU` on the larger instance is EXPECTED if the workload
             did not scale out — that is the finding you are looking for, not noise

INSUFFICIENT DATA
  IF the base run has no `CPUs` key
  THEN → the rule returned early and produced NO finding at all.
         Silence here is not parity (P1, R0)
```

## Runtime-specific consequences

A vCPU change is not neutral for any of the four target runtimes — each derives defaults from the core count,
so the *same* application behaves differently without any code or config change:

| Runtime | What auto-scales with vCPU count | Consequence for the comparison |
|---|---|---|
| **Java** | GC thread counts (`ParallelGCThreads` ≈ f(vCPU)), `ForkJoinPool.commonPool` parallelism (vCPU−1), default heap ergonomics | GC behaviour differs between runs; a "GC regression" may be pure ergonomics (P1, R2 to pin) |
| **.NET** | Server GC heap count = vCPU by default, `ThreadPool` min/max threads, `DOTNET_GCHeapCount` | Server GC on 4 vs 64 vCPU is a different allocator; pin `DOTNET_GCHeapCount` to compare (P1, R2) |
| **Python** | Nothing automatic — the GIL means one interpreter uses ~1 core. `multiprocessing.cpu_count()` drives *user* code | Throughput changes only if the app spawns per-CPU workers; if not, extra vCPUs are simply idle (expect `Underutilized CPU`) |
| **Perl** | Nothing automatic. Preforking servers size worker pools from config, not core count | Usually the least affected; a vCPU change alone often produces no throughput change at all |

**Pin the runtime's parallelism explicitly before any cross-size comparison** — otherwise you are comparing two
different allocator and thread-pool configurations, not two runs of the same program. For Java and .NET this is
the single highest-value preparation step (both R2: restart required, fully revertible).

## Architecture-specific considerations

A vCPU change and an architecture change are frequently the *same* change, and this gate only sees the first
half of it. Check `pmu_config.json` in both run directories before concluding anything
([ARCHITECTURE.md](../ARCHITECTURE.md) §1).

**The dangerous case is when this finding does NOT fire.** `m6i.4xlarge` → `m7g.4xlarge` keeps `CPUs` at 16 and
crosses from x86_64 to aarch64. No gate fires at all, yet every `perf_stat` metric changed meaning and two
findings (`High Code Sparsity`, `Old-Style Atomic Instructions`) become available on only one side.

**When this finding DOES fire, read the vCPU ratio together with the architecture:**

| Observed | Reading | Action |
|---|---|---|
| Ratio is a power of two, architecture matches | Straight resize within a family | Standard size-change reading (P0, R4) |
| Ratio is a power of two, **architecture differs** | Family *and* size changed | Two confounded variables. Re-run matched; do not attempt to separate them analytically (P0, R4) |
| Ratio ≈ 1 but not 1, architecture matches | CPU offlining, `isolcpus`, or hotplug | Host-level; check the kernel command line manually (P1, R4) |
| `CPUs` differ **and** one run has no `pmu_config.json` | PMU collection failed on one side — possibly an unrecognised CPU (`bail!`) | All 15 `perf_stat` findings are one-sided (P1, R0) |

**SMT/threads-per-core is the sizing subtlety this gate cannot express.** `CPUs` is `sysinfo`'s
`sys.cpus().len()` (`src/data/systeminfo.rs:125`) — a count of logical CPUs. On Intel and AMD with SMT enabled
that is 2× the physical cores; **Graviton has no SMT**, so one vCPU is one physical core. A 16-vCPU x86 instance
and a 16-vCPU Graviton instance therefore have **8 vs 16 physical cores**. The counts match, this gate stays
silent, and per-core throughput expectations are entirely different. This is the single most common source of
surprise in x86→arm64 migration comparisons.

Per-runtime consequence: every vCPU-derived default in the table above is derived from the *logical* count, so
Java's `ParallelGCThreads` and .NET's Server GC heap count land on 16 in both cases while the underlying
physical parallelism differs by 2×.

## Verification

Re-run on matched instance types and confirm this finding disappears. If it persists with identical
`Instance Type`, the difference is host-level (hotplug, boot parameters, offlining) and aperf cannot see the
cause — check the kernel command line manually, which aperf does not collect.

## Do not

- **Do not read the score as magnitude.** Flat −256: 4-versus-8 scores the same as 4-versus-96. The counts are in
  the description.
- **Do not compare aggregate CPU utilization across different core counts.** The denominator differs; the
  percentages are not the same quantity.
- **Do not trust any `cpu_utilization` finding** — `Underutilized CPU` included — while the counts differ.
- **Do not treat a network or throttle difference as a workload property.** Allowances scale with instance size.
- **Do not sum or compare `perf_stat` counters directly.** They scale with core count, and cache sizes scale with
  instance size.
- **Do not assume a small difference means a small change.** 63 versus 64 is usually an offline CPU or boot
  parameter — a configuration defect worth fixing precisely.
- **Do not assume equal `CPUs` means equal compute.** SMT and architecture differences are invisible here; check
  `Instance Type`.
- **Do not treat absence of this finding as proof of equal CPU capacity.** cgroup and `cpuset` limits are not
  collected, and a base run missing the key suppresses the rule.
- **Do not attribute scaling behaviour to the code by accident.** If you want a scaling study, run one
  deliberately.
- **Do not try to normalize the comparison analytically.** Match the instance type and re-run.

## References

- Rule definition: `src/analytics/rules/systeminfo.rs:18` — `key: "CPUs"`, `score: Score::Critical`. (Note the
  rule name uses lowercase "of": `"Inconsistent Number of CPUs"`.)
- Rule template: `src/analytics/rule_templates/key_value_key_run_comparison_rule.rs` — exact
  `value != base_value` string comparison; skips the base run; **returns early with `debug!` if the base run
  lacks the key**; emits a second description form when the key is absent from the compared run; **inserts
  `self.score` directly — no `compute_finding_score` call, so the score is flat**.
- Score: `Score::Critical = −256`, `src/analytics/mod.rs:147`.
- Key lookup: `key_value_value_by_key` → `lookup_key_value`,
  `src/data/common/processed_data_accessor.rs:157` and `:571` — scans all key-value groups, first match wins.
- Collection: `src/data/systeminfo.rs:125` — `set_total_cpus(sys.cpus().len())` from the `sysinfo` crate
  (`sysinfo 0.26`), i.e. **logical** CPUs as seen by the OS, stored via `total_cpus.to_string()` under the key
  `"CPUs"`; `is_static() == true`, collected once per run. Other keys in the same group: `System Name`,
  `OS Version`, `Kernel Version`, `Hostname`, `Instance ID`, `Region`, `Instance Type`, `AMI ID`,
  `Local Hostname`. EC2 metadata comes from IMDS and falls back to `"N/A"` on failure
  (`src/data/systeminfo.rs:131`).
- Frontend context: `systeminfo` is the report home page — `data-descriptions.ts:74`.
- `cpu_utilization` aggregate semantics: `data-descriptions.ts:102` — "The aggregate series represents the total
  CPU utilization", and its statistics account for the aggregate series
  (`src/data/common/time_series_data_processor.rs`, `stats_series_idx`).
- Related playbooks: `kernel-version-mismatch.md`, `../meminfo/inconsistent-physical-memory.md`,
  `../cpu_utilization/underutilized-cpu.md`, `../ena_stat/inbound-bandwidth-allowance-exceeded.md`,
  `../ena_stat/outbound-bandwidth-allowance-exceeded.md`, `../ena_stat/pps-allowance-exceeded.md`,
  `../netstat/inconsistent-inbound-network-traffic.md`,
  `../netstat/inconsistent-outbound-network-traffic.md`, `../statistical/README.md`.
- [Amazon EC2 instance types](https://aws.amazon.com/ec2/instance-types/)
- [Graviton perfrunbook — system load and compute headroom](https://aws.github.io/graviton/perfrunbook/system-load-and-compute-headroom.html)
