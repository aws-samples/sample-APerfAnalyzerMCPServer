---
rule_name: Kernel Version Mismatch
data_type: systeminfo
data_key: Kernel Version
template: key_value_key_run_comparison
condition: "value != base_run value"
base_score: Critical
score_sign: negative
requires_comparison: true
aperf_message: "Kernel Versions between runs are different. Make sure the difference is intended."
source: src/analytics/rules/systeminfo.rs:12
---

# Kernel Version Mismatch

## What fired

The `Kernel Version` string in this run is **not byte-for-byte identical** to the base run's. This is an exact
string comparison (`value != base_value`) — **not** a semantic version comparison. Any difference at all fires:
a different major version, a different patch level, a different build number, a different distro suffix, or a
different architecture tag.

Base score `Critical` (**−256**), the most severe score aperf defines. **The score is flat: −256 regardless of
how large the version difference is.** Comparison-only.

**This is a validity gate, not a performance finding.** It does not say either kernel is worse. It says the two
runs ran on **different kernels**, so every delta in the report has at least two candidate explanations — the
code under test, and the kernel.

## Reasoning

**Why a kernel difference earns `Critical` while a 20% traffic difference earns only `Bad`.** The kernel
mediates every metric aperf collects. A version change can alter, simultaneously and invisibly:

- **The scheduler** — CFS versus EEVDF (6.6), preemption model defaults (**7.0 defaults to PREEMPT_LAZY**),
  wakeup and load-balancing heuristics. Changes `cpu_utilization`, context-switch rates, and tail latency.
- **Memory management** — THP defaults and collapse behaviour, reclaim heuristics, folio/large-folio support,
  `MemAvailable` estimation. Changes `vmstat` fault rates, `meminfo`, and page-cache behaviour.
- **The network stack** — congestion control defaults, GRO/LRO behaviour, socket buffer autotuning, new
  `TcpExt:*` counters appearing or disappearing. Changes `netstat` entirely.
- **The counters themselves** — `/proc/vmstat`, `/proc/net/netstat`, and `/proc/meminfo` gain and lose fields
  between versions. **A metric present in one run and absent in the other is not a workload difference**, and
  aperf's per-metric comparison rules will simply not fire rather than telling you the metric vanished.
- **Mitigations and microarchitectural workarounds** — a new Spectre/Meltdown-class mitigation can cost
  single-digit percentages of syscall throughput with no code change, and shows up in `perf_stat` as changed
  instruction counts and branch behaviour.

So a kernel mismatch does not invalidate one metric; **it makes the entire report ambiguous.** That is the
justification for the top score, and it is why the message says "Make sure the difference is intended" rather
than naming a fix — aperf cannot know which kernel you meant to test.

**Why exact string comparison is the right implementation, and its consequence.** The rule cannot know which
parts of a kernel version string are performance-relevant, so it treats any difference as significant. That is
conservative in the correct direction: a false positive costs you one glance at `systeminfo`, whereas a missed
kernel difference silently corrupts a conclusion. **The consequence is that trivially different strings fire at
full severity.** `6.12.94-123.190.amzn2023.x86_64` versus `6.12.94-123.191.amzn2023.x86_64` — an Amazon Linux
patch bump with no scheduler or MM changes — scores exactly the same −256 as `5.10` versus `7.0`. **The score
carries no information about magnitude; you must read the strings.**

**The version string is whatever `sysinfo` returns, which is not always what you expect.** aperf collects it via
the `sysinfo` crate's `kernel_version()`. On Linux that is the release string (as from `uname -r`), which mixes
several independent things: upstream version, distro patch level, build number, distro tag, and architecture. A
difference in *any* of those fires the rule. In particular, **`amzn2023` versus `amzn2` in the suffix means a
different distribution**, which usually implies a different glibc, compiler, and default tunables — a much
bigger change than the version numbers alone suggest, and one worth noticing.

**The kernel-7.0 preemption change is the specific, documented performance trap, and aperf knows about it.**
Linux 7.0 changed the default preemption model to `PREEMPT_LAZY`. aperf has a dedicated multi-data rule for
exactly this: `PREEMPT_LAZY Detected` fires when the kernel major version is ≥ 7 **and**
`CONFIG_PREEMPT_LAZY == "y"`. **If one run is on 7.x and the other is not, check whether that rule fired on the
7.x run** — it names a concrete, actionable difference (`preempt=none` boot parameter, `CONFIG_PREEMPT_NONE=y`,
or `rseq` in hot functions) that the mismatch finding alone does not. That pairing is the single most useful
follow-up when a major-version boundary is crossed.

**The "key missing" branch is a distinct failure with the same score.** The template has two paths. If the key
exists in both runs and the values differ, you get the "is different from" description. **If the key is absent
from the compared run entirely, you get a different description — "The key … does not exist in …" — and the same
−256.** For `Kernel Version` that means `systeminfo` collection failed or the file was truncated, which is a
data-integrity problem, not a hardware one. If the key is missing from the *base* run, the rule returns early
with a `debug!` and **produces no finding at all** — so silence does not prove the versions match.

**Cross-run lookup detail worth knowing.** `lookup_key_value` scans **all** key-value groups and returns the
first match. `systeminfo` puts everything in a single unnamed group, so there is no ambiguity today — but the
lookup is order-dependent across a `HashMap` of groups, so a future multi-group layout could make the match
non-deterministic. Not a live defect; worth knowing before relying on the mechanism.

## Reading the description

`key_value_key_run_comparison` emits one of two descriptions.

**Values differ:**

```
The value of {key} in {run} ("{value}") is different from {base_run} ("{base_value}").
```

Concretely:

```
The value of Kernel Version in aperf_record_new ("6.12.94-123.191.amzn2023.x86_64") is different from aperf_record_base ("6.12.94-123.190.amzn2023.x86_64").
```

**Key missing from the compared run:**

```
The key {key} does not exist in {run}, while its value in {base_run} is "{base_value}".
```

Five things to know:

1. **Both full version strings appear verbatim, quoted.** Unlike the time-series templates, nothing is
   truncated, formatted, or summarized. **The description is the complete evidence** — you rarely need to open
   `systeminfo` to know what changed.
2. **There is no numeric comparison, no percentage, and no direction.** The template does not know which version
   is newer. `7.0` versus `5.10` and `…190` versus `…191` produce structurally identical descriptions.
3. **The score is flat −256** — there is no `compute_finding_score` call in this template at all; the rule's
   score is inserted directly. **No score table applies to this rule.** Nothing about the magnitude of the
   version difference reaches the score.
4. **A missing key produces a different sentence at the same severity.** Read which of the two forms you got:
   one means "different kernels", the other means "collection failed".
5. **The finding is keyed on `Kernel Version`** and appears under that key.

**How to read the two strings — the diff position tells you the magnitude:**

| Position of the difference | Example | Likely significance |
|---|---|---|
| **Major version** | `6.12.x` → `7.0.x` | **Largest.** Scheduler, preemption default (`PREEMPT_LAZY`), MM changes. **Check `PREEMPT_LAZY Detected`** |
| **Minor version** | `6.6.x` → `6.12.x` | Substantial — scheduler and MM evolve across minors (EEVDF landed in 6.6) |
| Upstream patch level | `6.12.94` → `6.12.97` | Usually small: backports and fixes. Occasionally a mitigation |
| **Distro build number** | `-123.190` → `-123.191` | Usually trivial, but **distro builds carry config changes**, which are invisible here — check `kernel_config` |
| **Distro tag** | `amzn2` → `amzn2023` | **Large in practice.** Different distribution: different glibc, compiler, defaults |
| Architecture tag | `x86_64` → `aarch64` | **Different CPU architecture entirely.** Nothing in the report is comparable |

## Interpretation

**First, read the two strings and locate the difference:**

| Observation | Reading |
|---|---|
| **Architecture tag differs** (`x86_64` vs `aarch64`) | **Different CPU architecture.** No metric in the report is comparable — `perf_stat` counters differ in meaning, not just value. Stop; this is not a valid comparison |
| **Distro tag differs** (`amzn2` vs `amzn2023`) | **Different distribution.** glibc, toolchain, and default tunables all differ. Much bigger than the numbers suggest |
| **Major version boundary crossed** | Scheduler and MM defaults changed. **If either run is 7.x, check `PREEMPT_LAZY Detected`** |
| Minor version differs | Real behavioural changes likely (e.g. EEVDF at 6.6). Treat as significant |
| **Only the distro build number differs** | **Usually trivial** — but distro builds can change `kernel_config`. Verify there rather than assuming |
| Only the upstream patch level differs | Usually backports. Check for a new mitigation if the delta is unexplained |
| The **"key does not exist"** form | **A collection failure, not a kernel difference.** `systeminfo` did not produce the key in that run |

**Then check what the version difference plausibly explains:**

| Also observed | Reading |
|---|---|
| **`PREEMPT_LAZY Detected` on the 7.x run** | **A concrete, named, actionable cause.** aperf is telling you which kernel change to test — `preempt=none`, `CONFIG_PREEMPT_NONE=y`, or `rseq`. **The highest-value follow-up** |
| `Huge Page Disabled` on one run only | THP configuration differs with the kernel build. Explains `vmstat` fault-rate deltas outright |
| Unexplained `cpu_utilization` shifts (esp. `system`) | Scheduler and syscall-path changes land here first |
| Unexplained `vmstat` fault or reclaim deltas | MM heuristics and THP behaviour changed |
| Unexplained `netstat` deltas | Congestion control defaults, autotuning, and offload behaviour changed |
| **A metric present in one run, absent in the other** | **Counter added or removed between kernel versions.** Not a workload difference — and the per-metric rules stay silent rather than reporting it |
| `perf_stat` instruction/branch count shifts with no code change | Mitigations, or a different kernel text layout |
| `Inconsistent Number of CPUs` also fired | **Different hardware too.** Now at least two confounds; the comparison is not salvageable |
| `Inconsistent Physical Memory` also fired | Same — different machines *and* different kernels |
| `JVM Version Comparison` also fired | A third variable. Multiple simultaneous confounds |
| Statistical (delta-vs-base) findings across the board | **All of them are ambiguous** while the kernels differ |

**Known false positives — in the strict sense, none.** The rule reports a real, exactly verified fact. What
varies is whether it is *material*:

- **A distro patch bump** (`-123.190` → `-123.191`) with no relevant change: correct finding, negligible impact,
  yet scored −256.
- **A deliberate kernel A/B test** — the finding is exactly what you wanted; it confirms the variable you set.
- **Comparing against a stale base run** captured before a routine host update. The cheapest thing to rule out.
- **The wrong base run selected.**
- **Automated patching between runs** on hosts with unattended upgrades — common and easy to overlook.

**Two genuine blind spots:**

- **The rule cannot fire if the base run lacks the key.** The template returns early with `debug!`. **Silence
  does not prove the kernels match** — verify `systeminfo` is populated in the base run.
- **Identical version strings do not mean identical kernels.** Boot parameters, `sysctl` values, and kernel
  config can all differ under the same release string. `preempt=none`, `mitigations=off`, THP mode, and
  `transparent_hugepage=never` are all invisible to this rule. **`kernel_config` and `sysctl` are where those
  live** — and aperf does not collect the kernel command line at all.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **The two version strings in the description** | `systeminfo` | **The complete evidence.** Locate the diff position to judge magnitude |
| **`Instance Type`, `CPUs`, `AMI ID`, `Instance ID`, `Region`** | `systeminfo` | Whether the hardware and image also differ. **`AMI ID` differing usually explains the kernel difference** |
| `System Name`, `OS Version` | `systeminfo` | Distribution and OS release — confirms an `amzn2` → `amzn2023` class change |
| `Hostname`, `Local Hostname` | `systeminfo` | Whether the runs are even from the same host |
| **`Inconsistent Number of CPUs`** | `systeminfo` | A second confound; different hardware as well as different kernel |
| `Inconsistent Physical Memory` | `meminfo` | Same — different machines *and* kernels |
| **`PREEMPT_LAZY Detected`** | `kernel_config` | **The one named, actionable kernel-change explanation aperf offers.** Fires at kernel ≥ 7 with `CONFIG_PREEMPT_LAZY=y` |
| **`CONFIG_PREEMPT*`, `CONFIG_TRANSPARENT_HUGEPAGE`, `CONFIG_HZ`, scheduler and mitigation configs** | `kernel_config` | **Where identical version strings can still differ.** Also where a distro build bump shows its real content |
| `Huge Page Disabled` | `kernel_config` | THP availability differing between builds explains `vmstat` deltas |
| `vm.*`, `kernel.sched_*`, `net.ipv4.tcp_*` tunables | `sysctl` | Runtime differences the version string cannot show. **No analytical rules — read manually** |
| Kernel command line (`preempt=`, `mitigations=`, `transparent_hugepage=`) | out of band | **Not collected by aperf.** A major invisible variable |
| `system`, `user`, `softirq`, `steal`, `aggregate` | `cpu_utilization` | Where scheduler and syscall-path changes surface first |
| `pgfault`, `pgmajfault`, `thp_*`, `pgsteal_*` | `vmstat` | MM and THP behaviour changes |
| **Metric presence/absence between runs** | `vmstat`, `netstat` | **Counters appear and disappear between kernel versions.** Missing metrics are not workload changes |
| `IpExt:*`, `TcpExt:*` | `netstat` | Congestion control, autotuning, and offload defaults |
| Instructions, branches, cache counters | `perf_stat` | Mitigation and kernel-layout effects with no code change |
| `JVM Version Comparison`, `jvmVersion` | `java_profile` | Whether a third variable is also in play |
| Statistical findings table | frontend | **All entries are ambiguous** while the kernels differ |

## Guidance

Ordered. **Steps 1–3 close essentially every firing.**

1. **Read the two version strings in the description and locate where they differ.** That position — major,
   minor, patch, distro build, distro tag, architecture — is the entire magnitude judgement, and the score
   provides none of it. **An architecture difference means stop: nothing in the report is comparable.**

2. **Confirm the base run is the one you meant.** A stale base run captured before a routine host patch, or the
   wrong base selected, is the most common cause. Also confirm the base run's `systeminfo` is populated — if the
   key is missing there, the rule cannot fire at all, so silence proves nothing.

3. **If the difference is a distro patch bump only, verify rather than assume it is harmless.** Distro builds
   carry configuration changes that this rule cannot see: check `kernel_config` for `CONFIG_PREEMPT*`,
   `CONFIG_TRANSPARENT_HUGEPAGE`, `CONFIG_HZ`, and mitigation settings.

4. **If a major-version boundary was crossed, check `PREEMPT_LAZY Detected`.** Linux 7.0 changed the default
   preemption model, and that rule fires precisely when the kernel is ≥ 7 with `CONFIG_PREEMPT_LAZY=y`. **It is
   the only kernel-change explanation aperf names concretely**, with three specific remedies: `preempt=none` as
   a boot parameter, `CONFIG_PREEMPT_NONE=y`, or `rseq` in the application's hot functions.

5. **Check `AMI ID` in `systeminfo`.** A differing AMI usually *is* the reason the kernels differ, and it tells
   you the fix is an image pin rather than anything about the workload.

6. **Treat every other delta as ambiguous until the kernels match.** Do not attribute `cpu_utilization`,
   `vmstat`, `netstat`, or `perf_stat` deltas to the code under test. This includes the entire statistical
   findings table.

7. **Check for metrics that exist in only one run.** Kernel versions add and remove `/proc` counters. aperf's
   per-metric rules simply do not fire on a missing metric, so a vanished counter looks like silence rather than
   a change.

8. **If the difference was deliberate — an intentional kernel A/B — record it and read the report as a kernel
   comparison, not a code comparison.** The finding is confirming your independent variable. Every delta is then
   *attributable to the kernel*, which is the opposite of the usual reading.

9. **If it was not deliberate, pin the kernel and re-run.** Match the AMI, disable unattended upgrades for the
   test window, and re-generate. There is no analysis that recovers a clean code comparison across kernels.

10. **Remember that identical version strings do not mean identical kernels.** Boot parameters, `sysctl`, and
    kernel config can all differ silently. If the runs *should* match and an unexplained delta persists, check
    `kernel_config` and `sysctl` — and the kernel command line, which aperf does not collect.

## Priority and execution risk

**Priority: P0 — Blocking** for attributing anything to application code. **P1** when the kernel change *is* the
independent variable, in which case the finding is confirming your experiment.

**Execution risk: R4 — Infrastructure change** (pin the AMI, disable unattended upgrades, re-run). Any
*remediation* the kernel difference suggests — preemption model, THP, mitigations — is **R5 —
behaviour-changing** and must be validated, not just applied.

**The score is flat −256** regardless of how large the version gap is. All magnitude information is in the
strings.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: the `Kernel Version` strings are not byte-identical.

```
STEP 1 — Locate the FIRST differing component. This is the whole magnitude judgement.
  Parse both strings, e.g. 6.12.94-123.190.amzn2023.x86_64
                          │ │  │   │       │        └─ architecture
                          │ │  │   │       └─ distro tag
                          │ │  │   └─ distro build
                          │ │  └─ patch
                          │ └─ minor
                          └─ major

  ARCHITECTURE differs (.x86_64 vs .aarch64)
    → STOP. Nothing is comparable; perf_stat counters differ in MEANING (P0, R4)
    → this is also the ONLY place aperf exposes architecture at all — there is no
      arch field, and no rule compares Instance Type

  MAJOR differs
    → expect broad behavioural change across scheduling, memory, and I/O (P1, R0)
    → IF the newer major is >= 7: check `PREEMPT_LAZY Detected` immediately.
      That rule fires only on major >= 7 with CONFIG_PREEMPT_LAZY=y and is the
      ONE kernel change aperf names concretely
    → IF the newer major is >= 6.9 (folios): huge-page accounting changed, so
      re-read the THP findings rather than trusting a like-for-like comparison

  MINOR or PATCH differs
    → targeted change; usually a specific subsystem (P2, R0)
    → verify: diff `kernel_config` between runs — that is where the real change
      usually lives

  DISTRO BUILD differs only (123.190 vs 123.191)
    → config and backport changes invisible to this rule (P2, R0)
    → verify: `kernel_config` for CONFIG_PREEMPT*, CONFIG_TRANSPARENT_HUGEPAGE,
      CONFIG_HZ, and mitigation settings

  DISTRO TAG differs (amzn2 vs amzn2023)
    → a DIFFERENT DISTRIBUTION, not a version bump (P0, R4)
    → glibc, compiler, and default sysctl set all change; treat as a stack rebuild
    → verify: re-record both runs on the same distribution. Nothing short of that
      isolates the change under test — the `sysctl` and `kernel_config` diffs will
      be large enough that attributing any single delta is guesswork

STEP 2 — Establish whether the change was intended.
  IF deliberate kernel A/B
  THEN → the report IS the kernel comparison. Every delta is attributable to the
         kernel — the inverse of the usual reading (P1, R0)
  ELSE → check `AMI ID`, which usually explains WHY the kernels differ, and tells
         you the fix is an image pin rather than anything about the workload (P0, R4)
       → verify: re-record with the AMI pinned. `Kernel Version` should then match
         and this gate should stop firing; if it still differs at a pinned AMI, the
         kernel was updated in-place after boot

STEP 3 — Check for silent config drift even when strings suggest a small change.
  Identical version strings do NOT mean identical kernels: boot parameters,
  `sysctl`, and kernel config differ invisibly. aperf collects `sysctl` and
  `kernel_config` but NOT the kernel command line.
  → IF an unexplained delta persists with near-identical versions, diff `sysctl`
    and `kernel_config` manually (P2, R0)

STEP 4 — Check for metrics that exist in only one run.
  Kernel versions add and remove /proc counters. Per-metric rules simply do not
  fire on a missing metric, and statistical findings SKIP metrics absent from
  either run.
  → a vanished counter looks like silence, not a change (P2, R0)

STEP 5 — What survives?
  VALID      : configuration findings (THP state, ENA Express, tiered compilation)
  CONFOUNDED : per-unit efficiency (IPC, miss rates) — meaningful but cause is unclear
  VOID       : absolute counters, all cpu_utilization/vmstat attribution to code,
               the statistical findings table as evidence about the application

INSUFFICIENT DATA
  IF the base run lacks the `Kernel Version` key
  THEN → the rule returned early; NO finding produced. Silence is not parity (P1, R0)
```

## Runtime-specific consequences

A kernel change affects the four target runtimes through different mechanisms. This matters most when the
kernel change was intentional and you need to know *where* to look for the effect:

| Runtime | Primary kernel-sensitive path | What to check |
|---|---|---|
| **Java** | Futex behaviour under GC and lock contention; THP interaction with the heap; timer granularity affecting GC pauses | `PREEMPT_LAZY Detected`, THP state, and GC pause distribution. A preemption-model change alters *tail* latency without moving averages |
| **.NET** | Same futex and scheduling exposure; `GCHeapHardLimit` reads cgroup v1 vs v2 differently, and cgroup layout changes across kernel/distro versions | Confirm the GC saw the same memory limit on both kernels — a cgroup v1→v2 move can silently change the heap ceiling (P1, R2) |
| **Python** | Syscall-heavy paths; allocator `mmap` threshold behaviour; `epoll`/`io_uring` availability for async frameworks | Syscall-bound workloads shift most. Check `cpu_utilization`'s `system` share |
| **Perl** | `fork()` cost for preforking servers; copy-on-write behaviour, which THP changes materially | Preforking servers are unusually sensitive to THP and fork cost — check both together |

**The cross-cutting one: THP.** Transparent huge pages interact strongly with JVM/CLR heaps and with
copy-on-write in preforking Perl and Python servers. A kernel or distro change that flips the THP default from
`madvise` to `always` (or back) can move throughput by double digits with no application change. `kernel_config`
tells you the *compile-time* setting only — the runtime setting in
`/sys/kernel/mm/transparent_hugepage/enabled` is **never collected**, so check it on the host directly (R0).

## Architecture-specific considerations

**The architecture suffix of the kernel string is the highest-value component to compare, and this gate reports
it only as part of an opaque string inequality.** `6.1.100-x86_64` vs `6.1.100-aarch64` produces one flat −256
finding worded exactly like a patch-level bump.

Cross-check against `pmu_config.json`, which is direct evidence rather than a distro-dependent suffix
([ARCHITECTURE.md](../ARCHITECTURE.md) §1). The suffix convention is Amazon Linux's; other distributions do not
guarantee it.

| First differing component | Architecture implication | Action |
|---|---|---|
| Architecture suffix (`.x86_64` vs `.aarch64`) | **The machines are a different ISA.** Every `perf_stat` finding is incomparable in meaning | STOP (P0, R4) |
| Major/minor version, same architecture | Behavioural change within one ISA | Standard kernel-change reading (P1, R0) |
| Distro build/tag only, same architecture | Config drift; check `kernel_config` | P2, R0 |
| Strings differ but architectures also differ per `pmu_config.json` | The kernel difference is a *consequence* of the platform difference | Treat as an architecture comparison, not a kernel one (P0, R4) |

**Architecture-linked kernel features that change what you should expect:**

- **THP folios (≥ 6.9)** matter more on arm64, where 64 KiB folios map onto the contiguous-PTE hint and reduce
  TLB pressure substantially. A kernel upgrade crossing 6.9 on arm64 can move `data-tlb-mpki` and
  `inst-tlb-mpki` on its own — attribute nothing to the application.
- **Base page size** is a kernel build option, not a version. Two kernels with the same version string can
  differ in page size; aperf collects neither the page size nor the relevant `kernel_config` entry directly.
- **`PREEMPT_LAZY` (≥ 6.12/7.x)** is architecture-independent but interacts with SMT-less arm64 differently
  under heavy thread counts.
- **arm64-only observability**: hotline requires ARM SPE (`/sys/devices/arm_spe_0/type`), so a kernel change
  that alters SPE availability removes hotline data on arm64 and is irrelevant on x86_64.

Runtime consequence worth stating: a kernel upgrade that also crosses architectures means **every native
artefact was rebuilt** — Python wheels, .NET R2R images, Perl XS modules, JVM intrinsics selection. The kernel
gate is then the least interesting of the differences it is reporting.

## Verification

Pin the AMI, disable unattended upgrades for the test window, and re-run. Confirm the finding disappears. If it
was intentional, keep the finding and re-label the report as a kernel comparison — there is no analysis that
recovers a clean code comparison across kernels.

## Do not

- **Do not read the score as magnitude.** It is a flat −256; a patch bump and a five-major-version jump score
  identically. Read the strings.
- **Do not assume the rule compared versions semantically.** It is an exact string comparison with no notion of
  newer or older.
- **Do not dismiss a distro-build-number difference without checking `kernel_config`.** Builds carry config
  changes this rule cannot see.
- **Do not overlook the distro tag.** `amzn2` → `amzn2023` is a different distribution, not a version bump.
- **Do not compare across architectures.** `x86_64` versus `aarch64` makes `perf_stat` counters
  incomparable in meaning, not just in value.
- **Do not attribute any delta to the code** while the kernels differ — including the statistical findings table.
- **Do not treat absence of this finding as proof the kernels match.** A base run missing the key suppresses the
  rule entirely.
- **Do not assume matching version strings mean matching kernels.** Boot parameters, `sysctl`, and config differ
  invisibly.
- **Do not skip `PREEMPT_LAZY Detected` when a 7.x kernel is involved.** It is the one named, actionable cause.
- **Do not interpret a missing metric as a workload change.** Kernel versions add and remove `/proc` counters.
- **Do not try to "correct for" the kernel difference analytically.** Pin the kernel and re-run.

## References

- Rule definition: `src/analytics/rules/systeminfo.rs:12` — `key: "Kernel Version"`, `score: Score::Critical`.
- Rule template: `src/analytics/rule_templates/key_value_key_run_comparison_rule.rs` — exact
  `value != base_value` comparison; skips the base run; **returns early with `debug!` if the base run lacks the
  key**; emits a **second description form** when the key is absent from the compared run
  (`"The key {} does not exist in {}, while its value in {} is \"{}\"."`); **inserts `self.score` directly — no
  `compute_finding_score` call, so the score is flat**.
- Score: `Score::Critical = −256`, `src/analytics/mod.rs:147`.
- Key lookup: `key_value_value_by_key` → `lookup_key_value`,
  `src/data/common/processed_data_accessor.rs:157` and `:571` — scans **all** key-value groups and returns the
  first match.
- Collection: `src/data/systeminfo.rs` — `kernel_version` from the `sysinfo` crate's `kernel_version()`
  (`sysinfo 0.26`), i.e. the `uname -r` release string; `is_static() == true`, so it is collected once per run,
  not per interval. Keys emitted: `System Name`, `OS Version`, `Kernel Version`, `Hostname`, `CPUs`,
  `Instance ID`, `Region`, `Instance Type`, `AMI ID`, `Local Hostname` — all in a single unnamed
  `KeyValueGroup`.
- **Related multi-data rule:** `PreemptLazyDetectedRule`, `src/analytics/rules/multi_data_rules.rs:16` — reads
  `Kernel Version` from `systeminfo`, parses the **major version** via `version.split('.').next()`, requires
  `major >= 7` **and** `CONFIG_PREEMPT_LAZY == "y"` in `kernel_config`.
- Frontend context: `systeminfo` is rendered as the report home page —
  `data-descriptions.ts:74` ("The APerf report homepage provides overviews of each recording run… every run's
  system information, analytical findings, and statistical findings").
- Related playbooks: `inconsistent-number-of-cpus.md`, `../kernel_config/preempt-lazy-detected.md`,
  `../kernel_config/huge-page-disabled.md`, `../meminfo/inconsistent-physical-memory.md`,
  `../java_profile/jvm-version-comparison.md`, `../statistical/README.md`.
- [PREEMPT_LAZY discussion (linked from the rule's own message)](https://lore.kernel.org/all/20260403191942.21410-1-dipiets@amazon.it/T/#t)
- [uname(1)](https://man7.org/linux/man-pages/man1/uname.1.html)
