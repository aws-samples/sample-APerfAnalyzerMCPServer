---
rule_name: Statistical Findings
data_type: "*"
data_key: "<metric> × <stat>"
template: frontend_computed
condition: "delta != 0 between a time-series metric's stat and the same stat in the base run"
base_score: "+1 / 0 / -1 (from the metric's desired direction)"
score_sign: mixed
requires_comparison: true
aperf_message: "A statistical finding represents the delta of comparing a time-series metric's stat against the same metric in the base run. The deltas are color-coded based on the desired value of the metric - green means as desired (good) and red means otherwise (bad). Use the filters to select data types, stats, and finding types to be included in the table."
source: src/report_frontend/src/utils/analytics.tsx:122
---

# Statistical Findings

This file is the treatment for the *other* half of aperf's findings. The 51 playbooks in this tree cover
**Analytical Findings** — curated rules evaluated in Rust at report-generation time. Statistical Findings are a
completely different mechanism with different guarantees, and they need to be read differently.

## What they are

For every time-series metric, for each of the **8 stats** (`avg`, `std`, `min`, `max`, `p50`, `p90`, `p99`,
`p99_9`), the frontend compares the value in this run against the same stat in the base run. **Every non-zero
delta becomes a finding.** There is no rule, no threshold, and no curation.

Per aperf's own help text: *"A statistical finding represents the delta of comparing a time-series metric's stat
against the same metric in the base run. The deltas are color-coded based on the desired value of the metric —
green means as desired (good) and red means otherwise (bad)."*

**The essential contrast:**

| | Analytical Findings | Statistical Findings |
|---|---|---|
| Where computed | Rust, at report generation | **Browser, at page load** (`computeAllTimeSeriesStatsDelta()`) |
| Count | **51 curated rules** | **Thousands** — one per (metric × stat × run) with a non-zero delta |
| Threshold | Per-rule, deliberate | **None.** A 0.0001% delta is a finding |
| Score | `Critical` −256 … `Optimal` +256 | **`+1`, `0`, or `-1` only** |
| Serialized | Yes, in `<data_type>_findings` | **No.** Recomputed in the browser each load |
| Single-run report | Many rules fire | **None.** Comparison-only |
| Data formats | time-series, key-value, profile | **time-series only** |
| Precision | High — each rule encodes a hypothesis | **Low.** Mechanical arithmetic |
| Recall | **Low** — 10 data types have no rules at all | **High** — every time-series metric, every stat |
| Says *why* | Yes: `description` + `message` | **No.** Only the numbers |

The two are complements: **analytical findings tell you what to think; statistical findings tell you what moved.**
Use analytical findings to form a hypothesis and statistical findings to test and extend it.

## How the numbers are computed

`computeAllTimeSeriesStatsDelta()` (`src/report_frontend/src/utils/analytics.tsx:122`), for each time-series data
type, each non-base run, and each metric present in **both** runs:

```js
if (baseValue > 0) {
  delta = (statValue - baseValue) / baseValue;      // fractional
  deltaStr = `${delta > 0 ? "+" : ""}${(delta * 100).toFixed(1)}%`;
} else {
  delta = statValue - baseValue;                    // RAW difference
  deltaStr = `${delta > 0 ? "+" : ""}${formatNumber(delta)}`;
}
```

Then the sign is assigned from the metric's `desired` field in `data-descriptions.ts`:

```js
if (delta == 0 || stat == "std")   { baseScore = 0;  color = "";      }
else if (desired === "higher")     { baseScore = delta > 0 ? 1 : -1;  }
else if (desired === "lower")      { baseScore = delta < 0 ? 1 : -1;  }
else                               { baseScore = 0;  color = "";      }
```

**Seven consequences that determine how you read the table:**

1. **The units of `delta` change silently.** When `baseValue > 0` the delta is a **fraction** rendered as a
   percentage. When `baseValue <= 0` it is a **raw difference** rendered by `formatNumber` (K/M/G/T, decimal). So
   `+2.50K` and `+15.0%` in the same column are different quantities. The `Base` column is what disambiguates
   them — **always read it.**
2. **A zero base makes any movement sort as infinite.** `compareDelta` treats `baseValue === 0` as `+Infinity`
   when the delta is positive and `−Infinity` when negative, so **a counter that was 0 in the base run and is 1
   now sorts above a metric that genuinely doubled** — and a counter that went non-zero → 0 sinks to the very
   bottom. The default sort is descending by delta, so **zero-base increases monopolise the first page and
   zero-base decreases are on the last page you will never open.** The pinned block is not unordered, either: the
   tie-break `return b.delta - a.delta` sorts it by raw magnitude, so **the largest zero-base increase is row 1
   and the largest zero-base decrease is the very last row in the table.** This is endemic to
   `netstat`/`ena_stat`/`efa_stat` error counters, which are legitimately 0 on a healthy base run.
3. **`std` is always scored 0.** Hard-coded. Variance changes are computed and displayed but never classified as
   good or bad — and since the default finding-type filter is `negative` only, **`std` findings are invisible by
   default.** Variability changes are often the most interesting thing in a comparison; you have to go looking.
4. **The sign is only as good as the `desired` field.** All **802** time-series metrics do carry a `desired`:
   486 `lower`, 115 `higher`, 124 `depends`, 68 `moderate`, 9 `fixed`. **Only `higher` and `lower` produce a
   non-zero score**, so **201 metrics (25.1%) always score 0**. Combined with the `std` rule, **2209 of the 6416
   possible (metric × stat) pairs per non-base run — 34.4% — are structurally incapable of being scored**, and the
   default `negative` filter then hides every one of them.

   **The `?.desired` optional chain is not hypothetical — it is the common case.** Measured on a real 2-run report
   from this host: **73 of 709** collected metrics (10.3%) have names absent from `data-descriptions.ts`, so
   `fieldDescriptions[metricName]?.desired` is `undefined`, the `else` branch runs, and **every stat of those
   metrics scores 0 and is hidden by the default filter.** They are the metrics whose names are generated at
   runtime rather than enumerated at build time:

   | Data type | Unknown / in table | Why the name is not in `data-descriptions.ts` |
   |---|---|---|
   | `interrupts` | **61** / 31 | One metric per IRQ line in `/proc/interrupts`, named from the hardware — e.g. `(PCI-MSIX-0000:00:04.0 1-edge nvme0q1)`. Never enumerable; the 31 in the table are the fixed named IRQs |
   | `aperf_stats` | 4 / 21 | Collector phase timers (`prepare`, `finish`, `static_collect`, `static_write`) |
   | `meminfo` | 4 / 56 | Newer kernel fields — `Zswap`, `Zswapped`, `SecPageTables`, `Unaccepted` |
   | `netstat` | 3 / 221 | Newer `TcpExt:` counters, e.g. `TcpExt:TCPReqQFullDrop` |
   | `ena_stat` | 1 / 90 | `rx_bp_invocations_cnt` |

   So the 802-metric census is the **build-time** surface, not the collected one, and the 201-never-score figure is
   a floor. On this report the true unscoreable count was 201 + 73 more. **A newer kernel silently widens this
   blind spot**: it adds counters that no rule and no `desired` covers, and they land in the one bucket the default
   view hides. `desired_direction()` returns `None` for these and the port scores them 0, matching aperf.
5. **`moderate` and `fixed` are silently treated as `depends`.** The code has no branch for them; they fall
   through to the `else`. So a metric whose ideal is a middle value or a constant is never flagged in either
   direction, no matter how far it moved.
6. **Metrics absent from either run are skipped entirely** (`if (baseMetric == undefined || curMetric == undefined)
   continue`). A counter that exists only in the newer kernel produces **no finding** — see Blind spots.
7. **Every stat was truncated to 2 decimal places before the frontend ever saw it.** Each field of `Statistics`
   is serialized through `f64_to_fixed_2` = `f64::trunc(value * 100.0) / 100.0`
   (`src/computations/mod.rs:138`, applied at `:8`–`:23`, `:154`). Three consequences the percentage cannot show
   you: a real change **below 0.01 in the metric's own unit produces no finding at all** because both stats
   serialize identically; the **smallest visible relative change is `0.01 / base`**, which is 1% at a base of 1
   and 0.01% at a base of 100, so a percentage on a small base is mostly grain; and truncation can **flip which
   branch runs** — a true base of `0.004` serializes to `0.0`, so the raw-difference branch is taken instead of
   the fractional one. Note also that the Delta column's `toFixed(1)` **rounds** while the values it is derived
   from were **truncated**, so the columns disagree in the last digit by design.

## What the table shows

`GlobalStatisticalFindings` (home page) renders columns **Data**, **Stat**, **Delta**, **Value**, **Base**, and
**Unit** — plus a leading actions column holding the help-panel and metric-graph icons — paginated at **20** rows
and sorted by default on the **Delta** column (`columnDefinitions[3]`), descending, with zero-base entries pinned
to ±Infinity. `LocalStatisticalFindings` (per-data page) drops the actions column, so its default sort is still
**Delta** (`columnDefinitions[2]`), but it paginates at **10**.

**The default filters are the most important operational fact here:**

| Filter | Default | Effect |
|---|---|---|
| Data types | all time-series types | — |
| **Stats** | **`avg` only** | **The other 7 stats are hidden.** `max`, `p99`, and `std` deltas are not shown until you change this |
| **Finding types** | **`negative` only** | **Positive and neutral findings are hidden.** You do not see improvements, and you do not see any `depends`/`moderate`/`std` finding |

So the default Statistical Findings view is **"average-only, regressions-only"**. That is a reasonable triage
default and a poor investigation default. On a data page, `LocalStatisticalFindings` defaults to
`STAT_OPTIONS[0]` (= `avg`) and `FINDING_TYPE_OPTIONS[0]` (= `negative`) as well.

The base run shows the literal text *"The base run does not have statistical findings."* — expected, not a bug.

## Reasoning — how to read them well

**They are recall, not precision. Use them second.** A comparison report can produce thousands of statistical
findings; most reflect ordinary run-to-run variance. Sorting by delta magnitude surfaces the largest *relative*
movements, not the most important ones. **The productive order is: read the analytical findings, form a
hypothesis, then use the statistical findings to confirm the mechanism and find the metrics no rule covers.**

**The `avg`-only default hides the shape of the change, and shape is usually the diagnosis.** Two runs can have
identical averages and completely different behaviour. Change the stat filter deliberately:

| Stat | What a delta in it means |
|---|---|
| `avg` | Total work or total resource changed. The default view |
| **`max`** | A new peak — the strongest evidence of a new burst, spike, or saturation event |
| **`p99` / `p99_9`** | Tail behaviour. **But for n ≤ 100 samples `p99 == max`**, and for n ≤ 1000 `p99_9 == max` (percentiles are `sorted[floor(pct × n)]`) |
| `p90` | The shoulder — where sustained-but-not-peak load lives. **`p90 == max` for n ≤ 10.** At the default `--period 10 --interval 1` an accumulative metric has **11** samples (10 intervals plus the forced-zero first one), so `p90` sits one index below `max` while `p99`, `p99_9`, and `max` are still **all the same number**. Drop to `--period 9` and `p90` collapses too |
| `p50` | The typical sample. `p50` flat with `avg` up means **the change is in the tail, not the body** |
| `min` | A floor moved — often the clearest signal of a new baseline cost (idle CPU, background traffic) |
| **`std`** | Variability changed. **Always scored 0, so hidden by the default filter** — and frequently the most diagnostic column |

The `max`/`min` rows above describe a `desired: lower` metric, which is the majority (486 of 802) but not all.
For a `desired: higher` metric the roles invert: `min` is the extreme sample and `max` is the floor. `std` is the
one stat that does not invert — wider spread is worse either way.

**The `p50`/`avg` divergence pattern is worth internalising**: `avg` up with `p50` flat and `max` up means a small
number of large samples moved — a burst, a stall, a GC pause, a retry storm. `avg` and `p50` moving together means
a uniform shift in the workload. These call for entirely different investigations, and the default view cannot
distinguish them. **Both readings assume a `desired: lower` metric**; on a `higher` one the regression is a
*decrease* and the extreme sample is `min`, not `max`.

**Percentages of small numbers are the dominant false-positive class.** A metric whose base `avg` is 0.02 and now
reads 0.05 shows `+150.0%` and sorts near the top. **Always read the `Value` and `Base` columns before reacting to
a percentage.** The `Unit` column tells you whether the absolute magnitude matters at all.

**Sample counts must match before a percentile delta means anything.** aperf's percentiles are positional
(`sorted_values[floor(pct × n)]`), so the number of samples changes what a percentile *is*. Two runs recorded with
different `--period` or `--interval` produce percentiles that are not comparable — and `avg` is diluted
differently too for accumulative metrics, whose **first sample is forced to 0** (`ignore_first_accumulative_value`),
contributing a `1/n` dilution that does not cancel across different run lengths. **Check `--period`/`--interval`
parity for both runs before reading any statistical finding.**

**Delta gaps in accumulative metrics can manufacture findings.** For counters processed by
`add_accumulative_data_point`, a **decreasing sample returns `None`** rather than a negative value, producing a
gap. Counter resets (interface reset, driver reload, counter wrap) therefore drop samples, which changes `n`,
which changes every percentile and dilutes the average. A statistical finding on such a metric can reflect a
collection artifact rather than a behavioural change.

**A statistical finding on a validity-gate metric outranks everything else in the report.** If `MemTotal`, `CPUs`,
or the instance type differ, the whole comparison is invalid and every statistical finding is comparing different
hardware. **Check the analytical validity gates first** — `Inconsistent Physical Memory`,
`Inconsistent Number of CPUs`, `Kernel Version Mismatch`, `JVM Version Comparison`,
`Inconsistent Inbound/Outbound Network Traffic`.

**They are the only findings available for 10 data types.** `processes`, `diskstats`, `interrupts`, `numastat`,
`memalloc`, `sysctl`, `hotline`, `perf_profile`, `aperf_stats`, and `aperf_runlog` have **no analytical rules at
all** (`impl AnalyzeData for X {}`). For the time-series ones — `processes`, `diskstats`, `interrupts`,
`numastat`, `memalloc`, `aperf_stats` — statistical findings are **the only automated signal aperf produces**. A
disk-saturated or IRQ-storming host emits zero analytical findings from `diskstats`/`interrupts`; the statistical
table is where that shows up, and only if you look. (`sysctl`, `kernel_config`, and `systeminfo` are key-value, and
`hotline`/`perf_profile`/`java_profile`/`aperf_runlog` are not time-series, so **they produce no statistical
findings either** — those have no automated coverage whatsoever beyond their few analytical rules.)

## Interpretation

| Evidence | Reading |
|---|---|
| **`Base` column is 0** | **Sorting artifact.** `compareDelta` pins zero-base rows to ±Infinity, so increases head the table and decreases sink to the last page. Common and usually benign for error counters — but a counter going 0 → non-zero is itself meaningful, so read the absolute `Value` |
| Large `%` with tiny `Value` and `Base` | **Noise.** A percentage of a near-zero number |
| Delta shown as `+2.50K` rather than `%` | **`baseValue <= 0`**, so this is a **raw difference**, not a percentage |
| `avg` up, `p50` flat, `max` up | **A burst or spike**, not a uniform shift. Look at the time series |
| `avg` and `p50` up together | A **uniform** workload or cost increase |
| `min` up | A **new floor** — background cost that did not exist before |
| `std` up (must un-filter to see) | **Variability increased.** Often the real story; always scored 0 |
| `p90` == `p99` == `p99_9` == `max` | **Expected at short run lengths.** With ~10 samples all four are the same element. Not a data error |
| Only `max`/`p99_9` moved | A single outlier sample. Check whether it is one interval |
| Metric appears in one run only | **No finding is generated** — the metric is skipped. A silent gap |
| Delta on a `depends`/`moderate`/`fixed` metric | **Scored 0 and hidden by the default `negative` filter.** Un-filter to see it |
| Hundreds of `negative` findings across all data types | Suspect a **systemic** difference — instance size, kernel, JVM, or load level — not hundreds of independent regressions |
| A validity-gate analytical finding also fired | **Discount the entire statistical table** until the runs are matched |
| Findings concentrated in one data type | A focused change. The most tractable case |

The four multi-stat rows above (`avg`/`p50`/`min`/`max`) are stated for a `desired: lower` metric. **Mirror them on
the 115 `desired: higher` metrics** — there a *decrease* is the regression and `min` is the extreme sample — or use
`read_shape(..., desired=…)`, which does the mirroring from the metric's own declared direction.

**Known false positives — the recurring classes:**

- **Percentage of a near-zero base.** The most common by volume.
- **Zero-base increases sorted to the top** (and zero-base decreases to the bottom) by the `±Infinity` rule in
  `compareDelta`.
- **Run-to-run variance** on any metric without a stable steady state; there is no threshold and no significance
  test.
- **Mismatched `--period`/`--interval`**, which makes percentiles and accumulative averages incomparable.
- **Counter-reset gaps** in accumulative metrics changing `n` and hence every stat.
- **Different hardware or runtime** — every finding in the table is then comparing different systems.
- **Warm-up and page-cache effects** in the first intervals of a run, which move `min`, `p50`, and `avg`.
- **A metric whose `desired` direction is wrong or absent** in `data-descriptions.ts`, giving a misleading colour
  or no score at all.

## Blind spots

What statistical findings **cannot** tell you. `INDEX.md` § "Data types with NO analytical rules" points here
because for six time-series data types this table is the only automated signal — and these are its limits.

- **No threshold and no significance test.** Every non-zero delta is a finding; nothing distinguishes signal from
  noise.
- **`std` is always scored 0**, so variability changes never appear in the default view.
- **`moderate` and `fixed` fall through to the `depends` branch** and always score 0.
- **201 of 802 metrics (25.1%)** marked `depends`/`moderate`/`fixed` are **permanently neutral** and hidden by the
  default filter. With the `std` rule that is **2209 of 6416 (metric × stat) pairs — 34.4% — that can never be
  scored.**
- **Changes smaller than 0.01 in the metric's own unit are invisible**, because every stat is truncated to 2 dp
  before serialization. The finding is not filtered out; it is never generated.
- **Metrics present in only one run are skipped**, so **new or removed counters produce no finding at all** —
  precisely what happens across a kernel or driver version change, where a new metric appearing is itself the
  news.
- **Only the base run (`RUNS[0]`) is ever compared against**; there is no cross-comparison among non-base runs.
- **Time-series only.** Key-value data (`systeminfo`, `kernel_config`, `sysctl`) and profile data
  (`java_profile`, `perf_profile`, `hotline`) produce **none**.
- **No `why`.** There is no `description` or `message` — only numbers. Interpretation is entirely on the reader.
- **No time dimension.** A stat is a whole-run summary; *when* within the run it changed is invisible. Open the
  metric graph.
- **Not serialized.** They are recomputed in the browser at page load, so they cannot be read from the report's
  JSON the way analytical findings can (`<data_type>_findings`). **Any MCP integration must recompute them from
  the stats rather than parse them out.**
- **Per-CPU and per-series detail is not compared** — the finding is per metric, not per series within it. Worse,
  **the stats come from exactly one series and the report does not say which**: `stats_series_idx` is
  `#[serde(skip)]` (`src/data/common/data_formats.rs:81`–`:96`), and for `diskstats` (`MaxSeries`) and `processes`
  the chosen series is **the one with the largest average**, which can be a *different device or process in each
  run*. A delta on those two data types may be comparing two different things entirely.
- **A NaN stat is displayed as a regression, not as bad data.** `NaN > 0` and `NaN < 0` are both false, so a NaN
  delta takes the `-1` arm on any `higher` **or** `lower` metric, lands in the default `negative` filter, and
  renders `NaN%` in red. (`getFindingColor`'s `isNaN` → gray branch is in `AnalyticalFindings.tsx:34` and does
  **not** apply here — statistical findings carry an inline colour span assigned in `analytics.tsx:158`–`:172`.)

## Guidance

Ordered. **Steps 1–3 are what make the table usable at all.**

1. **Check the analytical validity gates before reading a single statistical finding.**
   `Inconsistent Physical Memory`, `Inconsistent Number of CPUs`, `Kernel Version Mismatch`,
   `JVM Version Comparison`, and the two `Inconsistent … Network Traffic` rules each mean the two runs are not
   comparable. **If any fired, the entire statistical table is comparing different systems.**

2. **Confirm `--period` and `--interval` parity between the runs.** Percentiles are positional over the sample
   list, so a different sample count changes what `p90`/`p99`/`p99_9` mean, and accumulative averages are diluted
   differently by the forced-zero first sample. Without parity, percentile and average deltas are not comparable.

3. **Change the default filters immediately.** The default view is **`avg` only, `negative` only**. Add `max`,
   `p50`, `p99`, and **`std`**, and enable `zero` and `positive` finding types. The default hides the shape of the
   change, every improvement, and every `depends`/`moderate`/`std` metric.

4. **Read `Value`, `Base`, and `Unit` before reacting to any percentage.** A `+150.0%` on a base of 0.02 is noise;
   a `+8.0%` on a metric at 90% utilization is not. If the Delta column shows `+2.50K` rather than a percentage,
   `baseValue <= 0` and you are looking at a **raw difference**.

5. **Discount the top of the table when `Base` is 0, and check the bottom of it too.** `compareDelta` pins
   zero-base rows to ±Infinity, so zero-base *increases* sort first regardless of magnitude and zero-base
   *decreases* sort dead last — where the default descending sort and 20-row pagination bury them. Error counters
   legitimately read 0 on a healthy base run. That said, a counter moving 0 → non-zero is meaningful in its own
   right — judge it on the absolute `Value`.

6. **Read the stats together, not one at a time.** `avg` up with `p50` flat and `max` up means a **burst**;
   `avg` and `p50` moving together means a **uniform shift**; `min` up means a **new floor**. These have different
   causes and different fixes, and only the multi-stat view distinguishes them. **Those signatures are written for a
   `desired: lower` metric.** On the 115 `desired: higher` metrics every sign flips and `min`/`max` swap roles — the
   worst sample of a `higher` metric is its minimum — so read the shapes as *worse* and *better*, never as up and
   down. See § The triage procedure STEP 4.

7. **Un-filter to see `std`.** It is hard-coded to score 0 and therefore invisible under the default `negative`
   filter, yet a variability change is frequently the most diagnostic observation in a comparison.

8. **Open the metric graph for anything you intend to act on.** A stat is a whole-run summary with no time
   dimension; the graph shows *when* the change happened, whether it was a step or a spike, and whether it
   coincides with something else. The table's zoom icon does this in place.

9. **Group findings before investigating them.** Hundreds of negative findings across many data types almost
   always reflect **one** systemic difference — instance size, kernel, JVM, load level — not hundreds of
   independent regressions. Find the common cause rather than triaging rows.

10. **Use statistical findings deliberately for the 10 rule-less data types.** `processes`, `diskstats`,
    `interrupts`, `numastat`, `memalloc`, and `aperf_stats` have **no analytical rules**, so this table is their
    only automated signal. When investigating I/O wait, IRQ load, NUMA placement, or per-process cost, come here
    explicitly — nothing will point you at it.

11. **Cross-reference each statistical finding against the relevant analytical playbook.** If `pgfault`'s `avg`
    moved, read `vmstat/excessive-page-fault-rate.md` and `vmstat/increased-minor-page-faults.md` for the
    mechanism and corroborating checks. **The playbooks supply the reasoning that statistical findings lack.**

12. **Treat a suspicious accumulative-counter delta as possibly a collection artifact.** A decreasing sample
    yields `None` and a gap, so counter resets change `n` and thus every stat. Check the metric graph for gaps
    before believing the number.

13. **For MCP integration, recompute rather than parse.** Statistical findings are not serialized — they are
    derived in the browser at page load. Reproducing them means reading each time-series metric's `stats` object
    per run and applying the delta and `desired`-sign logic above, including the `baseValue > 0` branch, the
    `std`-is-zero rule, and the `moderate`/`fixed` fall-through. **Use `../tools/aperf_statistical.py` rather than
    re-deriving it** — the sign rule for `desired: "lower"` must be written as `delta < 0 ? 1 : -1` and not as its
    algebraic inverse, because the two disagree when the delta is NaN.

14. **Apply an absolute-magnitude floor, not a percentage floor.** aperf has no noise filter, so define one:
    disqualify NaN deltas, negative bases, and changes under the 0.01 serialization grain outright; treat any base
    below 1.0 as too small for a percentage to mean anything; and only then size on the relative delta. § The
    triage procedure gives the ordered test and the thresholds.

15. **Also read the metrics that produced no finding.** A metric present in only one run is skipped silently, and
    that is exactly what a new kernel's new counter looks like. Diff the metric name sets between runs — nothing in
    the report does it for you.

## The triage procedure

Everything above describes the mechanism. This section is the executable part: what to do, in order, with
concrete thresholds. `../tools/aperf_statistical.py` implements all of it — the delta port, the filter, the
ranking, the shape reading, and the routing — and `../tools/test_aperf_statistical.py` pins the port against
aperf's real TypeScript by running both over ~2100 generated cases under `node`. **Use the module rather than
re-deriving the arithmetic; the branch and sign rules have four edge cases that a from-scratch port gets wrong.**

### STEP 0 — Gate the whole table before reading one row

Two conditions void every statistical finding at once, and both are cheap.

```
Did any comparison-validity analytical finding fire?
  (Inconsistent Physical Memory | Inconsistent Number of CPUs | Kernel Version Mismatch |
   JVM Version Comparison | Inconsistent Inbound/Outbound Network Traffic |
   Inconsistent Inbound/Outbound EFA Traffics)
├─ YES → STOP. Every row is comparing different systems, different kernels, or different
│        offered load. Read the gate's playbook, match the runs, re-record. Do not triage
│        rows. (P0, R0)
└─ NO  → Do the sample counts match? (--period and --interval identical in both runs)
   ├─ NO  → STOP. Percentiles are positional over the sample list, so p50/p90/p99/p99_9 are
   │        not the same quantity in the two runs, and the forced-zero first sample dilutes
   │        accumulative averages by (n-1)/n differently. Re-record matched. (P0, R0)
   └─ YES → Proceed to STEP 1. Note which percentiles alias `max` at this n
            (`collapsed_stats(n)`) — at the default n=11 that is p99 and p99_9.
```

`check_preconditions(gates_fired, base_samples, current_samples)` returns exactly this, with the blocking reason
and the playbook to read.

### STEP 1 — Un-filter, then recompute

The default view is `avg`-only and `negative`-only, which hides the shape of every change, every improvement, and
all 2209 unscoreable pairs. Add `max`, `p50`, `min`, and **`std`**; enable `zero` and `positive`.

For an MCP or any programmatic reader, there is nothing to un-filter — **statistical findings are not serialized**
and must be recomputed from each metric's `stats` object. `recompute(base_run, cur_run)` does it, and
`skipped_metrics(base_run, cur_run)` returns the complement that no aperf view will ever show you: the metrics
present in only one run. **That list is often the more interesting half** — a counter that exists only in the newer
kernel is itself the news, and it produces no finding.

### STEP 2 — Apply the noise filter

aperf has none, so this is the step that turns thousands of rows into a shortlist. Run the disqualifying checks
first — an artifact is an artifact regardless of magnitude:

| Order | Test | Verdict | Why |
|---|---|---|---|
| 1 | `delta` is NaN | **artifact** | Scores −1 on any directional metric, so it shows by default and looks like the worst finding in the table. It is bad data |
| 2 | `Base` < 0 | **artifact** | The raw branch ran and the sign no longer tracks improvement: −5 → −3 is a positive delta *and* a move toward zero |
| 3 | `abs(Value − Base)` < 0.01 | **artifact** | Below the 2-dp serialization grain both stats were truncated to. The same true values could have serialized with no delta at all |
| 4 | relative delta < 2 × (0.01 / Base) | **artifact** | Within two grain steps, so most of the delta may be truncation |
| 5 | `Base` == 0 | see STEP 3 | Not noise, but the sort is lying about it |
| 6 | `Base` < 1.0 (fewer than 100 grains) | **weak** | One grain is already ≥ 1%, so the percentage is mostly quantisation. **The dominant false-positive class** |
| 7 | relative delta < 5% | **corroborating** | There is no significance test and no cross-run variance estimate in this table, so a delta this size is not distinguishable from run-to-run variation |
| 8 | otherwise | **actionable** | Large enough, well-based enough, and in a direction that means something |

The 5% floor and the 100-grain base floor are **conventional starting points, not aperf's**. A workload with a
tight latency SLO should lower the first; a noisy multi-tenant host should raise it. `triage(finding,
sample_count=n, min_relative_pct=…)` takes both as parameters and returns the tier plus the machine-readable
reasons.

**The analytical findings have no equivalent filter, and that is a real asymmetry.** Tests 4, 6 and 7 above
exist because a relative delta on a tiny base is mostly quantisation — but the 13
`time_series_stat_run_comparison` rules apply their `delta_ratio` threshold with **no absolute floor at all**
(`time_series_stat_run_comparison_rule.rs:97-110`), and their score is `ratio / threshold × base_score`, so it
grows without bound as the base shrinks. A statistical row that this table would demote to **weak** becomes a
loud analytical finding with a large score. Measured on two **idle** runs recorded 16 seconds apart on this host,
at identical `--period 10 --interval 1`:

| Finding | Base | Current | Score |
|---|---|---|---|
| `Inconsistent Inbound Network Traffic` | 791.36 B/s | 3241.09 B/s | **−61.91** |
| `Decreased User-Space CPU Utilization` | `avg(user)` 0.94% | 0.51% | **−72.98** |

Both outranked every genuine finding in that report; the second is a **0.43 percentage-point** move on a machine
that was ~90% idle in both runs. So when you reconcile the statistical table against the analytical findings, do
not treat a large analytical score as corroboration for a statistical row on the same metric — **check the
absolute values first.** The playbooks for those rules now branch on magnitude before percentage.

Two demotions apply after sizing:

- **`std` never exceeds `corroborating`.** A variability change is real and frequently the most diagnostic thing
  in a comparison, but it says the distribution changed, not that anything regressed — the cause is in the other
  stats.
- **A collapsed percentile is not independent evidence.** If `collapsed_stats(n)` contains the stat, that row is
  the same number as the `max` row. At the default n=11 a "tail regression across p99, p99_9 and max" is **one
  observation reported three times.**

### STEP 3 — Handle the zero-base block deliberately

```
Base == 0?
├─ Delta is positive → the counter left zero. `compareDelta` pinned this row to +Infinity,
│  so it is at the TOP of page 1 regardless of magnitude. The Delta column is a RAW
│  difference in the metric's unit, not a percentage.
│  ├─ abs(Delta) >= 1 unit → ACTIONABLE. A counter absent in the base run and present now is
│  │                         meaningful on its own terms. Read the Unit, then route (STEP 5).
│  │                         Endemic and legitimate for netstat/ena_stat/efa_stat error
│  │                         counters, which read 0 on a healthy base run — so confirm the
│  │                         counter is one where non-zero is bad before escalating. (P1, R1)
│  └─ abs(Delta) < 1 unit → CORROBORATING. A sub-unit move off zero. Read it as support for a
│                           hypothesis, not as a finding. (P3, R0)
└─ Delta is negative → the counter returned to zero. Pinned to −Infinity, so this row is on
   the LAST page, which the 20-row pagination guarantees nobody opens.
   → WEAK, and usually means the BASE run was the unhealthy one. Worth knowing, rarely worth
     acting on in the current run. **Go look at the last page at least once per comparison.**
     (P3, R0)
```

`sort_artifact_report(findings)` gives the census that tells you how much of page 1 is pinned: the count at each
infinity, the count visible under the default filters, and how many pages the default pagination produces.
`sort_as_aperf_does(findings)` reproduces the order the reader sees; `rank(triaged)` replaces it with
(confidence tier, then magnitude), which is what a shortlist should be sorted on.

### STEP 4 — Read the stats together to get the shape

A single stat's delta says a number moved. The **combination** says what moved, and the causes need different
fixes. This is the reading the `avg`-only default makes impossible.
`read_shape({stat: delta}, sample_count=n, desired=…)` names every shape consistent with the deltas.

**Read the signatures as *worse* and *better*, not as up and down.** For a `desired: lower` metric the regression
is an increase; for one of the 115 `desired: higher` metrics it is a **decrease**. `ipc` falling with `p50` flat is
the same burst as `iowait` rising with `p50` flat, and `min`/`max` swap roles — the worst sample of a `higher`
metric is its *minimum*. Pass the metric's real direction; a vocabulary read in raw signs names nothing at all for
those 115 metrics.

| Shape | Signature (in *worse*/*better*, not raw signs) | What it means and what to do |
|---|---|---|
| **burst** | `avg` worse, `p50` flat, tail worse | A small number of extreme samples moved while the body held: a stall, a GC pause, a retry storm, a lock convoy. Open the metric graph for *when*; expect an episodic cause, not a steady-state cost |
| **uniform shift** | `avg` and `p50` move the same way together | The whole distribution translated. More work per unit time, a slower code path on every request, or a different instance size |
| **new floor** | the floor got worse (`min` up for a `lower` metric, `max` down for a `higher` one) | A cost that did not exist before is now in *every* sample. A new agent or sidecar, background traffic, a daemon that now runs, or changed idle power management |
| **single outlier** | only the tail moved (and its collapsed aliases), `avg` and `p50` flat | One interval. **Confirm on the graph before believing it** — at n=11 one interval is 9% of the run |
| **variability only** | `std` moved, `avg` and `p50` flat | The same total work arriving less evenly: scheduling, batching, coalescing, contention. Never visible by default because `std` always scores 0. **Direction-neutral** — rising spread is worse whichever way the metric should go, so `std` is the one stat that is not mirrored |
| **tail clipped** | tail better, `avg` flat or worse | The extremes were cut off while the body held or worsened. Often a throttle, a rate limiter, or a queue-depth cap that started binding — which trades peak for predictability rather than being a straightforward win |

The module keys are `burst`, `uniform_shift`, `new_floor`, `single_outlier`, `variability_only`, and `tail_clipped`.
More than one can fire — they are not exclusive, and the combination is the diagnosis. "Flat" means a delta under
`flat_pct` (default **2%**), which is a judgement about noise, not something aperf defines; raise it for a noisy
workload. **`desired` defaults to `lower`**, which silently misreads all 115 `higher` metrics, so pass the metric's
own direction.

**Guard every shape reading with the sample count.** `read_shape` folds a collapsed percentile into the tail when
you pass `sample_count`; without it, a `p99` delta is counted as independent evidence and at the default run length
it is not.

### STEP 5 — Route to the reasoning

A statistical finding has no `description` and no `message`. The reasoning has to come from somewhere else, and
which somewhere depends on a number worth stating plainly:

**752 of the 802 time-series metrics (93.8%) have no analytical rule at all.** Only 50 do.

```
Does an analytical playbook cover this metric?  (`route(data_type, metric_name)`)
├─ YES (50 metrics) → Read the playbook for the mechanism and the corroborating checks before
│                     acting. **Check which stat the rule reads**: 18 of the 22 stat-bearing
│                     rules read `Average`, 2 read `Max`, 2 read `P99`. A delta on a different
│                     stat is outside what that rule can see, so the playbook's thresholds do
│                     not transfer to it directly. (P1, R1)
└─ NO (752 metrics) → Is the whole data type rule-less?
   ├─ YES → one of `processes`, `diskstats`, `interrupts`, `numastat`, `memalloc`,
   │        `aperf_stats`. **This table is the only automated signal aperf produces for them**,
   │        and nothing in the report will point you here. Use the per-type guidance below.
   │        (P1, R1)
   └─ NO  → the data type has rules but not for this metric — e.g. 5 of 9 `cpu_utilization`
            metrics (`irq`, `nice`, `softirq`, `steal`, `system`) and 4 of 19 `perf_stat`
            metrics (the split read/write TLB counters). **Check whether a related covered
            metric moved too**; that is where the reasoning is. (P2, R1)
```

**The six rule-less time-series data types — what to investigate, since no playbook says it:**

| Data type | Metrics | What a delta here means |
|---|---|---|
| `processes` | 7 | Per-process CPU, RSS, thread and process counts for the top 16 processes by CPU time. **The most direct attribution aperf offers: it names the process.** Caveat: the stats come from the single highest-average series, so the delta may be about a *different process* in each run. `user_space_time`/`kernel_space_time` also drop their first sample while the other five metrics do not |
| `diskstats` | 17 | Queue depth, service time, throughput per device. The companion to `../cpu_utilization/increased-io-wait-time.md`, which can tell you iowait rose but not *which device*. `time_in_progress` and `weighted_time_in_progress` carry queueing; `in_progress` is the only non-accumulative disk stat. Stats come from the busiest device, not the sum |
| `interrupts` | 31 | Per-IRQ counts, aggregated as the **average across CPUs**. An IRQ storm or a change in interrupt affinity shows here and nowhere else. Rising `IPI*`/`CAL` points at cross-CPU coordination cost; rising device IRQs with flat traffic points at coalescing having changed |
| `numastat` | 6 | `numa_miss`, `numa_foreign`, `other_node` rising means allocations are landing off the requesting node — the mechanism behind an unexplained memory-latency regression. Read with `../perf_stat/high-l3-cache-misses.md`, which sees the latency but not the cause. Four of the six are `depends`, so most score 0 and are hidden by default |
| `memalloc` | 94 | Buddy-allocator free blocks by order, page types, slab caches. Low-order-only free blocks means **fragmentation**: allocations needing contiguity fail or stall in compaction. Read with `../kernel_config/huge-page-disabled.md` and `../vmstat/excessive-page-fault-rate.md`. Half of memalloc's metrics are `moderate`/`fixed` and are therefore never scored at all |
| `aperf_stats` | 21 | **aperf's own per-interval collection cost**, in microseconds. Not a workload signal — it is the observer effect. A large delta here means the two runs were measured with different overhead, which biases every other comparison. Treat it as a **validity check on the report**, not a finding about the system |

### Worked example

A comparison of two runs, `--period 10 --interval 1` on both, no validity gate fired. The default view shows
`ena_stat/bw_in_allowance_exceeded [avg] +Infinity`-pinned at the top and 1,847 other negative rows.

1. **STEP 0** passes: gates clean, n=11 both sides. `collapsed_stats(11)` = `(p99, p99_9)`, so those two stat
   columns are aliases of `max`.
2. **STEP 1** un-filters to all 8 stats and all 3 finding types: 4,102 rows.
3. **STEP 2** filters them: 2,209 pairs were never scoreable, 1,431 fall below the grain or inside grain noise,
   118 are weak on a tiny base, 61 are corroborating, **9 are actionable.**
4. **STEP 3** on the pinned top row: `bw_in_allowance_exceeded` went 0 → 41 000 with unit `Count`. That is a
   counter leaving zero by ≫ 1 unit, so **actionable**, and it routes to a playbook.
5. **STEP 4** on `perf_stat/ipc`: `avg` −12.5%, `p50` −1%, `min` −2%, `max` −14%, `std` +180%. `ipc` is
   `desired: higher`, so every one of those decreases is a *worsening* and the tail is `min`, not `max`. `avg` worse
   with `p50` inside the flat band and the tail worse is **burst**; `min` worse on top of that is **new floor** —
   episodic stalls plus a ceiling that came down in every interval, not a uniform slowdown. The `std` +180%
   corroborates the burst but does **not** add **variability only**, which requires the body to be flat; here `avg`
   moved. Read as a `lower` metric the same five numbers name no shape at all — that is the direction bug this
   vocabulary exists to avoid.
6. **STEP 5** routes `ipc` to `../perf_stat/reduced-instructions-per-cycle.md` and
   `bw_in_allowance_exceeded` to `../ena_stat/inbound-bandwidth-exceeded-instance-allowance.md`. The rule behind
   the `ipc` playbook reads `Average`, which matches the stat that moved. The disk rows that also moved route
   nowhere — `diskstats` has no rules — so the per-type guidance above is what carries them.

The 1,847-row default view was 9 actionable rows and one lying sort.

### Programmatic entry point

```
python3 tools/aperf_statistical.py census      # the 802-metric desired distribution
python3 tools/aperf_statistical.py coverage    # 50 covered / 752 uncovered
python3 tools/aperf_statistical.py collapse 11 # which percentiles alias max at n=11
python3 tools/aperf_statistical.py classify <data_type> <metric> <stat> <base> <value> [--samples N]
python3 tools/aperf_statistical.py shape '<json of stat:delta>' [--samples N] [--desired lower|higher]
python3 tools/aperf_statistical.py shape '<json>' --samples 11 --metric <data_type> <metric>
python3 tools/aperf_statistical.py route <data_type> <metric>
```

`shape` defaults to `--desired lower`, which is **wrong for 115 of the 802 metrics**. Prefer
`--metric <data_type> <metric>`: it looks the direction up in the embedded table and prints which one it used, so
the reading cannot silently invert. `read_shape` takes the same `desired` argument and raises `InsufficientData`
on anything outside `lower`/`higher` rather than falling back to a default.

`full_triage(base_run, cur_run, gates_fired, base_samples, current_samples)` runs STEP 0 through STEP 3 in the
required order and returns the ranked list, the shortlist, the visibility census, and the skipped metrics. It
raises `InsufficientData` rather than guessing whenever a stat, a sample count, or a `desired` direction is
missing.

## Do not

- **Do not read the statistical table before checking the analytical validity gates.** Different hardware or
  runtime makes every row meaningless.
- **Do not treat a large percentage as a large problem.** Read `Value` and `Base`; a percentage of a near-zero
  base is the most common false positive.
- **Do not assume the Delta column is a percentage.** When `baseValue <= 0` it is a **raw difference** rendered by
  `formatNumber`.
- **Do not trust the top of the sorted table, and do not assume the last page is empty.** Zero-base rows are
  pinned to ±Infinity by `compareDelta` — increases first, decreases last.
- **Do not accept the default filters.** `avg`-only and `negative`-only hide the shape of the change, all
  improvements, and every `std`/`depends`/`moderate`/`fixed` finding.
- **Do not conclude a metric did not change because it has no finding.** Metrics absent from either run are
  skipped, `std` and non-directional metrics score 0 and are filtered out, and there is no cross-comparison among
  non-base runs.
- **Do not read the multi-stat shapes in raw signs.** `burst`, `new floor`, and the rest are defined in *worse* and
  *better*. On the 115 `desired: higher` metrics the regression is a **decrease** and `min`/`max` swap roles, so a
  raw-sign reading names no shape at all there — it fails silently, as "nothing matched" rather than as an error.
- **Do not compare percentiles across runs with different `--period`/`--interval`.** Percentiles are positional
  and depend on the sample count.
- **Do not read `p90`/`p99`/`p99_9` as distinct at short run lengths.** With ~10 samples — the default — all
  three equal `max`, so four of the eight stat columns carry one number and a "tail regression" across all of them
  is **one** observation, not four.
- **Do not read a statistical finding as an explanation.** There is no `description` and no `message` — only
  numbers.
- **Do not treat the count of findings as a severity measure.** Thousands of findings is the normal state of a
  comparison report.
- **Do not expect them in a single-run report** or on the base run — they are comparison-only by construction.
- **Do not try to parse them out of the report JSON.** They are not serialized; they must be recomputed.
- **Do not use them as a substitute for the analytical playbooks.** They tell you *what moved*, never *why it
  matters*.
- **Do not treat a `NaN%` row as a regression.** A NaN delta scores −1 on any directional metric and renders red
  under the default filter. It is a data-quality problem in the stat, not a performance change.
- **Do not read a percentage on a base below 1.0 as a real change.** One serialization grain is already ≥ 1% there,
  so most of what the Delta column shows is quantisation.
- **Do not compare `diskstats` or `processes` stats without checking which series they came from.** Both pick the
  series with the largest average, `stats_series_idx` is `#[serde(skip)]`, and the choice is made per run — so the
  delta may be comparing two different devices or two different processes.
- **Do not read an `aperf_stats` delta as a workload finding.** It is aperf's own collection overhead. A large one
  means the two runs were measured differently, which biases every other row in the table.

## References

- Computation: `computeAllTimeSeriesStatsDelta()`, `src/report_frontend/src/utils/analytics.tsx:122` — iterates
  `ALL_DATA_TYPES` filtered to `data_format == "time_series"` (`:126`), compares each non-base run against
  `RUNS[0]` (`:123`), skips metrics absent from either run (`:139`), and pushes a `StatisticalFinding` for every
  `delta != 0` (`:177`).
- Delta math: `src/report_frontend/src/utils/analytics.tsx:146`–`:154` — `(statValue - baseValue) / baseValue`
  when `baseValue > 0` (rendered `(delta * 100).toFixed(1)` + `%`), otherwise the **raw difference**
  `statValue - baseValue` (rendered by `formatNumber`).
- Sign assignment: `src/report_frontend/src/utils/analytics.tsx:158`–`:172` — `baseScore = 0` when `delta == 0`
  **or `stat == "std"`**; `desired === "higher"` ⇒ `delta > 0 ? 1 : -1`; `desired === "lower"` ⇒
  `delta < 0 ? 1 : -1`; **everything else (including `depends`, `moderate`, `fixed`, and unset) ⇒ 0**.
- Finding shape: `interface StatisticalFinding`, `src/report_frontend/src/utils/analytics.tsx:62` — `dataType`,
  `runName`, `metricName`, `stat`, `baseScore`, `delta`, `deltaString`, `statValue`, `baseValue`. **No
  description and no message.**
- Storage: `STATISTICAL_FINDINGS`, `src/report_frontend/src/utils/analytics.tsx:116`, and `DATA_STATS_DELTA`
  (`:106`) — both built in the browser; **not serialized into the report.**
- Stats enumerated: `ALL_STATS = ["avg", "std", "min", "max", "p50", "p90", "p99", "p99_9"]`,
  `src/report_frontend/src/definitions/types.ts:113`.
- Stat computation: `Statistics::from_values`, `src/computations/mod.rs:27` — **population** standard deviation
  (`sqrt(sum_sq_diff / n)`, `:48`); percentiles are `sorted_values[floor(pct × n)]` (`:52`–`:55`), **so `p90` ==
  `max` for n ≤ 10, `p99` == `max` for n ≤ 100, and `p99_9` == `max` for n ≤ 1000**. The record defaults are
  `--interval 1 --period 10` (`src/record.rs:37`, `:47`), i.e. **11** samples for an accumulative metric — 10
  intervals plus the forced-zero first one, which is why `p90` does *not* collapse at the default while `p99` and
  `p99_9` do.
- **2-dp truncation of every stat:** `struct Statistics`, `src/computations/mod.rs:8`–`:23` — each of the eight
  fields carries `#[serde(serialize_with = "serialize_f64_fixed2")]` (`:154`), which calls `f64_to_fixed_2`
  (`:138`) = `f64::trunc(value * 100.0) / 100.0`. `Series.values` is truncated the same way
  (`src/data/common/data_formats.rs:118`), and `src/report.rs:533`–`:540` confirms the truncated JSON is what the
  report writes. **So the frontend never sees an untruncated stat**, the noise floor is `0.01 / base`, and a change
  under one grain generates no finding at all.
- Sort tie-break: `compareDelta`'s `if (aDelta === bDelta) return b.delta - a.delta`
  (`StatisticalFindings.tsx:59`) — the ±Infinity-pinned block is ordered by raw magnitude, so the largest zero-base
  increase is row 1 and the largest zero-base decrease is the last row of the last page.
- **Which series the stats come from:** `stats_series_idx` selection,
  `src/data/common/time_series_data_processor.rs:312`–`:342`, applied at `:350`. Four branches: a single series →
  index 0; an auto-generated aggregate over exactly 2 series → drop the aggregate; **`MaxSeries` → the series with
  the largest average**; otherwise the series flagged `is_aggregate`, with a `warn!` and a fallback to 0. The field
  is `#[serde(skip)]` (`src/data/common/data_formats.rs:81`–`:96`), so **the report does not record which series a
  metric's stats describe.** `diskstats` uses `MaxSeries`; `processes` bypasses the processor entirely
  (`src/data/processes.rs:287`–`:313`) and likewise keeps the largest-`avg` series, skipping the first sample for
  `user_space_time`/`kernel_space_time` only.
- Aggregate modes, which determine what a metric's single series *is*: `Sum` → `aperf_stats`; `Custom` →
  `cpu_utilization`, `meminfo`, `netstat`, `vmstat`, `perf_stat`; `MaxSeries` → `diskstats`; `Average` →
  `efa_stat`, `ena_stat`, `interrupts`, `memalloc`, `numastat`
  (`src/data/common/time_series_data_processor.rs:431`–`:476` and the 13 macro call sites). Accumulative types:
  `diskstats`, `efa_stat`, `ena_stat`, `interrupts`, `netstat`, `numastat`, `vmstat`.
- **Analytical-rule coverage of the metric surface:** 50 of 802 time-series metrics are named by a rule; **752
  (93.8%) are not.** Fully uncovered: `aperf_stats` (21), `diskstats` (17), `interrupts` (31), `memalloc` (94),
  `numastat` (6), `processes` (7). Nearly uncovered: `netstat` 219/221, `vmstat` 187/190, `meminfo` 54/56,
  `ena_stat` 82/90, `efa_stat` 25/41. `cpu_utilization` leaves `irq`/`nice`/`softirq`/`steal`/`system` uncovered
  and `perf_stat` leaves the four split read/write TLB counters uncovered. Which stat each rule reads: **18
  `Average`, 2 `Max`, 2 `P99`**; the other 27 rules are not time-series templates. Recomputed by
  `../tools/test_aperf_statistical.py` against `../FINDINGS_REGISTRY.json` on every run.
- Sorting: `compareDelta`, `src/report_frontend/src/components/analytics/StatisticalFindings.tsx:56` — maps
  `baseValue === 0` to **`+Infinity` if `delta > 0`, `−Infinity` otherwise**, so zero-base rows sort to whichever
  extreme matches their direction. Default sorting column is `Delta` — `columnDefinitions[3]` on the home page
  (`:172`, after the actions and data columns) and `columnDefinitions[2]` per data page (`:276`) — with
  `pageSize: 20` globally (`:169`) and **`pageSize: 10`** per data page (`:273`).
- Table columns: `COMMON_COLUMN_DEFINITIONS`,
  `src/report_frontend/src/components/analytics/StatisticalFindings.tsx:63` — Stat, Delta, Value, Base, Unit;
  values rendered by `formatNumber` (`src/report_frontend/src/utils/utils.ts:64`, decimal K/M/G/T at 2 dp) and
  units by `getTimeSeriesMetricUnit` (`:86`, falling back to the data type's `defaultUnit`).
- **Default filters:** `src/report_frontend/src/components/ReportStateProvider.tsx:89`–`:99` —
  data types = `TIME_SERIES_DATA_TYPES`, **stats = `["avg"]`**, **finding types = `["negative"]`**. Per-data-page
  defaults are `STAT_OPTIONS[0]` and `FINDING_TYPE_OPTIONS[0]`
  (`StatisticalFindings.tsx:246`, `:249`) — also `avg` and `negative`.
- Finding-type classification: `isFindingTypeExpected`,
  `src/report_frontend/src/components/analytics/common.tsx:52` — `< 0` ⇒ `"negative"`, `> 0` ⇒ `"positive"`,
  else `"zero"`; readable names "Bad"/"Good"/"Neutral" (`src/report_frontend/src/utils/utils.ts:107`).
- Base run: `GlobalStatisticalFindings`,
  `src/report_frontend/src/components/analytics/StatisticalFindings.tsx:121` — renders *"The base run does not
  have statistical findings."* for `RUNS[0]`.
- Help text: `data-descriptions.ts:79` — `systeminfo` / `statisticalFinding`, quoted in full as `aperf_message`
  above; the `analyticalFinding` counterpart is at `:84`.
- `desired` distribution across `data-descriptions.ts`, over all **802** time-series metrics (every one of which
  has a `desired`): **486 `lower`, 115 `higher`, 124 `depends`, 68 `moderate`, 9 `fixed`** — only `higher` and
  `lower` produce a non-zero `baseScore`, so 201 (25.1%) never score, and with the `std` rule **2209 of the 6416
  possible (metric × stat) pairs (34.4%) can never be scored.** 79 metrics carry an explicit `unit`; the other 723
  inherit their data type's `defaultUnit`, so the Unit column is usually a category. The full table is embedded in
  `../tools/aperf_statistical.py` and re-verified against the upstream source by
  `../tools/test_aperf_statistical.py` on every run, so a `desired` change upstream fails the suite instead of
  silently inverting a sign.
- **The MCP implementation of everything in § The triage procedure:** `../tools/aperf_statistical.py` — the port
  (`classify`, `recompute`, `compare_delta`, `format_number`, `to_fixed`), the filter (`triage`, `rank`), the shape
  reading (`read_shape`), the routing (`route`, `PLAYBOOK_ROUTES`, `UNCOVERED_GUIDANCE`), and the gate
  (`check_preconditions`). Tested by `../tools/test_aperf_statistical.py`, whose load-bearing check runs aperf's
  own `computeAllTimeSeriesStatsDelta`/`compareDelta`/`formatNumber` under `node` over ~2100 generated cases and
  requires exact agreement on delta, delta string, score, and sort order.
- **Shape readings are normalised by the metric's `desired` direction**, not by raw sign: `read_shape` takes
  `desired`, flips the comparison for the 115 `higher` metrics, swaps the `min`/`max` roles so the tail is always
  the worst sample, and leaves `std` direction-neutral. `test_read_shape_mirrors_for_higher_metrics` asserts exact
  mirror symmetry — a `lower` metric's deltas and a `higher` metric's negated deltas must name the same shapes —
  because a raw-sign vocabulary fails **silently** on those 115 metrics, returning "no shape" rather than an error.
- Accumulative-metric semantics: `src/data/common/time_series_data_processor.rs:130`
  (`add_accumulative_data_point`) and `:189` (`get_delta_and_set_previous_value`) — the **first sample is forced
  to 0** (`ignore_first_accumulative_value: true`, `:73`) and a **decreasing sample returns `None`**, producing a
  gap rather than a negative value.
- Data types with **no analytical rules** (statistical findings are their only automated signal, and only for the
  time-series ones): `processes`, `diskstats`, `interrupts`, `numastat`, `memalloc`, `sysctl`, `hotline`,
  `perf_profile`, `aperf_stats`, `aperf_runlog`. See `../INDEX.md` § "Data types with NO analytical rules".
- Related: `../INDEX.md` (§ "The two finding families", § "Score scale"), `../SCHEMA.md`, and the 51 analytical
  playbooks — in particular the validity gates `../meminfo/inconsistent-physical-memory.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`, `../systeminfo/kernel-version-mismatch.md`,
  `../java_profile/jvm-version-comparison.md`,
  `../netstat/inconsistent-inbound-network-traffic.md`,
  `../netstat/inconsistent-outbound-network-traffic.md`.
