---
rule_name: Inconsistent Physical Memory
data_type: meminfo
data_key: MemTotal
template: time_series_stat_run_comparison
condition: "abs(delta_avg(MemTotal)) >= 0.1"
base_score: Critical
score_sign: negative
requires_comparison: true
aperf_message: "Different amount of total physical memory could result in significant performance discrepancy."
source: src/analytics/rules/meminfo.rs:11
---

# Inconsistent Physical Memory

## What fired

The **average** of `MemTotal` in this run differs from the base run by **10% or more in either direction**
(`abs: true`). `MemTotal` is "Total amount of physical memory available to the system including memory used by
kernel and applications" (`data-descriptions.ts`, `desired: "higher"`).

Base score `Critical` (**−256**), the most severe score aperf defines. Comparison-only: it cannot fire on a
single-run report.

**This is a validity gate, not a performance finding.** It does not say the run was slow. It says **the two
runs were taken on machines with different amounts of RAM**, so every memory-derived comparison in the report
— page cache behaviour, fault rates, available memory, cache-miss rates, and quite possibly CPU and network
metrics too — is comparing different hardware. Resolve this before reading anything else in a comparison
report.

## Reasoning

**`MemTotal` is a hardware constant, not a workload metric.** It is read from `/proc/meminfo` once per
interval and does not move during a run. Everything a workload does — allocating, freeing, caching, swapping —
changes `MemFree`, `MemAvailable`, `Cached`, and `AnonPages`, and leaves `MemTotal` untouched. So a difference
between runs cannot have been caused by the workload. **Something about the machine or its boot configuration
changed.** That is why the rule earns `Critical` while the other `meminfo` rule earns only `Poor`.

**Why 10% and why in both directions.** `MemTotal` is not perfectly stable across boots of the same instance
type: the kernel subtracts its own reserved regions, and firmware/hypervisor overhead varies slightly between
kernel versions and generations. Those differences are fractions of a percent to a couple of percent. The 10%
threshold is set well above that noise floor so that only a genuine hardware or boot-configuration change
fires. `abs: true` because the direction does not matter — **more RAM invalidates a comparison exactly as
thoroughly as less RAM does.** A run with twice the memory will show a fuller page cache, fewer major faults,
and less reclaim, and none of that is attributable to the code under test.

**The powers-of-two fingerprint — the most useful diagnostic here.** EC2 instance sizes step memory in powers
of two, and families step memory-per-vCPU in powers of two as well (`c` → `m` → `r` is 2 GiB → 4 GiB → 8 GiB
per vCPU). So a genuine instance mismatch produces a ratio very close to **1.0 (2×), 3.0 (4×), or 7.0 (8×)** —
never something in between. **A ratio between 0.1 and 0.9 is almost never an instance-size difference.** It
points instead at a boot-time carve-out on otherwise identical hardware: `mem=` or `memmap` kernel parameters,
a `crashkernel`/kdump reservation, a CMA reservation, a device or accelerator carve-out, or in rare cases a
hot-plug/ballooning difference. That distinction — *different machine* versus *same machine, different boot
configuration* — determines whether you re-run or fix the host image.

**Instance size couples memory to everything else.** Because EC2 scales vCPU count, memory, network bandwidth,
and EBS bandwidth together within a family, a `MemTotal` mismatch caused by a size difference means **the
entire machine differs**. Expect `Inconsistent Number of CPUs` to fire alongside it. If it does *not* fire,
the vCPU count matched while the memory did not — which means either a family change at the same size
(`c7g.4xlarge` vs `m7g.4xlarge`) or a boot-configuration difference, both worth knowing precisely.

**This finding disables the other `meminfo` rule.** `Reduced Memory Availability` carries the explicit caveat
*"(if the total memory is consistent between runs)"* in its own message. When this rule fires, that caveat is
violated: 10% less available memory on a machine with half the RAM is arithmetic, not pressure. **Read this
finding first and discount that one accordingly.**

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({cur_value}) is {pct_delta} {base_run} ({base_value}).
```

For this rule:

```
The average in aperf_record_new (68.71G) is 100% greater than aperf_record_base (34.36G).
```

Four things to know:

1. **The values are in bytes, not KiB and not GiB.** `parse_meminfo` multiplies every `kB` value by 1024, so a
   32 GiB machine reports `34.36G` (34,359,738,368 bytes → `formatted_number_string` divides by 1e9). **The
   number looks about 7.4% larger than the marketed GiB figure** because the suffix is decimal G while the
   instance spec is binary GiB. Divide by 1.0737 to recover GiB. Do not read `34.36G` as "34 GiB and therefore
   a mismatch".
2. **The percentage in the text is signed; the score uses the absolute value.** `delta_ratio_to_percentage_string`
   renders the *original* ratio, so the text tells you which run had more memory. The score cannot.
3. **Values are truncated to two decimals**, not rounded.
4. The finding is keyed on `MemTotal` and appears under that metric.

Score math — `compute_finding_score(abs_ratio, 0.1, −256)`, general branch, `delta = abs_ratio/0.1`:

| abs ratio | meaning | score |
|---|---|---|
| 0.10 | exactly 10% — **fires** (`GreaterEqual`) | **−256.00** |
| 0.11 | 11% | −281.60 |
| 0.125 | 12.5% | −320.00 |
| 0.15 | 15% | −384.00 |
| 0.20 | 20% | −512.00 |
| 0.25 | 25% | −640.00 |
| 0.50 | 50% — **not** a size step | −1280.00 |
| **1.00** | **2× memory — one size step, or `c`→`m`** | **−2560.00** |
| **3.00** | **4× memory — two size steps, or `c`→`r`** | **−7680.00** |
| **7.00** | **8× memory — three size steps** | **−17920.00** |

Two notes on the score:

- **The zero trap does not apply** (threshold is 0.1, not 0.0), and the `value == 0.0` branch is unreachable:
  if the averages are equal the ratio is 0.0 and `0.0 >= 0.1` is false, so the rule never fires with a zero
  value.
- Because the base score is already −256, this finding **dominates every score-ordered list it appears in**.
  That is intentional — it is the finding that tells you the comparison is invalid.

**A ratio of exactly 1.0 can also mean the base run's `MemTotal` was 0.** The template substitutes
`original_delta_ratio = 1.0` when `base_stat == 0.0` ("treat current stat as 100% larger"). For `MemTotal` that
would mean the base run collected no `meminfo` data at all — a collection failure, not a hardware difference.
Check that the base run's `meminfo` section is populated before concluding "2× the memory".

## Interpretation

**First, classify the ratio:**

| Observed ratio | Reading |
|---|---|
| **≈1.0, 3.0, or 7.0** | **Different instance size or family.** The runs are on different machines. Expect `Inconsistent Number of CPUs` too |
| 0.1–0.9, not a power-of-two step | **Same-class hardware, different boot configuration.** Look for `mem=`/`memmap`, `crashkernel`, CMA, or a device carve-out |
| ≈1.0 **and** base `meminfo` empty | **Collection failure in the base run**, not a memory difference — the template substitutes ratio 1.0 for a zero base |
| Very large (≫7.0) | Wildly different machines — likely a laptop/dev box versus an instance, or the wrong run selected as base |

**Then check what else moved:**

| Evidence | Reading |
|---|---|
| **`Inconsistent Number of CPUs` also fired** | **Instance size differs.** Whole machine changed; the comparison is not salvageable. Re-run on matched instances |
| CPU count matched, memory differs | **Family change at the same size** (`c` ↔ `m` ↔ `r`), or a boot-time reservation. Memory-per-vCPU differs, which changes cache and page-cache behaviour |
| `Kernel Version Mismatch` also fired | Two variables at once. Different kernels also reserve slightly different amounts — but not 10% |
| `MemTotal` **series is flat** in both runs (std 0) | Normal. `MemTotal` is a constant; the average is exact |
| `MemTotal` **varies within a run** | Memory hot-plug or ballooning — rare and worth investigating on its own |
| `Hugepagesize`, `HugePages_Total` differ | Huge-page configuration differs. Does not usually move `MemTotal`, but changes everything downstream |
| Instance types in `systeminfo` are identical | **The boot configuration differs, not the hardware.** The host image is the thing to fix |

**Downstream findings to discount while this one is open:**

| Finding | Why it is unreliable now |
|---|---|
| **`Reduced Memory Availability`** | Its own message says "if the total memory is consistent between runs". It is not |
| `Increased Major Page Faults` / `Increased Minor Page Faults` | Fault rates track memory size directly. Less RAM ⇒ more faults, with no code change |
| `Excessive Page Fault Rate` | Absolute threshold on a different-sized machine |
| Every statistical (delta-vs-base) finding | All of them compare across different hardware |
| Any `perf_stat` cache or TLB rule | Cache and TLB sizes scale with instance size |

**Known false positives — strictly speaking, none:**

The rule measures a real, unambiguous fact and 10% is far above the noise floor. What varies is whether the
difference is *unexpected*:

- **A deliberate sizing experiment** — comparing `m7g.2xlarge` against `m7g.4xlarge` on purpose. The finding is
  correct and expected; it is telling you that memory-derived deltas are explained by the size change, which
  is exactly what you wanted to know.
- **Comparing against a stale base run** taken on last quarter's instance type.
- **The wrong base run selected.** The cheapest thing to check.
- **A base run with no `meminfo` data**, which manufactures a ratio of exactly 1.0.

**A real blind spot in the other direction:** `MemTotal` comes from the host's `/proc/meminfo`. **A cgroup or
container memory limit does not appear here.** Two runs can show identical `MemTotal` while the workload was
capped at 4 GiB in one and 16 GiB in the other, and this rule stays silent. aperf collects no cgroup limits, so
that must be verified out of band.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **Instance type, vCPU count, memory size** | `systeminfo` | **Do this first.** Names the machines directly and settles size-versus-boot-config in one step |
| **`Inconsistent Number of CPUs`** | `systeminfo` | Whether the whole instance differs or only memory |
| `Kernel Version Mismatch` | `systeminfo` | A second confounding variable in the same comparison |
| Kernel command line (`mem=`, `memmap`, `crashkernel`, `cma=`) | out of band / `aperf_runlog` | The boot-time carve-outs that explain a non-power-of-two ratio. **aperf does not collect the cmdline** |
| `MemTotal` **series shape and `std`** | `meminfo` | Should be flat with std 0. Movement means hot-plug or ballooning |
| `MemFree`, `MemAvailable`, `Cached`, `AnonPages` | `meminfo` | How the different memory sizes actually got used |
| `HugePages_Total`, `Hugepagesize`, `Hugetlb`, `CmaTotal` | `meminfo` | Reserved pools that differ between hosts |
| `MemAvailable` and `Reduced Memory Availability` | `meminfo` | **Discount that finding** while this one is open |
| `pgmajfault`, `pgfault`, `pgsteal_*`, `pswpin` | `vmstat` | Fault and reclaim differences that are explained by the memory-size difference, not by the code |
| `cpu_utilization` (all series) | `cpu_utilization` | If vCPU counts differ, every per-CPU comparison is invalid too |
| Cache and TLB counters | `perf_stat` | Cache sizes scale with instance size; those rules are unreliable now |
| Network and EBS throughput | `ena_stat`, `diskstats` | Bandwidth allowances scale with instance size as well |
| cgroup/container memory limits | out of band | **Not collected by aperf**, and invisible to this rule |

## Guidance

Ordered. **Steps 1–3 resolve essentially every firing.**

1. **Read `systeminfo` for both runs and compare instance type, vCPU count, and memory size.** This finding is
   a statement about hardware; `systeminfo` names the hardware. One look usually ends the investigation.

2. **Confirm the base run is the one you meant to compare against.** A stale or mis-selected base run is the
   single most common cause, and the cheapest to rule out. Also confirm the base run's `meminfo` section is
   populated — an empty base manufactures a ratio of exactly 1.0 via the zero-base substitution.

3. **Classify the ratio.** ≈1.0/3.0/7.0 ⇒ **different instance size or family**; anything between 0.1 and 0.9
   ⇒ **same hardware class, different boot configuration**. Check `Inconsistent Number of CPUs` to confirm
   which.

4. **If it is a size or family difference: re-run on matched instances.** There is no analysis that recovers a
   valid comparison from different-sized machines. Stop reading the rest of the comparison report until you
   have matched runs — in particular, do not attribute any fault-rate, page-cache, or cache-miss delta to the
   code under test.

5. **If the instance types match but `MemTotal` does not, treat it as a host-image defect.** Diff the kernel
   command line between the two hosts for `mem=`, `memmap`, `crashkernel`/kdump, `cma=`, and huge-page boot
   reservations, and diff any device or accelerator carve-outs. Fix the image rather than the analysis; aperf
   does not collect the cmdline, so this is out-of-band work.

6. **Explicitly discount `Reduced Memory Availability`** if it also fired. Its message assumes consistent total
   memory, and that assumption is broken. The same applies to every fault-rate and reclaim comparison.

7. **If the sizing difference was deliberate, record it and move on.** The finding is doing its job: it is
   telling you that memory-derived deltas in this report are attributable to the size change. Read the
   *absolute* values per run instead of the deltas.

8. **Verify cgroup and container memory limits out of band.** `MemTotal` is the host's, so a limit difference
   is invisible to this rule — and it produces exactly the symptoms this finding is meant to catch.

9. **Once the runs are matched, expect this finding to disappear entirely.** It has no tuning knob and no
   partial resolution: either the machines have the same RAM or they do not.

## Priority and execution risk

**Priority: P0 — Blocking** when the delta reflects different hardware. **P1** when `Instance Type` is identical
and the delta is therefore a *configuration* difference (reserved memory), because that is a real, fixable
finding rather than an invalid comparison.

**Execution risk: R4 — Infrastructure change** for the hardware case; **R1–R2** for the configuration case
(hugepage reservation, `crashkernel`, GPU carve-out are boot-time or reversible settings).

Unlike the `CPUs` gate, this one is **scaled**, so the score does carry magnitude — see the table below.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `|avg(MemTotal) delta| >= 10%` versus the base run.

```
STEP 1 — Parse the observed values.
  Format: The avg in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).
  Values carry T/G/M/K suffixes at 2 dp — parse `61.00G` back to a number.
  Score scales: 10% -> -256, 20% -> -512, 50% -> -1280, 100% -> -2560.

  IF the delta reads exactly `100.00% greater than`
  THEN → AMBIGUOUS. `base_stat == 0.0` is hardcoded to a delta ratio of 1.0 (P2, R0)
       → verify: if the base value prints as 0, meminfo collection failed in the
         base run — this is not a memory difference at all

STEP 2 — MANDATORY manual check: `Instance Type`.
  IF `Instance Type` DIFFERS
  THEN → hardware difference. STOP, re-run matched (P0, R4)
       → note MemTotal is USABLE memory, always somewhat below the advertised
         instance memory (firmware and kernel reservations), so a small delta
         can accompany the same nominal size
  IF `Instance Type` is IDENTICAL
  THEN → this is a CONFIGURATION difference, and a genuinely useful finding (P1, R0)
       → the remediation risk is set in STEP 3, which is where the reservation is
         actually identified; classifying it here changes nothing yet
       → continue to STEP 3

STEP 3 — Size the configuration difference (Instance Type identical).
  IF |delta| is 10-15%
  THEN → most likely reserved memory: hugepage preallocation (`hugepages=`),
         `crashkernel=`, a GPU/accelerator carve-out, or a memory-hotplug difference
         (P1, R1)
       → verify: check `kernel_config` and the huge-page findings; aperf does NOT
         collect /proc/meminfo's HugePages_Total as a gate, so read it manually
  IF |delta| is 15-50%
  THEN → suspect a large static reservation or a NUMA node offline (P1, R4)
       → verify: `numastat` (NO analytical rules — read manually) will show
         node count and per-node totals
  IF |delta| > 50% with identical Instance Type
  THEN → almost certainly a collection or environment defect, not a real machine
         (P1, R0) — e.g. one run inside a memory-limited container/VM

STEP 4 — Direction matters for what follows.
  IF the compared run has LESS memory
  THEN → expect `Reduced Memory Availability`, page-fault findings, and cache-miss
         findings to fire downstream as CONSEQUENCES, not independent problems (P0, R0)
       → do not remediate those separately until memory is matched
  IF the compared run has MORE memory
  THEN → expect page-cache effects to FLATTER the compared run: fewer major faults,
         better apparent I/O. An "improvement" here may be entirely memory (P0, R0)

STEP 5 — What survives?
  VALID  : configuration findings (THP, ENA Express, tiered compilation)
  VOID   : all vmstat/meminfo pressure findings, cache and TLB miss comparisons,
           the statistical findings table for any memory-sensitive metric
  CAUTION: `MemTotal` is collected as a TIME SERIES, so the rule takes its average.
           A varying MemTotal within a run indicates memory hotplug or ballooning —
           check the metric graph, not just the average.

INSUFFICIENT DATA
  IF the base run lacks the `MemTotal` metric
  THEN → the rule returned early with a debug log and produced NO finding (P1, R0)
```

## Runtime-specific consequences

Total physical memory feeds runtime heap ergonomics directly. A memory delta silently reconfigures all four
runtimes, so an apparent GC or allocation regression may be pure sizing:

| Runtime | What auto-scales with total memory | Consequence |
|---|---|---|
| **Java** | Default max heap is a *fraction* of physical memory (`MaxRAMPercentage`, historically ¼ of RAM). Also selects the GC and whether compressed oops apply near the 32 GiB boundary | Two runs on different-memory hosts run **different heap sizes and possibly a different GC**. Crossing the ~32 GiB compressed-oops boundary changes object layout and cache behaviour (P1, R2 to pin with explicit `-Xmx`) |
| **.NET** | `GCHeapHardLimit` defaults to a percentage of available memory (cgroup-aware); Server GC heap sizing | Different heap ceiling and GC aggressiveness. Pin `DOTNET_GCHeapHardLimit` for a valid comparison (P1, R2) |
| **Python** | No heap ergonomics, but `mmap`/`brk` allocator behaviour and page-cache availability shift | Effects show up as page-fault and cache-miss deltas rather than allocator changes |
| **Perl** | No heap ergonomics. Preforking servers benefit from copy-on-write, which is page-cache and memory sensitive | Worker memory footprint appears to change without any code change |

**For Java and .NET, always pin the heap explicitly (`-Xmx` / `DOTNET_GCHeapHardLimit`) before comparing runs on
different-memory hosts** — both R2, restart-only and fully revertible. Otherwise the comparison includes an
uncontrolled heap-size variable, and the 32 GiB compressed-oops boundary in particular can produce a
double-digit throughput difference from nothing but memory sizing.

## Architecture-specific considerations

`MemTotal` is architecture-independent as a quantity, but two architecture-linked factors change how a given
delta should be read. Confirm architecture from `pmu_config.json` in each run
([ARCHITECTURE.md](../ARCHITECTURE.md) §1).

**Page size is the one that bites.** Amazon Linux on aarch64 ships a 64 KiB base page in some kernel builds
while x86_64 uses 4 KiB. A larger base page changes kernel memory accounting and rounds reserved regions up, so
a genuinely identically-sized pair of instances can show a small `MemTotal` delta purely from page-size
differences. aperf does **not** collect the page size — infer it or capture `getconf PAGESIZE` manually.

| Observed | Reading | Action |
|---|---|---|
| Delta 10–15%, `Instance Type` identical, architectures identical | Reserved-memory configuration: hugepage preallocation, `crashkernel`, GPU carve-out | P1, R0 to diagnose |
| Delta 10–15%, architectures **differ** | Likely page-size and kernel-reservation differences, not a genuine capacity change | Verify `Instance Type` sizes match; if they do, do not treat this as a capacity finding (P2, R0) |
| Delta > 15%, architectures differ | Different instance size *and* architecture | Two confounded variables (P0, R4) |

**Cross-architecture memory-pressure comparison is confounded twice over.** Beyond `MemTotal`, a 64 KiB base
page changes fault counts and TLB behaviour, so `vmstat` fault rates and the `data-tlb-*` findings are not
comparable x86↔arm64 even when `MemTotal` matches exactly.

Runtime notes that interact with architecture:

- **Java** — the ~32 GiB compressed-oops boundary is architecture-independent, but the **default thread stack
  is 2 MB on aarch64 vs 1 MB on x86_64**, so a thread-heavy app has a materially larger baseline footprint on
  arm64 before any heap tuning. With THP set to `always` the full 2 MB can be committed per thread; `madvise`
  mitigates it.
- **.NET** — `DOTNET_GCHeapHardLimit` and the cgroup-derived limits behave identically across architectures;
  the R2R image size differs, which affects RSS but not `MemTotal`.
- **Python / Perl** — allocator `mmap` thresholds interact with the base page size; arena behaviour differs on a
  64 KiB page.

## Verification

Re-run on matched instance types and confirm the finding disappears. If `Instance Type` is identical and the
delta persists, it is a reserved-memory or NUMA configuration difference — quantify it against
`/proc/meminfo`'s `HugePages_Total` and `numastat` directly, since aperf gates on neither.

## Do not

- **Do not read this as a performance finding.** It says the comparison is invalid, not that the run was slow.
- **Do not read the values as GiB.** They are bytes; a 32 GiB machine reports `34.36G`. Divide by 1.0737.
- **Do not attribute any memory-derived delta to the code** while this is open — fault rates, page-cache
  behaviour, reclaim, and cache-miss rates all track memory size.
- **Do not trust `Reduced Memory Availability`** here. Its own message conditions on total memory being
  consistent.
- **Do not assume a 0.5 ratio is an instance-size difference.** EC2 memory steps in powers of two; 50% points
  at a boot-time carve-out on the same hardware class.
- **Do not conclude "2× the memory" without checking the base run has `meminfo` data.** A zero base is
  substituted with a ratio of exactly 1.0.
- **Do not expect the score to tell you the direction.** The score uses the absolute ratio; only the
  description text is signed.
- **Do not look for a cause inside the workload.** `MemTotal` is a constant the workload cannot influence.
- **Do not assume matching `MemTotal` means matching available memory** — cgroup and container limits are
  invisible here.
- **Do not tune anything.** The fix is matched hardware or a corrected host image.

## References

- Rule definition: `src/analytics/rules/meminfo.rs:11` — `metric: "MemTotal"`, `stat: Stat::Average`,
  `comparator: Comparator::GreaterEqual`, `abs: true`, `delta_ratio: 0.1`, `score: Score::Critical`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — skips the base run,
  returns early if the base run lacks the metric, substitutes `original_delta_ratio = 1.0` when
  `base_stat == 0.0`, applies `abs()` to the comparison ratio only, and renders the **signed** ratio in the
  description.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Critical = −256`,
  `src/analytics/mod.rs:147`.
- Formatting: `formatted_number_string`, `src/computations/mod.rs:176` (K/M/G/T, **truncated** to 2 decimals);
  `delta_ratio_to_percentage_string`, `src/computations/mod.rs:162`.
- **Unit conversion:** `parse_meminfo`, `src/data/meminfo.rs:57` — `kB`/`KiB` values are multiplied by 1024,
  so **all `meminfo` metrics are in bytes**; `defaultUnit: "Bytes"` in the frontend.
- Processing: `src/data/meminfo.rs` — every metric via `add_data_point` (gauges, no delta processing), one
  `value` series per metric under `time_series_data_processor_with_custom_aggregate!`, so **no auto-generated
  `average` series**; metric order preserved from the first sample via
  `get_time_series_data_with_metric_name_order`.
- Metric semantics: `MemTotal` in `src/report_frontend/src/definitions/data-descriptions.ts:1026`
  (`desired: "higher"`).
- Related playbooks: `reduced-memory-availability.md`, `../systeminfo/inconsistent-number-of-cpus.md`,
  `../systeminfo/kernel-version-mismatch.md`, `../vmstat/increased-major-page-faults.md`,
  `../vmstat/excessive-page-fault-rate.md`.
- [proc_meminfo(5)](https://man7.org/linux/man-pages/man5/proc_meminfo.5.html)
- [Amazon EC2 instance types](https://aws.amazon.com/ec2/instance-types/)
