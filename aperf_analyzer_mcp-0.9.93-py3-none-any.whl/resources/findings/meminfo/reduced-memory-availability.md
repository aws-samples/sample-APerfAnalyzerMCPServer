---
rule_name: Reduced Memory Availability
data_type: meminfo
data_key: MemAvailable
template: time_series_stat_run_comparison
condition: "delta_avg(MemAvailable) <= -0.1"
base_score: Poor
score_sign: negative
requires_comparison: true
aperf_message: "The system is under a higher memory pressure (if the total memory is consistent between runs)."
source: src/analytics/rules/meminfo.rs:21
---

# Reduced Memory Availability

## What fired

The **average** of `MemAvailable` in this run is **at least 10% lower** than in the base run. Directional
(`abs: false`, threshold **−0.1**, comparator `LessEqual`) — **a run with *more* available memory never fires
this rule.** `MemAvailable` is "Estimate of memory available for starting new applications without causing
excessive swapping" (`data-descriptions.ts`, `desired: "higher"`).

Base score `Poor` (**−16**). Comparison-only: it cannot fire on a single-run report.

**The rule's own message carries a precondition: *"(if the total memory is consistent between runs)"*.** Check
`Inconsistent Physical Memory` before reading anything else here. If that fired, this finding is arithmetic
rather than pressure and should be discarded.

## The processing caveat — a bounded score and a rule that cannot fire against zero

Two arithmetic properties make this rule behave unlike every other aperf comparison rule, and both matter for
how you read it.

**1. The score has a hard floor at −160.** The score is `(ratio / −0.1) × −16` with
`ratio = (cur − base)/base`, and since `MemAvailable` can never go below 0, **the ratio cannot go below
−1.0**. So the entire reachable score range is **−16 to −160**:

| ratio | headroom left | score |
|---|---|---|
| −0.10 | 90% | −16.00 — the tripwire |
| −0.50 | half | −80.00 |
| −0.90 | a tenth | −144.00 |
| **−1.00** | **none** | **−160.00 — the floor** |

Every other comparison rule in aperf is unbounded (a 10× move scores 10× worse). This one saturates, so
**−160 is a categorical statement — "`MemAvailable` reached zero" — not "ten times worse than −16".** A
consequence for triage: this finding **can never outrank** an unbounded rule like
`Increased Major Page Faults` at 3× (−160.00) or beyond, even at total memory exhaustion. Its score is not a
severity, it is a percentage in disguise: `ratio = |score| × 0.1 / 16`.

**2. The rule cannot fire when the base run had zero available memory.**
`time_series_stat_run_comparison` substitutes `original_delta_ratio = 1.0` when `base_stat == 0.0`, and
`1.0 <= −0.1` is false. So **the worst possible baseline produces silence.** Compare against a run that was
itself completely starved and no finding appears — not a mild one, none. Absence of this finding is never
evidence that the base run had comfortable headroom.

The same directionality means a run that *gained* headroom is silent too. Between them, these two properties
make the rule a strictly one-sided detector: it can tell you this run is worse than the base, and nothing
else.

## Reasoning

**What `MemAvailable` actually is.** It is not `MemFree`. The kernel computes it as an estimate of how much
memory a new workload could claim *without* pushing the system into swapping: free pages above the low
watermark, plus the reclaimable share of the page cache, plus reclaimable slab — each discounted by the
watermark it must leave behind. So `MemAvailable` stays high on a system whose RAM is "full" of page cache,
because that cache is cheap to give back. **It only falls when memory is held in ways the kernel cannot easily
reclaim**: anonymous pages, locked pages, huge-page reservations, unreclaimable slab, and dirty pages that must
be written before they can be dropped. That is precisely why it is the right metric for a pressure rule and why
comparing `MemFree` instead would produce constant false alarms.

**Why a 10% drop is worth `Poor` rather than `Critical`.** A 10% reduction in headroom is not itself a
performance problem — a system can lose 10% of a large `MemAvailable` and still be nowhere near reclaim. What
makes it worth flagging is that it is **a leading indicator**: reclaim, swapping, and major faults are
threshold behaviours, so a workload that has quietly consumed 10% more unreclaimable memory is closer to a
cliff it has not hit yet. The `Poor` weight says "this predicts trouble", not "this caused trouble". **The
confirmation always lives in `vmstat`** — `pgsteal_*`, `pgscan_*`, `allocstall_*`, `pswpin`, and
`workingset_refault_*` — never in `meminfo` alone.

**The most common benign cause, and it is very common: page cache warmth.** `MemAvailable` counts most of the
page cache as available, but not all of it — the estimate withholds the low watermark and treats dirty and
mapped pages conservatively. So two runs of the same workload on the same machine can differ by 10% in
`MemAvailable` purely because one ran on a freshly booted host with a cold cache and the other ran on a host
that had been serving traffic, or because a large file was read in one run and not the other. **Nothing was
consumed and nothing was leaked.** The discriminator is `AnonPages`: if it did not grow, the workload did not
take the memory.

**The genuinely serious cause: unreclaimable growth.** `AnonPages` up, `Mlocked` up, `SUnreclaim` up, or
`HugePages_Total`/`Hugetlb` up. Anonymous growth is the workload's own heap — a larger dataset, a bigger JVM
heap, more concurrent requests, or a leak. Locked memory is often deliberate (databases, RDMA registration —
note that EFA requires locked memory, so `EFA Errors` about `reg_mr_err` and this finding can share a root
cause). Unreclaimable slab growth is kernel-side and usually means many more sockets, dentries, or inodes in
flight. Huge-page reservations remove memory from `MemAvailable` outright even when unused. **These are the
cases where a 10% drop today becomes reclaim tomorrow.**

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({cur_value}) is {pct_delta} {base_run} ({base_value}).
```

For this rule:

```
The average in aperf_record_new (12.44G) is 55.20% less than aperf_record_base (27.78G).
```

Five things to know:

1. **The values are in bytes.** `parse_meminfo` multiplies `kB` values by 1024, then
   `formatted_number_string` divides by 1e9 for the `G` suffix. So the printed number is **decimal G, about
   7.4% larger than the GiB figure** you would see from `free -g`. Divide by 1.0737 for GiB.
2. **The percentage is always "less than"** when this rule fires — the comparator is `LessEqual` against a
   negative threshold, so a firing always means a decrease. If you see "greater than" on this rule name,
   something is wrong with your reading of the report.
3. **`abs: false`, so the score and the text agree in sign** here — unlike the `Inconsistent *` rules where the
   text is signed and the score is absolute.
4. **Values are truncated to two decimals**, not rounded.
5. `MemAvailable` is a **gauge sampled once per interval** (`add_data_point`, no delta processing), so the
   average is a true mean of instantaneous headroom over the run — a run that ended in memory trouble but
   started clean will average out. **Look at the series shape, not just the average.**

Score math — `compute_finding_score(ratio, −0.1, −16)`, general branch, `delta = ratio/−0.1`:

| ratio | reading | score |
|---|---|---|
| −0.10 | 10% less — **fires** (`LessEqual`) | **−16.00** |
| −0.11 | 11% less | −17.60 |
| −0.125 | 12.5% less | −20.00 |
| −0.15 | 15% less | −24.00 |
| −0.20 | 20% less | −32.00 |
| −0.25 | 25% less | −40.00 |
| −0.30 | 30% less | −48.00 |
| −0.50 | half the headroom | −80.00 |
| −0.75 | a quarter left | −120.00 |
| −0.90 | a tenth left | −144.00 |
| **−1.00** | **`MemAvailable` is zero — the floor** | **−160.00** |

Equal averages give ratio `0.0`, which does not fire, so the `value == 0.0` zero-doubling branch of
`compute_finding_score` is unreachable for this rule. The zero-*base* substitution is covered in the caveat
section above.

## Interpretation

**Gate on total memory first:**

| Evidence | Reading |
|---|---|
| **`Inconsistent Physical Memory` also fired** | **Discard this finding.** The message's precondition is violated — 10% less headroom on a smaller machine is arithmetic. Fix the hardware mismatch and re-run |
| `Inconsistent Number of CPUs` also fired | Different instance size ⇒ different memory. Same conclusion |
| `MemTotal` identical in both runs | The precondition holds. **The finding is meaningful** — proceed |

**Then decide whether it is pressure or just cache accounting:**

| Evidence | Reading |
|---|---|
| **`pgsteal_*`, `pgscan_*`, `allocstall_*` all near zero** | **No reclaim happened.** Headroom shrank but the system was never squeezed. Most firings land here — informational |
| `pgsteal_*`/`pgscan_*` rising | **Reclaim is active.** The pressure is real and already costing CPU |
| **`pswpin` non-zero** | **Swapping.** The most serious confirmation available. Expect `Major Page Faults Detected` too |
| `workingset_refault_file`/`_anon` rising | Pages reclaimed and immediately re-faulted — genuine thrash |
| `Increased Major Page Faults` also fired | **Pressure has already turned into latency.** Work that finding; this one is the explanation |
| `Excessive Page Fault Rate` also fired | Check whether the volume is majors (pressure) or minors (allocation churn) |
| `oom_kill` non-zero | Something was killed. Far past a headroom warning |

**Then attribute the loss — the check that names the cause:**

| Evidence | Reading |
|---|---|
| **`AnonPages` grew by roughly the amount `MemAvailable` fell** | **The workload took it.** Larger heap, larger dataset, more concurrency — or a leak. The clearest and most actionable case |
| `Cached` fell, `AnonPages` flat | Page cache was displaced or simply colder. **Usually benign** — nothing was consumed |
| `Cached` grew, `MemAvailable` fell anyway | Cache growth in forms the estimate discounts (dirty, mapped, shmem). Check `Dirty`, `Mapped`, `Shmem` |
| `Mlocked`/`Unevictable` grew | **Locked memory** — deliberate (databases, RDMA/EFA memory registration) or a `mlockall` change. Unreclaimable by definition |
| `SUnreclaim` grew | **Kernel-side growth** — more sockets, dentries, inodes, or a kernel-object leak. Cross-check `memalloc` slab data |
| `HugePages_Total`/`Hugetlb` grew | Reserved huge pages are removed from `MemAvailable` **even when unused** |
| `Shmem`/`ShmemHugePages` grew | tmpfs or shared segments. Often a `/dev/shm` file that outlived its writer |
| `Committed_AS` up but `AnonPages` flat | More memory *reserved* than *touched*. Not yet real consumption |
| Nothing grew, `MemAvailable` still fell | Suspect a co-tenant, agent, or build job — `meminfo` is system-wide |

**Then read the series shape:**

| Observation | Reading |
|---|---|
| `MemAvailable` **monotonically declining** across the run | **Growth or a leak.** The most concerning shape; the average understates the endpoint |
| Low from the start, then flat | Steady-state footprint difference — a configuration change, not a leak |
| Dips and recovers | Transient allocation peaks. Reclaim coped |
| Falls only at the end | The average dilutes it. **A run that ended in trouble can score mildly** |

**Known false positives — a large share of firings:**

- **Page-cache warmth differences.** Cold-boot host versus warm host, or a large file read in one run only.
  Nothing consumed. **The most common cause; `AnonPages` is the discriminator.**
- **Different total memory** — the message's own precondition. Always check `Inconsistent Physical Memory`.
- **Co-tenant activity.** `meminfo` is system-wide: an agent, build, or another container moves it.
- **Deliberate configuration change** — a larger JVM heap or cache size is supposed to reduce headroom.
- **Huge-page reservations** made between the runs: memory leaves `MemAvailable` whether or not it is used.
- **A base run with an unusually large page cache**, making a normal run look starved.
- **A short run** where the average is dominated by a startup transient.

**Two blind spots worth stating explicitly:**

- **A base run with `MemAvailable == 0` suppresses the finding entirely** — see the caveat section. The worst
  possible base run produces silence.
- **Cgroup and container memory limits are invisible.** `MemAvailable` is the host's. A workload capped by a
  cgroup can be in severe pressure — reclaiming and OOM-killing inside its cgroup — while host `MemAvailable`
  looks comfortable and this rule stays quiet. aperf collects no cgroup data.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`MemTotal` / `Inconsistent Physical Memory`** | `meminfo` | **Do this first.** The message's stated precondition. If total memory differs, discard this finding |
| **`AnonPages`** | `meminfo` | **The attribution check.** Growth matching the `MemAvailable` drop means the workload took it |
| `Cached`, `Buffers` | `meminfo` | Page-cache warmth — the most common benign explanation |
| `Mlocked`, `Unevictable` | `meminfo` | Locked memory, unreclaimable by definition. Note EFA/RDMA registration locks memory |
| `SUnreclaim`, `SReclaimable`, `Slab`, `KReclaimable` | `meminfo` | Kernel-side growth versus reclaimable slab |
| `HugePages_Total`, `Hugetlb`, `HugePages_Free`, `Hugepagesize` | `meminfo` | Reservations removed from `MemAvailable` even when idle |
| `Shmem`, `ShmemHugePages` | `meminfo` | tmpfs and shared segments |
| `Dirty`, `Writeback`, `Mapped` | `meminfo` | Cache the estimate discounts |
| `Committed_AS`, `CommitLimit` | `meminfo` | Reserved versus touched |
| `SwapTotal`, `SwapFree`, `SwapCached` | `meminfo` | Whether swap exists at all — it changes what "pressure" means |
| `MemAvailable` **series shape** | `meminfo` | Monotonic decline (leak) versus flat-low (configuration) versus end-loaded (average dilutes it) |
| **`pgsteal_*`, `pgscan_*`, `allocstall_*`** | `vmstat` | **Whether reclaim actually happened.** All quiet ⇒ headroom shrank without cost. **No rules — read manually** |
| **`pswpin`, `pswpout`** | `vmstat` | **The decisive pressure check.** Non-zero ⇒ swapping. **No rules — read manually** |
| `workingset_refault_anon`, `workingset_refault_file` | `vmstat` | Genuine thrash |
| `pgmajfault`, `pgfault` | `vmstat` | See `Major Page Faults Detected`, `Increased Major Page Faults` |
| `oom_kill`, `compact_stall`, `thp_fault_fallback` | `vmstat` | Kills, fragmentation, THP failure under pressure |
| Slab caches, buddy/pagetype info | `memalloc` | Which kernel caches grew. **No analytical rules — read manually** |
| **Top processes by memory** | `processes` | **Who took the memory** — the workload or a co-tenant. **No analytical rules — read manually** |
| `system` CPU, `iowait` | `cpu_utilization` | Reclaim shows as `system`; swap-in shows as `iowait` |
| Swap-device and page-in I/O | `diskstats` | Physical evidence of swapping. **No analytical rules — read manually** |
| Instance memory size, instance type | `systeminfo` | Context for whether the absolute headroom is small or large |
| Java allocation profile | `java_profile` | Requires `--profile-java`. The frontend's own guidance for `MemAvailable` points here |
| cgroup/container memory limits | out of band | **Not collected.** A capped workload can be starved while the host looks fine |

## Guidance

Ordered. **Steps 1–3 close most firings.**

1. **Check `Inconsistent Physical Memory` and `MemTotal`.** The rule's message states the precondition
   explicitly. If total memory differs, **this finding is arithmetic, not pressure** — discard it, fix the
   hardware mismatch, and re-run.

2. **Ask whether reclaim actually happened.** Read `pgsteal_*`, `pgscan_*`, `allocstall_*`, and `pswpin` in
   `vmstat`. **If they are all quiet, the system was never squeezed** — headroom shrank without cost, and that
   is a complete and legitimate resolution. Most firings end here.

3. **Attribute the loss with `AnonPages`.** If `AnonPages` grew by roughly what `MemAvailable` lost, the
   workload consumed it — go to step 5. If `AnonPages` is flat and `Cached` moved instead, this is **page-cache
   warmth**, the most common benign cause: nothing was consumed and nothing leaked.

4. **If neither anonymous nor cache memory explains it, check the unreclaimable holders in order:**
   `Mlocked`/`Unevictable` (locked memory — note that EFA/RDMA memory registration locks pages, so this can
   share a root cause with `EFA Errors`), `SUnreclaim` (kernel objects — cross-check `memalloc` slab data),
   `HugePages_Total`/`Hugetlb` (reservations subtract even when unused), and `Shmem` (tmpfs, `/dev/shm`).

5. **Read the series shape before believing the average.** A **monotonic decline** is growth or a leak and is
   the shape worth escalating; the average understates where the run ended. A run that only degraded at the end
   can score a mild −16 while finishing in real trouble.

6. **Confirm ownership.** `meminfo` is system-wide. Read `processes` to check the workload took the memory
   rather than a co-tenant, agent, or build job.

7. **Read the score as a bounded, not a scaled, signal.** The range is only **−16 to −160**, because the ratio
   floors at −1.0. **−160 means `MemAvailable` reached zero** — categorical, not "ten times worse than −16".

8. **If pressure is confirmed and the workload owns it, work the consequences, not the headroom.** Go to
   `Increased Major Page Faults` and `Major Page Faults Detected` — that is where the latency lives. Reducing
   footprint, right-sizing heaps and caches, or moving to a larger memory-per-vCPU family (`c` → `m` → `r`)
   are the levers.

9. **For Java workloads, use `--profile-java`** to get the allocation profile — the frontend's own optimization
   guidance for `MemAvailable` points at exactly this, and it is the only memory-allocation profiling aperf
   offers.

10. **Verify cgroup/container limits out of band.** A capped workload can be reclaiming and OOM-killing inside
    its cgroup while host `MemAvailable` looks fine and this rule stays silent.

11. **Remember the suppression case.** If the *base* run had `MemAvailable == 0`, the template forces the ratio
    to 1.0 and this rule cannot fire. Absence of the finding is not evidence of comfortable headroom in the
    base run.

## Priority and execution risk

**Priority: P4 — Informational** when `pgsteal_*`, `pgscan_*`, `allocstall_*`, and `pswpin` are all quiet,
which is where most firings land: headroom shrank, the system was never squeezed, and nothing was paid. It is
**P3 — Monitor** when `AnonPages` grew but no reclaim followed — a real footprint increase heading toward a
cliff it has not reached. It rises to **P2 — Investigate** when reclaim is active, or when the series declines
monotonically (growth or a leak, which the average understates). It is **P1 — Act now** when `pswpin` is
non-zero, when `allocstall_*` or `oom_kill` are non-zero, or when `Increased Major Page Faults` also fired —
in that last case **the major-fault finding is the one to work and this one is its explanation.** And it is
**P4** by a different route when `Inconsistent Physical Memory` fired: the rule's own message names that
precondition, and a violated precondition makes the finding arithmetic rather than a regression.

**Execution risk: R0 — Read-only** for the whole diagnosis. Every discriminator — the `vmstat` reclaim
counters, `AnonPages`, `Cached`, the unreclaimable holders, the series shape — is already in the two reports.
Remediation ranges wider than most: **R1** for `vm.swappiness`, `vm.min_free_kbytes`, or
`vm.vfs_cache_pressure` (single writes, revertible, gradual in effect); **R2** to bound the largest consumer
(`-Xmx`, `DOTNET_GCHeapHardLimit`, `innodb_buffer_pool_size`, worker count — restart-only and revertible);
**R2** also to release a huge-page reservation or a stale `/dev/shm` file, which returns memory immediately;
**R3** to reduce the resident data set in the application; and **R4** to move to a larger memory-per-vCPU
family (`c` → `m` → `r`). Note that **adding swap is not a fix** — it converts a memory shortfall into latency
rather than removing it — and removing swap from a host that needs it is **R5**, since it turns recoverable
stalls into OOM kills.

**What the score is worth: read it as a percentage, never as a severity.**
`time_series_stat_run_comparison` amplifies, so `compute_finding_score` makes the score exactly
`ratio / −0.1 × −16` and `ratio = |score| × 0.1 / 16` inverts it. But the floor at −160 means **this finding
can never outrank an unbounded rule** — `Increased Major Page Faults` at 3× already scores −160.00, matching
total memory exhaustion here. In a score-ordered list that is backwards for the case where headroom collapsed,
so read the ratio.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `delta_avg(MemAvailable) <= -0.1` versus the base run — two runs required, and this run is
not the base.

```
STEP 0 — MANDATORY manual check: the rule's OWN precondition.
  The aperf message reads "(if the total memory is consistent between runs)".
  IF `Inconsistent Physical Memory` fired, or MemTotal differs between the runs
  THEN → the precondition is VIOLATED. Ten percent less headroom on a smaller
         machine is arithmetic, not pressure. DISCARD this finding (P4, R0)
       → inconsistent-physical-memory.md, see that playbook
  IF `Inconsistent Number of CPUs` fired
  THEN → different instance size implies different memory. Same conclusion
         (P4, R0)
       → ../systeminfo/inconsistent-number-of-cpus.md, see that playbook
  ELSE MemTotal matches, so the finding is meaningful. Continue to STEP 1.

STEP 1 — Did reclaim actually happen? This closes most firings.
  MemAvailable is an ESTIMATE of headroom, not a measurement of pressure. The
  confirmation lives in vmstat, which has no rules for these counters.
  IF pgsteal_*, pgscan_*, allocstall_* and pswpin are ALL near zero
  THEN → NO reclaim. Headroom shrank but the system was never squeezed and
         nothing was paid. A complete and legitimate resolution, and the most
         common outcome (P4, R0)
       → continue to STEP 2 only if you need to know where the memory went
  IF pswpin is non-zero
  THEN → SWAPPING. The most serious confirmation available, and the pages being
         fetched are live anonymous memory (P1, R2)
       → bound the largest anonymous consumer; expect
         ../vmstat/major-page-faults-detected.md to have fired too
       → verify: pswpin returns to 0, workingset_refault_anon falls, and
         MemAvailable recovers toward the base run's average
  IF allocstall_* or oom_kill is non-zero
  THEN → pressure already passed graceful degradation: allocations stalled and
         processes were killed. Tuning will not recover this (P1, R4)
       → size up, or cut the resident set hard
       → verify: allocstall_* and oom_kill return to 0
  IF pgsteal_* / pgscan_* are rising, or workingset_refault_* is rising
  THEN → reclaim is ACTIVE and already costing CPU; refaults mean genuine thrash
         (P2, R0)
       → continue to STEP 2 to name the holder

STEP 2 — Attribute the loss. AnonPages is the discriminator.
  IF AnonPages grew by roughly the amount MemAvailable fell
  THEN → THE WORKLOAD TOOK IT: a larger heap, a larger data set, more
         concurrency, or a leak. The clearest and most actionable case (P2, R2)
       → cap the consumer (-Xmx, GCHeapHardLimit, buffer pool, worker count);
         restart-only and revertible
       → verify: MemAvailable returns to within noise of the base run's average
         and AnonPages falls by the same amount
  IF AnonPages is FLAT and Cached moved instead
  THEN → PAGE-CACHE WARMTH: a cold-boot host versus a warm one, or a large file
         read in one run only. Nothing was consumed and nothing leaked. The most
         common benign cause (P4, R0)
  IF Cached GREW while MemAvailable fell anyway
  THEN → cache in forms the estimate discounts. Check Dirty, Writeback, Mapped
         and Shmem — the estimate withholds them deliberately (P3, R0)
  IF Committed_AS grew while AnonPages stayed flat
  THEN → memory RESERVED but not touched. Not yet real consumption, though it
         constrains future allocation (P3, R0)
  ELSE continue to STEP 3.

STEP 3 — Neither anonymous nor cache: find the unreclaimable holder.
  IF Mlocked or Unevictable grew
  THEN → LOCKED memory, unreclaimable by definition. Often deliberate: databases
         pinning buffers, or RDMA/EFA memory registration (P2, R0)
       → ../efa_stat/efa-errors.md can share this root cause via reg_mr_err
  IF SUnreclaim grew
  THEN → KERNEL-SIDE growth: more sockets, dentries or inodes in flight, or a
         kernel-object leak. Not tunable from the application (P2, R0)
       → read `memalloc` slab data to name the cache; it has no rules of its own
  IF HugePages_Total or Hugetlb grew
  THEN → RESERVED huge pages leave MemAvailable EVEN WHEN UNUSED. Compare
         HugePages_Free: a large free count means the reservation is wasted
         (P2, R2)
       → release the unused reservation, which returns the memory immediately
       → verify: MemAvailable rises by Hugepagesize x the released count
  IF Shmem or ShmemHugePages grew
  THEN → tmpfs or shared segments, often a /dev/shm file that outlived its
         writer (P2, R2)
       → verify: removing the stale segment returns the memory at once
  IF nothing in meminfo grew but MemAvailable still fell
  THEN → a co-tenant, agent, sidecar or build job. meminfo is system-wide and
         has no per-process attribution (P3, R0)
       → read `processes` in both runs

STEP 4 — Read the SHAPE before believing the average.
  MemAvailable is a gauge, so the average is a true mean of instantaneous
  headroom — and it dilutes anything that happened late in the run.
  IF the series declines MONOTONICALLY across the run
  THEN → GROWTH OR A LEAK. The shape worth escalating, and the average
         UNDERSTATES where the run ended (P2, R3)
       → re-record over a longer --period to establish the slope, then reduce the
         resident data set at the source
       → verify: on the longer run the slope flattens after the fix, rather than
         the average merely improving
  IF MemAvailable is low from the start and then flat
  THEN → a steady-state footprint difference: a configuration change, not a leak
         (P3, R0)
  IF the series falls only at the END of the run
  THEN → the average dilutes it, so a run that FINISHED in real trouble can
         score a mild -16 (P2, R0)
  IF the series dips and recovers
  THEN → transient allocation peaks that reclaim absorbed (P4, R0)
  ELSE continue to STEP 5.

STEP 5 — Has the pressure already become latency?
  IF `Increased Major Page Faults` also fired
  THEN → pressure has ALREADY turned into latency. That finding is the one to
         work; this one is its explanation (P1, R0)
       → ../vmstat/increased-major-page-faults.md, see that playbook
  IF `Major Page Faults Detected` fired in this run
  THEN → storage-blocking faults exist. Read its score first: -0.00 is one fault
         and means nothing (P2, R0)
       → ../vmstat/major-page-faults-detected.md, see that playbook
  IF `Excessive Page Fault Rate` fired
  THEN → check whether the volume is majors (pressure, this finding's story) or
         minors (allocation churn, a different one) (P3, R0)
       → ../vmstat/excessive-page-fault-rate.md, see that playbook
  IF the workload is Java and the cause is anonymous growth
  THEN → aperf's own guidance for MemAvailable points at allocation profiling,
         which requires --profile-java and is the only memory-allocation
         profiling aperf offers (P2, R1)
       → verify: the allocation profile names the growing site, and capping or
         fixing it returns MemAvailable to the base run's level
  ELSE → headroom fell, no reclaim followed, and the holder is named. Record it
         and monitor the trend (P3, R0)

STEP 6 — What survives?
  VALID  : `Increased Major Page Faults` and `Major Page Faults Detected` — this
           finding EXPLAINS them rather than competing with them
  VALID  : the ratio, recoverable exactly as |score| x 0.1 / 16
  VALID  : the conclusion "no pressure" when the vmstat reclaim counters are all
           quiet. That is a real answer, not a failure to find one
  CAUTION: the average on any run whose series is end-loaded or monotonically
           declining. Read the shape
  CAUTION: the host view for any containerized workload. cgroup limits are
           INVISIBLE here and aperf collects no cgroup data
  CAUTION: attribution to the workload before reading `processes`
  VOID   : this finding entirely when `Inconsistent Physical Memory` fired. The
           rule's own message names that precondition
  VOID   : the score as a severity ranking. It floors at -160, so it can never
           outrank an unbounded rule even at total exhaustion
  VOID   : reading the printed values as GiB. They are bytes with a decimal G
           suffix — divide by 1.0737
  VOID   : any claim about the BASE run's headroom from this rule's silence. A
           zero base is substituted with ratio 1.0 and cannot fire

INSUFFICIENT DATA
  IF either run has fewer than ~5 samples
  THEN → the average is dominated by whatever the startup transient was doing,
         and no shape is determinable (P4, R1)
       → re-record both runs with a longer --period
       → verify: on the longer runs the shape resolves into declining, flat-low,
         or transient
  IF the report has only one run
  THEN → the rule COULD NOT FIRE; it needs a base run (P4, R0)
  IF MemAvailable is absent in the base run
  THEN → the template returns early with a debug! and nothing comparable exists.
         Kernels before 3.14 do not export it (P4, R0)
```

## Runtime-specific consequences

`MemAvailable` falls when memory is held unreclaimably, and **a managed runtime's heap is exactly that**:
anonymous, touched, and invisible to reclaim. So the runtime's memory configuration usually *is* the answer to
STEP 2, and the ceiling it enforces is what determines whether the drop is bounded or open-ended. Runtime is
not reported by aperf — infer it from `processes` ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3) and
treat the inference as a hint.

| Runtime | Why `MemAvailable` falls | What to check, and the lever |
|---|---|---|
| **Java** | The heap is anonymous memory the kernel cannot reclaim, and it **grows toward `-Xmx` and does not give back** unless the collector is configured to uncommit. Off-heap adds to it invisibly: metaspace, direct byte buffers, thread stacks, and the code cache all sit outside `-Xmx` | Sum `-Xmx` plus off-heap against `MemTotal`; `-XX:MaxRAMPercentage` if the container size changed between runs; `-XX:+ShenandoahUncommit` or G1's periodic GC to return memory; `-XX:+AlwaysPreTouch` makes the whole commitment visible from the first sample instead of creeping (P2, R2) |
| **.NET** | Server GC creates **one heap per core**, so the same application on a larger instance holds proportionally more anonymous memory — a vCPU difference alone moves this metric, which is what `Inconsistent Number of CPUs` gates | `DOTNET_GCHeapHardLimit` or `GCHeapHardLimitPercent` to bound it outright; `DOTNET_gcServer=0` on small instances to collapse the per-core heaps (P2, R2) |
| **Python** | No heap ceiling exists at all — the footprint is whatever the objects require, so growth is **open-ended** and a leak has nothing to stop it. Preforking multiplies it by worker count, and `mmap`-ed data sets show up as cache rather than anonymous | Count workers × per-worker RSS; recycle workers on a request limit so private growth is bounded; check whether the data set is `mmap`-ed (cache, reclaimable) or read into memory (anonymous, not) (P2, R2) |
| **Perl** | Long-lived interpreters retain arenas, so a preforking server's private footprint grows with worker **age** rather than load — meaning a longer-lived run legitimately shows less headroom with no configuration difference | Compare worker ages and recycling limits across the runs before attributing the drop to the change under test (P3, R2) |

**When the runtime cannot be established**, STEP 2 still holds: `AnonPages` growth matching the
`MemAvailable` drop means something's heap took it, and `processes` names which one.

## Architecture-specific considerations

The most common architecture-specific cause of this finding is a **migration that raised the anonymous
footprint without changing a line of code.** aarch64's default thread stack is 2 MB versus 1 MB on x86_64, and
with THP set to `always` the full 2 MB can be committed on first touch — so a service with a thousand threads
gains up to 2 GB of unreclaimable anonymous memory
([../ARCHITECTURE.md](../ARCHITECTURE.md) §4.1). **No aperf gate fires on an architecture change**
([../GATES.md](../GATES.md)), so nothing in the report tells you the comparison crossed architectures;
confirm it from `pmu_config.json` ([../ARCHITECTURE.md](../ARCHITECTURE.md) §1).

| Observed | Reading | Action |
|---|---|---|
| Headroom down **after an Intel→Graviton migration**, `AnonPages` up, thread count unchanged | **The 2 MB default stack**, amplified by THP `always`. The workload did not grow; its per-thread commitment did | Set THP to `madvise`, or tune `-Xss`/`Thread.stackSize`; both are revertible (P2, R2) |
| Headroom down where the aarch64 kernel uses **64 KiB base pages** | Page-granularity rounding inflates every allocation and every slab object; huge-page reservations are 512 MB rather than 2 MB, so a single reservation removes far more | Capture `getconf PAGESIZE` per run out of band — aperf collects neither page size nor huge-page size context (P2, R0) |
| Headroom down on an AMD instance with multiple NUMA nodes (NPS) | `MemAvailable` is host-wide and hides per-node exhaustion: one node can be full while the total looks comfortable, forcing remote allocation | Read `numastat` per node — it has **no analytical rules** ([../ARCHITECTURE.md](../ARCHITECTURE.md) §4.3) (P2, R0) |
| Headroom down with `Increased Major Page Faults` on the same architecture and kernel | The confounds are excluded and the two findings agree. **The clean, actionable case** | Work the major-fault playbook; this finding is the attribution (P1, R2) |

**Cross-architecture comparison of this ratio needs the page size and the thread-stack default captured out of
band.** Neither is in the report, and neither has a gate.

## Verification

**Predict before you check.** If the cause is anonymous growth, predict that `AnonPages` rose by
approximately the bytes `MemAvailable` lost — the two should nearly cancel, and a large residual means a
second holder you have not named yet. If the cause is page-cache warmth, predict that `AnonPages` is flat
*now*, before any change: that check costs nothing and disposes of the most common false positive outright.
If the cause is a huge-page reservation, predict that releasing it raises `MemAvailable` by exactly
`Hugepagesize` × the released count — an arithmetic prediction, so a mismatch means the reservation was not
the holder. And if this finding is paired with `Increased Major Page Faults`, verify the pair together:
headroom recovering while faults persist means you fixed the accounting and not the pressure.

## Do not

- **Do not read this as confirmed pressure.** It is a headroom delta. `pgsteal_*`, `pgscan_*`, and `pswpin`
  confirm pressure; `meminfo` alone cannot.
- **Do not ignore the message's precondition.** If `MemTotal` differs between runs, the finding is arithmetic.
- **Do not confuse `MemAvailable` with `MemFree`.** `MemAvailable` counts reclaimable cache and slab; a "full"
  system can have plenty available.
- **Do not read the values as GiB.** They are bytes rendered with a decimal `G` suffix — about 7.4% above the
  GiB figure. Divide by 1.0737.
- **Do not treat a page-cache difference as consumption.** Check `AnonPages` before blaming the workload.
- **Do not scale the score linearly, or rank it against unbounded rules.** It saturates at −160 when
  `MemAvailable` hits zero, which `Increased Major Page Faults` reaches at a mere 3×.
- **Do not trust the average alone.** A monotonic end-loaded decline scores mildly and matters most.
- **Do not expect the rule to flag a starved *base* run.** It is directional, and a zero base is substituted
  with ratio 1.0, which never fires.
- **Do not assume the host view covers the workload.** cgroup and container limits are invisible here.
- **Do not blame the workload without `processes`.** `meminfo` is system-wide.
- **Do not add swap as the fix.** Swapping converts a memory shortfall into latency; it does not remove it.
- **Do not overlook idle huge-page reservations.** They leave `MemAvailable` whether or not anything uses them
  — check `HugePages_Free` against `HugePages_Total`.

## References

- Rule definition: `src/analytics/rules/meminfo.rs:21` — `metric: "MemAvailable"`, `stat: Stat::Average`,
  `comparator: Comparator::LessEqual`, `abs: false`, `delta_ratio: -0.1`, `score: Score::Poor`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — skips the base run,
  **returns early with a `debug!` if the base run lacks the metric**, `continue`s if the current run lacks it,
  and substitutes `original_delta_ratio = 1.0` when `base_stat == 0.0` (**which makes this rule unable to fire
  against a zero base**); with `abs: false` the comparison, score, and description share the same signed ratio.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Poor = −16`,
  `src/analytics/mod.rs:147`. Ratio floors at −1.0 because `cur >= 0`, so the score floors at **−160**.
- Formatting: `formatted_number_string`, `src/computations/mod.rs:176` (K/M/G/T, **truncated** to 2 decimals);
  `delta_ratio_to_percentage_string`, `src/computations/mod.rs:162`.
- **Unit conversion:** `parse_meminfo`, `src/data/meminfo.rs:57` — the trailing colon is stripped and
  `kB`/`KiB` values are multiplied by 1024 (`MiB` by 1024², `GiB` by 1024³), so **all `meminfo` values are
  bytes**; `defaultUnit: "Bytes"`. Metric ordering is fixed from the **first** sample.
- Processing: `src/data/meminfo.rs` — all metrics via `add_data_point` (gauges, no delta processing, no
  first-sample suppression); one **`value`** series per metric (singular, unlike `vmstat`'s `values`), so
  **no auto-generated `average` series** and no fractional values.
- Default sampling: `--interval 1`, `--period 10` (`src/record.rs:35`, `:45`) — about 10 samples, so the
  average rests on ten instantaneous readings.
- Metric semantics: `MemAvailable` at `data-descriptions.ts:1059` (`desired: "higher"`, with
  `optimization: [MEMORY_USAGE_INVESTIGATION]` — **the only `meminfo` metric carrying an optimization
  guide**); `MemFree` :944, `Cached` :938, `AnonPages` :1167, `Mlocked` :1142, `SUnreclaim` :1020,
  `Committed_AS` :1002, `Shmem` :1048.
- Frontend guidance: `MEMORY_USAGE_INVESTIGATION`, `src/report_frontend/src/definitions/optimization-guides.ts:32`
  — "it is useful to exam the memory allocation profiles… APerf only supports memory allocation profiling for
  Java applications (enabled through `--profile-java`)".
- Related playbooks: `inconsistent-physical-memory.md`, `../vmstat/increased-major-page-faults.md`,
  `../vmstat/major-page-faults-detected.md`, `../vmstat/excessive-page-fault-rate.md`,
  `../vmstat/increased-minor-page-faults.md`, `../kernel_config/huge-page-disabled.md`,
  `../efa_stat/efa-errors.md`, `../systeminfo/inconsistent-number-of-cpus.md`.
- [proc_meminfo(5)](https://man7.org/linux/man-pages/man5/proc_meminfo.5.html)
- [`MemAvailable` estimation](https://www.kernel.org/doc/html/latest/filesystems/proc.html#meminfo)
- [Reclaim and `vm` tunables](https://docs.kernel.org/admin-guide/sysctl/vm.html)
