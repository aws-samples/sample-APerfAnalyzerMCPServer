---
rule_name: Excessive Exceptions
data_type: java_profile
data_key: <profiler key (JVM name)>
template: profile_stack_frame_threshold
condition: "exception-construction frames >= 5.0% of cpu profile samples"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "We recommend not to use Java exceptions as control flow, and to remove exceptions when they appear in the hot-code path. Overhead can be mitigated some by using the -XX:+OmitStackTraceInFastThrow JVM flag to allow the Java runtime to optimize the exception flow for some hot paths. The best solution is to avoid the exceptions as much as possible."
source: src/analytics/rules/java_profile.rs:18
---

# Excessive Exceptions

## What fired

**5% or more** of the JVM's `cpu` profile samples — counted over `ThreadState::AsyncDefault` only, using
**total** (inclusive) samples — landed in stack frames matching aperf's exception-construction regex:

```
java\.lang\.(Throwable\.(fillInStackTrace|getStackTrace|getOurStackTrace)|StackTraceElement\.<init>)
|\w+(\.\w+)*\.((\w*Exception|\w*Error|Throwable)\.<init>)
```

That is: `Throwable.fillInStackTrace`, `Throwable.getStackTrace`, `Throwable.getOurStackTrace`,
`StackTraceElement.<init>`, **or the constructor of any fully-qualified class whose simple name ends in
`Exception` or `Error`, or is `Throwable`**.

Base score `Critical` (**−256**), flat — the template inserts `self.score` directly, so **there is no score table**. A
5.01% finding and a 98% finding score identically; **the percentage in the description is the only magnitude signal.**
Single-run, and it fires **once per JVM** (per profiler key). **This is a real, measured cost — the strongest actionable
finding in aperf's Java rules**: unlike the two metadata rules in this data type, this one observed CPU samples, and
five percent of a JVM's CPU spent constructing exceptions is work that produces no output.

## The processing caveat — the percentage is inclusive, and it ran 26× the self time

Verified by running aperf's own JFR converter and its own `Profile::get_samples` over a recording of a workload that
throws `IllegalStateException` in a loop and calls `getStackTrace()` on each one (Corretto 25.0.3, async-profiler 4.4,
`asprof` invoked with aperf's exact argument list). The rule fired at **98.12%** — the same pattern measured with
`total_samples: false` gives **3.76%**:

| Measurement | Samples | % of the 797-sample `AsyncDefault` denominator |
|---|---|---|
| The rule as written (`total_samples: true`) | 782 | **98.12%** — fires |
| Same pattern, self samples only | 30 | 3.76% — **would not fire** |
| `*Exception`/`*Error`/`Throwable` `.<init>` alone, inclusive | 497 | 62.36% |
| `Throwable.fillInStackTrace` alone, inclusive | 493 | 61.86% |
| `Throwable.getStackTrace` alone, inclusive | 285 | 35.76% |
| `Throwable.getOurStackTrace` alone, inclusive | 283 | 35.51% — the lazy materialisation path |
| `StackTraceElement.<init>` alone | 0 | 0.00% — never appeared; the elements inline away |

**That 26× ratio is the most important number here.** The percentage is not "CPU spent in exception constructors"; it is
"CPU spent anywhere beneath an exception constructor or a stack-walk entry point". Both are legitimate readings of
exception cost, but a reader who takes 98% as "the JVM is executing constructor bytecode" will look for the wrong fix.
Two structural results follow, confirmed on the same archive:

- **The single regex does not double-count.** 497 + 285 = **782 exactly**, the aggregate. `dfs_sum_samples` stops
  descending on a full match when `total_samples: true`, so `fillInStackTrace` nested under a constructor is counted
  once, inside the constructor's total — which is why the number stays ≤ 100% despite aggregation.
- **A rule with two *nesting* elements would exceed 100%.** The aggregation fold is `acc + count` and the
  stop-descending guard is per element, so summing the constructor pattern (497) with `fillInStackTrace` (493) — provably
  its descendant, since the two-element pattern `[ctor, fillInStackTrace]` returns 493 — gives 990 against 797 =
  **124.22%**. This rule has one element and is safe; it is the template's failure mode.

## Reasoning

**Why exception construction is expensive, and why the regex targets constructors.** In Java the cost of an exception
is not in `throw` or `catch` — it is in **filling in the stack trace**, inside the `Throwable` constructor.
`Throwable.<init>` calls `fillInStackTrace()`, which walks the whole thread stack and materialises a
`StackTraceElement` per frame, so the cost is **proportional to stack depth**; framework-heavy stacks run hundreds of
frames deep, making one construction cost microseconds. That explains every element of the pattern: it matches
**constructors** (`<init>`) rather than throw sites because construction is where the money goes, and it matches
`fillInStackTrace`, `getStackTrace`, and `getOurStackTrace` because those are the stack-walking entry points —
`getStackTrace` also appears when code *reads* a trace it already has (logging), and `getOurStackTrace` is the lazy
path that converts the internal backtrace into `StackTraceElement[]` on first access. **So the rule catches both
creation and consumption**, and the measurement above shows both carrying real weight (62% and 36% inclusive).

**Why 5% is the right threshold.** Exceptions serving their intended purpose — signalling genuinely exceptional
conditions — should be rare enough to be invisible in a CPU profile. Reaching 5% means they are being constructed at a
rate proportional to the workload, which is the definition of **using exceptions as control flow**, and is why the
message leads with exactly that. At 5% the rule is not reporting an inefficiency, it is inferring an architectural
pattern from a profile; `Critical` reflects that this is almost always both real and fixable.

**Why `total_samples: true` matters, and the one way it misleads.** A matched frame contributes its **inclusive**
count — itself plus all descendants — and the DFS then stops descending, because descendants are already included.
That captures the whole cost of the constructor including `fillInStackTrace`, at the price of the 26× inflation over
self time documented above. The corollary to watch: **anything the constructor calls is attributed to the exception.**
A subclass whose constructor builds a message by concatenation, formats context, or looks up an error code has that
cost counted here — arguably correct, since it is incurred only because an exception was created, but it means the fix
may be "make the constructor cheap" rather than "throw fewer".

**Why `aggregate_occurences: true` changes what the description tells you.** With aggregation on, the template sums
all pattern counts and sets `matched_pattern` to `None`. The sum is trivial for a one-pattern rule, but the `None` is
visible: **the description prints the entire regex rather than the frame that actually matched.** It tells you *how
much*, never *which exception class* or *where*, so identifying the culprit requires the heatmap.

**Why only `ThreadState::AsyncDefault`, and the measured consequence.** Numerator and denominator are both restricted
to `AsyncDefault`, so the percentage is internally consistent. async-profiler's JFR tags samples by thread state:
`STATE_RUNNABLE` → `AsyncRunnable`, `STATE_SLEEPING` → `AsyncSleeping`, `STATE_DEFAULT` → `AsyncDefault`. Measured
across six real archives, **every `cpu` sample carries state id 3 (`AsyncDefault`) and nothing else** — so here the
restriction is a no-op and the empty-list fallback to all three states would change nothing. That matters because the
*other* two profile types differ, which is where the rule's scope is really decided (see the blind spots in
`Interpretation`).

**Why the frame regex is anchored less than it looks.** `get_samples` wraps each element as `^{frame}{suffix}$`, with
`suffix` = `(_\[(0|j|i|k|1|v)\])?` when `frame_type` is `None`. But the pattern contains a **top-level `|`**, and
alternation binds looser than the interpolated anchors, so it parses as `(^A) | (B$)` — **the two anchors land on
different branches**, making the `java.lang.Throwable.*` branch a *prefix* match (`Throwable.fillInStackTraceDepth`
and `StackTraceElement.<init>_[Q]` match, and `frame_type` is not enforced on it at all) and the `*Exception`/`*Error`
branch a *suffix* match (`int freeze<com.example.FooException.<init>` matches, and `--cstack vm` frames can carry such
text). Verified against the `regex` crate at the pinned version: 7 of 15 probe frames matched the as-written pattern
but not a fully-parenthesised equivalent; **on the measured archive both forms returned the identical 782 samples**,
so this is latent looseness, not an observed error. `frame_type: None` meaning "any frame type" is correct here —
exception constructors appear interpreted, C1-compiled, and JIT-compiled depending on heat — and because the pattern
is **single-element**, it matches a constructor **anywhere** in the tree.

**What the pattern misses, which matters more than what it over-matches.** The `\w*Exception|\w*Error` alternative
requires the **simple name to end in** `Exception` or `Error`, preceded by a dotted `\w` package prefix. Verified
misses: custom throwables breaking the convention (`com.example.ValidationFailure`, `RetryableCondition extends
RuntimeException`); **inner-class throwables** — `com.example.Service$TimeoutException.<init>` does not match, because
`$ ∉ \w` and no `.` immediately precedes the simple name; unqualified `Exception.<init>`; Scala's
`scala.util.control.NoStackTrace$class.fillInStackTrace`; and `Throwable.printStackTrace` / `addSuppressed`, both of
which touch traces. Conversely `java.lang.Error` subclasses like `StackOverflowError` and `AssertionError` **do**
match, and Kotlin throwables following the convention (`kotlin.NoWhenBranchMatchedException`) match fine. **So the
finding under-reports**: the misses are systematic and workload-correlated, the over-matches need unusual frames.

**The `OmitStackTraceInFastThrow` recommendation is much narrower than it sounds.** The flag is **already enabled by
default** in HotSpot, and applies only to a small set of **implicit, JVM-generated** exceptions —
`NullPointerException`, `ArithmeticException`, `ArrayIndexOutOfBoundsException`, `ClassCastException`,
`ArrayStoreException` — and only once the JIT has seen a throw site go hot, at which point it reuses a **preallocated
instance with an empty stack trace**. It does nothing for exceptions your code builds with `new`. So for **implicit**
exceptions much of the cost may already be suppressed, and high cost anyway means checking whether something
**disabled** it (`-XX:-OmitStackTraceInFastThrow`, frequently set deliberately so production NPEs keep their traces —
`jvmArguments` carries the answer, and it **does** reflect `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile`,
verified). For **explicitly constructed** exceptions the flag is irrelevant and the message's own closing sentence is
the operative one: *"The best solution is to avoid the exceptions as much as possible."* `GUIDANCE_MODEL.md`
classifies the flag as **R5**, because suppressing traces changes what your logs contain.

**The collection precondition that makes this rule mostly dormant.** All three `java_profile` rules read
`AperfData::Profile`, which exists only if `java_profiler_data_<pid>.json` was written at record time — and that
happens **only when `init_params.save_profile_events` is true**, i.e. only when `aperf record` was invoked with the
**hidden** `--save-profile-events` flag. The source says so: *"TODO: Guard the new profile processing logic by the
`save_profile_events` flag, so that the new flow is only executed in tests."* Without it, `java_profile` falls back to
`AperfData::Graph` (heatmaps only), `profiler_keys` returns empty, and **all three rules produce nothing at all.** So
**`--profile-java` alone is not sufficient**, and **the absence of this finding is not evidence that exceptions are
cheap** — it is the default state. The heatmaps render either way; only the rule engine is blind. When it does fire,
the finding is keyed by the **profiler key** — the deduped JVM name (`process_names.first()`, else `"unknown"`) with
`" (N)"` appended for duplicates, **not the PID**, so two JVMs on the same main class become `name` and `name (1)`.

## Reading the description

`profile_stack_frame_threshold` emits the format string below, then the concrete result — the pattern prints as
`[<regex>]` because `aggregate_occurences: true` sets `matched_pattern = None`:

```
Stack pattern {pattern} accounts for {pct:.2}% of samples in {profile_type} (threshold: {threshold:.2}%)

Stack pattern [java\.lang\.(Throwable\.(fillInStackTrace|getStackTrace|getOurStackTrace)|StackTraceElement\.<init>)|\w+(\.\w+)*\.((\w*Exception|\w*Error|Throwable)\.<init>)] accounts for 98.12% of samples in cpu (threshold: 5.00%)
```

Five things to know:

1. **The percentage is the only magnitude information you get.** The score is flat −256 regardless, so 5.01% and 98%
   are the same score and a very different problem — **read the number.**
2. **The percentage is inclusive, and measured ~26× the self time.** It is "CPU beneath an exception constructor or
   stack-walk entry point", not "CPU executing constructor bytecode". Do not translate it into instructions retired
   in `Throwable.<init>`.
3. **The pattern printed is the regex, not the matching frame** — with aggregation on there is no single pattern to
   name. **The description never tells you which exception class or which call site.**
4. **The percentage is of `AsyncDefault` `cpu` samples only**, a consistent numerator and denominator. Measured on
   real archives every `cpu` sample is `AsyncDefault`, so read it as "percent of on-CPU time in this JVM". Note that
   `{:.2}` rounds, unlike `f64_to_fixed_2`, which truncates — a cosmetic difference from most aperf numbers.
5. **One finding per JVM**, keyed by the deduped JVM name; expect one per affected JVM with its own percentage.

**No score table applies.** The template computes `percentage = (sample_count / total_samples) * 100.0` (or `0.0` when
`total_samples == 0`), tests `percentage >= self.threshold`, and inserts `self.score` verbatim, so
`compute_finding_score` is never called.

## Interpretation

**First, read the percentage — it is the whole magnitude signal:**

| Observed % of cpu samples | Reading |
|---|---|
| 5–10% | **Real but bounded.** Worth fixing; unlikely to be the dominant problem alone |
| 10–25% | **Significant.** A meaningful fraction of the JVM's CPU produces no output; usually one hot throw site |
| 25–50% | **Exceptions are the workload.** Almost certainly control flow in a hot path or a tight retry loop |
| 50–95% | **Pathological.** Suspect an exception inside a loop, recursive failure, or per-request trace logging |
| >95% | Measured at **98.12%** on a deliberate throw-in-a-loop workload. Nothing else is worth reading first |
| Just above 5.00% | Check profile duration and sample count — a short profile makes the percentage noisy |

**Then work out which mechanism is producing them:**

| Evidence | Reading |
|---|---|
| Heatmap shows `Throwable.<init>` / `fillInStackTrace` under application code | **Explicitly constructed exceptions.** `OmitStackTraceInFastThrow` will not help; fix the code |
| Heatmap shows `getStackTrace` / `getOurStackTrace` prominently | **Traces are being *read*, not just created** — typically logging. Measured 36% inclusive on a `getStackTrace()`-per-throw workload. Log without the trace, or demote the level |
| Frames are `NullPointerException`, `ClassCastException`, `ArrayIndexOutOfBoundsException`, `ArithmeticException` | **Implicit, JVM-generated.** Check whether `-XX:-OmitStackTraceInFastThrow` disabled the fast path |
| The exception constructor itself is expensive (formatting, context capture) | Counted here because of `total_samples: true`. **Making the constructor cheap may fix it without reducing throw count** |
| `StackTraceElement.<init>` visible in the heatmap | Unusual — measured **0 samples** even on a `getStackTrace()`-heavy workload, because the elements inline away. If present, the JIT is not inlining the materialisation path |
| `StackOverflowError` among the matched frames | A distinct and more serious bug — recursion, not control flow |
| Flat, load-proportional exception rate | **Control flow.** Exceptions scale with requests. A bursty rate instead means an intermittent dependency failure or retry storm — look at the heatmap's time axis |

**Then check what else in the report the cost explains**, per `Corroborating data` below. In short: `Underutilized CPU`
absent with the CPU near saturation makes this a **direct throughput lever**; low `ipc` with elevated cache and TLB
miss rates is the **expected companion signature**, since stack walking is pointer-chasing; high allocation rate or GC
pressure is consistent, because every exception allocates a throwable, a backtrace, and a `StackTraceElement[]`; and a
co-firing `JVM Version Comparison` **confounds** any cross-run exception-cost delta.

**Known false positives — few, and none make the measurement wrong:**

- **Intentional exception-based control flow in a framework you do not own.** Cost real, fix unavailable to you.
- **A short profile**, where a startup or warm-up burst dominates a small denominator. Check the duration and whether
  the exceptions cluster at the start of the heatmap. **Startup and class-loading exceptions**
  (`ClassNotFoundException` in classpath scanning is the classic) are frequently absent in steady state.
- **An expensive exception constructor** rather than a high exception rate: the total is honest, but "throw fewer" is
  the wrong fix. Likewise **`AssertionError` in a test or dev build**, not present in production.
- **A frame name whose text merely ends in a throwable constructor** — the missing start anchor on the `*Exception` branch
  admits `int freeze<com.example.FooException.<init>`. Rare; needs a `--cstack vm` frame named that way.

**Blind spots — this rule systematically *under*-reports, unlike most aperf findings:**

- **It requires the hidden `--save-profile-events` flag**, and that is not the default. **The finding is rare not because
  exceptions are rare but because the data usually is not collected.** `--profile-java` is a prerequisite too — without
  it there is no `java_profile` data type whatsoever.
- **Custom throwables not named `*Exception`/`*Error`** never match, nor do **inner-class throwables** (`Outer$Inner`,
  since `$ ∉ \w`), unqualified names, or Scala's `NoStackTrace` mixin — all verified misses. Other JVM languages
  frequently break the convention, though Kotlin's built-ins do not.
- **Only the `cpu` profile is examined, and the other two are unreachable by a rule shaped like this one.** Verified on
  real archives: `alloc` samples are tagged `ThreadState::None` (id 0), and `ThreadState::ALL` is `[AsyncRunnable,
  AsyncSleeping, AsyncDefault]` = `[1,2,3]` — **id 0 is in no list**, so an alloc rule's denominator is 0 either way
  and `percentage` is forced to `0.0`. `wall` samples carry only ids 1 and 2, so a `wall` rule copying
  `thread_states: [AsyncDefault]` also gets a 0 denominator. **Allocation-side exception cost cannot be measured by
  this template at all.**
- **The description names no class and no call site**, so the heatmap is mandatory for diagnosis, and **sampling hides
  small contributors**: many throw sites each below the sampling floor can sum to real cost. **The score also carries
  no magnitude**, so 5% and 98% are indistinguishable in any score-ordered view, and the percentage is inclusive, so
  it is not comparable with a self-time figure from another tool.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **The `cpu` heatmap for this JVM** | `java_profile` | **Do this first.** The only way to learn *which* exception class and *which* call site. The finding gives the total; the heatmap gives the target |
| Time axis of the heatmap | `java_profile` | Steady state (control flow) versus startup or burst (benign, or intermittent) |
| **The `alloc` heatmap** | `java_profile` | Exception allocation: throwable + backtrace + `StackTraceElement[]`. **Read it visually — no rule can measure it**, since `alloc` samples are `ThreadState::None` |
| The `wall` heatmap | `java_profile` | Whether exception handling also blocks. Same caveat: its samples are runnable/sleeping, so `AsyncDefault` rules see nothing |
| `jdk.JVMInformation` / `jvmArguments` | `java_profile` | **Check for `-XX:-OmitStackTraceInFastThrow`**, which disables the JVM's own mitigation. Verified to include flags from `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile`. Also GC and heap settings |
| `jdk.JVMInformation` / `jvmVersion` | `java_profile` | Fast-throw behaviour and JIT quality vary by version. Short form, e.g. `25.0.3+9-LTS` |
| `jdk.ActiveSetting` group | `java_profile` | async-profiler settings — the sampling interval, which governs how reliable a marginal percentage is |
| **`Tiered Compilation Check`**, **`JVM Version Comparison`** | `java_profile` | The companion JIT finding — exception paths interact with compilation — and the confounder: a version difference invalidates any exception-cost comparison |
| **`user` CPU, `Underutilized CPU`** | `cpu_utilization` | Whether the JVM is CPU-bound and this waste is therefore a throughput lever |
| Per-CPU utilization | `cpu_utilization` | Whether the cost is concentrated on a few threads or cores |
| **`ipc`** | `perf_stat` | Stack walking is pointer-chasing — **low IPC is the expected companion signature** |
| `l3-cache-mpki`, `data-tlb-mpki`, `stall_backend_pkc` | `perf_stat` | Cache, TLB, and memory-bound stall cost of stack walking and array allocation |
| `pgfault`, `Excessive Page Fault Rate`; `MemAvailable`, `AnonPages` | `vmstat`, `meminfo` | Allocation churn and heap pressure from exception objects |
| Native and JIT frames | `perf_profile` | Cross-check the JVM picture against the system profile. **No analytical rules — read manually** |
| Application error logs and metrics | out of band | **The fastest route to the cause.** A high exception rate is usually already visible in logs |

## Guidance

Ordered. **Step 1 tells you whether the data even exists; step 2 sizes the problem; step 3 names the culprit.**

1. **Confirm the data was collected before drawing any conclusion from absence.** These rules need
   `AperfData::Profile`, which requires **both** `--profile-java` **and** the hidden `--save-profile-events` at record
   time. Without the latter, `java_profile` falls back to heatmaps only and **all three rules are silently disabled**
   — so a report without this finding is the default case, not a clean bill of health.

2. **Read the percentage, and read it as inclusive.** It is the entire magnitude signal: the score is flat −256 from
   5.01% to 98%. Above ~25% exceptions are effectively the workload; 5–10% is a bounded win. **Do not translate the
   number into self time** — measured, the inclusive figure ran 26× the self figure on the same profile (98.12% vs
   3.76%).

3. **Open the `cpu` heatmap for the named JVM and find the actual exception class and call site.** The description
   prints the regex, not the matching frame, so it cannot tell you what to fix. Look for `Throwable.<init>` and
   `fillInStackTrace`, and read what sits above them.

4. **Distinguish creation from consumption.** `Throwable.<init>` / `fillInStackTrace` dominant ⇒ exceptions are being
   **created**. `getStackTrace` / `getOurStackTrace` dominant ⇒ traces are being **read**, usually by logging, and the
   fix differs (log without the trace, or demote the level). Both carried real weight in the measurement (62% and 36%
   inclusive), so check which dominates rather than assuming.

5. **Check the time axis before treating it as steady state.** Exceptions clustered at the start are startup or
   class-loading artifacts and may not exist in production. Load-proportional and evenly spread means control flow.

6. **Check `jvmArguments` for `-XX:-OmitStackTraceInFastThrow`.** The fast-throw optimization is **on by default** and
   often deliberately disabled so production NPEs keep their traces. If it was disabled and the matched frames are
   implicit exceptions, that setting is a direct contributor — and re-enabling it trades against diagnosability
   (**R5**: it changes what your logs contain). The string is trustworthy here: it reflects `JAVA_TOOL_OPTIONS`,
   `JDK_JAVA_OPTIONS`, and `@argfile` as well as the literal command line. **Otherwise expect little from
   `-XX:+OmitStackTraceInFastThrow`**: it is already the default and applies only to a handful of JVM-generated
   exceptions at JIT-hot throw sites, never to `new`-constructed ones.

7. **Fix the source, in rough order of leverage:** remove exceptions from the hot path entirely (return values,
   `Optional`, status codes, validate-before-attempt); if the throwable is needed but the trace is not, override
   `fillInStackTrace()` to return `this` or use the four-arg `Throwable(msg, cause, suppression,
   writableStackTrace=false)` constructor; reuse a preallocated singleton for a signal-only exception; and make any
   expensive constructor cheap — **`total_samples: true` attributes constructor body work to this finding**, so
   message formatting and context capture count.

8. **Read the `alloc` heatmap by eye, and do not wait for a rule.** Every exception allocates the throwable, its
   backtrace, and (on first access) a `StackTraceElement[]`. That GC cost is often comparable to the CPU cost, is not
   in this percentage, and **cannot be**: `alloc` samples are tagged `ThreadState::None`, which no `thread_states`
   list can select, so an alloc-side threshold rule computes 0.00% by construction.

9. **Cross-check the companion signature in `perf_stat`.** Low `ipc` and elevated cache/TLB miss rates are the
   expected accompaniment of pointer-chasing stack walks. Their presence supports the diagnosis; their absence
   suggests the cost is smaller in practice than the sample share implies — which the inclusive/self gap makes
   entirely possible.

10. **In a comparison, check `JVM Version Comparison` first**, since fast-throw behaviour, JIT quality, and exception
    performance all vary by JVM version, so an exception-cost delta across versions is confounded. And in any single
    run, **expect this finding to be under-inclusive**: custom throwables not named `*Exception`/`*Error`, inner-class
    throwables, unqualified names, and Scala's `NoStackTrace` mixin do not match, so if the heatmap shows
    exception-shaped cost the percentage does not account for, that is why.

## Priority and execution risk

**Priority: P1 — Act now** when the percentage is in double digits: it is a measured slice of CPU producing no
output, and it is the only `java_profile` rule that observed anything. At 5–10% it is **P3 — Opportunistic**. Two
modifiers pull in opposite directions: the inclusive measurement can overstate how much *constructor* work exists
(confirm against `ipc` before promising a throughput number), while the regex's systematic misses mean the true
exception cost is at least what is reported.

**Execution risk: R3 — Rebuild** for the real fix, because removing exceptions from a hot path or overriding
`fillInStackTrace()` is a code change that must be built and shipped. Reading the heatmap and `jvmArguments` is **R0**.
The two JVM-flag levers are worse than the code fix, not better: `-XX:+OmitStackTraceInFastThrow` is **R5** in
`GUIDANCE_MODEL.md`'s own example list, because suppressing traces changes what your logs contain, and it is the default
anyway; re-enabling it after someone disabled it is **R2** plus that same R5 semantic trade. **The score is flat
−256** either way: a 5.01% finding and the 98.12% one measured here score identically, so ordering by score says
nothing about which JVM to fix first. Order by the percentage.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: this rule fired, **or** `java_profile` shows heatmaps but no findings (the far more common case,
and the one that proves nothing).

```
STEP 0 — Does rule-readable profile data exist at all?
  IF the java_profile data type is absent, or present with no profiler keys
  THEN → --save-profile-events was NOT passed, so AperfData fell back to Graph and all three
         java_profile rules were inert. The absence of this finding carries NO information about
         exception cost (P2, R0)
       → read the cpu heatmap directly for Throwable.<init> and fillInStackTrace; that data is
         present either way. To make the rules work, re-record with --profile-java AND the
         hidden --save-profile-events
  ELSE continue to STEP 1.

STEP 1 — Read the percentage. It is the only magnitude signal; the score is flat. The number is
  INCLUSIVE (total_samples: true). Measured on a deliberate throw-in-a-loop workload: 98.12%
  inclusive against 3.76% self, a 26x gap. Treat it as "CPU beneath an exception constructor",
  not "CPU inside one".
  IF the percentage is >= 25%
  THEN → exceptions are effectively the workload; nothing else in this JVM's profile ranks above
         it (P1, R0)
  IF the percentage is 10-25%
  THEN → a meaningful CPU slice producing no output, usually one hot throw site (P1, R0)
  IF the percentage is 5-10%
  THEN → real but bounded. Batch it with other work (P3, R0)
  IF the percentage is within ~0.5 points of 5.00
  THEN → check the profile duration and the jdk.ActiveSetting sampling interval first; a short
         profile makes a marginal percentage noisy (P4, R0)

STEP 2 — Is it steady state, or an artifact of startup?
  IF the exception frames cluster at the START of the heatmap's time axis
  THEN → class-loading or warm-up (ClassNotFoundException in classpath scanning is the classic).
         It may not exist in production at all. VOID as a steady-state claim unless a longer
         recording reproduces it (P4, R0)
  IF the frames are spread evenly and scale with load
  THEN → control flow. This is the case the aperf_message describes (P1, R0)
  IF the frames arrive in BURSTS
  THEN → an intermittent dependency failure or a retry storm, not an architectural pattern.
         Correlate the bursts with application error logs (P2, R0)

STEP 3 — Creation or consumption? Read the dominant frame in the heatmap. Measured shares on one
  real profile: constructors 62% inclusive, getStackTrace 36%, getOurStackTrace 36%,
  StackTraceElement.<init> 0%.
  IF Throwable.<init> / fillInStackTrace dominates
  THEN → exceptions are being CREATED. Remove them from the hot path: return values, Optional,
         status codes, or validate-before-attempt (P1, R3)
       → verify: re-record and confirm the percentage fell below 5.00 so the finding stops
         firing; cross-check that ipc rose
  IF getStackTrace / getOurStackTrace dominates
  THEN → traces are being READ, not just created — almost always logging. Log without the trace,
         or demote the log level (P1, R3)
       → verify: re-record; the getStackTrace share should collapse while the constructor share
         stays put
  IF the exception CONSTRUCTOR BODY is the cost (formatting, context capture, error-code lookup)
  THEN → total_samples: true attributes that work here, so "throw fewer" is the wrong fix. Make
         the constructor cheap instead (P1, R3)
       → verify: re-record and compare the percentage; if it barely moves, the cost was the
         throw rate after all
  IF StackTraceElement.<init> is prominent
  THEN → unusual: it measured 0 samples even on a getStackTrace()-heavy workload, because the
         elements inline away. Suspect the JIT is not inlining the materialisation path (P2, R0)

STEP 4 — Are these implicit JVM exceptions, and was the JVM's own mitigation off? Read
  jvmArguments in the profile metadata. It reflects JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, and
  @argfile as well as the literal command line — verified.
  IF the matched frames are NullPointerException, ClassCastException,
     ArrayIndexOutOfBoundsException, or ArithmeticException, AND -XX:-OmitStackTraceInFastThrow
     appears
  THEN → someone disabled the JVM's own fast-throw path, usually on purpose so production NPEs
         keep their traces. Re-enabling it is a restart plus a diagnosability trade, and
         GUIDANCE_MODEL.md rates that trade R5 (P2, R2)
       → verify: re-record after the restart and confirm the percentage fell; separately confirm
         your logs still carry enough context to debug with
  IF the frames are implicit AND no OmitStackTraceInFastThrow flag appears, OR they are
     exceptions your code constructs with `new`
  THEN → the flag is either already doing its job or irrelevant, so the remaining cost is real
         and the fix is in the code, not a JVM setting (P1, R3)
       → verify: re-record after the code change and confirm the finding clears

STEP 5 — Does the rest of the report corroborate the cost?
  IF ipc is low and cache/TLB miss rates are elevated
  THEN → the expected signature: stack walking is pointer-chasing. The diagnosis is corroborated
         and the CPU is on the critical path (P1, R0)
  IF ipc is unremarkable
  THEN → CAUTION on the magnitude. The inclusive measurement can run far above the constructor's
         own cost, so the throughput win may be smaller than the percentage suggests. Confirm
         before promising a number (P2, R0)
  IF allocation rate or GC pressure is high
  THEN → exception objects allocate three times over. Read the alloc heatmap by eye — no rule can
         measure it, because alloc samples are tagged ThreadState::None (P2, R0)
  IF JVM Version Comparison also fired
  THEN → CONFOUNDED across runs: fast-throw behaviour and JIT quality are version-dependent, so
         per-run percentages stay readable but the delta does not (P2, R0)

STEP 6 — Does the percentage account for all the exception-shaped cost you can see?
  IF the heatmap shows throwable-shaped frames the percentage seems not to cover
  THEN → expected. The regex misses inner-class throwables (Outer$Inner, because $ is not in \w),
         custom names not ending in Exception/Error, unqualified names, and Scala's NoStackTrace
         mixin — all verified. It UNDER-reports; read the heatmap as ground truth (P2, R0)
  IF a frame matched that does not look like a throwable constructor
  THEN → the pattern's top-level | splits the anchors, so one branch is a prefix match and the
         other a suffix match. Rare, and it changed nothing on the measured archive (P4, R0)

STEP 7 — What survives?
  VALID      : the observation that this share of cpu samples sits beneath exception construction
               or stack-walk frames
  VALID      : the direction of the fix, once STEP 3 has named creation vs consumption vs
               constructor body
  CAUTION    : the magnitude as a throughput promise — the number is inclusive and measured 26x
               the self time
  CAUTION    : any claim about allocation-side exception cost; visible in the heatmap,
               unmeasurable by any rule
  CONFOUNDED : cross-run exception-cost deltas while JVM Version Comparison is open
  VOID       : "exceptions are cheap here" drawn from this finding's ABSENCE
  VOID       : a startup-clustered burst read as a steady-state architectural pattern

INSUFFICIENT DATA
  IF heatmaps exist but no java_profile findings do
  THEN → STEP 0's case: the rules never ran. Re-record with --save-profile-events before
         concluding anything about exception cost (P2, R1)
       → verify: on the new run, confirm the report lists profiler keys
  IF the percentage is marginal on a short recording
  THEN → per STEP 1's last branch, the sample count cannot support a 5% threshold decision.
         Record for longer (P4, R1)
       → verify: the new run's cpu denominator should be several thousand samples
```

## Runtime-specific consequences

This rule is Java-only, and **exception cost is not measurable by aperf in any other runtime** — an asymmetry that
matters, because exceptions-as-control-flow is not a Java-specific antipattern.

| Runtime | What aperf can see | Consequence |
|---|---|---|
| **Java** | This rule, plus the `cpu`/`alloc`/`wall` heatmaps | The only runtime with a measured exception finding — and only with `--save-profile-events` |
| **.NET** | **Nothing rule-driven** | CLR exceptions are *more* expensive than JVM ones (two-pass unwinding, no fast-throw equivalent). `perf_profile` may show `RhpThrowEx`/`IL_Throw` frames, but no rules attach — read manually |
| **Python** | **Nothing** | Exceptions are cheap and idiomatic (`StopIteration` ends every loop), so the Java framing does not transfer. Do not look for an analogue |
| **Perl** | **Nothing** | `die`/`eval` cost is invisible; `processes` shows only a truncated `comm` |

**So for .NET in particular, treat exception cost as an unmeasured dimension** rather than an absent one — the
system-level `perf_profile` is the only lever aperf gives you, and it has no rules attached. Outside aperf: Java has
JFR `jdk.JavaExceptionThrow` events for exact counts; .NET has `dotnet-counters exception-count` or an
ETW/`dotnet-trace` exception provider; Python needs a `sys.settrace` counter on a specific suspected handler; Perl has
no runtime counter, so instrument the `die` sites.

## Architecture-specific considerations

Stack walking is pointer-chasing over a deep call stack, so its cost tracks memory-subsystem behaviour rather than clock
speed. **Confirm the architecture from `pmu_config.json`** ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before comparing
this percentage across reports — the `cpu` profile does not encode it.

| Observed | Reading | Action |
|---|---|---|
| Same percentage, architectures differ | The share is comparable; the **absolute** cost per exception is not — different codegen, different cache hierarchy | Compare as an architecture study, not an exception one (P0, R0) |
| High percentage on Graviton, lower on x86_64 for the same code | Consistent with exception handling being **materially costlier on aarch64**, which is why `OmitStackTraceInFastThrow` appears in the arm64 JVM checklist — but it is already on by default, and `GUIDANCE_MODEL.md` rates the flag **R5** | Fix the exception rate; do not conclude Graviton is slower overall (P1, R3) |
| Low `ipc` accompanying a high percentage | Expected on both architectures — the corroborating signature | Proceed with the diagnosis (P1, R0) |
| Elevated `data-tlb-mpki` | Deep stacks cost more under TLB pressure: `fillInStackTrace` touches one frame per level | Treat the stack depth itself as part of the cost (P2, R0) |
| `High Code Sparsity` or `inst-l1-mpki` also elevated | **arm64-only findings.** Exception paths inflate the compiled footprint, and aarch64 JIT code is larger | Consider `-XX:ReservedCodeCacheSize=64M` alongside the exception fix (P2, R2) |
| `Old-Style Atomic Instructions` co-fires | arm64-only and unrelated to exceptions | Do not merge the two stories (P1, R3) |
| Running JDK 11 or older on Graviton | JDK 17+ (Corretto) has better aarch64 codegen and intrinsics, cutting per-exception cost without changing the throw rate | Upgrade the JDK as a separate, independently measurable change (P1, R3) |

The measurement in this playbook was taken on **x86_64** (`__memset_avx512_unaligned_erms` and `srso_alias_safe_ret`
appear in the same profile's frame map), so the 26× inclusive/self ratio is an x86_64 number. Expect the same direction
on aarch64; do not assume the same magnitude.

## Verification

Re-record with **both** `--profile-java` and the hidden `--save-profile-events`, and confirm the percentage fell below
5.00 so the finding stops firing. Because the score is flat, the percentage is the only before/after signal aperf gives
you — record it explicitly before the change. Cross-check that `ipc` rose and that the `cpu` heatmap no longer shows
`Throwable.<init>` or `fillInStackTrace` under the hot path. If the percentage falls but `ipc` does not move, the
inclusive measurement was overstating the constructor's own cost and the throughput win is smaller than the percentage
implied.

## Do not

- **Do not read the absence of this finding as "exceptions are cheap".** It requires the hidden
  `--save-profile-events` flag; without it the rule cannot fire at all.
- **Do not read the percentage as self time.** It is inclusive (`total_samples: true`) and measured **26×** the self
  figure on the same profile — 98.12% against 3.76%. It means "CPU beneath an exception constructor or stack-walk
  frame", not "CPU executing constructor bytecode".
- **Do not read the score as magnitude.** Flat −256 with **no score table**; 5.01% and 98% are identical scores. The
  percentage is the only signal, so order JVMs by it, not by score.
- **Do not expect the description to name the exception.** It prints the regex (because `aggregate_occurences: true`),
  never the matching frame. The heatmap is mandatory.
- **Do not reach for `-XX:+OmitStackTraceInFastThrow` as the fix.** It is already the default, covers only
  JVM-generated implicit exceptions at JIT-hot sites — never `new`-constructed ones — and `GUIDANCE_MODEL.md` rates it
  **R5**, because suppressing traces changes what your logs contain.
- **Do not assume the exception rate is high** — an expensive exception *constructor* produces the same percentage,
  because `total_samples: true` counts everything inside it. And **do not treat startup exceptions as steady state**:
  check the time axis of the heatmap first.
- **Do not conclude the code is exception-free because the percentage is low.** Inner-class throwables
  (`Outer$Inner`), custom names not ending in `Exception`/`Error`, unqualified names, and Scala's `NoStackTrace` mixin
  are all verified misses, and sampling hides many small contributors.
- **Do not wait for a rule to quantify the allocation side.** `alloc` samples are tagged `ThreadState::None`, which
  appears in no `thread_states` list, so the denominator is 0 and any alloc-side percentage is `0.00%` by
  construction. Read the `alloc` heatmap by eye.
- **Do not expect `StackTraceElement.<init>` to show up.** It measured **0 samples** even on a `getStackTrace()`-per-throw
  workload; the elements inline away.
- **Do not compare percentages across different JVM versions** without checking `JVM Version Comparison`, or across
  architectures without confirming both from `pmu_config.json`.
- **Do not confuse this with `perf_profile`.** This rule reads only the JVM's `cpu` profile, `AsyncDefault` samples —
  and `perf_profile` has no analytical rules at all.

## References

- Rule definition: `src/analytics/rules/java_profile.rs:18` — `profile_type: "cpu"`, single-element `stack_frame`
  pattern, `frame_type: None`, `thread_states: [ThreadState::AsyncDefault]`, `aggregate_occurences: true`,
  `total_samples: true`, `threshold: 5.0`, `score: Score::Critical`. The comment at `:16` states: *"If rule for cpu or
  alloc group, use only ThreadState::AsyncDefault"*.
- Rule template: `src/analytics/rule_templates/profile_stack_frame_threshold_rule.rs` — iterates all runs and profiler
  keys (`:72`–`:75`); folds patterns with `acc + count` when `aggregate_occurences` (`:99`), which is **why two
  nesting elements would double-count**; `percentage = (sample_count / total_samples) * 100.0`, or `0.0` when
  `total_samples == 0` (`:107`); fires on `percentage >= self.threshold` (`:113`); with aggregation sets
  `matched_pattern = None`, so the description prints **all** patterns (`:117`–`:122`); description format at `:124`;
  **inserts `self.score` directly — no `compute_finding_score` call, so the score is flat** (`:134`). `Score::Critical
  = −256`, `src/analytics/mod.rs:147`.
- Sample matching: `Profile::get_samples`, `src/profiling/mod.rs:216` — each element compiles as `^{frame}{suffix}$`;
  with `frame_type: None` the suffix is `FrameType::any_regex_suffix()` = `(_\[(0|j|i|k|1|v)\])?` (`:545`), so **any
  frame type matches**. Because the pattern carries a top-level `|`, the interpolated `^` and `$` bind to different
  alternation branches — **verified against the `regex` crate at the pinned version (`Cargo.toml:59`): 7 of 15 probe
  frames matched the as-written pattern but not a fully-parenthesised equivalent**, while both forms returned the same
  782 samples on the real archive.
- DFS semantics: `dfs_sum_samples`, `src/profiling/mod.rs:248` — on a full match with `total_samples: true` it adds
  `total_samples` (inclusive of descendants) and **stops descending**; with `total_samples: false` it adds
  `self_samples` and keeps descending. **Measured through aperf's own converter: 782 inclusive vs 30 self, a 26×
  ratio**, and 497 + 285 = 782 exactly, confirming the guard prevents double-counting within one regex.
- Denominator: `Profile::get_total_samples`, `src/profiling/mod.rs:303` — sums `self_samples` across the context tree for
  the resolved thread states, memoised in a `OnceCell` that `set_time_range` resets (`:466`); `resolve_thread_states`,
  `:397` — an empty `thread_states` resolves to `ThreadState::ALL`. The accessors `profiler_keys`,
  `profiler_total_samples`, and `profiler_samples` (`src/data/common/processed_data_accessor.rs:281`, `:295`, `:317`) all
  return empty or 0 unless the run's data is `AperfData::Profile`.
- Thread states: `src/profiling/mod.rs:563` — `None = 0`, `AsyncRunnable = 1`, `AsyncSleeping = 2`, `AsyncDefault = 3`,
  mapped from JFR's `STATE_RUNNABLE`/`STATE_SLEEPING`/`STATE_DEFAULT` (`:577`). **`ThreadState::ALL` is `[1, 2, 3]` and
  omits `None`**, and `src/profiling/jfr/convert.rs:94` assigns `ThreadState::None` to every `AllocationSample` — so
  **`alloc` samples are unreachable by any rule**. Verified across six archives: `cpu` populates only id 3, `alloc` only
  id 0, `wall` only ids 1 and 2.
- **Collection precondition:** `src/data/java_profile.rs:375` — the `Profiler` (hence `java_profiler_data_<pid>.json`)
  is built **only when `init_params.save_profile_events` is true**; the `TODO` at `:372` says the flow is *"only
  executed in tests"* pending launch. The flag is the **hidden** `--save-profile-events` (`src/record.rs:96`, `hide =
  true`; wired at `:219`). Report-side, if no profiler data is read the data type falls back to `AperfData::Graph`
  (`:527`), leaving `profiler_keys` empty and **all three `java_profile` rules inert**. Enablement of the data type
  itself is `--profile-java`, `src/record.rs:93`.
- Collection command: `launch_asprof`, `src/data/java_profile.rs:63` — `asprof -d <dur> -o jfr -e cpu --alloc 2m
  --wall 100ms --cstack vm -F vtable`. The `--cstack vm` is why native and kernel frames appear in the `cpu` context
  tree alongside Java frames, and why the unanchored branch can meet odd frame names. `PROFILE_METRICS = ["cpu",
  "alloc", "wall"]` at `:32`. Profiler key naming at `:459` — the deduped JVM name from `process_names.first()` (else
  `"unknown"`), with `" (N)"` appended for duplicates. **Not the PID.**
- Empirical basis for this playbook: a JFR recorded from Corretto 25.0.3+9-LTS under async-profiler 4.4 with aperf's
  exact `asprof` argument list, then fed through `jfr::build_java_profiler_data` and `Profile::get_samples` — aperf's
  own code, not a reimplementation. The rule fired at **98.12%**. Six pre-existing archives under
  `aperf-output/java_profile_*` supplied the thread-state census.
- Data type semantics: `data-descriptions.ts:4690` — *"Java profiling shows profiled CPU utilization, memory allocations,
  and wall clocks for JVMs running on the system visualized as heatmaps. JVM and async-profiler metadata are also
  displayed."* The frontend's `MEMORY_USAGE_INVESTIGATION` guide notes that *"APerf only supports memory allocation
  profiling for Java applications (enabled through `--profile-java`)"* (`optimization-guides.ts:32`).
- Risk vocabulary: `OmitStackTraceInFastThrow` is named in `GUIDANCE_MODEL.md`'s **R5** example list
  ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §3). Related playbooks: `tiered-compilation-check.md`,
  `jvm-version-comparison.md`, `../cpu_utilization/underutilized-cpu.md`, `../perf_stat/low-ipc.md`, and
  `../vmstat/excessive-page-fault-rate.md`. External:
  [Throwable.fillInStackTrace](https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/Throwable.html#fillInStackTrace()),
  [async-profiler](https://github.com/async-profiler/async-profiler), and the [Graviton perfrunbook Java
  optimizations](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html).
