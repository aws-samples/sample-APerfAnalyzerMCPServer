---
rule_name: Tiered Compilation Check
data_type: java_profile
data_key: <profiler key (JVM name)>
template: profile_metadata_expected
condition: "jdk.JVMInformation/jvmArguments does not match '.*-XX:(-|\\+)TieredCompilation.*'"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "If your code has a large instruction footprint, try setting this argument. This feature enables the runtime to more adaptively use the just-in-time (JIT) compiler to achieve better performance."
source: src/analytics/rules/java_profile.rs:31
---

# Tiered Compilation Check

## What fired

The JVM's `jvmArguments` metadata string — as recorded in the JFR `jdk.JVMInformation` event — **does not contain**
either `-XX:+TieredCompilation` or `-XX:-TieredCompilation`. The pattern is `.*-XX:(-|\+)TieredCompilation.*`, and the
`(-|\+)` alternation matches **both signs**.

So the condition is not "tiered compilation is disabled". It is: **the flag was not specified at all, in either
direction.** The rule also fires if the `jvmArguments` key is missing entirely (`should_exist: true`), with a different
description.

Base score `Poor` (**−16**), flat — this template inserts `self.score` directly and never calls
`compute_finding_score`, so **there is no score table.** Single-run: it evaluates every run independently, and fires
**once per JVM** (per profiler key).

**This is the weakest finding aperf produces, and it needs to be read carefully.** It reports the absence of a
command-line flag whose value is *already the default*. The message is explicitly conditional — *"**If** your code has
a large instruction footprint, try setting this argument"* — and that condition is not something the rule checked.

## The processing caveat — the flag channels are visible, and only one narrow suppression exists

Verified by launching a JVM under aperf's exact `asprof` argument list, extracting `jdk.JVMInformation` with the same
`jfr print --json` invocation `src/data/java_profile.rs:294` uses, and running the rule's own regex over the resulting
`jvmArguments` string. **The widely assumed "the flag might be set through a channel `jvmArguments` cannot see" false
positive is mostly wrong.** What the string actually contains:

| Channel used to set `-XX:-TieredCompilation` | Appears in `jvmArguments`? | Rule fires? |
|---|---|---|
| Literal command line | **Yes**, verbatim | No — pattern satisfied |
| `JAVA_TOOL_OPTIONS` env var | **Yes** — verified present in the string | No |
| `JDK_JAVA_OPTIONS` env var | **Yes** — verified present in the string | No |
| `@argfile` expansion | **Yes** — expanded before the string is built | No |
| `.hotspotrc` file | **No** — contents never reach `jvmArguments` | **Yes, falsely** |
| A `-D` property whose *value* embeds the text | **Yes**, as part of the property | **No — falsely suppressed** |

Two results follow, and they point in opposite directions:

- **The only real false-positive channel is `.hotspotrc`.** Its flags land in a *separate* metadata key —
  `jvmFlags`, observed carrying `'+PrintFlagsFinal'` — and **no aperf rule reads `jvmFlags` at all.** So a JVM
  configured entirely through `.hotspotrc` is invisible to this rule, while the far more common
  `JAVA_TOOL_OPTIONS`/`@argfile` deployments are fully visible. Drop "it might be in the environment" from your
  reasoning; keep "it might be in `.hotspotrc`".
- **The substring match is suppressible in the other direction.** `-Dx=--XX:+TieredCompilation-in-a-property`
  satisfies `.*-XX:(-|\+)TieredCompilation.*` — the pattern has no word boundaries and no argument-splitting — so a
  property, a quoted nested command line, or a container-orchestration annotation carrying that text **silences the
  rule on a JVM that never set the flag.** Verified against the rule's regex.

And the real firing case, for calibration: `jvmArguments = '-XX:+PreserveFramePointer
-XX:+UnlockDiagnosticVMOptions -XX:+DebugNonSafepoints -Xmx512m'` — a perfectly ordinary profiling-friendly JVM —
**fires.** That is what this finding looks like in practice: a healthy JVM with no JIT flag typed.

## Reasoning

**What tiered compilation is, and why the default matters here.** HotSpot has two JIT compilers: **C1**, which compiles
fast and produces moderately good code, and **C2**, which compiles slowly and produces excellent code. Tiered
compilation runs both — a method starts interpreted, is promoted to C1 for quick wins, accumulates profile data, and is
eventually recompiled by C2 with that profile in hand. It has been **enabled by default since JDK 8**
(`-XX:+TieredCompilation` is the default value). `-XX:-TieredCompilation` disables C1 and goes interpreter → C2
directly, which yields slower warm-up but a smaller compiled-code footprint and less code-cache churn. So what the
finding actually tells you is only that neither form of the flag appears — which, given the default, means **tiered
compilation is almost certainly enabled and behaving normally.** Read it as *"nobody has tuned JIT compilation on this
JVM"*: an unexplored dimension, not a misconfiguration.

**The direction of the recommendation deserves scrutiny — this is the crux of the rule.** The `aperf_message` says *"try
setting this argument"*, and the frontend's `INSTRUCTION_FOOTPRINT_OPTIMIZATION` guide is more specific: *"Experiment
with setting `-XX:+TieredCompilation` for faster start-up time and better code optimization."* But
**`+TieredCompilation` is already the default**, so setting it explicitly changes nothing about how the JVM behaves.
Reconciling the rule with its own guidance:

- The guide's stated benefits (*faster start-up*, *better code optimization*) are exactly what tiered compilation
  provides **relative to `-XX:-TieredCompilation`**. So the advice is coherent as *"make sure tiered compilation is
  on"* — but the regex matching **both** signs means the rule **cannot detect** the case where someone turned it off. A
  JVM running `-XX:-TieredCompilation` **satisfies the pattern and produces no finding**, even though that is the
  configuration the guidance is warning against.
- **This is the rule's central weakness: it fires on the harmless case (flag absent, default active) and stays silent
  on the concerning case (flag present and negative).** Whether that is intended — a prompt to *consider* the
  dimension — or an oversight in the alternation, the practical upshot is the same: **you must read `jvmArguments`
  yourself to learn whether tiered compilation is actually disabled.** The finding will not tell you.
- The flag appearing in the guide's instruction-footprint section is also slightly counterintuitive: disabling tiered
  compilation *reduces* code footprint (no C1 versions), while enabling it increases the number of compiled method
  versions. The companion advice in the same guide — `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M`, and
  watching for `code cache full` — is the part that directly addresses footprint, and the more actionable half.

**Why `Poor` (−16) is arguably too severe.** `Poor` is the same score aperf assigns to `Huge Page Disabled` and to
`Reduced Memory Availability` — findings that reflect a real configuration gap or measured pressure. This finding
reflects a **flag not being mentioned**, on a JVM that is almost certainly running the recommended value. In a
score-ordered findings list it will outrank genuinely informative findings. Weight it by its content, not its position.

**How `group` is used, which is not how it reads.** The rule specifies `group: "jdk.JVMInformation"`, but the lookup
path — `profiler_value_by_key` → `lookup_key_value` — **scans every metadata group and returns the first match by key
name.** The group is used **only in the description text.** Worse, `key_value_groups` is a `HashMap`, so **the scan
order is nondeterministic across runs**: if two groups ever carried the same key, which one won could change between
report generations with no code change. `parse_jfr_metadata` creates `jdk.JVMInformation`, `jdk.ActiveRecording`, and
`jdk.ActiveSetting`, and `jvmArguments` was verified to exist only in the first, so there is no ambiguity today — but
the group name in the description is an assertion of intent, not a verified fact about where the value was found.

**Why the value is a single flat string, and what that costs.** `parse_jfr_metadata` stringifies each JFR field
(`json_to_string`), so `jvmArguments` arrives as **one space-separated string of the entire JVM command line**. That
makes the regex a plain substring search over the whole argument list, with the two measured consequences documented
above: **no argument boundaries** (a `-D` property can suppress the rule) and **no coverage of `.hotspotrc`** (which
lands in the unread `jvmFlags` key instead). The same string is also a rich source of *other* information the rule
ignores entirely: heap sizing, GC selection, `OmitStackTraceInFastThrow`, huge-page flags, code-cache sizing. **Read it
in full while you are there** — it is more valuable than the finding that pointed you at it.

**The two description forms mean quite different things.** `field_exists && !value_matches` produces the "should match
pattern" form, which is the normal case. `should_exist && !field_exists` produces `"Event type '{group}' field '{key}'
not found in profile data"` — **which is a metadata-collection failure, not a JVM configuration fact.** That form
appears when `jfr print` failed, when the JFR recording lacked `jdk.JVMInformation`, or when metadata parsing returned
an empty `KeyValueData`. Note that the missing-field description **does not name the run or the profiler key**, even
though the finding is filed under both — so distinguishing which JVM it refers to requires looking at where the finding
is attached.

**A latent behaviour worth knowing: an invalid regex silently inverts the rule.** The template compiles
`expected_value` once; on failure it logs at `debug!` and sets `regex = None`. With `regex == None`, `value_matches` is
`false` for every value (the `matches!` guard requires `Some(re)`), so **the rule would fire on every JVM regardless of
its arguments.** This rule's pattern is valid, so it does not happen here — but it is the template's failure mode.

**The collection precondition that makes this rule dormant by default — the same one as the other two `java_profile`
rules.** All three read `AperfData::Profile`, which exists only if `java_profiler_data_<pid>.json` was written at record
time. That happens **only when `init_params.save_profile_events` is true** — the **hidden** `--save-profile-events`
flag. The source is explicit that this path is *"only executed in tests"* pending launch. Without the flag,
`java_profile` falls back to `AperfData::Graph`, `profiler_keys` returns empty, and **all three rules produce
nothing.** So `--profile-java` alone does not enable this finding, and its absence carries no information. When it does
fire, the finding is keyed by the **profiler key** — the deduped JVM name, not the PID, with `" (N)"` appended for
duplicate names.

## Reading the description

`profile_metadata_expected` emits one of two descriptions. Field present but not matching, then field missing:

```
Event type '{group}' field '{key}' in {profiler_key} should match pattern '{expected_value}', found: {value:?}

Event type '{group}' field '{key}' not found in profile data
```

Concretely, using the real string measured from a profiling-friendly JVM:

```
Event type 'jdk.JVMInformation' field 'jvmArguments' in my-service should match pattern '.*-XX:(-|\+)TieredCompilation.*', found: "-XX:+PreserveFramePointer -XX:+UnlockDiagnosticVMOptions -XX:+DebugNonSafepoints -Xmx512m"

Event type 'jdk.JVMInformation' field 'jvmArguments' not found in profile data
```

Six things to know:

1. **Read which form fired.** "should match pattern" is a configuration observation. **"not found in profile data" is a
   metadata-collection failure** and says nothing about the JVM's flags.
2. **The `found:` value is the entire JVM command line, printed with `{:?}`** — so it is quoted and any special
   characters are escaped. **This string is the most useful thing in the finding.** Read all of it, and note that it
   was verified to include flags injected via `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile`.
3. **The pattern shown matches both `+` and `-`.** So the finding means the flag is **absent**, not that it is
   disabled. A JVM with `-XX:-TieredCompilation` produces **no finding**.
4. **The score is flat −16.** No ratio, no magnitude, **no score table**.
5. **The missing-field form names neither the run nor the JVM** — identify those from where the finding is attached in
   the report.
6. **One finding per JVM**, keyed by the deduped JVM name.

## Interpretation

**First, decide which form fired and whether the data is trustworthy:**

| Evidence | Reading |
|---|---|
| **"not found in profile data"** | **Metadata collection failed.** `jfr print` errored, or the JFR lacked `jdk.JVMInformation`. **Says nothing about tiered compilation.** Check whether `jdk.ActiveRecording`/`jdk.ActiveSetting` metadata is also absent |
| "should match pattern", `found:` shows a plausible command line | The metadata is good; the flag is genuinely absent from every visible channel |
| `found:` shows an empty or truncated string | Suspect metadata extraction problems even though the field exists |
| **No finding at all, on a report with `java_profile` data** | Three possibilities: the flag is present in **some** form (including `-XX:-TieredCompilation`!); some *other* argument's text happens to contain the pattern; or `--save-profile-events` was not used and the rule never ran |

**Then read what the absence of the flag actually implies:**

| Evidence | Reading |
|---|---|
| Flag absent (this finding) | **Tiered compilation is enabled — it is the default since JDK 8.** The JVM is running the recommended configuration. The finding marks an *untuned dimension*, not a defect |
| **`-XX:-TieredCompilation` present** | **No finding fires**, because the regex matches both signs. **This is the configuration the guidance warns against, and the rule cannot see it.** Read `jvmArguments` yourself |
| `-XX:+TieredCompilation` present | No finding. Explicitly set to the default — behaviourally identical to absent |
| `-XX:TieredStopAtLevel=1` present | C2 is disabled while tiered compilation remains "on". The rule does not check this at all — a real gap for warm-up-optimized JVMs |
| Flag set via `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, or `@argfile` | **All three were verified to appear in `jvmArguments`**, so the rule sees them and does *not* fire. This is not a false-positive channel |
| Flag set only in a `.hotspotrc` file | **The one real false positive.** `.hotspotrc` contents land in a separate `jvmFlags` key that **no rule reads**, so the finding fires on a JVM that did set the flag |

**Then decide whether the message's condition is even met:**

| Evidence | Reading |
|---|---|
| **Instruction-footprint metrics in `perf_stat` are elevated** | **The message's precondition holds** — *"If your code has a large instruction footprint"*. Now the JIT dimension is worth exploring, especially code-cache sizing |
| Instruction-footprint metrics normal | **The message's precondition fails.** The finding is not actionable. This is the common case |
| High `stall_frontend_pkc` / instruction-fetch stalls | Consistent with a large instruction footprint — the JIT-footprint angle is live |
| `ipc` low with frontend-bound stalls | Same story; see the `LOW_IPC_INVESTIGATION` and `CPU_FRONTEND_STALLS_INVESTIGATION` guidance |
| Short-lived JVM, or startup latency matters | **Warm-up is the relevant axis**, and tiered compilation (already on) is what helps it. `-XX:-TieredCompilation` would hurt here |
| Long-running steady-state JVM | JIT tier configuration matters much less; C2 will have compiled everything hot regardless |
| **`Excessive Exceptions` also fired** | Prioritise that one — it is a measured cost, this one is a flag observation |
| `JVM Version Comparison` also fired | JIT behaviour and defaults change across versions; the comparison is confounded |

**Known false positives — this finding is mostly benign by construction:**

- **The flag is absent and tiered compilation is on by default.** The overwhelmingly common case: correct observation,
  no problem, nothing to do. Frequently paired with **a workload that has no instruction-footprint problem**, so the
  message's own conditional does not apply either.
- **The flag is set only in a `.hotspotrc` file.** Verified: those contents never reach `jvmArguments`, landing in a
  separate `jvmFlags` key no rule reads. **This is the only channel that produces a genuine false positive** — the
  environment-variable and `@argfile` channels do not.
- **"not found in profile data"** from a metadata-extraction failure, which is a tooling problem, not a JVM fact.
- **A JVM where explicit JIT tuning was deliberately avoided** on the sound principle that HotSpot's defaults are
  well-tuned. The finding is then an accurate observation of a deliberate decision.

**Blind spots — this rule's gaps are larger than what it reports:**

- **`-XX:-TieredCompilation` produces no finding.** The regex's `(-|\+)` matches both signs, so **the one
  configuration the guidance argues against is invisible.** The single most important thing to know about this rule.
- **Any argument whose text contains the pattern silences the rule.** Verified: `-Dx=--XX:+TieredCompilation-in-a-property`
  satisfies the regex, because the substring match has no argument boundaries. A false negative that needs no unusual
  JVM, just an unusual property value.
- **It requires the hidden `--save-profile-events` flag**; without it the rule never runs, so absence means nothing.
- **`-XX:TieredStopAtLevel=N` is not checked**, though it materially changes JIT behaviour, and neither are
  **`-XX:ReservedCodeCacheSize` / `InitialCodeCacheSize`** — even though the frontend guide presents them alongside
  this flag as the footprint remedy, and they are the more actionable half.
- **The instruction-footprint precondition in the message is never evaluated.** The rule fires regardless of whether
  the workload has the problem the flag is meant to address.
- **The group name is decorative** — `lookup_key_value` scans all metadata groups by key, in `HashMap` order, so a
  duplicated key would resolve nondeterministically between report generations.
- **An invalid regex would make the rule fire universally** (`regex = None` ⇒ `value_matches == false` always). Not
  triggered by this rule's pattern, but it is the template's failure mode.
- **`jvmArguments` does not reflect flags the runtime applies to itself** (ergonomics, container-aware defaults), nor
  the `jvmFlags` key where `.hotspotrc` settings land.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **The full `found:` string in the description** | `java_profile` | **Do this first, and read all of it.** The entire JVM command line — heap sizing, GC choice, code-cache flags, `OmitStackTraceInFastThrow`, huge-page flags — and verified to include `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile` contributions. **Far more informative than the finding itself** |
| **Whether `-XX:-TieredCompilation` or `-XX:TieredStopAtLevel` appears** | `java_profile` | **The rule cannot report these.** Check by hand — `-XX:-TieredCompilation` is the case the guidance actually warns about |
| **`jvmFlags`, the separate metadata key** | `java_profile` | Where `.hotspotrc` settings land (observed carrying `'+PrintFlagsFinal'`). **No rule reads it** — it is the only place a genuinely-set flag can hide |
| `-XX:ReservedCodeCacheSize`, `-XX:InitialCodeCacheSize` | `java_profile` | The frontend guide's companion recommendation for instruction footprint, and the more actionable one |
| `jdk.JVMInformation` / `jvmVersion` | `java_profile` | JIT defaults and behaviour vary by version. Short form, e.g. `25.0.3+9-LTS` |
| `jdk.ActiveRecording`, `jdk.ActiveSetting` groups; profiler keys present | `java_profile` | Whether metadata extraction worked at all — relevant to the "not found" form — and which JVMs were profiled |
| **`Excessive Exceptions`**, **`JVM Version Comparison`** | `java_profile` | A **measured** cost in the same data type, which outranks this flag observation; and the confounder that invalidates any cross-version JIT comparison |
| The `cpu` heatmap — interpreted (`_[0]`) / C1 (`_[1]`) / JIT (`_[j]`) frame types | `java_profile` | **Direct evidence of what the JIT actually did.** A profile dominated by interpreted frames indicates a real compilation problem, worth far more than the flag's presence |
| **`inst-tlb-mpki`, `inst-tlb-tw-pki`, instruction-cache metrics** | `perf_stat` | **Whether the message's "large instruction footprint" precondition actually holds** |
| **`stall_frontend_pkc`** | `perf_stat` | Frontend/instruction-fetch stalls — the symptom a large compiled footprint produces |
| `ipc`, `l3-cache-mpki` | `perf_stat` | Overall efficiency (see `LOW_IPC_INVESTIGATION`), and whether code and data are competing for cache |
| `user` CPU, `Underutilized CPU` | `cpu_utilization` | Whether the JVM is CPU-bound and JIT quality is on the critical path |
| JIT compiler thread CPU | `processes` | C1/C2 compiler threads' cost during warm-up. **No analytical rules — read manually** |
| Native/JIT frames | `perf_profile` | System-level view of compiled code. **No analytical rules — read manually** |
| `code cache full` warnings in the JVM log | out of band | The frontend guide's explicit trigger for raising the code-cache size |
| JVM warm-up and startup latency measurements | out of band | The dimension tiered compilation actually governs |

## Guidance

Ordered. **Step 1 is the whole point of this finding; step 2 is what the rule cannot tell you.**

1. **Read the entire `found:` string.** It is the JVM's full command line, and it is the most valuable content in this
   finding: heap sizing, GC selection, code-cache sizing, `-XX:±OmitStackTraceInFastThrow` (relevant to `Excessive
   Exceptions`), huge-page flags (relevant to `Huge Page Disabled`). **Treat the finding as a prompt to review JVM
   arguments rather than as a claim about tiered compilation.**

2. **Check by hand whether tiered compilation is actually disabled.** The regex matches **both**
   `-XX:+TieredCompilation` and `-XX:-TieredCompilation`, so **a JVM running with it disabled produces no finding at
   all.** Also look for `-XX:TieredStopAtLevel=N`, which the rule ignores entirely. This is the one configuration the
   guidance genuinely warns against, and the rule is blind to it.

3. **Understand that the flag being absent is the expected, healthy state.** `+TieredCompilation` has been the default
   since JDK 8; setting it explicitly changes nothing. **This finding does not indicate a misconfiguration.**

4. **Test the message's own precondition before acting.** The message says *"**If** your code has a large instruction
   footprint…"* — and the rule never checked that. Read `inst-tlb-mpki`, instruction-cache metrics, and
   `stall_frontend_pkc` in `perf_stat`. **If the instruction footprint is unremarkable, close this finding.**

5. **If the footprint *is* large, go to the code-cache half of the guidance, not the flag.** The frontend's
   `INSTRUCTION_FOOTPRINT_OPTIMIZATION` guide pairs the flag with `-XX:ReservedCodeCacheSize=64M
   -XX:InitialCodeCacheSize=64M` and says to watch for `code cache full` messages. **That is the actionable part**;
   setting an already-default flag is not.

6. **Look at frame types in the `cpu` heatmap for direct evidence of JIT behaviour.** async-profiler labels frames
   `_[0]` interpreted, `_[1]` C1, `_[j]` JIT, `_[i]` inlined. A steady-state profile heavy in interpreted or C1 frames
   is a real compilation problem — **worth far more than knowing whether a flag was typed.**

7. **Weigh this finding well below its score.** `Poor` (−16) is the same score as `Huge Page Disabled` and `Reduced
   Memory Availability`, which reflect real configuration gaps and measured pressure. This one reflects an unmentioned
   flag on a correctly-defaulted JVM. **Work `Excessive Exceptions` and every measured finding first.**

8. **If the description says "not found in profile data", treat it as a tooling failure.** `jfr print` failed or the
   recording lacked `jdk.JVMInformation`. Check whether the other metadata groups are present too, and remember this
   form names neither the run nor the JVM.

9. **Check `.hotspotrc` before calling this a false positive — but not the environment.** Verified:
   `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile` flags **all appear** in `jvmArguments`, so those channels
   cannot hide the flag. Only `.hotspotrc` can: its contents land in a separate `jvmFlags` key that no rule reads.

10. **Consider the JVM's lifetime before changing anything.** Tiered compilation primarily governs **warm-up**. For
    short-lived JVMs and startup-latency-sensitive services it matters a great deal (and is already on); for
    long-running steady-state services C2 will have compiled the hot paths regardless.

11. **Verify the data was collected at all before reading absence as reassurance.** Like the other `java_profile`
    rules, this one requires the hidden `--save-profile-events` flag in addition to `--profile-java`. And when a JVM
    that *should* have fired did not, check whether some unrelated argument's text happens to contain the pattern —
    verified to suppress the rule.

## Priority and execution risk

**Priority: P4 — Monitor** in the ordinary case, which is nearly every case: the flag is absent, the default is active,
and nothing is wrong. This is the lowest-priority finding in the tree, and the only aperf finding whose *stated
condition* is satisfied by the healthy configuration. Two modifiers can raise it. If the `perf_stat`
instruction-footprint metrics are genuinely elevated — the precondition the message asserts but never checks — the JIT
and code-cache dimension becomes **P2 — Plan**, though the actionable lever is code-cache sizing, not this flag. If the
description is the **"not found in profile data"** form, it is **P3 — Opportunistic** as a *tooling* fix: metadata
extraction failed and the rest of the `java_profile` guidance is degraded until it works.

**Execution risk: R0 — Read-only** for everything this playbook actually asks you to do: read the `found:` string, grep
it for `-XX:-TieredCompilation` and `-XX:TieredStopAtLevel`, check `jvmFlags`, and read the `perf_stat` footprint
metrics. Acting on the message is **R2 — Restart**, since any JVM flag change requires a restart, and it is a poor
trade: setting `-XX:+TieredCompilation` is a **behavioural no-op** because it is already the default. If you *do* find
`-XX:-TieredCompilation` and decide to remove it, that is a real change with a real warm-up effect and is also **R2**.
Raising `-XX:ReservedCodeCacheSize` is **R2** and the one flag change with a plausible payoff. **The score is flat
−16**, so it carries no magnitude and nothing to rank by.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: this rule fired, **or** you are auditing a JVM's JIT configuration and want to know what aperf's
silence means.

```
STEP 0 — Which description form fired?
  IF the description reads "not found in profile data"
  THEN → metadata extraction failed: jfr print errored, or the JFR carried no jdk.JVMInformation.
         This is a TOOLING fault and says nothing about tiered compilation. It also names
         neither the run nor the JVM (P3, R1)
       → verify: re-record and confirm jdk.ActiveRecording and jdk.ActiveSetting are present too
  ELSE continue to STEP 1.

STEP 1 — Read the whole found: string before anything else. It is the entire JVM command line,
  and it was verified to include flags from JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, and @argfile.
  IF the string is plausible and complete
  THEN → the flag is genuinely absent from every visible channel, which means the DEFAULT is
         active and tiered compilation is ON. This is the healthy state (P4, R0)
  IF the string is empty or truncated
  THEN → suspect metadata extraction even though the field exists; treat the configuration claim
         as unproven (P3, R0)
       → verify: compare against the JVM's own -XX:+PrintFlagsFinal output out of band

STEP 2 — Does the JVM disable or restrict JIT tiering in a way the rule cannot see? Grep the
  found: string yourself. The regex matches BOTH signs, so a disabled JVM is silent.
  IF -XX:-TieredCompilation appears
  THEN → no finding could have fired for it. This IS the configuration the frontend guidance
         warns against: warm-up is slower, C1 is gone. Removing the flag restores the default
         (P2, R2)
       → verify: after the restart, re-record and confirm warm-up latency and the interpreted
         frame share both fell
  IF -XX:TieredStopAtLevel=N appears
  THEN → C2 is capped while tiering nominally stays on. No aperf rule checks this. Intentional
         for fast-start short-lived JVMs, wrong for steady-state services (P2, R2)
       → verify: re-record and compare the _[j] JIT frame share against the _[1] C1 share
  IF neither appears and no code-cache flag appears
  THEN → the JVM is on JIT defaults across the board. Nothing is misconfigured (P4, R0)

STEP 3 — Is the message's own precondition true? It says "IF your code has a large instruction
  footprint" — and the rule never checked. Read perf_stat.
  IF inst-tlb-mpki, instruction-cache metrics, or stall_frontend_pkc are elevated
  THEN → the precondition holds and the JIT/code-cache dimension is live. Go to STEP 4 for the
         lever that actually applies (P2, R0)
  IF those metrics are unremarkable
  THEN → the precondition FAILS. The finding is not actionable; close it and spend the time on a
         measured finding instead (P4, R0)
  IF perf_stat is absent from the report
  THEN → the precondition is untestable, so the finding cannot be actioned either way. Treat the
         flag question as open, not as a problem (P4, R0)

STEP 4 — The footprint is real. Which lever?
  IF the JVM log carries "code cache full", or no code-cache flag is set
  THEN → size the code cache: -XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M, then
         tune. This is the frontend guide's actionable half and the only flag change here with a
         plausible payoff (P2, R2)
       → verify: re-record, confirm the code-cache-full messages stopped and stall_frontend_pkc
         fell
  IF the code cache is already sized and the footprint is still large
  THEN → the problem is the compiled footprint itself, not JIT configuration: reduce megamorphic
         call sites and inlining pressure, or profile-guide the hot set (P2, R3)
       → verify: re-record and compare stall_frontend_pkc and inst-tlb-mpki against the baseline
  IF someone proposes adding -XX:+TieredCompilation as the fix
  THEN → VOID: it is already the default, so it is a behavioural no-op. Do not spend a restart
         on it (P4, R0)

STEP 5 — Does the cpu heatmap agree that JIT compilation is healthy?
  IF the steady-state profile is dominated by _[j] JIT frames
  THEN → the JIT did its job. Whatever the flag says, compilation is not your problem (P4, R0)
  IF interpreted _[0] or C1 _[1] frames dominate in steady state
  THEN → a REAL compilation problem, and worth far more than the flag observation: methods are
         not reaching C2. Suspect -XX:TieredStopAtLevel, a full code cache, or deoptimization
         churn (P1, R0)
       → verify: check for code-cache-full messages, then re-read the frame-type mix after any
         change
  IF the java_profile heatmaps exist but no findings do
  THEN → --save-profile-events was not passed, so all three java_profile rules were inert. The
         absence of this finding carries no information (P4, R0)

STEP 6 — Is the rule silent when it should have fired?
  IF no finding fired and you have confirmed -XX:±TieredCompilation is genuinely not set
  THEN → some other argument's text satisfies the pattern. Verified: a -D property whose value
         embeds the flag text suppresses the rule, because the substring match has no argument
         boundaries. The rule is unreliable as a presence check (P4, R0)
  IF the flag IS set, only in a .hotspotrc file, and the finding fired anyway
  THEN → the one genuine false positive. .hotspotrc contents land in a separate jvmFlags key that
         no aperf rule reads, so the rule cannot see them. Dismiss the finding (P4, R0)

STEP 7 — What survives?
  VALID      : "no ±TieredCompilation flag appears in this JVM's visible arguments"
  VALID      : the found: string itself as a full inventory of the JVM's command line, including
               JAVA_TOOL_OPTIONS, JDK_JAVA_OPTIONS, and @argfile contributions
  CAUTION    : the finding as a JIT problem report — the default it omits is the recommended
               value, so the healthy case is what fires
  CAUTION    : the group name in the description; lookup_key_value scans all groups in HashMap
               order and the group is never verified
  CONFOUNDED : any cross-run JIT comparison while JVM Version Comparison is open
  VOID       : "tiered compilation is disabled here" read off this finding
  VOID       : "tiered compilation is enabled here" read off this finding's ABSENCE
  VOID       : setting -XX:+TieredCompilation as a remediation — already the default

INSUFFICIENT DATA
  IF java_profile heatmaps exist but no findings do
  THEN → STEP 5's last case: the rules never ran without --save-profile-events, so nothing can be
         concluded about JIT configuration (P4, R1)
       → verify: on the new run, confirm the report lists profiler keys
  IF the found: string is present but perf_stat is not
  THEN → the message's instruction-footprint precondition cannot be tested, so the finding cannot
         be actioned. Re-record with perf_stat enabled (P4, R1)
       → verify: the new run should carry inst-tlb-mpki and stall_frontend_pkc
```

## Runtime-specific consequences

JIT tier configuration is a HotSpot concept, and this rule is Java-only. The dimension it gestures at — how a managed
runtime compiles hot code — exists in other runtimes, but aperf has no rule for any of them.

| Runtime | What aperf can see | Consequence |
|---|---|---|
| **Java** | This rule, `jvmArguments`, and the `cpu` heatmap's `_[0]`/`_[1]`/`_[j]` frame types | The frame-type mix is **direct evidence** of what the JIT did, and beats this rule outright. Only with `--save-profile-events` |
| **.NET** | **Nothing rule-driven** | Tiered compilation exists (`TieredCompilation`, `TieredPGO`, `ReadyToRun`) and is on by default, but no aperf rule reads CLR config. `perf_profile` may show JIT frames; read manually |
| **Python** | **Nothing** | CPython 3.13+ has a copy-and-patch JIT behind a build flag; nothing aperf inspects, and the tiering framing does not transfer |
| **Perl** | **Nothing** | No JIT at all; `processes` shows only a truncated `comm` |

**So for .NET in particular, do not read the absence of this finding as "JIT configuration was checked".** No rule
looks at any runtime but Java, and even for Java the rule checks one flag's *presence*, not the JIT's *behaviour*. The
`cpu` heatmap's frame types are the only behavioural evidence aperf offers.

## Architecture-specific considerations

Nothing in this rule is architecture-dependent: it is a substring match over a string. But the *instruction footprint*
the message invokes very much is. **Confirm the architecture from `pmu_config.json`**
([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before acting on the footprint half of the guidance.

| Observed | Reading | Action |
|---|---|---|
| Same finding on both architectures | Expected — the rule matches text, so it fires identically wherever the flag is untyped | Do not read it as an architecture signal (P0, R0) |
| Elevated `inst-l1-mpki` or `High Code Sparsity` on Graviton | **arm64-only findings.** aarch64 fixed-width instructions make compiled code larger, so JIT footprint pressure shows here first and hardest | Size the code cache before touching tier flags (P2, R2) |
| `stall_frontend_pkc` high on aarch64, unremarkable on x86_64 for the same code | Consistent with the larger aarch64 compiled footprint, not with a JIT misconfiguration | Treat as a footprint problem; the flag is still a no-op (P2, R2) |
| Running JDK 11 or older on Graviton | JDK 17+ (Corretto) has materially better aarch64 codegen and intrinsics — a bigger JIT win than any tier flag | Upgrade the JDK as its own measurable change (P1, R3) |
| `Old-Style Atomic Instructions` co-fires | arm64-only, and about atomics rather than compilation tiers | Do not merge the two stories (P1, R3) |
| Comparing this finding across architectures | It compares only whether a flag was typed, which is a deployment artifact | Compare the frame-type mix and `stall_frontend_pkc` instead (P0, R0) |

The `-XX:ReservedCodeCacheSize=64M` figure in aperf's own guidance is a starting point, not an architecture-aware
number; expect aarch64 to want at least as much as x86_64 for the same application, and tune from the `code cache full`
messages rather than from the default.

## Verification

There is usually nothing to verify, because there is usually nothing to change: the flag's absence means the
recommended default is active. When you do act, the check depends on which lever you pulled. Removing an
`-XX:-TieredCompilation` you found by hand: re-record and confirm the interpreted/C1 frame share fell and warm-up
latency improved — **this finding will not change either way**, since it never fired for that JVM. Raising the code
cache: confirm the `code cache full` messages stopped and `stall_frontend_pkc` fell. **Adding
`-XX:+TieredCompilation` will silence the finding while changing nothing about the JVM** — the score is flat and the
percentage-free description gives you no before/after signal, so treat that silence as cosmetic rather than as a fix.

## Do not

- **Do not read this as "tiered compilation is disabled".** The regex matches both signs, so the finding means the flag
  is **absent** — and the default is enabled.
- **Do not conclude tiered compilation is enabled because there is no finding.** `-XX:-TieredCompilation` satisfies the
  pattern and **produces no finding**. Read `jvmArguments` yourself.
- **Do not set `-XX:+TieredCompilation` expecting a change.** It is already the default; setting it explicitly is a
  behavioural no-op that costs a restart and silences the finding without fixing anything.
- **Do not act on it without testing the instruction-footprint precondition.** The message is conditional and the rule
  never evaluated the condition.
- **Do not blame the environment for a false positive.** `JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile` were
  all **verified to appear** in `jvmArguments`. Only `.hotspotrc` hides a flag, in a separate `jvmFlags` key no rule
  reads.
- **Do not treat the rule as a reliable presence check.** Verified: a `-D` property whose value embeds the flag text
  satisfies the pattern and silences the rule, because the substring match has no argument boundaries.
- **Do not weight it by its score.** Flat −16 with **no score table**, on what is usually a healthy default.
- **Do not trust the "not found in profile data" form as a configuration statement** — it is a metadata-collection
  failure, and it names neither the run nor the JVM.
- **Do not assume the `group` was verified.** `lookup_key_value` scans all metadata groups by key in `HashMap` order;
  the group name appears only in the description.
- **Do not overlook `-XX:TieredStopAtLevel` or the code-cache flags** — they change JIT behaviour substantially, they
  are the actionable half of aperf's own guidance, and no rule checks any of them.
- **Do not read absence of the finding as reassurance** when `--save-profile-events` was not used: the rule never ran.
- **Do not prioritise this over `Excessive Exceptions`.** One is a measured CPU cost; this is a flag observation on a
  correctly-defaulted JVM.

## References

- Rule definition: `src/analytics/rules/java_profile.rs:31` — `group: "jdk.JVMInformation"`, `key: "jvmArguments"`,
  `expected_value: ".*-XX:(-|\\+)TieredCompilation.*"`, `should_exist: true`, `score: Score::Poor`. **The `(-|\+)`
  alternation matches both the enabling and disabling forms of the flag**, and the leading/trailing `.*` make it a
  boundary-free substring search.
- Rule template: `src/analytics/rule_templates/profile_metadata_expected_rule.rs` — compiles `expected_value` once,
  logging at `debug!` and setting `regex = None` on failure (`:60`); iterates all runs and all profiler keys
  (`:71`–`:74`); fires when `(field_exists && !value_matches) || (self.should_exist && !field_exists)` (`:86`); two
  description forms at `:88` and `:97`; **inserts `self.score` directly — no `compute_finding_score` call, so the score
  is flat** (`:108`). `Score::Poor = −16`, `src/analytics/mod.rs:147`.
- Value lookup: `profiler_value_by_key`, `src/data/common/processed_data_accessor.rs:349` — delegates to
  `lookup_key_value` (`:571`), which **scans all metadata groups and returns the first key match**. Because
  `KeyValueData::key_value_groups` is a `HashMap<String, KeyValueGroup>` (`src/data/common/data_formats.rs:148`), that
  scan order is **nondeterministic**; the rule's `group` field is used **only in the description text**.
- Metadata construction: `parse_jfr_metadata`, `src/profiling/jfr/convert.rs:477` — builds key-value groups named
  `jdk.JVMInformation`, `jdk.ActiveRecording`, and `jdk.ActiveSetting` from the JFR JSON, stringifying every value
  (`json_to_string`, `:488`) and skipping `startTime`; so **`jvmArguments` is one flat space-separated string** and the
  pattern is a substring search over it. `.hotspotrc` settings arrive in the **separate `jvmFlags` key** — observed
  carrying `'+PrintFlagsFinal'` — which **no rule reads**.
- Metadata extraction: `src/data/java_profile.rs:294` — `jfr print --json --events` over `jdk.ActiveRecording,
  jdk.ActiveSetting, jdk.CheckPoint, jdk.Metadata, jdk.JVMInformation, jdk.NativeLibrary`; on failure the JSON is
  `Value::Null`, which yields empty metadata and hence the **"not found in profile data"** description form.
- **Collection precondition:** `src/data/java_profile.rs:375` — the `Profiler` (and hence
  `java_profiler_data_<pid>.json`) is written **only when `init_params.save_profile_events` is true**; the `TODO` at
  `:372` states the flow is *"only executed in tests"* pending launch. The flag is the **hidden**
  `--save-profile-events` (`src/record.rs:96`, `hide = true`; wired at `:219`). Report-side, if no profiler data is read
  the data type falls back to `AperfData::Graph` (`src/data/java_profile.rs:527`), leaving `profiler_keys` empty and
  **all three `java_profile` rules inert**. Enablement of the data type itself is `--profile-java`, `src/record.rs:93`.
- Profiler key naming: `src/data/java_profile.rs:459` — the deduped JVM name from `process_names.first()` (or
  `"unknown"`), with `" (N)"` appended for duplicates. **Not the PID.**
- Empirical basis for this playbook: a JVM launched under aperf's exact `asprof` argument list with the flag supplied
  through each channel in turn, then `jdk.JVMInformation` extracted with the same `jfr print --json` invocation aperf
  uses and the rule's regex run over the result. **`JAVA_TOOL_OPTIONS`, `JDK_JAVA_OPTIONS`, and `@argfile` all appeared
  in `jvmArguments`; `.hotspotrc` did not.** The real firing case measured was `'-XX:+PreserveFramePointer
  -XX:+UnlockDiagnosticVMOptions -XX:+DebugNonSafepoints -Xmx512m'`, and `-Dx=--XX:+TieredCompilation-in-a-property`
  was confirmed to suppress the rule.
- Frontend guidance: `INSTRUCTION_FOOTPRINT_OPTIMIZATION`,
  `src/report_frontend/src/definitions/optimization-guides.ts:39` — *"Experiment with setting
  `-XX:+TieredCompilation` for faster start-up time and better code optimization"*, and *"Start with setting
  `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M` and then tune the sizes. Messages like `code cache full`
  indicate that the cache size needs to be increased."* Data type semantics: `data-descriptions.ts:4690` — *"JVM and
  async-profiler metadata are also displayed."*
- Frame types (for reading the heatmap): `FrameType`, `src/profiling/mod.rs:508` — `_[0]` interpreted, `_[1]` C1, `_[j]`
  JIT, `_[i]` inlined, `_[k]` kernel, `_[v]` vDSO.
- Related playbooks: `excessive-exceptions.md`, `jvm-version-comparison.md`, `../kernel_config/huge-page-disabled.md`,
  `../perf_stat/low-ipc.md`. External: [HotSpot performance
  enhancements](https://docs.oracle.com/en/java/javase/21/vm/java-hotspot-virtual-machine-performance-enhancements.html)
  and the [Graviton perfrunbook Java
  optimizations](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html).
