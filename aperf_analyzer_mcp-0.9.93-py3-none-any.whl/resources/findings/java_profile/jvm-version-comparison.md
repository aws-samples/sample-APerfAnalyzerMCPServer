---
rule_name: JVM Version Comparison
data_type: java_profile
data_key: <profiler key (JVM name)>
template: profile_metadata_comparison
condition: "jdk.JVMInformation/jvmVersion differs from base run"
base_score: Critical
score_sign: negative
requires_comparison: true
aperf_message: "JVM versions are different across runs, which may significantly affect performance. Ensure that this is intentional, or run comparison using consistent versions."
source: src/analytics/rules/java_profile.rs:40
---

# JVM Version Comparison

## What fired

The `jvmVersion` string from the JFR `jdk.JVMInformation` event **differs between this run and the base run** for
the same JVM — an **exact string comparison**, not a semantic version comparison. The rule also fires when the
field is present in the base run but **missing** in a comparison run (`should_exist: true`), with a different
description, and when the base run has **no** `jvmVersion` values at all.

Base score `Critical` (**−256**), flat — this template inserts `self.score` directly and never calls
`compute_finding_score`, so **there is no score table.** Comparison-only: it cannot fire on a single-run report.

**This is a validity gate, not a performance finding.** It does not say either run was slow. It says the two runs
ran on **different JVMs**, so every Java-related comparison in the report — heap behaviour, allocation rates, JIT
quality, GC pauses, exception cost, and quite possibly CPU and memory metrics too — is comparing different
runtimes. Resolve this before attributing any delta to the application code. It is the `java_profile` analogue of
`Kernel Version Mismatch` and `Inconsistent Physical Memory`.

## Reasoning

**Why a JVM version change is a `Critical`-severity confound.** The JVM is a compiler, a memory manager, and a
runtime all at once, and all three change between versions:

- **JIT**: C1/C2 optimization passes, inlining heuristics, intrinsics, and vectorization all evolve. The same
  bytecode compiles to different machine code.
- **GC**: the default collector changed to G1 in JDK 9; ZGC and Shenandoah matured over subsequent releases;
  G1's own heuristics, region sizing, and pause targets change every release. Allocation rate, pause
  distribution, and heap-occupancy behaviour all shift.
- **Ergonomics**: default heap sizing, thread-stack sizes, container-awareness, and code-cache defaults are all
  version-dependent — so **two runs with identical explicit flags can still get different effective
  configuration.**
- **Library internals**: `String` (compact strings in JDK 9), collections, `java.time`, and cryptography
  implementations change beneath unchanged application code.
- **Platform-specific codegen**: on Graviton in particular, newer JVMs add AArch64 intrinsics and better
  vectorization. A JDK 11 → 21 move can be a large, real, and entirely runtime-attributable win.

That last point is the crux: **a JVM version change frequently produces a larger performance delta than the code
change being tested.** Hence `Critical` — the same score aperf assigns to `Kernel Version Mismatch`. The message
is correspondingly framed as a validity instruction rather than advice: *"Ensure that this is intentional, or run
comparison using consistent versions."*

**Exact string comparison, and what that buys and costs.** The comparison is `comp_value != base_value` on the
`jvmVersion` string. **Observed verbatim in a real aperf archive** (`jdk.JVMInformation`, JDK 25 on x86_64):

```
25.0.3+9-LTS
```

That is the whole value: major.minor.patch, build number, and LTS status. It does **not** encode vendor, VM
flavour, target architecture, or build date — those are either in sibling fields (`jvmName` was
`'OpenJDK 64-Bit Server VM'`) or absent from the event entirely. Consequences:

- **Any difference fires, including ones that do not matter** — most commonly a build-number bump
  (`+9` vs `+10`) on an otherwise identical release.
- **The string is short, so the *position* of the difference is the whole diagnostic**: major, minor/patch, or
  build number (see the table below). There is no build timestamp to explain away a difference.
- **Architecture is NOT in this string**, so a cross-architecture comparison does **not** fire this rule on that
  basis alone — it fires only if the JDK versions also differ. Two hosts running the same JDK build on
  `aarch64` and `x86_64` produce **identical** `jvmVersion` values and this gate stays silent. That confound is
  covered by `Inconsistent Number of CPUs` and `Kernel Version Mismatch`, plus `Instance Type` in `systeminfo`.
- **Vendor is NOT in this string either.** OpenJDK vs Corretto vs Temurin at the same version and build can compare
  equal here. Read `jvmName` and `jvmArguments` from the profile metadata to tell them apart.
- **No semantic ordering.** The rule cannot tell you which run has the newer JVM; you must read the strings.

**The two-branch comparison logic, which is the subtlest part of this template.** After collecting
`profiler_key → jvmVersion` maps for the base run and the comparison run, the template takes one of two paths:

1. **If both runs have exactly one entry**, it compares the values **regardless of whether the profiler keys
   match** — deliberately, since the same service may be named differently across runs. The description then
   names **both** keys (`in {run} for '{comp_key}' … differs from {base} for '{base_key}'`).
2. **Otherwise** (multi-JVM on either side), it iterates the base run's keys and looks each one up **by exact key
   name** in the comparison run. A base key absent from the comparison run yields the "not found" description
   **only if `should_exist`** (it is `true` here).

The practical consequence is a **multi-JVM blind spot**: in the multi-key path, keys are matched by exact deduped
JVM name. If a JVM was renamed between runs — different main class, a wrapper script change, or a
`" (N)"` dedup suffix landing differently because JVM startup order changed — **the base key is not found, so you
get a spurious "not found" finding for it, while the correspondingly renamed comparison-run JVM is never checked
at all.** JVMs present only in the comparison run are never examined in either path.

**The base-run branch is a distinct signal that is easy to misread.** If `base_values` is empty — no profiler in
the base run reported `jvmVersion` — the template emits a finding **against the base run itself**, keyed by
`self.rule_name` (i.e. the literal string `"JVM Version Comparison"`, not a JVM name), with the description
`"Event type 'jdk.JVMInformation' field 'jvmVersion' not found in run {base_run}."` — then returns without
examining any comparison run. **So this form means "the base run has no JVM metadata", which is a collection
problem, and it also means no version comparison was performed at all.** Recognise it by the key being the rule
name rather than a JVM name, and by the trailing period (the only one of the four description forms that has one).

**A silent early return worth knowing.** If the base run is absent from `processed_data.runs` entirely, the
template logs at `debug!` (only when the map is non-empty) and returns. **No finding is produced** — so an
absent base run looks exactly like "versions match".

**How `group` is used, which is not how it reads.** The rule specifies `group: "jdk.JVMInformation"`, but
`profiler_value_by_key` → `lookup_key_value` **scans every metadata group and returns the first match by key
name.** The group is used **only in the description text**. `parse_jfr_metadata` creates `jdk.JVMInformation`,
`jdk.ActiveRecording`, and `jdk.ActiveSetting` groups, and `jvmVersion` lives only in the first, so there is no
practical ambiguity — but the group name is an assertion of intent, not a verified fact.

**Why this finding invalidates the other two `java_profile` findings.** `Excessive Exceptions` depends on
JIT-compiled exception paths and on `OmitStackTraceInFastThrow` behaviour, both version-dependent.
`Tiered Compilation Check` depends on JIT defaults, which also change by version. So when this rule fires, **an
exception-cost delta or a JIT observation between the two runs is confounded.** The absolute per-run values remain
readable; the deltas do not.

**Where the finding is filed.** Under data type `java_profile`, key = the **profiler key** (deduped JVM name, not
the PID) — except in the empty-base branch, where the key is the rule name. One finding per mismatched JVM.

**The collection precondition that makes this rule dormant by default — shared with the other two
`java_profile` rules.** All three read `AperfData::Profile`, which exists only if `java_profiler_data_<pid>.json`
was written at record time, and that happens **only when `init_params.save_profile_events` is true** — the
**hidden** `--save-profile-events` flag. The source states the path is *"only executed in tests"* pending launch.
Without it, `java_profile` falls back to `AperfData::Graph` and `profiler_keys` returns empty.

**Observed, and it is NOT silence.** Reporting a real JVM archive that was recorded *without* the flag, aperf 1.3.0
emitted this rule at the **full −256**, filed against the single run:

```
Event type 'jdk.JVMInformation' field 'jvmVersion' not found in run java_profile_20260525_152932.
```

That is the fourth description form, and it fires from the `should_exist` branch
(`profile_metadata_comparison_rule.rs:92`–`:109`) which runs **before** any comparison and **before** the
other-runs loop at `:111`. Three consequences that a source reading alone does not give you:

- **On a SINGLE-run report this gate fires at Critical**, and its `message` still says *"JVM versions are different
  across runs"* — which is false, because there is no other run. The `description` is authoritative here, the
  `message` is not.
- **The two other `java_profile` rules stay genuinely silent** in the same report, so this asymmetry is a property
  of the *template*, not of the flag. `Tiered Compilation Check` also sets `should_exist: true`
  (`rules/java_profile.rs:35`), but its check sits **inside** the `for key in &profiler_keys` loop
  (`profile_metadata_expected_rule.rs:74`–`:86`); with no profiler keys the loop body never runs and nothing is
  emitted. The comparison template instead tests `base_values.is_empty()` **outside** any such loop, which is why
  only this rule speaks up. Confirmed on the same archive: 1.3.0 reported `JVM Version Comparison` and **not**
  `Tiered Compilation Check`, while the 1.2.2 reporter — whose collector wrote the metadata — reported the reverse.
- **A missing-metadata failure and a real version mismatch are both −256**, distinguishable only by which of the
  four description forms fired.

So the accurate warning is narrower than "absence is not reassurance": **a −256 here most often means the metadata
was never collected, not that the JVMs differ.** The genuinely silent failure mode is the *other* one — when the
base run is absent from `processed_data.runs` entirely, the rule returns at `:64`–`:69` with only a `debug!`.

## Reading the description

`profile_metadata_comparison` emits one of **four** descriptions.

**Single-JVM-on-both-sides mismatch** (both runs have exactly one entry; keys need not match):

```
Event type '{group}' field '{key}' in {run} for '{comp_key}' ("{comp_value}") differs from {base_run} for '{base_key}' ("{base_value}")
```

**Multi-JVM mismatch** (keys matched by name):

```
Event type '{group}' field '{key}' in {run} for '{key}' ("{value}") differs from {base_run} ("{base_value}")
```

**Key present in base, missing in comparison run:**

```
Event type '{group}' field '{key}' not found in {run} for '{key}', while its value in {base_run} is "{base_value}"
```

**Base run has no values at all** (filed against the base run, keyed by the rule name, **with a trailing
period**):

```
Event type '{group}' field '{key}' not found in run {base_run}.
```

Concretely, using a **real** `jvmVersion` observed in an aperf archive (`jdk.JVMInformation`, JDK 25 on x86_64):

```
Event type 'jdk.JVMInformation' field 'jvmVersion' in aperf_record_new for 'my-service' ("25.0.3+9-LTS") differs from aperf_record_base for 'my-service' ("21.0.3+9-LTS")
```

**`jvmVersion` is the SHORT form.** Observed verbatim: `'25.0.3+9-LTS'` — no vendor, no VM flavour, no
architecture, no `JRE (...)` tail. Those live in **sibling fields of the same event**, which this rule does not
read: `jvmName` (`'OpenJDK 64-Bit Server VM'`), `jvmArguments`, `javaArguments`, `jvmFlags`, `jvmStartTime`, `pid`.
Do not expect a long `"OpenJDK 64-Bit Server VM (21.0.3+9-LTS) for linux-aarch64 ..."` string in this description —
compare `jvmName` yourself if you need the flavour, and use `systeminfo`'s `Instance Type` for the architecture.

Six things to know:

1. **Read which of the four forms fired.** Two are genuine version mismatches; **the two "not found" forms are
   collection or JVM-identity problems**, and the fourth means **no comparison was performed at all**.
2. **Both version strings are printed.** **This is the entire diagnostic payload** — compare them character by
   character and note *where* they diverge. They are short (`25.0.3+9-LTS`), so the divergence is easy to place.
3. **The comparison is exact-string, not semantic.** The rule cannot tell you which is newer, and a build-metadata
   difference fires just as loudly as a major-version jump.
4. **The architecture is NOT in this string, so this rule cannot catch a cross-architecture comparison.** Verified
   against a real archive: `jvmVersion` was `'25.0.3+9-LTS'` with no `linux-aarch64`/`linux-amd64` substring. Read
   `Instance Type` and `Kernel Version` from `systeminfo` instead — `Inconsistent Number of CPUs` and
   `Kernel Version Mismatch` are the gates that actually cover that confound.
5. **The score is flat −256.** No ratio, **no score table**; a build-number difference and a JDK 11 → 21 jump score
   identically. **The strings, not the score, carry the magnitude.**
6. **Only the single-JVM form names both profiler keys**; use that to spot a JVM that was renamed between runs.

## Interpretation

**First, identify which form fired:**

| Description form | Reading |
|---|---|
| "…differs from…" naming **both** keys | **Single JVM on both sides.** The normal, informative case. Compare the two strings |
| "…differs from…" naming **one** key | **Multi-JVM path**, keys matched by exact name. Same reading, but check whether other JVMs were skipped |
| "not found in {run} for '{key}', while its value in {base} is…" | The base run's JVM has **no counterpart by that name** in the comparison run — either metadata failed, the JVM did not run, or **it was renamed**. Not a version mismatch |
| **"not found in run {base_run}."** (trailing period, keyed by the rule name) | **The base run has no JVM metadata at all.** A collection failure — **and no version comparison was performed** |
| **No finding, on a comparison report** | Either versions match, **or** the base run is absent from the data, **or** `--save-profile-events` was not used. **Not reassurance** |

**Then read where in the string the two versions diverge — this is the magnitude judgement:**

| Divergence position | Reading |
|---|---|
| **Major version** (`21.0.3+9-LTS` vs `25.0.3+9-LTS`) | **The comparison is not salvageable.** JIT, GC defaults, ergonomics, and library internals all differ. Expect large, runtime-attributable deltas — often larger than the code change under test |
| **Minor/patch** (`21.0.1+12` vs `21.0.3+9`) | Usually modest, but GC and JIT fixes do ship in patch releases. Treat deltas with suspicion, especially GC-related ones |
| **Build number only** (`21.0.3+9` vs `21.0.3+10`) | Almost always immaterial. The finding is technically correct and practically ignorable |
| **LTS suffix only** (`21.0.3+9-LTS` vs `21.0.3+9`) | A different packaging of the same build. Ignorable on its own, but it hints the two images came from different sources — check `jvmName` and `jvmArguments` |
| **Not visible in this string at all** — vendor, VM flavour, architecture, build date | **This rule cannot see them.** `jvmVersion` is just `25.0.3+9-LTS`. A vendor swap (Corretto → Temurin), a `Server VM` → `Client VM` change, or an `aarch64` → `x86_64` move at the same JDK build leaves this gate SILENT. Read `jvmName`/`jvmArguments` from the metadata and `Instance Type`/`Kernel Version` from `systeminfo` |

**Then check what else differs, since a JVM change rarely travels alone:**

| Evidence | Reading |
|---|---|
| **`Kernel Version Mismatch` also fired** | Two runtime variables at once. Likely different AMIs — **re-run on matched images** |
| **`Inconsistent Number of CPUs` / `Inconsistent Physical Memory` also fired** | Different instances. **The whole comparison is invalid**, not just the Java parts |
| Instance types identical, JVM differs | A deliberate or accidental JDK upgrade on the same hardware. The cleanest form of this finding |
| **`Excessive Exceptions` differs between runs** | **Confounded** — exception cost and fast-throw behaviour are version-dependent |
| **`Tiered Compilation Check` fires on one run only** | Likely reflects differing JIT defaults or command lines that came with the version change |
| `jvmArguments` also differ | **Two variables.** Isolate them: a version change plus a flag change cannot be attributed |
| GC-related deltas (allocation rate, `alloc` heatmap shape) | Strongly version-sensitive. The default collector and its heuristics change between releases |
| Memory findings (`Reduced Memory Availability`, fault rates) | JVM ergonomics set default heap sizing by version — **the memory delta may be the JVM, not the workload** |
| `perf_stat` deltas (`ipc`, cache/TLB, instruction footprint) | Different codegen from a different JIT. **Do not attribute these to the application** |
| Newer JVM on Graviton showing a large win | **Expected.** AArch64 intrinsics and vectorization improved substantially across recent releases |

**Known false positives — the rule measures a real fact, so these are all "correct but not meaningful":**

- **A build-number or build-date difference** on the same version. Technically a mismatch; practically nothing.
- **A vendor repackaging** of the same upstream version.
- **A deliberate JVM-upgrade experiment** — the finding is doing exactly its job: telling you the deltas in this
  report are attributable to the runtime change, which is what you wanted to measure. Read absolute values per
  run rather than the deltas.
- **A stale or mis-selected base run.** The cheapest thing to rule out.
- **A renamed JVM** producing a spurious "not found" finding rather than a version comparison.
- **`" (N)"` dedup suffixes landing differently** because JVM startup order changed between runs, which breaks
  key matching in the multi-JVM path.

**Blind spots, in order of importance:**

- **It requires the hidden `--save-profile-events` flag on both runs.** Without it the rule never runs — so **a
  genuine cross-version comparison shows no finding.** For a validity gate this is the most dangerous gap.
- **An absent base run produces no finding** (silent `debug!` return), indistinguishable from "versions match".
- **Multi-JVM key matching is by exact name.** A renamed JVM yields a spurious "not found" for the base key while
  the renamed comparison-run JVM is never checked. **JVMs present only in the comparison run are never examined.**
- **No semantic version comparison** — the rule cannot say which run is newer, nor how far apart they are.
- **`jvmArguments` differences are not reported by this rule**, though they are often the *real* cause of a delta
  and travel with a version change. Read them by hand; `Tiered Compilation Check` shows the string.
- **`--profile-java` is required at all**, and only JVMs actually profiled are compared.
- **Non-JVM version context is invisible**: container base image, glibc, JVM flags from `JAVA_TOOL_OPTIONS`.
- **`java_profile` has no `statisticalFinding` path** — there is no mechanical delta view of JVM metadata to fall
  back on.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **Both `jvmVersion` strings in the description** | `java_profile` | **Do this first.** Compare character by character; the **position** of the divergence is the magnitude judgement |
| **`Instance Type` and `Kernel Version`** | `systeminfo` | Whether this is **also** a hardware or architecture difference — much more severe. `jvmVersion` does **not** carry the architecture, so this rule cannot tell you |
| **`jvmName`** in the profile metadata | `java_profile` | Vendor and VM flavour (`'OpenJDK 64-Bit Server VM'`), neither of which appears in `jvmVersion` |
| **`jdk.JVMInformation` / `jvmArguments` for both runs** | `java_profile` | **Read these too.** Flag differences travel with version changes and are often the real cause. See `Tiered Compilation Check` |
| `jdk.ActiveRecording`, `jdk.ActiveSetting` groups | `java_profile` | Whether metadata collection worked — relevant to the two "not found" forms |
| Profiler keys present in each run | `java_profile` | **Whether a JVM was renamed**, which breaks multi-JVM key matching and produces spurious "not found" findings |
| **`Excessive Exceptions` in each run** | `java_profile` | Version-dependent; **the delta is confounded**, the absolute values are not |
| **`Tiered Compilation Check`** | `java_profile` | JIT defaults differ by version; firing on one run only is often a symptom of the same change |
| `cpu` / `alloc` / `wall` heatmaps for both runs | `java_profile` | Where the behaviour actually moved. Compare shapes, not just totals |
| Frame types (`_[0]`/`_[1]`/`_[j]`) in both `cpu` heatmaps | `java_profile` | Whether JIT behaviour itself changed — direct evidence of the runtime difference |
| **`Kernel Version Mismatch`** | `systeminfo` | A second runtime variable; a JDK change usually arrives with an AMI change |
| **`Inconsistent Number of CPUs`, `Inconsistent Physical Memory`** | `systeminfo` | **If either fired, the whole comparison is invalid**, not just the Java parts |
| Instance type, AMI ID | `systeminfo` | Whether the hardware and image were held constant |
| `ipc`, `l3-cache-mpki`, `*-tlb-mpki`, instruction footprint | `perf_stat` | Different JIT ⇒ different machine code. **Do not attribute these deltas to the application** |
| `user` / `system` CPU, `Underutilized CPU` | `cpu_utilization` | Overall shift; interpret against the version difference, not the code |
| `MemAvailable`, `AnonPages`, fault rates | `meminfo`, `vmstat` | **JVM ergonomics set default heap sizing by version** — the memory delta may be the runtime |
| Every statistical (delta-vs-base) finding | all | All of them compare across different runtimes while this is open |
| GC logs, JVM startup logs | out of band | The authoritative record of collector choice and effective ergonomics |
| Deployment/AMI provenance for both runs | out of band | How the two runs came to have different JVMs — usually answers the "was this intentional" question immediately |

## Guidance

Ordered. **Steps 1–3 resolve essentially every firing.**

1. **Read both `jvmVersion` strings and note exactly where they diverge.** They are short — `25.0.3+9-LTS` — so
   this is quick. Major version ⇒ the comparison is not salvageable. Minor/patch ⇒ treat deltas, especially
   GC-related ones, with suspicion. Build number only ⇒ record it and move on. **Check `Instance Type` in
   `systeminfo` separately** — the architecture is **not** in this string, so a cross-architecture comparison does
   not show up here.

2. **Confirm the base run is the one you meant to compare against.** A stale or mis-selected base is the most
   common cause and the cheapest to rule out. If the description is the **"not found in run {base_run}."** form,
   the base run has no JVM metadata at all and **no version comparison was performed** — fix the collection and
   re-run.

3. **Check whether the whole report is invalid, not just the Java parts.** If `Kernel Version Mismatch`,
   `Inconsistent Number of CPUs`, or `Inconsistent Physical Memory` also fired, the runs are on different
   machines or images and the JVM difference is one symptom of a larger problem. Re-run on matched instances and
   images.

4. **If the versions genuinely differ and the difference was not intentional, re-run with matched JVMs.** The
   message is a validity instruction: *"Ensure that this is intentional, or run comparison using consistent
   versions."* No amount of analysis recovers a clean attribution from two different runtimes.

5. **If the version change *was* the experiment, invert how you read the report.** The finding is telling you the
   deltas are attributable to the runtime. Read **absolute values per run** rather than deltas, and expect JIT,
   GC, and codegen effects — on Graviton in particular, newer JVMs bring real AArch64 intrinsic and vectorization
   improvements, so a large win is plausible and *is* the result.

6. **Read `jvmArguments` for both runs before concluding anything.** Flag changes routinely accompany version
   changes, and **this rule does not report them.** A version difference plus a flag difference is two variables;
   isolate them. `Tiered Compilation Check` prints the full argument string.

7. **Explicitly discount the other two `java_profile` findings' deltas.** Exception cost, fast-throw behaviour,
   and JIT defaults are all version-dependent, so an `Excessive Exceptions` difference or a one-sided
   `Tiered Compilation Check` between different JVMs is confounded. The per-run absolute values remain valid.

8. **Treat `perf_stat` and memory deltas as suspect too.** Different JIT means different machine code (`ipc`,
   cache and TLB behaviour, instruction footprint), and different ergonomics means different default heap sizing
   (memory and fault-rate metrics). **These are not application-code effects.**

9. **If the description is a "not found … for '{key}'" form, check whether the JVM was renamed.** Multi-JVM
   matching is by exact deduped name, so a renamed JVM produces a spurious "not found" **and** silently skips the
   real comparison. Compare the profiler-key lists of the two runs directly. Note that JVMs present only in the
   comparison run are never examined at all.

10. **Do not read absence of this finding as matching versions.** It requires the hidden `--save-profile-events`
    flag on **both** runs, and an absent base run produces a silent `debug!` return. **For a validity gate, verify
    the versions by hand** whenever the comparison matters.

11. **Once the JVMs are matched, expect this finding to disappear entirely.** There is no partial resolution:
    either the version strings are identical or they are not.

## Priority and execution risk

**Priority: P0 — Blocking** for attributing anything to application code. But there is a prior P1 concern that
outranks reading the finding at all: **this rule is inert unless the hidden `--save-profile-events` flag was
passed**, so its *absence* proves nothing about JVM parity.

**Execution risk: R4 — Infrastructure change** to fix the comparison (pin the JVM, rebuild the image). Acting on
what a JVM change reveals is **R2 — restart required** (flags, GC selection) or **R3 — rebuild** (AOT, CDS).

**The score is flat −256.** A build-number bump and a JDK 8 → 21 jump score identically.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: this rule fired, **or** `java_profile` data is absent (which is the more common and more
dangerous case).

```
STEP 0 — Does java_profile METADATA exist at all?
  Check for `profilers` in the java_profile data. `data_format: "graph"` with
  `graph_groups` (flamegraph HTML only) means there is NO metadata.

  IF the java_profile data type is missing or has no profiler keys
  THEN → --save-profile-events was NOT passed, so no version comparison was
         performed. Observed: this rule still fires at the full -256 with the
         "not found in run {base}." form, and its message still claims the
         versions differ. BELIEVE THE DESCRIPTION, NOT THE MESSAGE (P1, R0)
       → this is the most likely reason to see this finding at all, and it is a
         COLLECTION failure, not a version mismatch. Do not re-platform anything
       → on a SINGLE-run report the -256 is guaranteed noise: there is no other
         run to differ from
       → action: compare JVM versions MANUALLY (`java -version` on both hosts,
         or the deployment manifest) before reading any other finding
       → verify: re-record with the hidden --save-profile-events flag. The
         java_profile data should gain `profilers` with a `jdk.JVMInformation`
         group, and this finding should either disappear or change to one of the
         two "differs from" forms
  ELSE continue.

STEP 1 — Which of the FOUR description forms is this?
  A. Both runs have one JVM, values differ
     → a genuine version comparison; go to STEP 2
  B. Multiple keys, per-key comparison
     → multiple JVMs profiled; check WHICH key differs
  C. Field not found in run {X}
     → the compared run's profile lacks jvmVersion; collection issue (P1, R0)
  D. Filed against the BASE run, keyed by the rule name, trailing period
     → NO comparison was performed at all. The base run had no value (P1, R0)
       → treat exactly like STEP 0: compare manually

STEP 2 — Locate the FIRST differing component of the version string.
  e.g. 21.0.4+7-LTS  /  "OpenJDK 64-Bit Server VM (21.0.4+7-LTS, mixed mode)"

  ARCHITECTURE differs (aarch64 vs amd64 in the VM string)
    → STOP. JIT codegen differs entirely; nothing comparable (P0, R4)
  MAJOR version differs (17 -> 21)
    → expect changed GC defaults, JIT behaviour, and library internals (P0, R4)
    → this is the highest-magnitude case and the most likely to explain a
      throughput or latency change on its own
    → verify: re-record BOTH runs on the same major version. Whatever difference
      survives is attributable to the change under test; whatever disappears was
      the JVM upgrade. There is no way to subtract it analytically
  MINOR / PATCH differs (21.0.3 -> 21.0.4)
    → targeted fixes; usually low behavioural impact but NOT zero (P1, R0)
  BUILD NUMBER or LTS SUFFIX differs only (21.0.3+9 vs 21.0.3+10)
    → same source, different build. Suspect a different vendor image or
      build flags (P2, R0)
  THE STRINGS ARE IDENTICAL but you still suspect a runtime difference
    → this rule has told you everything it can; it compares ONLY `25.0.3+9-LTS`.
      Vendor, VM flavour, and architecture are invisible to it (P2, R0)
    → read `jvmName` from the profile metadata for vendor and flavour, and
      `Instance Type` from `systeminfo` for architecture. Continue to STEP 2b

STEP 2b — Read the sibling metadata fields this rule does NOT compare.
  `jdk.JVMInformation` also carries `jvmName`, `jvmArguments`, `javaArguments`,
  `jvmFlags`, `jvmStartTime`, and `pid`. None are compared by any rule.

  `jvmName` differs (e.g. Server VM vs Client VM, or Zero/OpenJ9)
    → STOP. `-Xint` or Client VM makes performance data meaningless (P0, R2)
    → a MISCONFIGURATION, not a version difference — the highest-value catch here,
      and this gate is SILENT on it
    → verify: `jvmName` should read the same on both runs; re-record after fixing
  `jvmName` implies a different VENDOR at the same version
    → same OpenJDK base, different patches, defaults, and CDS archives (P1, R4)
    → verify: standardize on one vendor and re-record. If the difference persists
      at matched vendor AND matched version, the JVM was not the cause; check
      `jvmArguments`, since vendors differ in defaults more than in code
  `jvmArguments` / `jvmFlags` differ
    → heap sizing, GC selection, or JIT flags changed. Often the REAL cause when
      the versions match (P1, R0)
    → verify: match the flags across runs and re-record

STEP 3 — Cross-check what else changed with the JVM.
  A JVM version change usually arrives with an image change, so verify:
  → `Kernel Version Mismatch` and `AMI ID` — did the base image change too?
  → `Tiered Compilation Check` — but note its regex matches BOTH signs, so it
    fires only when the flag is absent entirely (see that playbook) (P2, R0)
  → GC selection: aperf does not report the active GC directly; read
    jvmArguments in the profile metadata

STEP 4 — What survives?
  VALID      : configuration findings (THP, ENA Express state)
  CONFOUNDED : IPC, cache/TLB miss rates, all CPU-time attribution
  VOID       : any claim that an application code change caused the delta

INSUFFICIENT DATA
  → forms C and D above, and the absent-data case in STEP 0
```

## Runtime-specific consequences

This is the **only runtime-version gate aperf has**, and it covers Java alone.

| Runtime | Version gate in aperf | Consequence |
|---|---|---|
| **Java** | This rule — but inert without `--save-profile-events` | Works only when explicitly enabled |
| **.NET** | **None** | A CLR major-version change (GC and JIT rewrites, `DATAS` on by default in newer versions) is completely invisible to aperf |
| **Python** | **None** | A 3.11/3.12/3.13 change (specialising interpreter, JIT work, free-threading builds) is invisible. `processes` shows only a truncated `comm` like `python3` |
| **Perl** | **None** | Version and, more importantly, *build* configuration (`perl -V`: threading, allocator) are invisible |

**Therefore: for .NET, Python, and Perl, runtime-version parity must be verified manually as a mandatory
pre-read step.** There is no finding that will ever tell you it drifted. This is a documentation-level gap in
aperf, not something the tree can compensate for.

Concretely, capture on both hosts before comparing (all R0):

| Runtime | Command |
|---|---|
| Java | `java -version` and `java -XX:+PrintFlagsFinal -version` for the effective flag set |
| .NET | `dotnet --info` (runtime version, RID, and whether Server GC is active) |
| Python | `python3 -VV` plus `pip freeze` for C-extension versions, which are architecture-specific |
| Perl | `perl -V` — the build config matters more than the version string |

## Architecture-specific considerations

The JVM abstracts the ISA, which makes it easy to assume architecture is irrelevant here. It is not: **the same
JVM version generates materially different code on aarch64 and x86_64**, and several intrinsics are
architecture-gated. Confirm architecture from `pmu_config.json`
([ARCHITECTURE.md](../ARCHITECTURE.md) §1) — the JVM version string aperf captures does not reliably encode it.

| Observed | Reading | Action |
|---|---|---|
| Same JVM version, architectures differ | **Different generated code, same bytecode.** The finding does not fire, and nothing else in aperf flags it | Compare as an architecture study, not a JVM one (P0, R0) |
| JVM version differs **and** architectures differ | Two confounded variables | Re-run with a matched JDK per architecture (P0, R3) |
| VM flavour differs (`-Xint`, Client VM) | Highest-value catch, architecture-independent | P1, R2 |
| JDK < 17 on aarch64 | Missing LSE atomics and several intrinsics | Upgrade to JDK 17+ (Corretto recommended on Graviton) (P1, R3) |

**arm64-specific JVM configuration requests** — verify these before attributing any regression to the
application:

| Request | Why | Signal if unmet | P / R |
|---|---|---|---|
| **JDK 17+ (Corretto)** on Graviton | LSE atomic support (Corretto 11+), better codegen | `Old-Style Atomic Instructions` (arm64-only finding) | P1 / R3 |
| **AES/GCM intrinsics** | Hardware AES on Graviton; large gains on TLS-heavy paths | Low `ipc` on crypto-heavy work | P2 / R2 |
| **`-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M`** | JIT code footprint is larger on aarch64 | `High Code Sparsity` (arm64-only), `inst-l1-mpki` | P2 / R2 |
| **THP `madvise` rather than `always`** | Default thread stack is 2 MB on aarch64; `always` can commit it all | Elevated RSS with high thread counts | P2 / R1 |
| **`-XX:+OmitStackTraceInFastThrow`** | Exception handling is materially costlier on Graviton | Throw-heavy hot paths | P3 / **R5** |

`Old-Style Atomic Instructions` deserves emphasis: it is the one finding that directly detects an unmet
architecture-specific JVM requirement, and **it can only fire on arm64**. On x86_64 its absence means nothing.

**For .NET, Python, and Perl there is no version gate at all** (see the section above), and the architecture
dimension makes that gap worse — for those three, the runtime version *and* the architecture-specific build must
both be captured manually. The highest-value checks: `dotnet --info` (confirm the RID is `linux-arm64` vs
`linux-x64` and that R2R/NativeAOT was actually published for it), `python3 -c "import sysconfig;
print(sysconfig.get_platform())"` plus the installed wheel tags, and `perl -V` for the XS build configuration
([ARCHITECTURE.md](../ARCHITECTURE.md) §5.3).

## Verification

Pin the JVM (exact vendor and build, not just the major version), rebuild the image, and re-run with
`--save-profile-events` so the gate can actually fire. Confirm the finding disappears. If the JVM change was
intentional, keep it and read the report as a JVM comparison — every delta is then attributable to the runtime.

## Do not

- **Do not read this as a performance finding.** It says the Java comparison is invalid, not that either run was
  slow.
- **Do not read the score as magnitude.** Flat −256 with **no score table**; a build-number difference and a
  JDK 11 → 21 jump score identically. **The strings carry the magnitude.**
- **Do not expect a semantic comparison.** Exact string equality — the rule cannot tell you which JVM is newer.
- **Do not attribute JIT, GC, allocation, memory, or `perf_stat` deltas to the application** while this is open.
- **Do not trust the delta in `Excessive Exceptions` or `Tiered Compilation Check`** across different JVM
  versions.
- **Do not read absence of the finding as "versions match".** The hidden `--save-profile-events` flag is required
  on both runs, and an absent base run returns silently.
- **Do not confuse the four description forms.** Two are version mismatches; **"not found … for '{key}'" is a
  JVM-identity or collection problem, and "not found in run {base_run}." means no comparison happened at all.**
- **Do not assume all JVMs were compared** in a multi-JVM report. Keys are matched by exact name; renamed JVMs are
  skipped, and JVMs unique to the comparison run are never examined.
- **Do not look for the architecture, the vendor, or the VM flavour in this finding.** `jvmVersion` is the short
  form — `25.0.3+9-LTS`, verified against a real archive — so an `aarch64` → `x86_64` move, a Corretto → Temurin
  swap, or a `Server VM` → `Client VM` change at the same JDK build leaves this gate **silent**. Read `jvmName` and
  `jvmArguments` from the profile metadata and `Instance Type`/`Kernel Version` from `systeminfo`.
- **Do not read a −256 here as "the JVMs differ" without reading the description.** The most likely cause is that
  `--save-profile-events` was never passed, which makes the rule fire on the base run alone with the
  **"not found in run {base}."** form while the `message` still claims a cross-run difference. On a single-run
  report that −256 is guaranteed to be noise.
- **Do not assume the `group` was verified.** `lookup_key_value` searches all metadata groups by key.
- **Do not stop at the version.** `jvmArguments` differences are not reported here and are often the real cause.
- **Do not tune anything.** The fix is matched JVMs or an explicit acknowledgement that the runtime change *is*
  the experiment.

## References

- Rule definition: `src/analytics/rules/java_profile.rs:40` — `group: "jdk.JVMInformation"`,
  `key: "jvmVersion"`, `should_exist: true`, `score: Score::Critical`.
- Rule template: `src/analytics/rule_templates/profile_metadata_comparison_rule.rs` — resolves
  `analytics::get_base_run_name()` (`:62`); **returns early with a `debug!` if the base run is absent** (`:64`);
  builds `profiler_key → value` maps per run (`:72`); if `base_values` is empty and `should_exist`, files a
  finding **against the base run keyed by `self.rule_name`** with the `"not found in run {}."` description
  (`:92`–`:108`) and returns; skips the base run when iterating comparison runs (`:111`); **if both runs have
  exactly one entry, compares values regardless of key match** (`:123`); otherwise matches base keys by exact name
  in the comparison run (`:146`); **inserts `self.score` directly — no `compute_finding_score` call, so the score
  is flat**.
- Description formats: `:100` (empty base), `:135` (single-JVM, names both keys), `:151` (multi-JVM),
  `:155` (key missing in comparison run).
- Score: `Score::Critical = −256`, `src/analytics/mod.rs:147`.
- Value lookup: `profiler_value_by_key`, `src/data/common/processed_data_accessor.rs:349` — delegates to
  `lookup_key_value` (`:571`), which **scans all metadata groups and returns the first key match**. The rule's
  `group` field is used **only in the description text**.
- Metadata construction: `parse_jfr_metadata`, `src/profiling/jfr/convert.rs:477` — builds key-value groups named
  `jdk.JVMInformation`, `jdk.ActiveRecording`, and `jdk.ActiveSetting`, stringifying every field value
  (`json_to_string`, `:488`) and skipping `startTime`.
- Metadata extraction: `src/data/java_profile.rs:294` — `jfr print --json --events` over
  `jdk.ActiveRecording, jdk.ActiveSetting, jdk.CheckPoint, jdk.Metadata, jdk.JVMInformation, jdk.NativeLibrary`;
  on failure the JSON is `Value::Null`, producing empty metadata and hence the "not found" description forms.
- **Collection precondition:** `src/data/java_profile.rs:375` — the `Profiler` (and hence
  `java_profiler_data_<pid>.json`) is written **only when `init_params.save_profile_events` is true**; the `TODO`
  at `:372` states the flow is *"only executed in tests"* pending launch. The flag is the **hidden**
  `--save-profile-events` (`src/record.rs:96`, `hide = true`; wired at `:219`). Report-side, if no profiler data
  is read the data type falls back to `AperfData::Graph` (`src/data/java_profile.rs:527`), leaving
  `profiler_keys` empty and **all three `java_profile` rules inert** — including this validity gate.
- Profiler key naming: `src/data/java_profile.rs:459` — the deduped JVM name from `process_names.first()`
  (or `"unknown"`), with `" (N)"` appended for duplicates. **Not the PID** — which is why a renamed JVM or a
  changed startup order can break key matching in the multi-JVM path.
- Profile metrics: `PROFILE_METRICS = ["cpu", "alloc", "wall"]`, `src/data/java_profile.rs:32`.
- Data type semantics: `data-descriptions.ts:4690` — *"JVM and async-profiler metadata are also displayed."*
- Enablement: `--profile-java`, `src/record.rs:93`.
- Related playbooks: `excessive-exceptions.md`, `tiered-compilation-check.md`,
  `../systeminfo/kernel-version-mismatch.md`, `../systeminfo/inconsistent-number-of-cpus.md`,
  `../meminfo/inconsistent-physical-memory.md`.
- [JDK release notes](https://www.oracle.com/java/technologies/javase/jdk-relnotes-index.html)
- [Graviton perfrunbook — language runtime versions](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html)
