# Architecture Dimension — Intel, AMD, and arm64

Third axis of the guidance model, alongside [GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) (inputs, priority, risk) and
[GATES.md](GATES.md) (comparison validity).

This file exists because **the same finding, at the same value, means different things on different
architectures — and on some architectures it cannot fire at all.** aperf selects its PMU event set by CPU
vendor and microarchitecture, so the finding inventory is not constant across a fleet. A tree that ignores
this will confidently explain a finding that was mechanically impossible on the machine in question, or read
a threshold breach that is an artefact of how the metric was normalised.

---

## 1. Architecture *is* recoverable from a run — correcting a gap

[GUIDANCE_MODEL.md](GUIDANCE_MODEL.md) §1.4 states that CPU architecture is not collected. That is true of
`systeminfo` — there is no `arch` key, no `uname -m`, no CPU model name — but it is **not true of the run
directory as a whole.**

When `perf_stat` collection runs, aperf writes the PMU config it selected to **`pmu_config.json` in the run
data directory**:

```rust
// src/data/perf_stat.rs:801
pmu_config.save_to_file(&get_saved_pmu_config_path(&init_params.run_data_dir))?;

// src/data/perf_stat.rs:52
fn get_saved_pmu_config_path(run_dir: &Path) -> PathBuf {
    PathBuf::from(run_dir).join("pmu_config.json")
}
```

The whole run directory is archived (`tar.append_dir_all(dir_name, run_data_dir)`, `src/record.rs:312`), so
`pmu_config.json` ships inside the `.tar.gz`, and the report path *requires* it
(`PmuConfig::from_file(&get_saved_pmu_config_path(...))`, `src/data/perf_stat.rs:1298`).

**Consequence: the event encodings in `pmu_config.json` are an architecture fingerprint.** It is the most
reliable architecture signal in an aperf run — stronger than the `Instance Type` inference, because it is
what aperf actually measured with rather than what the instance nominally is.

### 1.1 Reading the fingerprint

| Observed in `pmu_config.json` | Architecture |
|---|---|
| Event strings start `armv8_pmuv3_0/` | **arm64** (Graviton) |
| `Code_Sparsity` or `STREX_SPEC` present | **arm64** — these exist in no other config |
| `L3_READ` present (`event=0x36`) | **arm64, Graviton 5** (`grv_5` extension applied) |
| Event strings start `cpu/`, `Cycles` = `cpu/event=0x3c,umask=0x0/` | **Intel** |
| `Slots` present (`cpu/event=0xa4,umask=0x1/`) | **Intel Ice Lake or Sapphire Rapids** |
| `Data_RD_TLB` present | **Intel Sapphire Rapids** only |
| Event strings start `cpu/`, `Cycles` = `cpu/event=0x76,umask=0x0/` | **AMD** (0x76 is the AMD cycle event) |
| `Backend_Stalls_1` + `Backend_Stalls_2` | **AMD Milan** |
| `stall-backend-pkc` = `... * 167` | **AMD Genoa** |
| No `stall-backend-pkc` metric at all | **AMD, neither Milan nor Genoa** |

The single cleanest discriminator is the `Cycles` event: `armv8_pmuv3_0/event=0x11/` (arm64) vs
`cpu/event=0x3c` (Intel) vs `cpu/event=0x76` (AMD).

### 1.2 Ordered architecture-derivation chain

1. **`pmu_config.json` in the run directory** — direct evidence of what aperf measured. Use this first.
2. **`Instance Type` from `systeminfo`** — `*g.*` families (`m7g`, `c7g`, `r8g`, `x2gd`) are Graviton/arm64;
   `*i*` are Intel; `*a*` are AMD. An inference, but it also yields the ENA ceilings the network playbooks need.
3. **`Kernel Version` suffix** — Amazon Linux appends `.x86_64` / `.aarch64`. Distro-specific.

Steps 2 and 3 are inferences; step 1 is data. **If `perf_stat` was not collected, there is no `pmu_config.json`
and architecture falls back to inference.** Say which one you used.

### 1.3 How aperf detects the microarchitecture — and what it misses

`CpuInfo` (`src/data/common/utils.rs:17`–`:100`) parses exactly three fields from `/proc/cpuinfo`:
`CPU part`, `vendor_id`, `model name`. The predicates are far cruder than the config filenames suggest:

| Predicate | Actual implementation | What this means in practice |
|---|---|---|
| `is_graviton()` | **`self.part.is_some()`** | Any CPU exposing `CPU part` — i.e. **any aarch64 chip**, Graviton or not. Not a Graviton test |
| `is_graviton_5()` | `part == "0xd84"` | Exact match on one part code |
| `is_intel()` | `vendor_id == "GenuineIntel"` | Reliable |
| `is_intel_icelake()` | `model_name == "Intel(R) Xeon(R) Platinum 8375C CPU @ 2.90GHz"` | **Exact full-string match, including the clock speed** |
| `is_intel_sapphire_rapids()` | `model_name == "Intel(R) Xeon(R) Platinum 8488C"` | **Exact full-string match** |
| `is_amd()` | `vendor_id == "AuthenticAMD"` | Reliable |
| `is_amd_genoa()` | `model_name.starts_with("AMD EPYC 9R14")` | Prefix match |
| `is_amd_milan()` | `model_name.starts_with("AMD EPYC 7R13")` | Prefix match |

Four consequences that matter for guidance:

- **Any unlisted Intel or AMD part silently gets the generic config.** A newer Intel part, a different SKU, or
  a `model name` string that differs by one character falls through to `intel_pmu_config.json` /
  `amd_pmu_config.json`. Nothing warns you. For AMD this is not cosmetic — see §3.
- **`is_graviton()` is really an "is aarch64" test.** Order matters: it is checked *first*
  (`src/data/perf_stat.rs:764`), so on any arm64 host the Graviton config is used regardless of vendor.
- **An unrecognised CPU aborts `perf_stat` entirely** — `bail!("Unrecognized CPU type for PMU config
  selection")`. On such a host you get no PMU data and therefore none of the 15 `perf_stat` findings. Their
  absence says nothing about the workload.
- **Detection happens at *record* time on the *recording* host.** It reflects the machine, not the instance
  type you believe you launched.

Part-code mapping (**external knowledge, not present in aperf's source — verify before relying on it**):
`0xd0c` Neoverse N1 (Graviton 2), `0xd40` Neoverse V1 (Graviton 3), `0xd4f` Neoverse V2 (Graviton 4),
`0xd84` treated by aperf as Graviton 5.

---

## 2. Which findings can fire on which architecture

Derived by diffing the 8 files in `src/pmu_configs/` and resolving `extend_from_default`, which is a plain
`HashMap::extend` — **the microarchitecture file overwrites same-named keys from the base file**
(`src/data/perf_stat.rs:200`–`:205`).

When a rule's metric is absent, every `perf_stat` template hits `None => continue` and **produces no finding
and no warning** (`time_series_stat_threshold_rule.rs:69`,
`time_series_stat_intra_run_comparison_rule.rs:77` and `:86`, `time_series_stat_run_comparison_rule.rs:95`).

| Finding | Metric | arm64 G2–G4 | arm64 Grv5 | Intel generic | Intel ICX | Intel SPR | AMD generic | AMD Milan | AMD Genoa |
|---|---|---|---|---|---|---|---|---|---|
| Reduced Instructions per Cycle | `ipc` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Frontend-Dominated CPU Stalls | both stall metrics | ✅ | ✅ | ✅ | ⚠️ | ⚠️ | **❌** | ✅ | ⚠️ |
| Backend-Dominated CPU Stalls | both stall metrics | ✅ | ✅ | ✅ | ⚠️ | ⚠️ | **❌** | ✅ | ⚠️ |
| High Branch Mispredictions | `branch-mpki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| High L1 Instruction Cache Misses | `inst-l1-mpki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Instruction TLB Misses | `inst-tlb-mpki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Instruction TLB Table Walks | `inst-tlb-tw-pki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **High Code Sparsity** | `code-sparsity` | ✅ | ✅ | **❌** | **❌** | **❌** | **❌** | **❌** | **❌** |
| High L1 Data Cache Misses | `data-l1-mpki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| High L2 Cache Misses | `l2-mpki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| High L3 Cache Misses | `l3-mpki` | ✅ | ⚠️ | ✅ | ✅ | ✅ | ⚠️ | ⚠️ | ⚠️ |
| Data TLB Misses | `data-tlb-mpki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Data TLB Table Walks | `data-tlb-tw-pki` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Old-Style Atomic Instructions** | `strex-spec-pki` | ✅ | ✅ | **❌** | **❌** | **❌** | **❌** | **❌** | **❌** |
| PMU Counter Collection Multiplexing | `mux_counter_schedule_rate` | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

✅ can fire · ⚠️ can fire but the metric is not comparable to other architectures (§3) · ❌ **mechanically
impossible**

The columns are the **eight effective profiles** — the three base configs plus each base merged with its five
microarchitecture extensions — not the eight files. A profile's metric set is `base ∪ extension` with the
extension winning on collisions, which is why Graviton 5 gets its own column: it inherits every arm64 metric
but **redefines `l3-mpki`** (§3.2). The same 8 profile names are the values of the `architectures` array on
each `perf_stat` entry in `FINDINGS_REGISTRY.json`, so a tool can apply this table without parsing it.

### 2.1 The three structural asymmetries

**Two findings are arm64-only.** `High Code Sparsity` (event `0x11c`) and `Old-Style Atomic Instructions`
(`STREX_SPEC`, event `0x6f`) exist in no Intel or AMD config. Their absence in an x86_64 report is a property
of aperf, not of the code. Never report "no code sparsity problem" for an x86_64 run — report that the metric
does not exist there.

**Both stall findings are silently dead on generic AMD.** `amd_pmu_config.json` has **no
`stall-backend-pkc`**; only the Milan and Genoa extensions add it. Since both stall rules reference *both*
stall metrics (one as baseline, one as comparison), a missing backend metric kills **both** directions. So on
an AMD part that is neither `AMD EPYC 7R13*` (Milan) nor `AMD EPYC 9R14*` (Genoa) — including any future EPYC
generation, until aperf adds it — the report contains **no stall attribution at all**, and `Reduced
Instructions per Cycle` fires with its own remediation advice ("Check the frontend and backend stall metrics
to locate the bottleneck") pointing at metrics that were never collected.

**Four Intel metrics are collected but no rule consumes them.** `data-st-tlb-mpki` and `data-st-tlb-tw-pki`
(Intel, all) plus `data-rd-tlb-mpki` and `data-rd-tlb-tw-pki` (Sapphire Rapids only) have no rule in
`src/analytics/rules/perf_stat.rs`. Intel splits data-TLB into load and store paths; the generic
`data-tlb-mpki` rule only reads the load path (`cpu/event=0x8`). **On Intel, a store-side TLB problem is
measured, charted, and never flagged.** Read those series manually.

---

## 3. Same metric name, different quantity

This is the subtlest and highest-value part of the architecture dimension. The metric *names* are deliberately
unified across configs so the same rules apply everywhere. The *quantities* behind them are not equivalent.

### 3.1 `stall-backend-pkc` — three different normalisations

| Profile | Effective definition | Denominator |
|---|---|---|
| arm64 G2–G4 | `Backend_Stalls / Cycles * 1000` | cycles |
| arm64 Graviton 5 | `Backend_Stalls / Cycles * 1000` (inherited) | cycles |
| Intel generic | `Backend_Stalls / Cycles * 1000` | cycles |
| **Intel Ice Lake** | `Backend_Stalls / Slots * 1000` | **issue slots** |
| **Intel Sapphire Rapids** | `Backend_Stalls / Slots * 1000` | **issue slots** |
| **AMD generic** | **absent** | — (both stall findings dead, §2.1) |
| AMD Milan | `(Backend_Stalls_1 + Backend_Stalls_2) / Cycles * 1000` | cycles |
| **AMD Genoa** | `Backend_Stalls / Cycles * 167` | cycles, **scaled by 167 not 1000** |

`stall-frontend-pkc` is `Frontend_Stalls / Cycles * 1000` in **every** config.

**Therefore the two stall findings — which compare backend against frontend *within a single run*
(`time_series_stat_intra_run_comparison`, threshold ±10%) — compare differently-normalised numbers on Ice
Lake, Sapphire Rapids, and Genoa.** On the Intel ones the backend value is divided by issue slots (several per
cycle on these cores) while the frontend value is divided by cycles; on Genoa the backend value carries a ×167
scale against the frontend's ×1000. In both cases backend stalls are systematically deflated relative to
frontend stalls, biasing the pair toward reporting **Frontend-Dominated CPU Stalls** and away from
**Backend-Dominated CPU Stalls**.

Practical rule: **on Ice Lake, Sapphire Rapids, and Genoa, treat the frontend-vs-backend verdict as
directional at best and do not act on a narrow margin.** Corroborate from the memory-hierarchy findings
(`l2-mpki`, `l3-mpki`, `data-tlb-*`) which are unaffected by the normalisation, and from the raw event series.
On arm64, generic Intel, and Milan the comparison is apples-to-apples.

Also note the Ice Lake and Sapphire Rapids extensions **redefine `Frontend_Stalls` with a different `cmask`**
(base Intel `cmask=0x4`, Ice Lake `cmask=0x5`, Sapphire Rapids `cmask=0x6`), so even the frontend number is
not comparable across Intel generations.

### 3.2 `l3-mpki` — the same threshold over four different quantities

| Profile | Effective definition | What it actually counts |
|---|---|---|
| arm64 G2–G4 | `L3 / Instructions * 1000`, `L3` = `event=0x37` | last-level cache misses |
| **arm64 Graviton 5** | `(L3 / L3_READ * L2) / Instructions * 1000` | **a derived estimate**, not a direct count |
| Intel (all three) | `L3 / Instructions * 1000`, `L3` = `event=0x2e,umask=0x41` | longest-latency-cache misses |
| **AMD (all three)** | `L1_Any_Fills_DRAM / Instructions * 1000`, `event=0x44,umask=0x8` | **L1 fills sourced from DRAM** |

Neither the Ice Lake, Sapphire Rapids, Milan nor Genoa extension touches `l3-mpki`, so each inherits its base
definition — which is why the AMD reading applies to all three AMD profiles and the Intel reading to all three
Intel ones. The rule applies one threshold (`> 10.0`, `Bad`) to all four distinct quantities. The AMD definition is a DRAM-fill counter, not
an L3 miss counter, and the Graviton 5 definition is an inferred ratio. **Do not compare `l3-mpki` across
architectures, and do not treat the AMD value as an L3 hit-rate statement** — on AMD it is closer to a DRAM
traffic indicator, which is arguably more actionable but is not what the finding's message says.

### 3.3 `branch-mpki` and the misleading event names

All three vendors count *mispredictions* here despite the arm64 and Intel configs naming the event
`Branches`: arm64 `event=0x10`, Intel `event=0xc5`, AMD `event=0xc3` (`Branch_Mispredictions`). The metric is
comparable in kind. The arm64 event is the speculative-mispredict counter rather than a retired one, so
expect a systematically higher value on arm64 for identical code; treat the `>= 10.0` threshold as
architecture-relative and compare like-for-like only.

### 3.4 `PMU Counter Collection Multiplexing` fires nearly everywhere, unevenly

Default collection mode is **grouped** — `InitParams::new` initialises `pmu_counter_mode` to
`GROUPED_PMU_MODE` (`src/data_collection.rs:379`), and ungrouped is reached only when the operator passes the
opt-in `--ungroup-pmu-events` flag (`src/record.rs:110`, applied at `:197`–`:198`; dispatched at
`src/data/perf_stat.rs:805`). **The default is therefore the higher counter count**, which is the pessimistic
case for multiplexing:

| Profile | Counters, default (grouped) | Counters with `--ungroup-pmu-events` |
|---|---|---|
| arm64 G2/G3/G4 | 28 | 15 |
| arm64 Graviton 5 | 30 | 16 |
| Intel generic | 28 | 15 |
| Intel Ice Lake | 28 | 16 |
| **Intel Sapphire Rapids** | **32** | **18** |
| **AMD generic** | **22** | **12** |
| AMD Milan | 25 | 14 |
| AMD Genoa | 24 | 13 |

The two columns are not two event lists. In grouped mode aperf builds one counter group **per metric**
containing every event that metric's expression references (`create_metric_counter_groups`,
`src/data/perf_stat.rs:213`), so an event shared by several metrics costs one counter *per group* — aperf's own
doc comment at `:207`–`:211` says this "puts more loads on the collection multiplexing, and each event is
collected for less time." Ungrouped creates one counter per *unique* event instead (`:277`). That is why the
grouped total is roughly double, and why Ice Lake (16 unique events, 28 grouped) lands below Graviton 5
(16 unique events, 30 grouped): same event count, different metric-to-event fan-out.

Every number in both columns exceeds the general-purpose PMU register count of any current server core, so
multiplexing — and therefore this finding — is effectively guaranteed on all architectures, in either mode.
aperf probes the real limit at runtime (`probe_pmu_counter_limit`, `src/data/perf_stat.rs:344`, bounded 1–16)
using an architecture-specific probe event, and only logs the warning at `debug!` level (`warn_multiplexing`,
`:59`, with an explicit TODO saying the default config always triggers it).

**So this finding is a data-quality statement, not a workload problem, and its severity is
architecture-dependent** — a config with more counters multiplexes harder, giving a lower schedule rate and a
worse score for reasons that have nothing to do with the application. At the default grouped mode Sapphire
Rapids schedules 32 counters against generic AMD's 22. Read the schedule-rate value: the further below 100%,
the more every other `perf_stat` number in the report is an extrapolation from a partial sample. It also means
**cross-architecture `perf_stat` comparisons inherit different sampling error**, on top of the definitional
differences above.

**Check the mode before comparing two runs.** `pmu_counter_mode` is recorded in the run metadata and read back
on the report path (`src/report.rs:98`), and an empty value there is treated as legacy and defaulted
(`src/data/perf_stat.rs:1289`). A run recorded with `--ungroup-pmu-events` carries roughly half the counter
pressure of a default run, so **its schedule rate is better for a reason unrelated to the workload** — comparing
a grouped baseline against an ungrouped run will show a multiplexing "improvement" that is purely a collection
flag.

---

## 4. Architecture-specific problems, by architecture

### 4.1 arm64 (Graviton)

| Problem | aperf signal | Fix | P / R |
|---|---|---|---|
| **Load/store-exclusive atomics instead of LSE** | `Old-Style Atomic Instructions` (`strex-spec-pki >= 10`) | Rebuild with `-march=armv8.2-a` (or `-mcpu=neoverse-*`), or `-moutline-atomics` for portable binaries. Rust: `RUSTFLAGS="-Ctarget-feature=+lse"` | P1 / **R3** |
| **Sparse code layout** | `High Code Sparsity` (`> 0.5`) | `-flto`, `-Os`, PGO/AutoFDO. JVM: `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M` | P2 / **R3** (R2 for JVM flags) |
| **Larger default thread stacks** | `meminfo` / RSS higher than the x86 baseline for the same app | JVM default thread stack is 2 MB on aarch64 vs 1 MB on x86_64; THP `always` can commit the full 2 MB. Set THP to `madvise`, or tune `-Xss` | P2 / R1–R2 |
| **Missing arch-specific native build** | `Reduced Instructions per Cycle`, raised `inst-l1-mpki` | A generic or emulated build, or a Python wheel that fell back to source. See §5 | P1 / R3 |
| **Weaker memory model than x86 TSO** | Not visible in aperf | Correctness, not performance: custom lock-free code needs explicit barriers. Standard mutexes are safe | — / R5 |
| **Exception-heavy hot paths** | High `ipc` degradation with heavy `java_profile` throw activity | Exception handling is materially costlier on Graviton; `-XX:+OmitStackTraceInFastThrow` | P3 / **R5** |

arm64-only aperf capabilities worth knowing: **hotline requires ARM SPE** (`/sys/devices/arm_spe_0/type`,
`src/hotline/sys.c:106`; the record path is `#ifdef __aarch64__`, `src/hotline/hotline.c:336`), so
hotline-based memory-hotspot analysis is **unavailable on Intel and AMD entirely**.

### 4.2 Intel

| Problem | aperf signal | Fix | P / R |
|---|---|---|---|
| **Store-side TLB pressure invisible** | `data-st-tlb-mpki` / `data-st-tlb-tw-pki` charted, **no rule** (§2.1) | Read the series manually; treat as an unflagged Data TLB finding and apply THP guidance | P2 / R0→R1 |
| **Stall verdict biased toward frontend** on ICX/SPR | `Frontend-Dominated CPU Stalls` firing with a narrow margin | Slots-vs-cycles normalisation (§3.1). Corroborate with cache/TLB findings before acting | P2 / R0 |
| **ISA level not used by the build** | `Reduced Instructions per Cycle`; low IPC on vectorisable work | AVX-512 / AMX on SPR require an ISA-aware build or library. For oneDNN, `ONEDNN_MAX_CPU_ISA` gates dispatch (`AVX512_CORE`, `AVX512_CORE_AMX`, `AVX10_*`) | P1 / R3 |
| **Unlisted SKU → generic config** | `pmu_config.json` lacks `Slots` on a machine you believe is ICX/SPR | Exact-string detection (§1.3) failed. Metric definitions differ from what you assume; do not compare against a correctly-detected run | P1 / R0 |
| **Highest multiplexing pressure** (SPR, 18 events) | `PMU Counter Collection Multiplexing` with a low rate | Use a custom `--pmu-config` with only the events you need | P3 / R0 |

### 4.3 AMD

| Problem | aperf signal | Fix | P / R |
|---|---|---|---|
| **No stall attribution on non-Milan/Genoa parts** | Both stall findings **absent**; `Reduced IPC` present and pointing at them | Confirm via `pmu_config.json` (no `stall-backend-pkc`). Collect backend stalls with a custom `--pmu-config`, or accept that IPC cannot be decomposed | **P1** / R0 |
| **`l3-mpki` is a DRAM-fill counter** | `High L3 Cache Misses` | Read it as DRAM traffic, not L3 hit rate (§3.2). Do not compare the value to an Intel or arm64 run | P2 / R0 |
| **NPS / NUMA topology effects** | `numastat` data present but **it has no rules**; `l3-mpki` and `data-tlb-*` elevated | EPYC exposes multiple NUMA domains per socket; cross-CCX/CCD access is costly. Pin workers, size heaps per NUMA node | P2 / R2 |
| **Genoa backend scale (×167)** | Backend stalls implausibly low vs frontend | Normalisation artefact (§3.1), not a real frontend bottleneck | P2 / R0 |
| **Generic x86 build ignoring Zen features** | `Reduced Instructions per Cycle` | Build with `-march=znver3` (Milan) / `-znver4` (Genoa) or an AMD-tuned library. See §5 | P1 / R3 |

Note the instance-family mapping for the two detected microarchitectures: `AMD EPYC 7R13` (Milan) backs the
6th-generation `*a` families, `AMD EPYC 9R14` (Genoa) the 7th. A 5th-generation or newer-than-Genoa AMD
instance gets the generic config and loses stall attribution.

---

## 5. Architecture-specific configuration requests

The class of problem the ONNX Runtime examples illustrate: **the application asks to be built or configured
for a specific architecture, and that request is what actually determines the instruction mix aperf
measures.** When it is unmet, aperf reports the *symptom* (low IPC, high L1I misses) and cannot name the
*cause*, because aperf has no view of build flags, execution providers, or dispatch environment variables.

### 5.1 ONNX Runtime as the worked example

The same model, on the same graph, runs through a completely different kernel library depending on how the
runtime was built:

| Target | Execution provider | Build flag | Verified |
|---|---|---|---|
| Intel CPU | oneDNN / DNNL | `--use_dnnl` | ✅ upstream `build.py` |
| Intel CPU / NPU | OpenVINO | `--use_openvino <CPU\|GPU\|NPU>` | ✅ upstream `build.py` |
| **AMD EPYC** | **ZenDNN** | **`--use_zendnn`** (CMake `-Donnxruntime_USE_ZENDNN=ON`) | ✅ `amd/ZenDNN-onnxruntime`, branch `rel-1.19.2_zendnn_rel`, `tools/ci_build/build.py:557` |
| arm64 | Arm Compute Library | `--use_acl --acl_home=… --acl_libs=…` | ✅ upstream `build.py` |
| arm64 | Arm NN | `--use_armnn` (`--armnn_relu`, `--armnn_bn`) | ✅ upstream `build.py` |
| any | XNNPACK | `--use_xnnpack` | ✅ upstream `build.py` |
| any | default CPU EP | *(none)* | baseline |

Two things worth knowing precisely, because both are easy to get wrong:

- **`--use_zendnn` does not exist upstream.** It is absent from `microsoft/onnxruntime` and from the AMD
  fork's `main` branch (which tracks upstream); it exists only on the fork's `*_zendnn_*` branches. So "we use
  ONNX Runtime on AMD" does **not** imply ZenDNN — it almost certainly means the default CPU EP unless someone
  deliberately built that branch.
- **Falling back to the default CPU EP is silent.** An unavailable or unregistered provider means the graph
  runs on the generic kernels. Throughput drops; nothing errors.

**How this lands in aperf:** an EP change alters the instruction mix wholesale. Expect movement in
`ipc` (vectorised kernels retire far more work per cycle), `inst-l1-mpki` and `code-sparsity` (arm64 —
specialised kernel libraries are large), `data-l1-mpki` / `l2-mpki` / `l3-mpki` (different blocking and
tiling strategies), and the stall balance. **No aperf finding names the execution provider.** Capture it
manually — `onnxruntime.get_available_providers()` and the session's actual provider list — and record it
alongside the run.

### 5.2 The cross-architecture trap this creates

Comparing an x86_64 run against an arm64 run of "the same" inference service, where the x86 build has oneDNN
with AVX-512/AMX and the arm64 build silently fell back to the default CPU EP because ACL was never built:

| Check | Base (`m7i`) | Compared (`m7g`) | Gate fires? |
|---|---|---|---|
| `CPUs` | 16 | 16 | No |
| `MemTotal` | 64 GiB | 64 GiB | No |
| `Instance Type` | `m7i.4xlarge` | `m7g.4xlarge` | **No rule exists** |
| Architecture | x86_64 | **aarch64** | **No rule exists** |
| Execution provider | oneDNN + AMX | **default CPU EP** | **Not collected at all** |

**Zero validity gates fire.** aperf reports a clean comparison of a vectorised build against a scalar one, and
the whole `perf_stat` section is incomparable in *meaning* on top of that. This is the concrete case that
makes the architecture-parity check (§6) mandatory rather than advisory.

### 5.3 The same pattern in the four target runtimes

| Runtime | Architecture-specific request | Failure mode when unmet | aperf signal |
|---|---|---|---|
| **Python** | Wheel must match `manylinux_*_x86_64` / `_aarch64`; numeric stacks dispatch on ISA at runtime | pip builds from source with generic flags, or a pure-Python fallback replaces a C extension | `Reduced IPC`, raised `inst-l1-mpki`; `processes` shows the interpreter dominating |
| **Java** | Mostly portable, but JIT codegen and intrinsics are per-architecture; JDK 17+ (Corretto) recommended on Graviton; LSE atomics in Corretto 11+ | An old JDK on arm64 generates non-LSE atomics and misses intrinsics | `Old-Style Atomic Instructions` (arm64), `Reduced IPC` |
| **.NET** | ReadyToRun / NativeAOT images are architecture-specific (`linux-x64` vs `linux-arm64`); Server GC heap count follows vCPU | Wrong RID means JIT-only startup or a failed publish; portable build loses R2R | `Reduced IPC`, raised `inst-l1-mpki` early in the run |
| **Perl** | XS modules are compiled per-architecture; `perl -V` build flags matter more than runtime flags | XS module rebuilt with generic flags, or pure-Perl fallback | `Reduced IPC`; often not in `processes`' top 16 |

Native-library dispatch knobs worth recording per run, since none are visible to aperf: `ONEDNN_MAX_CPU_ISA`
(verified, oneDNN), `ZENDNN_LOG_OPTS` / `ZENDNN_BLIS_PATH` (ZenDNN), `OMP_NUM_THREADS` and thread-affinity
settings for any OpenMP-based kernel library. **Version-check these against your own stack before quoting
them** — dispatch variable names move between releases.

---

## 6. Architecture parity as a validity gate

There is **no architecture-parity rule anywhere in aperf.** Verified: nothing under `src/analytics/` mentions
`pmu_config`, `PmuConfig`, `model_name`, or `vendor`, and no rule compares `Instance Type`. The
`CpuInfo` predicates are called from exactly two places, both in `src/data/perf_stat.rs` (PMU config selection
and counter-limit probing) plus one unit test — never from analytics.

**Add this as an explicit manual step in the gate precedence chain** ([GATES.md](GATES.md) § "Precedence
order", step 2a):

```
2a. Architecture parity (MANUAL — no rule exists)
    Compare `pmu_config.json` between the two runs (or, if perf_stat is absent,
    the Instance Type / kernel-suffix inference).

    IF the Cycles event encoding differs (armv8_pmuv3_0/event=0x11 vs cpu/event=0x3c
       vs cpu/event=0x76)
    THEN → STOP. Different vendor/ISA. Every perf_stat comparison is void in MEANING,
           not just in value. Two findings exist on only one side (P0, R4)

    IF the vendor matches but the microarchitecture extension differs
       (Slots present on one side only; *167 on one side only;
        stall-backend-pkc missing on one side only)
    THEN → perf_stat metric DEFINITIONS differ between the runs.
           Stall and l3-mpki comparisons are void; cache/TLB comparisons survive (P0, R0)

    IF one run has pmu_config.json and the other does not
    THEN → PMU collection failed or was skipped on one side; possibly an
           unrecognised CPU (bail!). All 15 perf_stat findings are one-sided (P1, R0)

    ELSE architectures match; proceed.
```

Placed after the hardware gates and before the instance-type check, because a vendor mismatch is strictly
worse than a size mismatch: a size change makes values incomparable, a vendor change makes the *metrics*
incomparable.

---

## 7. Do not

- **Do not report an arm64-only finding as absent-and-therefore-fine on x86_64.** `High Code Sparsity` and
  `Old-Style Atomic Instructions` cannot fire there. Say "not measured on this architecture".
- **Do not read a missing stall finding on AMD as "no stall problem".** Generic AMD has no
  `stall-backend-pkc`, which silences both stall rules with no warning.
- **Do not compare `l3-mpki` across vendors.** It is LL-cache misses on Intel and arm64, a derived estimate on
  Graviton 5, and DRAM fills on AMD.
- **Do not act on a narrow frontend-vs-backend verdict on Ice Lake, Sapphire Rapids, or Genoa.** The two sides
  are normalised differently.
- **Do not treat `PMU Counter Collection Multiplexing` as a workload finding**, and do not compare its
  severity across architectures — the event counts differ by 50%.
- **Do not assume aperf's microarchitecture detection succeeded.** It is exact-string matching on `model
  name`; check `pmu_config.json` rather than the instance type.
- **Do not infer the execution provider, build flags, or ISA dispatch from aperf.** None of them are
  collected. Capture them out-of-band or state that they are unknown.
- **Do not assume `is_graviton()` means Graviton.** It means "`/proc/cpuinfo` has a `CPU part` field", i.e.
  aarch64.

---

## References

- PMU config selection: `src/data/perf_stat.rs:764`–`:791`; custom config `:737`; save `:801`; archive path
  helper `:52`; report-side load `:1298`.
- Config files: `src/pmu_configs/` — `grv`, `grv_5`, `intel`, `intel_icelake`, `intel_sapphire_rapids`, `amd`,
  `amd_milan`, `amd_genoa` (`DEFAULT_PMU_CONFIG_DIR`, `src/data/perf_stat.rs:31`, embedded via `include_dir!`).
- Merge semantics (`HashMap::extend`, later file wins): `src/data/perf_stat.rs:200`–`:205`.
- `CpuInfo` and every predicate: `src/data/common/utils.rs:17`–`:100`.
- Unrecognised CPU aborts collection: `src/data/perf_stat.rs:793` (`bail!` message at `:794`); unsupported single event is skipped with a
  `warn!` at `:323` (ungrouped) or drops the whole metric group at `:462` (grouped).
- Missing-metric silence: `time_series_stat_threshold_rule.rs:69`,
  `time_series_stat_intra_run_comparison_rule.rs:77`/`:86`, `time_series_stat_run_comparison_rule.rs:95`.
- Rule definitions and thresholds: `src/analytics/rules/perf_stat.rs:19`–`:145`.
- Zero-threshold score handling (the four TLB rules use `threshold: 0.0`): `compute_finding_score`,
  `src/analytics/mod.rs:167`–`:176`.
- Counter mode: default **grouped** via `InitParams::new` (`src/data_collection.rs:379`, constants
  `src/lib.rs:45`–`:46`); opt-in flag `--ungroup-pmu-events` declared `src/record.rs:110`, applied `:197`–`:198`;
  dispatch `src/data/perf_stat.rs:805`; grouped builder `:213` (rationale `:207`–`:211`), ungrouped builder
  `:277`; mode round-tripped to the report at `src/report.rs:98`, legacy-empty default
  `src/data/perf_stat.rs:1289`.
- Multiplexing: `warn_multiplexing` `src/data/perf_stat.rs:59`; `probe_pmu_counter_limit` `:344`; rate
  computation `:999`–`:1030`.
- Run archive includes the whole run dir: `src/record.rs:310`–`:312`.
- hotline is ARM SPE-only: `src/hotline/sys.c:106`; `src/hotline/hotline.c:336`, `:382`.
- No architecture rule in analytics: verified absent from `src/analytics/` for `pmu_config`, `model_name`,
  `vendor`, `Instance Type`.
- ONNX Runtime EP build flags: `microsoft/onnxruntime` `tools/ci_build/build.py`;
  `amd/ZenDNN-onnxruntime` branch `rel-1.19.2_zendnn_rel` `tools/ci_build/build.py:557` and `:1040`.
- oneDNN ISA dispatch: `ONEDNN_MAX_CPU_ISA`, oneDNN CPU dispatcher control documentation.
- arm64 guidance: aperf's own `LSE_OPTIMIZATION` and `TLB_MISS_OPTIMIZATION` strings,
  `src/report_frontend/src/definitions/optimization-guides.ts:58`, `:109`; AWS Graviton technical guide.
