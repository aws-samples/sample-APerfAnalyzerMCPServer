# Guidance Model — decision-tree inputs, priority, and execution risk

Shared substrate for the prescriptive pass. Every playbook's `## Decision tree`, `## Priority`, and
`## Execution risk` sections are defined against this file, so the vocabulary is declared once here rather
than re-invented 51 times.

Raw research output. Format for tool consumption is **not** settled — see § "Format notes for the tool" at
the end for what a consumer needs and what the two candidate delivery modes imply.

---

## 1. Decision-tree inputs — what aperf actually gives you

A tree keyed on an input aperf never records is useless. This is the verified inventory.

### 1.1 Available and reliable

| Input | Where | Exact key / metric | Notes |
|---|---|---|---|
| **Instance type** | `systeminfo` | `Instance Type` | Via IMDS. **Collected but no rule compares it** — see §1.4 |
| **vCPU count** | `systeminfo` | `CPUs` | `sysinfo` total_cpus. Gated by `Inconsistent Number of CPUs` |
| **Physical memory** | `meminfo` | `MemTotal` | Gated by `Inconsistent Physical Memory` |
| **Kernel version** | `systeminfo` | `Kernel Version` | Full `uname -r`-style string. Gated by `Kernel Version Mismatch` |
| **OS version** | `systeminfo` | `OS Version` | **No rule compares it** — see §1.4 |
| **Region / AMI / instance ID** | `systeminfo` | `Region`, `AMI ID`, `Instance ID` | **No rule compares them** — see §1.4 |
| **CPU utilization split** | `cpu_utilization` | `user`, `system`, `iowait`, `idle`, `nice`, `irq`, `softirq`, `steal` | Per-CPU and aggregate |
| **Workload processes** | `processes` | `<pid>_<comm>` series | **Top 16 by CPU only** — see §1.3 |
| **Kernel config** | `kernel_config` | e.g. `CONFIG_TRANSPARENT_HUGEPAGE` | Falls back to `KERNEL_CONFIG=NOT FOUND` |
| **Run geometry** | `aperf_stats` / run params | `--interval`, `--period` | Determines whether percentiles mean anything |
| **CPU vendor + µarch** | **run dir** | `pmu_config.json` event encodings | Only when `perf_stat` ran. **No rule compares it** — see [ARCHITECTURE.md](ARCHITECTURE.md) |

### 1.2 Available but conditional

| Input | Condition for existence | If absent |
|---|---|---|
| **PMU counters** (`perf_stat`) | PMU accessible; often unavailable in VMs/containers | No pipeline or memory-hierarchy findings |
| **ENA metrics** (`ena_stat`) | ENA driver exposing `ethtool -S` counters | No allowance findings |
| **EFA metrics** (`efa_stat`) | `/sys/class/infiniband` non-empty — HPC instance types only | `"No EFA metrics available"`; no EFA findings |
| **JVM profile** (`java_profile`) | **hidden `--save-profile-events` flag** | All 3 java rules inert; absence proves nothing |
| **Instance metadata** | IMDS reachable | All five fields become the literal string `"N/A"` |

### 1.3 Runtime / language detection — the honest picture

**There is no language or runtime field in aperf.** For .NET / Python / Java / Perl guidance, the runtime must
be *inferred*, and the only general-purpose source is the `processes` data type:

- Metric names are `<pid>_<comm>`, where `comm` comes from `/proc/<pid>/stat`.
- **`comm` is truncated to 15 characters** by the kernel. `dotnet`, `python3`, `java`, `perl` all fit, but
  `python3.11-conf…`-style names and long wrappers get cut.
- **Only the top 16 processes by CPU time are retained**, plus the aperf process itself. A runtime that is not
  in the top 16 is invisible.
- `comm` is the *executable* name, so a Python service launched via `gunicorn` shows `gunicorn`, a Java app via
  a shell wrapper may show the wrapper, and anything using `exec -a` lies outright.

**Consequence for the tree:** runtime detection is a *hint with a confidence level*, never a fact.

| Runtime | Primary signal in `processes` | Corroboration | Confidence |
|---|---|---|---|
| **Java / JVM** | `java`, `jsvc`, or the app's `-XX`-launched comm | `java_profile` data type exists at all (needs the hidden flag) | High when `java_profile` present, else medium |
| **.NET** | `dotnet`, or a self-contained single-file app name | No .NET-specific data type in aperf | **Low–medium** |
| **Python** | `python`, `python3`, `python3.N`, `gunicorn`, `uwsgi`, `celery` | Thread count via `NumberThreads` (GIL ⇒ low CPU per thread) | Medium |
| **Perl** | `perl`, or a script name when the shebang is exec'd | Very often *not* in the top 16 | **Low** |

**When the runtime cannot be established, the tree must fall through to a runtime-agnostic branch and say so.**
Guessing a runtime and emitting runtime-specific advice is worse than emitting generic advice.

### 1.4 Verified gaps — inputs the tree cannot use

These matter because they are the inputs a human would reach for first:

- **CPU architecture is not in `systeminfo`** — no `arch`, no `uname -m`, no CPU model name — **but it *is*
  recoverable from the run directory.** When `perf_stat` collects, aperf writes the microarchitecture-specific
  PMU config it selected to `pmu_config.json` in the run dir (`src/data/perf_stat.rs:801`), and the whole dir
  is archived. The event encodings identify vendor and microarchitecture directly: `armv8_pmuv3_0/…` is arm64,
  `cpu/event=0x3c` cycles is Intel, `cpu/event=0x76` cycles is AMD. **This is the strongest architecture
  signal in a run**; the `Instance Type` and `.x86_64`/`.aarch64` kernel-suffix readings are inferences and
  only needed when `perf_stat` is absent. **No analytical rule compares architecture**, so parity is still a
  manual check. Full treatment, including which findings are mechanically impossible per architecture and
  which metrics share a name but not a definition: **[ARCHITECTURE.md](ARCHITECTURE.md)**.
- **`Instance Type` is collected but no analytical rule compares it between runs.** Two runs on `m5.large`
  and `m7g.16xlarge` produce **no instance-type finding**. `CPUs` and `MemTotal` are the only proxies, and they
  miss same-size-different-family changes (`m6i.4xlarge` → `m7g.4xlarge`: same vCPU, same memory, different
  architecture, different everything). **This is the single largest gate gap in aperf** — treated as a
  first-class check in every gate playbook. `pmu_config.json` catches the architecture half of this when
  `perf_stat` ran ([ARCHITECTURE.md](ARCHITECTURE.md) §6), but nothing catches a same-vendor resize.
- **Build-time and dispatch configuration is not collected at all.** Compiler flags, ONNX Runtime execution
  providers, ISA dispatch variables (`ONEDNN_MAX_CPU_ISA`), Python wheel provenance, .NET runtime identifiers.
  These often *are* the cause of an IPC or instruction-footprint finding, and aperf can only ever show the
  symptom ([ARCHITECTURE.md](ARCHITECTURE.md) §5).
- **`OS Version`, `AMI ID`, `Region` are collected but never compared.** A distro upgrade or a cross-region
  move passes silently unless the kernel string also changed.
- **Context switches (`ctxt`) are not collected.** Only rescheduling-IPI proxies in `interrupts`.
- **No cgroup / container limits.** aperf reads host-level `/proc`, so a container capped at 2 CPUs on a
  64-vCPU host reports `CPUs: 64`. Utilization percentages are host-wide, not workload-relative.
- **No disk or filesystem topology**, no per-device queue depth beyond `diskstats` (which has no rules).

---

## 2. Priority model

Each finding gets a **priority** that is *not* its aperf score. aperf's score measures deviation from a
threshold; priority measures **what to act on first**.

| Priority | Meaning | Action posture |
|---|---|---|
| **P0 — Blocking** | The report cannot be interpreted until resolved. Validity gates live here. | Stop. Fix the comparison, re-run. Do not read other findings |
| **P1 — Act now** | A real limit is being hit and the workload is measurably degraded. | Remediate in this cycle |
| **P2 — Investigate** | Strong signal, but cause is ambiguous. Needs a corroborating read before action. | Diagnose before changing anything |
| **P3 — Opportunistic** | Real but bounded upside; often a rebuild or config change. | Batch with other work |
| **P4 — Informational** | Context, or a signal too weak to act on alone. | Note it; act only if it corroborates something else |

**Why priority ≠ score.** aperf's `Critical` (−256) is assigned per-rule at authoring time and then scaled by
how far the value exceeded the threshold, so scores are unbounded (a 400% memory delta scores −10240). Two
findings can both be `Critical` while one is P0 (invalid comparison) and the other P1 (real limit hit).
Conversely `PREEMPT_LAZY Detected` is `Neutral` (0) and is P4 — its score is *flat*, carrying no magnitude at all.

**Priority is modulated by observed values**, which is the whole point of the decision tree: `Reduced Memory
Availability` at −11% is P3; at −60% with major page faults present it is P1.

---

## 3. Execution risk model

Every remediation carries risk. A playbook that recommends a change without stating the risk is not
prescriptive, it is reckless.

| Risk | Meaning | Examples |
|---|---|---|
| **R0 — Read-only** | Observation only. Cannot affect the workload. | Reading `/proc`, re-running aperf, inspecting a JFR |
| **R1 — Reversible, no restart** | Runtime-tunable, revert instantly. | `sysctl`, THP `madvise`→`always`, IRQ affinity |
| **R2 — Restart required** | Needs a process or service restart; config is revertible. | JVM/CLR flags, GC selection, worker counts |
| **R3 — Rebuild / redeploy** | Requires building and shipping an artifact. | `-flto`, `-moutline-atomics`, AutoFDO, ReadyToRun |
| **R4 — Infrastructure change** | Changes the instance, network, or topology. Cost and blast radius. | Instance resize, ENA Express, placement groups, kernel upgrade |
| **R5 — Behaviour-changing** | May alter correctness, latency profile, or semantics. Needs validation. | `OmitStackTraceInFastThrow`, disabling mitigations, preemption model |

**Every recommendation must state: priority, risk, and how to verify the change worked.** A change whose effect
cannot be measured by re-running aperf and re-reading the same finding should be flagged as unverifiable.

### 3.1 Risk notes by target runtime

| Runtime | R2 (restart) levers | R3 (rebuild) levers | Runtime-specific hazard |
|---|---|---|---|
| **Java** | Heap sizing, GC choice, `-XX` flags, thread pools | AOT/JIT tiering, class-data sharing | Flag interactions are non-obvious; GC changes shift the latency profile, not just throughput |
| **.NET** | `DOTNET_gcServer`, `DOTNET_GCHeapCount`, `DOTNET_TieredPGO`, thread-pool config | ReadyToRun, NativeAOT, trimming | Server GC defaults differ by container vs host; NativeAOT removes reflection paths |
| **Python** | Worker/process count, allocator env, `PYTHONMALLOC` | C-extension rebuild, `-O` builds | GIL makes thread-count tuning mostly ineffective; scale by *process* |
| **Perl** | Preforking model, worker count | Rebuild with threading/allocator options | Long-lived interpreters leak differently; `perl -V` build options matter more than runtime flags |

---

## 4. Decision-tree conventions

A tree is expressed as ordered, mutually exclusive branches. Each branch declares its condition on
**observed values**, and each leaf carries priority, risk, and a verification step.

```
IF   <condition on the observed value>
AND  <corroborating condition from another data type>
THEN <conclusion>
     → action (P<n>, R<n>)
     → verify: <what re-running aperf should show>
ELSE fall through to the next branch
```

Rules for authoring a tree:

1. **Branch on the value, not the finding's existence.** The finding firing is the tree's entry condition,
   never a branch.
2. **Every tree needs an insufficient-data branch.** At aperf's default `--interval 1 --period 10` (~10 samples)
   `p90`, `p99`, `p99_9`, and `max` are all the same element, and any percentile-based branch is unsound.
   Say so rather than routing on noise.
3. **Corroboration is part of the condition,** not an afterthought. `Increased I/O Wait Time` alone is
   ambiguous; with `diskstats` showing saturation it is not.
4. **Name the runtime branch explicitly, including the unknown case** (§1.3).
5. **A leaf that cannot be verified by re-reading aperf must say so.**

---

## 5. Format notes for the tool

What a consumer of this tree needs, independent of encoding:

- **Join key** is `rule_name` (exact string from aperf's finding JSON).
- **Observed values** must be parsed from the finding's `description`, whose format is fixed per template.
  The two gate templates:
  - `key_value_key_run_comparison` → `The value of {key} in {run} ("{v}") is different from {base} ("{bv}").`
    and, when the key is missing, `The key {key} does not exist in {run}, while its value in {base} is "{bv}".`
  - `time_series_stat_run_comparison` → `The {stat} in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).`
    Values are `formatted_number_string` (T/G/M/K, 2 dp), so **`1.50G` must be parsed back to a number**;
    `equal to` replaces the percentage when the delta is exactly 0.
- **Score is not a severity.** It is unbounded and scaled by threshold exceedance; the two `key_value` gates
  are **flat** (always exactly −256). Priority must come from the tree, not the score.
- **Tree inputs the consumer must supply** beyond the finding itself: `Instance Type`, `CPUs`, `MemTotal`,
  `Kernel Version`, `OS Version`, run geometry, the `processes` metric names, which optional data types exist
  at all, and — for every `perf_stat` finding — **`pmu_config.json`, which determines whether the finding
  could have fired and what its metric actually means** ([ARCHITECTURE.md](ARCHITECTURE.md) §2, §3).

**Two candidate delivery modes** (to be tested, per the user's note):

1. **Static lookup** — the tool resolves `rule_name` → playbook and returns the tree verbatim. Deterministic,
   auditable, no inference at read time. Weakness: cannot combine findings or reason about co-occurrence.
2. **Re-feed to a model** — hand the model the findings plus the relevant playbooks and let it synthesize
   guidance on the fly. Handles co-occurrence and cross-finding precedence naturally. Weakness: needs the
   precedence rules and the gap list (§1.4) supplied explicitly, or it will confidently use inputs aperf
   does not collect.

Mode 2 is the reason §1.4 is written as a first-class section: **a model asked to reason about instance sizing
will invent an instance-type comparison that aperf never performed** unless told the gap exists. The same holds
for architecture: a model will happily explain `High Code Sparsity` on an Intel run, where the metric does not
exist, unless [ARCHITECTURE.md](ARCHITECTURE.md) §2 is supplied alongside the finding.
