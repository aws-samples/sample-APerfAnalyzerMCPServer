---
rule_name: Consistent CPU Utilization
data_type: cpu_utilization
data_key: aggregate
template: time_series_stat_run_comparison
condition: "abs(delta_avg(aggregate)) <= 0.01"
base_score: Good
score_sign: positive
requires_comparison: true
aperf_message: "Similar amount of CPU resources are being utilized between two runs."
source: src/analytics/rules/cpu_utilization.rs:15
---

# Consistent CPU Utilization

## What fired

The **average** of the `aggregate` metric (total CPU utilization across all CPUs) in this
run differs from the same average in the **base run** by **1% or less** in relative terms.

This is one of only **two positive findings in all of aperf** (the other is
`ENA Express Enabled with UDP`). Base score is `Good` (+2), so it sorts to the *bottom* of
the Analytical Findings panel — findings are sorted ascending by score.

Requires ≥2 runs. The base run is the first run in the comparison and never carries this
finding.

## The processing caveat — verified by reading the collection code

Two facts about *which numbers this rule actually compares* change how it must be read. Both
were established from `src/data/cpu_utilization.rs` and the stats-selection code, not inferred.

**1. The stat is taken from the `total` series, not from any CPU state.** The `aggregate`
metric holds **nine** series: one per `CpuState` (added with `add_data_point`, so
`is_aggregate == false`) plus a `total` series added with `add_aggregate_data_point`
(`src/data/cpu_utilization.rs:226`, `is_aggregate == true`). `cpu_utilization` uses
`TimeSeriesDataAggregateMode::Custom`, and with nine series the selection at
`time_series_data_processor.rs:340` resolves `stats_series_idx` by finding the series with
`is_aggregate == true`. So this rule compares `avg(total)`, where
`total = (Σstate − idle) / Σstate × 100` (`src/data/cpu_utilization.rs:216`) — that is,
`100 − idle` per sample. It is *not* the sum of the eight state series.

**2. `avg(total) + avg(idle)` does not equal 100, and the shortfall reveals the sample
count.** The first sample of every `cpu_utilization` metric is forced to zero
(`cpu_time_delta_sum == 0.0` on the first snapshot, so the `else` branch stores `0.0`), and
that zero is inside the average. Therefore:

```
avg(total) = 100 × (n−1)/n − avg(idle)        so        avg(total) + avg(idle) = 100 × (n−1)/n
```

| Samples `n` | `avg(total) + avg(idle)` | Recording geometry at `--interval 1` |
|---|---|---|
| 11 | 90.909 | `--period 10` (the default) |
| 21 | 95.238 | `--period 20` |
| 61 | 98.361 | `--period 60` |
| 601 | 99.834 | `--period 600` |

This is directly useful: **`n = 100 / (100 − (avg(total) + avg(idle)))`** recovers a run's
sample count from two numbers the report already shows. Use it in STEP 1 to detect a
geometry mismatch between runs, which is this rule's dominant false-positive source.

## Reasoning

`aggregate` is described in `data-descriptions.ts` as "Percentage of CPU time spent on all
activities (across all CPUs for each type)", with `desired: "higher"`. The series this rule
reads, `total`, is the one the same file calls "the total CPU utilization".

The rule exists to answer a **comparison-validity** question, not a performance question:
*did the two runs consume comparable CPU?* When two runs are being compared to evaluate a
change, the interpretation of every other delta in the report depends on whether the runs
did comparable amounts of work. If total CPU volume is essentially identical, then any
throughput or latency difference between the runs cannot be attributed to one run simply
getting more CPU time than the other — the difference must lie in *efficiency*, in
*blocking*, or outside the CPU entirely.

The threshold is deliberately tight: **1%**, far tighter than the 10% used by the
directional `user` and `iowait` rules. Only genuinely well-controlled comparisons fire it.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({value}) is {±pct} {base_run} ({base_value}).
```

The percentage clause is produced by `delta_ratio_to_percentage_string`, which renders the
*absolute* percentage plus a relation word: `"greater than"`, `"less than"`, or — when the
delta is exactly zero — the literal string `"equal to"` with no percentage at all. So a
real finding reads:

```
The average in run_b (54.31) is 0.42% greater than run_a (54.08).
```

or, in the exact-match case:

```
The average in run_b (54.08) is equal to run_a (54.08).
```

Both values are percentages of total CPU time, from the `total` series (see the caveat above).

**Five things to know before branching on these numbers:**

1. **`f64_to_fixed_2` truncates, it does not round.** A printed `54.31` is anything in
   `[54.31, 54.32)`. Never state an exact value from the text.
2. **The printed percentage is the delta *ratio*, not percentage points.** `0.42% greater
   than` means the averages differ by 0.42% *of the base value* — at a base of 54.08 that is
   0.23 percentage points.
3. **`equal to` carries no number.** `delta_ratio_to_percentage_string`
   (`src/computations/mod.rs:162`) returns the bare literal `"equal to"` at exactly 0.0, so
   the usual `{pct}% {relation}` parse fails on this form. Handle it explicitly.
4. **The relation word is computed from the *signed* ratio but the number is absolute**, so
   `less than` plus a positive percentage is normal, not a bug.
5. **The direction is not meaningful for this rule.** `abs: true` means it fires on
   `|delta| ≤ 0.01` regardless of sign; the description still reports the direction of a
   difference the rule deliberately ignored.

Score math — `compute_finding_score(|delta_ratio|, 0.01, +2)`, `src/analytics/mod.rs:167`.
Because a firing value is always `≤ 0.01`, `delta = value/threshold ≤ 1`, so the reciprocal
branch (`if delta < 1.0 { delta = delta.recip() }`) is **always** taken. The score is
therefore `(0.01 / |delta_ratio|) × 2` — **unbounded as the delta approaches zero**:

| observed Δ | score | note |
|---|---|---|
| 1% (0.01) | **+2.00** | exactly at threshold; the floor |
| 0.99% (0.0099) | **+2.02** | |
| 0.5% (0.005) | **+4.00** | ties with an exact match |
| 0.42% (0.0042) | **+4.76** | |
| 0.2% (0.002) | **+10.00** | |
| 0.1% (0.001) | **+20.00** | |
| 0.01% (0.0001) | **+200.00** | |
| 0.0001% (1e-6) | **+20,000.00** | prints as `0% greater than` |
| **exactly 0** | **+4.00** | the `value == 0.0` branch returns `2 × rule_score` |

**The score is non-monotonic and unbounded, so it must not be read as strength of
evidence.** Two consequences:

- Any `|delta|` in `(0, 0.005)` scores *higher* than a perfect match, which scores `+4.00`.
  The crossover is exactly `0.005`, where both give `+4.00`. A run pair differing by one part
  in a billion scores `+20,000,000`.
- Because findings sort ascending by score and this one is positive, a near-perfect match
  sorts to the very bottom of the panel — further down than a merely good match. Position
  carries no meaning here.

**The zero-baseline branch is provably unreachable for this rule.** PATTERN.md §5 requires
every comparison playbook to handle `base_stat == 0.0`, which forces `delta_ratio = 1.0` and
prints `100.00% greater than`. Here that forced ratio would have to satisfy `1.0 ≤ 0.01`, so
the rule cannot fire through it. This is the one comparison rule where that branch is dead —
stated explicitly because its absence below is deliberate, not an omission.

**A different zero case *does* fire, and it is a trap.** The template checks
`cur_stat == base_stat` **before** it checks `base_stat == 0.0`
(`time_series_stat_run_comparison_rule.rs:98`), so when *both* averages are `0.0` the first
branch wins: ratio `0.0`, description `equal to`, score `+4.00`. `avg(total) == 0` means
`idle` was 100% in every sample — a **completely idle machine**. Two idle runs therefore earn
a positive `Good` finding stating they "utilized a similar amount of CPU resources". STEP 2
exists to catch this.

## Interpretation

The finding is a **licence to compare**, scoped narrowly to CPU volume.

**What it lets you rule out:**

- The two runs did not differ in total CPU time consumed. A throughput or latency delta
  between them is *not* explained by one run simply being given more CPU.
- Combined with matched `systeminfo` (no `Inconsistent Number of CPUs`) and matched
  `meminfo` (no `Inconsistent Physical Memory`), the environment is comparable enough that
  other deltas are worth interpreting.

**What it explicitly does NOT prove — this is the important half:**

| Hidden condition | Why `aggregate` misses it | Check instead |
|---|---|---|
| A user→system shift | `aggregate` sums all CPU-time types; 40% user + 10% system and 10% user + 40% system both total 50% | `user`, `system` series; `Increased/Decreased User-Space CPU Utilization` findings |
| Different work per cycle | Same CPU *time* can execute very different instruction counts | `ipc` in `perf_stat`; `Reduced Instructions per Cycle` |
| Both runs equally idle | Two runs both at 8% utilization are "consistent" and both useless | `Underutilized CPU` — if it also fired, this finding confirms only that both runs were equally under-loaded |
| Different amount of useful work | aperf does not know your throughput. Same CPU for half the requests is a 2× regression | Application-side throughput/latency metrics |
| I/O-side differences | iowait is counted separately from busy time | `iowait`; `Increased I/O Wait Time` |
| Per-CPU imbalance | `aggregate` is a sum; it is blind to distribution | Per-CPU `idle` / `user` series |

**Known false positives — cases where the finding is technically true but misleading:**

- **Both runs saturated at a ceiling.** Two runs both pinned at ~100% aggregate are
  trivially "consistent". The consistency is imposed by the ceiling, not by controlled
  conditions, and it hides everything happening behind that ceiling.
- **Both runs mostly idle.** Same logic at the other end. Always check whether
  `Underutilized CPU` fired on either run before treating this as good news.
- **Compensating shifts.** A run that moved 15% of CPU from `user` to `system` while
  holding the total constant fires this finding, yet has changed materially.
- **Different run durations.** The average is over each run's own samples. Two runs of
  very different length can average the same while having quite different phase structure.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `user`, `system` series | `cpu_utilization` | Whether the constant total conceals a mode shift |
| `idle`, `iowait` | `cpu_utilization` | Whether "consistent" means consistently busy or consistently blocked |
| Per-CPU `aggregate` / `idle` | `cpu_utilization` | Whether distribution across cores changed even though the sum did not |
| `ipc` | `perf_stat` | Same CPU time, different instruction throughput ⇒ efficiency change |
| `CPUs`, `Kernel Version` | `systeminfo` | If `Inconsistent Number of CPUs` fired, `aggregate` is normalized over different denominators and this finding is **not** meaningful |
| `MemTotal` | `meminfo` | If `Inconsistent Physical Memory` fired, the runs were on different machines |
| `IpExt:InOctets` / `IpExt:OutOctets` | `netstat` | Confirms the load generator delivered comparable traffic |
| `number_threads`, `number_processes` | `processes` | Concurrency level was comparable. **No analytical rules exist for `processes`** — read manually |

## Guidance

1. **Confirm the comparison is genuinely valid before relying on this.** Check
   `systeminfo` (`Inconsistent Number of CPUs`, `Kernel Version Mismatch`) and `meminfo`
   (`Inconsistent Physical Memory`). If any fired, this finding is nearly worthless:
   `aggregate` is a percentage of a *different* number of cores, so equality is
   coincidental.

2. **Check the two degenerate cases.** Look at the absolute value in the description. If
   both runs sat near 0% or near 100%, say so explicitly — the consistency is an artifact
   of a floor or a ceiling. If `Underutilized CPU` fired on either run, report that this
   finding confirms only *equal under-utilization*.

3. **Decompose the constant total.** Read `user` and `system`. A stable `aggregate` with a
   shifted `user`/`system` split is a real change that this finding hides by construction.
   The `Increased`/`Decreased User-Space CPU Utilization` findings cover that; check
   whether either fired.

4. **Use it to narrow, not to conclude.** State the inference explicitly in the report:
   CPU *volume* is controlled, so investigate efficiency (`ipc`, stall metrics, cache and
   TLB findings) and blocking (`iowait`, off-CPU profile) rather than CPU allocation.

5. **Do not stop investigating because a positive finding appeared.** Positive findings
   are the *fewest* in aperf (2 of 51) precisely because the engine is tuned to surface
   problems. Their presence is not an all-clear on the run.

## Priority and execution risk

**Priority: P3 — Context** in the normal case. This finding prescribes no action on the
system: it licenses one axis of a comparison. It rises to **P1 — Act now** in exactly one
situation, and it is an inverted one: when the finding fires *and* both runs were idle or both
were pinned at a ceiling, the finding is actively misleading and the reader must be warned
before they trust any other delta. It falls to **P4 — Informational** when the runs are known
good and this is simply confirming the control held.

**Execution risk: R0 — Read-only**, and unusually there is no second risk: there is nothing
to remediate, because nothing is wrong. The real risk this finding carries is *epistemic* —
acting on a downstream finding whose validity you believed this one established. `aggregate`
licenses total CPU volume and nothing else, so the risk of the *next* action is set by
whichever playbook you route to, not by this one.

**The score carries neither severity nor confidence.** It is `(0.01 / |delta_ratio|) × 2`,
unbounded and non-monotonic: a perfect match scores `+4.00` while a 0.1% difference scores
`+20.00`. Never rank two `Consistent CPU Utilization` findings against each other, and never
read the panel position of a positive finding as significance.

**The comparator is `LessEqual` with `abs: true`**, so exactly 1.0% fires and direction is
discarded. This makes the rule a two-sided band around equality, not a directional test —
the direction word in the description is reporting a difference the rule chose to ignore.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `|Δ avg(total)| ≤ 1%` versus the base run — the two runs used a comparable
*volume* of CPU. This is a licence to compare one axis, and the tree's job is to bound it.

```
STEP 0 — Are the validity gates clear? This finding is WORTHLESS if they are not.
  IF `Inconsistent Number of CPUs` fired
  THEN → STOP treating this as a licence. `total` is a PERCENTAGE, so equal
         percentages over unequal core counts mean UNEQUAL absolute CPU: 50% of
         64 vCPUs is 4x 50% of 16. The equality is an artifact of normalization
         (P0, R0)
       → this is the single most dangerous misread of this finding
  IF `Inconsistent Physical Memory` or `Kernel Version Mismatch` fired
  THEN → different machines or different kernels. Equal CPU volume does not make
         them comparable; resolve the gate first (P0, R0)
  ELSE continue.

STEP 1 — MANDATORY check: did the two runs have the SAME recording geometry?
  This is the dominant false-positive AND false-negative source, and aperf does
  not surface it as a finding.
  Recover each run's sample count:  n = 100 / (100 - (avg(total) + avg(idle)))

  IF the recovered n DIFFERS between the runs
  THEN → the averages are diluted by different amounts and the delta is partly or
         wholly an ARTIFACT (P1, R0)
       → magnitude of the spurious delta, base n vs compared n:
           11 -> 21   : +4.76%      6 -> 11  : +9.09%
           11 -> 61   : +8.20%      6 -> 61  : +18.03%
           11 -> 601  : +9.82%      3 -> 601 : +49.75%
           61 -> 11   : -7.58%     601 -> 11 : -8.94%
       → NOTE the direction: a geometry mismatch produces a delta of roughly
         1/(n_b-1), which at the DEFAULT --period 10 is ~10%. That is ten times
         this rule's 1% threshold, so mismatched geometry does not usually create
         a false POSITIVE — it SUPPRESSES a true one. If two runs really did use
         identical CPU but were recorded at different lengths, this finding is
         absent and the reader wrongly concludes the runs were uncontrolled
       → verify: re-report both runs with `--time-range 1:` to drop the forced-zero
         sample. `avg(total) + avg(idle)` should then equal 100.00 for both, and the
         delta should be re-read from the corrected values
  IF the recovered n MATCHES
  THEN → the dilution is identical in both runs and cancels in the ratio. The
         delta is real; continue (P3, R0)

STEP 2 — MANDATORY check: WHERE in the range is the agreed value?
  A ratio near zero says the two runs agree. It does not say they agree on
  anything useful. Read the absolute value from the description.

  IF avg(total) is 0.00 in BOTH runs (description reads `equal to`)
  THEN → both machines were COMPLETELY IDLE. `total` is 100 - idle, so zero means
         idle was 100% in every sample. The template's `cur == base` branch is
         checked before its zero-base branch, so this fires with a POSITIVE score
         (P1, R0)
       → the finding's message ("similar amount of CPU resources are being
         utilized") is true and useless. Report it as a NO-LOAD run, not a
         controlled comparison
       → verify: `Underutilized CPU` should have fired on both runs; the `idle`
         average should be ~90.9 at default geometry (100 x (n-1)/n)
  IF avg(total) is low in both runs (Underutilized CPU fired on both)
  THEN → this confirms only EQUAL UNDER-LOAD. Route to underutilized-cpu.md and
         re-qualify the whole report there before using any delta (P1, R0)
       → the consistency is imposed by the absence of load, not by control
  IF avg(total) is near a ceiling in both runs (>= ~95 after correcting for
     geometry)
  THEN → the consistency is imposed by SATURATION. Both runs hit the same wall, so
         equality is guaranteed and hides everything behind it (P1, R0)
       → verify: the `total` series should be flat-topped rather than varying;
         check `Increased I/O Wait Time` and the ENA allowance findings for what
         the wall actually is
  ELSE → the runs agree at a meaningful load level. This is the case where the
         finding does its job; continue (P3, R0)

STEP 3 — MANDATORY manual check: does equal VOLUME mean equal WORK?
  It does not, and this is the finding's central limitation. `total` is CPU TIME.
  Nothing in aperf knows your throughput.

  IF application-side throughput differs between the runs
  THEN → equal CPU for unequal work is a real efficiency change, and this finding
         is the EVIDENCE FOR it, not against it: the same CPU produced less (P1, R0)
       → route to perf_stat: `Reduced Instructions per Cycle` and the stall
         findings quantify it
       → aperf does not collect throughput. This step needs the user or the load
         generator's own output
  IF throughput is unknown
  THEN → say so. Do not report "CPU usage was consistent" as if it implied the
         runs were equivalent (P3, R0)

STEP 4 — Decompose the constant total. It is a SUM and hides its own composition.
  Read the eight CPU-state series in the `aggregate` metric.

  IF `Increased`/`Decreased User-Space CPU Utilization` ALSO fired
  THEN → a user<->system shift at constant total: 40u+10s and 10u+40s both total
         50. This is a MATERIAL change that this finding conceals by construction
         (P1, R0)
       → route to the matching user-space playbook; that is the real finding
       → verify: `user` and `system` averages should move in opposite directions by
         similar magnitudes
  IF `Increased I/O Wait Time` ALSO fired
  THEN → NOTE `iowait` is NOT part of `total`: total = 100 - idle, and iowait is a
         separate CpuState from IDLE. So iowait can change substantially while
         `total` holds, and both findings are simultaneously true (P1, R0)
       → route to increased-io-wait-time.md
  IF per-CPU `idle` series are BIMODAL in either run
  THEN → equal aggregate volume, different distribution. `total` is computed from
         the `cpu` line of /proc/stat and is blind to imbalance (P2, R0)
       → verify: compare the per-CPU series counts and shapes across runs

STEP 5 — What survives? This finding EXPANDS what is readable, so state the bound.
  VALID      : per-unit efficiency comparisons (IPC, MPKI, stall rates) — this is
               precisely what a controlled CPU volume licenses, and the highest
               value this finding delivers
  CAUTION    : throughput and latency conclusions — valid only once STEP 3's
               external throughput data is in hand
  CONFOUNDED : anything depending on the user/system split or on per-CPU
               distribution, if STEP 4 found a shift
  VOID       : nothing, by virtue of this finding. It voids no other finding —
               that is what makes it different from the eight validity gates,
               which void things

INSUFFICIENT DATA
  IF only ONE run is present
  THEN → the rule requires a base run and a compared run; it produced NO finding.
         Absence proves nothing about consistency (P3, R0)
  IF the base run lacks the `aggregate` metric
  THEN → the rule returned early with a `debug!` and produced NO finding for ANY
         run, not just the base (P2, R0)
  IF the finding is ABSENT with both runs present
  THEN → this is the ordinary case and is NOT a problem. The 1% threshold is
         tight; most legitimate comparisons miss it. Check STEP 1 before reading
         absence as evidence of poor control (P3, R0)
```

## Runtime-specific consequences

This rule reads `/proc/stat` and is entirely runtime-agnostic — no runtime can change what it
measures. It matters to the four runtimes only through **what a constant total conceals**,
which is STEP 4's question. In each case the runtime holds CPU volume steady while changing
what that CPU is doing, so the finding fires and the change is invisible in it.

| Runtime | How it holds total CPU constant while changing behaviour | What to check |
|---|---|---|
| **.NET** | A GC mode change (Workstation ↔ Server, `DOTNET_gcServer`) redistributes CPU between application and GC threads at a similar total. Tiered compilation shifts CPU between JIT and steady-state execution early in a run | `user` vs `system` split; whether the run was long enough to leave tier-0. A short `--period` measures mostly JIT |
| **Python** | GIL contention burns CPU in kernel futex waits rather than in application code — `system` rises, `user` falls, total holds. A C-extension change can move the same work between `user` and native code invisibly | `system` share specifically; process count in `processes`. Total CPU says nothing about whether the GIL was the limiter |
| **Java** | The largest source of a hidden shift. A GC change (Parallel → G1 → ZGC) moves CPU between application and collector threads; JIT compiler threads consume `user` early. All at a similar total | `user`/`system` split, plus `jvmArguments` in the profile metadata. Also `JVM Version Comparison` — a JVM change alters GC defaults, so "consistent CPU" across JVM versions is often two different CPU budgets that happen to sum alike |
| **Perl** | Preforked workers give a stable total by design, since worker count is static. A change in per-request work shows up as throughput, not as CPU volume — which is exactly the STEP 3 blind spot | Throughput externally; `system` share for syscall-heavy changes |

**The unknown-runtime case is the default and is fine here.** Runtime is inferred from
`processes` metric names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). STEP 4's
user/system decomposition is runtime-independent and answers the same question without needing
to identify the runtime at all.

## Architecture-specific considerations

The metric is `/proc/stat`-derived, so this finding fires on every architecture and means the
same thing everywhere. The architecture dependence is in what "equal CPU volume" implies.

**Equal CPU percentage is not equal CPU capacity, and no gate catches it.** aperf has no
architecture field and no rule compares `Instance Type` ([../GATES.md](../GATES.md)). An
Intel→Graviton comparison with matched `CPUs` and `MemTotal` fires **no gate at all** — and
this finding will happily confirm "consistent CPU utilization" across it. But 16 Graviton
vCPUs are 16 physical cores while 16 x86 vCPUs are 8 cores with SMT, so:

- **On x86 with SMT**, 50% aggregate utilization may already be physical-core saturation, the
  idle half being siblings that cannot contribute. Two runs at "consistent 50%" can be at
  completely different distances from their real ceilings.
- **On arm64**, throughput tracks utilization near-linearly (`data-descriptions.ts:105`), so
  equal utilization is much closer to implying equal delivered work.

Cross-architecture, therefore, this finding licenses *less* than it appears to: use it only
after confirming `Instance Type` matches, which is a manual check.

**This finding is the precondition for the comparison most affected by architecture.** STEP 5
declares per-unit `perf_stat` metrics VALID — but `stall-backend-pkc` and `l3-mpki` are
*redefined* per PMU profile ([../ARCHITECTURE.md](../ARCHITECTURE.md) §2), so a
cross-architecture comparison of the same finding compares different quantities. Equal CPU
volume does not repair that; it is worse than a missing metric because it looks valid.

**Counter mode affects what you compare next, not this finding.** Grouped is the default
(`src/data_collection.rs:379`); `--ungroup-pmu-events` opts out and runs about half the
counters. Two runs recorded in different modes have differently multiplexed PMU data even
when their CPU volume matched exactly — check `mux_counter_schedule_rate` in both before
acting on the efficiency comparison this finding licensed.

**Architecture-tuned builds are invisible here by design.** A workload rebuilt for the host —
the exemplar being `microsoft/onnxruntime` versus `amd/ZenDNN-onnxruntime`, or an arm64 build
gaining `-mcpu=neoverse-*` — typically consumes *the same CPU time* while doing more work per
cycle. This finding fires, and the entire improvement sits in the throughput that aperf does
not collect (STEP 3). A `Consistent CPU Utilization` finding across a build change is the
signature of exactly that.

## Verification

There is nothing to remediate, so verification here means confirming the licence is sound
rather than confirming a fix. Two checks, both read-only. First, re-report both runs with
`--time-range 1:`: `avg(total) + avg(idle)` should equal `100.00` for each, confirming the
forced-zero sample is gone and the geometry matched; if the delta moves across the 1%
threshold under that correction, the original finding was a geometry artifact and STEP 1 was
the real answer. Second, confirm the absolute level is meaningful — `Underutilized CPU` absent
from both runs, and `total` not flat-topped near a ceiling. If both hold, the licence in STEP
5 is sound. If throughput data exists externally, the decisive check is whether it matched
too: equal CPU with unequal throughput means this finding is evidence of an efficiency
regression, and no aperf re-run can establish that on its own.

## Do not

- **Do not report this as "performance is fine".** It states that CPU *volume* matched. It
  says nothing about whether either run performed acceptably.
- **Do not treat it as a licence to compare everything.** It licenses one axis: total CPU
  time. Instruction efficiency, mode split, per-core distribution and I/O are all
  untouched.
- **Do not trust it when `Inconsistent Number of CPUs` also fired.** Equal percentages over
  unequal core counts mean unequal absolute CPU.
- **Do not read the score magnitude as strength of evidence.** It is unbounded and
  non-monotonic: a zero delta scores +4.00, a 0.5% delta also scores +4.00, and a 0.1% delta
  scores +20.00. Never rank two of these findings against each other.
- **Do not assume its absence is bad.** The 1% threshold is tight; most legitimate
  comparisons simply miss it without anything being wrong. Check the recording geometry first
  (STEP 1) — mismatched `--period` suppresses this finding on runs that really were controlled.
- **Do not compare the two runs' averages without checking `avg(total) + avg(idle)` in each.**
  If that sum differs between runs, the sample counts differ and part of the delta is the
  forced-zero first sample, not the workload.
- **Do not read `total` as the sum of the eight CPU-state series.** It is `100 − idle`
  computed per sample from the `cpu` line of `/proc/stat`; `iowait` is a separate state and is
  therefore *inside* `total`, while `idle` is not.
- **Do not treat `equal to` with both values at 0.00 as a good result.** That is a completely
  idle machine on both sides, earning a positive finding. It is the worst case this rule can
  report, not the best.
- **Do not expect the `100.00% greater than` zero-baseline form.** It is unreachable for this
  rule: a forced ratio of 1.0 cannot satisfy `≤ 0.01`. If you see it, the finding is not this one.

## References

- Rule definition: `src/analytics/rules/cpu_utilization.rs:15` — `metric: "aggregate"`,
  `stat: Stat::Average`, `comparator: Comparator::LessEqual`, `abs: true`,
  `delta_ratio: 0.01`, `score: Score::Good`. `abs: true` makes it a two-sided band around
  equality, so the direction word in the description is not part of the test.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` —
  delta math at `:98`–`:106`. Branch order matters: `cur_stat == base_stat` is tested
  **before** `base_stat == 0.0`, which is why the both-zero case fires with `equal to` while
  the zero-baseline case cannot fire at all under a 0.01 threshold. Returns early with a
  `debug!` when the **base** run lacks the metric, suppressing the finding for every run;
  skips the base run itself; `continue`s silently for a compared run missing the metric.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`, over
  `Score::Good = +2` (`src/analytics/mod.rs:154`). A firing value is always `≤ threshold`, so
  the reciprocal branch always applies and the score is `(0.01 / |delta_ratio|) × 2` —
  **unbounded** as the delta approaches zero, and non-monotonic against the `value == 0.0`
  branch which returns a flat `2 × rule_score = +4.00`.
- Description formatters, `src/computations/mod.rs`: `delta_ratio_to_percentage_string` at
  `:162` (literal `"equal to"` at exactly 0.0; absolute percentage with a signed relation
  word), `formatted_number_string` at `:176`, `f64_to_fixed_2` at `:138` — which
  **truncates**, so printed values are lower bounds.
- **Which series the stat reads**: the `aggregate` metric receives eight CPU-state series via
  `add_data_point` plus a `total` series via `add_aggregate_data_point`
  (`src/data/cpu_utilization.rs:205` and `:226`). `cpu_utilization` uses
  `TimeSeriesDataAggregateMode::Custom`
  (`time_series_data_processor_with_custom_aggregate!`, `src/data/cpu_utilization.rs:132`), so
  `stats_series_idx` resolves by `is_aggregate` at `time_series_data_processor.rs:340` and the
  stat is `avg(total)`, **not** the sum of the state series.
- `total` definition: `src/data/cpu_utilization.rs:216` —
  `(Σ state_delta − idle_delta) / Σ state_delta × 100`, i.e. `100 − idle` per sample. `iowait`
  is a distinct `CpuState` (`src/data/cpu_utilization.rs:99`) from `IDLE`, so **iowait is
  inside `total`** while idle is not.
- Forced-zero first sample: `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189` returns `None` on the first snapshot, so
  `cpu_time_delta_sum == 0.0` and the `else` branch
  stores `0.0` (`src/data/cpu_utilization.rs:225`). The zero is inside the average because `compute_time_diff_index`
  (`src/data/common/processed_data_accessor.rs`) yields `start_idx = 0` without
  `--time-range`. Confirmed by `data-descriptions.ts:94`: "the first value is always zero. The
  statistics of a metric graph accounts for its aggregate series." Hence
  `avg(total) + avg(idle) = 100 × (n−1)/n`.
- Recording geometry: `--interval` default `1` (`src/record.rs:37`), `--period` default `10`
  (`src/record.rs:47`), collection loop `while current_time <= end_time`
  (`src/data_collection.rs:146`) giving ~11 samples. `--time-range` is a *report*-time flag
  (`src/report.rs:245`), so `--time-range 1:` corrects an existing run without re-recording.
- Graviton scaling: `data-descriptions.ts:105` — "the performance of Graviton instances
  increases near-linearly with CPU utilization". Counter-mode default `GROUPED_PMU_MODE`,
  `src/data_collection.rs:379`, affects the PMU comparison this finding licenses.
- Upstream guide: `CPU_UTILIZATION_OPTIMIZATION` in
  `src/report_frontend/src/definitions/optimization-guides.ts:1`.
- Related playbooks: `underutilized-cpu.md` (STEP 2's degenerate cases),
  `increased-user-space-cpu-utilization.md`, `decreased-user-space-cpu-utilization.md`,
  `increased-io-wait-time.md` (STEP 4's hidden shifts),
  `../systeminfo/inconsistent-number-of-cpus.md` (voids this finding),
  `../java_profile/jvm-version-comparison.md`, `../statistical/README.md`.
- Cross-cutting: [../GATES.md](../GATES.md) (precedence),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) (P/R vocabulary),
  [../ARCHITECTURE.md](../ARCHITECTURE.md) (PMU profiles, redefined metrics).
- [Graviton perfrunbook — defining your test plan](https://aws.github.io/graviton/perfrunbook/defining_your_test_plan.html)
- [`proc_stat(5)`](https://man7.org/linux/man-pages/man5/proc_stat.5.html)
