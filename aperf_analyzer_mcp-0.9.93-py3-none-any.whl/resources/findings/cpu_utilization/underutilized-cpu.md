---
rule_name: Underutilized CPU
data_type: cpu_utilization
data_key: idle
template: time_series_stat_threshold
condition: "avg(idle) > 50.0"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "CPU utilization might not be maximized."
source: src/analytics/rules/cpu_utilization.rs:25
---

# Underutilized CPU

## What fired

The **average** of the `idle` metric across the whole recording, for the `aggregate`
series (all CPUs combined), exceeded **50.0%**. Nothing else was considered — not the
shape of the curve, not the workload, not whether the machine was supposed to be busy.

Because the base score is `Critical` (-256) and the score is amplified by `avg(idle) / 50.0`,
this rule routinely produces the most negative score in the report and sorts to the top of
the Analytical Findings panel. **That position is a property of the score formula, not
evidence that it is the most important problem in the run** — nor of how much CPU is actually
reclaimable, which the finding never states. STEP 4b computes it.

## Reasoning

`idle` comes from `/proc/stat`, as the fraction of time CPUs had no runnable work at all
(distinct from `iowait`, which is time blocked on I/O). aperf treats a majority-idle
recording as a finding for two separate reasons, and they demand opposite responses:

1. **The measurement may be invalid.** Performance data gathered while the system is
   mostly idle does not characterize the workload. PMU ratios (`ipc`, `*-mpki`) are
   computed over whatever the CPU actually did, so an idle-dominated window dilutes them
   with idle-loop and background-daemon activity. Any conclusion drawn from that run —
   including other findings in the same report — rests on a small, possibly unrepresentative
   slice of samples.

2. **The workload may be blocked rather than working.** If the system was *supposed* to be
   saturated, idle time means threads are not runnable: they are waiting on locks, on
   synchronous I/O, on network round-trips, on a downstream service, or on a thread pool
   that is too small to keep cores fed. The CPU is not the bottleneck; something upstream
   of it is. This is the case where the finding points at real, fixable headroom.

The aperf-specific stake is stated in `data-descriptions.ts` for the `aggregate` metric:
Graviton performance scales near-linearly with utilization, so headroom left on the table
translates fairly directly into unrealized throughput or over-provisioned instance cost —
which is quantifiable, and STEP 4b quantifies it.

## Reading the description

`time_series_stat_threshold` emits exactly one form:

```
The {stat} in {run_name} is {value}.
```

Concretely:

```
The average in flask_run_02 is 86.92.
```

Five things to know:

1. **The number is `avg(idle)` in percent, not utilization.** Utilization is roughly
   `100 − idle`, and `iowait` is counted separately from `idle`, so busy ≈
   `100 − idle − iowait`. Reading 86.92 as "87% utilized" inverts the finding.
2. **The stat is computed over the `Aggregate` series only**, not over per-CPU series
   (`stats_series_idx`, `time_series_data_processor.rs:312`). The finding is therefore blind
   to imbalance by construction — 32 saturated cores and 32 fully idle cores report 50%.
3. **The value is truncated to 2 decimals, not rounded** (`f64_to_fixed_2`), so `86.92`
   means `[86.92, 86.93)`.
4. **The average includes the forced-zero first sample.** Every `cpu_utilization` value is
   a delta between two `/proc/stat` snapshots, so the first sample is always 0. At the
   default `--interval 1 --period 10` (~11 samples) that understates `avg(idle)` by about
   `idle/n` — roughly **8 percentage points at a true 90% idle**. See the table below.
5. **Only the average appears.** Nothing about the shape of the curve reaches the
   description, and shape is what decides the response — see STEP 2 of the tree.

Score math — `compute_finding_score(avg_idle, 50.0, −256)`, general branch, so
`delta = avg_idle / 50.0` and the score is `delta × −256`:

| avg(idle) | approx. busy | score |
|---|---|---|
| 50.01 (the minimum that fires; `Greater`, so exactly 50.0 does not) | ~50% | **−256.05** |
| 60 | ~40% | −307.20 |
| 70 | ~30% | −358.40 |
| 86.92 | ~13.1% | −445.03 |
| 99.9 | ~0.1% | −511.49 |

Notes on that table:

- **The score is bounded in practice**, unlike most amplified scores: `idle` is a
  percentage, so the score cannot go below `−512`. It nonetheless outranks almost
  everything else in the report, which is why this rule sorts to the top.
- **The score is more precise than the description**, being computed from the full-precision
  average rather than the truncated one. Recover it with
  `value_from_score(score, 50.0, SCORE["Critical"])` from `tools/aperf_desc.py`, taking the
  root above 50 — the lower root is the reciprocal branch and cannot have fired. The real
  `flask_run_02` finding scored `−445.05461168773354`, back-solving to `avg(idle) = 86.9247…`
  (the other root, `28.76`, is spurious).
- **The zero trap does not apply.** `avg(idle) == 0.0` cannot reach the `value == 0.0`
  branch, because 0.0 fails `Greater 50.0` and no finding is produced.

**How the forced-zero first sample biases the average, and what it does to the threshold.**
Reported = true × `(n−1)/n`, so inverting it gives the **true** idle the rule actually needs:
`50 × n/(n−1)`. Both directions, by run geometry:

| `--period` / `--interval` | samples | true 60% reads as | true 90% reads as | true idle needed to fire | so it is silent below |
|---|---|---|---|---|---|
| 2 / 1 (minimum) | 3 | 40.00 | 60.00 | **75.00%** | 25% utilization |
| 10 / 1 (**default**) | ~11 | 54.55 | 81.82 | **55.00%** | 45% utilization |
| 20 / 1 | ~21 | 57.14 | 85.71 | 52.50% | 47% utilization |
| 60 / 1 | ~61 | 59.02 | 88.52 | 50.83% | 49% utilization |
| 300 / 1 | ~301 | 59.80 | 89.70 | 50.17% | 50% utilization |

So at default geometry the rule **misses** genuinely-idle runs: a machine at a true 45–49%
utilization produces no finding at all. **The absence of this finding on a short run is not
evidence that CPU is well utilized** — run the STEP 4b arithmetic regardless of whether the
rule fired. `--time-range 1:` at report time drops the zero sample
(`compute_time_diff_index`, `processed_data_accessor.rs:597`) and re-derives every stat,
restoring the nominal 50% threshold without re-recording.

## Interpretation

Establish the *intent* of the recording first. The same value means different things:

| Situation | avg(idle) ~50-70% | avg(idle) > 85% |
|---|---|---|
| Recording was meant to capture a saturated workload | Real bottleneck upstream of CPU; investigate blocking | Workload barely ran, or load generator never engaged; **the run is likely invalid** |
| Recording captured normal production traffic | Expected headroom; finding is informational | Over-provisioned instance, or captured an off-peak window |
| Recording included idle warm-up / teardown | Average is diluted; re-scope the window | Measurement window is mostly not workload |

**Known false positives — check these before recommending any change:**

- **Recording window wider than the workload.** aperf was started before the load began or
  stopped after it ended. Very common, and the single most likely explanation for
  `avg(idle) > 85%`. Re-report scoped to the loaded interval (`--time-range`) rather than
  acting on this finding.
- **Idle-by-design systems.** Latency-sensitive services deliberately run at low utilization
  to preserve tail latency headroom. Here high idle is the goal — and if you do size it, use
  a 50–60% ceiling, not the default 70%.
- **Deliberately capped or pinned workloads.** A single-threaded process on a 64-vCPU
  instance cannot exceed ~1.6% aggregate utilization even while fully saturating its one
  core. Aggregate idle is then meaningless; per-CPU is the only useful view.
- **Throttling that reads as idle.** Both a cgroup CPU quota and an out-of-credits T-family
  instance look like idle cores from `/proc/stat`, which aperf reads at **host** level — so a
  container at its own quota shows as host idle. `steal` distinguishes the T-family case.

## Corroborating data

The finding on its own cannot distinguish "invalid measurement" from "real blocking".
These do:

| Check | Data type | What it tells you |
|---|---|---|
| `max` of the `aggregate` metric's `total` series | `cpu_utilization` | **The peak, and the sizing input.** Never derive it as `100 − min(idle)`: the forced zero makes `min(idle)` 0.00, so that expression always returns 100% |
| `CPUs`, `Instance Type` | `systeminfo` | The other two sizing inputs — the denominator, and whether SMT halves the physical cores behind STEP 4b's target |
| Per-CPU `idle` series (not just `aggregate`) | `cpu_utilization` | Some CPUs ~0% idle while others ~100% ⇒ imbalance or single-threaded workload, **not** global under-load |
| `idle` over time | `cpu_utilization` | Distinguishes steady under-load from a warm-up/teardown artifact |
| `iowait` | `cpu_utilization` | Non-trivial iowait ⇒ storage-blocked, not idle; pivot to `Increased I/O Wait Time` |
| `system` vs `user` | `cpu_utilization` | High `system` share of a small busy fraction ⇒ syscall/kernel overhead dominating |
| `number_threads`, `number_processes` | `processes` | Thread count far below core count ⇒ not enough concurrency to fill the machine (pool sized too small) |
| `user_space_time` vs `kernel_space_time` | `processes` | Per-process split: identifies *which* process is (or is not) consuming the CPU |
| `time_reading`, `time_writing`, `in_progress`, `weighted_time_in_progress` | `diskstats` | Confirms storage blocking. **No analytical rules exist for `diskstats`** — inspect it manually |
| `ERR`, `MIS` and per-IRQ series | `interrupts` | Rules out interrupt-driven stalls. Also has **no analytical rules** |
| Off-CPU profile | `java_profile` **only** | The decisive evidence: names the call stacks that blocked. **`--profile` cannot supply it** — it records `cpu-clock:pppH` (`perf_profile.rs:126`–`:139`), which by definition samples only threads that are ON a CPU. Java's `--profile-java` collects `wall` (`java_profile.rs:32`, `:81`), so stacks heavy in `wall` and absent from `cpu` are the ones that slept |
| `bw_in_allowance_exceeded`, `bw_out_allowance_exceeded`, `pps_allowance_exceeded` | `ena_stat` | Network ceiling capping the workload before CPU |
| `MemAvailable`, `pgmajfault` | `meminfo`, `vmstat` | Memory pressure / paging stalling threads |
| `mux_counter_schedule_rate` | `perf_stat` | Below 100 ⇒ PMU counters were multiplexed, adding error to every other `perf_stat` finding |

## Guidance

Ordered — each step gates the next. Do not skip to remediation.

1. **Validate the measurement window.** Plot the `idle` series over time. If idle is high
   only at the start/end, the window is wrong: re-generate the report scoped to the loaded
   interval and re-evaluate. Do not proceed on a diluted average.

2. **Check aggregate vs per-CPU.** If per-CPU `idle` is bimodal (some cores busy, others
   idle), the problem is parallelism or affinity, not global under-utilization. Redirect to
   thread-pool sizing / work distribution, and treat the aggregate number as misleading.

3. **Establish intent.** Confirm with the user whether this recording was meant to capture
   a saturated workload. If it was not, downgrade the finding to informational and quantify
   the headroom (below) rather than reporting a defect.

4. **If saturation was intended, find what blocked.** Read `number_threads` /
   `number_processes` from `processes`, then `iowait`, then `diskstats` and the `ena_stat`
   allowance ceilings. Off-CPU profiling is the definitive answer, and **aperf can only
   collect it for Java** (`--profile-java`, which includes `wall`); `--profile` is on-CPU
   only, so for anything else this step ends in aperf's data.

5. **Re-qualify every other finding in the report.** This is the step most often missed.
   If the run was mostly idle, PMU-derived findings (`Reduced Instructions per Cycle`,
   the `*-mpki` family, stall findings) were computed over a diluted sample and should be
   reported as low-confidence until a properly loaded run exists.

6. **Only then remediate**, matching the cause established above: increase concurrency or
   pool size, remove the blocking dependency, resolve the I/O or network ceiling, or
   right-size the instance downward if the headroom is genuine and permanent.

**Quantify the recommendation — do not stop at "there is headroom."** aperf's message,
`CPU utilization might not be maximized.`, is a judgement with no number in it, yet the report
already contains everything needed to say *how much*.
[`../tools/aperf_rightsize.py`](../tools/aperf_rightsize.py) computes it:

```console
$ python3 tools/aperf_rightsize.py --vcpu 64 --avg-total 12.74 --avg-idle 86.92 \
      --peak 31.0 --no-smt
CPU averages 12.74% with a max peak of 31.00% across 64 vCPUs (19.84 vCPUs in use at
peak). Holding peak under 70% needs 28.34 vCPUs, so 32 vCPUs suffices — a 50% reduction.
```

Read `--vcpu` from systeminfo `CPUs`, `--avg-total` and `--peak` from the `aggregate` metric's
`total` series, and `--avg-idle` from the `idle` series. The tool prints its caveats alongside
the sentence, and refuses rather than guessing when the inputs cannot support a recommendation.

Three outcomes, all reachable from a *low* average — and note that the score does not order
them, which is why the number matters more than the finding:

| Observed (5-min run) | score | Sizing verdict at a 70% ceiling |
|---|---|---|
| 64 vCPU, avg 12.74%, peak 31% | −445.03 | 32 vCPU suffices — **50% reduction** |
| 16 vCPU, avg 33.89%, peak 34% | −336.80 | 8 vCPU suffices — **50% reduction** |
| 16 vCPU, avg 0.25%, one 74% spike | **−509.04** | peak alone needs 16.91 vCPU — **do not shrink** |

## Priority and execution risk

**Priority: P2 — Investigate** by default: the finding is a strong signal with an ambiguous
cause, and the two causes demand opposite actions. It becomes **P1 — Act now** once the
recording is confirmed to have targeted a saturated workload and the idle time is steady
rather than an edge artifact. It drops to **P4 — Informational** when the idle is by design
or is genuine headroom — but P4 here means *report the number from STEP 4b*, not *say nothing*:
an unquantified "there is headroom" is the outcome this playbook exists to prevent.

**Execution risk: R0 — Read-only** to diagnose: every step up to and including off-CPU
profiling only reads, and so does computing the sizing recommendation. Acting on the outcome
splits by cause and spans the whole range — **R2** to resize a thread pool or add worker
processes, **R4** to right-size the instance or lift a network ceiling, **R5** where
increasing concurrency trades tail latency for throughput. **Never inherit the R0 of the
investigation into the remediation:** the arithmetic is free, the resize is not.

**The score is amplified but carries no severity.** It is exactly `avg(idle)/50 × −256`, so it
is bounded at `−512` and is a restatement of the value — with the practical consequence that
this rule almost always sorts first in the Analytical Findings panel. **Top position here is
an artifact of the formula, not a ranking**, and **the score says nothing about how many vCPUs
are reclaimable.** On 16 vCPUs, a near-idle run with one 74% spike scores `−509.04` and is
reducible by **0%** (the peak alone needs 16.91 vCPUs), while a flat 34% run scores `−336.80`
and is reducible by **50%**. The worse-scoring finding is the one you must not act on. Only
STEP 4b distinguishes them.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `avg(idle)` over the `Aggregate` series exceeded 50.0% (`Greater`, so
exactly 50.00 does not fire).

```
STEP 0 — Are the validity gates clear?
  IF any of the 8 gates fired (GATES.md)
  THEN → resolve them FIRST. In particular `Inconsistent Number of CPUs` changes the
         DENOMINATOR of this metric, so the two runs' idle percentages are not
         comparable quantities (P0, R4)
  ELSE continue. This rule is single-run, so it is readable even when a comparison
       is void — but its cross-run interpretation is not.

STEP 1 — Recover the precise value, then sanity-check the geometry.
  Parse: The {stat} in {run} is {value}.   e.g. "The average in flask_run_02 is 86.92."
  Prefer value_from_score(score, 50.0, -256) and take the root above 50.

  IF the run used the default --interval 1 --period 10 (~11 samples)
  THEN → the reported average understates true idle by roughly idle/n, about 8pp at
         90% idle. The finding is REAL but the magnitude is understated (P2, R0)
       → verify: re-report with `--time-range 1:` to drop the forced-zero first
         sample; avg(idle) should RISE and the score become more negative
       → for anything beyond triage, re-record with --period 60 or longer

  IF `mux_counter_schedule_rate` < 100 in the same run
  THEN → note it for STEP 5 only; it does not affect this finding, which reads
         /proc/stat and never touches the PMU (P4, R0)

STEP 2 — Read the SHAPE of the idle series. The average cannot distinguish these,
         and they need opposite responses.
  Retrieve the full `idle` Aggregate series, not the stat.

  FLAT high idle for the whole window
    → steady under-load. The average is representative; continue to STEP 3 (P2, R0)

  HIGH at the start and/or end, LOW in the middle
    → MEASUREMENT WINDOW ARTIFACT: aperf was started before the load or stopped
      after it. The most common explanation for avg(idle) > 85% (P2, R0)
    → verify: re-report with `--time-range FROM:TO` scoped to the loaded interval.
      If the finding disappears, it was an artifact and nothing needs remediation
    → do NOT proceed to remediation on a diluted average

  RAMP that never plateaus
    → the workload never reached steady state within the window (P2, R0)
    → verify: re-record with a longer --period; the plateau is what to measure

  SAWTOOTH or periodic collapse
    → an external dependency stalling in cycles: GC pauses, batch commits, a
      polling loop, or credit exhaustion on a T-family instance (P2, R0)
    → verify: overlay `steal` — a sawtooth in `steal` is credit throttling, not
      your workload

STEP 3 — MANDATORY manual check: is the machine idle, or is the WORK narrow?
  Aggregate idle is blind to imbalance (the stat reads the Aggregate series only).

  IF per-CPU `idle` is BIMODAL (some series near 0%, others near 100%)
  THEN → NOT global under-utilization. This is a parallelism, affinity, or
         partitioning limit, and the aggregate number is misleading (P1, R2)
       → verify: after raising concurrency, per-CPU idle should FLATTEN across
         series; aggregate idle falling with a bimodal shape intact means you
         added work to the already-busy cores
       → the ceiling: a single-threaded process on N vCPUs cannot push aggregate
         utilization above ~100/N percent, so on 64 vCPUs it reads ~98.4% idle
         while fully saturating one core

  IF per-CPU idle is UNIFORMLY high
  THEN → genuine global under-load; continue to STEP 4 (P2, R0)

  IF `steal` is non-trivial
  THEN → the hypervisor took the time; this is not your idle (P1, R4)
       → verify: on a T-family instance check CPU credit balance in CloudWatch —
         aperf does not collect it. Throttling reads as idle from /proc/stat
       → aperf reads HOST /proc/stat, so a cgroup-quota-throttled container also
         looks idle here while being at its own limit. Check the quota manually

STEP 4 — Establish INTENT, then find what blocked.
  The same value means opposite things depending on what the recording targeted.
  aperf does not record intent — this step needs the user or the run's metadata.

  IF the recording was NOT meant to capture saturation
  THEN → downgrade to informational and QUANTIFY the headroom. Do not stop at
         "there is headroom" -- compute the reduction, per STEP 4b (P4, R0)
       → the right-sizing test: sustained avg(idle) > 70% with a flat shape, across
         a representative window (not 10 seconds), and no latency SLO depending on
         the headroom. Then downsizing is the action, and it is R4
       → verify: after resizing, expect avg(idle) to fall toward the target and
         `Consistent CPU Utilization` to STOP firing against the old run

STEP 4b — QUANTIFY it. Turns "might not be maximized" into an actionable number.
  Run `tools/aperf_rightsize.py` (formula and inputs in Guidance above). Two traps
  it exists to prevent: peak is max(total), NEVER 100 - min(idle), which always
  yields 100%; and at --period 10 both p99 and p99_9 ARE max, not tail statistics.

  IF vcpu_needed > cur_vcpu
  THEN → DO NOT SHRINK. Despite the low average, peaks already breach the ceiling:
         this is a bursty workload, not spare capacity (P4, R0)

  IF target < cur_vcpu
  THEN → report the sentence, then gate it on the other dimensions (P4, R4)
       → verify: memory (MemAvailable/MemTotal) and network (ena_stat allowances)
         are resized by the SAME instance change. A CPU saving that hits a memory
         or bandwidth ceiling is a regression
       → verify: on x86 with SMT the target is target/2 PHYSICAL cores and siblings
         share execution units, so confirm with a load test, not arithmetic

  ELSE → correctly sized already; the low average is idle time between peaks (P4, R0)

  IF saturation WAS intended, find the blocker in this order:
    IF `iowait` is non-trivial or `Increased I/O Wait Time` fired
    THEN → storage-blocked, not idle. Pivot to that playbook (P1, R4)
         → verify: `diskstats` time_reading/time_writing/in_progress. NOTE
           diskstats has NO analytical rules — read it manually

    IF any `ena_stat` allowance finding fired
    THEN → a network ceiling capped the workload before the CPU (P1, R4)
         → verify: the allowance counter should stop incrementing after the
           instance or ENA configuration changes

    IF `number_threads`/`number_processes` from `processes` is far below vCPU count
    THEN → not enough concurrency to fill the machine (P1, R2)
         → verify: raise the pool, then confirm per-CPU idle flattens (STEP 3)
         → runtime-specific: see below — for Python the axis is PROCESSES

    IF `MemAvailable` is low or `pgmajfault` is non-zero
    THEN → threads stalled on memory reclaim or paging (P1, R4)
         → verify: `Major Page Faults Detected` / `Excessive Page Fault Rate`

    ELSE → no aperf data explains it: the blocking is in-application (locks,
           synchronous RPC, a downstream service) (P2, R0)
         → OFF-CPU PROFILING is the only decisive evidence, and aperf collects it
           for JAVA ONLY. --profile records cpu-clock:pppH, which samples only
           threads that are ON a CPU, so a blocked thread contributes zero
           samples -- exactly the data needed and exactly what is missing
         → for Java: --profile-java, then compare the `wall` and `cpu` profiles;
           stacks heavy in wall and absent from cpu are the ones that slept
         → otherwise the honest answer is that aperf cannot answer this, and the
           investigation continues in an external off-CPU tool

STEP 5 — Re-qualify the rest of the report. Most often skipped.
  A mostly-idle window means every PMU ratio was computed over a diluted sample:
  the idle loop and background daemons are in the denominator.
  → report `Reduced Instructions per Cycle`, the `*-mpki` family, and both stall
    findings as LOW CONFIDENCE until a properly loaded run exists (P2, R0)
    → verify: on a properly loaded re-run, these ratios should CHANGE — if they
      are unchanged, the dilution was not what produced them and they are real
    → note: this is independent of `mux_counter_schedule_rate`, which is a
      separate source of error in the same numbers

STEP 6 — What survives?
  VALID      : configuration findings (THP state, ENA Express, tiered compilation,
               PREEMPT_LAZY) — they do not depend on load at all
  CAUTION    : `ena_stat`/`efa_stat` saturation flags — a hit ceiling is real even
               in an idle window, and is a likely CAUSE of the idle
  CONFOUNDED : all per-unit `perf_stat` efficiency metrics (IPC, miss rates,
               stall rates), diluted by idle-loop and daemon activity
  VOID       : any claim that the application is CPU-bound, and any absolute
               throughput or per-second rate read as characteristic of the workload

INSUFFICIENT DATA
  IF the `idle` metric is absent from the run
  THEN → the rule returned early (`None => continue`); NO finding produced (P2, R0)
  IF the run is at default geometry and avg(idle) is just above 50
  THEN → the forced-zero sample makes the true value ~5pp higher and the threshold
         proximity meaningless. Do not branch on the exact value (P2, R0)
```

## Runtime-specific consequences

The mechanism is the same for all four: each runtime derives its concurrency from something
that is *not* the vCPU count of the machine, so a machine can sit idle while the runtime
believes it is at capacity. What differs is which knob actually moves the idle number.

| Runtime | Why the machine can be idle while the runtime is "full" | What to check, and the effective axis |
|---|---|---|
| **.NET** | `ThreadPool` grows by hill-climbing at roughly one thread per 500 ms, so a burst of blocking work starves the pool for seconds. Blocking on `Task.Result`/`.Wait()` consumes a pool thread that then cannot run work | `ThreadPool.MinThreads` (or `DOTNET_ThreadPool_MinThreads`); convert sync-over-async to `await`. Server GC (`DOTNET_gcServer=1`) sizes heaps per core and is the other core-count-derived default |
| **Python** | The GIL means threads do not add CPU parallelism — a thread pool on 64 vCPUs still saturates about one core. This is the most common cause of a bimodal per-CPU profile in STEP 3 | **Scale by PROCESSES, not threads**: `gunicorn -w`, `multiprocessing.Pool`, `uvicorn --workers`. Check whether the hot path is a native extension that releases the GIL — those do scale on threads |
| **Java** | `availableProcessors()` sizes the common `ForkJoinPool` at `n−1`, the GC thread count, and JIT compiler threads. Under a cgroup quota the JVM sees the quota, not the host, so it may be correctly sized for a limit the host does not show | `jvmArguments` in the profile metadata (aperf does not report the active GC directly); pool sizing in application code. For blocking I/O the fix is usually a dedicated pool, not a larger common one |
| **Perl** | Preforking is the only real concurrency model; ithreads are rarely used and do not share well. Worker count is a static configuration number, so it does not adapt to load at all | The preforking parent's worker count (`StartServers`/`MaxRequestWorkers` under mod_perl, or the equivalent supervisor setting). `perl -V` build options matter more than any runtime flag |

**The unknown-runtime case is the default.** aperf reports no language field; the runtime is
inferred from `processes` metric names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3),
which is a heuristic. When the runtime cannot be identified, stop at STEP 3's bimodal test —
it is runtime-independent and answers the same question.

## Architecture-specific considerations

This finding reads `/proc/stat`, so unlike the 15 `perf_stat` findings it fires on every
architecture and its metric means the same thing everywhere. The architecture dependence is
entirely in **what you should do about the idle time** — and specifically in whether STEP 4b's
target is trustworthy.

**Graviton's near-linear utilization scaling is the reason the rule is `Critical`**
(`data-descriptions.ts:105`): each vCPU is a physical core with no sibling contention, so
throughput tracks utilization more linearly than on SMT x86. Two consequences:

- On **arm64**, idle headroom converts to throughput more predictably, so STEP 4b's
  arithmetic is more trustworthy — treat its number as a projection you can act on.
- On **Intel** and **AMD** with SMT enabled, two vCPUs share one physical core, so STEP 4b's
  target of *N* vCPUs is only *N/2* physical cores. A run reading 50% aggregate idle may
  already be at physical-core saturation, with the idle half being siblings that cannot
  contribute. **Check `threads-per-core` before treating x86 idle as headroom** — aperf does
  not expose it, so this is a manual check against the instance type. This is the single most
  common over-estimate of x86 headroom, and the reason STEP 4b's x86 branch ends in a load
  test rather than a resize.

**The silent cross-architecture case.** aperf has no architecture field, and no rule
compares `Instance Type` ([../GATES.md](../GATES.md)). An Intel→Graviton comparison with
matched `CPUs` and `MemTotal` fires **no gate at all**, yet 16 Graviton vCPUs are 16 physical
cores while 16 x86 vCPUs are 8. A "CPU utilization improved" conclusion across that pair is
comparing different amounts of hardware.

**Architecture-specific builds are where the idle actually goes.** When STEP 4 finds no
blocker in aperf's data and the workload is a framework rather than application code, the
build variant is the usual answer — the exemplar being `microsoft/onnxruntime` versus
`amd/ZenDNN-onnxruntime`, or an arm64 build without `-mcpu=neoverse-*`. A generic build
leaves cores idle waiting on a serial path that a tuned build vectorizes. This is **R3 —
rebuild**, and it is invisible to every metric aperf collects; the only signal is that the
idle has no other explanation.

**Counter mode does not affect this finding**, but it does affect STEP 5. Grouped is the
default (`src/data_collection.rs:379`), running about twice the counters of
`--ungroup-pmu-events`, so a run whose `perf_stat` numbers look cleaner may simply have been
recorded ungrouped. See [../ARCHITECTURE.md](../ARCHITECTURE.md) §3.4 before comparing the
PMU findings you re-qualified.

## Verification

There is no single re-run that confirms this finding, because the causes are verified
differently. For a **measurement artifact**, re-report with `--time-range` scoped to the
loaded interval: the finding should disappear, and if it does, nothing on the system needed
changing. For **real blocking**, apply the concurrency or dependency fix from STEP 4 and
re-record: `avg(idle)` should fall and per-CPU idle should flatten across series — if
aggregate idle falls while the per-CPU shape stays bimodal, you added work to already-busy
cores and the parallelism limit is untouched. For **genuine headroom**, the verification is
the resize itself: after it, `max(total)` should land near the ceiling STEP 4b sized for, and
this finding should stop firing. If `max(total)` overshoots the ceiling, the peak used for
sizing was a percentile that had collapsed to `max` — re-check with a long run.

Note that a run recorded at default `--period 10` cannot verify anything here: the
forced-zero sample moves the average by ~10% relative, which is larger than most
improvements you would be trying to detect, and every percentile at or above `p99` is a
single 1-second sample.

## Do not

- **Do not recommend "increase load" as the fix.** The finding describes the measurement,
  not the production system. Raising synthetic load may hide a real upstream bottleneck.
- **Do not treat the top position or the large negative score as severity.** Both follow
  mechanically from the score formula. A `Critical`-scored idle finding on a service
  designed for headroom is noise.
- **Do not read `idle` as utilization.** Utilization ≈ `100 − idle`; `iowait` is counted
  separately and is not idle.
- **Do not conclude "CPU is not the bottleneck" and stop**, and do not stop at "there is
  headroom" either. Both are the beginning of the investigation; the deliverable is a number.
- **Do not trust aggregate idle for pinned, single-threaded, or cgroup-limited workloads.**
  The stat is computed over the `Aggregate` series only, so per-CPU imbalance is structurally
  invisible to it — step 3 exists because the number cannot show it.
- **Do not act on other PMU findings from the same run without re-qualifying them** (step 5).
- **Do not read the absence of this finding as proof the machine was busy.** At the default
  `--period 10` the rule needs a *true* `avg(idle)` above **55%** to fire, so it is silent on
  a machine genuinely running at 45–49% utilization. Run STEP 4b's arithmetic anyway.
- **Do not treat x86 idle as headroom without checking SMT.** Two vCPUs share a physical
  core, so 50% aggregate idle can already be physical-core saturation, and STEP 4b's target
  of *N* vCPUs is *N/2* cores. aperf does not report `threads-per-core`.
- **Do not add threads to a Python workload to consume the idle time.** The GIL means
  threads do not add CPU parallelism; the axis is processes. This is the most common wrong
  action taken on this finding.
- **Do not compute peak utilization as `100 − min(idle)`.** The forced-zero first sample is
  applied to every CPU state, so `min(idle)` is `0.00` in essentially every run and
  `100 − min(idle)` returns exactly `100%` on an idle machine — blocking a resize that should
  have gone ahead. Read `max(total)` from the `aggregate` metric instead.
- **Do not quote a `p99` peak from a short run.** Percentiles index with `floor(q × n)`, so
  `p99` equals `max` for any run with n ≤ 100 samples, and `p99_9` for n ≤ 1000. At the
  default `--period 10` both *are* the single highest 1-second sample; calling that a
  percentile implies a tail measurement that does not exist.
- **Do not right-size off a short run, or off the average alone.** A low average with a high
  peak is a bursty workload, not spare capacity — size on `max(total)`, since peak can need
  *more* vCPUs than the instance has even while `avg(idle)` exceeds 50%.
- **Do not conclude anything cross-run from this rule.** It is single-run and per-run, so
  two runs each produce their own finding; comparing their values is only meaningful once
  the gates in [../GATES.md](../GATES.md) are clear — `Inconsistent Number of CPUs` in
  particular changes this metric's denominator.

## References

- Rule definition: `src/analytics/rules/cpu_utilization.rs:25` — `metric: "idle"`,
  `stat: Stat::Average`, `comparator: Comparator::Greater`, `threshold: 50.0`,
  `score: Score::Critical`. Single-run and per-run: `requires_comparison` is false, so each
  run produces its own finding independently.
- Rule template: `src/analytics/rule_templates/time_series_stat_threshold_rule.rs` — calls
  `compute_finding_score`, so **this rule's score is amplified**: it is a restatement of the
  value, not a severity. Returns early (`None => continue`) when the metric is absent from a
  run, producing no finding at all.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`, over
  `Score::Critical = −256` (`src/analytics/mod.rs:147`). With `threshold = 50.0` the `else`
  branch applies: `delta = value / 50.0`, then `delta × −256`. Because `idle` is a percentage
  bounded at 100, the score is bounded at **−512**.
- Aggregate-only statistics: `src/data/common/time_series_data_processor.rs:312`
  (`stats_series_idx`) and `:348` — the stat is computed over the `Aggregate` series alone,
  which is why per-CPU imbalance is invisible to this finding.
- Forced-zero first sample: `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189` — returns `None` on the first snapshot;
  `compute_time_diff_index`, `src/data/common/processed_data_accessor.rs` (used at `:105`,
  `:434`, `:501`) yields `start_idx = 0` without `--time-range`, so the zero is inside the
  average. Confirmed by the frontend text at `data-descriptions.ts:94`: "since the metric
  values were computed using the delta between two snapshots, the first value is always zero.
  The statistics of a metric graph accounts for its aggregate series."
- Recording geometry: `--interval` default `1` (`src/record.rs:37`), `--period` default `10`
  (`src/record.rs:47`), giving ~11 samples. `--time-range` is a *report*-time flag
  (`src/report.rs:245`), so `--time-range 1:` re-scopes an already-recorded run without
  re-recording.
- CPU states collected: `CpuState` at `src/data/cpu_utilization.rs:99` — eight variants
  (`USER`, `NICE`, `SYSTEM`, `IDLE`, `IOWAIT`, `IRQ`, `SOFTIRQ`, `STEAL`). `IOWAIT` and
  `STEAL` are **separate metrics from `IDLE`**, which is why blocked and stolen time do not
  inflate this finding but do explain it.
- Graviton scaling claim: `data-descriptions.ts:105` — "the performance of Graviton instances
  increases near-linearly with CPU utilization". This is the stated reason idle time is
  treated as `Critical`. Counter mode default `GROUPED_PMU_MODE`,
  `src/data_collection.rs:379`, matters only to the PMU findings re-qualified in step 5.
- Upstream guide: `CPU_UTILIZATION_OPTIMIZATION` in
  `src/report_frontend/src/definitions/optimization-guides.ts:1` — covers both the
  higher- and lower-than-expected directions, and profiling prerequisites.
- Related playbooks: `increased-io-wait-time.md`, `consistent-cpu-utilization.md`,
  `decreased-user-space-cpu-utilization.md`,
  `../systeminfo/inconsistent-number-of-cpus.md` (changes this metric's denominator),
  `../ena_stat/inbound-bandwidth-allowance-exceeded.md`,
  `../ena_stat/outbound-bandwidth-allowance-exceeded.md`,
  `../meminfo/inconsistent-physical-memory.md`, `../statistical/README.md`.
- Sizing recipe: [`../tools/aperf_rightsize.py`](../tools/aperf_rightsize.py) — computes the
  three numbers this finding omits (underutilization, peak, reducible %) with the forced-zero,
  percentile-collapse, `min(idle)` and SMT corrections applied. `tools/test_aperf_rightsize.py`
  validates it against a simulation of aperf's collection loop, not merely against itself.
- Cross-cutting: [../GATES.md](../GATES.md) (precedence),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) (P/R vocabulary, runtime inference),
  [../ARCHITECTURE.md](../ARCHITECTURE.md) (PMU profiles, counter mode).
- Graviton perfrunbook: [system load and compute
  headroom](https://aws.github.io/graviton/perfrunbook/system-load-and-compute-headroom.html),
  [check CPU usage](https://aws.github.io/graviton/perfrunbook/debug_system_perf.html#check-cpu-usage),
  [off-CPU profiling](https://aws.github.io/graviton/perfrunbook/debug_code_perf.html#off-cpu-profiling)
  — the last recommends a technique aperf cannot collect for non-Java workloads. Field
  semantics: [`proc_stat(5)`](https://man7.org/linux/man-pages/man5/proc_stat.5.html)
