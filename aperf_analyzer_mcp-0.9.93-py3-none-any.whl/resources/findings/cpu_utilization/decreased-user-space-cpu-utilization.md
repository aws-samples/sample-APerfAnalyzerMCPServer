---
rule_name: Decreased User-Space CPU Utilization
data_type: cpu_utilization
data_key: user
template: time_series_stat_run_comparison
condition: "delta_avg(user) <= -0.1"
base_score: Poor
score_sign: negative
requires_comparison: true
aperf_message: "The code is consuming less CPU time. Some functions may be putting threads to sleep and causing the CPU to go idle more."
source: src/analytics/rules/cpu_utilization.rs:44
---

# Decreased User-Space CPU Utilization

## What fired

The **average** of the `user` metric in this run is **at least 10% lower** (relative) than
the same average in the **base run**. The rule uses `Comparator::LessEqual` against a
`delta_ratio` of `-0.1` with `abs: false`, so it is strictly directional — only decreases
fire it.

Requires ≥2 runs. Base score `Poor` (−16).

## The collection gap — off-CPU profiling is Java-only, verified by reading the collection code

**aperf's upstream guide tells you to do off-CPU profiling, and aperf cannot collect it for
non-Java workloads.** This matters because off-CPU profiling is the one decisive answer to
"what put the threads to sleep" — the question every section below turns on.

`--profile` runs exactly one command (`src/data/perf_profile.rs:126`–`:139`):

```
perf record -a -q -g -k 1 -F <perf_frequency> -e cpu-clock:pppH -o <run_dir>/perf.data -- sleep <period>
```

`cpu-clock` only samples threads that are **on** the CPU. There is no `sched:sched_switch`
event, no `--off-cpu`, and no second `perf record` invocation — `raw_perf_on_cpu_profile_path`
is the only profile path in the file, and the name is literal. Whatever aperf produces from
this (`flamegraph.svg`, `reverse-flamegraph.svg`, `perf.data.jit` via `perf inject -j`) is an
on-CPU artifact. **A blocked thread contributes zero samples**, which is precisely the data you
need and precisely what is missing.

**Java is the exception.** `--profile-java` launches async-profiler with three modes,
`cpu`, `alloc`, and `wall` (`PROFILE_METRICS`, `src/data/java_profile.rs:32`), and the launch
passes `--wall 100ms` (`:81`). **Wall-clock profiling samples threads regardless of run
state**, so a Java run recorded with `--profile-java` *does* contain the off-CPU evidence — in
the `wall` heatmap, not the `cpu` one. Diffing `wall` against `cpu` isolates blocked time
directly: stacks heavy in `wall` and absent from `cpu` are stacks that slept.

**For every other runtime, off-CPU profiling is an out-of-band step.** You must run it
yourself alongside aperf (`perf record -e sched:sched_switch -g`, `offcputime-bpfcc`, or
`bpftrace`), or infer the cause from the state decomposition in the decision tree's STEP 2.
Recommending
"re-record with `--profile`" for a Python, .NET, or Perl blocking investigation **will not
produce the data** — say so rather than sending the user on a round trip.

## Reasoning

**aperf scores *less* user CPU as a problem. This is counterintuitive and is the whole point
of the rule** — so understand the assumption before acting.

`user` is "Percentage of CPU time spent in user mode", `desired: "higher"`. The rule's
premise is a **fixed-load benchmark**: the load offered to the system is held constant
between runs. Under that premise, if the application spends materially less time executing
its own instructions, the threads did not become more efficient — they **stopped running**.
Something took them off-CPU:

- **Lock contention** — threads blocked on a mutex, semaphore, or monitor.
- **Synchronous I/O** — a read/write that now blocks where it previously hit cache.
- **Network round-trips** — a downstream call added, or a downstream service slowed.
- **Thread-pool starvation** — fewer runnable threads, or a pool resized down.
- **Scheduler / cgroup throttling** — CPU quota now being hit.
- **A new sleep or backoff** — retry logic, rate limiting, added `sleep`.

That is precisely what aperf's message says: *"Some functions may be putting threads to
sleep and causing the CPU to go idle more."*

**But the premise fails in the most important case.** If the change under test was a genuine
optimization — a better algorithm, removed redundant work, an added cache, vectorization —
then doing the *same* work with *less* CPU is exactly the goal, and this finding is firing on
your success. The finding cannot tell the two apart, because aperf does not know your
throughput.

The discriminator is **where the CPU time went**:

| `user` ↓ and… | Reading |
|---|---|
| `idle` ↑ | Threads are off-CPU. Blocking — investigate. |
| `iowait` ↑ | Threads blocked on storage specifically. |
| `system` ↑ | Work moved into the kernel (more syscalls) — not a win. |
| nothing else changed, throughput held | Genuine efficiency win. False positive. |
| throughput also ↓ | The workload delivered less; find out why. |

**Off-CPU profiling is the definitive discriminator** — it names the call stacks that went
to sleep. On-CPU profiling cannot answer this question, because the problem is time *not*
spent on CPU. **aperf collects off-CPU data for Java only** (async-profiler's `wall` mode);
`--profile` runs `perf record -e cpu-clock`, which is on-CPU and blind to blocked threads. See
*The collection gap* above before recommending a re-record.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({value}) is {±pct} {base_run} ({base_value}).
```

`delta_ratio_to_percentage_string` renders the **absolute** percentage plus a relation word.
Because this rule only fires on decreases, the word is always `"less than"`:

```
The average in run_b (38.10) is 24.30% less than run_a (50.32).
```

The percentage is unsigned in the text — the direction is carried by the word `less`, not by
a minus sign. Recover the signed delta ratio as `(value − base_value) / base_value`.

Score math — `compute_finding_score(delta_ratio, −0.1, −16)`. Both the value and the
threshold are negative, so their ratio is positive and the score stays negative:

| observed Δ | score |
|---|---|
| −12% (−0.12) | `(−0.12/−0.1) × −16` = **−19.20** |
| −24.3% (−0.243) | `(−0.243/−0.1) × −16` = **−38.88** |
| −50% (−0.5) | `(−0.5/−0.1) × −16` = **−80.00** |

Linear in the delta: `|delta_ratio| = |score| / 16 × 0.1`.

**Edge case:** if this run's `avg(user)` is exactly `0.0` while the base run's is non-zero,
the value-zero branch of `compute_finding_score` returns `2 × −16 = −32.00` regardless of
how large the base value was. A score of exactly `−32.00` on this rule means the application
used **no** user-mode CPU in this run at all — almost always a failed or never-started
workload, not a performance issue.

## Interpretation

| Observed Δ | Throughput held constant | Throughput also fell |
|---|---|---|
| −10 to −20% | Mild blocking, or a modest efficiency win | Workload delivered less — find out why |
| −20 to −50% | Significant blocking; off-CPU profile needed | Likely a functional problem, not a perf one |
| >−50% | Workload probably did not run properly | Verify the run is valid at all |
| `user` ≈ 0 | The application did not execute | Invalid run |

**Known false positives — check these first:**

- **The change was a genuine optimization.** Less CPU for the same delivered throughput is
  the goal. This is the single most important false positive for this rule, and the reason
  it must never be reported as a defect without throughput data.
- **Load generator delivered less traffic.** If `Inconsistent Inbound Network Traffic` also
  fired, the runs were not given the same input and the comparison is invalid. Very common.
- **Work moved user→kernel.** A change that adds syscalls (smaller I/O batches, disabled
  batching, added instrumentation) *decreases* `user` while *increasing* `system`. Not an
  improvement, but not blocking either. Read `system`.
- **Base run was anomalously busy.** If the base run had a spin-wait, a busy-poll loop, or a
  runaway thread, its high `user` is the defect and this run is the healthy one.
- **The workload finished early.** If the application completed before the recording window
  ended, the trailing idle period drags the average down. Check the `user` series shape over
  time.
- **Different core counts or instance types.** `user` is a percentage over all CPUs; if
  `Inconsistent Number of CPUs` fired, the denominators differ and the comparison is invalid.
- **Recording window included more warm-up/teardown** in this run than in the base.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `idle` | `cpu_utilization` | The primary discriminator: `idle` ↑ by a comparable amount ⇒ threads went off-CPU (blocking) |
| `iowait` | `cpu_utilization` | `iowait` ↑ ⇒ storage-blocked specifically; pivot to `Increased I/O Wait Time` |
| `system` | `cpu_utilization` | `system` ↑ ⇒ user→kernel shift, not blocking |
| `aggregate` | `cpu_utilization` | If `Consistent CPU Utilization` also fired, total CPU is flat ⇒ pure mode shift, so read `system` |
| `user` series over time | `cpu_utilization` | Distinguishes a uniformly lower level from a run that stopped early |
| **Off-CPU evidence** | `java_profile` (`wall`) **only** | **The decisive evidence** — names the stacks that blocked. Available for Java via `--profile-java` (async-profiler `--wall 100ms`). **`--profile` collects on-CPU only** (`perf record -e cpu-clock`), so for non-Java runtimes this must be gathered out of band. **No analytical rules** — read manually |
| `number_threads`, `number_processes` | `processes` | Fewer threads ⇒ pool shrank or threads died. **No analytical rules — read manually** |
| `user_space_time` per process | `processes` | Confirms *which* process stopped consuming CPU |
| `time_reading`, `time_writing`, `in_progress` | `diskstats` | Confirms storage blocking. **No analytical rules — read manually** |
| `IpExt:InOctets`, `IpExt:OutOctets` | `netstat` | Whether the offered load was actually the same |
| `bw_*_allowance_exceeded`, `pps_allowance_exceeded`, `conntrack_allowance_exceeded` | `ena_stat` | A network ceiling throttling the workload upstream of the CPU |
| `MemAvailable`, `SwapFree` | `meminfo` | Memory pressure stalling threads |
| `pgmajfault` | `vmstat` | Major faults blocking threads on disk |
| `ipc` | `perf_stat` | Sanity check on efficiency; note `ipc` is computed over whatever ran, so a mostly-idle run gives a diluted value |
| `CPUs` | `systeminfo` | Denominator check |

## Guidance

Ordered. Step 1 gates everything; do not report a defect before completing it.

1. **Get throughput for both runs from outside aperf.** This finding is uninterpretable
   without it.
   - Throughput **unchanged**, `user` down ⇒ **efficiency win.** Report as an improvement,
     not a defect. Explain that aperf scores it `Poor` because the rule assumes fixed load.
   - Throughput **also down** ⇒ real problem. The application delivered less. Proceed.
   - Throughput **up** while `user` is down ⇒ a substantial win; verify the measurement.
   - Throughput **unknown** ⇒ say so explicitly and present both hypotheses rather than
     asserting one.

2. **Validate the comparison.** Check `Inconsistent Number of CPUs` / `Kernel Version
   Mismatch` (`systeminfo`), `Inconsistent Physical Memory` (`meminfo`), and
   `Inconsistent Inbound Network Traffic` (`netstat`). A load-generator difference is the
   most common invalidator for this specific rule.

3. **Find where the CPU time went.** Read `idle`, `iowait`, and `system` over the same
   window and classify per the table in *Reasoning*. This single step usually determines the
   whole investigation:
   - → `idle` ⇒ blocking; continue to step 4.
   - → `iowait` ⇒ storage; go to `Increased I/O Wait Time` and `diskstats`.
   - → `system` ⇒ syscall/kernel overhead; profile kernel-side.
   - → nowhere (total CPU also fell, throughput held) ⇒ efficiency win.

4. **Off-CPU evidence.** This is the answer to "what put the threads to sleep". For Java,
   re-record with `--profile-java` and diff the `wall` heatmap against `cpu`. For every other
   runtime, aperf cannot collect it — gather it out of band (`perf record -e
   sched:sched_switch -g`, `offcputime-bpfcc`, `bpftrace`). **Do not recommend `--profile`
   for this**; it is on-CPU only and blind to blocked threads.

5. **Check for external ceilings before blaming the code.** `ena_stat` allowance findings,
   `diskstats` latency, `MemAvailable` pressure, and cgroup CPU quota all produce this
   signature and are not application defects.

6. **Confirm the run is valid.** If `user` fell by more than ~50%, or the score is exactly
   `−32.00`, treat the run as suspect: verify the application started, stayed up, and was
   under load for the whole recording window before drawing performance conclusions.

## Priority and execution risk

**Priority: P2 — Investigate** by default, and this rule's default is unusually weak because
**the finding fires on success.** A genuine optimization produces exactly this signal. It rises
to **P1 — Act now** only once throughput is confirmed to have fallen *with* CPU, or `idle`/
`iowait` absorbed the difference at constant offered load — either is real blocking. It drops
to **P4 — Informational** when throughput held constant, where the correct report is "this is
an improvement that aperf scores negatively", and to **P0 — Blocked** when the run looks
invalid (score exactly `−32.00`, or `user` down more than ~50%), because nothing downstream is
interpretable until the run is confirmed to have executed.

**Execution risk: R0 — Read-only** to diagnose. Acting spans **R1** (raise a thread-pool size,
lift a cgroup CPU quota — reversible, no restart) through **R2** (change a runtime flag, resize
a connection pool) to **R3** (rebuild after removing a lock or a `sleep`) and **R4** where the
cause is a downstream service or an instance-level network ceiling that is not yours to change.
Note that **the highest-value outcome of this investigation is often no change at all** —
confirming an optimization worked.

**The score is capped, unlike its mirror.** A percentage cannot fall below zero, so
`delta_ratio ≥ −1.0` and the score cannot exceed `−160` — with one exception: the
`value == 0.0` branch of `compute_finding_score` (`src/analytics/mod.rs:180`) returns exactly
`2 × −16 = −32.00`, which is *weaker* than a −50% decrease scores. **The most severe case
(`user` at zero) produces one of the mildest scores.** Never rank this finding by score.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `avg(user)` in this run is at least 10% **lower** than in the base run,
relatively. Direction is certain; whether it is good or bad is not.

```
STEP 0 — Are the validity gates clear?
  IF `Inconsistent Number of CPUs` fired
  THEN → STOP. `user` is a percentage over all CPUs; the denominators differ and the
         delta is a normalization artifact (P0, R4)
       → verify: re-record on matched instance types
  IF `Inconsistent Inbound Network Traffic` fired
  THEN → THE LOAD GENERATOR DELIVERED LESS. This is the most common invalidator for
         THIS rule specifically: less offered load trivially produces less user CPU
         (P0, R4)
       → verify: `IpExt:InOctets` should match within noise across the runs before
         any CPU conclusion is drawn
  IF `Kernel Version Mismatch` or `Inconsistent Physical Memory` fired
  THEN → different kernels or hosts; scheduler and allocator behaviour differ and a
         `user` delta is expected (P0, R4)
       → verify: re-record on matched hosts and kernels
  ELSE continue.

STEP 1 — Is the run VALID? Do this before interpreting anything.
  IF the score is exactly -32.00
  THEN → this run's `avg(user)` is EXACTLY 0.0 (the `value == 0.0` branch,
         src/analytics/mod.rs:180). The application executed NO user-space code
         (P0, R0)
       → verify: check `processes` for the workload's PID and `user_space_time`; a
         true zero means it never started, died early, or was never given load
       → this is a broken run, not a performance finding. Do NOT profile it
  IF `avg(user)` fell by more than ~50%
  THEN → treat the run as suspect until proven otherwise (P1, R0)
       → verify: read the `user` series over time. A CLIFF partway through means the
         workload stopped; a UNIFORMLY LOWER LEVEL means it ran throughout
       → if it stopped early, the trailing idle drags the average down and the delta
         measures run duration, not efficiency
  IF the compared run's recording geometry is SHORTER than the base run's
  THEN → recover both sample counts:  n = 100 / (100 - (avg(total) + avg(idle)))
         (derivation in consistent-cpu-utilization.md)
       → the forced-zero first sample dilutes the SHORTER run more, biasing this
         delta DOWNWARD. Geometry alone can fire this rule whenever the compared
         run's n <= 5 (at n=5 the spurious decrease reaches -20%; at n=11, the
         default --period 10, it is about -10% and CAN cross the threshold)
         (P1, R0)
       → verify: re-report BOTH runs with `--time-range 1:`. If the finding
         disappears it was pure geometry
       → NOTE this rule is MORE exposed to geometry than its Increased mirror,
         because the default 11-sample run sits right at the -10% threshold
  IF `avg(user)` in BOTH runs is under ~5%
  THEN → NOISE. The rule is a pure ratio test with no absolute floor
         (time_series_stat_run_comparison_rule.rs:97-110), so at near-zero
         utilization a fraction of a percentage point produces a large ratio and
         therefore a large score. There is no workload here to have regressed
         (P3, R0)
       → read the score as a measure of RELATIVE change only. It is NOT a measure
         of severity when the absolute values are this small
       → verify: check `idle`. If `avg(idle)` is ~90% or higher in both runs, the
         machine was doing nothing in both, and `Underutilized CPU` will have
         fired on both runs — that finding, not this one, is the true story
       → observed on this host: two IDLE runs 16 s apart, identical
         --period 10 --interval 1, fired at score -72.98 because `avg(user)` went
         0.94 -> 0.51, a 0.43 PERCENTAGE-POINT change, while `avg(idle)` was
         89.60 and 90.10. The score outranked every genuine finding in the report
       → do NOT continue to STEP 2. Its decomposition assumes the lost percentage
         points are large enough to locate; here they are within sampling noise
  ELSE continue.

STEP 2 — Where did the CPU time GO? This is the classifying step.
  Read `idle`, `iowait`, `system`, `nice`, `steal` and the `aggregate`/`total` series
  over the same window. The percentage points `user` lost must reappear somewhere.

  IF `idle` ROSE by a comparable amount
  THEN → THREADS WENT OFF-CPU. Genuine blocking. Continue to STEP 3 (P1, R0)
  IF `iowait` ROSE by a comparable amount
  THEN → storage blocking specifically. Route to increased-io-wait-time.md and
         `diskstats` (P1, R0)
       → verify: `time_reading`/`time_writing`/`in_progress` in `diskstats` should
         have risen; `pgmajfault` in `vmstat` if it is paging
  IF `system` ROSE by a comparable amount
  THEN → work moved USER -> KERNEL. Not blocking, and NOT an improvement: more
         syscalls for the same work (smaller I/O batches, disabled batching, added
         instrumentation, a syscall-heavy library swap) (P2, R0)
       → verify: total CPU (`total`) roughly unchanged while the user/system split
         moved. `Consistent CPU Utilization` firing confirms it
  IF `nice` ROSE while `user` fell
  THEN → an ACCOUNTING split, not lost work. `user` excludes `nice`
         (src/data/cpu_utilization.rs:112-113), so any niced process lands in a
         metric this rule does not read (P3, R0)
       → verify: read `user` + `nice` TOGETHER, and check `idle` before concluding
         anything. Two different causes both land on this branch:
           `user`+`nice` roughly CONSTANT and `idle` roughly constant
             → a pure renice: the same work was reclassified. Nothing changed
           `user`+`nice` ROSE and `idle` FELL
             → niced work was ADDED. The machine got BUSIER while this rule
               reported a decrease. The finding is a false positive about the
               workload, and the real story is in `nice`, which has no rule at all
       → do NOT expect `user` + `nice` to be conserved. Observed on a real pair:
         `user` 1.19 -> 0.55 fired this rule at score -85.25 while `nice` went
         0.00 -> 89.90 and `idle` went 89.13 -> 0.00. The sum went 1.19 -> 90.45,
         so a conservation test would have wrongly cleared the branch
  IF `steal` ROSE
  THEN → the hypervisor took cycles away; on a T-family instance suspect CPU credit
         exhaustion (P1, R4)
       → verify: CPU credit balance in CloudWatch — aperf does not collect it
  IF NOTHING ELSE ROSE (total CPU fell too)
  THEN → the machine genuinely did less. Go to STEP 4; this is where the efficiency
         win lives (P2, R0)

STEP 3 — Blocking confirmed. Name the blocker.
  First rule out EXTERNAL CEILINGS, which are not application defects:
  IF any `ena_stat` allowance finding fired (bw_*, pps_, conntrack_,
     linklocal_allowance_exceeded)
  THEN → a network ceiling is throttling the workload UPSTREAM of the CPU. Threads
         are waiting on the network, not on your code (P1, R4)
       → verify: the allowance counter's rise should align in time with the `idle`
         rise
  IF `Reduced Memory Availability` fired or `pgmajfault` rose
  THEN → memory pressure is stalling threads (P1, R1)
       → verify: `MemAvailable`/`SwapFree` in `meminfo`
  IF cgroup CPU quota is in use
  THEN → throttling produces this exact signature. aperf does NOT collect
         cpu.stat/nr_throttled — check it out-of-band (P1, R1)
       → verify: `cpu.stat` `throttled_time` on the container's cgroup

  Then get the off-CPU evidence:
  IF the workload is JAVA and `--profile-java` data exists
  THEN → diff the `wall` heatmap against the `cpu` heatmap. Stacks heavy in `wall`
         and absent from `cpu` ARE the blocked stacks (P1, R0)
       → this is the ONLY off-CPU evidence aperf collects; see the section above
  IF the workload is Java and profile data is ABSENT
  THEN → re-record with `--profile-java` (P2, R0)
       → verify: the `wall` tab should appear in the report
  IF the workload is NOT Java
  THEN → aperf CANNOT collect off-CPU profiles. Run it out of band:
         `perf record -e sched:sched_switch -g`, `offcputime-bpfcc`, or `bpftrace`
         (P2, R0)
       → do NOT recommend re-recording with `--profile`; it produces an on-CPU
         profile that is blind to blocked threads
       → meanwhile, `processes` (`number_threads`, `user_space_time` per process)
         narrows WHICH process stopped consuming CPU, which is often enough

STEP 4 — No CPU went anywhere. Efficiency win, or less work delivered?
  This needs throughput, which aperf DOES NOT KNOW. Get it out of band.
  IF throughput HELD CONSTANT
  THEN → GENUINE EFFICIENCY WIN. The finding fired on your success. Report it as an
         improvement and explain the fixed-load assumption behind the `Poor` score
         (P4, R0)
       → verify: CPU-per-unit-work should have fallen by the same ratio as `user`
       → there is nothing to remediate. Do not manufacture an action
  IF throughput ALSO FELL
  THEN → the workload DELIVERED LESS. This is usually a functional problem rather
         than a performance one (P1, R0)
       → verify: whether errors, timeouts, or retries rose; a run serving fewer
         requests successfully is a correctness question first
  IF throughput ROSE while `user` fell
  THEN → a substantial win — but verify the measurement before believing it
         (P3, R0)
       → verify: confirm both runs ran the same scenario and the throughput metric
         means the same thing in both
  IF throughput is UNKNOWN
  THEN → present BOTH hypotheses explicitly. Do NOT assert a defect (P2, R0)
       → STEP 2's decomposition still stands on its own: it distinguishes blocking
         from a mode shift from a genuine reduction, without throughput

STEP 5 — What survives?
  VALID      : configuration findings — independent of load
  VALID      : the state decomposition from STEP 2 — arithmetic on the same window
  CAUTION    : `perf_stat` efficiency metrics. `ipc` is computed over whatever ran,
               so a mostly-idle run yields a DILUTED value that is not comparable to
               a busy run's. If `Underutilized CPU` fired on this run, treat every
               PMU ratio as low-confidence
  CAUTION    : any on-CPU flamegraph conclusion — it shows the shrinking remainder,
               which is the wrong question for a blocking investigation
  CONFOUNDED : the good/bad verdict, if STEP 4 could not establish throughput
  VOID       : the claim "this run regressed". Less CPU is the goal of most
               optimization work. This rule cannot distinguish success from failure

INSUFFICIENT DATA
  IF only ONE run is present
  THEN → the rule requires a base run; NO finding was produced (P2, R0)
  IF the BASE run lacks the `user` metric
  THEN → the rule returned early with a `debug!` and produced NO finding for ANY
         run (P2, R0)
  IF the finding is absent but you expected a decrease
  THEN → check STEP 1's geometry test in reverse: a base run recorded SHORTER than
         this one biases the delta upward and can mask a real decrease (P2, R0)
```

## Runtime-specific consequences

Every runtime can block, but each has a characteristic way of *appearing* to lose user CPU
without anything blocking — and the off-CPU gap above bites all of them except Java.

| Runtime | Characteristic cause of a `user` decrease, and what it is not | What to check |
|---|---|---|
| **.NET** | `ThreadPool` starvation is the classic true positive: blocking calls on pool threads shrink the runnable set while the hill-climbing algorithm adds threads only slowly, so `user` falls and `idle` rises. The benign counterpart is reaching steady state — JIT threads that burned `user` early in the base run are simply done, so a longer run reads lower | `ThreadPool` queue length and thread count out of band; whether the base run was short enough to be JIT-dominated. `DOTNET_ThreadPool_*` differences |
| **Python** | The GIL makes this reading unreliable: only one thread executes bytecode at a time, so a multi-threaded Python process cannot exceed roughly one core of `user` regardless of load, and a drop often means threads moved to waiting on the GIL — which is a futex wait, so it lands in `system`, not `idle`. `asyncio` blocking the event loop shows up as `idle` | Whether `system` rose (GIL contention) or `idle` rose (real blocking). Thread count in `processes` — more threads with less `user` is the GIL signature |
| **Java** | **The only runtime where aperf can answer this.** `--profile-java` collects `wall` alongside `cpu` (`--wall 100ms`), so blocked stacks are directly visible. True positives: monitor contention, a GC pause pattern change, a resized `ForkJoinPool`. Benign: JIT compilation finishing, or a GC change that cut collector CPU | Diff the `wall` heatmap against `cpu`. `jvmArguments` for pool sizing and GC changes. `JVM Version Comparison` |
| **Perl** | Single-threaded and interpreted, so `user` tracks work done closely and a decrease is usually real: a blocking DB call, a `sleep` in retry logic, or an added network round-trip. There is no adaptive runtime to produce a benign explanation | `diskstats` and `netstat` for what it is waiting on. `strace`-level detail is out of band; aperf's on-CPU profile will not show the wait |

**When the runtime is unknown** — it is inferred from `processes` metric names
([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3), a heuristic — STEP 2's state decomposition
is runtime-independent and answers the same classifying question.

## Architecture-specific considerations

The metric is `/proc/stat`-derived and means the same thing on every architecture. What
changes is the plausibility of the benign reading.

**A `user` decrease across an architecture change is the expected shape of a successful
migration.** Better vectorization, LSE atomics instead of LL/SC, or a higher-IPC core all do
the same work in less CPU time. aperf has **no architecture field** and no rule compares
`Instance Type` ([../GATES.md](../GATES.md)), so an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate at all** while this rule reports a decrease and scores it
`Poor`. Confirm `Instance Type` manually before reading the score as bad news — on a migration
comparison, this finding firing is frequently the result you were hoping for.

**SMT makes the percentage misleading in the other direction here.** On Intel and AMD with SMT,
two vCPUs share one physical core, so a `user` drop from 60% to 45% may not have freed
proportional physical capacity — the remaining threads may simply have stopped contending for
shared execution units and gotten faster per thread. On arm64, where each vCPU is a physical
core, the drop is closer to a literal capacity change (`data-descriptions.ts:105`). aperf does
not report `threads-per-core`; this is a manual check.

**Spin-then-block behaviour differs by architecture and changes which bucket the time lands
in.** A lock that spins burns `user` time; a lock that parks moves that time to `idle`.
Adaptive spin thresholds, `WFE`-based backoff on arm64, and `PAUSE` timing on x86 all differ, so
the same contention level can read as high `user` on one architecture and high `idle` on
another. **A `user` decrease with `idle` up across an architecture change can therefore be the
same contention behaving differently, not new blocking** — the lock is parking where it used to
spin. Confirm with an off-CPU profile (Java `wall`, or out-of-band tooling) before calling it a
regression.

**The `perf_stat` cross-check is weakest exactly here.** `ipc` is computed over whatever
executed, so a run that went idle yields a diluted, non-comparable value — and both stall
findings are dead on the `amd` generic PMU profile ([../ARCHITECTURE.md](../ARCHITECTURE.md)
§2). Check the registry's `architectures` array before reading a stall finding's silence as
evidence, and compare `mux_counter_schedule_rate` before trusting any PMU delta (grouped is the
default, `src/data_collection.rs:379`).

## Verification

What to verify depends entirely on which branch STEP 2 and STEP 4 landed on, and **in the most
common good outcome there is nothing to verify because there is nothing to fix.** If throughput
held constant and no other state absorbed the CPU, the verification is arithmetic:
CPU-per-unit-work should have fallen by the same ratio as `user`, and the correct deliverable is
a statement that the optimization worked and that aperf's `Poor` score reflects its fixed-load
assumption. Say that plainly rather than inventing an action.

If STEP 1 flagged geometry, re-report both runs with `--time-range 1:` — the finding should
disappear, and if it does, nothing changed. If STEP 1 flagged an invalid run, verification is
confirming the workload started and stayed under load for the whole window; performance
conclusions resume only after that.

For confirmed blocking, apply the fix from STEP 3 and re-record both runs at matched geometry:
`avg(user)` should rise back toward the base value **while throughput rises too**. Watch for the
trap — raising `user` alone is not success. A spin-wait, a busy-poll loop, or a larger thread
pool that thrashes will all raise `user` while delivering the same or less work, which converts
this finding into `Increased User-Space CPU Utilization` without improving anything. Check both
numbers, and for Java confirm the previously-`wall`-heavy stacks shrank. For an external ceiling
or a cgroup quota, the verification is that the ceiling's own counter stops rising — the CPU
metric is downstream evidence, not the target.

## Do not

- **Do not report this as a defect when throughput held constant.** Less CPU for the same
  work is the goal of most optimization work. The `Poor` score reflects the rule's
  fixed-load assumption, not a verdict on your change.
- **Do not use on-CPU profiling to investigate it.** The time of interest is time *not* spent
  on CPU; on-CPU flamegraphs will show you the shrinking remainder, which is the wrong
  question. Use off-CPU profiling.
- **Do not conclude "lock contention" without evidence.** It is the most-cited cause and one
  of several; `idle` ↑ narrows it to off-CPU, and only a profile names the call.
- **Do not compare `user` across different CPU counts or instance types.**
- **Do not read the score as severity** — it is a linear restatement of the delta, except for
  the `user == 0` case which pins at exactly −32.00.
- **Do not ignore the possibility that the base run was the broken one.**
- **Do not recommend `--profile` to investigate blocking on a non-Java workload.** It runs
  `perf record -e cpu-clock` (`src/data/perf_profile.rs:136`), which samples only running
  threads. The user will re-record and still have no off-CPU data.
- **Do not rank this finding against `Increased User-Space CPU Utilization` by score.** This
  rule is capped at `−160` and its mirror is unbounded, so the same run pair scores very
  differently depending on which run is `--base`.
- **Do not read `−32.00` as mild.** It is the `value == 0.0` branch and means `avg(user)` was
  exactly zero — the most severe case on this rule produces one of its weakest scores.
- **Do not read `user` as all application time.** `CpuState::USER` is `/proc/stat` field 0 and
  excludes `nice` (field 1), so a renice moves time out of this metric with no change in work.
- **Do not compare runs recorded at different `--period` values.** The forced-zero first sample
  dilutes the shorter run more, and this rule sits close enough to its threshold that default
  geometry alone can fire it — re-report with `--time-range 1:` first.
- **Do not trust `ipc` or any PMU ratio from a run that went idle.** They are computed over
  whatever executed, so a mostly-idle run yields a diluted value that is not comparable to a
  busy run's.
- **Do not treat "raised `user` back up" as verification.** A spin-wait or an oversized thread
  pool does that while delivering the same work. Throughput must rise with it.

## References

- Upstream guide: `CPU_UTILIZATION_OPTIMIZATION` in
  `src/report_frontend/src/definitions/optimization-guides.ts` — the
  "Lower-than-expected CPU utilization" half names lock contention, I/O bottlenecks and OS
  scheduler issues, and points at off-CPU profiling (which aperf itself collects only for Java).
- Rule definition: `src/analytics/rules/cpu_utilization.rs:44` — `metric: "user"`,
  `Stat::Average`, `Comparator::LessEqual`, `delta_ratio: -0.1`, `abs: false`, score `Poor`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` —
  branch order at `:98`–`:106` (`cur == base` → `0.0` first, then `base == 0.0` → forced `1.0`
  at `:103`), description built at `:121`, early `debug!` return at `:79` when the base run
  lacks the metric.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `value == 0.0`
  branch at `:180` returns `2 × rule_score`; `Score::Poor = -16` at `:149`.
- **On-CPU-only profiling**: `perf record -a -q -g -k 1 -F <freq> -e cpu-clock:pppH`,
  `src/data/perf_profile.rs:126`–`:139`; `raw_perf_on_cpu_profile_path` at `:63` is the only
  profile path in the file.
- **Java off-CPU (wall-clock) profiling**: `PROFILE_METRICS = ["cpu", "alloc", "wall"]`
  (`src/data/java_profile.rs:32`); `launch_asprof` passes `--wall 100ms` at `:81`. Surfaced as
  the `wall` tab (`data-descriptions.ts:4695`).
- `CpuState` enum and `/proc/stat` field mapping: `src/data/cpu_utilization.rs:99` (variants),
  `:112`–`:113` (`USER => 0`, `NICE => 1`).
- Forced-zero first sample: `get_delta_and_set_previous_value` returns `None` on the first
  snapshot (`src/data/common/time_series_data_processor.rs:189`); documented for users at
  `data-descriptions.ts:94`.
- Recording defaults: `--interval 1` (`src/record.rs:37`), `--period 10` (`src/record.rs:47`);
  `interval >= period` is rejected at `src/record.rs:143`, so the minimum sample count is 3.
- `--time-range` is a **report**-time flag (`src/report.rs:245`), so geometry correction needs
  no re-recording.
- PMU counter mode defaults to **grouped** (`src/data_collection.rs:379`);
  `--ungroup-pmu-events` (`src/record.rs:110`) changes multiplexing and `ipc` comparability.
- Graviton scaling note (each vCPU is a physical core): `data-descriptions.ts:105`.
- [Graviton perfrunbook — off-CPU profiling](https://aws.github.io/graviton/perfrunbook/debug_code_perf.html#off-cpu-profiling)
- [Graviton perfrunbook — system load and compute headroom](https://aws.github.io/graviton/perfrunbook/system-load-and-compute-headroom.html)
- [`proc_stat(5)`](https://man7.org/linux/man-pages/man5/proc_stat.5.html)
