---
rule_name: Increased User-Space CPU Utilization
data_type: cpu_utilization
data_key: user
template: time_series_stat_run_comparison
condition: "delta_avg(user) >= 0.1"
base_score: Poor
score_sign: negative
requires_comparison: true
aperf_message: "The code is consuming more CPU time. The results of CPU profiling could help identify hot functions."
source: src/analytics/rules/cpu_utilization.rs:34
---

# Increased User-Space CPU Utilization

## What fired

The **average** of the `user` metric in this run is **at least 10% higher** (relative) than
the same average in the **base run**. `abs` is false, so this rule is strictly
directional — only increases fire it. Decreases are covered by the separate
`Decreased User-Space CPU Utilization` rule.

Requires ≥2 runs. Base score `Poor` (−16).

## Reasoning

`user` is "Percentage of CPU time spent in user mode" (`data-descriptions.ts`), with
`desired: "higher"` — note that the metric's *desired direction is higher*, yet this rule
scores an increase as `Poor`. That is not a contradiction; it reflects two different
questions. For statistical findings, more user-mode time is generally the goal (work being
done in your code rather than the kernel). For this analytical rule, the question is
whether a **controlled A/B comparison** shows the application burning more CPU than the
baseline did.

Time in user mode is time the CPU spent executing application instructions. More of it, at
the same wall-clock scale, means the application executed more work per unit time. That has
exactly two readings, and **the finding cannot distinguish them**:

1. **A regression.** The application does more CPU work to accomplish the *same* result —
   a new inefficient code path, lost vectorization, a hot loop added, a library upgrade
   with worse constant factors, added serialization/encryption/compression, or a cache that
   stopped hitting. This is the case worth fixing.
2. **More throughput.** The application served more requests, so it legitimately used more
   CPU. Nothing is wrong; the higher CPU is the *cost of the extra work delivered*.

Separating these requires normalizing CPU time by work done (requests/sec, ops/sec, bytes
processed) — a quantity **aperf does not know**. Nothing in the aperf report can resolve
this ambiguity on its own. Establishing which case applies is therefore the single most
important step, and it requires information from outside the report.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({value}) is {±pct} {base_run} ({base_value}).
```

The percentage clause comes from `delta_ratio_to_percentage_string`: absolute percentage
plus the word `"greater than"` (this rule only fires on increases, so it is always
`"greater than"`). Example:

```
The average in run_b (62.40) is 24.00% greater than run_a (50.32).
```

Both values are percentages of total CPU time. Recover the delta ratio as
`(value − base_value) / base_value`.

**Five things to know before branching on these numbers:**

1. **The printed percentage is a *relative* delta, not percentage points.** `24.00% greater
   than` at a base of 50.32 is 12.08 percentage points; at a base of 2.0 it is 0.48 points.
   **The same score can mean a trivial or a massive absolute change**, so always read the two
   absolute values, never the percentage alone.
2. **`f64_to_fixed_2` truncates.** A printed `62.40` is anything in `[62.40, 62.41)`. At small
   base values this matters: a base printed as `0.01` could be up to twice its printed value,
   making the computed ratio badly wrong. Prefer `value_from_score` when the base is small.
3. **`user` excludes `nice`.** `CpuState::USER` is `/proc/stat` field 0 and `NICE` is field 1
   (`src/data/cpu_utilization.rs:112`), collected as separate metrics. Renicing a workload
   moves time out of `user` into `nice`, which reads here as a decrease.
4. **`user` is a percentage over all CPUs**, so it is bounded at 100 and its denominator is
   the core count. A different `CPUs` value makes the two percentages incommensurable.
5. **This rule fires per compared run**, so with three runs you can get two findings against
   the same base. They are independent; do not chain them.

Score math — `compute_finding_score(delta_ratio, 0.1, −16)`, `src/analytics/mod.rs:167`.
A firing value is always `≥ 0.1`, so `delta = value/threshold ≥ 1` and the reciprocal branch
is **never** taken. The score is exactly `(delta_ratio / 0.1) × −16` — linear and **unbounded**:

| observed Δ | score | note |
|---|---|---|
| +10% (0.1) | **−16.00** | exactly at threshold; `GreaterEqual`, so it fires |
| +12% (0.12) | **−19.20** | |
| +24% (0.24) | **−38.40** | |
| +50% (0.5) | **−80.00** | |
| +100% (1.0) | **−160.00** | also the value the zero-baseline substitution produces |
| +500% (5.0) | **−800.00** | |
| +9900% (99.0) | **−15,840.00** | e.g. `user` 0.5% → 50% |

Invert it with `delta_ratio = |score| / 16 × 0.1`, or use
`value_from_score(score, 0.1, SCORE["Poor"])` — which is more precise than the truncated text.

**This rule is unbounded while its mirror is not.** `Decreased User-Space CPU Utilization`
cannot exceed a delta of `−1.0` (a percentage cannot fall below zero), so it is capped at
`−160`. This rule has no such cap. **A swap of which run is the base therefore changes the
score dramatically**: `user` 20→40 fires Increased at `−160`, while 40→20 fires Decreased at
`−80`, for the same pair of runs. Never compare the magnitudes of these two findings, and
never infer that an increase is "worse" than a decrease from their scores.

**Zero-baseline trap:** if the base run's `avg(user)` is exactly `0.0`, the template
substitutes a delta ratio of `1.0` (`time_series_stat_run_comparison_rule.rs:100`, documented
as "treat current stat as 100% larger") rather than dividing by zero, producing exactly
`100.00% greater than` and a score of `−160`. A base value of `0` means the base run executed
**no measurable user-space code at all** — a collection failure or a completely idle run, not
a doubling. Note the branch order: `cur_stat == base_stat` is tested first, so if *both* are
zero the rule computes a ratio of `0.0` and does not fire. `base_stat_was_zero()` in
`aperf_desc.py` detects the live case.

## Interpretation

| Observed Δ | With throughput held constant | With throughput also up |
|---|---|---|
| +10–20% | Modest regression; worth a profile diff | Roughly proportional cost — likely fine |
| +20–50% | Real regression; profile and diff hot functions | Check for super-linear cost (contention, GC) |
| >50% | Significant regression, or the workload changed | Verify the two runs ran the same scenario at all |

**Known false positives — check these before calling it a regression:**

- **Higher throughput.** The most common benign explanation. If the load generator drove
  more traffic, or the system under test simply got faster and completed more work, higher
  `user` is the expected consequence. Check `IpExt:InOctets` in `netstat` — if
  `Inconsistent Inbound Network Traffic` also fired, the runs were not given the same
  input and the comparison is not apples-to-apples.
- **Work shifted from kernel to user space.** A change that moves work out of syscalls into
  userspace (io_uring, userspace TLS, batching that reduces syscall count) *increases*
  `user` while *decreasing* `system` — often a net win. Always read `system` alongside.
- **The base run was under-loaded.** If `Underutilized CPU` fired on the base run, its low
  `user` average is the anomaly, and this finding is measuring the base run's defect rather
  than a regression in this one.
- **Different core counts.** `user` is a percentage over all CPUs. If
  `Inconsistent Number of CPUs` fired, the two percentages are over different denominators
  and are not comparable — this finding is then an artifact.
- **Warm-up / JIT differences.** A run that included more startup, class-loading, or JIT
  compilation time skews the average. Check where in the timeline the difference sits.
- **Different run durations.** Averages over different-length windows weight phases
  differently.
- **Frequency/instance differences.** A slower-clocked CPU needs more CPU *time* for the
  same instructions. If the instance types differ, this is expected.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `system` series | `cpu_utilization` | If `system` fell by a comparable amount, work moved kernel→user — likely benign |
| `idle`, `iowait` | `cpu_utilization` | If `idle` fell by the same amount, the machine simply got busier; if `iowait` fell, previously-blocked threads are now working |
| `aggregate` | `cpu_utilization` | If `Consistent CPU Utilization` also fired, total CPU is unchanged and this is purely a mode shift, not extra work |
| `ipc` | `perf_stat` | **The key discriminator for efficiency.** Higher `user` with *lower* `ipc` ⇒ same/more time spent less efficiently (stalling). Higher `user` with stable `ipc` ⇒ genuinely more instructions executed |
| `stall-frontend-pkc`, `stall-backend-pkc` | `perf_stat` | Localizes an efficiency loss to fetch vs execute |
| `data-l1-mpki`, `l2-mpki`, `l3-mpki` | `perf_stat` | A new memory-bound hot path |
| `branch-mpki` | `perf_stat` | New unpredictable control flow |
| On-CPU profile / flamegraph | `perf_profile` / `java_profile` | **The decisive evidence** — names the functions that grew. Requires `--profile` (or `--profile-java`). **`perf_profile` has no analytical rules** — read it manually |
| `IpExt:InOctets`, `IpExt:OutOctets` | `netstat` | Whether the input load was actually the same |
| `user_space_time`, `kernel_space_time`, `number_threads` | `processes` | Attributes the increase to a specific process, and rules out "more threads" as the cause. **No analytical rules — read manually** |
| `pgminorfault`, `pgfault` | `vmstat` | Increased allocation churn showing up as user-mode CPU |
| `CPUs` | `systeminfo` | Denominator check — must match for the percentages to be comparable |

## Guidance

Ordered. Steps 1–2 gate everything else; do not profile before establishing them.

1. **Normalize by work done. This is the crux.** Obtain throughput for both runs from
   outside aperf (load generator report, application metrics, request logs). Compute
   CPU-per-unit-work for each run:
   - CPU/work **unchanged** ⇒ higher throughput, not a regression. Report it as such and
     stop.
   - CPU/work **increased** ⇒ genuine efficiency regression. Proceed.
   - Throughput **unknown** ⇒ state that explicitly as a limitation of the conclusion; do
     not assert a regression you cannot support.

2. **Validate that the comparison is legitimate.** Check `Inconsistent Number of CPUs` and
   `Kernel Version Mismatch` (`systeminfo`), `Inconsistent Physical Memory` (`meminfo`),
   and `Inconsistent Inbound Network Traffic` (`netstat`). Any of these firing undermines
   the comparison — resolve or explicitly discount them first.

3. **Read `system` and `idle` in the same window.** Classify the shape of the change:
   - `user` ↑ and `system` ↓, total flat ⇒ kernel→user shift, frequently an improvement.
   - `user` ↑ and `idle` ↓ ⇒ the machine got busier; tie back to step 1.
   - `user` ↑ and `iowait` ↓ ⇒ threads that used to block are now running; often an
     improvement in a storage-bound workload.

4. **Decide efficiency vs volume using `ipc`.** If `ipc` dropped (see
   `Reduced Instructions per Cycle`), the CPU is executing *less efficiently* — pivot to
   the stall findings and the cache/TLB family. If `ipc` held steady, the application
   genuinely executed more instructions — pivot to profiling.

5. **Profile and diff.** With `--profile` data, compare flamegraphs between the two runs and
   identify which stacks grew. This is what aperf's own message points at. If profiling data
   is absent, recommend re-recording both runs with `--profile` (and `--profile-java` for
   JVM workloads) — without it, attribution is guesswork.

6. **Attribute to a process.** Use `processes` (`user_space_time` per process) to confirm
   the increase belongs to the application under test and not to a co-tenant agent, sidecar,
   or monitoring daemon.

## Priority and execution risk

**Priority: P2 — Investigate** by default. The finding is reliable about *what* changed and
silent about *whether it is bad*, because the same signal is produced by a regression and by
higher throughput. It rises to **P1 — Act now** once CPU-per-unit-work is confirmed to have
increased — that is a quantified efficiency regression with a named cause path. It drops to
**P4 — Informational** when throughput rose proportionally, and to **P3 — Context** when
`system` fell by a comparable amount, since a kernel→user shift at constant total is often an
improvement.

**Execution risk: R0 — Read-only** to diagnose: every discriminating step reads existing data
or re-records. Acting spans the range and is set by the *cause*, not by this finding —
**R2** to change a runtime flag or thread-pool size, **R3** to rebuild with restored
vectorization or a reverted library, **R5** where the remedy trades correctness or semantics
(disabling a checksum, changing a crypto suite). **Do not inherit the R0 of the investigation
into the remediation.**

**The score is a linear restatement of the delta ratio and is unbounded.** It is
`(delta_ratio / 0.1) × −16`, so it carries no severity: a `−15,840` finding on a `user`
average that moved 0.5% → 50% is arithmetically extreme and may be operationally trivial.
Worse, it is **not comparable to its mirror rule**, which is capped at `−160` — so swapping
which run is the base changes the apparent magnitude several-fold for the same pair.

**The comparator is `GreaterEqual` with `abs: false`**, so exactly +10.0% fires, and only
increases fire. The sign is preserved deliberately: this rule and
`Decreased User-Space CPU Utilization` partition the two directions and never both fire on the
same run pair.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `avg(user)` in this run is at least 10% **greater** than in the base run,
relatively. Direction is certain; cause is not.

```
STEP 0 — Are the validity gates clear?
  IF `Inconsistent Number of CPUs` fired
  THEN → STOP. `user` is a percentage over all CPUs, so the two values have
         different denominators and the delta is an artifact of normalization
         (P0, R4)
  IF `Inconsistent Physical Memory` or `Kernel Version Mismatch` fired
  THEN → different machines or kernels; a user-space CPU delta is expected and
         not attributable to the change under test (P0, R4)
       → verify: re-record both runs on matched hosts and kernels; if the finding
         survives a matched pair, it is real
  IF `JVM Version Comparison` fired and the workload is Java
  THEN → JIT and GC defaults changed with the JVM, which moves `user` on its own
         (P0, R4). See ../java_profile/jvm-version-comparison.md
       → verify: re-record with the SAME JVM build on both sides, or pin the
         changed defaults explicitly, before attributing the delta to code
  ELSE continue.

STEP 1 — Recover the values, then check the RECORDING GEOMETRY.
  Parse: The {stat} in {run} ({v}) is {pct}% greater than {base} ({bv}).
  Prefer value_from_score(score, 0.1, -16) — the text is truncated.

  Recover each run's sample count:  n = 100 / (100 - (avg(total) + avg(idle)))
  (see consistent-cpu-utilization.md for the derivation)

  IF the base run's n <= 10 (base --period <= 9s at --interval 1) AND the compared
     run's n is larger
  THEN → GEOMETRY ALONE CAN PRODUCE THIS FINDING. The forced-zero first sample
         dilutes a short run more, so a longer compared run reads higher with
         IDENTICAL true utilization (P1, R0)
       → the spurious delta approaches 1/(n_base - 1):
           base n=3  (period 2s)  -> up to +50.0%
           base n=6  (period 5s)  -> up to +20.0%
           base n=10 (period 9s)  -> up to +11.1%
           base n=11 (period 10s) -> up to  +9.999%  <- CANNOT reach +10%
       → so at the DEFAULT --period 10 or longer, geometry alone can NEVER fire
         this rule. Only a base run shorter than the default is at risk
       → verify: re-report BOTH runs with `--time-range 1:`. If the finding
         disappears, it was pure geometry and nothing changed
  IF the base value is 0.00 (description reads exactly `100.00% greater than`)
  THEN → NOT a doubling. The template substituted a delta ratio of 1.0 because the
         base stat was zero: the base run recorded NO user-space CPU at all
         (P1, R0)
       → verify: check whether the base run has any `cpu_utilization` data; a true
         zero avg(user) means an idle machine or failed collection
       → treat as a collection defect, not a regression
  IF `avg(user)` in BOTH runs is under ~5%
  THEN → NOISE. The rule is a pure ratio test with no absolute floor
         (time_series_stat_run_comparison_rule.rs:97-110), so at near-zero
         utilization a fraction of a percentage point yields a large ratio and a
         large score. There is no workload here to have regressed (P3, R0)
       → verify: check `idle`. ~90% or higher in BOTH runs means the machine was
         doing nothing in both, and `Underutilized CPU` fires on both — that is
         the real finding
       → the Decreased mirror was observed doing exactly this on this host: two
         IDLE runs 16 s apart scored -72.98 on a 0.43 percentage-point move
         (0.94 -> 0.51) at ~90% idle. This rule is symmetric and equally exposed
       → do NOT proceed to normalize by work done. There is no work to normalize by
  ELSE continue with the recovered ratio.

STEP 2 — MANDATORY manual check: normalize by WORK DONE. This is the crux.
  aperf does not know your throughput. Nothing in the report can resolve this.
  Obtain requests/sec, ops/sec, or bytes processed for BOTH runs.

  IF CPU-per-unit-work is UNCHANGED
  THEN → NOT a regression. The run did more work and paid proportionally for it.
         Report it as throughput, and stop (P4, R0)
       → verify: the ratio of throughputs should match the ratio of avg(user)
         within measurement noise
  IF CPU-per-unit-work INCREASED
  THEN → genuine efficiency regression; continue to STEP 3 (P1, R0)
  IF throughput is UNKNOWN
  THEN → state that as a limitation of the conclusion. Do NOT assert a regression
         you cannot support (P2, R0)
       → the rest of the tree still narrows the mechanism, but cannot establish
         that anything got worse

STEP 3 — Read the SHAPE across the other CPU states. This classifies the change.
  Read `system`, `idle`, `iowait`, `nice`, `steal` for the same window.

  IF `system` FELL by a comparable amount and `Consistent CPU Utilization` fired
  THEN → a kernel->user SHIFT at constant total, frequently an IMPROVEMENT:
         io_uring, userspace TLS, batching that cut syscall count (P3, R0)
       → verify: `system` should fall by roughly the percentage points `user` rose;
         total CPU volume unchanged
       → do not remediate this without throughput evidence that it got worse
  IF `nice` FELL while `user` rose
  THEN → a PRIORITY change, not a workload change. `user` excludes `nice`, so
         un-renicing a process moves time between the two (P2, R0)
       → verify: `user` + `nice` should be roughly unchanged across the runs
  IF `idle` FELL by a comparable amount
  THEN → the machine simply got busier; tie back to STEP 2's throughput (P2, R0)
  IF `iowait` FELL
  THEN → threads that used to block are now running. In a storage-bound workload
         this is usually an IMPROVEMENT (P3, R0)
       → verify: `Increased I/O Wait Time` should NOT have fired, and diskstats
         time_reading/time_writing should have fallen
  IF `steal` differs between runs
  THEN → the hypervisor's share changed, which moves every other percentage. On a
         T-family instance suspect credit exhaustion (P1, R4)
       → verify: CPU credit balance in CloudWatch; aperf does not collect it

STEP 4 — Efficiency or volume? `ipc` is the discriminator.
  IF `ipc` DROPPED (or `Reduced Instructions per Cycle` fired)
  THEN → the CPU is executing LESS EFFICIENTLY: same or more time, fewer
         instructions retired per cycle. This is a stall problem, not a code-volume
         problem (P1, R0)
       → route to the perf_stat stall and memory-hierarchy playbooks; the
         `*-mpki` family localizes it
       → CAUTION: if `Underutilized CPU` fired on either run, the PMU ratios are
         diluted and low-confidence
  IF `ipc` held STEADY
  THEN → the application genuinely executed MORE INSTRUCTIONS. This is a code-path
         change and profiling is the decisive evidence (P1, R0)
       → continue to STEP 5
  IF `perf_stat` data is absent
  THEN → the discriminator is unavailable. Re-record with PMU collection before
         concluding efficiency vs volume (P2, R0)

STEP 5 — Attribute it. Profiling is the only decisive evidence.
  IF on-CPU profile data exists for BOTH runs
  THEN → diff the flamegraphs and identify which stacks GREW. This is what aperf's
         own message points at (P1, R0)
       → verify: the growth in the named stacks should account for the observed
         percentage-point change; if it does not, the cause is elsewhere
       → then attribute to a process with `processes` (`user_space_time`) to rule
         out a co-tenant agent, sidecar, or monitoring daemon
       → NOTE `perf_profile` has NO analytical rules — read it manually
  IF profile data is ABSENT
  THEN → attribution is guesswork. Recommend re-recording BOTH runs with
         `--profile` (and `--profile-java` for JVM workloads) (P2, R0)
       → this requires RECORD-time flags; it cannot be recovered at report time
  IF the profile names a framework rather than application code
  THEN → suspect an architecture-specific build variant (see below) (P2, R3)
       → verify: rebuild with the host-tuned variant; `user` should fall at
         unchanged throughput

STEP 6 — What survives?
  VALID      : configuration findings (THP state, ENA Express, tiered compilation,
               PREEMPT_LAZY) — independent of load
  CAUTION    : `perf_stat` efficiency metrics — meaningful only if STEP 0's gates
               are clear AND neither run fired `Underutilized CPU`
  CONFOUNDED : any conclusion about the CHANGE UNDER TEST, if STEP 2 could not
               establish throughput. The finding then describes a difference of
               unknown sign
  VOID       : the claim "this run is slower" — CPU time is not latency, and this
               rule says nothing about either latency or throughput

INSUFFICIENT DATA
  IF only ONE run is present
  THEN → the rule requires a base run; NO finding was produced. Absence proves
         nothing (P2, R0)
  IF the BASE run lacks the `user` metric
  THEN → the rule returned early with a `debug!` and produced NO finding for ANY
         run (P2, R0)
  IF the finding is absent but you expected it
  THEN → check the geometry test in STEP 1 in reverse: a base run recorded LONGER
         than the compared run biases the delta downward and can mask a real
         increase of up to ~9% at default geometry (P2, R0)
```

## Runtime-specific consequences

`user` time is where application code runs, so every runtime reaches this finding — but each
has a characteristic way of raising `user` without the application changing. Those are the
false positives worth knowing, because they look exactly like a regression.

| Runtime | Characteristic cause of a `user` increase that is NOT an application regression | What to check |
|---|---|---|
| **.NET** | Tiered compilation: JIT work is `user` time, so a shorter run or a cold start weights tier-0 and the JIT threads heavily. A GC mode change (Workstation → Server, `DOTNET_gcServer=1`) moves collection work into more `user` threads. ReadyToRun or a changed `DOTNET_TieredPGO` setting shifts the same work between JIT and steady state | Whether the run was long enough to reach steady state; `DOTNET_*` env differences. Re-record with a longer `--period` before profiling |
| **Python** | A pure-Python fallback replacing a native path is the classic case: the same work moves from a C extension into interpreted bytecode, multiplying `user` several-fold at identical throughput. GIL contention, by contrast, shows up in `system` (futex waits), not here | Whether the hot path is still using its native extension (a version or wheel change is enough). Check `system` to separate GIL contention from interpreted work |
| **Java** | The largest set of benign causes. JIT compiler threads consume `user` early in a run; a GC change (Parallel → G1 → ZGC) redistributes work between application and collector threads; loss of intrinsics or a deoptimization storm raises `user` with no source change | `jvmArguments` in the profile metadata; `JVM Version Comparison`. Use `--profile-java`, since a JVM stack is unreadable in a plain `perf` profile |
| **Perl** | Almost always genuine: no JIT, no adaptive runtime, so `user` tracks work done fairly directly. The usual non-regression cause is a module upgrade replacing an XS (C) implementation with a pure-Perl one — the same substitution as Python's | Whether XS backends are still selected (e.g. `JSON::XS` vs `JSON::PP`). `perl -V` build options matter more than any runtime flag |

**The unknown-runtime case is the default.** Runtime is inferred from `processes` metric names
([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3), which is a heuristic. When it cannot be
identified, STEP 3's `system`/`nice` decomposition and STEP 4's `ipc` test are both
runtime-independent and answer the same question.

## Architecture-specific considerations

The metric is `/proc/stat`-derived, so this finding fires on every architecture and means the
same thing everywhere. Architecture determines *what a `user` increase implies* and what
remedy applies.

**A `user` increase across an architecture change is expected, not a regression.** Different
ISAs need different amounts of CPU *time* for the same logical work: vector width differs
(AVX-512 vs NEON/SVE), atomics differ (`-moutline-atomics` and LSE on arm64), and clock speeds
differ. aperf has **no architecture field**, and no rule compares `Instance Type`
([../GATES.md](../GATES.md)) — so an Intel→Graviton comparison with matched `CPUs` and
`MemTotal` fires **no gate at all** while this finding reports a large increase. Confirm
`Instance Type` manually before attributing a `user` delta to code.

| Architecture | What a `user` increase most often means here | Remedy class |
|---|---|---|
| **Intel** | Loss of AVX-512 or AVX2 codegen (a build flag change, or a library that dropped a dispatch path) multiplies instruction count for identical work. SMT siblings make the percentage non-linear near saturation | R3 — rebuild with the vector path restored; confirm with `ipc` roughly flat |
| **AMD** | The same vectorization story, plus generic-build penalties: a framework built for the Intel path runs correct-but-slow code (`microsoft/onnxruntime` vs `amd/ZenDNN-onnxruntime`). Both stall findings are dead on the `amd` generic PMU profile, so STEP 4 may be unavailable | R3 — switch to the vendor-tuned build; do not read STEP 4's silence as "no stall" |
| **arm64 / Graviton** | Missing `-mcpu=neoverse-*` tuning, or atomics falling back to LL/SC instead of LSE (`-moutline-atomics`). Each vCPU is a physical core, so the percentage scales closer to linearly (`data-descriptions.ts:105`) | R3 — rebuild with host tuning and LSE atomics enabled |

**SMT changes the meaning of the percentage.** On Intel and AMD with SMT, two vCPUs share one
physical core, so `user` time on a sibling competes for the same execution units. A `user`
increase from 45% to 55% may cross physical-core saturation and cost far more than the 10
points suggest; the same increase on arm64, where each vCPU is a physical core, is closer to
linear (`data-descriptions.ts:105`). aperf does not report `threads-per-core` — this is a
manual check.

**Architecture-specific build variants are the highest-value R3 cause.** When STEP 5's profile
names a framework rather than application code, a generic build running on tuned hardware is
the usual answer — the exemplar being `microsoft/onnxruntime` versus
`amd/ZenDNN-onnxruntime`, or an arm64 build compiled without `-mcpu=neoverse-*`. A generic
build executes more instructions for identical work, which lands squarely in `user`. This is
invisible to every metric aperf collects: the only signal is `user` up, `ipc` roughly flat, and
the profile pointing at library internals.

**The `ipc` discriminator in STEP 4 is itself architecture-dependent.** `ipc` is derived from
different counters per PMU profile, and both stall findings are dead on the `amd` generic
profile ([../ARCHITECTURE.md](../ARCHITECTURE.md) §2) — so STEP 4 can be unavailable rather
than negative. Check the registry's `architectures` array before reading a stall finding's
silence as evidence. Counter mode matters too: grouped is the default
(`src/data_collection.rs:379`), and a run recorded with `--ungroup-pmu-events` multiplexes
differently, so compare `mux_counter_schedule_rate` in both runs before trusting an `ipc` delta.

## Verification

Verification depends on which cause STEP 2 and STEP 4 established, and one case needs no
system change at all. If STEP 1 flagged a geometry mismatch, re-report both runs with
`--time-range 1:`: the finding should disappear, and if it does, nothing changed. If throughput
rose proportionally, the verification is arithmetic rather than a re-run — CPU-per-unit-work
should be equal within noise, and no action follows. For a confirmed efficiency regression,
apply the fix from STEP 4 or STEP 5 and re-record both runs at matched geometry: `avg(user)`
should fall toward the base value and the previously-grown stacks should shrink in the
flamegraph. If `avg(user)` falls but throughput falls with it, the "fix" removed work rather
than cost. For a kernel→user shift, there is nothing to verify because there is nothing wrong —
say so explicitly rather than manufacturing a check.

## Do not

- **Do not call this a regression without normalizing by throughput.** More CPU for more
  work is not a defect. This is the single most common misreading of this finding.
- **Do not act on it in isolation from `system`.** A kernel→user shift can fire this rule
  while representing a genuine improvement.
- **Do not compare `user` percentages across different CPU counts or instance types.**
- **Do not read the score as severity.** It is a linear restatement of the delta ratio.
- **Do not trust a `100.00% greater than` reading with a base value of 0** — that is the
  template's zero-baseline substitution, not a measurement.
- **Do not skip straight to optimizing the top flamegraph frame.** Confirm it actually grew
  *between the runs*; the hottest function is often hot in both.
- **Do not compare this score against `Decreased User-Space CPU Utilization`.** Increased is
  unbounded and Decreased is capped at `−160`, so the two are on different scales. Reversing
  which run is `--base` changes the magnitude several-fold for the same pair of runs.
- **Do not conclude "the run got slower."** `user` is CPU time, not wall-clock latency and not
  throughput. A run can raise `user` and finish sooner.
- **Do not read `user` as "all application time."** `CpuState::USER` is `/proc/stat` field 0
  and excludes `nice` (field 1), so a renice moves time out of this metric with no change in
  work done.
- **Do not compare runs recorded at different `--period` values without re-reporting with
  `--time-range 1:`.** The forced-zero first sample dilutes a short base run more, biasing the
  delta upward by up to `1/(n_base − 1)`.
- **Do not treat the absence of this finding as proof that `user` did not rise.** A base run
  recorded longer than the compared run biases the delta downward and can mask a real increase
  of up to roughly 9% at default geometry.
- **Do not conclude "efficiency regressed" from a missing `ipc` reading.** Both stall findings
  are dead on the `amd` generic PMU profile, so STEP 4 can be unavailable rather than negative.

## References

- Upstream guide: `CPU_UTILIZATION_OPTIMIZATION` in
  `src/report_frontend/src/definitions/optimization-guides.ts` — the
  "Higher-than-expected CPU utilization" half, including profiling prerequisites
  (`kernel.kptr_restrict=0`, `-g -fno-omit-frame-pointer`, async-profiler for Java,
  `--perf-basic-prof` for NodeJS).
- Rule definition: `src/analytics/rules/cpu_utilization.rs` — `user` comparison rule,
  threshold `0.1`, `Comparator::GreaterEqual`, `abs: false`, base score `Poor` (−16).
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` —
  branch order at `:98`–`:106` (`cur == base` → `0.0` first, then `base == 0.0` → forced
  `1.0` at `:103`), description built at `:121`, early `debug!` return when the base run
  lacks the metric.
- `CpuState` enum and `/proc/stat` field mapping: `src/data/cpu_utilization.rs:99` (variants)
  and `:110`–`:117` (`get_cpu_time` indices — `USER => 0`, `NICE => 1`).
- Total-utilization derivation `(Σstate − idle)/Σstate × 100`:
  `src/data/cpu_utilization.rs:216`; the `total` series is registered as the aggregate at `:227`.
- Forced-zero first sample: `get_delta_and_set_previous_value` returns `None` on the first
  snapshot (`src/data/common/time_series_data_processor.rs:189`); the stored `0.0` is included in the
  average unless `--time-range` excludes it.
- Recording defaults: `--interval 1` (`src/record.rs:37`), `--period 10` (`src/record.rs:47`),
  collection loop `while current_time <= end_time` (`src/data_collection.rs:146`) → ~11 samples.
- `--time-range` is a **report**-time flag (`src/report.rs:245`), so geometry correction needs
  no re-recording.
- PMU counter mode defaults to **grouped**: `src/data_collection.rs:379`
  (`--ungroup-pmu-events` changes multiplexing and therefore `ipc` comparability).
- Value formatting: `f64_to_fixed_2` **truncates** (`src/computations/mod.rs:138`);
  `delta_ratio_to_percentage_string` (`:162`) emits an absolute percentage plus a signed
  relation word.
- Graviton scaling note (each vCPU is a physical core):
  `src/report_frontend/src/definitions/data-descriptions.ts:105`; forced-zero first sample
  documented at `:94`.
- [Graviton perfrunbook — on-CPU profiling](https://aws.github.io/graviton/perfrunbook/debug_code_perf.html#on-cpu-profiling)
- [Graviton perfrunbook — check CPU usage](https://aws.github.io/graviton/perfrunbook/debug_system_perf.html#check-cpu-usage)
- [`proc_stat(5)`](https://man7.org/linux/man-pages/man5/proc_stat.5.html)
- [.NET tiered compilation](https://learn.microsoft.com/dotnet/core/runtime-config/compilation)
