---
rule_name: Increased I/O Wait Time
data_type: cpu_utilization
data_key: iowait
template: time_series_stat_run_comparison
condition: "delta_avg(iowait) >= 0.1"
base_score: Poor
score_sign: negative
requires_comparison: true
aperf_message: "Higher iowait time indicates a bottleneck in disk operations. If the system uses an NFS, consider expanding the provision or switching to local storage."
source: src/analytics/rules/cpu_utilization.rs:54
---

# Increased I/O Wait Time

## What fired

The **average** of the `iowait` metric in this run is **at least 10% higher** (relative) than
the same average in the **base run**. Directional (`abs: false`) — only increases fire.

Requires ≥2 runs. Base score `Poor` (−16).

**Note the threshold is relative, not absolute.** A run whose `iowait` went from 0.10% to
0.12% fires this rule at +20%, identically to one that went from 20% to 24%. The percentage
in the description is a *change in a percentage*, and the absolute values matter far more
than the delta. Read them first.

## Reasoning

`iowait` is "Percentage of CPU time spent waiting for I/O operations to complete"
(`data-descriptions.ts`, `desired: "lower"`). It comes from `/proc/stat`, and it counts time
a CPU was **idle while at least one I/O request was outstanding**.

That definition is the source of nearly every misreading of this metric, so it is worth
stating the traps explicitly:

1. **`iowait` is a percentage of CPU time, not a measure of I/O load.** On a 64-vCPU
   instance, one thread fully blocked on storage contributes at most ~1.6% aggregate
   `iowait`, even while that thread is completely stalled. **A small absolute `iowait` can
   coexist with severe storage saturation.**
2. **`iowait` can rise without I/O getting worse.** It is idle time. If the CPU-side work
   got *faster* (a code optimization, a faster instance) while I/O stayed constant, the CPU
   now spends a larger *share* of its time waiting — `iowait` rises as a direct consequence
   of an improvement.
3. **`iowait` can fall while storage gets worse.** If the workload becomes more CPU-bound,
   or spawns more busy threads, the same absolute I/O wait becomes a smaller share.
4. **`iowait` is not exclusively disk.** Any blocking I/O counts — NFS and other network
   filesystems in particular, which is why aperf's own message calls out NFS. A network
   filesystem stall looks identical to a local disk stall in this metric.
5. **It excludes non-`iowait` blocking.** Time blocked on a socket, a lock, or a sleep is
   `idle`, not `iowait`. A low `iowait` does not mean threads are not blocked.

Because of (1) and (2), **`iowait` is a hint to go look at storage, not evidence about
storage.** The authoritative data is in `diskstats` — which has **no analytical rules at
all**, so aperf will never raise a finding about the underlying device no matter how
saturated it is. Reading `diskstats` manually is mandatory for this finding.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({value}) is {±pct} {base_run} ({base_value}).
```

`delta_ratio_to_percentage_string` gives the **absolute** percentage plus `"greater than"`:

```
The average in run_b (6.40) is 35.00% greater than run_a (4.74).
```

`6.40` and `4.74` are `iowait` as a percentage of CPU time. `35.00%` is the *relative*
change between them. **Both numbers matter and they mean different things** — quote the
absolute values, not just the delta, in any report.

Score math — `compute_finding_score(delta_ratio, 0.1, −16)`:

| observed Δ | score |
|---|---|
| +12% (0.12) | `(0.12/0.1) × −16` = **−19.20** |
| +35% (0.35) | `(0.35/0.1) × −16` = **−56.00** |
| +100% (1.0) | `(1.0/0.1) × −16` = **−160.00** |

`delta_ratio = |score| / 16 × 0.1`.

**Zero-baseline trap — acute for this metric.** `iowait` is very often exactly `0.00` in the
base run. When the base stat is `0.0`, the template substitutes a delta ratio of `1.0`
instead of dividing by zero, producing a fixed score of `−160.00` and a description reading
`100.00% greater than` with base value `0`. That happens whether the new value is `0.01%` or
`40%`. **A score of exactly `−160.00` with base `0` carries no magnitude information at
all** — read the absolute current value.

## Interpretation

Judge the **absolute** value first, then the delta:

| avg(iowait) in this run | Reading |
|---|---|
| < 1% | Almost certainly immaterial regardless of the delta. Note and move on unless the instance has few vCPUs |
| 1–5% | Worth checking `diskstats`; may be normal for a storage-touching workload |
| 5–20% | Real storage involvement; investigate device latency and queueing |
| > 20% | Storage is very likely the dominant bottleneck |

Then scale by vCPU count: on a large instance, even 5% aggregate `iowait` can represent
several fully-blocked threads. Per-CPU `iowait` series are more informative than the
aggregate here.

**Known false positives — check these before recommending storage changes:**

- **Zero baseline.** As above: base `0.00` → fixed `+100%` / `−160.00`. Extremely common and
  usually immaterial. Check the absolute value before anything else.
- **Trivial absolute values.** 0.10% → 0.13% fires the rule. This is noise.
- **The CPU side got faster.** A genuine CPU-side optimization raises `iowait`'s *share*
  without changing I/O at all. If `user` fell while `iowait` rose and throughput held or
  improved, this is a success, not a regression.
- **Page-cache cold start.** A run whose cache was cold (fresh instance, dropped caches,
  first run after boot) does real disk I/O that a warm run does not. Compare where in the
  timeline the `iowait` sits — front-loaded `iowait` is a warm-up artifact.
- **Different instance storage.** EBS vs local NVMe ("d." instances), or different EBS
  volume types/sizes, change `iowait` fundamentally. Confirm the storage configuration
  matched.
- **Different core counts.** If `Inconsistent Number of CPUs` fired, the percentages are over
  different denominators and are not comparable.
- **Logging or profiling overhead.** Enabling `--profile`, debug logging, or an extra agent
  in one run adds writes that the other run did not perform.
- **Co-tenant EBS contention.** On shared volumes or burst-credit-limited volumes, the
  neighbour's I/O affects yours.

## Corroborating data

`iowait` on its own cannot tell you whether storage is slow, busy, or merely more visible.
These can:

| Check | Data type | What it tells you |
|---|---|---|
| `time_reading`, `time_writing` | `diskstats` | **Primary evidence.** Time spent servicing reads/writes — rising values with flat request counts ⇒ the device got slower |
| `reads`, `writes`, `sectors_read`, `sectors_written` | `diskstats` | Whether the *volume* of I/O changed (workload did more I/O) vs the device got slower for the same I/O |
| `in_progress`, `weighted_time_in_progress` | `diskstats` | Queue depth and queue-weighted service time — the clearest saturation signal |
| `merged`, `writes_merged` | `diskstats` | I/O pattern change (sequential vs random) |
| `flushes`, `time_flushing` | `diskstats` | fsync/barrier pressure — often the real cause in database workloads |
| **All of the above have NO analytical rules** | `diskstats` | aperf will *never* raise a finding here. Manual inspection is mandatory |
| `pgmajfault` | `vmstat` | Major faults are disk I/O. If `Major Page Faults Detected` or `Increased Major Page Faults` also fired, paging may be the I/O source rather than application reads |
| `pswpin`, `pswpout` | `vmstat` | Swapping — a specific and severe cause of `iowait` |
| `pgpgin`, `pgpgout` | `vmstat` | Total pages in/out from block devices |
| `MemAvailable`, `Cached`, `SwapFree`, `Dirty` | `meminfo` | Shrinking page cache ⇒ more physical reads. Rising `Dirty` ⇒ writeback pressure |
| `idle`, `user`, `system` | `cpu_utilization` | Where the time came from. `user` ↓ + `iowait` ↑ ⇒ threads now blocking; `user` flat + `idle` ↓ + `iowait` ↑ ⇒ new I/O added |
| Per-CPU `iowait` | `cpu_utilization` | Concentrated on a few CPUs ⇒ a few blocked threads; spread evenly ⇒ system-wide storage pressure |
| Off-CPU evidence | `java_profile` (`wall`) **only** | Names the call stacks blocking on I/O — for Java, via `--profile-java` (async-profiler `--wall 100ms`). **`--profile` collects on-CPU only** (`perf record -e cpu-clock`), which is blind to a thread blocked on I/O; for other runtimes gather this out of band (`biosnoop`, `offcputime-bpfcc`). **No analytical rules** |
| `user_space_time`, `kernel_space_time` per process | `processes` | Attributes the I/O to a process. **No analytical rules — read manually** |
| `bw_in_allowance_exceeded`, `bw_out_allowance_exceeded` | `ena_stat` | For **NFS/EFS/network storage**, the network path may be the real ceiling — this is the link aperf's NFS advice implies |
| `IpExt:InOctets` / `IpExt:OutOctets` | `netstat` | Network-filesystem traffic volume |

## Guidance

Ordered. Steps 1–2 exist to stop you from acting on noise, which is the dominant outcome for
this rule.

1. **Read the absolute values before the delta.** From the description, take this run's
   `avg(iowait)` and the base run's. If this run is below ~1%, and especially if the base was
   `0.00` (score exactly `−160.00`), classify the finding as immaterial and say so
   explicitly — do not investigate storage on that basis alone. Scale the judgement by vCPU
   count.

2. **Rule out "the CPU got faster".** Compare `user` and `aggregate`. If CPU-side work
   dropped while throughput held or improved, the `iowait` share rose *because of* the
   improvement. Report it that way; there is no storage regression to fix.

3. **Go to `diskstats` — this is the mandatory step.** aperf raises no findings there, so
   nothing will prompt you. Determine which of the two cases you are in:
   - **More I/O requested**: `reads`/`writes`/`sectors_*` up. The workload changed. Find out
     why (cold cache, more data, less caching, different query plan).
   - **Same I/O, slower service**: request counts flat but `time_reading`/`time_writing` and
     `in_progress` up. The device or its provisioning is the constraint.
   Do this per device — a single hot volume is common.

4. **Rule out paging as the I/O source.** Check `pgmajfault` (`vmstat`) and `pswpin` /
   `pswpout`. If major faults or swap activity rose, the fix is memory-side (see
   `Major Page Faults Detected` and `Reduced Memory Availability`), not storage-side.
   Cross-check `MemAvailable` and `Cached` in `meminfo`: a shrunken page cache converts
   previously-cached reads into physical I/O.

5. **Establish where in the run it happened.** Plot the `iowait` series. Front-loaded
   `iowait` is warm-up/cold-cache; sustained `iowait` is a steady-state constraint; spiky
   `iowait` suggests checkpoints, compactions, log rotation, or GC.

6. **Identify the blocking caller.** For Java, `--profile-java`'s `wall` heatmap names the
   stacks waiting on I/O — diff it against `cpu`. For every other runtime aperf cannot do
   this: `--profile` is on-CPU only and a thread blocked on I/O contributes no samples, so
   gather stacks out of band (`biosnoop`, `biotop`, `offcputime-bpfcc`). `processes`
   (`kernel_space_time`) narrows *which* process in either case.

7. **For network filesystems, check the network path too.** If the workload uses NFS/EFS —
   the case aperf's own message calls out — inspect `ena_stat` allowance metrics and
   `netstat` octets. A network bandwidth ceiling presents as `iowait`, and scaling storage
   IOPS will not help.

8. **Only then remediate**, matched to the cause established above: provision more EBS IOPS
   or throughput, move to an instance type with local NVMe storage (the `d.` families), size
   the page cache / instance memory to keep the working set resident, batch or coalesce
   writes, reduce fsync frequency, or expand the NFS provisioning per aperf's advice.

## Priority and execution risk

**Priority: P3 — Context** by default, which is lower than most negative findings, because the
dominant outcome for this rule is noise: the base run's `iowait` is very often exactly `0.00`,
which pins the score at `−160.00` regardless of magnitude, and a relative threshold on a metric
that routinely sits below 1% fires on rounding. It rises to **P1 — Act now** when this run's
absolute `avg(iowait)` is material (roughly >5%, or >1% on a small instance) **and** `diskstats`
confirms rising service time at flat request counts — that is a device or provisioning
constraint with a concrete remedy. It rises to **P0 — Blocked** when `pswpin`/`pswpout` rose,
because swapping invalidates every other performance conclusion in the run. It drops to
**P4 — Informational** when the CPU side got faster at held throughput, where the rising
`iowait` *share* is a consequence of the improvement.

**Execution risk: R0 — Read-only** to diagnose — `diskstats`, `vmstat`, and `meminfo` are all
already in the run. Acting spans **R1** (raise EBS IOPS or throughput on a `gp3` volume — an
online change, no restart), **R2** (change an fsync or writeback setting, resize the page cache
budget), **R3** (batch or coalesce writes in the application), **R4** (migrate to a local-NVMe
instance family, expand NFS provisioning, change volume type — new infrastructure), and **R5**
where the remedy trades durability for throughput. **Reducing fsync frequency is R5, not R2**:
it changes what survives a crash. Never present it as a tuning knob.

**The score carries less information here than on any other comparison rule.** Two separate
effects flatten it: the zero-baseline substitution pins it at exactly `−160.00`, and the
relative threshold means a `0.10% → 0.13%` change and a `20% → 26%` change score identically at
`−48.00`. **Rank this finding by its absolute value, never by its score.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `avg(iowait)` in this run is at least 10% **greater** than in the base run,
relatively. STEP 1 exists to discard noise, which is the most likely outcome.

```
STEP 0 — Are the validity gates clear?
  IF `Inconsistent Number of CPUs` fired
  THEN → STOP. `iowait` is a percentage over all CPUs; the denominators differ (P0, R4)
       → verify: re-record on matched instance types
  IF `Inconsistent Physical Memory` fired
  THEN → page cache size differs, which directly changes how many reads reach the
         device. An `iowait` delta is expected (P0, R4)
       → verify: compare `Cached` and `MemAvailable`; a smaller cache converts
         cached reads into physical I/O
  IF the two runs used DIFFERENT STORAGE (EBS vs local NVMe, different volume type
     or size, different NFS mount)
  THEN → the comparison is about storage configuration, not about the change under
         test (P0, R4). aperf has NO rule for this — check it manually
       → verify: `lsblk`, the instance type, and the mount table out of band
  ELSE continue.

STEP 1 — Read the ABSOLUTE values. Most findings stop here.
  Parse: The average in {run} ({v}) is {pct}% greater than {base} ({bv}).

  IF the base value is 0.00 (description reads exactly `100.00% greater than`,
     score exactly -160.00)
  THEN → the zero-baseline substitution, NOT a doubling
         (time_series_stat_run_comparison_rule.rs:100, forced 1.0 at :103). The
         score is fixed and carries NO magnitude (P3, R0)
       → the ONLY number that matters is this run's absolute value; judge on that
         alone and continue to the absolute test below
  IF this run's avg(iowait) < 1%
  THEN → IMMATERIAL on any instance with more than a handful of vCPUs. Say so
         explicitly and STOP. Do not open a storage investigation on this basis
         (P4, R0)
       → EXCEPT on a 1–4 vCPU instance, where 1% aggregate can be a meaningfully
         blocked thread — scale by vCPU count before dismissing
  IF this run's avg(iowait) is 1-5%
  THEN → possibly normal for a storage-touching workload. Worth one look at
         `diskstats`, not a full investigation (P3, R0)
  IF this run's avg(iowait) > 5%
  THEN → material. Continue (P2, R0)
  IF this run's avg(iowait) > 20%
  THEN → storage is very likely the dominant bottleneck (P1, R0)

  Then check the RECORDING GEOMETRY, because `iowait` is delta-derived like every
  other CPU state:
  IF the base run's n <= 10 (recover it as n = 100 / (100 - (avg(total) + avg(idle))),
     derivation in consistent-cpu-utilization.md) AND the compared run's n is larger
  THEN → the forced-zero first sample dilutes the shorter base run more, biasing
         this delta upward by up to 1/(n_base - 1) (P2, R0)
       → verify: re-report BOTH runs with `--time-range 1:`; at the default
         --period 10 or longer, geometry alone cannot reach +10%

STEP 2 — Did the CPU side get FASTER? Rule this out before touching storage.
  `iowait` is IDLE TIME with an outstanding request. Its share rises whenever the
  non-idle work shrinks, with I/O completely unchanged.
  IF `Decreased User-Space CPU Utilization` fired on this run AND throughput held
     or improved
  THEN → the `iowait` SHARE rose BECAUSE OF a CPU-side improvement. There is no
         storage regression to fix (P4, R0)
       → verify: `diskstats` request counts and service times should be essentially
         unchanged between the runs. If they are, this is confirmed
       → report it as an improvement; do not provision anything
  IF `user` is flat and `idle` FELL while `iowait` rose
  THEN → NEW I/O was added — the machine is waiting on work it did not do before
         (P2, R0)
  ELSE continue.

STEP 3 — MANDATORY: read `diskstats`. Nothing will prompt you.
  `diskstats` has ZERO analytical rules (src/analytics/rules/diskstats.rs is an
  empty `impl AnalyzeData for Diskstats {}`), so aperf will NEVER raise a finding
  about the device no matter how saturated it is. This step is the whole investigation.

  READ IT PER DEVICE. The reported statistic for each metric comes from the device
  series with the HIGHEST AVERAGE (MaxSeries mode,
  time_series_data_processor.rs:320-332), and PARTITIONS are separate series from
  their parent device — so the summary stat may describe a partition, and a second
  busy device can be entirely hidden behind the first.

  Derive the three numbers iostat would give you (all metrics are per-interval
  deltas; time_* are in MILLISECONDS, so at the default --interval 1 the interval
  is 1000 ms):
    device busy %      = time_in_progress / 1000 * 100
    avg queue depth    = weighted_time_in_progress / time_in_progress
    avg latency (ms)   = (time_reading + time_writing) / (reads + writes)

  IF request counts (`reads`, `writes`, `sectors_read`, `sectors_written`) ROSE
  THEN → MORE I/O WAS REQUESTED. The workload changed; the device is doing what it
         was asked (P2, R0)
       → verify: the rise in sectors should roughly account for the rise in
         time_reading/time_writing at unchanged average latency
       → find out WHY: cold page cache, a larger dataset, lost caching, a changed
         query plan, added logging. Provisioning more IOPS does NOT address this
  IF request counts are FLAT but avg latency ROSE
  THEN → SAME I/O, SLOWER SERVICE. The device or its provisioning is the constraint
         (P1, R1)
       → verify: `in_progress` and the derived queue depth should have risen too
       → remedy: raise provisioned IOPS/throughput (R1 on gp3), or move to local
         NVMe (R4). Confirm the volume is not burst-credit-limited
  IF `time_flushing` or `flushes` ROSE disproportionately
  THEN → FSYNC/BARRIER PRESSURE, the usual cause in database and log-heavy
         workloads (P1, R5)
       → verify: flushes per second against the application's commit rate
       → CAUTION: reducing fsync frequency changes DURABILITY. This is R5. Present
         it as a correctness trade-off, never as tuning
  IF device busy % is near 100 on an NVMe device
  THEN → do NOT read this as saturation. Multi-queue devices service requests in
         parallel, so "busy" only means the queue was non-empty (P2, R0)
       → verify: use the derived queue depth and latency instead; rising latency at
         rising queue depth is the real saturation signal
  IF `in_progress` looks low despite high latency
  THEN → `in_progress` is the ONE diskstats metric that is INSTANTANEOUS rather than
         a delta (src/data/diskstats.rs:165) — it is a single sample per interval and
         misses bursts entirely (P2, R0)
       → verify: prefer `weighted_time_in_progress`, which integrates over the whole
         interval

STEP 4 — Is the I/O actually PAGING? A different fix entirely.
  IF `pswpin` or `pswpout` (`vmstat`) ROSE
  THEN → THE SYSTEM IS SWAPPING. This invalidates every other performance
         conclusion in the run, not just this one (P0, R1)
       → verify: `SwapFree` in `meminfo` falling; `MemAvailable` low
       → the fix is memory-side — reduce footprint or size up. Storage provisioning
         treats the symptom
  IF `pgmajfault` rose, or `Major Page Faults Detected` / `Increased Major Page
     Faults` fired
  THEN → major faults ARE disk reads. The I/O source is the memory subsystem, not
         application reads (P1, R1)
       → verify: `Cached` and `MemAvailable` in `meminfo`; a shrunken page cache
         converts previously-cached reads into physical I/O
       → route to ../vmstat/major-page-faults-detected.md and
         ../meminfo/reduced-memory-availability.md
  ELSE the I/O is application-issued; continue.

STEP 5 — WHEN in the run, and WHO issued it?
  IF the `iowait` series is FRONT-LOADED
  THEN → warm-up / cold page cache. An artifact of run setup, not steady state
         (P3, R0)
       → verify: the base run's timeline should show the same shape if its cache was
         also cold; if only this run is front-loaded, its cache was colder
       → remedy: warm the cache before recording, or exclude the ramp with
         `--time-range` (report-time, R0)
  IF the `iowait` series is SPIKY
  THEN → periodic work: checkpoints, compactions, log rotation, backup, GC
         (P2, R0)
       → verify: the spike period should match a known schedule; correlate with
         `flushes` spikes in `diskstats`
  IF the `iowait` series is SUSTAINED
  THEN → a steady-state constraint. This is the case worth remediating (P1, R0)
  IF per-CPU `iowait` is CONCENTRATED on a few CPUs
  THEN → a few blocked threads, not system-wide pressure. The aggregate understates
         their individual impact (P2, R0)
       → verify: read the per-CPU series, not the aggregate

  Then attribute it:
  IF the workload is JAVA and `--profile-java` data exists
  THEN → diff the `wall` heatmap against `cpu`; stacks heavy in `wall` and absent
         from `cpu` are the blocking callers (P1, R0)
  IF the workload is NOT Java
  THEN → aperf CANNOT profile off-CPU. `--profile` runs
         `perf record -e cpu-clock` (src/data/perf_profile.rs:136), which samples
         only RUNNING threads and is blind to a thread blocked on I/O (P2, R0)
       → do NOT recommend re-recording with `--profile` to find the blocking caller
       → use `processes` (`kernel_space_time` per process) to narrow which process,
         and gather stacks out of band (`biosnoop`, `biotop`, `offcputime-bpfcc`)

STEP 6 — Is it NETWORK storage? aperf's own message says to check.
  IF the workload uses NFS, EFS, FSx, or any network filesystem
  THEN → the ceiling may be the NETWORK path, and scaling storage IOPS will not
         help (P1, R4)
       → verify: `bw_in_allowance_exceeded` / `bw_out_allowance_exceeded` /
         `pps_allowance_exceeded` in `ena_stat`, and `IpExt:InOctets`/`OutOctets`
         in `netstat`
       → NOTE: network-filesystem I/O may not appear in `diskstats` AT ALL, since
         there is no block device behind it. Flat `diskstats` with high `iowait` is
         the signature
       → remedy: expand the NFS/EFS provisioned throughput, or move the working set
         to local storage

STEP 7 — What survives?
  VALID      : configuration findings — independent of I/O
  VALID      : the `diskstats` derivations in STEP 3 — same window, same run
  CAUTION    : `perf_stat` efficiency metrics. Time blocked on I/O is time not
               retiring instructions, so a high-`iowait` run yields diluted PMU
               ratios. If `Underutilized CPU` also fired, treat every ratio as
               low-confidence
  CAUTION    : the `diskstats` summary statistic — it is the highest-average DEVICE
               (or partition), not the system total
  CONFOUNDED : any storage conclusion if STEP 4 found swapping. Fix memory first,
               then re-measure
  VOID       : "storage is the bottleneck", asserted from this finding alone. It is
               a share of CPU time and the prompt to read `diskstats`, nothing more
  VOID       : the score as a severity ranking — pinned at -160.00 on a zero
               baseline, and identical for trivial and severe absolute changes

INSUFFICIENT DATA
  IF only ONE run is present
  THEN → the rule requires a base run; NO finding was produced (P2, R0)
  IF the BASE run lacks the `iowait` metric
  THEN → the rule returned early with a `debug!` and produced NO finding for ANY
         run (P2, R0)
  IF `diskstats` was skipped at record time
  THEN → the mandatory step of STEP 3 is unavailable and no storage conclusion is
         supportable. Re-record without skipping it (P2, R0)
  IF the finding is ABSENT but `iowait` is high in absolute terms
  THEN → absence proves nothing. A run that was ALREADY storage-bound in the base
         shows no relative change while both runs are constrained (P2, R0)
```

## Runtime-specific consequences

`iowait` is charged to the CPU, not to a process, so the runtime does not change what the
metric measures. What it changes is **which I/O the runtime issues on your behalf** — and in
several cases the I/O is not application data at all.

| Runtime | Characteristic I/O that raises `iowait` without the application reading more data | What to check |
|---|---|---|
| **.NET** | Assembly and ReadyToRun image loading is real disk I/O at startup, so a cold-start or short run is front-loaded with `iowait` that steady state never repeats. `DOTNET_TieredPGO` profile writes and crash-dump configuration add writes. On Linux, `/tmp` and the diagnostic IPC socket see traffic a container image may back with slow storage | Whether the run was long enough to leave startup. Front-loaded vs sustained `iowait` in the timeline |
| **Python** | Import is filesystem-heavy — `sys.path` scanning stats many directories, and a large virtualenv or a network-mounted `site-packages` turns import into thousands of small reads. `__pycache__` writes on first run add writes a warm run does not. Very often the entire `iowait` delta is import, not workload | Whether `__pycache__` was pre-populated; whether `site-packages` is on the same volume as the data. Front-loaded shape confirms import |
| **Java** | **The one runtime where aperf can attribute the blocking**: `--profile-java` collects `wall` alongside `cpu` (`--wall 100ms`), so stacks blocked on I/O are visible in the `wall` heatmap. Characteristic non-workload I/O: JIT and class loading from JARs at startup, GC log writes, and JFR recording itself — profiling the run adds the writes you are measuring | Diff `wall` against `cpu`. Whether GC logging or JFR was enabled in only one run |
| **Perl** | `@INC` scanning at startup is the same pattern as Python's import, and Perl's default line-buffered output to a file means log writes are frequent and small. Almost all `iowait` here is either startup or logging | Whether output was redirected to a file vs a pipe (buffering differs); `@INC` length |

**A profiling flag can be the cause.** `--profile` writes `perf.data` for the whole recording
period, and `--profile-java` writes a JFR per JVM. If one run was profiled and the other was
not, the profiled run does writes the other did not — check before attributing anything.

**When the runtime is unknown** — it is inferred from `processes` metric names
([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3), a heuristic — the timeline shape test in
STEP 5 is runtime-independent and separates startup I/O from steady state on its own.

## Architecture-specific considerations

`iowait` is `/proc/stat`-derived and means the same thing on every architecture. What differs is
**the storage attached to the instance**, and that is a far larger effect than the ISA.

| Comparison | Why `iowait` moves, independently of your change | What to check |
|---|---|---|
| **EBS vs local NVMe** (`d`/`en` families) | Different order of magnitude in latency and a different saturation model. EBS is network-attached, so its throughput is also bounded by the instance's EBS bandwidth ceiling, not just the volume's IOPS | Instance type and `lsblk` out of band — aperf records neither the volume type nor the mount table |
| **`gp2` vs `gp3` vs `io2`** | `gp2` IOPS scale with volume size and burst on credits, so a smaller volume in one run silently throttles. `gp3` decouples IOPS from size | Volume type and provisioned IOPS. Burst-credit exhaustion presents as latency rising partway through the run — a step change in the timeline |
| **Nitro vs earlier generations** | Nitro moves storage virtualization to dedicated hardware; the same volume reads faster with less host CPU overhead. An instance-generation change alone shifts `iowait` | Instance generation. This is invisible to every metric aperf collects |
| **Intel/AMD vs Graviton** | The ISA does not change device latency. What changes is the *share*: a higher-IPC or better-vectorized core finishes its CPU work sooner and then waits, so `iowait` rises on the faster architecture with I/O unchanged | STEP 2 — this is exactly the "CPU side got faster" case, and on a migration comparison it is the expected result, not a regression |

**aperf has no architecture field and no storage field.** No rule compares `Instance Type`
([../GATES.md](../GATES.md)), so a comparison across instance families with matched `CPUs` and
`MemTotal` fires **no gate at all** while `iowait` moves for reasons that have nothing to do
with the change under test. Confirm the instance type and the storage configuration manually —
for this finding that check matters more than it does for any other `cpu_utilization` rule.

**SMT affects the denominator.** On Intel and AMD with SMT, `iowait` is a share over vCPUs, two
of which share a physical core; on arm64 each vCPU is a physical core
(`data-descriptions.ts:105`). A blocked thread therefore contributes a different fraction of
aggregate `iowait` on the two, which is one more reason to read per-CPU series rather than the
aggregate when the absolute value is small.

## Verification

**In the most common case there is nothing to verify, because there is nothing to fix.** If
STEP 1 found an absolute value below 1% or a zero baseline, the deliverable is an explicit
statement that the finding is immaterial and why — the fixed `−160.00` score and the relative
threshold on a near-zero metric. Manufacturing a storage investigation from that is the failure
mode this playbook exists to prevent.

If STEP 2 established that the CPU side got faster, verification is that `diskstats` request
counts and service times are unchanged across the runs while `user` fell and throughput held.
That confirms an improvement; no action follows.

For a confirmed device or provisioning constraint, apply the STEP 3 remedy and re-record both
runs at matched geometry. The check is on `diskstats`, not on `iowait`: **average latency should
fall at unchanged request counts**, and the derived queue depth should fall with it. `iowait`
falling on its own is not sufficient — it also falls when the CPU side gets busier, when the
workload simply does less I/O, and when threads move from I/O blocking to lock blocking (which
lands in `idle`). Confirm that throughput rose, or at minimum held, alongside the latency
improvement.

If the cause was **more I/O requested**, the verification target is the request count itself:
after restoring the cache, reverting the query plan, or fixing the caching layer, `reads` and
`sectors_read` should fall back toward the base run's values. Provisioning more IOPS in this case
raises cost and leaves the request count where it was — if `iowait` improves but sectors did
not, you paid for the symptom.

For **swapping** (STEP 4), verify `pswpin`/`pswpout` return to zero and `SwapFree` stops
falling before drawing any further storage conclusion; the run was not interpretable until then.
For **network storage** (STEP 6), the target is the `ena_stat` allowance counter — it must stop
incrementing. And for an **fsync change**, state plainly that the verification is a durability
review, not a performance measurement: confirm the new setting still meets the application's
crash-consistency requirement before treating the latency win as a result.

## Do not

- **Do not treat `iowait` as a measure of storage load.** It is a share of CPU time. A small
  number on a large instance can hide a fully saturated device; a large number on a small
  instance can be one thread.
- **Do not act on the relative delta alone.** 0.10% → 0.13% fires this rule. Always quote
  and judge the absolute values.
- **Do not trust a `100.00% greater than` reading with base `0.00`** — that is the
  zero-baseline substitution and its `−160.00` score is fixed, not measured.
- **Do not conclude "disk is the bottleneck" from this finding.** It is the prompt to read
  `diskstats`, and `diskstats` has no rules to prompt you otherwise.
- **Do not assume rising `iowait` means storage regressed.** A faster CPU side raises
  `iowait` share with storage unchanged.
- **Do not provision more IOPS before distinguishing "more I/O" from "slower I/O".** More
  IOPS does not help a workload that simply started reading much more data.
- **Do not read low `iowait` as "not blocked".** Socket, lock, and sleep waits land in
  `idle`, not `iowait`.
- **Do not compare `iowait` across different core counts, instance types, or storage
  configurations.**
- **Do not read the `diskstats` summary statistic as a system total.** It is the single device
  series with the **highest average** (`MaxSeries` mode), and partitions are separate series
  from their parent device — a second busy device can be entirely hidden. Read per device.
- **Do not read `in_progress` as a queue depth, or a near-100% device-busy figure on NVMe as
  saturation.** `in_progress` is the one `diskstats` metric that is instantaneous rather than a
  per-interval delta, so it misses bursts; and multi-queue devices service requests in parallel,
  so "busy" only means the queue was non-empty. Use `weighted_time_in_progress` and read
  latency at queue depth instead.
- **Do not draw any storage conclusion from a run that was swapping.** If `pswpin`/`pswpout`
  rose, fix memory first — the whole run is confounded, not just this finding.
- **Do not present reducing fsync frequency as a tuning change.** It changes what survives a
  crash. That is R5, and it needs a durability decision, not a performance one.
- **Do not recommend `--profile` to find the blocking caller on a non-Java workload.** It runs
  `perf record -e cpu-clock`, which samples only running threads; a thread blocked on I/O
  contributes no samples at all.
- **Do not read the absence of this finding as "storage is fine."** A run that was already
  storage-bound in the base shows no relative change while both runs are constrained.

## References

- Upstream guide: `IOWAIT_TIME_OPTIMIZATION` in
  `src/report_frontend/src/definitions/optimization-guides.ts` — provision more EBS IOPS
  ([EBS-optimized instances](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ebs-optimized.html)),
  or migrate to instance types with local storage (the `d.` instances).
- Rule definition: `src/analytics/rules/cpu_utilization.rs:54` — `metric: "iowait"`,
  `Stat::Average`, `Comparator::GreaterEqual`, `delta_ratio: 0.1`, `abs: false`, score `Poor`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` —
  branch order at `:98`–`:106`; zero-baseline substitution tested at `:100` and the forced
  `1.0` at `:103`; description built at `:121`; early `debug!` return at `:79`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Poor = -16` at
  `:149`.
- **`diskstats` has no analytical rules**: `src/analytics/rules/diskstats.rs` is the whole
  file — `impl AnalyzeData for Diskstats {}` with an empty body.
- `diskstats` processing: `time_series_data_processor_with_max_series_aggregate!`
  (`src/data/diskstats.rs:142`), so the reported statistic is the device series with the
  highest average (`src/data/common/time_series_data_processor.rs:320`–`:332`). One series per
  device **and per partition**, keyed on the `/proc/diskstats` device name (`:151`–`:177`).
- **`in_progress` is the only non-accumulative `diskstats` metric** — added with
  `add_data_point` rather than `add_accumulative_data_point` because it is a gauge, not a
  counter (`src/data/diskstats.rs:163`–`:170`, citing the kernel iostats doc).
- `DiskStatKey` variants and `/proc/diskstats` field indices: `src/data/diskstats.rs:85`–`:103`
  and `:105`.
- `time_*` units are **milliseconds** and `sectors_*` are **512-byte sectors**:
  `data-descriptions.ts:2501`–`:2603` (`time_reading` measured "from
  `blk_mq_alloc_request()` to `__blk_mq_end_request()`"; `weighted_time_in_progress`
  "accounting for queue depth").
- **On-CPU-only profiling**: `perf record -a -q -g -k 1 -F <freq> -e cpu-clock:pppH`,
  `src/data/perf_profile.rs:126`–`:139`. **Java off-CPU (wall-clock)**: `PROFILE_METRICS =
  ["cpu", "alloc", "wall"]` (`src/data/java_profile.rs:32`), `--wall 100ms` at `:81`.
- Recording and reporting mechanics: forced-zero first sample from
  `get_delta_and_set_previous_value` (`src/data/common/time_series_data_processor.rs:189`),
  documented for users at `data-descriptions.ts:94` and in the `diskstats` summary at `:2504`;
  defaults `--interval 1` / `--period 10` (`src/record.rs:37`, `:47`); `--time-range` is a
  **report**-time flag (`src/report.rs:245`); Graviton vCPUs are physical cores
  (`data-descriptions.ts:105`).
- [Graviton perfrunbook — check I/O usage](https://aws.github.io/graviton/perfrunbook/debug_system_perf.html#check-io-usage)
- [Amazon EBS volume types](https://docs.aws.amazon.com/ebs/latest/userguide/ebs-volume-types.html)
  and [`gp2` burst-credit behaviour](https://docs.aws.amazon.com/ebs/latest/userguide/general-purpose.html)
- [`proc_stat(5)`](https://man7.org/linux/man-pages/man5/proc_stat.5.html) — definition of the `iowait` field
- [`Documentation/iostats.rst`](https://www.kernel.org/doc/Documentation/iostats.txt) — the `/proc/diskstats` fields behind aperf's `diskstats`
