---
rule_name: High L3 Cache Misses
data_type: perf_stat
data_key: l3-mpki
template: time_series_data_point_threshold
condition: "any(l3-mpki) > 10.0"
base_score: Bad
score_sign: negative
requires_comparison: false
aperf_message: "This indicates the working set data footprint is not fitting in L3, leading to CPU backend stalls and a larger DRAM bandwidth being consumed. There can be a larger issue if your instance is co-located with multiple neighbors that consume a measurable amount of DRAM bandwidth."
source: src/analytics/rules/perf_stat.rs:108
---

# High L3 Cache Misses

## What fired

**At least one** data point of `l3-mpki` was **greater than 10.0** L3 cache misses per thousand
instructions, in **any** series including per-CPU. A single sample anywhere in the recording is enough.

Base score `Bad` (−2) — double the `Concerning` (−1) used for L1D and L2, because an L3 miss is a DRAM
access and consumes a resource that is **shared and finite**. Single-run rule.

## The processing caveat — `l3-mpki` counts four different things across the eight PMU profiles

**The metric name is stable; the counter behind it is not.** `l3-mpki` is defined at base in
`grv_pmu_config.json`, `intel_pmu_config.json` and `amd_pmu_config.json`, and then *overridden* by
`grv_5_pmu_config.json` — the only profile in the tree that redefines it. `icelake`, `sapphire_rapids`,
`milan` and `genoa` inherit their vendor's base definition unchanged. Verified by dumping every
`src/pmu_configs/*.json` and re-deriving each expression:

| Profiles | `l3-mpki` counts | Is `l3-mpki / l2-mpki` a survival fraction? |
|---|---|---|
| `intel`, `icelake`, `spr` | `0x2e` umask `0x41` — last-level cache **misses** | **Yes.** The one case where the funnel ratio means what it looks like |
| `grv` | `0x37` — last-level cache **READ refills** | **No.** Write and prefetch traffic reaching DRAM is not counted, so the value **understates** a store-heavy working set and the ratio is a lower bound |
| `grv5` | `(L3 / L3_READ * L2)` — L2 misses scaled by the LL **read** miss ratio (`L3_READ` = `0x36`) | **No.** A modelled **estimate** of the whole funnel, not a direct count. Not comparable to a `grv` run, let alone an x86 one |
| `amd`, `milan`, `genoa` | `0x44` umask `0x8` — L1 fills **sourced from DRAM** | **No.** Not a subset of `l2-mpki` at all, so the ratio may legitimately exceed 1.0. A DRAM-traffic figure only |

The quantifier reports the semantics with the funnel so the ratio is never read blind:

```
$ python3 ../tools/aperf_memory_hierarchy.py --funnel --data-l1 45 --l2 22 --l3 14 --profile amd
l2_of_l1: 0.489, l3_of_l2: 0.636, boundary: dram, l3_ratio_valid: false, l3_kind: l1_fills_from_dram
```
The same three inputs return `l3_ratio_valid: true, l3_kind: ll_cache_miss` on `intel`,
`ll_cache_read_miss` on `grv` and `derived_estimate` on `grv5` — identical arithmetic, four different
meanings. `cross_architecture_comparable('l3-mpki', 'grv', 'grv5')` is therefore **False** even though both
are Graviton, and the registry says so: *"Do not compare across architectures."*

**`spr` is a two-layer case.** It inherits the generic-Intel L3 encoding (`0x2e`/`0x41`) but overrides
`L2` to `0x25`/`0x1f`, so the two halves of the funnel ratio come from different config layers. That is
valid — but confirm from `Instance Type` that the run really was collected on Sapphire Rapids, because
aperf records no profile field and the wrong overlay silently changes one half.

**What is *not* defective here:** unlike the four zero-threshold TLB rules, this threshold is non-zero, so
`compute_finding_score` is monotonic and the template reports the **series peak** — verified directly,
`--select 25 12 45 30 --threshold 10 --rule-score -2` returns `reported_value: 45.0, series_max: 45.0,
reports_the_peak: true`.

## Reasoning

`l3-mpki` is "Level 3 cache misses per thousand instructions executed, indicating how often the CPU has
to access DRAM. A higher number means more DRAM bandwidth will be consumed." (`data-descriptions.ts`,
`desired: "lower"`)

**This is the end of the memory hierarchy — an L3 miss is a DRAM access.** Hundreds of cycles of
latency, and, uniquely among the cache metrics, consumption of a resource that is shared and finite:
memory bandwidth. That second property makes this the most consequential of the three cache findings and
introduces two failure modes L1D and L2 never show.

1. **Latency.** Several hundred cycles per access. At 10 MPKI that is thousands of cycles of potential
   stall per thousand instructions — more than any out-of-order window can hide.
2. **Bandwidth saturation, including from neighbours.** DRAM bandwidth is a per-socket ceiling shared by
   every core, and on non-metal instances it is shared with **co-tenants**. aperf's own message says so:
   *"There can be a larger issue if your instance is co-located with multiple neighbors that consume a
   measurable amount of DRAM bandwidth."* Once the memory controller saturates, latency rises
   non-linearly for everyone and your own numbers change with no change to your code. This is the one
   `perf_stat` finding whose cause can lie **entirely outside your instance**.

Reaching this rate means the working set exceeds the **system-level cache**, tens of megabytes on
Graviton-class parts. Nothing in the struct-packing or code-layout toolbox fixes that; only **reducing the
volume of data touched per unit of work** does, which is why `DATA_FOOTPRINT_OPTIMIZATION` is the attached
guide and why its advice is about reuse and access order rather than layout detail.

The causes, and the lever each one implies — note that the last three are not code defects at all:

| Cause | Lever |
|---|---|
| **Working set genuinely exceeds L3** — large heaps, big indexes, wide scans, high per-request state × high concurrency | Footprint |
| **Streaming access with no reuse** — one-pass scans over data far larger than cache, bandwidth-bound by construction | Touch less data, or buy more bandwidth |
| **Random access across a large structure** — prefetchers cannot predict, so every access is a DRAM round trip. Hash tables, graph traversals over multi-gigabyte data | Locality, or prefetch |
| **Cache pollution** — a large streaming pass evicting the small hot set the rest of the workload reuses | Non-temporal hints, or separating the passes |
| **NUMA remote access** — another node's memory costs more and consumes interconnect bandwidth too | Placement, not restructuring |
| **Co-tenant bandwidth contention** — not your workload at all | A metal instance |
| **Too many concurrent threads** — each thread's footprint multiplies the aggregate working set | Concurrency: the cheapest experiment of the seven |

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 25.00 (greater than the threshold of 10).
```

`25.00` **is** the worst single sample — the peak, verified above — but it is **not the average**, and a
run that touched 25 MPKI once during a load phase reports identically to one that sat there throughout.
**It may also be one CPU's series**: this template iterates **every** series including per-CPU
(`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based
`perf_stat` rules that read only `Aggregate` (`:432`). The value is **truncated, not rounded**
(`f64_to_fixed_2`, `src/computations/mod.rs:138`), so `25.00` is anything in `[25.00, 25.01)`.
And there is **no `(n−1)/n` dilution correction**: `perf_stat` opts out of the forced first zero via
`use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`), so the first sample is real.

Score math — `compute_finding_score(value, 10.0, −2)`. The value is always above the threshold, so no
inversion applies and the score is a clean linear function of it:

| worst sample | score |
|---|---|
| 12.0 | `(12/10) × −2` = **−2.40** |
| 25.0 | `(25/10) × −2` = **−5.00** |
| 40.0, then 60.0 | `(40/10) × −2` = **−8.00**, `(60/10) × −2` = **−12.00** |

Recover the sample as `value = |score| / 2 × 10 = |score| × 5`.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The peak sits at or below 10.0 | no finding. On `grv` that is weaker evidence than it looks: reads only are counted |
| Only one `CPU{n}` series exceeded | reported for the whole run; the `Aggregate` series may be well under 10 |
| The run multiplexed heavily | the peak is an extrapolation, and one distorted interval is sufficient to fire |
| The profile is `amd`/`milan`/`genoa`, or `grv5` | a DRAM-traffic figure that can exceed `l2-mpki`, or a derived estimate incomparable to any other run including a `grv` one — not an L3 miss count either way |

**Do not compare this score against `High L2 Cache Misses`.** Both use a threshold of 10.0, but L3 uses
`Bad` (−2) and L2 `Concerning` (−1), so the same MPKI value scores twice as severely here. That is
intentional and correct, and it makes a score comparison between the two findings meaningless.

## Interpretation

| sustained value | Reading |
|---|---|
| 10–20 | Real DRAM traffic. Latency-sensitive workloads will feel it |
| 20–40 | Substantial; likely a leading bottleneck if the backend is dominant |
| > 40 | Severe — expect **bandwidth**, not latency, to be the ceiling |

| `l3-mpki` high **and** | Reading |
|---|---|
| sustained across the series | Genuine. One isolated sample is a load phase, a full scan, GC or warm-up, and is not |
| `data-l1-mpki` and `l2-mpki` high too | Consistent escalation: the working set exceeds every level. Total footprint reduction is the only structural fix. Run `--funnel` to confirm the boundary |
| `data-l1-mpki` low, `l3-mpki` high | Streaming or non-temporal access bypassing earlier levels — or instruction traffic. Check `inst-l1-mpki`. On AMD, check the caveat first: the two counters are not nested |
| `Backend-Dominated CPU Stalls` fired | **The confirmed case** — DRAM access is the bottleneck |
| `ipc` very low (< 0.5) | Classic memory-bound signature; the core is starved |
| `ipc` healthy (> 2) | Enough memory-level parallelism to hide the latency. Bandwidth may still be the eventual ceiling |
| `numa_miss` / `other_node` high | Part of the cost is remote-node access — a **placement** fix, not a footprint fix |
| `data-tlb-tw-pki` high | Page-table walks themselves miss to DRAM, compounding both axes. Huge pages help twice over |
| the value varies between identical runs | **Specific to this finding** — co-tenant bandwidth contention. Your code did not change |
| `Frontend-Dominated CPU Stalls` fired | Secondary. Check `inst-l1-mpki`: instruction traffic flows through L3 too |

**Known false positives — check these before concluding your code is at fault:**

- **A single transient sample.** The dominant false positive for every
  `time_series_data_point_threshold` rule. A load phase, full scan, GC cycle or cache warm-up spikes it,
  and the peak is exactly what gets reported.
- **Co-tenant DRAM bandwidth contention.** **Unique to this finding.** Your access pattern did not
  change; a neighbour's did. Hard to prove from inside the instance — the signature is `l3-mpki` and the
  backend stall rate varying between otherwise-identical runs. Metal removes the variable entirely.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, the peak is an extrapolation and one
  distorted interval fires the rule.
- **One hot CPU.** The rule reads every per-CPU series, so a single streaming thread fires it for the run
  while the aggregate is benign. **Idle-diluted or kernel-heavy runs** are the same class: background
  daemons contribute their own DRAM traffic, and if `system` time dominates, part of it is kernel-side.
- **The workload is legitimately bandwidth-bound.** Analytics scans, ETL, video and image processing, large
  joins, in-memory databases: they access more data than any cache holds. That is the cost of the work, and
  the lever is instance selection, not code. Streaming with no reuse is the same story, and so is **GC** —
  a copying collector reads and writes large regions by design.
- **The traffic is instruction, not data.** High `inst-l1-mpki` means part of `l3-mpki` is code fetches. And
  **high thread count** raises the aggregate working set with no change to the code at all.
- **Different instance size.** SLC capacity and memory bandwidth scale with instance size, so the same
  workload legitimately shows a different `l3-mpki` on a different instance type. Never compare across
  families — and on a **vendor** change the metric is not even the same counter.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `l3-mpki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient; uniform elevation (bandwidth ceiling) vs a few cores (specific threads) |
| `l2-mpki`, `data-l1-mpki` | `perf_stat` | The escalation pattern — whether pressure builds through the funnel or appears only at L3. Feed all three to `--funnel`. See `High L2 Cache Misses`, `High L1 Data Cache Misses` |
| `inst-l1-mpki` | `perf_stat` | Whether part of the L3 traffic is instruction fetches. See `High L1 Instruction Cache Misses` |
| `stall-backend-pkc` vs `stall-frontend-pkc`, `ipc` | `perf_stat` | **Severity gate.** Very low `ipc` with high `l3-mpki` is the canonical memory-bound signature. See `Backend-Dominated CPU Stalls` |
| `data-tlb-tw-pki`, `data-tlb-mpki` | `perf_stat` | Page-table walks also miss to DRAM, compounding latency and bandwidth. See `Data TLB Table Walks` |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ the peak may be an extrapolation artifact |
| `numa_hit`, `numa_miss`, `numa_foreign`, `local_node`, `other_node` | `numastat` | **Most important at this level** — remote-node access adds latency and interconnect bandwidth. **No analytical rules — read manually** |
| `MemTotal`, `MemAvailable`, `Cached`, `AnonHugePages` | `meminfo` | Total memory, pressure, and whether huge pages are shortening the walks |
| `pgfault`, `pgminorfault`, `pgmajfault` | `vmstat` | Allocation churn and paging; major faults add disk I/O on top of DRAM traffic |
| `number_threads`, `resident_set_size_bytes` | `processes` | Concurrency and per-process footprint — the R1 lever. **No analytical rules.** With `idle`/`aggregate` in `cpu_utilization`, also the dilution check |
| `Instance Type`, `Kernel Version` | `systeminfo` | SLC capacity and DRAM bandwidth are instance-type properties; metal removes co-tenant contention; and the instance type is the **only** clue to which PMU profile applied |
| On-CPU profile | `perf_profile` / `java_profile` | Which code performs the missing accesses. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | **The intended tool** — attributes DRAM-bound accesses to instructions and addresses, which is the prerequisite for prefetch placement. Native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |
| Memory allocation profile | `java_profile` | Where the large allocations come from (`--profile-java`) |

## Guidance

Ordered. Step 1 disposes of transient firings; step 2 decides what the number even means; step 5 is
unique to this finding and is often the answer.

1. **Read the `l3-mpki` series before anything else.** An **isolated spike** at startup, a scan phase or
   aligned with GC ⇒ transient; stop. **Sustained above 10** ⇒ continue. Check per-CPU: uniform
   elevation across all cores suggests a bandwidth ceiling, concentration on a few suggests specific
   threads and a much cheaper fix.

2. **Establish what `l3-mpki` counts on this run.** Read `Instance Type` and map it to a profile, then
   apply `The processing caveat`. On **AMD** it is L1 fills from DRAM, so it is *not* a subset of
   `l2-mpki` and the funnel ratio is not a survival fraction. On **`grv`** it is read refills only, so a
   store-heavy workload is understated. On **`grv5`** it is a derived estimate. Only on Intel is it a
   direct last-level miss count. This step changes the *reading*, not the value.

3. **Gate on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`) and `avg(idle)` (`Underutilized CPU`).

4. **Confirm the backend is the bottleneck.** Compare `stall-backend-pkc` and `stall-frontend-pkc`, and
   read `ipc`. Very low IPC (< 0.5) with high `l3-mpki` is the classic memory-bound signature and needs
   no further confirmation. On generic `amd` neither stall metric exists, so use `ipc` alone.

5. **Distinguish "your footprint" from "someone else's bandwidth" — before optimizing anything.** The
   check that applies only at L3:
   - Compare `l3-mpki` and the backend stall rate across **multiple runs of the same workload**. If they
     vary materially between identical runs, that is external variability — most likely co-tenant DRAM
     bandwidth contention, exactly as aperf's message warns.
   - Check `numastat` (`numa_miss`, `other_node`): remote-node access raises cost with no footprint
     change, and the fix is placement (`numactl`, thread and memory affinity), not restructuring. It has
     **no analytical rules**, so nothing flags it for you.
   - If the workload is bandwidth-bound and the instance is shared, a **metal instance** removes the
     neighbour variable and is the cleanest way to prove it.

6. **Localize the boundary in the funnel** rather than reading the three cache findings separately:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --funnel --data-l1 45 --l2 22 --l3 14 --profile intel
   l2_of_l1: 0.489, l3_of_l2: 0.636, l3_of_l1: 0.311, boundary: dram, l3_ratio_valid: true
   ```

   `boundary: dram` is the expensive case and the one that justifies a real data-structure change.
   Consistent escalation across all three levels means the working set exceeds every level; L3 high with
   L1D and L2 modest means streaming, non-temporal access, or instruction traffic.

7. **Determine whether the workload is latency-bound or bandwidth-bound.** Latency-bound (dependent
   chains, pointer chasing) responds to prefetching and more memory-level parallelism. Bandwidth-bound
   (streaming, wide scans) does not — it responds only to touching less data or to more bandwidth. `ipc`
   plus the access pattern separates them: pointer chasing shows very low IPC with modest bandwidth,
   streaming shows low IPC with the memory system saturated.

8. **Check translation.** A high `data-tlb-tw-pki` means page-table walks are themselves missing to DRAM.
   Huge pages then help twice — fewer translations, and shorter walks. Apply `TLB_MISS_OPTIMIZATION`; it is
   a configuration change and far cheaper than anything in step 9.

9. **Attribute to code and address.** With `--profile`, find the stalling stacks; for native code on
   metal Graviton, `hotline` identifies the specific DRAM-bound accesses. This is the prerequisite for
   prefetch placement and for knowing whether the code is even yours.

10. **Only then remediate**, per `DATA_FOOTPRINT_OPTIMIZATION`, in rough order of leverage at this level:
    **reduce the total data touched per unit of work** (smaller representations, compression, column
    pruning, no unnecessary materialization) — the only lever that addresses bandwidth; **improve reuse**
    so each fetched line is used more before eviction; **tile or block loops** so intermediates stay
    on-chip; **store related data contiguously and access it sequentially** so prefetchers and DRAM page
    locality work for you; **insert prefetches** at hotline-identified sites for unavoidable random
    access; **fix NUMA placement**; **reduce concurrency** if aggregate footprint scales with threads;
    and **change instance type** for more SLC and more bandwidth if the footprint is irreducible — for
    bandwidth-bound workloads frequently the only real answer, and metal additionally removes co-tenants.

## Priority and execution risk

**Priority: P2 — Investigate** by default. The threshold of 10.0 is meaningful, the reported value is the
true peak, and `Bad` (−2) already says this level costs more than the two above it. It rises to
**P1 — Act now** when the value is sustained above roughly 20 **and** `Backend-Dominated CPU Stalls` fired
with low `ipc` — that is the combination in which DRAM access is demonstrably the bottleneck — and also
when `--funnel` returns `boundary: dram` with all three levels over threshold, because the remediation is
then a known structural change rather than a search. It drops to **P3 — Monitor** when only one `CPU{n}`
series is elevated, when the elevation is confined to a load or GC phase, or when the profile is `amd`,
`milan`, `genoa` or `grv5`, where the counter is a DRAM-traffic figure or an estimate rather than an L3
miss count. It drops to **P4 — Informational** whenever the run multiplexed, or when the value varies
materially between identical runs, which points outside the instance.

**Execution risk: R0 — Read-only** to diagnose: the series, the per-CPU split, the funnel ratios, the stall
comparison, `numastat` and the run-to-run comparison are all reads. Acting spans the widest range in this
family. **R1 — Config change** for `numactl` placement or a thread-count reduction, both reversible in a
restart. **R4 — Infrastructure change** for enabling huge pages to shorten walks, and for moving to a larger
or metal instance — which changes cost and capacity planning, not just performance. **R2 — Code change** to
**R3 — Rebuild** for the footprint levers, which are the ones that actually fix a bandwidth-bound workload
and the ones that take weeks: tiling, representation changes and prefetch placement all require
re-validating correctness, not just re-measuring.

**The score is monotonic here and comparable across runs of this same rule** — `value = |score| × 5`
recovers the peak exactly. It is not comparable with `High L2 Cache Misses`, which shares the threshold
but halves the base score, nor across architectures, where the counter changes meaning.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `l3-mpki`, in any series including per-CPU, exceeded `10.0`
(`Greater 10.0`). The reported value is the series peak — verified, unlike the four zero-threshold TLB
rules.

```
STEP 0 — Does the data exist, and what does `l3-mpki` COUNT on this run?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `Instance Type` maps to `amd`, `milan` or `genoa`
  THEN → the counter is L1_Any_Fills_DRAM (0x44 umask 0x8): L1 fills SOURCED FROM DRAM, not L2
         misses that missed L3. It is not a subset of l2-mpki, so l3-mpki/l2-mpki is NOT a
         survival fraction and may legitimately exceed 1.0. Read it as DRAM traffic; cap at P3
         (P3, R0)
       → verify: `--funnel --profile amd` returns `l3_ratio_valid: false` and
         `l3_kind: l1_fills_from_dram`; if you computed a survival fraction by hand, discard it
  IF `Instance Type` maps to `grv`
  THEN → the counter is 0x37, last-level READ refills. Write and prefetch traffic reaching DRAM
         is NOT counted, so a store-heavy workload is UNDERSTATED and the funnel ratio is a
         lower bound (P2, R0)
       → verify: `--funnel --profile grv` returns `l3_kind: ll_cache_read_miss`; corroborate the
         store side from the backend stall rate, since no aperf metric carries it on arm64
  IF `Instance Type` maps to `grv5`
  THEN → grv_5 OVERRIDES the metric to (L3 / L3_READ * L2) -- L2 misses scaled by the LL read
         miss ratio. That models the whole funnel but it is an ESTIMATE, not a count, and it is
         not comparable to a grv run. Cap at P3 (P3, R0)
       → verify: `--funnel --profile grv5` returns `l3_kind: derived_estimate`, and
         `cross_architecture_comparable('l3-mpki','grv','grv5')` is False
  IF `Instance Type` maps to `spr`
  THEN → the L3 half is the generic-intel 0x2e/0x41 but L2 is OVERRIDDEN to 0x25/0x1f, so the
         two halves of the funnel ratio come from different config layers. Valid, but confirm
         the run really was Sapphire Rapids -- aperf records no profile field (P2, R0)
  IF the profile is `intel` or `icelake`
  THEN → a direct last-level-cache MISS count and the only case where the funnel ratio is a
         true survival fraction: continue to STEP 1

STEP 1 — Is it sustained, and is it the instance or one thread?
  IF the elevation is one or two isolated samples
  THEN → a load phase, a full scan, a GC cycle or cache warm-up. The template reports the PEAK,
         so a single spike produces the largest number the run ever saw. Record and STOP
         (P4, R0)
  IF only one or two `CPU{n}` series exceed 10.0
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one streaming
         thread fires it for the whole run while the Aggregate series may be well under 10: a
         thread, not the instance (P3, R0)
       → verify: the on-CPU profile names a thread doing bulk or streaming work; a targeted fix
         should move that CPU's series and barely move the aggregate
  IF every CPU is elevated roughly uniformly
  THEN → consistent with a BANDWIDTH ceiling rather than one bad access pattern, which changes
         the remediation from code to capacity. Confirm in STEP 5 before spending (P2, R0)
       → verify: reducing thread count leaves per-core l3-mpki roughly flat while total
         throughput barely moves -- the signature of a saturated memory controller

STEP 2 — Gate on measurement confidence.
  IF `mux_counter_schedule_rate` < 100
  THEN → the peak is an extrapolation by a factor of 100/R, and one distorted interval fires the
         rule. Report low-confidence and do NOT act on the magnitude (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the peak collapses, the original
         finding was a multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons contribute their own DRAM traffic, so the peak may not be the
         workload's at all (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES confirms
         the workload, one that falls confirms the daemons

STEP 3 — Is the backend actually the bottleneck? This decides whether any of it matters.
  IF `Backend-Dominated CPU Stalls` fired AND `ipc` < 0.5
  THEN → the CONFIRMED memory-bound case. DRAM latency, bandwidth, or both, are the ceiling and
         no out-of-order window hides hundreds of cycles (P1, R2)
       → verify: `stall-backend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative to
         the frontend; a falling ratio with a flat absolute means the frontend got worse
  IF `ipc` is healthy (> 2) despite the high miss rate
  THEN → the workload has enough memory-level parallelism to hide the latency. Bandwidth may
         still become the ceiling under higher load, so record it as a scaling risk (P3, R0)
  IF `Frontend-Dominated CPU Stalls` fired
  THEN → SECONDARY, and check `inst-l1-mpki`: instruction traffic flows through L3 too, so part
         of this value may be code fetch. Fix the frontend first (P4, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence
         of health since 600 pkc on both sides fires nothing, or the run is on generic `amd`
         where `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read
         the absolutes, or `ipc` alone on amd (P3, R0)

STEP 4 — Where does the funnel break? Do NOT read the three cache findings separately.
  IF `data-l1-mpki` > 20 AND `l2-mpki` > 10 AND this finding fired
  THEN → `--funnel` returns `boundary: dram`: the working set runs the whole hierarchy to DRAM.
         The expensive case, and the one that justifies a real data-structure or locality change
         rather than a tuning flag (P1, R3)
       → verify: `--funnel --data-l1 <v> --l2 <v> --l3 <v> --profile <p>` reports
         `boundary: dram`, and after the change l3-mpki falls BEFORE data-l1-mpki does
  IF `data-l1-mpki` is modest while this finding fired
  THEN → streaming or non-temporal access is bypassing the earlier levels, or the traffic is
         INSTRUCTION fetch. Check `inst-l1-mpki` before touching the data path (P2, R0)
       → verify: `inst-l1-mpki` is below its own threshold of 20; if it is not, part of this
         value is code and `INSTRUCTION_FOOTPRINT_OPTIMIZATION` applies instead
  IF the profile is AMD and `l3-mpki` EXCEEDS `l2-mpki`
  THEN → NOT a collection bug: the counters are not nested on AMD, so the DRAM-fill figure can
         legitimately exceed the L2 miss rate. Do not chase it (P3, R0)
  IF `l2_of_l1` exceeds 1.0
  THEN → more L2 misses were counted than L1 misses. Suspect PMU multiplexing, or prefetch
         traffic counted at L2 but not at L1. Treat the whole funnel as low-confidence (P4, R0)

STEP 5 — Your footprint, or someone else's bandwidth? Unique to this level.
  IF `l3-mpki` and the backend stall rate VARY between otherwise-identical runs
  THEN → external variability, most likely co-tenant DRAM bandwidth contention -- exactly what
         aperf's own message warns about. Your access pattern did not change (P3, R4)
       → verify: the same workload on a METAL instance shows a stable value across runs; if it
         still varies there, the variation is in your workload
  IF `numa_miss` or `other_node` in `numastat` is material
  THEN → remote-node access raises the cost of every miss and consumes interconnect bandwidth,
         and numastat has NO analytical rules so nothing flags it. The fix is PLACEMENT, not
         restructuring (P2, R1)
       → verify: after `numactl` pinning or interleaving, other_node falls AND stall-backend-pkc
         falls; a falling other_node with a flat stall means placement was not the constraint
  IF `number_threads` is high and per-thread footprint is material
  THEN → aggregate working set scales with concurrency, so the code may be innocent. The
         cheapest experiment in this playbook (P2, R1)
       → verify: halving the thread count reduces l3-mpki more than proportionally if footprint
         was the cause; if throughput per core rises, the machine was oversubscribed on memory

STEP 6 — Latency-bound or bandwidth-bound? They respond to DIFFERENT fixes.
  IF the access pattern is pointer chasing or dependent chains, with very low `ipc` and modest
         total traffic
  THEN → LATENCY-bound. Prefetching and more memory-level parallelism help; touching less data
         helps less (P2, R2)
       → verify: inserting prefetches at hotline-identified sites raises ipc with l3-mpki
         roughly UNCHANGED -- the misses still happen, they just stop stalling
  IF the pattern is streaming or wide scans and the memory system is saturated
  THEN → BANDWIDTH-bound. Prefetching CANNOT help: it hides latency, it does not create
         bandwidth. Only touching less data, or buying more bandwidth, moves it (P1, R3)
       → verify: l3-mpki falls in proportion to the bytes touched after the footprint change; if
         it does not, the bottleneck was latency after all
  IF `data-tlb-tw-pki` is also high
  THEN → page-table walks are THEMSELVES missing to DRAM, so huge pages help twice: fewer
         translations and shorter walks. The cheapest lever available at this level (P1, R4)
       → verify: `AnonHugePages` in `meminfo` rises, then l3-mpki AND data-tlb-tw-pki both fall;
         a rising AnonHugePages with flat metrics means the pages went to an inactive mapping

STEP 7 — What survives?
  VALID      : the reported value AS the series peak; the per-CPU split; `value = |score| × 5`;
              the funnel boundary computed with the profile's semantics; the stall split read as
              absolute pkc; numastat read by hand; and every non-PMU finding in the run
  CAUTION    : the funnel ratio on `grv`, where reads only are counted; the SPR value, whose two
              halves come from different config layers; and any conclusion drawn from a single
              run, since this is the one finding whose cause can be external
  CONFOUNDED : the value on a multiplexed run; the value on an idle-diluted run; and the value
              on a run whose thread count differs from the one being compared against
  VOID       : any survival fraction on `amd`/`milan`/`genoa`, where the counters are not nested;
              any comparison of this value across vendors, instance families or against `grv5`;
              any score comparison with `High L2 Cache Misses`, which shares the threshold but
              halves the base score; and any claim that this is the average

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF the profile cannot be identified from `Instance Type`
  THEN → STEP 0 is unanswerable, so the metric's SEMANTICS are unknown and the funnel ratio may
         be meaningless. Report the magnitude only, at P3 (P3, R0)
  IF `numastat` was not collected on a multi-socket instance
  THEN → remote-node traffic cannot be excluded, and it changes the fix from footprint to
         placement. Do not commit to a restructuring on this evidence (P3, R0)
```

## Runtime-specific consequences

An L3 miss costs the same everywhere; what differs by runtime is **how much data is live at once and
whether the runtime, rather than your code, is the one touching it**.

| Runtime | Why the misses, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | The largest real case. A copying collector *reads and writes whole regions*, so GC alone generates DRAM traffic proportional to live-set size, on top of the application's own. A rising `l3-mpki` that tracks GC cycles is the runtime, not the code | `GC` data and `java_profile` for whether the elevated intervals align with collections; `-Xmx` and the collector choice (a region-based collector touches less per cycle). Heap size and GC choice are the axes |
| **Python** | Object-per-value allocation means a "small" data set is a large scattered pointer graph, and every traversal is a DRAM tour. A NumPy or torch stack then behaves completely differently: contiguous, prefetch-friendly, bandwidth-bound rather than latency-bound | Whether the pressure tracks native-array work or pure-Python object graphs. The first responds to blocking and reuse, the second only to moving the data into arrays. Data representation is the axis |
| **.NET** | Gen-0 and gen-1 collections compact, so the young set stays dense, but the large-object heap is not compacted and fragments over a long run — a value that trends up across a long recording is the signature | `DOTNET_gcServer` and gen-0 sizing; whether the series *trends* rather than being flat-elevated. Allocation profile is the axis |
| **Perl** | Every value is an SV from arenas, with no compaction, so a large data set is scattered by construction and there is no tuning flag. Structural, not a finding | Whether the hot data can move into a packed structure or an XS/C library. Otherwise the axis is capacity: fewer threads, or a bigger instance |

**The unknown-runtime case is the default** — aperf reports no language field, and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 5: the co-tenant, NUMA and concurrency questions need no knowledge of who allocated the
memory, and they are also the three cheapest levers.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles, and the registry carries the warning:
*"Metric definition differs by architecture: LL-cache misses on arm64/intel, a derived estimate on
Graviton 5, L1 fills from DRAM on AMD. Do not compare across architectures."* It is the only cache
finding with such a note, and it is the whole story of this section.

| Profile | `L3` event | What `l3-mpki` counts | Funnel ratio valid? |
|---|---|---|---|
| `grv` | `armv8_pmuv3_0/event=0x37/` | LL-cache **read** refills — reads only | **No** — a lower bound |
| `grv5` | `(L3 / L3_READ * L2)`, `L3_READ` = `0x36` | A **derived estimate** of the whole funnel | **No** — an estimate, and incomparable to `grv` |
| `intel`, `icelake` | `cpu/event=0x2e,umask=0x41/` | LL-cache **misses** | **Yes** |
| `spr` | `0x2e`/`0x41` inherited, but `L2` overridden to `0x25`/`0x1f` | LL-cache misses, with the ratio's halves from **different config layers** | **Yes**, if the instance really is SPR |
| `amd`, `milan`, `genoa` | `cpu/event=0x44,umask=0x8/` | L1 fills **sourced from DRAM** | **No** — not a subset of `l2-mpki` |

So four profiles report something other than "L3 misses", and `grv5` is the only profile in the tree that
*overrides* this metric — a Graviton-to-Graviton comparison is void where the L1D and L2 metrics would be
fine. `cross_architecture_comparable` returns True for `l3-mpki` between `intel` and `spr` and between
`intel` and `icelake`, and False for every arm64/x86 pair **and** for `grv` vs `grv5`; and
`test_aperf_memory_hierarchy.py` re-derives all of it from `src/pmu_configs/*.json`, so it cannot drift.

**No aperf gate protects any of this.** aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate**, yet the event, the semantics, the SLC capacity and the available
DRAM bandwidth all changed at once. The capacity point applies within a vendor too — SLC and bandwidth
scale with instance size, so the same workload legitimately produces a different value on a larger instance
of the same family.

## Verification

Re-record at the **same geometry, same counter mode, same instance type and the same thread count**, then
check three things in order. First, `l3-mpki` must fall — and because the reported value is the peak, a
fix that only smooths a transient spike will show up here as a large improvement that changes nothing
real, so compare the sustained level, not the peak. Second, `stall-backend-pkc` must fall in **absolute
pkc**, not merely relative to the frontend. Third, throughput must actually improve: at this level it is
entirely possible to reduce the miss rate and gain nothing, because the misses were already overlapped.

Which metric moves tells you which limit you were on. If `l3-mpki` falls in proportion to the bytes touched,
the workload was **bandwidth**-bound and the footprint change was correct. If `ipc` rises with `l3-mpki`
roughly unchanged, it was **latency**-bound and prefetching or more memory-level parallelism did the work.
If neither moves, re-read STEP 5: a co-tenant, a remote NUMA node or the thread count was the constraint,
and none of those are fixed by touching the code.

## Do not

- **Do not treat the reported value as the run's average.** It is the series peak, and one load-phase or
  GC spike produces the largest number the run ever saw.
- **Do not compare this score with `High L2 Cache Misses`.** Same threshold (10.0), different base score
  (`Bad` −2 vs `Concerning` −1), so the same value scores twice as severely here.
- **Do not read `l3-mpki` as "L3 misses" without checking the profile.** It is LL-cache read refills on
  `grv`, a derived estimate on `grv5`, and L1 fills from DRAM on AMD — three of the four semantics are
  something else, and the registry's `architecture_note` says so.
- **Do not compute `l3-mpki / l2-mpki` as a survival fraction on AMD.** The counters are not nested
  there, so a ratio above 1.0 is legitimate rather than a bug. And **do not treat the `grv` ratio as
  complete**: writes and prefetches reaching DRAM are not counted.
- **Do not compare this value across architectures, instance families or instance sizes** — nor between
  `grv` and `grv5`. No aperf gate fires on an architecture change with matched `CPUs` and `MemTotal`.
- **Do not assume the cause is inside your instance.** Co-tenant DRAM bandwidth contention produces this
  finding with no change to your code; compare several runs, and use metal to prove it.
- **Do not apply L1-level fixes.** Struct packing does not reduce a working set that exceeds tens of
  megabytes. And **do not expect prefetching to fix a bandwidth-bound workload**: prefetching hides
  latency, it cannot create bandwidth. Establish which limit you are on first.
- **Do not act on a GC, scan-phase or warm-up spike**, and **do not act on the value when
  `mux_counter_schedule_rate` is below 100** — the peak is then an extrapolation.
- **Do not read the value as characteristic of the instance.** This template iterates every series
  including per-CPU (`processed_data_accessor.rs:104`), so one streaming thread fires it for the run. And
  **do not overlook NUMA or the thread count**: both raise this metric without any code defect, both are
  R1 to test, and `numastat` has no analytical rules so nothing flags it for you.
- **Do not optimize data footprint while the workload is frontend-bound** — and check `inst-l1-mpki`,
  since instruction traffic flows through L3 too.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:108` — `metric: "l3-mpki"`,
  `comparator: Comparator::Greater`, `threshold: 10.0`, `score: Score::Bad`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void. Note
  `High L2 Cache Misses` (`:100`) uses the **same** threshold with `Score::Concerning`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)`; with a non-zero threshold and a monotonic score
  that is the series **peak**. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — `delta = value / threshold`,
  inverted only when below 1.0, times `rule_score`. `Score::Bad = −2` at `:147`–`:157`.
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config by
  `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:750`–`:797`. `L3` is
  `event=0x37` (grv), `event=0x2e,umask=0x41` (intel, icelake, spr), `event=0x44,umask=0x8` (amd, milan,
  genoa); `grv_5_pmu_config.json` overrides the **metric** to `(L3 / L3_READ * L2) / Instructions * 1000`
  and adds `L3_READ` = `event=0x36`. `perf_stat` opts **out** of the forced first zero via
  `use_first_accumulative_value()` (`:1295`), so the first sample is real.
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) — `--funnel`
  returns the boundary, the three ratios, `l3_kind`, `l3_ratio_valid` and the per-profile caveat;
  `--select` reproduces the template's choice and confirms the peak is reported;
  `cross_architecture_comparable` decides whether two profiles may be compared.
  `test_aperf_memory_hierarchy.py` re-derives the expressions and encodings from `src/pmu_configs/`.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate
  of R% is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and
  duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `DATA_FOOTPRINT_OPTIMIZATION` (the remediation attached to this metric — reuse,
  contiguous storage, sequential access, loop splitting, prefetch placement) and
  `CPU_BACKEND_STALLS_INVESTIGATION` (which lists `l3-mpki`), in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `high-l2-cache-misses.md` and `high-l1-data-cache-misses.md` (the two levels above,
  read together via `--funnel`), `high-l1-instruction-cache-misses.md` (instruction traffic also flows
  through L3), `backend-dominated-cpu-stalls.md` (the severity gate), `data-tlb-table-walks.md` and
  `data-tlb-misses.md` (walks that themselves miss to DRAM),
  `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../kernel_config/huge-page-disabled.md`, `../cpu_utilization/underutilized-cpu.md`. Cross-cutting:
  [../GATES.md](../GATES.md), [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md),
  [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down back-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html?highlight=l3-mpki#drill-down-back-end-stalls)
- [Arm Neoverse N3 — last-level cache read MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/MPKI-metrics-for-Neoverse-N3?lang=en#md407-mpki_mg__ll_cache_read_mpki_m_MPKI)
