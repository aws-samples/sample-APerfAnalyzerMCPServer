---
rule_name: Instruction TLB Table Walks
data_type: perf_stat
data_key: inst-tlb-tw-pki
template: time_series_data_point_threshold
condition: "any(inst-tlb-tw-pki) > 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "Upon instruction TLB misses, multiple traverses in the page table were required to find the correct physical address for an instruction. The instruction footprint might be too large and cause CPU frontend stalls."
source: src/analytics/rules/perf_stat.rs:76
---

# Instruction TLB Table Walks

## What fired

**At least one** data point of `inst-tlb-tw-pki` was **greater than 0.0**.

**The threshold is zero** — any non-zero page-table-walk rate in any single sample fires this rule. Like
its three sibling TLB rules, it is among the least selective findings in aperf. The *magnitude* is the
signal, not the firing. Base score `Concerning` (−1). Single-run rule.

## The processing defect — the value understates the peak, and the ratio is not a fraction

Two independent arithmetic traps sit on this finding, and both change the number you would report.
**Trap 1 — the reported value is the worst-*scoring* sample, not the worst sample.**
`compute_finding_score` (`src/analytics/mod.rs:170`) special-cases a zero threshold:

```
if value < 1.0  →  score = rule_score            (flat, no magnitude)
else            →  score = (value - 1.0) * rule_score
```

so `|score|` is **V-shaped** — flat at 1.0 below value 1.0, zero at exactly 1.0, and only above value
2.0 does it exceed the flat branch. The template (`time_series_data_point_threshold_rule.rs:98`–`:117`)
keeps the sample with the largest `abs(finding_score)`, *not* the largest value, using `>=` so a later
tie overwrites:

| series | reports | score | the peak |
|---|---|---|---|
| `[0.40, 1.60]` | **0.40** | −1.00 | 1.60 — scores only −0.60, so it loses |
| `[0.0, 0.22, 0.31, 0.18]` | **0.31** | −1.00 | 0.31, but every sub-1.0 sample ties and `>=` takes the last |
| `[0.90, 2.00]` | **2.00** | −1.00 | 2.00 — a tie with 0.90, won by position |
| `[1.00]` | **1.00** | **−0.00** | renders **grey** with the neutral icon |

**Trap 2 — `inst-tlb-tw-pki / inst-tlb-mpki` is an escalation fraction on arm64 only.** The whole value
of this finding is the ratio against its sibling, and that ratio is a *fraction of misses that
escalated* only where the two counters are nested. On `grv` and `grv5` they are (`0x2` refill, `0x35`
walk, a walk being a consequence of a refill). On **Intel, Ice Lake, Sapphire Rapids and AMD they are
disjoint** — same event with non-overlapping umasks on Intel, distinct documented events on AMD — so
the two count mutually exclusive outcomes, the total instruction-TLB miss rate is `mpki + tw`, and the
escalation fraction is `tw / (mpki + tw)`. A raw `tw / mpki` above 1.0 is then **legitimate**, not a
collection bug. The relations are re-derived from `src/pmu_configs/*.json` by
`test_aperf_memory_hierarchy.py::test_tlb_pairings_are_derived_from_umask_bits` (16/16), so
`tlb_pressure()` refuses to run without a profile key:

```
$ python3 ../tools/aperf_memory_hierarchy.py --tlb --miss-pki 2.50 --walk-pki 3.20 \
      --profile intel --tlb-side instruction
relation: disjoint, total_misses_pki: 5.7, escalation_fraction: 0.561, thp_leverage: high
```

The same inputs on `grv` return `relation: nested` and a fraction of 1.0 with a multiplexing
caveat, because 3.20 walks out of 2.50 misses is impossible when walks are a subset.

## Reasoning

`inst-tlb-tw-pki` is "Translation Lookaside Buffer (TLB) table walks for instruction fetches per
thousand instructions. It is triggered upon a cache miss in the instruction TLB to translate
virtual instruction addresses into physical ones, and multiple traversals in the OS-built page
table were required to find the correct physical address. It indicates code size issues and poor
code locality." (`data-descriptions.ts`, `desired: "lower"`)

This is the **expensive tail** of `Instruction TLB Misses`, and the relationship between the two is
the whole point of reading this playbook rather than that one. An **ITLB miss** means the translation
was not in the L1 instruction TLB; many such misses are satisfied by the larger, shared **L2 TLB** at
a modest cost of tens of cycles. A **table walk** means the L2 TLB missed too, so the hardware must
traverse the OS page table in memory — up to **four levels of dependent memory accesses** with 4 KB
pages (five on a 5-level-paging kernel), each of which can itself miss in the data caches. A walk
that reaches DRAM at every level costs hundreds of cycles.

So `inst-tlb-mpki` measures translation pressure; `inst-tlb-tw-pki` measures translation pressure
that has **overwhelmed the entire TLB hierarchy**. A workload with high misses but few walks is being
absorbed by the L2 TLB and is comparatively cheap. **A high walk rate is the signal that huge pages
will give a real, measurable win** — a walk avoided is hundreds of cycles saved, and huge pages both
reduce the number of translations needed and shorten the walk itself, since a 2 MB page needs one
fewer level of traversal. The stall is a **frontend** stall: instruction fetch is blocked while the
walk completes, and the frontend is the pipeline's supply line, so nothing downstream can proceed.
The physical cause is the same as for ITLB misses — **hot code spanning too many pages** — produced
by very large binaries, code scattered by poor layout, JIT-generated code spread across a large code
cache, and interpreter loops jumping across a big runtime.

**Because the threshold is 0.0 the firing carries almost no information, but the silence does.**
`inst-tlb-tw-pki` is defined on all 8 PMU profiles, so an absent finding on a run that collected
`perf_stat` means the metric was missing or identically zero — a collection question first.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 3.20 (greater than the threshold of 0).
```

**Four things that sentence does not tell you.** **`3.20` is the worst-*scoring* sample, not the worst sample and not the average** (see
`The processing defect`); the peak may be higher and is not recoverable from this text. **It may be
one CPU's series** — this template iterates **every** series including per-CPU
(`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based
`perf_stat` rules which read only `Aggregate` (`:432`), so one thread with a scattered footprint
fires this for the whole run. **The value is truncated, not rounded** (`f64_to_fixed_2`,
`src/computations/mod.rs:138`), so `3.20` is anything in `[3.20, 3.21)`, and
`(greater than the threshold of 0)` is printed rather than computed. And **there is no `(n−1)/n`
dilution correction**: `perf_stat` opts out of the forced first zero via
`use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`), unlike `ena_stat` and
`cpu_utilization`, so the first sample is real.

Score math — `compute_finding_score(value, 0.0, −1)`, the `threshold == 0.0` branch:

| worst-scoring sample | score | note |
|---|---|---|
| 0.05, 0.30 | **−1.00** | flat: any value below 1.0 gives the base score |
| **1.00** | **−0.00** | score collapses to zero; renders **grey** |
| 1.60 | **−0.60** | *milder* than a 0.05 sample |
| 2.00 | **−1.00** | collides with the entire sub-1.0 range |
| 3.20 | **−2.20** | |

Above 1.0 recover the sample as `value = |score| + 1`; below 1.0 it is not recoverable, since `|score|
= 1.00` has two disjoint preimages — everything below 1.0, and exactly 2.0.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The metric is identically zero across every sample | no finding. Plausible on a small-footprint workload with THP active, so unlike its sibling this silence *can* be real — but confirm the metric exists in the run |
| The only exceeding sample is exactly 1.0 | the finding exists at score **−0.00** and renders grey with a neutral icon, sorting below every positive finding |
| The run multiplexed heavily | extrapolation alone can produce a non-zero sample. A zero threshold has **no** noise margin |
| Only one `CPU{n}` series exceeded | reported for the run; the `Aggregate` series may be benign |

## Interpretation

**Read this alongside `inst-tlb-mpki`, with the profile's set relation applied.** The escalation
fraction is the most useful number available, and it is `tw / mpki` only on arm64:

| escalation fraction | Reading |
|---|---|
| < 0.2 | Most ITLB misses are absorbed by the L2 TLB. Moderate cost however large the miss rate |
| 0.2–0.5 | Partial saturation. Huge pages help, sized on the walk figure rather than the miss figure |
| ≥ 0.5 | The TLB hierarchy is saturated; misses go all the way to page-table walks. **Huge pages are likely to give a real win** |

Absolute orientation for the walk rate itself:

| sustained value | Reading |
|---|---|
| < 0.1 | Measurement floor. Ignore |
| 0.1–1 | Mild. Cheap fixes worth trying if the frontend is dominant |
| 1–5 | Real cost — each walk is potentially hundreds of cycles |
| > 5 | Severe. Instruction footprint substantially exceeds TLB coverage; huge pages are a priority |

And the usual gates:

| elevated **and** | Reading |
|---|---|
| sustained across the series | Genuine and actionable; one isolated sample is startup, JIT or a phase transition, and is not |
| `Frontend-Dominated CPU Stalls` fired | **The confirmed case** — walks are blocking instruction supply |
| `Huge Page Disabled` also fired | **Direct cheap fix available** — THP is off at the kernel-config level |
| `Data TLB Table Walks` also fired | System-wide translation pressure; one huge-page change addresses both sides |
| `inst-l1-mpki`, `code-sparsity` also high | Instruction footprint and layout are the shared root cause |
| `l2-mpki` or `l3-mpki` also high | Each walk level is itself a memory access, so poor data-cache behaviour makes every walk more expensive |

**Known false positives:**

- **Any non-zero value fires it.** The defining condition; a walk rate of 0.01 is noise. And the
  reported value understates the peak, so a small description value does not settle it either way.
- **A single transient sample.** Process startup, dynamic linking and JIT compilation touch cold
  code across many pages; walks are guaranteed there and are a one-time cost.
- **PMU multiplexing.** With a zero threshold there is no noise margin — extrapolation error alone
  can produce a non-zero sample. If `PMU Counter Collection Multiplexing` fired, this finding is
  low-confidence by default.
- **One hot CPU.** The rule reads every per-CPU series, so a single scattered thread fires it for the
  run while the aggregate is benign.
- **Idle-diluted or kernel-heavy runs.** Background daemons execute scattered code and generate their
  own walks; and kernel text spans many pages, so if `system` time dominates, much of the walk cost is
  kernel-side and not addressable by rebuilding your application.
- **A walk rate exceeding the miss rate.** On `grv`/`grv5` that is impossible and means multiplexing
  distorted one counter. **On Intel and AMD it is expected**, because the counters are disjoint —
  do not report it as a collection defect there.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `inst-tlb-tw-pki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient, and whether one CPU or all — the description gives neither |
| `inst-tlb-mpki` | `perf_stat` | **Read together — the escalation fraction is the key number**, computed with the profile's set relation. See `Instruction TLB Misses` |
| `stall-frontend-pkc` vs `stall-backend-pkc` | `perf_stat` | **Severity gate.** Walks block instruction fetch. See `Frontend-Dominated CPU Stalls` |
| `inst-l1-mpki`, `code-sparsity`, `ipc` | `perf_stat` | Footprint size and layout are the shared root cause, and `ipc` says whether the pipeline is suffering. `code-sparsity` is **arm64 only** |
| `data-tlb-tw-pki` | `perf_stat` | If data walks are also high, translation pressure is system-wide and huge pages help both sides. See `Data TLB Table Walks` |
| `l2-mpki`, `l3-mpki` | `perf_stat` | Page-table walks are themselves memory accesses; poor data-cache behaviour makes each walk more expensive |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate — critical.** Zero threshold means no noise margin |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | **The fix check.** See `Huge Page Disabled` |
| `AnonHugePages`, `HugePages_Total`, `HugePages_Free`, `Hugepagesize` | `meminfo` | Whether huge pages are configured and actually in use |
| PageBlocks series | `memalloc` | Fragmentation preventing huge-page allocation. **No analytical rules — read manually** |
| `Kernel Version` | `systeminfo` | ≥ 6.9 supports 16 KB / 64 KB folios in addition to 2 MB pages, and 5-level paging adds a walk level |
| `user` vs `system`, `idle` | `cpu_utilization` | Application vs kernel text, and the dilution check |
| On-CPU profile, Hotline output | `perf_profile` / `java_profile`, `hotline` | Which code regions execute during elevated intervals, and instruction-address attribution (native code on metal Graviton). Both need `--profile`; **neither has analytical rules** |

## Guidance

Ordered. Steps 1–2 eliminate most firings.

1. **Read the series, not the description.** The threshold is zero, so firing alone means nothing, and
   the reported value is the worst-*scoring* sample rather than the peak. A sustained peak **< 0.1** is
   measurement floor — stop. An **isolated spike** at startup or a phase boundary is a warm-up artifact
   — stop. **Sustained** ⇒ continue, checking the per-CPU series first.

2. **Gate hard on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`) — a zero-threshold rule has no noise margin — and `avg(idle)` (`Underutilized CPU`).

3. **Compute the escalation fraction against `inst-tlb-mpki` using the profile's set relation.** This
   is the step that makes this finding worth more than its sibling, and the step where a hand-computed
   ratio is wrong on five of the eight profiles:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --tlb --miss-pki 2.50 --walk-pki 3.20 \
         --profile intel --tlb-side instruction
   relation: disjoint, total_misses_pki: 5.7, escalation_fraction: 0.561, thp_leverage: high
   ```

   A **small** fraction means the L2 TLB is absorbing most of the pressure — moderate cost, lower
   priority. A **large** fraction means the hierarchy is saturated and each walk costs hundreds of
   cycles: **the case where huge pages give a measurable win.**

4. **Confirm the frontend is the bottleneck.** Compare `stall-frontend-pkc` and `stall-backend-pkc` and
   read `ipc`. Frontend dominant with low IPC ⇒ actionable; otherwise record as secondary. On generic
   `amd` neither stall metric exists, so use `ipc` alone.

5. **Check whether huge pages are already available, and whether they can allocate.** Read
   `CONFIG_TRANSPARENT_HUGEPAGE` (`kernel_config`, see `Huge Page Disabled`), `AnonHugePages` /
   `HugePages_Total` / `Hugepagesize` (`meminfo`), and `Kernel Version` — on ≥ 6.9 the smaller folio
   sizes are available and are easier to allocate under fragmentation than 2 MB pages. If THP is off or
   unused, this is the first thing to try and it requires no rebuild. If it is *enabled* but
   `AnonHugePages` sits far below the workload's footprint and the `memalloc` PageBlocks series shows
   few high-order free blocks, the kernel cannot find contiguous memory: the fix is compaction settings
   or a restart with pre-reserved pages, not more THP configuration.

6. **Decide whether footprint reduction is also needed.** Read `inst-l1-mpki` and, on arm64,
   `code-sparsity`. If both are elevated, profile-guided layout reduces the page span itself, lowering
   walks, ITLB misses, L1I misses and branch mispredictions together.

7. **Only then remediate**, per `TLB_MISS_OPTIMIZATION` and `INSTRUCTION_FOOTPRINT_OPTIMIZATION`:
   enable THP with `echo always > /sys/kernel/mm/transparent_hugepage/enabled` (or `madvise`); on
   kernels ≥ 6.9 tune folio sizes under
   `/sys/kernel/mm/transparent_hugepage/hugepages-{16kB,64kB,2048kB}/enabled`; for `mmap`-based
   applications reserve pinned huge pages via `sysctl -w vm.nr_hugepages=X` or
   `hugepagesz=2M hugepages=512` in `/etc/default/grub`; for Java add `-XX:+UseTransparentHugePages`
   (THP ≥ `madvise`) or `-XX:+UseLargePages`. Footprint lever: `-flto`, `-Os`, AutoFDO for C/C++;
   `-XX:+TieredCompilation` and code-cache sizing for Java.

## Priority and execution risk

**Priority: P3 — Monitor** by default. A zero threshold means the firing itself ranks nothing, but this
finding starts one band above its sibling because *every* counted event here is expensive — a completed
page-table walk, not a translation that the L2 TLB absorbed. It rises to **P2 — Investigate** once the
sustained walk rate is above roughly 1 pki, and to **P1 — Act now** when the escalation fraction is at
or above 0.5 **and** `Frontend-Dominated CPU Stalls` fired, since that is the combination in which huge
pages have a quantified target — or, on the same evidence, when `Huge Page Disabled` also fired, because
a costly problem then has a configuration-only fix. It drops to **P4 — Informational** whenever the run
multiplexed, and stays at **P3 at most** when only one `CPU{n}` series is elevated.

**Execution risk: R0 — Read-only** to diagnose — the series, the per-CPU split, the escalation fraction,
the stall comparison and the THP configuration are all reads. Acting is **R4 — Infrastructure change**
for enabling THP or reserving huge pages, which changes allocation behaviour machine-wide and can fail
outright under fragmentation, and **R3 — Rebuild** for the footprint lever. Pre-reserved pages via
`vm.nr_hugepages` are the higher-risk end of R4: they take memory from the page cache permanently, so
a workload that then needs that memory regresses on a different axis.

**The score is amplified, non-monotonic, and unusable for ranking.** A sample of 2.00 and a sample
of 0.05 both score exactly −1.00; exactly 1.00 scores −0.00 and renders **grey**. **Rank on the
sustained walk rate and the escalation fraction, never on score.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `inst-tlb-tw-pki`, in any series including per-CPU, exceeded
`0.0` (`Greater 0.0`, so exactly zero does not fire).

```
STEP 0 — Does the perf_stat data exist, and is this metric defined on this profile?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `perf_stat` exists and this finding is ABSENT while `Instruction TLB Misses` FIRED
  THEN → the informative silence: misses occurred but no walk was ever counted, so the L2 TLB
         absorbed all of them. Unlike its sibling this CAN be genuine, and it means huge pages
         have little to win on the instruction side (P4, R0)
  IF BOTH this finding and `Instruction TLB Misses` are absent
  THEN → `inst-tlb-tw-pki` is defined on all 8 profiles, so two identically-zero translation
         metrics point at COLLECTION, not at clean translation (P3, R0)
  IF the finding fired
  THEN → the firing itself carries almost no information (threshold 0.0):
         continue to STEP 1

STEP 1 — Recover the real magnitude. The description does NOT give it: the reported value is
         the worst-SCORING sample, which on a zero-threshold rule is frequently the LEAST
         severe firing sample.
  IF the score is exactly -0.00 and the finding renders GREY
  THEN → the only exceeding sample was exactly 1.0 (mod.rs:170 collapses it,
         AnalyticalFindings.tsx:35 paints score==0 grey). At 1 walk per thousand instructions
         that is NOT a non-event; read it as a value of 1.0 (P3, R0)
  IF the score is exactly -1.00
  THEN → AMBIGUOUS by construction: the preimage is the whole interval below 1.0 PLUS exactly
         2.0, which differ by a factor of hundreds in cycle cost. Read the series (P4, R0)
  IF the series peak exceeds the reported value
  THEN → expected, not a bug in the report: `>=` plus the V-shaped score prefers a smaller
         sample. Use the PEAK for every branch below (P3, R0)
       → verify: `../tools/aperf_memory_hierarchy.py --select <series>` reproduces the
         template's choice; if it disagrees with the report, the series you read is not the
         series the rule saw (suspect a per-CPU series)

STEP 2 — Gate on measurement confidence. A zero threshold has NO noise margin.
  IF `mux_counter_schedule_rate` < 100
  THEN → extrapolation alone can produce a non-zero walk sample. Report low-confidence and do
         NOT act (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the value collapses toward zero the
         original finding was multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons execute scattered code and generate their own walks, so the value
         is diluted with behaviour that is not the workload's (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES
         confirms the workload, one that falls confirms the daemons
  IF only one or two `CPU{n}` series are elevated
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one
         scattered thread fires it for the whole run: a thread, not the instance (P3, R0)
       → verify: the on-CPU profile names a thread with a distinct code footprint; a targeted
         fix should move that CPU's series and barely move the aggregate

STEP 3 — Compute the escalation fraction. The set relation is VENDOR-DEPENDENT and a single
         cross-vendor `tw / mpki` formula is wrong somewhere.
  IF `Instruction TLB Misses` did NOT fire but this finding did
  THEN → on grv/grv5 that is IMPOSSIBLE, since a walk implies a refill: suspect multiplexing
         or a truncated miss value below 0.005. On Intel and AMD it is legitimate, because the
         counters are disjoint and the non-escalating half can be genuinely zero (P3, R0)
       → verify: `--tlb --profile <p> --tlb-side instruction` raises InsufficientData on the
         nested profiles for exactly this input; if it raises, fix the collection first
  IF the profile is `grv` or `grv5`
  THEN → NESTED (0x2 refill, 0x35 walk): `inst-tlb-tw-pki / inst-tlb-mpki` IS the escalation
         fraction, bounded by 1.0, and the total miss rate is the mpki figure alone (P2, R0)
       → verify: `--tlb --profile grv --tlb-side instruction` clamps a fraction above 1.0 and
         flags it; if it flags, the collection is distorted
  IF the profile is `intel`, `icelake` or `spr`
  THEN → DISJOINT (0x85 um 0x20 vs 0x1, or 0x11 um 0x20 vs 0xe on spr). Total misses is
         `mpki + tw`, the fraction is `tw / (mpki + tw)`, and a raw ratio above 1.0 is
         LEGITIMATE rather than a bug (P2, R0)
       → verify: `--tlb --profile <p> --tlb-side instruction` returns a fraction in [0, 1]; a
         hand-computed ratio above 1.0 means you used the wrong relation
  IF the profile is `amd`, `milan` or `genoa`
  THEN → DISJOINT by vendor semantics (0x84 is an L1 ITLB miss that HIT the L2 ITLB, 0x85 one
         that missed it). Same correction as Intel, derived from AMD's documentation rather
         than from umask bits (P2, R0)
       → verify: `--tlb --profile amd --tlb-side instruction` flags the derivation as `vendor`
         rather than `umask`; report that caveat to the reader
  IF the escalation fraction is >= 0.5
  THEN → the TLB hierarchy is saturated: most misses reach a full walk of 4-5 dependent memory
         references. HUGE PAGES are the primary lever, and they both remove translations and
         shorten each remaining walk by a level (P1, R4)
       → verify: `inst-tlb-tw-pki` falls FASTER than `inst-tlb-mpki` after enabling THP, since
         the walks are the tail that huge pages remove first
  IF the escalation fraction is < 0.2
  THEN → the L2 TLB absorbs most misses, so the walk cost is small however large the miss
         count. Size the THP expectation on THIS figure, not on the miss figure (P3, R0)

STEP 4 — Is the frontend actually the bottleneck? This decides whether ANY of it matters.
  IF `Frontend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: instruction supply is the bottleneck and completed page-table
         walks are among the most expensive ways to block it (P1, R4)
       → verify: `stall-frontend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative
         to the backend; a falling ratio with a flat absolute means the backend got worse
  IF `Backend-Dominated CPU Stalls` fired
  THEN → SECONDARY. Fix the backend first and re-measure. Record and STOP (P4, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence
         of health since 600 pkc on both sides fires nothing, or the run is on generic `amd`
         where `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read
         the absolutes directly, or `ipc` alone on amd (P3, R0)

STEP 5 — Is the cheap fix available, and will it allocate? MANDATORY manual check: aperf
         reports the THP kernel config but not the runtime `/sys` setting.
  IF `Huge Page Disabled` fired
  THEN → `CONFIG_TRANSPARENT_HUGEPAGE` is off at the KERNEL level, so no runtime setting can
         turn THP on: a kernel change, not an `echo` (P1, R4)
       → verify: after enabling, `AnonHugePages` in `meminfo` becomes non-zero AND
         `inst-tlb-tw-pki` falls; a rising AnonHugePages with a flat walk rate means the huge
         pages went to data, not text
  IF THP is configured but `AnonHugePages` is far below the workload's footprint
  THEN → fragmentation is preventing allocation. Check the `memalloc` PageBlocks series for
         high-order free blocks; the fix is compaction settings, boot-time reservation, or the
         smaller folio sizes on kernels >= 6.9 (P2, R4)
       → verify: AnonHugePages rises toward the footprint, and only then re-read the walk rate
  IF the fix under consideration is `vm.nr_hugepages` rather than THP
  THEN → reserved pages are taken from the page cache PERMANENTLY, so a workload that needs
         that memory regresses on a different axis. The higher-risk end of R4 (P2, R4)
       → verify: `MemAvailable` and the page-cache figures in `meminfo` after reservation, plus
         the `vmstat` swap and reclaim counters; a rise in reclaim means the reservation was
         too large

STEP 6 — Footprint or translation? This decides between a config change and a rebuild.
  IF `inst-l1-mpki` is ALSO above 20 and (on arm64) `code-sparsity` is above 0.5
  THEN → the hot code spans more pages than its SIZE requires: a layout problem. Profile-
         guided layout lowers walks, ITLB misses, L1I misses and mispredictions together
         (P2, R3)
       → verify: all of inst-tlb-tw-pki, inst-l1-mpki and branch-mpki fall together; if only
         one moves, the layout change did not address the shared cause
  IF `inst-l1-mpki` is low while the walk rate is high
  THEN → the code CACHES well but is spread across many pages: a pure TRANSLATION problem, and
         the cleanest huge-page case in this playbook (P2, R4)
       → verify: inst-tlb-tw-pki falls after THP while inst-l1-mpki stays flat -- the signature
         of a translation-only fix
  IF `l2-mpki` or `l3-mpki` is also elevated
  THEN → each walk level is itself a memory access, so a saturated data hierarchy makes every
         walk MORE expensive than the nominal 4-5 references. Fixing the data side reduces the
         walk cost without reducing the walk count (P2, R3)
       → verify: the walk rate is unchanged while stall-frontend-pkc falls -- confirming the
         walks got cheaper rather than rarer

STEP 7 — What survives?
  VALID      : the per-CPU and aggregate `inst-tlb-tw-pki` series read as magnitudes; the
              escalation fraction computed WITH the profile's set relation; the stall split
              read as absolute pkc; and every non-PMU finding in the run
  CAUTION    : the reported VALUE, which is the worst-scoring rather than the worst sample; and
              the nominal 4-5 references per walk, which is a floor and not a cost
  CONFOUNDED : the value on a multiplexed run, where a zero threshold has no noise margin; and
              on an idle-diluted run, where daemon code contributes its own walks
  VOID       : any severity claim from the SCORE, which is non-monotonic and flat below 1.0;
              any `tw / mpki` fraction computed without the set relation, which is wrong on
              five of the eight profiles; and any cross-architecture comparison of this metric

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF `Instruction TLB Misses` is absent on a NESTED profile while this finding fired
  THEN → the escalation fraction is not computable and the two counters disagree about a
         physical impossibility. Fix the collection before reading either (P3, R0)
```

## Runtime-specific consequences

A page-table walk is the same cost everywhere; what differs by runtime is **how many pages the hot
code occupies and who chose that layout**. For three of the four, the answer is the runtime.

| Runtime | Why the walks, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **.NET** | Tier-0 code is emitted, then hot methods are re-emitted at tier 1 into *different* pages, so during warm-up two copies of the hot set are live and the span is at its widest. Steady-state walks are usually much lower — a walk rate measured across warm-up is not the steady-state figure | Whether the recording covers warm-up at all. `DOTNET_TieredCompilation` and `DOTNET_TieredPGO`; a ReadyToRun image is laid out ahead of time and spans fewer pages. Layout is the axis |
| **Python** | The interpreter loop is compact and rarely walks, so a high walk rate points at the *native extension* surface — a NumPy/SciPy/torch stack is tens of megabytes of text reached through dispatch. Rarely a defect and rarely the bottleneck | Whether the walk rate tracks native-extension calls rather than Python-level work. A high rate on pure-Python code usually means the profile captured import and startup |
| **Java** | The largest real case. JIT code lands in a code cache whose default reservation (240 MB) dwarfs TLB coverage, and tiered compilation keeps tier-0 and tier-1 versions live, so the hot set is scattered by construction | `jvmArguments` for `-XX:ReservedCodeCacheSize` (packing hot code into fewer pages) and `-XX:+UseTransparentHugePages`. `java_profile` says whether the hot set is genuinely large or warm-up is short |
| **Perl** | The op tree is walked per statement, so execution jumps across the interpreter's text plus every loaded XS module. Perl is normally frontend-heavy for this reason and that is structural, not a finding | Whether hot loops can move into XS or a C library. There is no code-layout flag to tune, which makes THP relatively more attractive here than anywhere else |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is
inferred from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be
identified, stop at STEP 5: the THP question needs no knowledge of who generated the code, and it is
also the remediation that shortens each remaining walk by a page-table level rather than merely
reducing the count.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — registry `architectures` lists every one and
`architecture_note` is empty. What that silence hides is the thing this playbook is *about*: the
walk counter's relationship to the miss counter is not the same relation on every vendor, so the one
number this finding exists to produce is computed differently per profile.

| Profile | `Instruction_TLB_TW` encoding | Relation to `Instruction_TLB` | Derived from |
|---|---|---|---|
| `grv`, `grv5` | `armv8_pmuv3_0/event=0x35/` | **NESTED** in `0x2`: a walk follows a refill, so `tw / mpki ≤ 1` | vendor (Arm ARM) |
| `intel`, `icelake` | `cpu/event=0x85,umask=0x1/` | **DISJOINT** from `0x85` umask `0x20` — same event, non-overlapping umasks | umask bits |
| `spr` | `cpu/event=0x11,umask=0xe/` — refreshed by the SPR override | **DISJOINT** from `0x11` umask `0x20`; `0xe` is a multi-bit page-size breakdown | umask bits |
| `amd`, `milan`, `genoa` | `cpu/event=0x85,umask=0xf/` | **DISJOINT** from `0x84`: AMD documents `0x84` as an L1 ITLB miss that HIT the L2 ITLB and `0x85` as one that missed | vendor docs |

Note the collision hazard when reading raw configs: **`0x85` is the instruction-TLB *walk* event on
AMD and the instruction-TLB *miss* event on generic Intel.** The umask relations are re-derived from
`src/pmu_configs/*.json` by `test_aperf_memory_hierarchy.py` (16/16 pairings), so they cannot drift
silently; the two vendor-derived rows are flagged as such because the config alone cannot settle them.

**The walk depth is not a constant either.** 4-level paging gives up to four dependent references per
walk and a 5-level-paging kernel gives five, which is why `PAGE_TABLE_LEVELS = (4, 5)` makes the
module report a range rather than a number. aperf collects no page-table-depth field, so **the
per-walk cost is never observable from a report** — hence the refusal to convert this metric into a
cycle budget. Only `stall-backend-pkc` and `stall-frontend-pkc` carry a real cycle cost, and they
attribute it to the pipeline side, not to the walk.

**Sapphire Rapids refreshed this side and not the other.** The SPR override moves the instruction
pair to `0x11` and `L2` to `0x25`, and adds `data-rd-tlb-*` / `data-st-tlb-*` on `0x12` / `0x13` —
while leaving the *data* TLB pair on the inherited `0x8`. So this playbook covers the side SPR
updated; `data-tlb-table-walks.md` covers the one it did not. Finally, aperf has no architecture
field and no rule compares `Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an
Intel→Graviton comparison with matched `CPUs` and `MemTotal` fires **no gate**, yet the event, the
set relation, the TLB geometry and the page size all changed.

## Verification

Apply the fix and re-record at the **same geometry, same counter mode, and same instance type**, then
check three things in order. First, `AnonHugePages` in `meminfo` must actually have risen — an
unchanged figure means the setting was accepted and the allocation failed, so nothing was tested.
Second, `inst-tlb-tw-pki` should fall **faster** than `inst-tlb-mpki`: huge pages remove the
escalating tail first, so a run where both fall proportionally suggests something else changed.
Third, `stall-frontend-pkc` must fall in **absolute pkc**, not merely relative to the backend.

If the walk rate falls and the frontend stall does not, the walks were not the frontend's constraint
and STEP 6's footprint branch is still open. If `inst-tlb-tw-pki` falls but the finding **persists**,
that is expected: with a zero threshold the rule fires until the metric is identically zero. This
finding therefore **cannot be verified by its own presence or by its score** — a materially improved
run still fires it, and a worse run can score milder. Verify on the magnitude, the escalation
fraction, and the absolute stall figure.

## Do not

- **Do not treat the firing itself as a problem.** The threshold is 0.0, so its presence ranks
  nothing. Its *silence* is the informative case here — and unlike its sibling, a genuine silence is
  plausible: it means the L2 TLB absorbed every miss.
- **Do not treat the reported value as the worst sample, or as the average.** It is the
  worst-**scoring** sample: `[0.40, 1.60]` reports `0.40`, and a score tie is broken by `>=` in
  favour of whichever came last.
- **Do not rank severity by score.** A sample of 2.00 and one of 0.05 both score exactly −1.00 while
  differing by a factor of hundreds in cycle cost, and exactly 1.00 scores −0.00 and renders **grey
  with a neutral icon**.
- **Do not compute `inst-tlb-tw-pki / inst-tlb-mpki` without the profile's set relation.** The
  counters are nested only on `grv`/`grv5`. On Intel and AMD they are disjoint, so the total miss
  rate is `mpki + tw` and the escalation fraction is `tw / (mpki + tw)`.
- **Do not report a walk rate above the miss rate as a collection bug on Intel or AMD.** There it is
  expected, because the counters are disjoint. On `grv`/`grv5` it *is* impossible and means
  multiplexing distorted one counter.
- **Do not read this finding in isolation from `inst-tlb-mpki`.** The escalation fraction is what
  tells you whether the TLB hierarchy is saturated, and that is what determines whether huge pages
  will help.
- **Do not convert this metric into a cycle budget.** The walk depth is 4 or 5 levels depending on
  the kernel's paging mode, each level's latency depends on where it hits in the data caches, and
  aperf reports neither. `stall-frontend-pkc` is the only real cycle figure available.
- **Do not act on a non-zero value when `mux_counter_schedule_rate` is below 100.** A zero-threshold
  rule has no noise margin, and extrapolation alone can fire it. And **do not read the value as
  characteristic of the instance**: this template iterates every series including per-CPU
  (`processed_data_accessor.rs:104`), so one scattered thread fires it for the whole run.
- **Do not enable huge pages reflexively.** They cost allocation latency, can fail outright under
  fragmentation, and waste memory when partially used — an R4 change. `vm.nr_hugepages` is worse
  still: reserved pages leave the page cache permanently.
- **Do not confuse this with `Data TLB Table Walks`.** Separate TLBs, separate causes — code
  footprint vs data footprint — though the same huge-page fix helps both. And **do not optimize
  either while the workload is backend-bound.**
- **Do not compare this metric across architectures.** The event differs on every vendor, `0x85`
  means *walk* on AMD and *miss* on generic Intel, and no aperf gate fires on an architecture change
  with matched `CPUs` and `MemTotal`.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:76` — `metric: "inst-tlb-tw-pki"`,
  `comparator: Comparator::Greater`, `threshold: 0.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` —
  the selection loop keeps the largest `abs(finding_score)` using `>=`, so a later tie wins and the
  reported value is the worst-**scoring** sample. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `threshold == 0.0` branch at
  `:170` returns the flat `rule_score` below value 1.0 and `(value − 1.0) * rule_score` above, making
  `|score|` V-shaped. `Score::Concerning = −1` at `:147`–`:157`. A score of exactly `0` is painted grey
  with the neutral icon by `getFindingColor` and `FindingIcon`
  (`src/report_frontend/src/components/analytics/AnalyticalFindings.tsx:35`).
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config
  by `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:765`–`:797`.
  `Instruction_TLB_TW` is `event=0x35` (grv, grv5), `event=0x85,umask=0x1` (intel, icelake),
  `event=0x11,umask=0xe` (spr — refreshed), `event=0x85,umask=0xf` (amd, milan, genoa). `perf_stat`
  opts **out** of the forced first zero via `use_first_accumulative_value()` (`:1295`).
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) — `--tlb`
  returns the corrected total and escalation fraction for the profile and side and raises on the
  impossible nested case; `--select` reproduces the template's selection.
  `test_aperf_memory_hierarchy.py` re-derives all 16 TLB pairings from the umask bits and ports the
  selection loop independently.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule
  rate of R% is an extrapolation factor of `100/R`. Grouped is the default
  (`src/data_collection.rs:379`) and duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `TLB_MISS_OPTIMIZATION` (exact THP/folio/reserved-page commands) and
  `CPU_FRONTEND_STALLS_INVESTIGATION` (which lists `inst-tlb-tw-pki`), in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `instruction-tlb-misses.md` (the non-escalating half),
  `data-tlb-table-walks.md` (the data side, on the encoding SPR did *not* refresh),
  `frontend-dominated-cpu-stalls.md` (the severity gate), `high-l1-instruction-cache-misses.md`,
  `high-code-sparsity.md`, `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../kernel_config/huge-page-disabled.md`, `../cpu_utilization/underutilized-cpu.md`.
  Cross-cutting: [../GATES.md](../GATES.md), [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md),
  [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down front-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-front-end-stalls)
- [Arm Neoverse N3 — ITLB MPKI metric group](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/MPKI-metrics-for-Neoverse-N3?lang=en#md407-mpki_mg__itlb_mpki_m_MPKI)
- [LWN — large folios](https://lwn.net/Articles/937239/)
