---
rule_name: High L1 Instruction Cache Misses
data_type: perf_stat
data_key: inst-l1-mpki
template: time_series_data_point_threshold
condition: "any(inst-l1-mpki) > 20.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "This indicates the working-set code footprint is large and spilling out of the fastest cache on the processor. This can cause CPU frontend stalls."
source: src/analytics/rules/perf_stat.rs:60
---

# High L1 Instruction Cache Misses

## What fired

**At least one** data point of `inst-l1-mpki` was **greater than 20.0** L1 instruction-cache misses per
thousand instructions, in **any** series including per-CPU. A single sample anywhere in the recording is
enough — the average may be far below the threshold.

Base score `Concerning` (−1). Single-run rule.

## The collection gap — the discriminator this playbook needs exists on 2 of 8 profiles

The central question for this finding is **layout or capacity**: is the hot code genuinely bigger than
L1I, or small enough but scattered so each 64-byte fetch carries mostly cold bytes? Those have different
fixes at different costs, and aperf has exactly one metric that answers it — `code-sparsity`. That metric
is defined **only** in `grv_pmu_config.json` (`Code_Sparsity` = `armv8_pmuv3_0/event=0x11c/`), inherited
by `grv5`. On the six x86 profiles it does not exist:

```
rule_can_fire('High Code Sparsity', 'grv')   → True      rule_can_fire(…, 'intel')  → False
rule_can_fire('High Code Sparsity', 'grv5')  → True      rule_can_fire(…, 'amd')    → False
```

So on Intel or AMD, **`High Code Sparsity` cannot fire and its absence is not evidence.** STEP 4 below is
structurally unanswerable from aperf data on six of the eight profiles, and the substitute — infer layout
pressure from `branch-mpki` and `inst-tlb-mpki` moving together — is weaker and indirect. This is a
collection gap, not a workload fact, and it is the single most consequential thing to know before reading
this finding on x86.

**The counter itself also differs in kind, not only encoding.** The expression is
`L1_Instructions / Instructions * 1000` on five profiles and `L1_Instruction_Misses / …` on the three AMD
ones, and none of the three resolutions is a demand-miss count:

| Profiles | Config entry and event | What the hardware counts |
|---|---|---|
| `grv`, `grv5` | `L1_Instructions` = `armv8_pmuv3_0/event=0x1/` | L1I cache **refills** — lines brought into L1I |
| `intel`, `icelake`, `spr` | `L1_Instructions` = `cpu/event=0x24,umask=0xe4/` | The **all-code-read** encoding of the L2 request event: every L2 code-read request, demand **and prefetch** |
| `amd`, `milan`, `genoa` | `L1_Instruction_Misses` = `cpu/event=0x60,umask=0x10/` | An L2 request-group counter for instruction-cache **fill requests** |

On Intel the umask deliberately combines the code-read sub-events, so instruction **prefetch** traffic is
counted alongside demand fetch — a well-behaved next-line prefetcher raises this metric while *improving*
frontend throughput. On arm64 and AMD the count is fill traffic, which merges concurrent misses to the same
line and is therefore a **lower bound** on demand misses. In both directions the metric is best read as
**instruction fetch traffic per thousand instructions**, not as a miss rate.

**What is *not* defective:** the threshold is non-zero, `compute_finding_score` is monotonic and the
template reports the **series peak** — verified, `--select 25 12 45 30 --threshold 20 --rule-score -1`
selects `45.0`. Unlike the four zero-threshold TLB rules, the value in the description is the maximum.
Within a vendor the encodings are stable, so `cross_architecture_comparable('inst-l1-mpki','intel','spr')`
is **True** — this metric has no SPR-refresh problem, unlike `l2-mpki`.

## Reasoning

`inst-l1-mpki` is "Level 1 instruction cache misses per thousand instructions indicating instruction fetch
efficiency and code locality patterns" (`data-descriptions.ts`, `desired: "lower"`).

L1I is the CPU's fastest source of code — typically 32–64 KB, hit in a handful of cycles. Every instruction
the core executes must first be fetched from it. When the fetch misses, the frontend waits on L2 (tens of
cycles) or further out, and the execution units starve. This is pure **frontend** cost: the machine knows
what to do next but cannot get the bytes. It is also the harder half of the pipeline to hide — an
out-of-order core absorbs data-side latency behind other work, but it cannot execute instructions it has
not fetched, which is why an L1I problem often costs more than a numerically larger L1D one.

Above 20 MPKI the code being executed does not fit in the fastest cache. Two mechanisms produce that:

1. **Capacity** — the hot code is genuinely larger than L1I. Big binaries, heavy C++ templating, deep
   inlining, large generated code, JIT-compiled methods, interpreter dispatch loops.
2. **Layout** — the hot code is *small enough* but scattered across many cache lines and pages, so each
   fetch brings in mostly-cold bytes. Every wasted byte in a line is wasted capacity.

The distinction matters because layout problems are cheap to fix (linker ordering, PGO/FDO) and capacity
problems are not (`-Os`, restructuring, reducing inlining) — and layout is frequently the real cause.

| Cause | Signature | Lever |
|---|---|---|
| **Scattered hot code** | `code-sparsity` > 0.5 (arm64), or `branch-mpki` and `inst-tlb-mpki` elevated together | Profile-guided layout / AutoFDO. Improves L1I, branches and ITLB at once — the best ratio here |
| **Genuine code bloat** | Sparsity low, value still high; large binary; deep inlining | `-Os`, `-flto`, less inlining and templating |
| **JIT code-cache churn** | Java or NodeJS; `code cache full`; recompilation storms | Size the code cache. See the runtime table |
| **Interpreter dispatch** | Python, Perl, a bytecode loop | Structural, not a defect. Move hot work into native code |
| **Kernel text** | `system` time dominates | Not recompilable. Reduce syscall rate instead |
| **Cold-start fetch** | The first samples only | Not a defect at all |

Note what this metric is *not*: misses **per thousand instructions**, not per fetch. A workload with high
instruction density in tight loops shows a low value even with a mediocre hit rate, and vice versa — and
because the counter measures fill or request traffic (above), no hit rate is recoverable from it at all.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

The comparator renders from its `strum` string, here `"greater than"`:

```
At least one data point in aperf_record is 24.00 (greater than the threshold of 20).
```

`24.00` **is** the series peak — the template scans every value and keeps the one with the largest absolute
score. **It is not the average.** A run that touched 24 MPKI once during startup reports identically to one
that sat at 24 MPKI throughout, so reading the series is the difference between "ignore" and "restructure
the binary". **It may also be one CPU's series**: this template iterates **every** series including per-CPU
(`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based `perf_stat`
rules that read only `Aggregate` (`:432`). The value is **truncated, not rounded** (`f64_to_fixed_2`,
`src/computations/mod.rs:138`), so `24.00` is anything in `[24.00, 24.01)`. And there is **no
`(n−1)/n` dilution correction**: `perf_stat` opts out of the forced first zero via
`use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`) — which matters here more than for any
other metric in the family, because the first interval is exactly when cold-code fetch peaks.

Score math — `compute_finding_score(value, 20.0, −1)`. The value always exceeds the threshold, so no
inversion applies and the score is linear in it:

| worst sample | score |
|---|---|
| 24.0 | `(24/20) × −1` = **−1.20** |
| 40.0 | `(40/20) × −1` = **−2.00** |
| 60.0, then 120.0 | `(60/20) × −1` = **−3.00**, `(120/20) × −1` = **−6.00** |

Recover the peak as `value = |score| × 20`. The base score is only `Concerning` (−1), so this finding
sorts **low** in the Analytical Findings panel however severe the value; position is not importance. Note
`High Code Sparsity` uses `Bad` (−2) with a threshold of 0.5, so the two findings' scores are on completely
different scales and cannot be ranked against each other.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The peak sits at or below 20.0 | no finding. On arm64/AMD that is weaker than it looks — fill counting merges concurrent misses |
| Only one `CPU{n}` series exceeded | reported for the whole run; the `Aggregate` series may be well under 20 |
| The run multiplexed heavily | the peak is an extrapolation, and one distorted interval is sufficient to fire |
| The profile is x86 | `High Code Sparsity` **cannot fire**, so the layout-vs-capacity question has no direct answer in the report |
| The profile is `intel`/`icelake`/`spr` | instruction **prefetch** is counted, so a good prefetcher inflates the value |
| Only the first interval is elevated | still reported, at full magnitude — `perf_stat` keeps the first sample |

## Interpretation

| sustained value | Reading |
|---|---|
| 20–30 | Marginally over threshold. Check whether it is sustained before doing anything |
| 30–60 | Real instruction-fetch pressure when sustained |
| > 60 | Severe — the frontend is spending a large share of cycles fetching code |

Then the questions that decide whether to act:

| `inst-l1-mpki` high **and** | Reading |
|---|---|
| sustained across the series | Genuine footprint problem. Actionable |
| one or two isolated samples | Startup, JIT, or a phase transition. Not actionable |
| `Frontend-Dominated CPU Stalls` fired | **The confirmed case** — instruction fetch is a leading contributor to the bottleneck |
| `Backend-Dominated CPU Stalls` fired | Real but secondary. Fix the backend first |
| `ipc` healthy (> 2) | The core is absorbing it. Low priority |
| `code-sparsity` > 0.5 (arm64 only) | **Layout**, not capacity. Fix layout — cheaper, and it fixes several findings at once |
| `code-sparsity` low but this still high | Genuine **capacity**. Shrink the code itself |
| `inst-tlb-mpki` non-zero too | Footprint spans many pages as well as many lines. Huge pages help the translation half |
| `branch-mpki` high too | On x86 the best available layout proxy: scattered code degrades prediction and fetch together |
| `l2-mpki` high too | Part of that L2 traffic is **code**, so the data-side playbooks will mis-attribute it |
| `system` time dominates | Much of the missing text is kernel and cannot be recompiled |

**Known false positives — check these before changing build flags:**

- **A single transient sample.** The dominant false positive for every
  `time_series_data_point_threshold` rule. One spike fires it; the steady state may be fine.
- **Startup, class loading, dynamic linking.** Cold code is fetched exactly once and always misses. The
  first samples of nearly every run show elevated `inst-l1-mpki`, and `perf_stat` keeps the first sample
  rather than zeroing it.
- **JIT compilation events.** Freshly compiled code is cold by definition, and recompilation invalidates
  the previous copy. Java and NodeJS workloads spike on every significant compilation.
- **Phase transitions.** Moving between distinct stages of work (load → query, batch boundary) executes a
  different code region that is initially cold.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, the peak is extrapolated — and
  because the rule fires on the single worst sample, one distorted interval is enough. A common
  combination.
- **Idle-diluted run.** If `Underutilized CPU` fired, samples mix workload with background-daemon code,
  which has its own cold-fetch profile. **One hot CPU** is the same class: the rule reads every per-CPU
  series, so one thread with a large code footprint fires it while the aggregate is benign.
- **Interpreted or VM workloads.** Dispatch loops plus a large runtime legitimately stress L1I. Expected,
  not defective — and so are **kernel-heavy workloads**: if `system` time dominates, much of the missing
  code is kernel text you cannot recompile.
- **Instruction prefetch on `intel`/`icelake`/`spr`.** The `0xe4` umask counts code-read prefetches, so an
  effective prefetcher raises the metric while improving throughput.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `inst-l1-mpki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient; whether it coincides with startup or a phase change; per-thread concentration |
| `code-sparsity` | `perf_stat` | **The key discriminator: layout vs capacity** — and it exists on `grv`/`grv5` **only**. See `High Code Sparsity` |
| `stall-frontend-pkc` vs `stall-backend-pkc`, `ipc` | `perf_stat` | **Severity gate.** L1I misses cost frontend cycles. See `Frontend-Dominated CPU Stalls`; `ipc` says whether the pipeline is suffering |
| `branch-mpki` | `perf_stat` | A shared root cause — and on x86 the best available **proxy** for the layout question. See `High Branch Mispredictions` |
| `inst-tlb-mpki`, `inst-tlb-tw-pki` | `perf_stat` | Whether the footprint also exceeds ITLB coverage — an independent, cheaper huge-page fix. See `Instruction TLB Misses` |
| `l2-mpki` | `perf_stat` | L2 carries both halves, so a high value here means part of that finding is code. See `High L2 Cache Misses` |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ the peak may be an extrapolation artifact |
| `user` vs `system` | `cpu_utilization` | Whose code is missing — application or kernel |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| `Instance Type` | `systeminfo` | The **only** clue to which PMU profile — and therefore whether `code-sparsity` could exist at all, and whether prefetch is counted |
| On-CPU profile | `perf_profile` / `java_profile` | Which code regions execute when the misses occur. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | Instruction-address-level attribution. Native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |
| `Excessive Time in Symbol` | `java_profile` | Names the hot method whose compiled footprint to inspect |
| `jvmArguments`, `GC` | `java_profile` | Code-cache sizing and tiered-compilation flags; whether spikes align with compilation |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | THP can back text pages on newer kernels, reducing the translation half. See `Huge Page Disabled` |

## Guidance

Ordered. Step 1 disposes of most firings of this rule; step 4 is the highest-leverage step and the one the
profile may not let you take.

1. **Read the `inst-l1-mpki` series before anything else.** The description gives you one sample.
   **Isolated spike(s)**, especially at the start of the run or aligned with a JIT or phase event ⇒ report
   as a warm-up artifact and stop; optionally re-scope to steady state and confirm the finding disappears.
   **Sustained above 20** ⇒ continue. Check per-CPU too: a single hot CPU points at one thread with a large
   code footprint and a much narrower fix.

2. **Gate on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`). Because this rule fires on the single worst sample, one distorted interval is
   sufficient — multiplexing is a materially higher risk here than for average-based rules. Also check
   `avg(idle)` (`Underutilized CPU`).

3. **Confirm the frontend is the bottleneck.** Compare `stall-frontend-pkc` and `stall-backend-pkc`, and
   read `ipc`. Frontend dominant with low IPC ⇒ actionable. Backend dominant, or healthy IPC ⇒ record as a
   secondary observation and address the backend or stop. On generic `amd` neither stall metric exists, so
   use `ipc` alone.

4. **Decide layout vs capacity — the highest-leverage step, and check first that you can.** Read
   `Instance Type`. On **`grv`/`grv5`** read `code-sparsity`: **> 0.5** ⇒ the hot code is scattered, each
   fetched line carries cold bytes, and profile-guided layout typically improves `branch-mpki` and
   `inst-tlb-mpki` at the same time; **low with `inst-l1-mpki` still high** ⇒ genuine capacity, so reduce
   the footprint itself. On **any x86 profile** `code-sparsity` does not exist and `High Code Sparsity`
   cannot fire — use `branch-mpki` and `inst-tlb-mpki` rising together as an indirect layout proxy, and
   record the conclusion as inferred rather than measured.

5. **Check the translation side.** If `inst-tlb-mpki` or `inst-tlb-tw-pki` is non-zero, the footprint also
   exceeds ITLB coverage. That has an independent and cheap fix — huge pages for text, per
   `TLB_MISS_OPTIMIZATION` — which does not address L1I capacity. Apply both if both apply.

6. **Check whether this finding is inflating a data-side one.** If `l2-mpki` is also elevated, part of that
   value is instruction fetch, and `High L2 Cache Misses` will read as a data-footprint problem it is not.
   Establishing the split here prevents work on the wrong half.

7. **Attribute to code.** With `--profile`, find which functions and regions execute during the elevated
   intervals. For native code on metal Graviton, `hotline` gives instruction-address resolution. Determine
   whether the code is yours, a library's, the runtime's or the kernel's — the remediation differs
   completely, and for kernel text there is no build-flag answer at all.

8. **Only then remediate**, per `INSTRUCTION_FOOTPRINT_OPTIMIZATION`. **C/C++**: `-flto` and `-Os`, and
   [AutoFDO](https://gcc.gnu.org/wiki/AutoFDO/Tutorial) for profile-guided hot/cold splitting and linker
   ordering; consider reducing aggressive inlining and template instantiation, both of which multiply code
   size. **Java**: `-XX:+TieredCompilation`, and size the code cache with
   `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M` then tune — `code cache full` messages mean
   it must grow, and an undersized code cache causes repeated recompilation, a direct cause of *sustained*
   L1I misses rather than a startup spike.

## Priority and execution risk

**Priority: P2 — Investigate** by default. The threshold of 20.0 is meaningful, the reported value is the
true peak, and frontend stalls are harder for the core to hide than backend ones — but `Concerning` (−1)
is the right weight because the single most common cause is cold-code fetch, which is not a defect. It
rises to **P1 — Act now** when the elevation is sustained, `Frontend-Dominated CPU Stalls` fired, and
either `code-sparsity` exceeds 0.5 or the JIT code cache is undersized — all three cases have a known,
bounded fix. It drops to **P3 — Monitor** when `ipc` is healthy, when the workload is interpreted or
kernel-dominated (structural, not fixable by layout), when only one `CPU{n}` series is elevated, or when
the run is on x86 where the layout-vs-capacity question cannot be answered and any remediation is a guess.
It drops to **P4 — Informational** whenever the run multiplexed, and whenever the elevation is confined to
startup, class loading or a compilation burst.

**Execution risk: R0 — Read-only** to diagnose: the series, the per-CPU split, `code-sparsity`, the stall
comparison, the profile and hotline output are all reads. **R1 — Config change** for JVM code-cache and
tiered-compilation flags, which are restart-reversible and are the cheapest real fix in this playbook.
**R3 — Rebuild** for the compiler levers — `-flto`, `-Os`, AutoFDO, reduced inlining — which change the
binary and need re-validation rather than just re-measurement; treat AutoFDO as R3 even though it changes
no source, because the layout it produces is profile-dependent and can regress an unrepresentative
workload. **R4 — Infrastructure change** for huge pages backing text.

**The score is monotonic and comparable across runs of this same rule** — `value = |score| × 20` recovers
the peak exactly — and within a vendor the encodings are stable, so `intel`/`icelake`/`spr` compare
cleanly, unlike `l2-mpki`. It is **not** comparable across vendors, and not comparable with
`High Code Sparsity` (threshold 0.5, base score `Bad`).

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `inst-l1-mpki`, in any series including per-CPU, exceeded `20.0`
(`Greater 20.0`). The reported value is the series peak — verified, unlike the four zero-threshold TLB
rules.

```
STEP 0 — Does the data exist, and CAN the layout question be answered on this profile?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `Instance Type` maps to any x86 profile (intel, icelake, spr, amd, milan, genoa)
  THEN → `code-sparsity` is NOT DEFINED there, so `High Code Sparsity` cannot fire and its
         absence says nothing about code layout. STEP 4's discriminator is unavailable and any
         layout conclusion is INFERRED, not measured (P3, R0)
       → verify: `rule_can_fire('High Code Sparsity', '<profile>')` returns False; use branch-mpki
         and inst-tlb-mpki rising together as the proxy, and label the conclusion inferred
  IF `Instance Type` maps to `intel`, `icelake` or `spr`
  THEN → the counter is the ALL-CODE-READ umask 0xe4, which includes instruction PREFETCH, so an
         effective prefetcher inflates this metric while improving throughput. Encodings are
         identical across the three, so those runs ARE mutually comparable (P2, R0)
       → verify: `cross_architecture_comparable('inst-l1-mpki','intel','spr')` returns True; if
         the frontend stall metric is flat while this value is high, suspect prefetch
  IF `Instance Type` maps to `grv` or `grv5`
  THEN → the counter is L1I REFILLS (0x1) and `code-sparsity` EXISTS, so this is the only profile
         family where the layout question is directly answerable: continue to STEP 1 (P2, R0)

STEP 1 — Is it sustained, or is it cold code?
  IF the elevation is confined to the FIRST interval or the first few
  THEN → cold-code fetch at process start, class loading or dynamic linking. It always misses, it
         is a one-time cost, and `perf_stat` keeps the first sample rather than zeroing it. Record
         and STOP (P4, R0)
       → verify: re-record with `--time-range` excluding the startup window; the finding should
         disappear entirely rather than shrink
  IF the elevation aligns with JIT compilation or a phase boundary
  THEN → freshly compiled or newly entered code is cold by definition. Not actionable UNLESS the
         bursts RECUR, which is the code-cache-churn case in STEP 5 (P4, R0)
       → verify: the java_profile compilation timeline or the phase markers line up with the
         elevated intervals; if bursts repeat throughout, go to STEP 5
  IF only one or two `CPU{n}` series exceed 20.0
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one thread with
         a large code footprint fires it for the whole run while the Aggregate series may be well
         under 20 (P3, R0)
       → verify: the on-CPU profile names that thread; a targeted fix should move its series and
         barely move the aggregate
  IF the elevation is sustained across the run
  THEN → a genuine instruction-footprint problem: continue to STEP 2 (P2, R0)

STEP 2 — Gate on measurement confidence.
  IF `mux_counter_schedule_rate` < 100
  THEN → the peak is an extrapolation by a factor of 100/R, and because this rule fires on the
         single worst sample one distorted interval is enough. Report low-confidence and do NOT
         act on the magnitude (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the peak collapses, the original
         finding was a multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → samples mix workload code with background-daemon code, which has its own cold-fetch
         profile, so the peak may not be the workload's (P4, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES confirms
         the workload, one that falls confirms the daemons

STEP 3 — Is the FRONTEND actually the bottleneck?
  IF `Frontend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: instruction fetch is starving the execution units, and unlike a data
         miss the core cannot hide it behind other work (P1, R0)
       → verify: `stall-frontend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative to
         the backend; a falling ratio with a flat absolute means the backend got worse
  IF `Backend-Dominated CPU Stalls` fired
  THEN → real but SECONDARY. Fix the backend first -- but read STEP 6, because part of the L2
         traffic that backend playbook is reasoning about may be this finding's code fetch
         (P3, R0)
  IF `ipc` is healthy (> 2)
  THEN → the core is absorbing the fetch latency. Low priority; record and stop unless STEP 5
         finds code-cache churn (P3, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence of
         health since 600 pkc on both sides fires nothing, or the run is on generic `amd` where
         `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read the
         absolutes, or `ipc` alone on amd (P3, R0)

STEP 4 — LAYOUT or CAPACITY? The highest-leverage branch, available on arm64 only.
  IF `code-sparsity` > 0.5 (grv/grv5 only)
  THEN → LAYOUT: the hot code is scattered and each fetched line carries cold bytes, so the code
         may be small enough already. Profile-guided layout (AutoFDO, linker ordering) is the fix
         and it improves branch-mpki and inst-tlb-mpki at the same time (P1, R3)
       → verify: code-sparsity, inst-l1-mpki, branch-mpki and inst-tlb-mpki ALL fall after the
         layout change; if only code-sparsity moves, the hot set was mis-identified by the profile
  IF `code-sparsity` is below 0.5 and this finding still fired (grv/grv5)
  THEN → genuine CAPACITY: the hot code is simply bigger than L1I. `-Os`, `-flto`, less inlining
         and less template instantiation. More expensive and lower-yield than the layout fix
         (P2, R3)
       → verify: binary text size falls AND inst-l1-mpki falls; a size reduction with no metric
         movement means the shrunk code was not the hot code
  IF the profile is x86 AND `branch-mpki` and `inst-tlb-mpki` are elevated together
  THEN → INFERRED layout pressure: scattered code degrades prediction, fetch and translation
         together. AutoFDO is still the right first attempt, but the evidence is indirect and the
         result must be measured rather than assumed (P2, R3)
       → verify: all three metrics fall together after the layout change; if only inst-l1-mpki
         moves, the cause was capacity and the inference was wrong
  IF the profile is x86 AND `branch-mpki` is low
  THEN → the layout hypothesis has no support and the capacity hypothesis has no confirmation
         either. Attribute with `--profile` first (STEP 7) rather than changing build flags
         (P3, R0)

STEP 5 — Is the footprint the runtime's rather than the code's?
  IF the workload is Java or NodeJS AND the bursts RECUR through the run
  THEN → JIT CODE-CACHE CHURN: an undersized cache evicts and recompiles, so cold code is
         continually re-fetched. This is the cheapest real fix in the playbook -- size the cache
         and set tiered compilation (P1, R1)
       → verify: `code cache full` messages stop, compilation counts fall, and inst-l1-mpki
         becomes flat rather than bursty; a flat-but-still-high value means real capacity
  IF the workload is interpreted (Python, Perl, a bytecode loop)
  THEN → dispatch loops plus a large runtime legitimately stress L1I. STRUCTURAL, not a defect,
         and no build flag of yours applies. The axis is moving hot work into native code
         (P3, R3)
       → verify: after moving the hot loop into a native extension, inst-l1-mpki falls AND
         throughput rises; if only the metric moves, the loop was not the bottleneck
  IF `system` time dominates `cpu_utilization`
  THEN → much of the missing text is KERNEL and cannot be recompiled. The lever is reducing the
         syscall or interrupt rate, not instruction layout (P3, R2)
       → verify: the on-CPU profile attributes the elevated intervals to kernel symbols; after
         reducing syscall volume, inst-l1-mpki falls with no build change

STEP 6 — Is this finding inflating a data-side one?
  IF `High L2 Cache Misses` also fired
  THEN → L2 carries BOTH halves, so part of that value is code fetch and reading it as a data
         footprint problem mis-attributes the cause. Establish the split before anyone acts on the
         data side (P2, R0)
       → verify: after the instruction-side fix, l2-mpki falls together with inst-l1-mpki; if
         l2-mpki barely moves, the L2 traffic really was data
  IF `Instruction TLB Misses` or `Instruction TLB Table Walks` also fired
  THEN → the footprint exceeds ITLB coverage as well as L1I capacity. Huge pages for text are an
         INDEPENDENT and much cheaper fix that does not touch capacity -- do it first (P2, R4)
       → verify: `AnonHugePages` rises and inst-tlb-mpki falls while inst-l1-mpki stays flat --
         the signature of a translation-only win

STEP 7 — What survives?
  VALID      : the reported value AS the series peak; the per-CPU split; `value = |score| × 20`;
              comparisons within a vendor (grv/grv5, intel/icelake/spr, amd/milan/genoa); the
              stall split read as absolute pkc; the startup-vs-sustained distinction; and every
              non-PMU finding in the run
  CAUTION    : the value as a MISS count, since every profile counts refill or request traffic;
              any hit rate, which is not recoverable at all; the value on intel/icelake/spr, which
              includes instruction prefetch; and any layout conclusion drawn on x86
  CONFOUNDED : the value on a multiplexed run; the value on an idle-diluted run; the value on a
              kernel-dominated or interpreted workload, where the footprint is not the code's; and
              the value during a compilation burst
  VOID       : any cross-vendor comparison; any score comparison with `High Code Sparsity`
              (threshold 0.5, base score Bad) or with the data-side rules; any claim that the
              ABSENCE of High Code Sparsity on x86 means the code is compact; and any claim that
              this value is the average

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "startup", which is the
         single most important distinction for this finding, and no percentile is readable
         (P3, R0)
  IF the profile is x86 and `branch-mpki` is absent or unreadable
  THEN → neither the direct discriminator (code-sparsity, which does not exist) nor the proxy is
         available, so layout versus capacity is unanswerable. Report the magnitude and attribute
         with `--profile`; do not change build flags (P3, R0)
  IF the run has no `--profile`
  THEN → the missing code cannot be attributed to application, library, runtime or kernel text,
         and those four have entirely different remediations -- including "none" for the kernel
         (P3, R0)
```

## Runtime-specific consequences

Instruction footprint is more runtime-determined than any other metric in this family: the same source
produces wildly different code volume depending on who generates it and when.

| Runtime | Why the misses, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | The JIT generates code *during* the run, so cold fetch is continuous rather than confined to startup, and an undersized code cache turns it into a recompilation loop. Tiered compilation keeps two versions of hot methods alive. Recurring bursts are a **real, cheap-to-fix defect**; a single startup ramp is not | `jvmArguments` for `-XX:ReservedCodeCacheSize` and `-XX:+TieredCompilation`; `code cache full` in the logs; whether spikes recur. Axis: **code-cache sizing** (R1) before anything else |
| **Python** | The interpreter dispatch loop plus a large C runtime is a fixed footprint the workload cannot shrink, and it is exercised on every bytecode. **Structural, not a defect** — this metric is expected to be high | Whether hot work can move into a native extension or a vectorized library. Axis: **leave the interpreter loop**, not instruction layout |
| **.NET** | Same JIT dynamic as Java, plus ReadyToRun and tiered compilation as explicit controls. Recurring bursts are actionable; the startup ramp is not | Whether ReadyToRun / AOT publishing is in use; tiered-compilation settings. Axis: **AOT or R2R** to move code generation out of the run |
| **Perl** | The interpreter plus XS modules gives a large, scattered text footprint with no layout control from the script side. Structural | Whether hot loops can move into XS or a C library. Otherwise the axis is capacity, not layout |

**The unknown-runtime case is the default** — aperf reports no language field, and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 3 and report two things that need no runtime knowledge: whether the elevation is sustained or
confined to startup, and whether the frontend is stall-dominated. Those decide whether anything is worth
doing; the runtime only decides *which* lever.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — the registry `architectures` lists every one and
`architecture_note` is empty. Its **discriminator** does not.

| Profile | Config entry and event | Semantics | `code-sparsity` available? |
|---|---|---|---|
| `grv`, `grv5` | `L1_Instructions` = `armv8_pmuv3_0/event=0x1/` | L1I refills | **Yes** — `Code_Sparsity`, `event=0x11c` |
| `intel`, `icelake`, `spr` | `L1_Instructions` = `cpu/event=0x24,umask=0xe4/` | All L2 code-read requests, demand **and prefetch** | **No** |
| `amd`, `milan`, `genoa` | `L1_Instruction_Misses` = `cpu/event=0x60,umask=0x10/` | L2 request-group instruction-cache fill requests | **No** |

So `cross_architecture_comparable('inst-l1-mpki', …)` is **True** for every within-vendor pair —
`intel`/`spr` included, unlike `l2-mpki`, because the SPR override does not touch this event — and False
across vendors. `test_aperf_memory_hierarchy.py` re-derives all of it from `src/pmu_configs/*.json`, so it
cannot drift.

The asymmetry that matters operationally is the second column of that table: **`code-sparsity` exists on
two profiles out of eight**, so the same finding supports a confident layout-vs-capacity call on Graviton
and only an inference on x86. `rule_can_fire('High Code Sparsity', '<x86 profile>')` returns False, and
reading that silence as "the code is compact" is a category error — see `High Code Sparsity`.

**No aperf gate protects any of this.** aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate**, yet the event, the prefetch accounting, the L1I size, the
instruction encoding density and the availability of the discriminator all changed. Instruction density is
the subtle one — the same program compiled for two ISAs has different code volume, so the denominator and
the numerator both move.

## Verification

Re-record at the **same geometry, same counter mode, same instance type and the same build**, then check in
order. First, `inst-l1-mpki` must fall — compare the **sustained** level, not the peak, and specifically
exclude the startup window, because a fix that only smooths the cold-start ramp will look like a large win
while changing nothing about steady state. Second, `stall-frontend-pkc` must fall in **absolute pkc**, not
merely relative to the backend. Third, `branch-mpki` and `inst-tlb-mpki` should move **with** it if the fix
was layout, and should be unchanged if the fix was pure size reduction — that divergence is the cleanest
confirmation available of which mechanism was actually at work. Fourth, throughput must improve; the
frontend is harder to hide than the backend, so a real fix here usually does show end to end.

If the metric falls but throughput is flat, the fetches were being absorbed and STEP 3 already said so. If
`l2-mpki` fell alongside it, part of that data-side finding was code all along. And if an AutoFDO rebuild
improved the profiled workload but regressed another, the layout was over-fitted — the specific risk that
makes the compiler levers R3 rather than R2.

## Do not

- **Do not treat the reported value as the run's average.** It is the series peak, and one startup or JIT
  spike produces the largest number the run ever saw. This is the single most common error with this
  finding.
- **Do not act on a startup-only spike.** Cold-code fetches always miss, are a one-time cost, and are
  *not* diluted away — `perf_stat` keeps the first sample.
- **Do not read the absence of `High Code Sparsity` on x86 as evidence that the code is compact.** The
  metric does not exist there, so the rule is structurally silent.
- **Do not change build flags before answering layout-vs-capacity**, and on x86 do not pretend the answer
  is measured when it is inferred from `branch-mpki` and `inst-tlb-mpki`. `-Os` will not fix scattering,
  and AutoFDO will not fix genuine bloat.
- **Do not compute a cache hit rate, or any per-fetch rate, from this metric.** The denominator is
  instructions, and the numerator is refill or request traffic — not demand misses.
- **Do not treat a value inflated by instruction prefetch on `intel`/`icelake`/`spr` as a defect** — the
  `0xe4` umask counts code-read prefetches, which improve throughput. And **do not optimize instruction
  footprint while the workload is backend-bound**, or **read the small score as small impact**:
  `Concerning` (−1) caps the score low however severe the value.
- **Do not assume the code is yours.** Kernel, runtime and library text all count, and for kernel text
  there is no build-flag remediation at all.
- **Do not read the value as characteristic of the instance.** This template iterates every series
  including per-CPU (`processed_data_accessor.rs:104`), so one thread can fire it for the whole run.
- **Do not act on the value when `mux_counter_schedule_rate` is below 100** — the peak is then an
  extrapolation, and this rule is unusually exposed because it fires on a single sample.
- **Do not compare this score with `High Code Sparsity`** (threshold 0.5, base score `Bad`) or with the
  data-side rules; the scales are unrelated, and **do not compare across vendors** either — the event
  differs in kind. And **do not ship an AutoFDO layout validated on one workload** as a general
  improvement: profile-guided layout is over-fittable, which is why it is R3.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:60` — `metric: "inst-l1-mpki"`,
  `comparator: Comparator::Greater`, `threshold: 20.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void. `High Code Sparsity`
  (`:84`) uses `0.5` with `Score::Bad`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)`; with a non-zero threshold and a monotonic score
  that is the series **peak**. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — `delta = value / threshold`,
  inverted only below 1.0, times `rule_score`. `Score::Concerning = −1` at `:147`–`:157`.
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config by
  `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:750`–`:797`. The expression is
  `L1_Instructions / Instructions * 1000` on grv, grv5, intel, icelake, spr and
  `L1_Instruction_Misses / Instructions * 1000` on amd, milan, genoa. `L1_Instructions` resolves to
  `event=0x1` (arm64) and `event=0x24,umask=0xe4` (**all three** Intel profiles — the SPR override does not
  touch it); `L1_Instruction_Misses` resolves to `event=0x60,umask=0x10`. `Code_Sparsity`
  (`event=0x11c`) is defined **only** in `grv_pmu_config.json`. `perf_stat` opts **out** of the forced
  first zero via `use_first_accumulative_value()` (`:1295`), which is why startup fetch is reported at full
  magnitude. Metric display order comes from the Graviton top-down list at `:968`–`:988`.
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) —
  `rule_can_fire('High Code Sparsity', <profile>)` returns False on all six x86 profiles, which is the
  collection gap above; `--side` classifies a fired set into instruction-side versus data-side and returns
  the matching upstream guides; `resolved_events` and `cross_architecture_comparable` establish the
  within-vendor True results; `--select` confirms the peak is reported.
  `test_aperf_memory_hierarchy.py` re-derives the expressions and encodings from `src/pmu_configs/`.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate of
  R% is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and
  duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `INSTRUCTION_FOOTPRINT_OPTIMIZATION` (the remediation attached to this metric — `-flto`,
  `-Os`, AutoFDO, JVM code-cache sizing), `CPU_FRONTEND_STALLS_INVESTIGATION` (which lists `inst-l1-mpki`
  alongside `branch-mpki`, `inst-tlb-mpki`, `inst-tlb-tw-pki` and `code-sparsity`) and
  `TLB_MISS_OPTIMIZATION`, in `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `high-code-sparsity.md` (the discriminator, and arm64-only),
  `frontend-dominated-cpu-stalls.md` (the severity gate), `high-branch-mispredictions.md` (the shared root
  cause and the x86 layout proxy), `instruction-tlb-misses.md` and `instruction-tlb-table-walks.md` (the
  translation half of the same footprint), `high-l2-cache-misses.md` (which carries this finding's traffic
  and can mis-attribute it), `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../kernel_config/huge-page-disabled.md`, `../java_profile/excessive-time-in-symbol.md`,
  `../cpu_utilization/underutilized-cpu.md`. Cross-cutting: [../GATES.md](../GATES.md),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md), [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down front-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-front-end-stalls)
- [Graviton perfrunbook — optimizing for large instruction footprint](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html#optimizing-for-large-instruction-footprint)
- [Arm Neoverse N3 — L1I cache MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/L1I-Cache-Effectiveness-metrics-for-Neoverse-N3?lang=en#md558-l1i_cache_effectiveness_mg__l1i_cache_mpki_m_L1I_Cache_Effectiveness)
