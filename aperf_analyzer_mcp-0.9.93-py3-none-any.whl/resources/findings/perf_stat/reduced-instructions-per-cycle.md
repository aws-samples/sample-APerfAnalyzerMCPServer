---
rule_name: Reduced Instructions per Cycle
data_type: perf_stat
data_key: ipc
template: time_series_stat_run_comparison
condition: "delta_avg(ipc) <= -0.1"
base_score: Poor
score_sign: negative
requires_comparison: true
aperf_message: "Less instructions are being executed by the CPUs. Check the frontend and backend stall metrics to locate the bottleneck."
source: src/analytics/rules/perf_stat.rs:19
---

# Reduced Instructions per Cycle

## What fired

The **average** of the `ipc` metric (aggregate across all CPUs) in this run is **at least 10%
lower** (relative) than the same average in the **base run**. `abs: false`, so it is strictly
directional — only decreases fire.

Requires ≥2 runs. Base score `Poor` (−16).

## Reasoning

`ipc` is "Average number of instructions executed per CPU clock cycle" (`data-descriptions.ts`,
`desired: "higher"`). It is the top of the **top-down performance analysis** hierarchy: the
single number that says how much useful work the CPU extracted from each cycle it was given.

A cycle can end in one of two ways: it retired instructions, or it **stalled**. Falling IPC
means a larger fraction of cycles produced nothing. The CPU was there, clocked, and busy —
but waiting. Every possible reason lives in one of two places, which is exactly why aperf's
message sends you to the stall metrics:

- **Frontend stall** — the CPU could not *supply* instructions to execute. Branch
  mispredictions flushing the pipeline, instruction-cache misses, instruction-TLB misses,
  sparse code layout. Measured by `stall-frontend-pkc`.
- **Backend stall** — instructions were available but could not *complete*. Data cache
  misses waiting on L2/L3/DRAM, data-TLB walks, long-latency arithmetic, insufficient
  memory-level parallelism, atomic/lock serialization. Measured by `stall-backend-pkc`.

**IPC is a rate, not an amount, and this is where most misreadings begin.** It says nothing
about how much work was done or how fast the workload ran:

- IPC can fall while **throughput rises** — e.g. vectorization replaces many scalar
  instructions with fewer, longer-latency SIMD ones. Fewer instructions, more work each, lower
  IPC, faster program. This is a *win* that fires this rule.
- IPC can rise while **throughput falls** — e.g. a spin-wait loop retires tightly-cached
  instructions at very high IPC while accomplishing nothing.
- IPC is **not comparable across ISAs or microarchitectures**. Different instruction sets need
  different instruction counts for the same work; different cores have different issue widths
  (a 4-wide core cannot exceed IPC 4). Comparing Graviton to x86, or Graviton 2 to Graviton 4,
  by IPC is meaningless.

The metric is also **diluted by idleness**: it is computed over whatever the CPU executed, so
a mostly-idle run mixes in idle-loop and background-daemon behaviour. And it is
**extrapolated under multiplexing** — as a ratio, `ipc`'s numerator and denominator can come
from different time slices, making it the single metric most sensitive to
`PMU Counter Collection Multiplexing`.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({value}) is {±pct} {base_run} ({base_value}).
```

`delta_ratio_to_percentage_string` gives the **absolute** percentage plus a relation word.
Since this rule only fires on decreases, the word is always `"less than"`:

```
The average in run_b (0.94) is 18.00% less than run_a (1.15).
```

**Five things that sentence does not tell you.**

1. **The values are dimensionless, and the average behind them is a ratio of sums — not a mean
   of ratios.** `0.94` and `1.15` are instructions per cycle, read from the `Aggregate` series,
   which `perf_stat` builds by summing `instructions` and `cycles` across CPUs and *then*
   dividing (`src/data/perf_stat.rs:1118`–`:1148`). That is the correct aggregation for a ratio
   — busy CPUs are weighted correctly and **no CPU-count correction applies**, unlike every
   `TimeSeriesDataAggregateMode::Average` metric — but it hides a single-CPU outlier completely.
   With `instructions = [900000, 1000, 1000, 1000]` over `cycles = [300000, 10000, 10000,
   10000]` the aggregate reads IPC **2.736** while the mean of the four per-CPU ratios is
   **0.825**: a 3.3× disagreement in which the aggregate is the flattering number. Read the
   per-CPU series before calling the instance uniformly efficient.
2. **The percentage is unsigned.** `delta_ratio_to_percentage_string` prints the magnitude and
   a relation word. Recover the signed ratio as `(value − base_value) / base_value`, or from the
   score below, which is more precise.
3. **Both numbers are truncated, not rounded.** `f64_to_fixed_2`
   (`src/computations/mod.rs:138`) truncates, so a printed `1.99` is anything in
   `[1.99, 2.00)` and a printed `0.94` is anything in `[0.94, 0.95)`.
4. **The threshold is unreliable at the boundary, and the sentence cannot show it.** `−0.1` has
   no exact binary representation. `(1.8 − 2.0) / 2.0` evaluates to `−0.09999999999999998`,
   which is **not** `<= −0.1`, so a textbook **2.00 → 1.80 regression produces no finding at
   all**, while `(9 − 10) / 10` is exactly `−0.1` and fires. Sweeping 100 base values at a
   nominal 10% drop, only **34 of 100 fire**. The absence of this finding bounds nothing.
5. **Nothing in the sentence is about work done.** It reports a rate, so it cannot distinguish a
   slower program from one that did the same work with fewer, heavier instructions — the
   distinction STEP 4 of the tree exists to force.

Score math — `compute_finding_score(delta_ratio, −0.1, −16)`. Value and threshold are both
negative, so their ratio is positive and the score stays negative:

| observed Δ | score | recovered `−\|score\|/160` |
|---|---|---|
| −10% (−0.10) | `(−0.10/−0.1) × −16` = **−16.00** | −0.1000 |
| −18.26% (the worked example) | **−29.22** | −0.1826 |
| −35% (−0.35) | `(−0.35/−0.1) × −16` = **−56.00** | −0.3500 |
| −100% (−1.0) | `(−1.0/−0.1) × −16` = **−160.00** | −1.0000 |

Linear and invertible: `delta_ratio = −|score| / 160`. Prefer that to the truncated text.

**Every other sentence this rule can produce.** A tree that handles only the common form
mis-routes the rest, and two of these forms are *silences* rather than sentences:

| Situation | What you get |
|---|---|
| Normal firing | `The average in run_b (0.94) is 18.00% less than run_a (1.15).` |
| `avg(ipc)` in **this** run is exactly `0.0` | the `value == 0.0` branch returns `2 × −16` = **exactly −32.00**, regardless of the base value. `−32.00` means **no instructions were counted at all** — collection failure or a fully idle run — not an 18% regression |
| `avg(ipc)` in the **base** run is exactly `0.0` | the template substitutes `delta_ratio = 1.0` (`time_series_stat_run_comparison_rule.rs:117`–`:122`) instead of dividing by zero. `+1.0` can never satisfy `<= −0.1`, so **a base run whose `perf_stat` collection failed produces NO finding however far IPC fell.** The comparison is skipped silently, not flagged |
| `ipc` absent from either run | the rule returns early; no finding. `perf_stat` is the most commonly absent data type, because it needs PMU access |
| IPC **rose** | `abs: false`, so nothing is emitted. This rule never reports improvements |

## Interpretation

Absolute IPC context first — a "low" IPC is microarchitecture-dependent, but as rough
orientation on Neoverse cores:

| avg(ipc) | Reading |
|---|---|
| > 2.0 | Executing efficiently; a drop here still leaves headroom |
| 1.0–2.0 | Typical for general server workloads |
| 0.5–1.0 | Substantially stalled; real optimization headroom exists |
| < 0.5 | Heavily memory- or dependency-bound |

Then the delta:

| Observed Δ | Throughput unchanged / worse | Throughput improved |
|---|---|---|
| −10 to −20% | Mild efficiency regression; localize via stalls | Likely an instruction-mix change (e.g. vectorization) — a win |
| −20 to −50% | Real regression; expect a matching stall increase | Verify with a work-normalized measure before celebrating |
| >−50% | Large — check measurement validity (idle run, multiplexing) before the code | Very likely a mix change or a measurement artifact |

**Known false positives — check these before investigating the code:**

- **Instruction-mix change.** Vectorization (NEON/SVE), better use of wide loads, or
  replacing a loop with a single complex instruction all *reduce* IPC while *improving*
  performance. Fewer instructions, each doing more. This is the most important false positive
  and the reason IPC must never be optimized as an end in itself.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` also fired, `ipc` is the
  metric most affected — its numerator and denominator may be sampled in different slices.
  Check the schedule rate in both runs before trusting the delta.
- **Idle-diluted run.** If `Underutilized CPU` fired on either run, `ipc` reflects a mix of
  workload and idle/background behaviour. Two runs with different idle fractions have
  incomparable IPC.
- **Different instance types or CPU generations.** IPC is not portable across
  microarchitectures. If `Kernel Version Mismatch` or `Inconsistent Number of CPUs` fired,
  or the instance types differ, the comparison is invalid at the outset.
- **Different phase mix.** A run that included more startup, JIT compilation, or warm-up has a
  different instruction profile. Check where in the timeline the IPC differs.
- **Frequency effects.** IPC is per *cycle*. A change in clock frequency (turbo, thermal,
  T-family throttling) changes wall-clock performance without changing IPC — and conversely,
  IPC being flat does not mean performance was flat.
- **Removing a spin-wait.** Replacing busy-polling with proper blocking *lowers* IPC (the
  high-IPC spin loop is gone) and improves the system. Cross-check `idle` and `user`.

## Corroborating data

The whole point of this finding is that it localizes nothing on its own. These do:

| Check | Data type | What it tells you |
|---|---|---|
| `stall-frontend-pkc` vs `stall-backend-pkc` | `perf_stat` | **The first thing to read.** Whichever grew is where the IPC went. See `Frontend-Dominated CPU Stalls` / `Backend-Dominated CPU Stalls` |
| `branch-mpki` | `perf_stat` | Frontend cause: mispredicted branches flushing the pipeline (`High Branch Mispredictions`) |
| `inst-l1-mpki` | `perf_stat` | Frontend cause: code footprint spilling L1I (`High L1 Instruction Cache Misses`) |
| `inst-tlb-mpki`, `inst-tlb-tw-pki` | `perf_stat` | Frontend cause: instruction address translation |
| `code-sparsity` | `perf_stat` | Frontend cause: poor code layout (`High Code Sparsity`) |
| `data-l1-mpki`, `l2-mpki`, `l3-mpki` | `perf_stat` | Backend cause: data footprint escalating through the cache hierarchy |
| `data-tlb-mpki`, `data-tlb-tw-pki` | `perf_stat` | Backend cause: data address translation |
| `strex-spec-pki` | `perf_stat` | Backend cause: old-style atomics serializing under contention (`Old-Style Atomic Instructions`) |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 in either run ⇒ the IPC delta may be extrapolation error |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check: was either run mostly idle? |
| `user`, `system` | `cpu_utilization` | A user→kernel shift changes the instruction mix being measured |
| On-CPU profile | `perf_profile` / `java_profile` | Which code the cycles were spent in. Requires `--profile`. **`perf_profile` has no analytical rules** |
| Hotline output | `hotline` | Per-instruction / per-address hotspot attribution for native code on metal Graviton. **No analytical rules and no `data-descriptions.ts` entry** — read manually |
| `MemAvailable`, `Cached` | `meminfo` | Memory pressure changing the effective cache/DRAM behaviour |
| `pgmajfault`, `pgminorfault` | `vmstat` | Fault-driven stalls and allocation churn |
| `numa_miss`, `other_node` | `numastat` | Remote-node memory access raising latency. **No analytical rules — read manually** |

## Guidance

Ordered. Steps 1–2 are confidence gates; do not skip them, because IPC is the most
easily-invalidated metric in the report.

1. **Gate on measurement validity.** Check `mux_counter_schedule_rate` in **both** runs
   (`PMU Counter Collection Multiplexing`) and `avg(idle)` in both (`Underutilized CPU`). If
   either run was heavily multiplexed or mostly idle, report the delta as low-confidence and
   recommend a re-record before investigating the code. IPC is a ratio and suffers most from
   both problems.

2. **Gate on comparability.** Confirm the two runs are on the same microarchitecture with the
   same core count (`systeminfo`, `Inconsistent Number of CPUs`, `Kernel Version Mismatch`).
   IPC is not portable across CPU generations or ISAs.

3. **Decide "regression" vs "instruction-mix change" using work done.** Obtain throughput from
   outside aperf.
   - Throughput **flat or worse** with IPC down ⇒ genuine efficiency regression. Continue.
   - Throughput **better** with IPC down ⇒ the instruction mix changed for the better
     (vectorization, fewer-but-heavier instructions). Report as an improvement and explain why
     aperf scores it `Poor`.
   - Throughput **unknown** ⇒ say so; present both readings rather than asserting one.

4. **Split frontend vs backend — this is the step aperf's own message prescribes.** Compare
   `stall-frontend-pkc` and `stall-backend-pkc` between the runs and within this run.
   - Frontend grew ⇒ go to `Frontend-Dominated CPU Stalls`, then `branch-mpki`,
     `inst-l1-mpki`, `inst-tlb-mpki`, `inst-tlb-tw-pki`, `code-sparsity`.
   - Backend grew ⇒ go to `Backend-Dominated CPU Stalls`, then `data-l1-mpki`, `l2-mpki`,
     `l3-mpki`, `data-tlb-mpki`, `data-tlb-tw-pki`.
   - Neither grew materially ⇒ suspect an instruction-mix change (step 3) or a measurement
     artifact (step 1).

5. **Follow the cache/TLB hierarchy outward.** Within whichever side grew, find the level where
   the miss rate jumped. A rise confined to L1 with L2/L3 flat is a locality problem; a rise
   that propagates to `l3-mpki` means the working set is going to DRAM and bandwidth (possibly
   shared with co-tenants) is in play.

6. **Attribute to code.** With `--profile` data, diff the on-CPU profiles between the runs to
   find which stacks grew. For native code on metal Graviton instances, `hotline` attributes
   stalls to specific instructions and addresses, which is the most direct path to a fix.

7. **Only then remediate**, matched to the localized cause — the upstream guides are keyed to
   exactly this split: `INSTRUCTION_FOOTPRINT_OPTIMIZATION` for frontend causes,
   `DATA_FOOTPRINT_OPTIMIZATION` for cache causes, `TLB_MISS_OPTIMIZATION` for translation
   causes, `LSE_OPTIMIZATION` for atomics.

8. **Quantify the cycle cost before reporting.** `tools/aperf_perf_stat.py --ipc --base B
   --current C` converts the delta into the number a reader can act on:

   ```
   $ python3 tools/aperf_perf_stat.py --ipc --base 1.15 --current 0.94
   IPC fell from 1.150 to 0.940, 18.26% less work retired per cycle. To do the same
   instruction count the current run needs 1.22x the cycles -- so at equal clock this is
   a 22.3% wall-clock regression on any CPU-bound phase.
   ```

   The cycle ratio is `base/current`, and it is larger than the percentage drop: an 18.26% IPC
   fall is a **22.3%** cycle increase, not an 18% one. Report the cycle ratio, not the IPC
   percentage — the reader cares about wall clock.

## Priority and execution risk

**Priority: P2 — Investigate** by default: the finding is a real measurement but it localizes
nothing, and its two readings (efficiency regression vs instruction-mix improvement) call for
opposite actions. It rises to **P1 — Act now** once STEP 4 has confirmed throughput is flat or
worse *and* one stall side has grown, because the cause is then both real and located. It drops
to **P4 — Informational** when throughput improved — the correct report is then "aperf scores
this `Poor`; it is a win", which is a statement worth making explicitly rather than suppressing.
It is **P3 — Monitor** when the measurement gates in STEP 1 fail, since the honest deliverable
is a re-record, not a conclusion.

**Execution risk: R0 — Read-only** to diagnose: the stall split, the `*-mpki` family, the mux
rate, and the cycle-ratio arithmetic are all reads of an existing report. Acting on what it
reveals spans the range and is never R0 — **R2** to change a JVM flag or a thread-pool size,
**R3** to rebuild with different compiler flags or a different `-march`, **R4** to change
instance family for more cache or bandwidth, **R5** where the fix is an algorithmic change to
data layout in production code. **Never inherit the R0 of the split into the remediation:**
reading which side stalled is free; restructuring the data is not.

**The score is amplified and is a pure restatement of the delta — with one hard-coded
exception.** It is exactly `delta_ratio / −0.1 × −16`, so `delta_ratio = −|score| / 160` and the
score contains no severity information the percentage does not. The exception is worth
recognizing on sight: **exactly `−32.00`** is the `value == 0.0` branch, meaning `avg(ipc)` was
zero in this run — a collection failure or an entirely idle run — and **not** a 20% regression.
And because the base score is `Poor` (−16), this rule outranks every `Concerning` (−1)
`perf_stat` finding in the Analytical Findings panel by a factor of 16 while saying strictly
less about where the problem is. Its position is the base score, not its usefulness.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `avg(ipc)` over the `Aggregate` series fell by at least 10% relative to the
base run (`LessEqual −0.1`, so only decreases fire, and see STEP 1's boundary case for why
"at least 10%" is not quite true).

```
STEP 0 — Does the perf_stat data exist in BOTH runs?
  This rule needs the PMU in two runs, and perf_stat is the data type most often absent.

  IF `perf_stat` is missing from either run
  THEN → NO finding was possible. The silence proves nothing about IPC (P3, R0)
       → aperf needs PMU access: bare metal, or a virtualized PMU the instance
         family exposes. Some instance types and container runtimes have none
  IF `ipc` is present but `avg(ipc)` in the BASE run is exactly 0.00
  THEN → the template substitutes delta_ratio = +1.0 (time_series_stat_run_comparison_rule.rs:117),
         which can NEVER satisfy <= -0.1. NO finding, however far IPC fell (P3, R0)
       → this is the dangerous silence: a base run with failed PMU collection
         cannot produce an IPC regression. Check the base run's ipc series is
         non-zero before trusting the absence of this finding
  ELSE continue.

STEP 1 — Recover the delta, and check whether the threshold was even reachable.
  Parse: The {stat} in {run} ({value}) is {pct} {base_run} ({base_value}).
  Prefer delta_ratio = -|score| / 160 — the text is truncated, the score is not.

  IF the score is exactly -32.00
  THEN → avg(ipc) in THIS run was 0.0: the value == 0.0 branch, not a regression.
         Treat as a collection failure or a fully idle run (P3, R0)
       → verify: read the raw `ipc` series; an all-zero series confirms it
  IF the nominal drop is within a hair of 10%
  THEN → the finding's presence or absence is a floating-point accident. -0.1 is
         not representable, so 2.00 -> 1.80 is -0.09999999999999998 and is SILENT
         while 10 -> 9 is exactly -0.1 and fires (P2, R0)
       → only 34 of 100 nominal-10% drops fire. Read the two IPC numbers from the
         report and compute the ratio yourself; never bound the regression by the
         finding's existence
  ELSE → the delta is unambiguous; continue to STEP 2.

STEP 2 — Gate on measurement validity. IPC is the most easily invalidated number
         in the report, because it is a ratio of two separately scheduled counters.
  IF `mux_counter_schedule_rate` < 100 in EITHER run
  THEN → numerator and denominator may come from different time slices. Report the
         delta as low-confidence and quantify the duty cycle (P3, R0)
       → run `tools/aperf_perf_stat.py --mux --rate R`: the extrapolation factor is
         100/R, and any phase shorter than that many intervals can be missed
       → the two runs' rates must BOTH be stated when reporting the delta; a rate
         difference alone can produce it
  IF `Underutilized CPU` fired on either run
  THEN → the average is diluted with idle-loop and daemon behaviour, whose IPC is
         unrepresentative. Two runs at different idle fractions have incomparable
         IPC (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval in both runs;
         if the delta collapses, it was dilution
  ELSE continue.

STEP 3 — Gate on comparability. Check the 8 gates (GATES.md) first.
  IF `Inconsistent Number of CPUs` or `Kernel Version Mismatch` fired
  THEN → resolve before reading the delta. A CPU-count change alters which cores
         are summed into the Aggregate ratio (P0, R4)
       → verify: after re-recording matched, the two runs' `CPUs` and
         `Kernel Version` agree and neither gate fires; the IPC delta may change
         sign, which is the point of resolving it first
  IF the two runs are on different instance families or CPU generations
  THEN → IPC is NOT portable. Issue width bounds it (a 4-wide core cannot exceed
         4) and the instruction count for the same work differs across ISAs.
         Nothing comparable here (P2, R0)
       → aperf compares no architecture field, so this fires NO gate. It is a
         MANDATORY manual check against the two runs' `Instance Type`
  ELSE continue.

STEP 4 — MANDATORY manual check: regression, or instruction-mix improvement?
  aperf has no throughput metric. This answer must come from outside the report,
  and it inverts the conclusion.

  IF throughput is FLAT or WORSE with IPC down
  THEN → genuine efficiency regression. Quantify it and continue to STEP 5 (P1, R0)
       → run `tools/aperf_perf_stat.py --ipc --base B --current C`: the cycle ratio
         is base/current, so an 18.26% IPC drop is a 22.3% wall-clock regression on
         a CPU-bound phase — report THAT number
  IF throughput IMPROVED with IPC down
  THEN → an instruction-mix change for the better: vectorization (NEON/SVE), wider
         loads, or fewer-but-heavier instructions. Report as a WIN and explain why
         aperf scores it Poor (P4, R0)
       → verify: instruction count should have FALLEN while cycles fell further.
         If `instructions` rose, this is not a mix change
  IF throughput is UNKNOWN
  THEN → present both readings; do not assert one. This is the honest outcome and
         it is common (P2, R0)
       → the cheapest disambiguator is the instruction count itself, which aperf
         does collect: same work with far fewer instructions is a mix change

STEP 5 — Split frontend vs backend. This is the step aperf's own message prescribes,
         and it is the only step that localizes anything.
  Read avg(stall-frontend-pkc) and avg(stall-backend-pkc) in BOTH runs.

  IF the FRONTEND side grew
  THEN → `Frontend-Dominated CPU Stalls` — see that playbook, then branch-mpki,
         inst-l1-mpki, inst-tlb-mpki, inst-tlb-tw-pki, code-sparsity
  IF the BACKEND side grew
  THEN → `Backend-Dominated CPU Stalls` — see that playbook, then data-l1-mpki,
         l2-mpki, l3-mpki, data-tlb-mpki, data-tlb-tw-pki
  IF NEITHER stall finding fired in this run
  THEN → the two sides are within 10% of each other. This is the DEAD ZONE
         (be/fe in (1/1.1, 1.1)) and it produces no stall finding however high
         BOTH stalls are — a balanced, heavily stalled pipeline is invisible to
         the split (P2, R0)
       → read the two absolute pkc values anyway: pkc/10 is percent-of-cycles, so
         420 pkc is 42% of all cycles lost. High-and-balanced is a real bottleneck
         with no direction, not an absence of one
  IF the run is on a profile where the two metrics are not commensurable
  THEN → treat exactly like STEP 5 above, but correct the backend value first —
         see the architecture section for the per-profile factors

STEP 6 — What survives?
  VALID      : the instruction and cycle counts themselves, and every non-PMU
               finding in both runs — cpu_utilization, ena_stat, meminfo, vmstat
  CAUTION    : the stall split and the *-mpki family, if either run multiplexed;
               they are extrapolated by the same factor as ipc but were scheduled
               in different slices
  CONFOUNDED : any per-unit efficiency claim when either run was idle-diluted, and
               any cross-generation IPC reading
  VOID       : any claim that the workload got slower, or faster, on the strength
               of this finding alone; and the delta itself when the base run's
               avg(ipc) was 0.0

INSUFFICIENT DATA
  IF only one run was recorded
  THEN → this rule requires_comparison and cannot fire. Its absence says nothing
         about IPC; read avg(ipc) and the stall split directly (P3, R0)
  IF the run is at default `--interval 1 --period 10`
  THEN → ~10 PMU samples, of which perf_stat keeps the first (it is the ONLY
         collector that calls use_first_accumulative_value, perf_stat.rs:1295).
         Every percentile at or above p90 is the same single sample; do not branch
         on one (P3, R0)
```

## Runtime-specific consequences

IPC is measured on the hardware, so every runtime is measured the same way. What differs is
**what a falling IPC means about the runtime**, and in three of the four cases the drop is a
phase artifact rather than a code regression — which is why STEP 4's throughput check matters
more here than the stall split.

| Runtime | Why IPC moves without the code changing | What to check, and the effective axis |
|---|---|---|
| **.NET** | Tiered JIT: tier-0 code is unoptimized and retires far fewer instructions per cycle than tier-1. A run capturing more startup, or one where tiering did not promote the hot path, reads lower IPC for identical source. Server GC's per-core heaps also change the memory access pattern | Whether the window included startup; `DOTNET_TieredPGO` and `DOTNET_TieredCompilation` state. Compare like-for-like phases, not whole runs |
| **Python** | CPython's bytecode interpreter is a dispatch loop — an indirect branch per opcode — so IPC is *structurally* low (often < 1) and dominated by the interpreter rather than the workload. A change in IPC usually means a change in the C-extension fraction, not in the Python code | Whether the hot path moved between pure Python and a native extension (NumPy, `orjson`, a C module). Falling IPC with rising throughput is the normal signature of pushing work *into* a vectorized extension |
| **Java** | JIT compilation is the dominant confound: C1 code, C2 code, and deoptimization each have different IPC, and OSR transitions move a loop between them mid-run. Class loading is frontend-heavy and depresses IPC early in every run | `jvmArguments` in the profile metadata; whether the window covered warm-up. `-XX:+TieredCompilation` and code-cache sizing change which tier the hot loop runs in |
| **Perl** | A tree-walking interpreter over an op tree — pointer chasing between ops, so IPC is low and *backend*-dominated, unlike Python's frontend-dominated dispatch. Little run-to-run variance, which makes a real IPC delta more trustworthy here than in the JIT'd runtimes | Module set and XS fraction; `perl -V` build options. There is no JIT tier to confound the comparison |

**The unknown-runtime case is the default**, since aperf reports no language field and the
runtime is inferred from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3).
When it cannot be identified, stop at STEP 4: the throughput comparison is runtime-independent
and answers the same question. Note that for **all four**, an IPC drop confined to the first
seconds of the window is warm-up, and the fix is to re-scope with `--time-range`, not to touch
the code.

## Architecture-specific considerations

`ipc` exists in **all eight** PMU profiles (registry `architectures`: `arm64`,
`arm64_graviton5`, `intel`, `intel_icelake`, `intel_sapphire_rapids`, `amd`, `amd_milan`,
`amd_genoa`) and is defined identically everywhere as `Instructions / Cycles`, with no
per-profile normalisation. It is the only `perf_stat` metric in this playbook set with that
property, and the registry attaches **no `architecture_note`** to it. The architecture
dependence is therefore not in the metric — it is in what a given IPC number *can* be, and in
what STEP 5 does next.

**IPC is bounded by issue width, so the same value means different things.** A core cannot
retire more instructions per cycle than it can issue: Neoverse V1/V2 and recent x86 cores are
in the 4–8 range, so an IPC of 3.0 is near-saturation on a 4-wide core and mid-range on an
8-wide one. There is no universal good value, which is why this playbook never states an
absolute threshold and why the rule itself only compares a run against its own base.

**A cross-architecture IPC comparison is meaningless, and no gate stops you.** Different ISAs
need different instruction counts for the same work — AArch64's `LDP`/`STP` and predicated SVE
do in one instruction what x86 needs several for, and the reverse holds for x86's
memory-operand arithmetic. So the *denominator of the work* changes with the ISA. aperf has no
architecture field and no rule compares `Instance Type`
([../GATES.md](../GATES.md) §"The two gaps"), so an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate at all** while this rule happily reports a percentage.
That percentage is not a regression. Treat an instance-family change as STEP 3's dead end.

**STEP 5 inherits an architecture problem this metric does not have.** `ipc` is portable across
profiles; `stall-backend-pkc` is not. It is `/Cycles*1000` on `grv`, `grv5`, `intel` and
`milan`; `/Slots*1000` on `icelake` and `spr`; `/Cycles*167` on `genoa`; and **absent from
generic `amd`**, which silences both stall rules outright. So the split this finding routes to
is unavailable on one profile and mis-scaled on three:

| Profile | STEP 5 usable? | Correction needed |
|---|---|---|
| `grv`, `grv5`, `intel`, `milan` | yes | none — both sides are `/Cycles*1000` |
| `icelake`, `spr` | with care | backend is per-Slot; the factor is the issue width (5 on Ice Lake, 6 on Sapphire Rapids) and the module refuses to invent it |
| `genoa` | yes, corrected | backend is understated by exactly `1000/167 = 5.99×`. `tools/aperf_perf_stat.py --stalls --profile genoa` applies it, and the verdict often **flips**: 300 fe / 100 be reads "frontend-dominated" raw, but corrected backend is 598.80 pkc and the answer is backend |
| `amd` (generic) | **no** | `stall-backend-pkc` does not exist; neither stall rule can fire. IPC fell and the split is structurally unavailable — go straight to the `*-mpki` family |

**Counter mode changes the mux rate, which changes STEP 2.** Grouped is the default
(`src/data_collection.rs:379`) and creates one counter per event *per metric group*
(`src/data/perf_stat.rs:217`–`:221`), roughly doubling register pressure versus
`--ungroup-pmu-events`. A base run recorded ungrouped and a current run recorded grouped differ
in `mux_counter_schedule_rate` for reasons that have nothing to do with the workload — and IPC
is the metric most sensitive to that. Check `pmu_counter_mode` in both runs before attributing
an IPC delta to code. See [../ARCHITECTURE.md](../ARCHITECTURE.md) §3.4.

**Architecture-specific builds are a common cause of a real IPC drop** that no aperf metric
attributes. A generic `-march=armv8-a` binary on Graviton 3 leaves both LSE atomics and wider
vectors unused; a framework built for one vendor's kernels (`microsoft/onnxruntime` versus
`amd/ZenDNN-onnxruntime`) runs a different code path entirely. This is **R3 — rebuild**, and the
only signal is that STEP 5 finds a stall increase with no corresponding data-structure change.

## Verification

Apply the fix STEP 5 localized, re-record **both** runs at the same geometry and counter mode,
and check three things in order: `avg(ipc)` should recover toward the base value; the stall side
that grew should shrink; and the external throughput number should improve by roughly the cycle
ratio the arithmetic predicted — an 18.26% IPC recovery is a ~22.3% wall-clock improvement on a
CPU-bound phase, so if wall clock moves by 2% the IPC change was not on the critical path. If
IPC recovers and throughput does not, the workload was not CPU-bound in the first place and the
remaining time is in I/O, locks, or a downstream service — pivot to `Increased I/O Wait Time`
or off-CPU analysis. If IPC does *not* recover but throughput does, you made an instruction-mix
change, which is STEP 4's second branch and a success.

This finding cannot be verified from a single re-record, because it is a comparison: you need
the base run to still exist and to still be comparable. A re-record that also changes instance
type, kernel, or counter mode has replaced the measurement rather than repeated it, and the new
percentage is not commensurable with the old one.

## Do not

- **Do not treat IPC as a performance target.** It is a rate. Optimizing IPC can make a
  program slower (executing more, cheaper instructions raises IPC), and improving a program can
  lower IPC (vectorization). Always tie it back to work done.
- **Do not compare IPC across instance types, CPU generations, or ISAs.** Issue width bounds it
  and the instruction count for the same work differs. No aperf gate catches this.
- **Do not treat the absence of this finding as evidence IPC held up.** `−0.1` is not
  representable in binary: a 2.00 → 1.80 drop computes to `−0.09999999999999998` and is
  **silent**, and only 34 of 100 nominal-10% drops fire. Read `avg(ipc)` in both runs directly.
- **Do not read `−32.00` as a severe regression.** It is the `value == 0.0` branch — this run's
  `avg(ipc)` was zero, meaning collection failure or a fully idle run.
- **Do not trust a comparison whose base run had `avg(ipc) == 0.0`.** The template substitutes
  `+1.0`, which cannot satisfy a negative threshold, so the regression is silently skipped.
- **Do not act on the delta without checking `mux_counter_schedule_rate` in both runs.** IPC is
  a ratio of two separately scheduled counters and is the metric most distorted by multiplexing.
- **Do not act on it from an idle-dominated run** (see `Underutilized CPU`) — the average mixes
  workload behaviour with the idle loop.
- **Do not read the Aggregate IPC as characteristic of every CPU.** It is a ratio of *summed*
  counters, so one busy CPU at IPC 2.7 can hide three at 0.1. Check the per-CPU series.
- **Do not stop at this finding.** It says the CPU stalled more; it does not say why. The stall
  split is one step away and mandatory.
- **Do not conclude "balanced pipeline, therefore healthy" when neither stall rule fired.** The
  dead zone is `be/fe ∈ (1/1.1, 1.1)`, and a run at 600 pkc on both sides — 60% of all cycles
  lost on each — produces no stall finding at all.
- **Do not compare the stall split on `genoa`, `icelake`, or `spr` without correcting it**, and
  do not expect a split at all on generic `amd`, which has no `stall-backend-pkc`.
- **Do not read the score as severity** — it is `−|score|/160` restated, except the `−32.00`
  case. And do not read its rank: `Poor` (−16) puts it 16× above every `Concerning` `perf_stat`
  finding while telling you strictly less.
- **Do not report the IPC percentage as the performance impact.** The cycle ratio is
  `base/current`, so an 18.26% IPC fall is a 22.3% cycle increase. Report the larger number.
- **Do not assume a high IPC is healthy.** Spin-wait and busy-poll loops produce excellent IPC
  while accomplishing nothing.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:19` — `metric: "ipc"`, `stat: Stat::Average`,
  `comparator: Comparator::LessEqual`, `threshold: -0.1`, `abs: false`, `score: Score::Poor`.
  `abs: false` is why improvements are never reported.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — calls
  `compute_finding_score`, so **this rule's score is amplified**. The zero-baseline substitution
  is at `:117`–`:122`, and it hardcodes `delta_ratio = 1.0`, which for a `LessEqual −0.1` rule
  can never fire.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`, over `Score::Poor = −16`
  (`src/analytics/mod.rs:147`–`:157`). The `value == 0.0` branch returns `2 × rule_score` =
  exactly `−32.00`.
- Aggregate is a **ratio of sums**: `src/data/perf_stat.rs:1118`–`:1148` sums `instructions` and
  `cycles` across CPUs and divides once. Correct for a ratio — so unlike
  `TimeSeriesDataAggregateMode::Average` metrics, **no CPU-count correction applies** — but it
  hides per-CPU outliers. `stats_series_idx` (`src/data/common/time_series_data_processor.rs:312`)
  selects the `Aggregate` series; per-CPU series are named `CPU{n}` (`utils.rs:237`).
- Multiplexing compensation: `src/data/perf_stat.rs:1093` scales each value by
  `time_enabled / time_running`, so a rate of R% means an extrapolation factor of `100/R`.
  `time_running == 0` skips the metric entirely (`:1085`–`:1088`). `perf_stat` is the **only**
  collector that calls `use_first_accumulative_value()` (`:1295`), so it alone keeps its first
  sample; every other data type's first point is a forced `0.0`.
- Truncation: `f64_to_fixed_2`, `src/computations/mod.rs:138` — truncates, does not
  round, so a printed value is a half-open interval.
- Quantifier: [`../tools/aperf_perf_stat.py`](../tools/aperf_perf_stat.py) `--ipc` — converts the
  delta into a cycle ratio and a wall-clock percentage, and flags the floating-point boundary
  case. `tools/test_aperf_perf_stat.py` pins it, including the sweep showing 34/100 nominal-10%
  drops fire.
- Upstream guide: `LOW_IPC_INVESTIGATION` in
  `src/report_frontend/src/definitions/optimization-guides.ts` — "try to identify whether the
  bottleneck comes from the frontend or backend by checking the `stall_frontend_pkc` and
  `stall_backend_pkc` metrics." The remediation guides keyed to the split are
  `INSTRUCTION_FOOTPRINT_OPTIMIZATION`, `DATA_FOOTPRINT_OPTIMIZATION`, `TLB_MISS_OPTIMIZATION`
  and `LSE_OPTIMIZATION`.
- Related playbooks: `frontend-dominated-cpu-stalls.md`, `backend-dominated-cpu-stalls.md`,
  `pmu-counter-collection-multiplexing.md`, `high-branch-mispredictions.md`,
  `old-style-atomic-instructions.md`, `../cpu_utilization/underutilized-cpu.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`, `../systeminfo/kernel-version-mismatch.md`.
- Cross-cutting: [../GATES.md](../GATES.md) (precedence, and the missing architecture gate),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) (P/R vocabulary, runtime inference),
  [../ARCHITECTURE.md](../ARCHITECTURE.md) (the 8 PMU profiles, counter mode).
- [Graviton perfrunbook — top-down method to debug hardware performance](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#top-down-method-to-debug-hardware-performance)
- [Arm Neoverse N3 — IPC metric definition](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/General-metrics-for-Neoverse-N3?lang=en#md420-general_mg__ipc_m_General)
- [Arm Neoverse V2 software optimization guide](https://developer.arm.com/documentation/109898/latest/)
  — issue width and retire bandwidth, i.e. the ceiling this metric is measured against.
