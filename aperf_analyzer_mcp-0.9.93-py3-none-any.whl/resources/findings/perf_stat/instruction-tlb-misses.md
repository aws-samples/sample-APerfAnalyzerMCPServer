---
rule_name: Instruction TLB Misses
data_type: perf_stat
data_key: inst-tlb-mpki
template: time_series_data_point_threshold
condition: "any(inst-tlb-mpki) > 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "This indicates the CPU has to do extra stalls to translate virtual addresses of instructions into physical addresses before fetching them. The instruction footprint might be too large and cause CPU frontend stalls."
source: src/analytics/rules/perf_stat.rs:68
---

# Instruction TLB Misses

## What fired

**At least one** data point of `inst-tlb-mpki` was **greater than 0.0**.

**The threshold is zero.** Any non-zero instruction-TLB miss rate in any single sample of the
recording fires this rule, making it one of the **most frequently-firing and least selective
findings in aperf** — most real workloads produce it. Treat its presence as normal and its
*magnitude* as the actual signal. Base score `Concerning` (−1). Single-run rule.

## The processing defect — the reported value is not the worst sample

**The natural reading of the description — that the value is "the worst single sample" — is false
for this rule and for the other three zero-threshold TLB rules.** It holds for the five
non-zero-threshold `perf_stat` memory rules and only for them. Two pieces of code compose to break
it here.

`compute_finding_score` (`src/analytics/mod.rs:170`) special-cases a zero threshold:

```
if value < 1.0  →  score = rule_score            (flat, no magnitude)
else            →  score = (value - 1.0) * rule_score
```

so `|score|` is **V-shaped**: flat at `1.0` for every value below 1.0, collapsing to `0.0` at
exactly 1.0, and only exceeding the flat branch above value 2.0. The template
(`time_series_data_point_threshold_rule.rs:98`–`:117`) then keeps the sample with the largest
`abs(finding_score)` — *not* the largest value — using `>=`, so a later tie overwrites an earlier
one. Composed, the template prefers a **smaller** sample:

| series | reports | score | the peak |
|---|---|---|---|
| `[0.30, 1.50]` | **0.30** | −1.00 | 1.50 — scores only −0.50, so it loses |
| `[0.0, 0.31, 0.42, 0.28, 0.35]` | **0.35** | −1.00 | 0.42 — a score tie, and `>=` takes the last |
| `[0.50, 2.00]` | **2.00** | −1.00 | 2.00 — a tie with 0.50; the last one wins by luck |
| `[1.00]` | **1.00** | **−0.00** | renders **grey**, neutral icon |

Verified by porting the Rust selection loop and sweeping it: over every two-sample series drawn from
a value grid, **more than a third understate the peak** (`test_aperf_memory_hierarchy.py`,
`test_zero_threshold_rules_report_a_smaller_sample_than_the_peak`).

So: read the series, never the description, for magnitude; any value in `(1.0, 2.0)` scores weaker
than any value below 1.0; and a run whose only exceeding sample is exactly 1.0 scores 0.00, which
`getFindingColor` (`AnalyticalFindings.tsx:35`) renders grey with the neutral icon — a negative
finding disguised as a non-event. `tools/aperf_memory_hierarchy.py --select <series>` reproduces
the selection exactly and names which trap applies.

## Reasoning

`inst-tlb-mpki` is "Translation Lookaside Buffer (TLB) misses for code instructions per thousand
instructions. When the instruction footprint is too large, the TLB is filled, and the CPU needs
to query the OS-built page table in memory to translate the virtual instruction addresses to
physical ones." (`data-descriptions.ts`, `desired: "lower"`)

Every instruction fetch uses a *virtual* address that must be translated to a physical one before
memory can be accessed. The instruction TLB (ITLB) caches those translations. It is small —
typically tens of entries at L1 level — and each entry covers one page, so with 4 KB pages a
48-entry L1 ITLB covers roughly **192 KB of code**. Exceed that and translations start missing, each
miss costing a lookup in the larger, slower L2 TLB or a full page-table walk if that misses too.
The consequence is a **frontend** stall: the core cannot fetch the next instruction until the
translation resolves.

The key insight for remediation is that ITLB pressure is driven by **how many pages the hot code
spans**, not by how many bytes it occupies. That gives two independent levers. **Reduce the number
of pages** — shrink the footprint or pack hot code together — which is layout and compiler work.
Or **make each page cover more code**: a single 2 MB huge page replaces 512 4 KB pages, so one
ITLB entry covers 2 MB of text instead of 4 KB. That is why `TLB_MISS_OPTIMIZATION` is the guide
attached to this metric and why it is usually the cheapest fix available — a configuration change,
no rebuild. On kernels ≥ 6.9, THP is extended with **folios** offering 16 KB and 64 KB pages in
addition to 2 MB, which the kernel can apply in more places, including file-backed text mappings.

**Because the threshold is 0.0, the firing itself carries almost no information — but the silence
does.** Every real workload does some instruction translation, so this rule fires on essentially
every run that collected `perf_stat`. Its *absence*, on a profile that defines the metric, means
the metric was missing or identically zero — a collection question, not a workload one.

**What this metric counts is not the same quantity on every vendor.** On arm64 it is
`L1I_TLB_REFILL` (event `0x2`); on generic Intel and Ice Lake it is `0x85` umask `0x20`; on
Sapphire Rapids the config **refreshes** it to `0x11` umask `0x20`; on AMD it is
`Instruction_TLB_Misses`, event `0x84`. On the Intel and AMD encodings the miss counter and the
walk counter are **disjoint**, which changes the arithmetic — see
`Architecture-specific considerations`.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator string `"greater than"`:

```
At least one data point in aperf_record is 2.50 (greater than the threshold of 0).
```

**Four things that sentence does not tell you.**

1. **`2.50` is the worst-*scoring* sample, not the worst sample and not the average.** See
   `The processing defect` above. The peak may be higher and is not recoverable from this text.
2. **It may be one CPU's series, not the run's.** This template iterates **every** series
   including per-CPU (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`),
   unlike the stat-based `perf_stat` rules which read only `Aggregate` (`:432`). One hot core
   fires this for the whole run.
3. **The value is truncated, not rounded** (`f64_to_fixed_2`,
   `src/computations/mod.rs:138`), so `2.50` is anything in `[2.50, 2.51)`, and
   `(greater than the threshold of 0)` is printed rather than computed.
4. **There is no `(n−1)/n` dilution correction here.** `perf_stat` opts out of the forced first
   zero via `use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`), unlike `ena_stat`
   and `cpu_utilization`, so the first sample is real and the average is not understated.

Score math — `compute_finding_score(value, 0.0, −1)`, the `threshold == 0.0` branch:

| worst-scoring sample | score | note |
|---|---|---|
| 0.05, 0.99 | **−1.00** | flat: every value below 1.0 scores identically |
| **1.00** | **−0.00** | collapses to zero; renders **grey** |
| 1.50 | **−0.50** | *milder* than a 0.05 sample |
| 2.00 | **−1.00** | collides with the whole sub-1.0 range |
| 12.00 | **−11.00** | |

Above 1.0 recover the sample as `value = |score| + 1`. Below 1.0 it is **not** recoverable:
`|score| = 1.00` has two disjoint preimages — the entire interval below 1.0, and exactly 2.0.
`recover_value_from_score()` returns both rather than guessing.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The metric is identically zero across every sample | no finding. On a profile that defines `inst-tlb-mpki` this is implausible for real code; read it as a collection problem |
| The only exceeding sample is exactly 1.0 | the finding exists at score **−0.00** and renders grey with a neutral icon. Sorting by score buries it below every positive finding |
| Only one `CPU{n}` series exceeded | the finding is reported for the run, and the `Aggregate` series may be benign |

## Interpretation

Because the rule fires on any non-zero value, **the magnitude read off the series is the finding**:

| sustained value | Reading |
|---|---|
| < 0.5 | Essentially universal. Ignore unless the frontend is dominant and everything else is clean |
| 0.5–2 | Mild instruction-translation pressure. Worth a cheap fix (THP) if the frontend is dominant |
| 2–10 | Real ITLB pressure; huge pages likely to give a measurable win |
| > 10 | Severe — the instruction footprint substantially exceeds ITLB coverage |

| `inst-tlb-mpki` elevated **and** | Reading |
|---|---|
| sustained across the series | Genuine and actionable; one isolated sample is startup, dynamic linking or JIT, and is not |
| `Frontend-Dominated CPU Stalls` fired | **The confirmed case** — translation is contributing to the bottleneck. If `Backend-Dominated CPU Stalls` fired instead, this is secondary: fix the backend first |
| `Instruction TLB Table Walks` also fired | Misses are escalating. **On arm64 the walk count is a subset of this one; on Intel and AMD it is not** — see the architecture section before computing a ratio |
| `inst-l1-mpki` also high | Large instruction footprint is the common root cause of both |
| `High Code Sparsity` also fired (arm64 only) | The hot code spans more pages than its size requires — a layout fix reduces this directly |
| `Huge Page Disabled` also fired | **Direct, cheap fix available** — THP is off at the kernel-config level |

**Known false positives — most firings of this rule fall here:**

- **Any non-zero value fires it.** The defining condition. 0.02 MPKI is measurement floor. And the
  reported value understates the peak, so a "small" description value does not rule out a large
  sample either way; read the series.
- **A single transient sample.** Startup, dynamic linking and JIT compilation touch cold code
  across many pages and always generate ITLB misses.
- **PMU multiplexing.** With a zero threshold there is nothing to absorb extrapolation noise.
  **This is the single most likely false-positive combination in the whole `perf_stat` family**,
  and it applies equally to the other three `threshold: 0.0` TLB rules.
- **One hot CPU.** The rule reads every per-CPU series, so a single scattered thread fires it for
  the run while the aggregate is benign.
- **Idle-diluted run.** Background daemons execute scattered code and generate their own misses.
- **Kernel-heavy workloads.** Kernel text is large; if `system` time dominates, much of the
  translation cost is kernel-side and not addressable by rebuilding the application.
- **Interpreted / JIT runtimes.** A large runtime plus dynamically generated code spans many
  pages by construction — structural, not a defect.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `inst-tlb-mpki` full series and per-CPU | `perf_stat` | **Do this first.** The description names one firing sample, not the peak, and possibly one CPU's |
| `inst-tlb-tw-pki` | `perf_stat` | Whether misses escalate to full page-table walks. **The relation is vendor-dependent** — see `Instruction TLB Table Walks` |
| `stall-frontend-pkc` vs `stall-backend-pkc` | `perf_stat` | **Severity gate.** ITLB misses cost frontend cycles. See `Frontend-Dominated CPU Stalls` |
| `inst-l1-mpki`, `branch-mpki`, `ipc` | `perf_stat` | Large instruction footprint drives L1I misses, mispredictions and ITLB pressure together, and `ipc` says whether the pipeline is suffering at all. See `High L1 Instruction Cache Misses` |
| `code-sparsity` | `perf_stat` | Scattered hot code spans more pages than necessary. **arm64 only** — see `High Code Sparsity` |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate — critical here.** With a zero threshold, extrapolation noise alone can fire this rule |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | **The fix check.** If `Huge Page Disabled` fired, THP is off and the cheapest remediation is available |
| `AnonHugePages`, `HugePages_Total`, `HugePages_Free`, `Hugepagesize` | `meminfo` | Whether huge pages are configured and actually in use |
| PageBlocks series | `memalloc` | Memory fragmentation preventing huge-page allocation. **No analytical rules — read manually** |
| `Kernel Version` | `systeminfo` | ≥ 6.9 supports 16 KB / 64 KB folios, easier to allocate under fragmentation |
| `user` vs `system` | `cpu_utilization` | Whether the missing translations are for application or kernel text |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| On-CPU profile | `perf_profile` / `java_profile` | Which code regions execute during elevated intervals. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | Instruction-address attribution. Native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |

## Guidance

Ordered. Steps 1–2 eliminate most firings.

1. **Read the series, not the description.** The threshold is zero, so firing means nothing on its
   own, and the reported value is the worst-*scoring* sample rather than the peak. A sustained peak
   **< 0.5** is measurement floor — stop. An **isolated spike** at run start or a phase boundary is
   a warm-up artifact — stop. **Sustained and above ~0.5** ⇒ continue, checking the per-CPU series
   first, since one scattered thread fires this rule for the whole run.

2. **Gate hard on measurement confidence.** Check `mux_counter_schedule_rate`
   (`PMU Counter Collection Multiplexing`). A zero-threshold rule has no noise margin — if
   multiplexing was active, a small non-zero value may be pure extrapolation artifact. Also check
   `avg(idle)` (`Underutilized CPU`).

3. **Confirm the frontend is the bottleneck.** Compare `stall-frontend-pkc` and
   `stall-backend-pkc` and read `ipc`. Frontend dominant with low IPC ⇒ actionable; otherwise
   record as secondary, since translation is not where the cycles are going.

4. **Check whether misses escalate to walks, using the right arithmetic for the profile.** Read
   `inst-tlb-tw-pki` (`Instruction TLB Table Walks`). On **arm64** the walk counter is a subset of
   this one, so `tw / mpki` is an escalation fraction bounded by 1.0. On **Intel, Ice Lake,
   Sapphire Rapids and AMD** the two counters are disjoint, so total misses is `mpki + tw` and the
   fraction is `tw / (mpki + tw)`. Do not compute the ratio by hand:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --tlb --miss-pki 2.50 --walk-pki 2.10 \
         --profile intel --tlb-side instruction
   relation: disjoint, total_misses_pki: 4.6, escalation_fraction: 0.457, thp_leverage: moderate
   ```

5. **Check whether huge pages are already available — the cheapest possible fix.** Read
   `CONFIG_TRANSPARENT_HUGEPAGE` in `kernel_config` (see `Huge Page Disabled`),
   `AnonHugePages` / `HugePages_Total` / `Hugepagesize` in `meminfo`, and `Kernel Version` — on
   ≥ 6.9 the smaller folio sizes are available. If THP is disabled or unused, that is the first
   remediation to try, because it requires no rebuild.

6. **Decide footprint vs layout.** Read `inst-l1-mpki` and, on arm64, `code-sparsity`. If both are
   elevated, the hot code spans more pages than it needs to, and profile-guided layout reduces ITLB
   pressure, L1I misses and branch mispredictions together — a better investment than huge pages
   alone. On x86 `code-sparsity` does not exist, so its absence is not evidence of good layout.

7. **Only then remediate**, applying both levers as they apply. The **translation lever**
   (`TLB_MISS_OPTIMIZATION`): enable THP with
   `echo always > /sys/kernel/mm/transparent_hugepage/enabled` (or `madvise` for opt-in workloads);
   on kernels ≥ 6.9 tune the folio sizes under
   `/sys/kernel/mm/transparent_hugepage/hugepages-{16kB,64kB,2048kB}/enabled`; for `mmap`-based
   applications reserve pinned huge pages via `sysctl -w vm.nr_hugepages=X` or
   `hugepagesz=2M hugepages=512` in `/etc/default/grub`; for Java add
   `-XX:+UseTransparentHugePages` (THP at least `madvise`) or `-XX:+UseLargePages`. The
   **footprint lever** (`INSTRUCTION_FOOTPRINT_OPTIMIZATION`): `-flto`, `-Os`, AutoFDO for C/C++;
   `-XX:+TieredCompilation` and code-cache sizing for Java.

## Priority and execution risk

**Priority: P4 — Informational** by default, and that is the honest baseline: a zero-threshold rule
fires on essentially every run, so its presence ranks nothing. It rises to **P3 — Monitor** once
the sustained value is above roughly 0.5, to **P2 — Investigate** when `Frontend-Dominated CPU
Stalls` also fired and `ipc` is low — the only combination in which instruction translation is
demonstrably costing cycles — and to **P1 — Act now** when that holds *and* `Huge Page Disabled`
also fired, because then a materially costly problem has a configuration-only fix. It drops back to
**P4** whenever the run multiplexed, since a zero-threshold rule has no noise margin, and stays at
**P3 at most** when only one `CPU{n}` series is elevated, since the finding then describes a thread
rather than the instance.

**Execution risk: R0 — Read-only** to diagnose: the series, the per-CPU split, the stall comparison,
the escalation fraction and the THP configuration are all reads. Acting is **R4 — Infrastructure
change** for enabling THP or reserving huge pages, which changes allocation behaviour machine-wide
and can fail under fragmentation; **R3 — Rebuild** for the footprint lever. **Do not inherit the R0
of the diagnosis into the THP change:** THP costs allocation latency and wastes memory on
partially-used pages, so it is a real infrastructure decision even though it is one `echo`.

**The score is amplified, non-monotonic, and unusable for ranking.** Every value below 1.0 scores
exactly −1.00, exactly 1.0 scores −0.00 and renders **grey**, and only above 2.0 does `|score|`
exceed the flat branch — so a run peaking at 1.9 sorts below one peaking at 0.01. **Rank on the
sustained value read from the series, never on score.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `inst-tlb-mpki`, in any series including per-CPU, exceeded
`0.0` (`Greater 0.0`, so exactly zero does not fire).

```
STEP 0 — Does the perf_stat data exist, and is this metric defined on this profile?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `perf_stat` exists and this finding is ABSENT
  THEN → `inst-tlb-mpki` is defined on all 8 PMU profiles, so absence means the metric was
         missing or identically zero across every sample -- implausible for real code. Read
         it as a COLLECTION problem, NOT as evidence of clean translation (P3, R0)
  IF the finding fired
  THEN → the firing itself carries almost no information (threshold 0.0):
         continue to STEP 1

STEP 1 — Recover the real magnitude. The description does NOT give it: the reported value is
         the worst-SCORING sample, which on a zero-threshold rule is frequently the LEAST
         severe firing sample.
  IF the score is exactly -0.00 and the finding renders GREY
  THEN → the only exceeding sample was exactly 1.0 (mod.rs:170 collapses it,
         AnalyticalFindings.tsx:35 paints score==0 grey): a negative finding disguised as a
         non-event, to be read as a value of 1.0 (P3, R0)
  IF the score is exactly -1.00
  THEN → AMBIGUOUS by construction: the preimage is the whole interval below 1.0 PLUS
         exactly 2.0. Do not infer severity from it; read the series (P4, R0)
  IF the series peak exceeds the reported value
  THEN → expected, not a bug in the report: `>=` plus the V-shaped score prefers a smaller
         sample. Use the PEAK for every branch below (P3, R0)
       → verify: `../tools/aperf_memory_hierarchy.py --select <series>` reproduces the
         template's choice; if it disagrees with the report, the series you read is not the
         series the rule saw (suspect a per-CPU series)

STEP 2 — Gate on measurement confidence. A zero threshold has NO noise margin.
  IF `mux_counter_schedule_rate` < 100
  THEN → extrapolation alone can produce a non-zero sample from a workload with effectively
         no ITLB pressure. Report low-confidence and do NOT act (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the value collapses toward zero,
         the original finding was multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons execute scattered code and contribute their own misses, so the
         value is diluted with behaviour that is not the workload's (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES
         confirms the workload, one that falls confirms the daemons
  IF only one or two `CPU{n}` series are elevated
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one
         scattered thread fires it for the whole run: a thread, not the instance (P3, R0)
       → verify: the on-CPU profile names a thread whose code footprint is distinct; a fix
         targeted at it should move that CPU's series and barely move the aggregate

STEP 3 — Is the frontend actually the bottleneck? This decides whether ANY of it matters.
  IF `Frontend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: instruction supply is the bottleneck and translation is one of
         its causes. Continue (P2, R0)
  IF `Backend-Dominated CPU Stalls` fired
  THEN → SECONDARY. Instruction translation is not where the cycles are going; fix the
         backend first and re-measure. Record and STOP (P4, R0)
  IF NEITHER stall finding fired
  THEN → the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence of
         health: 600 pkc on both sides fires nothing. Read both absolutes directly (P3, R0)
  IF the run is on generic `amd`
  THEN → `stall-backend-pkc` does not exist there, so BOTH stall rules are structurally
         silent and this severity gate is UNREADABLE. Use `ipc` alone (P3, R0)

STEP 4 — How far does the pressure escalate? The arithmetic is VENDOR-DEPENDENT: miss and walk
         counters are nested on arm64 and disjoint on Intel and AMD, so a single cross-vendor
         `tw / mpki` formula is wrong somewhere.
  IF the profile is `grv` or `grv5`
  THEN → NESTED (events 0x2 and 0x35): `inst-tlb-tw-pki / inst-tlb-mpki` IS the escalation
         fraction and is bounded by 1.0. A ratio above 1.0 is impossible and means
         multiplexing distorted one counter (P2, R0)
       → verify: `--tlb --profile grv --tlb-side instruction` clamps and flags it; if it
         flags, fix the collection before reading the fraction
  IF the profile is `intel`, `icelake` or `spr`
  THEN → DISJOINT (same event, umasks 0x20 vs 0x1 — or 0x11/0x20 vs 0x11/0xe on spr). Total
         misses is `mpki + tw`, NOT the mpki this finding reports, and raw `tw / mpki` is an
         odds ratio that may legitimately exceed 1.0 (P2, R0)
       → verify: `--tlb --profile <p> --tlb-side instruction` returns the corrected total and
         a fraction in [0, 1]; a hand-computed ratio above 1.0 means you used the wrong
         relation
  IF the profile is `amd`, `milan` or `genoa`
  THEN → DISJOINT by vendor semantics (0x84 counts L1 ITLB misses that HIT the L2 ITLB, 0x85
         those that missed it). Same correction as Intel, but derived from AMD's event
         documentation rather than from the umask bits (P2, R0)
       → verify: `--tlb --profile amd --tlb-side instruction` flags the derivation as
         `vendor` rather than `umask`; report that caveat to the reader
  IF the escalation fraction is >= 0.5
  THEN → most misses reach a full page-table walk, each costing 4-5 dependent memory
         references. HUGE PAGES are the primary lever, because they remove the misses rather
         than making the walks cheaper. Below ~0.2 the intermediate caches absorb most misses
         and the walk cost is small however large the miss count (P1, R4)
       → verify: `inst-tlb-tw-pki` falls toward zero after enabling THP; the walks are the
         expensive tail, so they should fall faster than the misses

STEP 5 — Is the cheap fix already available? MANDATORY manual check: aperf reports the THP
         kernel config but not the runtime `/sys` setting.
  IF `Huge Page Disabled` fired
  THEN → `CONFIG_TRANSPARENT_HUGEPAGE` is off at the KERNEL level, so no runtime setting can
         turn THP on: a kernel change, not an `echo` (P1, R4)
       → verify: after enabling, `AnonHugePages` in `meminfo` becomes non-zero AND
         `inst-tlb-mpki` falls; a rising AnonHugePages with a flat mpki means the huge pages
         went to data, not text
  IF THP is configured but `AnonHugePages` is far below the workload's footprint
  THEN → fragmentation is preventing allocation. Check the `memalloc` PageBlocks series for
         high-order free blocks; the fix is compaction settings, boot-time reservation, or
         the smaller folio sizes on kernels >= 6.9 (P2, R4)
       → verify: AnonHugePages rises toward the footprint after the change, and only then
         should inst-tlb-mpki be re-read
  IF `Kernel Version` is < 6.9
  THEN → only 2 MB pages are available, which are the hardest to allocate under
         fragmentation. The 16 kB / 64 kB folios that would help here need a newer kernel
         (P3, R4)
       → verify: on a >= 6.9 kernel the per-size `enabled` files under
         /sys/kernel/mm/transparent_hugepage/hugepages-*/ exist and AnonHugePages rises

STEP 6 — Footprint or layout? This decides between a config change and a rebuild.
  IF `inst-l1-mpki` is ALSO above 20 and (on arm64) `code-sparsity` is above 0.5
  THEN → the hot code spans more pages than its SIZE requires: a layout problem. Profile-
         guided layout lowers ITLB misses, L1I misses and branch mispredictions together,
         which is a better investment than huge pages alone (P2, R3)
       → verify: all three of inst-tlb-mpki, inst-l1-mpki and branch-mpki fall together. If
         only one moves, the layout change did not address the shared cause
  IF `inst-l1-mpki` is high but the profile is x86
  THEN → `code-sparsity` does not exist on any Intel or AMD config, so the layout-vs-size
         question is NOT answerable from aperf data there. Its absence is not evidence of
         good layout (P3, R0)
       → verify: an AutoFDO or PGO rebuild that lowers inst-l1-mpki confirms layout was the
         driver; no aperf metric can predict it on x86 beforehand
  IF `inst-l1-mpki` is low while this finding is elevated
  THEN → the code CACHES well but is spread across many pages: a pure TRANSLATION problem,
         and the cleanest huge-page case in this playbook (P2, R4)
       → verify: inst-tlb-mpki falls after THP while inst-l1-mpki stays flat — the signature
         of a translation-only fix

STEP 7 — What survives?
  VALID      : the per-CPU and aggregate `inst-tlb-mpki` series read as magnitudes; the stall
              split read as absolute pkc; and every non-PMU finding in the run
  CAUTION    : the reported VALUE, which is the worst-scoring rather than the worst sample;
              and any escalation fraction computed without the profile's set relation
  CONFOUNDED : the value on a multiplexed run, where a zero threshold has no noise margin;
              and on an idle-diluted run, where daemon code contributes
  VOID       : any severity claim from the SCORE, which is non-monotonic and flat below 1.0;
              and any cross-architecture comparison of this metric, since the event encoding
              differs on every vendor and spr refreshed it while its siblings did not

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF this finding is absent while `perf_stat` was collected
  THEN → the metric was missing or identically zero. NOT evidence of clean translation, since
         for real code an identically-zero ITLB miss rate is implausible (P3, R0)
```

## Runtime-specific consequences

Instruction translation pressure is a property of **how many pages the hot code spans**, so the
runtime matters through the *size and locality of the code it executes on your behalf* — for three
of the four, code you did not write and cannot lay out.

| Runtime | Why the ITLB misses, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **.NET** | Tiered JIT emits tier-0 code, then re-emits hot methods at tier 1 into *different* pages, so the hot set moves during warm-up and the steady-state layout is chosen by the JIT. ReadyToRun images are laid out ahead of time and span fewer pages | `DOTNET_TieredCompilation` and `DOTNET_TieredPGO` (better steady-state layout at the cost of a longer warm-up), and whether the app ships as ReadyToRun. Layout is the axis; THP on text needs file-backed THP support |
| **Python** | The interpreter loop is small and hot, so CPython itself is ITLB-friendly — but the *extension* surface is not: a large NumPy/SciPy/torch stack is tens of megabytes of native text reached through dispatch. Usually **not** the bottleneck, and rarely a defect | Whether the miss rate tracks native-extension calls rather than Python-level work. If pure-Python code shows high ITLB misses, suspect the profile is measuring import/startup rather than steady state |
| **Java** | The largest real case. JIT-compiled code lands in the **code cache**, whose default size (240 MB reserved) far exceeds ITLB coverage, and tiered compilation keeps both tier-0 and tier-1 versions live. A large hot method set scatters across the cache by construction | `jvmArguments` for `-XX:ReservedCodeCacheSize` (a smaller cache packs hot code into fewer pages) and `-XX:+UseTransparentHugePages`. Check `java_profile` for whether the hot set is genuinely large or an artifact of insufficient warm-up |
| **Perl** | The op tree is walked per statement, so execution jumps across the interpreter's own text plus every loaded XS module. Perl is normally **frontend**-heavy for this reason, and that is expected rather than a finding | Whether hot loops can move into XS or a C library, which shrinks the interpreted path. There is no code-layout flag to tune, which makes THP relatively more attractive here |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is
inferred from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot
be identified, stop at STEP 5: the THP question is runtime-independent, and it is the only
remediation here that needs no knowledge of who generated the code. For **all four**, a JIT or
interpreter means the *runtime* chooses the code layout, so the honest first move is a runtime
setting, not a source change.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — registry `architectures` lists every one and
`architecture_note` is empty. That is accurate about *availability* and silent about what matters:
**the counter is a different event on every vendor, and its relationship to the walk counter is not
the same relation.**

| Profile | `Instruction_TLB` encoding | Relation to `Instruction_TLB_TW` |
|---|---|---|
| `grv`, `grv5` | `armv8_pmuv3_0/event=0x2/` — L1I TLB refill | **NESTED** in `0x35`; a walk is a consequence of a refill, so `tw / mpki` is a fraction bounded by 1.0. Derived from the Arm ARM, not from the config |
| `intel`, `icelake` | `cpu/event=0x85,umask=0x20/` | **DISJOINT** from `0x85` umask `0x1` — same event, non-overlapping umasks, so the two count mutually exclusive outcomes. Total misses is the SUM |
| `spr` | `cpu/event=0x11,umask=0x20/` — **refreshed** by the SPR override | **DISJOINT** from `0x11` umask `0xe`, a multi-bit page-size breakdown. Total misses is the SUM |
| `amd`, `milan`, `genoa` | `cpu/event=0x84,umask=0x0/` | **DISJOINT** from `0x85` umask `0xf`: AMD documents `0x84` as an L1 ITLB miss that HIT the L2 ITLB and `0x85` as one that missed it. Different event codes, so this comes from vendor docs |

The umask relations are re-derived from `src/pmu_configs/*.json` by
`test_aperf_memory_hierarchy.py::test_tlb_pairings_are_derived_from_umask_bits`, so they cannot
drift silently; the two `vendor`-derived rows are flagged as such because the config alone cannot
settle them.

**The consequence is a wrong number, not a missing one.** On Intel and AMD, a reader who computes
`inst-tlb-tw-pki / inst-tlb-mpki` gets an odds ratio and may find it above 1.0 — which looks like
a collection bug and is not. Worse, the *total* instruction-TLB miss rate there is `mpki + tw`, so
**this finding understates translation pressure on five of the eight profiles.** `tlb_pressure()`
refuses to run without a profile key for exactly this reason.

**Sapphire Rapids is the profile where the config's own priorities are visible.** The SPR override
refreshes `Instruction_TLB` (`0x85` → `0x11`) and `L2` (`0xf1` → `0x25`), and adds
`data-rd-tlb-*` / `data-st-tlb-*` on `0x12` / `0x13` — yet leaves the *data* TLB pair on the
inherited `0x8`. So the instruction side, which this playbook covers, is the side SPR **did**
update; see `data-tlb-misses.md` for the side it did not.

**Counter mode changes whether the finding is trustworthy.** Grouped is the default
(`src/data_collection.rs:379`) and creates one counter per event per metric group
(`src/data/perf_stat.rs:217`–`:221`), roughly doubling register pressure versus
`--ungroup-pmu-events`. A zero-threshold rule is the most exposed of all to the resulting
extrapolation ([../ARCHITECTURE.md](../ARCHITECTURE.md) §3.4). Finally, aperf has no architecture
field and no rule compares `Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an
Intel→Graviton comparison with matched `CPUs` and `MemTotal` fires **no gate**, yet the ITLB
geometry, the page size, and this counter's own definition all changed — so "instruction TLB misses
improved" across that pair is not a measurement.

## Verification

Apply the fix STEP 5 or STEP 6 identified, re-record at the **same geometry, same counter mode,
and same instance type**, and check the pair rather than either number alone: the sustained
`inst-tlb-mpki` should fall **and** `stall-frontend-pkc` should fall with it in absolute pkc. If
the miss rate falls and the frontend stall does not, translation was not the frontend's
constraint and STEP 6's footprint branch is still open — the common outcome when THP is enabled on
a workload whose real problem is L1I capacity. If `inst-tlb-mpki` falls but the finding
**persists**, that is expected and not a failure: with a zero threshold the rule fires until the
metric is identically zero, which never happens on real code. This finding therefore
**cannot be verified by its own presence or by its score** — a materially improved run still fires
it, and a worse run can score milder. The only sound verification is the magnitude plus the stall
split. For the THP path, also confirm `AnonHugePages` actually rose: an unchanged `AnonHugePages`
means the setting was accepted and the allocation failed, so nothing was tested.

## Do not

- **Do not treat the firing itself as a problem.** The threshold is 0.0 — nearly every real
  workload fires this rule, so its presence ranks nothing. Its *silence* is the informative case,
  and it means a collection problem rather than clean translation.
- **Do not treat the reported value as the worst sample, or as the average.** It is the
  worst-**scoring** sample: `[0.30, 1.50]` reports `0.30`, and a score tie is broken by `>=` in
  favour of whichever came last. Read the series.
- **Do not rank severity by score.** Every value below 1.0 scores exactly −1.00, exactly 1.0 scores
  −0.00 and renders **grey with a neutral icon**, and only above 2.0 does `|score|` exceed the flat
  branch — so a run peaking at 1.9 sorts below one peaking at 0.01, and `−1.00` is ambiguous between
  "anything below 1.0" and "exactly 2.0".
- **Do not compute `inst-tlb-tw-pki / inst-tlb-mpki` without the profile's set relation.** The
  counters are nested only on arm64. On Intel and AMD they are disjoint, so total misses is
  `mpki + tw`, the escalation fraction is `tw / (mpki + tw)`, and a raw ratio above 1.0 is
  legitimate rather than a collection bug. It follows that **this finding is not the total
  instruction-TLB miss rate** on those five profiles — it is the non-escalating half only, and it
  **understates** translation pressure there.
- **Do not act on a non-zero value when `mux_counter_schedule_rate` is below 100.** A
  zero-threshold rule has no noise margin, and extrapolation alone can fire it from a workload
  with no real ITLB pressure.
- **Do not read the value as characteristic of the instance.** This template iterates every
  series including per-CPU (`processed_data_accessor.rs:104`), so one scattered thread fires it
  for the whole run while the aggregate is benign.
- **Do not enable huge pages reflexively.** Confirm the frontend is dominant and the value is
  material first; THP costs allocation latency, can fail outright under fragmentation, and wastes
  memory on partially-used pages — an R4 change, not a free one.
- **Do not read a missing `High Code Sparsity` on x86 as good code layout.** `code-sparsity`
  exists only on `grv` and `grv5`, so the layout-vs-size question is structurally unanswerable
  from aperf data on Intel and AMD.
- **Do not confuse this with `Data TLB Misses`.** Instruction translation and data translation are
  separate TLBs with separate causes — code footprint vs data footprint — even though the huge-page
  fix helps both. And **do not optimize either while the workload is backend-bound**: fix the
  backend first, since the frontend fix buys nothing until instruction supply is the constraint.
- **Do not compare this metric across architectures.** The event differs on every vendor —
  `0x2` on arm64, `0x85/0x20` on generic Intel, `0x11/0x20` on Sapphire Rapids, `0x84` on AMD —
  and no aperf gate fires on an architecture change with matched `CPUs` and `MemTotal`.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:68` — `metric: "inst-tlb-mpki"`,
  `comparator: Comparator::Greater`, `threshold: 0.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117`
  — the selection loop keeps the largest `abs(finding_score)` using `>=`, so a later tie wins and
  the reported value is the worst-**scoring** sample. It iterates **every** series including
  per-CPU (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the
  stat-based rules which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `threshold == 0.0`
  branch at `:170` returns the flat `rule_score` below value 1.0 and `(value − 1.0) * rule_score`
  above, which is what makes `|score|` V-shaped and non-monotonic. `Score::Concerning = −1` at
  `:147`–`:157`. A score of exactly `0` is painted grey with the neutral icon by `getFindingColor`
  and `FindingIcon` (`src/report_frontend/src/components/analytics/AnalyticalFindings.tsx:35`).
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic
  config by `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:765`–`:797`.
  `Instruction_TLB` is `event=0x2` (grv, grv5), `event=0x85,umask=0x20` (intel, icelake),
  `event=0x11,umask=0x20` (spr — refreshed by the override), `event=0x84,umask=0x0` (amd, milan,
  genoa). `perf_stat` opts **out** of the forced first zero via `use_first_accumulative_value()`
  (`:1295`), so no `(n−1)/n` correction applies.
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) —
  `--select` reproduces the template's selection and names the trap that applies; `--tlb` returns the
  corrected total and escalation fraction for the profile and side. `test_aperf_memory_hierarchy.py`
  pins it, re-deriving the merged expressions, the event encodings and the umask-based TLB relations
  from `src/pmu_configs/*.json` and porting the selection loop independently.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a
  schedule rate of R% is an extrapolation factor of `100/R`. Grouped is the default
  (`src/data_collection.rs:379`), duplicates events per metric group (`perf_stat.rs:217`–`:221`),
  and the limit is probed at `:344`.
- Upstream guides: `TLB_MISS_OPTIMIZATION` (the remediation attached to this metric, with the exact
  THP/folio/reserved-page commands and the JVM flags) and `CPU_FRONTEND_STALLS_INVESTIGATION`, in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `instruction-tlb-table-walks.md` (the escalating half, and the vendor relation
  in full), `high-l1-instruction-cache-misses.md`, `high-code-sparsity.md`,
  `frontend-dominated-cpu-stalls.md` (the severity gate), `data-tlb-misses.md` (the data side, and
  the encoding SPR did *not* refresh), `pmu-counter-collection-multiplexing.md` (the confidence
  gate), `../kernel_config/huge-page-disabled.md`, `../cpu_utilization/underutilized-cpu.md`.
  Cross-cutting: [../GATES.md](../GATES.md), [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md),
  [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down front-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-front-end-stalls)
- [Arm Neoverse N3 — L1I TLB MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/ITLB-Effectiveness-metrics-for-Neoverse-N3?lang=en#md549-itlb_effectiveness_mg__l1i_tlb_mpki_m_ITLB_Effectiveness)
- [LWN — large folios](https://lwn.net/Articles/937239/)
