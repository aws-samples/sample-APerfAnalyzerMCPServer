---
rule_name: High Branch Mispredictions
data_type: perf_stat
data_key: branch-mpki
template: time_series_stat_threshold
condition: "avg(branch-mpki) >= 10.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "A large number of branch mis-predictions puts bottlenecks on the processor."
source: src/analytics/rules/perf_stat.rs:51
---

# High Branch Mispredictions

## What fired

The **average** of `branch-mpki` over the `Aggregate` series was **greater than or equal to 10.0**
branch mispredictions per thousand instructions. Base score `Concerning` (−1), single-run
(`requires_comparison: false`), filed under the `branch-mpki` key.

This is a **stat threshold**, not a data-point threshold: it reads `avg()` over the whole recording,
so a single spiking sample does not fire it. That makes this finding more robust than its `perf_stat`
siblings — `High L1 Instruction Cache Misses`, both TLB rules and `Old-Style Atomic Instructions` all
fire on one sample.

## The processing caveat — verified by reading the collection code

**`avg(branch-mpki)` is a mean of per-interval ratios, and the aggregation is *not*
instruction-weighted.** The two layers of averaging pull in opposite directions, and only the first
is benign:

- **Across CPUs, within one interval**, the `Aggregate` value is a *ratio of sums*: mispredicts
  summed over all CPUs divided by instructions summed over all CPUs (`src/data/perf_stat.rs:1118` –
  `:1148`). Correct for a ratio — a busy CPU dominates a quiet one, as it should — so **no CPU-count
  correction applies**. Its only blind spot is a single-CPU outlier.
- **Across intervals, within the run**, `Statistics::from_values` (`src/computations/mod.rs:27` –
  `:41`) takes the plain arithmetic mean of those per-interval ratios. Every interval gets **equal
  weight regardless of how many instructions it retired**, so a nearly-idle interval that executed
  100 K instructions counts exactly as much as a saturated one that executed a billion.

That second layer is a real inflation, not a rounding concern. Four intervals of
`(mispredicts, instructions)` = `(1e6, 1e9)`, `(2e3, 1e5)`, `(2e3, 1e5)`, `(2e3, 1e5)` — one busy
interval at 1.0 mpki plus three quiet ones at 20 mpki — give:

| aggregation | value | fires at `>= 10.0`? |
|---|---|---|
| mean of per-interval ratios — **what this rule reads** | **15.25** | **yes** |
| instruction-weighted — what the run actually did | **1.01** | no |

A **15.2× inflation**, and the finding fires on a run whose real misprediction rate is 1 per thousand
instructions. The mechanism is that low-instruction intervals have small denominators, so their ratios
are both noisier and larger, and the mean is pulled toward them. This is why STEP 2's dilution gate is
not boilerplate here: `avg(idle)` is the proxy for "how many of my intervals were nearly empty", and
an idle-diluted run does not merely blur this value — it **manufactures** it. Re-scoping with
`--time-range` to the loaded interval re-derives the stat from the surviving samples
(`compute_time_diff_index`, `processed_data_accessor.rs:597`); no re-record is needed.

Two smaller facts from the same read: **`perf_stat` is the one collector that keeps its first sample**
— `use_first_accumulative_value()` is called at `src/data/perf_stat.rs:1295` and nowhere else, so
unlike `ena_stat` and `cpu_utilization` there is no forced-zero first point — and the PMU counters are
**reset after every read** (`:517`, `:564`), so each interval's value is its own rate, not a running
total.

## Reasoning

`branch-mpki` is *"Number of branch prediction misses per thousand instructions indicating CPU
pipeline efficiency and code predictability"* (`data-descriptions.ts`, `desired: "lower"`).

Modern out-of-order cores are deeply pipelined and execute *speculatively*: on reaching a conditional
branch or indirect jump, the predictor guesses the outcome and the core keeps fetching and executing
down the predicted path before the real outcome is known. When the guess is wrong, everything
speculatively executed is discarded and the pipeline is refilled from the correct target. That is
**frontend** cost — the execution units sit idle while instructions are re-fetched — which is why
this metric is the first entry in `CPU_FRONTEND_STALLS_INVESTIGATION` and why the severity gate for
this finding is the stall split, not the value.

The arithmetic is what makes 10 MPKI matter. At 10 mispredicts per thousand instructions and ~11
wasted cycles each on Neoverse, mispredictions alone burn **110 cycles per thousand instructions**. A
thousand instructions at IPC 1.0 occupy 1000 cycles, so that is **11% of every cycle the CPU ran** —
before any cache or memory effect. The same 10 MPKI is 17% on Sapphire Rapids and 18% on Zen.

Predictors are extremely good — above 95% accuracy is routine — precisely because most branches are
regular: loop back-edges, error checks that never fire, type checks that always resolve the same
way. High MPKI therefore means the code contains branches that are **genuinely unpredictable**, and
the shapes that produce it are recognizable:

- **Data-dependent branching** — a comparison on high-entropy input: sorting or filtering unsorted
  data, `if (value > pivot)` on random keys. **Short, irregular loops** belong here too: trip counts
  that vary unpredictably mispredict on every exit.
- **Deep or polymorphic indirect dispatch** — C++ vtables, Java megamorphic call sites, interface
  dispatch: targets that change per call site or per object. **Large switch / jump tables** are the
  extreme: interpreter dispatch is one indirect branch whose target is a new bytecode each iteration.
- **Very large branch footprint** — so many distinct branches that they thrash the predictor's own
  history tables. A *capacity* problem, not a predictability one; it overlaps with instruction
  footprint, and it is why `INSTRUCTION_FOOTPRINT_OPTIMIZATION` is the attached guide.

**The counter is a rate per instruction, not per branch.** Control-heavy code with a high branch
*density* can show high MPKI at a perfectly normal misprediction rate *per branch*. aperf collects no
branch count on any profile, so **per-branch accuracy is not derivable** — the hard limit on how far
this finding can be pushed, and the reason the capacity cause cannot be separated from the other two
without a profile.

## Reading the description

`time_series_stat_threshold` emits exactly one form:

```
The {stat} in {run_name} is {value}.

The average in aperf_record is 14.30.
```

**Four things that sentence does not tell you.**

1. **`14.30` is `avg(branch-mpki)` — mispredicts per thousand *instructions*, not per branch** — and
   **`{run_name}` is the run being described, not a baseline.** The threshold (10.0) and the
   comparator (`GreaterEqual`, so exactly 10.0 fires) appear nowhere in the text; both are implicit
   in the rule. It is a single-run threshold: no comparison, no base run, so it stays readable when
   every cross-run comparison in the report is void.
2. **The number carries no cycle cost, which is the only form in which it is actionable.** Multiply
   by the profile's per-misprediction penalty — ~11 cycles on Graviton, ~17 on Intel, ~18 on AMD —
   and divide by `1000 / ipc` for percent-of-cycles. At 14.30 mpki on Graviton that is 157 cycles per
   thousand instructions, **15.7% of all cycles at IPC 1.0**.
3. **It is a mean of per-interval ratios, so it is not instruction-weighted** — see the caveat
   section above, where an idle-diluted run reads 15.25 against a true 1.01.
4. **The value is truncated, not rounded** (`f64_to_fixed_2`,
   `src/computations/mod.rs:138`), so `14.30` means `[14.30, 14.31)`. The score is
   computed from the untruncated average, so it is the more precise of the two.

Score math — `compute_finding_score(value, 10.0, −1)`. The value always satisfies `>= threshold` here,
so the reciprocal branch is unreachable and the score is exactly `value / 10 × −1`:

| avg(branch-mpki) | 10.0 (minimum) | 14.3 | 25.0 | 50.0 |
|---|---|---|---|---|
| score | **−1.00** | **−1.43** | **−2.50** | **−5.00** |
| recovered `\|score\| × 10` | 10.0 | 14.3 | 25.0 | 50.0 |

The score is a linear restatement of the value, so it is exactly recoverable — `avg(branch-mpki) =
|score| × 10` — and, unusually for an amplified score, it is **not** blind to magnitude the way the two
stall rules' scores are. The problem is the opposite, and `Priority and execution risk` below has it:
the `Concerning` base makes even a severe value sort low. Both the `value == 0.0` and
`threshold == 0.0` branches of `compute_finding_score` are unreachable here, so there is no zero trap
on this rule.

## Interpretation

Below 5 the predictor is doing its job. 5–10 is elevated but produces **no finding**, and since the
mean-of-ratios defect biases *upward* the true rate is at most that. Above 40 is severe and usually
structural — interpreters, VMs, heavily branch-bound code. Between 10 and 40 the band alone decides
nothing; the cycle budget does. **That budget is what makes the value actionable**: cycles lost per
thousand instructions is `mpki × penalty`, and the same figure as percent-of-cycles at the observed
IPC is `× ipc / 10`.

| profile (penalty) | 10 mpki | 15 mpki | 25 mpki | 40 mpki |
|---|---|---|---|---|
| `grv`, `grv5` (~11 cyc) | 110 cyc — **11.0%** at IPC 1.0 | 165 — 16.5% | 275 — 27.5% | 440 — 44.0% |
| `intel`, `icelake`, `spr` (~17 cyc) | 170 cyc — **17.0%** at IPC 1.0 | 255 — 25.5% | 425 — 42.5% | 680 — 68.0% |
| `amd`, `genoa`, `milan` (~18 cyc) | 180 cyc — **18.0%** at IPC 1.0 | 270 — 27.0% | 450 — 45.0% | 720 — 72.0% |

Percent-of-cycles scales *with* IPC, because higher IPC packs the same thousand instructions into
fewer cycles: 25 mpki on Graviton is 13.8% of cycles at IPC 0.5 but 55.0% at IPC 2.0. When the estimate
exceeds 100% the flat penalty has over-counted — real cores overlap recovery with other work, and the
full penalty is only exposed when the pipeline was otherwise full. Treat any figure above ~60% as
"this dominates" rather than as a literal fraction. The value only becomes a *conclusion* in
combination:

| `branch-mpki` high **and** | Reading |
|---|---|
| `Frontend-Dominated CPU Stalls` fired | **The confirmed case.** Mispredictions are a leading contributor to the frontend bottleneck |
| `Backend-Dominated CPU Stalls` fired | Real but not the bottleneck — the mispredicts are hidden behind memory latency. Note it; fix the backend first |
| **neither** stall rule fired | The dead zone (`be/fe ∈ (1/1.1, 1.1)`) or no `perf_stat` stall metrics. Read both absolute pkc values before concluding anything |
| `ipc` > 2, or < 1 with frontend dominance | Above 2 the core is absorbing it — low priority whatever the mpki. Below 1 with frontend dominance is the top optimization candidate |
| `code-sparsity` > 0.5, or `inst-l1-mpki` high | Large instruction footprint thrashing the I-cache *and* the predictor tables. Layout is the common cause — one fix serves both |
| `Underutilized CPU` fired | **Suspect the value itself** — the mean-of-ratios inflation lands here |

**Known false positives**, all of them reasons to stop before recommending a code change, each expanded
in `Do not`: a **data-dependent algorithm or a runtime** (sort, parse, compress, bytecode dispatch —
the unpredictability is the problem's nature); **high branch density at normal per-branch accuracy**,
which aperf cannot distinguish because it collects no branch count; an **idle-diluted or
startup-inflated window**, both being the mean-of-ratios defect; **PMU multiplexing**, which
extrapolates numerator and denominator alike by `100/rate` across a threshold that sits close to
healthy values; and a **cross-architecture expectation**, since arm64 counts a speculative event over a
retired denominator while x86 counts retired over retired.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `stall-frontend-pkc` vs `stall-backend-pkc` | `perf_stat` | **The severity gate.** Mispredicts cost frontend cycles; if the frontend is not dominant this is not the bottleneck. See `Frontend-Dominated CPU Stalls` |
| `ipc` | `perf_stat` | Converts the cycle budget into percent-of-cycles, and says whether the pipeline is actually suffering |
| `code-sparsity`, `inst-l1-mpki`, `inst-tlb-mpki`, `inst-tlb-tw-pki` | `perf_stat` | Whether this is instruction *footprint* rather than pure unpredictability — scattered hot code hurts prediction and fetching alike. All elevated together ⇒ fix layout once. `code-sparsity` is **`grv` only**; its absence is not evidence |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ numerator and denominator are both extrapolated |
| `branch-mpki` full series and per-CPU `CPU{n}` | `perf_stat` | Steady state vs startup; and whether one thread or the whole instance. The interval spread is also the dilution check |
| `idle`, `aggregate` | `cpu_utilization` | Dilution gate — quiet intervals inflate the mean of ratios |
| `user` vs `system` | `cpu_utilization` | High `system` ⇒ the mispredicting code may be kernel code you cannot recompile |
| On-CPU profile; Hotline output | `perf_profile` / `java_profile`; `hotline` | Which functions execute the unpredictable branches, and — on metal Graviton for native code — the specific instruction. Both require `--profile`. **Neither has analytical rules**, and `hotline` has no `data-descriptions.ts` entry |
| `Excessive Exceptions`, `Excessive Time in Symbol` | `java_profile` | Exception-based control flow mispredicts heavily and is a concrete, fixable cause; the symbol rule points at the method to inspect |
| `Instance Type`, `jvmArguments` | `systeminfo` / profile metadata | The penalty and the speculative-vs-retired counting both depend on the CPU; the JVM flags decide whether a Java frontend fix exists |

## Guidance

Ordered. Steps 1–3 establish whether the number is real and whether it matters; most firings do not
warrant a code change on their own.

1. **Convert to a cycle budget before anything else.** `mpki × penalty` cycles per thousand
   instructions, then `× ipc / 10` for percent-of-cycles;
   `tools/aperf_perf_stat.py --branch --mpki M --profile P --ipc-value I` does both and prints the
   profile's counting caveat. A value with no cycle figure attached cannot be prioritized.

2. **Gate on measurement confidence — this rule needs it twice over.** Check
   `mux_counter_schedule_rate` (`PMU Counter Collection Multiplexing`) and `avg(idle)`
   (`Underutilized CPU`). Multiplexing extrapolates both the mispredict count and the instruction
   denominator; idle dilution inflates the mean of ratios directly, by up to an order of magnitude.
   If either gate fails, re-scope with `--time-range` and re-read before acting.

3. **Establish whether the frontend is the bottleneck, then whether it costs anything.** Compare
   `stall-frontend-pkc` and `stall-backend-pkc`; on `genoa`, `icelake` and `spr` correct the backend
   value first (`--stalls --profile <p>`). Frontend dominant ⇒ mispredicts are plausibly a leading
   cause; backend dominant ⇒ secondary, fix the backend first. Then `ipc`: above 2 the core absorbs
   the cost whatever the mpki; below 1 with frontend dominance this is a genuine target.

4. **Read the series and the per-CPU spread, not the average.** Front-loaded mpki is predictor training
   or JIT warm-up. A wide interval spread with low `avg(aggregate)` is the dilution artifact. A single
   hot `CPU{n}` is one branch-heavy thread, and a fix aimed at it will barely move the aggregate. Only
   sustained, broad elevation justifies structural change.

5. **Separate "unpredictable branches" from "too many branches".** Read `inst-l1-mpki`,
   `inst-tlb-mpki`, `inst-tlb-tw-pki` and `code-sparsity` alongside. All elevated together ⇒
   **instruction footprint / layout** is the root cause, and fixing layout improves prediction,
   fetching and translation at once — the higher-leverage path. Only `branch-mpki` elevated ⇒
   unpredictable control flow, which requires changing the algorithm or the data.

6. **Locate the branches, then remediate to the cause.** With `--profile`, find the hot functions;
   on metal Graviton, `hotline` identifies the mispredicting instruction. Without one of these, any
   change is speculative. Then: **footprint/layout** — `-flto` and `-Os` for C/C++, or
   [AutoFDO](https://gcc.gnu.org/wiki/AutoFDO/Tutorial) so the compiler lays hot paths out linearly
   and biases branches correctly; for Java `-XX:+TieredCompilation` plus code-cache sizing
   (`-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M`). **Unpredictable-branch** —
   branchless select/`cmov`-style arithmetic, sorting input so branches correlate, hoisting
   invariant conditions out of loops, a monomorphic fast path in place of virtual dispatch, lookup
   tables instead of long conditional chains. **Exception-driven** (Java) — eliminate
   exception-based control flow, see `Excessive Exceptions`.

## Priority and execution risk

**Priority: P3 — Monitor** by default: at 10–15 mpki on a run that has not been dilution-checked, the
honest deliverable is a cycle figure and a confidence caveat. It rises to **P2 — Investigate** once the
cycle budget clears roughly 20% of cycles *and* `Frontend-Dominated CPU Stalls` fired, and to **P1 —
Act now** when that holds *and* `ipc` is below 1 *and* one of the footprint metrics is elevated too —
at which point the remediation is a compiler or JIT flag with a known payoff. It drops to **P4 —
Informational** on an interpreter or JIT-hosted workload, which is branch-unpredictable by design, and
on any run where `Underutilized CPU` also fired, because the mean-of-ratios inflation is then the
leading explanation for the value itself.

**Execution risk: R0 — Read-only** to resolve: the cycle conversion, the stall split, the four
footprint metrics, the per-CPU spread, and `--time-range` re-scoping are all reads. Acting on what it
reveals is **R3 — Rebuild** for the dominant remediation (`-flto`, `-Os`, AutoFDO, a different
`-march`), **R2** for a JVM code-cache or tiered-compilation flag, and **R5** where hot-path control
flow is restructured — branchless rewrites and dispatch specialization change semantics under
contention and edge cases, and need a correctness suite before a performance one. **Do not inherit
the R0 of the reading into the rebuild:** a profile-guided rebuild changes the binary that runs in
production, and its verification is a re-record, not a re-read.

**The score restates the value exactly and is worth nothing as a severity.** It is `value / 10 × −1`,
so `avg(branch-mpki) = |score| × 10` — unlike the two stall rules, no information is lost. What is
lost is *rank*: `Concerning` (−1) means a severe 50 mpki scores `−5.00` and sorts below every `Poor`
and `Critical` finding in the panel, including `Old-Style Atomic Instructions` (`Poor`, 16× the base)
and `Underutilized CPU` (`Critical`, 256×). Rank on the **cycle budget**, never on score. And note
the comparator is `GreaterEqual`, so exactly 10.0 fires — inclusive here, unlike
`Underutilized CPU`'s `Greater`.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `avg(branch-mpki)` over the `Aggregate` series was at least 10.0
(`GreaterEqual 10.0`, so exactly 10.0 does fire), in a single run.

```
STEP 0 — Does the perf_stat data exist, and is the value comparable to anything?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible. aperf needs metal or a
         family exposing a virtualized PMU, and the silence proves nothing about
         branch behaviour (P3, R0)
  IF the run is on `grv` or `grv5`
  THEN → the counter is BR_MIS_PRED (0x10), a SPECULATIVE event, over a retired
         denominator, so values read systematically higher than x86 for identical
         source and the 10.0 threshold is not neutral. Against an x86 run (Intel
         BR_MISP_RETIRED 0xC5, AMD 0xC3, both retired/retired) it is INCOMPARABLE,
         and no gate catches it: no architecture field, no rule compares
         `Instance Type` (../GATES.md "The two gaps") (P2, R0)
  ELSE continue.

STEP 1 — Convert to a cycle budget. Nothing below is prioritizable without it.
  Parse: The {stat} in {run_name} is {value}.   {run_name} is the run described,
         NOT a baseline; recover exactly avg(branch-mpki) = |score| x 10.
  cycles lost per thousand instructions = mpki x penalty (~11 grv/grv5, ~17
         intel/icelake/spr, ~18 amd/genoa/milan); percent of all cycles = that
         x ipc / 10. Both, with the per-profile counting caveat, come from
         `tools/aperf_perf_stat.py --branch --mpki M --profile P --ipc-value I`

  IF the budget is under 10% of cycles
  THEN → not a bottleneck. Report the figure and STOP; no compiler-flag
         discussion is warranted (P4, R0)
  IF 10-20% of cycles
  THEN → real but modest. Worth pursuing only if the frontend is also dominant;
         continue to STEP 2 (P3, R0)
  IF 20-60% of cycles
  THEN → substantial, with real headroom. Continue (P2, R0)
  IF over 60% of cycles
  THEN → dominant -- but the flat penalty over-counts here, since cores overlap
         recovery with other work. Read it as "this dominates", not as a literal
         fraction (P1, R0)

STEP 2 — Gate the VALUE itself. This rule's average is not instruction-weighted,
         so dilution does not blur it, it manufactures it.
  IF `Underutilized CPU` fired, or the per-interval spread is wide with a low
     `avg(aggregate)` (the same defect without the companion rule firing)
  THEN → PRIME SUSPECT. avg() is a mean of per-interval ratios, so a near-empty
         interval weighs the same as a saturated one. A worked case reads 15.25
         against a true instruction-weighted 1.01 -- 15.2x (P3, R0)
       → verify: re-report with `--time-range` scoped to the loaded interval.
         The stat is re-derived from the surviving samples; if the finding
         disappears, the mispredictions were an artifact of the idle intervals.
         Or compute the instruction-weighted rate by hand from two intervals at
         the extremes; if it lands below 10.0, there is no finding
  IF `mux_counter_schedule_rate` < 100
  THEN → BOTH the mispredict count and the instruction denominator are
         extrapolated by 100/rate. At 10.0 the threshold is close enough to
         healthy values that this error alone can cross it (P3, R0)
       → verify: `--mux --rate R` gives the factor (25% ⇒ 4.00x); to remove it,
         re-record with `--ungroup-pmu-events`, since grouped mode is the default
         and duplicates each event per metric group
  ELSE the value is trustworthy; continue.

STEP 3 — Is the frontend the bottleneck, and is it costing anything?
  IF `Frontend-Dominated CPU Stalls` fired
  THEN → the CONFIRMED case: mispredicts are a leading contributor to a measured
         frontend bottleneck. Continue to STEP 4 (P2, R0)
  IF `Backend-Dominated CPU Stalls` fired
  THEN → the mispredicts are hidden behind memory latency, so fixing them will
         not move wall-clock. Secondary; fix the backend first (P3, R0)
  IF NEITHER stall rule fired
  THEN → the dead zone (be/fe in (1/1.1, 1.1)), or the profile lacks the metrics
         (generic `amd` has no stall-backend-pkc at all). NOT evidence of a
         balanced-and-healthy pipeline: 600 pkc on both sides fires nothing.
         Read both absolute pkc values (P3, R0)
  IF the profile is `genoa`, `icelake` or `spr`
  THEN → the split's DIRECTION may be reversed: the backend metric is normalised
         differently. Correct with `--stalls --profile <p>` first (P3, R0)
  IF `ipc` > 2, or < 1 with frontend dominance
  THEN → above 2 the core absorbs the cost whatever the mpki: note it and stop
         (P4, R0). Below 1 with frontend dominance is the ACTIONABLE case:
         continue to STEP 4 (P1, R0)

STEP 4 — Unpredictable branches, or simply too many branches? Note that
         `code-sparsity` exists ONLY on `grv`, so on the other seven profiles its
         absence is unreadable, not evidence of good layout (P3, R0).
  IF `inst-l1-mpki`, `inst-tlb-*` or `code-sparsity` are elevated too
  THEN → INSTRUCTION FOOTPRINT is the root cause, and layout is one fix for all of
         them -- `-flto`, `-Os`, AutoFDO, linker ordering -- with higher leverage
         than attacking branches individually (P2, R3)
       → verify: after the rebuild branch-mpki AND the footprint metric AND
         stall-frontend-pkc all fall. If only the footprint metric falls, the
         branches were independently unpredictable
  IF only `branch-mpki` is elevated
  THEN → genuinely unpredictable CONTROL FLOW. The fix changes the algorithm or the
         data, not the build flags (P2, R5)
       → verify: needs a correctness suite before a performance one -- branchless
         rewrites and dispatch specialization change edge-case behaviour
  IF the workload is an interpreter, VM or JIT-hosted runtime
  THEN → structural: bytecode dispatch is one hard-to-predict indirect branch
         executed constantly. Expected, and addressable only at the runtime
         level (P4, R2) — see the runtime section
       → verify: the runtime flag is the whole change (DOTNET_TieredPGO,
         -XX:ReservedCodeCacheSize); expect a modest fall, since the dispatch
         branch itself does not go away
  IF the algorithm is inherently data-dependent (sort, search, parse, compress)
  THEN → the unpredictability is the problem's nature, not a defect. A branchless
         rewrite is a design change (P3, R5)
       → verify: quantify the ceiling first -- STEP 1's budget is the most the
         rewrite can recover, and it is usually less than it appears

STEP 5 — Check the timeline before attributing to steady state. Sustained, broad
         elevation is representative; continue to STEP 6 (P2, R0).
  IF elevation is confined to the START of the run
  THEN → predictor training, class loading, or JIT warm-up. All genuinely
         mispredict-heavy, none of it steady state (P4, R0)
       → verify: re-report with `--time-range` past warm-up; if the finding
         disappears, nothing needs remediation
  IF only a few `CPU{n}` series show it
  THEN → one branch-heavy thread, not the instance. The Aggregate ratio of sums
         weighted it by instruction count, so a busy well-behaved CPU can mask
         it (P3, R0)
       → verify: correlate with the on-CPU profile to name the thread; a
         thread-targeted fix will barely move the aggregate

STEP 6 — MANDATORY manual check: whose branches are they? aperf cannot answer
         this from metrics, and the answer decides whether a fix exists.
  IF it is APPLICATION code you build
  THEN → your flags apply: INSTRUCTION_FOOTPRINT_OPTIMIZATION, or an algorithmic
         change if STEP 4 routed there (P2, R3)
       → verify: re-profile; the hot stacks shift and the cycle budget from
         STEP 1 shrinks proportionally
  IF it is KERNEL code (high `system` in cpu_utilization)
  THEN → you do not control its branches; reduce the syscall rate instead (P3, R2)
       → verify: batching, io_uring, or larger buffers lower `system` time and
         branch-mpki together
  IF `Excessive Exceptions` also fired (Java)
  THEN → exception-based control flow is a concrete, fixable cause of irregular
         branching -- the most tractable case on this whole tree (P2, R3)
       → verify: after removing the exception path, branch-mpki falls and the
         java_profile finding clears
  IF no `--profile` data exists
  THEN → STOP. Any flag or algorithm recommendation from here is speculative;
         the honest deliverable is a re-record with `--profile` (P2, R0)

STEP 7 — What survives?
  VALID      : the mpki value as an ORDER OF MAGNITUDE on a run that passed STEP 2;
               the cycle budget derived from it; every non-PMU finding
  CAUTION    : the value on a run that multiplexed or was idle-diluted, and the
               stall split on `genoa`/`icelake`/`spr`
  CONFOUNDED : any steady-state claim from a window including warm-up, and any
               instance-wide claim when one CPU{n} carries it
  VOID       : any per-BRANCH accuracy figure -- aperf collects no branch count on
               any profile; and any comparison across an arm64/x86 boundary, where
               the event changes from speculative to retired

INSUFFICIENT DATA
  IF the value is 5-10 and no finding fired
  THEN → below threshold, but the mean-of-ratios defect biases UPWARD, so the true
         rate is at most this. Weak evidence of health, not strong (P4, R0)
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples, each equally weighted. The average is readable but
         no percentile is, and one anomalous interval moves the mean by ~10% of
         its own value (P3, R0)
```

## Runtime-specific consequences

Branch predictability is a property of the *instruction stream*, and three of the four runtimes
generate their own at run time — so the branches you would fix are often not the ones you wrote:

| Runtime | Why branches mispredict, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **.NET** | Tiered JIT emits two bodies per hot method; tier-0→tier-1 promotion invalidates predictor history mid-run, and the doubled code footprint thrashes the history tables. Interface dispatch on a megamorphic site is the usual real cause | `DOTNET_TieredPGO` — it devirtualizes hot call sites from observed profiles, which is the single most effective branch fix on .NET. `DOTNET_TieredCompilation`, and whether the window covered promotion. ReadyToRun trades footprint for history stability |
| **Python** | CPython's eval loop is one indirect branch per opcode — **structurally** unpredictable and not a defect. Since 3.11 the specializing interpreter and computed-goto dispatch already reduce the rate substantially; there is no further source-level lever | Whether the hot path is bytecode or a C extension. A branch fix targets the extension, never the Python. Expect a high baseline mpki and treat this finding as P4 unless the extension surface is large |
| **Java** | The most tractable case, for one reason: **exception-based control flow**, which `Excessive Exceptions` names directly. Beyond that, megamorphic call sites defeat the JIT's inline caches, and a too-small code cache forces continuous recompilation that re-trains the predictor from cold | `jvmArguments` in the profile metadata. `-XX:+TieredCompilation`, `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M` — a `code cache full` message means it is too small. Then the `java_profile` findings for the throwing method |
| **Perl** | A tree-walking interpreter: op dispatch is a small hot loop, but the *op-tree traversal* is pointer chasing, so Perl is usually **backend**-bound. High mpki in a Perl workload points at a large XS/native surface, not at Perl. No JIT tier and no code cache to tune | The XS module set and `perl -V`. The absence of runtime knobs makes a branch finding here more likely to be genuinely about a linked C library — which is a rebuild you may not control |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is
inferred from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be
identified, stop at STEP 6's profile check: "whose branches are they" is runtime-independent and is
what actually gates the remediation. For **all four**, elevation confined to the first seconds is
predictor training, and the fix is `--time-range`, not a rebuild.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — one of the few `perf_stat` rules with no structural
silence. The registry's `architecture_note` states the problem exactly: *"arm64 uses a speculative
mispredict counter; expect systematically higher values than x86 for identical code."*

**Every profile's event is a genuine misprediction event — the portability defect is what gets
counted, not which event.** The formula variable is confusingly named:

| Profile | `branch-mpki` definition | Event | Counts |
|---|---|---|---|
| `grv`, `grv5` | `Branches / Instructions * 1000` | `0x10` BR_MIS_PRED | **SPECULATIVE** mispredicts, over a **retired** denominator |
| `intel`, `icelake`, `spr` | `Branches / Instructions * 1000` | `0xC5` BR_MISP_RETIRED | retired mispredicts, retired denominator |
| `amd`, `genoa`, `milan` | `Branch_Mispredictions / Instructions * 1000` | `0xC3` | retired mispredicted branches, retired denominator |

The variable name `Branches` on `grv`/`intel` invites the reader to think those metrics divide by a
branch *count*. They do not — all three numerators are mispredicts. **Do not "correct" this by
dividing by a branch count**; the metric is right and no branch count exists in the data. Only three
base configs define `branch-mpki` (`grv`, `intel`, `amd`); the five overlays inherit it unchanged.

What is genuinely non-portable is the **speculative-versus-retired mismatch on arm64**: a
mispredicted branch on the wrong path is counted by `BR_MIS_PRED` even though it never retires, while
the denominator counts only retired instructions. Graviton therefore reads structurally higher than
x86 for identical source, and the ~11-cycle Neoverse penalty versus ~17 on Intel and ~18 on Zen means
the *cycle* consequence moves the opposite way from the *value*. A uniform threshold of 10.0 cannot
be neutral across that. Compounding it, aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with
matched `CPUs` and `MemTotal` fires **no gate**, so "branch mispredictions got worse after the
migration" is not a measurement.

**Two companion metrics are missing where you most need them.** `code-sparsity` is defined **only**
in `grv_pmu_config.json` — one of eight — so on every Intel and AMD run STEP 4's layout branch is
unreadable rather than negative. And generic `amd` has no `stall-backend-pkc`, which silences *both*
stall rules and removes STEP 3's severity gate entirely: on that profile this finding can fire with
no way to establish whether the frontend is the bottleneck.

**Counter pressure also differs per profile, for reasons unrelated to the workload.** Grouped is the
default and creates one counter per event *per metric group*, so the merged configs require 22–32
counters per CPU against a probed limit bounded to 16 — at a realistic 6–10 usable registers, a
21–43% schedule rate and so a 2.3–4.7× extrapolation on **both** numerator and denominator. `spr`
(32 counters) multiplexes harder than `amd` (22) purely because its config defines more events.
`--ungroup-pmu-events` removes the duplication but no longer guarantees the two were sampled
together, which for a ratio metric trades one error for another.

## Verification

Apply the fix STEP 4 and STEP 6 localized, re-record at the **same geometry, same counter mode, and
same instance type**, and verify the pair rather than the value alone: `avg(branch-mpki)` should fall
**and** the STEP 1 cycle budget should shrink proportionally, with `avg(stall-frontend-pkc)` falling
in absolute pkc alongside it. A fall in mpki without a fall in frontend stalls means the
mispredictions were not driving the bottleneck and the other three frontend causes are still open. A
fall in mpki with unchanged wall-clock on a backend-dominated run is the expected outcome of fixing
the wrong thing. If the value falls only because the re-record was quieter, the mean-of-ratios defect
moved it, not the fix — compare `avg(idle)` across the pair and re-scope both with `--time-range`
before believing the improvement. Unlike the stall rules, this finding **can** be verified partly by
score, since `avg(branch-mpki) = |score| × 10` exactly; what the score cannot tell you is whether the
change was worth making, which is the cycle budget's job.

## Do not

- **Do not compute a per-branch misprediction rate from this metric.** It is per *instruction*. aperf
  collects no branch count on any profile, so per-branch accuracy is not derivable from the report —
  and the variable being named `Branches` on `grv`/`intel` does not make it one.
- **Do not trust the average on an idle-diluted run.** It is a mean of per-interval ratios with no
  instruction weighting, so quiet intervals count as much as saturated ones: a worked case reads
  **15.25 against a true 1.01**. Check `avg(idle)` and re-scope with `--time-range` first. The same
  defect makes a **startup-inclusive window** report predictor training as steady state.
- **Do not treat the small score as small impact.** `Concerning` (−1) puts a severe 50 mpki at
  `−5.00`, below every `Poor` and `Critical` finding. Rank on the cycle budget: `mpki × penalty ×
  ipc / 10` is percent-of-cycles, and 25 mpki on Graviton at IPC 2.0 is 55% of them.
- **Do not compare this value across an arm64/x86 boundary.** arm64's `BR_MIS_PRED` (`0x10`) is
  **speculative** over a retired denominator; Intel `0xC5` and AMD `0xC3` are retired over retired.
  Graviton reads structurally higher for identical source, the per-misprediction penalty moves the
  *other* way (~11 vs ~17/~18 cycles), and **no aperf gate catches the mismatch** — there is no
  architecture field and no rule compares `Instance Type`.
- **Do not optimize branches while the workload is backend-bound**, and **do not read a missing
  companion metric as a negative one**. Check the stall split first; on `genoa`/`icelake`/`spr`
  correct the backend value before trusting its direction, and on generic `amd` there is **no
  `stall-backend-pkc` at all**, so this rule can fire with the severity gate structurally
  unavailable. Likewise `code-sparsity` is defined in **one** of the eight PMU configs (`grv`), so on
  Intel and AMD runs STEP 4's layout branch is unreadable, not negative.
- **Do not treat data-dependent branching or interpreter dispatch as a defect.** For sorting, parsing,
  compression, and any bytecode loop the unpredictability *is* the problem's nature. Quantify the
  ceiling from STEP 1 before proposing a branchless rewrite — it is usually smaller than it looks, and
  the rewrite is **R5**, not R3.
- **Do not act on a multiplexed value.** Grouped mode is the default and the merged configs need
  22–32 counters against ≤16 registers, so **both** the mispredict count and the instruction
  denominator are extrapolated by the same `100/rate` factor — and at a threshold of 10.0 that error
  alone can decide whether the finding exists.
- **Do not recommend a rebuild without `--profile` data.** STEP 6 exists because a branch fix aimed
  at the wrong binary — a runtime, a linked C library, or the kernel — changes nothing, and because
  **the R0 of reading this metric does not transfer to the R3/R5 of acting on it**.

## References

- Rule and template: `src/analytics/rules/perf_stat.rs:51` — `metric: "branch-mpki"`,
  `Stat::Average`, `Comparator::GreaterEqual`, `threshold: 10.0`, `score: Score::Concerning`,
  `requires_comparison` false (readable even when every cross-run comparison is void). Emitted by
  `src/analytics/rule_templates/time_series_stat_threshold_rule.rs`, which calls
  `compute_finding_score` — so **the score is amplified** — carrying only `{stat}`, `{run_name}`
  and `{value}`, threshold and comparator implicit.
- Score math: `compute_finding_score`, `src/analytics/mod.rs:167`, over `Score::Concerning = −1`
  (`:147`–`:157`); recover `avg(branch-mpki) = |score| × 10`. The displayed value is **truncated**
  (`f64_to_fixed_2`, `src/computations/mod.rs:138`).
- The two aggregation layers: across CPUs, `src/data/perf_stat.rs:1118`–`:1148` sums mispredicts
  and instructions and divides once — a **ratio of sums**, so **no CPU-count correction applies**;
  across intervals, `Statistics::from_values` (`src/computations/mod.rs:27`–`:41`) takes the plain
  mean of those ratios, with **no instruction weighting**. `stats_series_idx`
  (`src/data/common/time_series_data_processor.rs:312`–`:342`) selects the `Aggregate` series
  (named at `utils.rs:241`); per-CPU series are `CPU{n}` (`utils.rs:237`). `--time-range`
  re-derives every stat via `compute_time_diff_index` (`processed_data_accessor.rs:597`).
- Per-profile definitions: `src/pmu_configs/*.json`, merged as **overlays** by `extend_from_default`
  (`src/data/perf_stat.rs:200`–`:205`), selected at `:765`–`:790`. `branch-mpki` is defined in three
  base configs only (`grv`, `intel`, `amd`) and inherited by all five overlays; `code-sparsity` exists
  in `grv` alone. `perf_stat` is the **only** collector calling `use_first_accumulative_value()`
  (`:1295`), so it keeps its first sample; counters are reset after each read (`:517`, `:564`).
- Multiplexing: in grouped mode (the default, `src/data_collection.rs:379`) `:1093` scales every
  counter in a group by the *same* factor, and `branch-mpki` is degree-0 in its counters, so it
  **cancels** — a low schedule rate costs coverage, not magnitude. Only `--ungroup-pmu-events`
  (per-event factors, `:1216`) can skew the value across 10.0. `warn_multiplexing` (`:59`–`:64`) is
  `debug!`, but the runlog is archived at `LevelFilter::Debug`: grep "APerf Logs" for `multiplex`.
- Quantifier: [`../tools/aperf_perf_stat.py`](../tools/aperf_perf_stat.py) `--branch` — the cycle
  budget, the percent-of-cycles conversion at a given IPC, the over-100% caveat, and the
  speculative-vs-retired warning per profile; `--profiles` prints the 8-profile matrix.
  `tools/test_aperf_perf_stat.py` pins the penalties and the counting caveats.
- Related playbooks: `frontend-dominated-cpu-stalls.md` (the severity gate),
  `backend-dominated-cpu-stalls.md` (where a firing here is secondary),
  `reduced-instructions-per-cycle.md` (the step above in the top-down method),
  `pmu-counter-collection-multiplexing.md` and `../cpu_utilization/underutilized-cpu.md` (the two
  confidence gates), `high-l1-instruction-cache-misses.md`, `instruction-tlb-misses.md`,
  `instruction-tlb-table-walks.md`, `high-code-sparsity.md`,
  `../java_profile/excessive-exceptions.md`. Cross-cutting: [../GATES.md](../GATES.md) (precedence,
  and the missing architecture gate), [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) (P/R vocabulary,
  runtime inference), [../ARCHITECTURE.md](../ARCHITECTURE.md) (the 8 PMU profiles, counter mode).
- Upstream guides and external references: `INSTRUCTION_FOOTPRINT_OPTIMIZATION` (the remediation
  attached to this metric) and `CPU_FRONTEND_STALLS_INVESTIGATION` (which lists `branch-mpki` first
  of five), in `src/report_frontend/src/definitions/optimization-guides.ts`; Graviton perfrunbook
  [front-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-front-end-stalls)
  and
  [large instruction footprint](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html#optimizing-for-large-instruction-footprint);
  [Arm Neoverse N3 branch-MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/MPKI-metrics-for-Neoverse-N3?lang=en#md407-mpki_mg__branch_mpki_m_MPKI);
  [GCC AutoFDO tutorial](https://gcc.gnu.org/wiki/AutoFDO/Tutorial), the profile-guided layout path
  STEP 4's footprint branch routes to, whose .NET analogue is `DOTNET_TieredPGO`.
