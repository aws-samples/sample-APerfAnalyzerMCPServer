---
rule_name: Data TLB Table Walks
data_type: perf_stat
data_key: data-tlb-tw-pki
template: time_series_data_point_threshold
condition: "any(data-tlb-tw-pki) > 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "Upon data TLB misses, the CPUs need to traverse the OS-build page table to find the correct physical address for the virtual address in the load/store instructions, which requires extra memory references before executing them and causes CPU backend stalls."
source: src/analytics/rules/perf_stat.rs:124
---

# Data TLB Table Walks

## What fired

**At least one** data point of `data-tlb-tw-pki` was **greater than 0.0**.

**The threshold is zero** — any non-zero page-table-walk rate in any single sample fires this rule. Last
of the four zero-threshold TLB rules, and equally unselective. The *magnitude* is the signal, not the
firing. Base score `Concerning` (−1). Single-run rule.

## The collection gap — the metric is blind to stores on Intel, and the value is not the peak

**Gap 1 — on `intel`, `icelake` and `spr` this metric does not cover stores.** `data-tlb-tw-pki` resolves to
`cpu/event=0x8,umask=0x1/` while the *same* config separately defines `data-st-tlb-tw-pki` on event `0x49` —
the config's own evidence that the metric the rule reads is one side of the picture. **No aperf rule reads
`data-st-tlb-tw-pki`** (nor, on `spr`, the refreshed `data-rd-tlb-*` / `data-st-tlb-*` pair on `0x12`/`0x13`),
so a store-heavy workload's walk traffic is **invisible to this finding on Intel**; arm64 (`0x34`) and AMD
(`0x45` umask `0xf0`) count both sides in one counter, so there the value is complete. **On `spr` the encoding
is also stale**: the override refreshes `Instruction_TLB` (`0x85` → `0x11`) and `L2` (`0xf1` → `0x25`) and
*adds* the `0x12`/`0x13` pair, yet leaves the data-TLB pair on the inherited generic-Intel `0x8` — the rules
read the un-refreshed encoding and the refreshed metrics have no rule. **Treat an SPR value as corroborating
evidence only.**

**Gap 2 — the reported value is the worst-*scoring* sample, not the worst sample.**
`compute_finding_score` (`src/analytics/mod.rs:170`) special-cases a zero threshold:

```
if value < 1.0  →  score = rule_score            (flat, no magnitude)
else            →  score = (value - 1.0) * rule_score
```

so `|score|` is **V-shaped** — flat at 1.0 below value 1.0, zero at exactly 1.0, and only above value
2.0 does it exceed the flat branch. The template (`time_series_data_point_threshold_rule.rs:98`–`:117`)
keeps the sample with the largest `abs(finding_score)`, *not* the largest value, using `>=` so a later
tie overwrites:

| series | reports | score | the peak |
|---|---|---|---|
| `[0.20, 1.90]` | **0.20** | −1.00 | 1.90 — scores only −0.90, so it loses |
| `[0.0, 0.55, 0.71, 0.34]` | **0.34** | −1.00 | 0.71 — every sub-1.0 sample ties and `>=` takes the last |
| `[0.75, 2.00]` | **2.00** | −1.00 | 2.00 — a tie with 0.75, won by position |
| `[1.00]` | **1.00** | **−0.00** | renders **grey** with the neutral icon |

**And the "walks exceed misses ⇒ collection bug" reading is wrong on Intel.** The two counters are
**disjoint** there, so a raw `tw / mpki` above 1.0 is legitimate; it is impossible only on the nested
profiles. Both gaps are checked by `test_aperf_memory_hierarchy.py`, which ports the selection loop
independently and re-derives all 16 TLB pairings from the umask bits:

```
$ python3 ../tools/aperf_memory_hierarchy.py --tlb --miss-pki 4.80 --walk-pki 4.10 \
      --profile amd --tlb-side data
relation: nested, total_misses_pki: 4.8, escalation_fraction: 0.854, thp_leverage: high
```

## Reasoning

`data-tlb-tw-pki` is "Translation Lookaside Buffer (TLB) table walks for data accesses per thousand
instructions. It is triggered upon a cache miss in the data TLB to translate virtual addresses in a
load/store instruction into physical ones, and multiple traversals in the OS-build page table were
required to find the correct physical address. It can lead to much higher latency for some memory
accesses." (`data-descriptions.ts`, `desired: "lower"`)

This is the **expensive tail** of `Data TLB Misses`, and their relationship is what makes it worth reading
separately. A **DTLB miss** means the translation was not in the L1 data TLB; many are satisfied by the
shared **L2 TLB** at tens of cycles. A **table walk** means the L2 TLB missed too, so the hardware traverses
the OS page table in memory — up to **four levels of dependent accesses**, five on a 5-level-paging kernel.

The critical property — and why this metric can be worse than it looks — is that **each level of the walk
is itself a memory access that can miss in the data caches**. A cached walk costs tens of cycles; one that
misses to DRAM at every level costs *hundreds*, and it competes for the same bandwidth as the access it is
enabling, so in an already DRAM-bound workload (`High L3 Cache Misses`) the two compound. Huge pages attack
this from two directions, which is why they are the canonical fix: **far fewer walks**, since one 2 MB entry
covers what 512 4 KB entries covered, and **shorter walks**, since a 2 MB mapping terminates one level
earlier. A high walk rate is therefore **the strongest single indicator in `perf_stat` that huge pages will
produce a measurable win** — more so than the DTLB miss rate alone.

Causes match DTLB misses but must be severe enough to overwhelm the L2 TLB too: very large heaps with
scattered access, random access over multi-gigabyte structures, large memory-mapped files, high allocation
churn. **The silence here is more informative than for its sibling**: the metric is defined on all 8
profiles, so an absent finding while `Data TLB Misses` fired means the L2 TLB absorbed every miss — cheap,
and a case where huge pages have little to win.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 4.00 (greater than the threshold of 0).
```

**Four things that sentence does not tell you.** **`4.00` is the worst-*scoring* sample, not the worst sample
and not the average** (see `The collection gap`); the peak may be higher and is not recoverable. **It may be
one CPU's series** — this template iterates **every** series including per-CPU
(`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based `perf_stat`
rules which read only `Aggregate` (`:432`), so one thread with a scattered working set fires this for the
whole run. **The value is truncated, not rounded** (`f64_to_fixed_2`, `computations/mod.rs:138`), so `4.00`
is anything in `[4.00, 4.01)`. And **there is no `(n−1)/n` dilution correction**: `perf_stat` opts out of the
forced first zero via `use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`), so sample one is real.

Score math — `compute_finding_score(value, 0.0, −1)`, the `threshold == 0.0` branch:

| worst-scoring sample | score | note |
|---|---|---|
| 0.05, 0.30 | **−1.00** | flat: any value below 1.0 gives the base score |
| **1.00** | **−0.00** | score collapses to zero; renders **grey** |
| 1.50 | **−0.50** | *milder* than a 0.05 sample |
| 2.00, then 4.00 | **−1.00**, **−3.00** | 2.00 collides with the entire sub-1.0 range; only above it does the score separate |

Above 1.0 recover the sample as `value = |score| + 1`; below 1.0 it is not recoverable, since `|score| =
1.00` has two disjoint preimages — everything below 1.0, and exactly 2.0.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The metric is identically zero while `Data TLB Misses` fired | no finding, and this silence **is** informative: the L2 TLB absorbed every miss, so huge pages have little to win |
| Both this and `Data TLB Misses` are absent | two identically-zero translation metrics on a metric defined for all 8 profiles — a collection question |
| The workload is store-heavy on `intel`/`icelake`/`spr` | a value covering **loads only**; the store side is `data-st-tlb-tw-pki`, which no rule reads |
| The only exceeding sample is exactly 1.0 | the finding exists at score **−0.00** and renders grey with a neutral icon, sorting below every positive finding |
| The run multiplexed heavily, or only one `CPU{n}` series exceeded | extrapolation alone can produce a non-zero sample and a zero threshold has **no** noise margin; and a single elevated per-CPU series is reported for the whole run while `Aggregate` may be benign |

## Interpretation

**The escalation fraction against `data-tlb-mpki` is the most useful number available**, and it is
`tw / mpki` only where the counters are nested — arm64 and AMD on this side, *not* Intel:

| escalation fraction | Reading |
|---|---|
| < 0.2 | Most DTLB misses are absorbed by the L2 TLB. Moderate cost however large the miss rate |
| 0.2–0.5 | Partial saturation. Huge pages help, sized on the walk figure rather than the miss figure |
| ≥ 0.5 | The TLB hierarchy is saturated; misses go all the way to page-table walks. **Huge pages are very likely to give a real win** |

| sustained value | Reading |
|---|---|
| < 0.1 | Measurement floor. Ignore |
| 0.1–1 | Mild. Cheap fixes worth trying if backend-dominant |
| 1–5 | Real cost — each walk is 4–5 dependent memory accesses |
| > 5 | Severe. Data footprint vastly exceeds TLB coverage; huge pages are a priority |

| elevated **and** | Reading |
|---|---|
| sustained across the series | Genuine and actionable; one isolated sample is startup, first-touch or a phase transition, and is not |
| `Backend-Dominated CPU Stalls` fired | **The confirmed case** — address resolution is blocking issued instructions |
| `Huge Page Disabled` also fired | **Direct cheap fix available** — THP is off at the kernel-config level |
| `High L3 Cache Misses` also fired | **The compounding case** — walks miss to DRAM too, adding latency *and* consuming the bandwidth that is already the ceiling. Huge pages help both |
| `data-l1-mpki`/`l2-mpki` low but walks high | Data is cached well, pages are scattered. The cleanest huge-page win |
| `Instruction TLB Table Walks` also fired | System-wide translation pressure; one huge-page change addresses both |

**Known false positives:**

- **Any non-zero value fires it.** The defining condition; a walk rate of 0.01 is noise. And the reported
  value understates the peak, so a small description value does not settle it either way. **A single
  transient sample** is the same class of non-finding: first-touch of newly mapped memory, heap growth,
  startup and phase transitions all guarantee walks.
- **PMU multiplexing.** With a zero threshold there is no noise margin — extrapolation error alone can
  produce a non-zero sample. If `PMU Counter Collection Multiplexing` fired, treat this as low-confidence
  by default. **One hot CPU** is the same class of error: the rule reads every per-CPU series, so a single
  scattered thread fires it for the run while the aggregate is benign.
- **Idle-diluted or kernel-heavy runs.** Background daemons touch scattered pages; and if `system` time
  dominates, part of the walk cost is kernel-side.
- **Large-heap workloads are inherently high-walk.** Databases, multi-gigabyte JVM heaps, in-memory caches
  and large memory-mapped files exceed TLB coverage by orders of magnitude. Expected — and exactly the case
  huge pages target.
- **A walk rate exceeding the miss rate.** On `grv`/`grv5` and `amd`/`milan`/`genoa` that is impossible and
  means multiplexing distorted one counter. **On `intel`/`icelake`/`spr` it is expected**, because the
  counters are disjoint — do not report it as a collection defect there.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `data-tlb-tw-pki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient, and whether one CPU or all — the description gives neither |
| `data-tlb-mpki` | `perf_stat` | **Read together — the escalation fraction is the key number**, computed with the profile's set relation. See `Data TLB Misses` |
| `data-rd-tlb-tw-pki`, `data-st-tlb-tw-pki` | `perf_stat` | **Mandatory on Intel** — the read/store split, and the only way to see store-side walks at all there. **No rules fire on these** |
| `stall-backend-pkc` vs `stall-frontend-pkc`, `ipc` | `perf_stat` | **Severity gate.** Walks block issued loads and stores, and `ipc` says whether the pipeline is suffering. See `Backend-Dominated CPU Stalls` |
| `l2-mpki`, `l3-mpki` | `perf_stat` | **Especially important here** — page-table entries live in memory, so poor cache behaviour makes every walk dramatically more expensive. See `High L3 Cache Misses` |
| `data-l1-mpki`, `mux_counter_schedule_rate` | `perf_stat` | Cache behaviour on the data accesses themselves — low here with high walks = a pure translation problem; and the **confidence gate**, critical on a zero threshold with no noise margin |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | **The fix check.** See `Huge Page Disabled` |
| `AnonHugePages`, `HugePages_Total`, `HugePages_Free`, `Hugepagesize`, `ShmemHugePages` | `meminfo` | Whether huge pages are configured and actually in use |
| PageBlocks series | `memalloc` | High-order free blocks — whether fragmentation blocks huge-page allocation. **No analytical rules — read manually** |
| `Kernel Version`, `Instance Type` | `systeminfo` | ≥ 6.9 enables 16 KB / 64 KB folios, and 5-level paging adds a walk level; the instance type is the only clue to which PMU profile applied |
| `pgfault`, `pgminorfault` | `vmstat` | Allocation churn moving the active set to new pages. See `Increased Minor Page Faults` |
| `numa_miss`, `other_node` | `numastat` | **The worst case** — a walk whose levels land on a remote node pays remote latency four or five times over. **No analytical rules** |
| `resident_set_size_bytes` | `processes` | Process footprint — how many pages are in play. **No analytical rules — read manually** |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| On-CPU profile, Hotline output | `perf_profile` / `java_profile`, `hotline` | Which code performs the scattered accesses, and address-level attribution (native code on metal Graviton). Both need `--profile`; **neither has analytical rules** |

## Guidance

Ordered. Steps 1–2 eliminate most firings; step 5 is what makes this finding actionable.

1. **Read the series, not the description.** The threshold is zero, so firing alone means nothing, and
   the reported value is the worst-*scoring* sample rather than the peak. A sustained peak **< 0.1** is
   measurement floor — stop. An **isolated spike** at startup, heap growth or a phase boundary is a
   first-touch artifact — stop. **Sustained** ⇒ continue, checking the per-CPU series first.

2. **Gate hard on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`) — a zero-threshold rule has no noise margin — and `avg(idle)` (`Underutilized CPU`).

3. **On Intel, read the store side by hand before going further.** `data-tlb-tw-pki` covers loads only on
   `intel`/`icelake`/`spr`, and `data-st-tlb-tw-pki` (event `0x49`) has no rule. On `spr` also record
   that the encoding the rule reads is the un-refreshed generic-Intel `0x8`, so the value is
   corroborating evidence only.

4. **Confirm the backend is the bottleneck.** Compare `stall-backend-pkc` and `stall-frontend-pkc`, and
   read `ipc`. Backend dominant with low IPC ⇒ actionable; frontend dominant ⇒ record as secondary. On
   generic `amd` neither stall metric exists, so use `ipc` alone.

5. **Compute the escalation fraction against `data-tlb-mpki` using the profile's set relation.** This is
   the step that makes this finding more decision-relevant than its sibling, and the step where a
   hand-computed ratio is wrong on three of the eight profiles:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --tlb --miss-pki 4.80 --walk-pki 4.10 \
         --profile amd --tlb-side data
   relation: nested, total_misses_pki: 4.8, escalation_fraction: 0.854, thp_leverage: high
   ```

   The data side is **nested** on `grv`/`grv5` *and* on `amd`/`milan`/`genoa` (walk umask `0xf0` ⊂ miss
   umask `0xff`), but **disjoint** on `intel`/`icelake`/`spr`, where the total is `mpki + tw` and a raw ratio
   above 1.0 is legitimate — the opposite of the instruction side on AMD. A **small** fraction means the L2
   TLB absorbs most pressure; a **large** one means the hierarchy is saturated: **the strongest signal in
   `perf_stat` that huge pages will pay off**, since they both reduce the walks and shorten each one.

6. **Check whether walks are compounding a DRAM problem.** Read `l3-mpki`. If it is also high, the walks
   compete for the same saturated DRAM bandwidth as your data — each walk costs far more than its count
   suggests, and huge pages relieve both pressures at once. Read `numastat` here too: a walk whose levels
   land on a remote node pays remote latency four or five times over, and nothing in aperf flags it.

7. **Check whether huge pages are available, and whether they can allocate.** Read
   `CONFIG_TRANSPARENT_HUGEPAGE` (`kernel_config`, see `Huge Page Disabled`), `AnonHugePages` /
   `HugePages_Total` / `Hugepagesize` (`meminfo`), and `Kernel Version` — ≥ 6.9 offers smaller folio sizes.
   If THP is off or unused, that is the first remediation and needs no rebuild. If it is *enabled* but
   `AnonHugePages` sits far below the footprint and the `memalloc` PageBlocks series shows few high-order
   free blocks, the kernel cannot find contiguous memory: the fix is compaction settings or boot-time
   reservation, not more THP configuration.

8. **Only then remediate**, per `TLB_MISS_OPTIMIZATION`: enable THP with
   `echo always > /sys/kernel/mm/transparent_hugepage/enabled` (or `madvise`); on kernels ≥ 6.9 tune folio
   sizes under `/sys/kernel/mm/transparent_hugepage/hugepages-{16kB,64kB,2048kB}/enabled`; for `mmap`-based
   applications reserve pinned huge pages via `sysctl -w vm.nr_hugepages=X` or `hugepagesz=2M hugepages=512`
   in `/etc/default/grub`; for Java add `-XX:+UseTransparentHugePages` (THP ≥ `madvise`) or
   `-XX:+UseLargePages`. Complementary, from `DATA_FOOTPRINT_OPTIMIZATION`: contiguous storage, sequential
   access and footprint reduction, all of which shrink the page span. Fix NUMA placement if `numastat` shows
   remote-node access, and use the read/store split to target it — store-driven walks usually mean
   allocation churn or write-scattered structures.

## Priority and execution risk

**Priority: P3 — Monitor** by default. A zero threshold means the firing itself ranks nothing, but this
finding starts one band above its sibling because *every* counted event here is expensive — a completed walk
of 4–5 dependent memory references, not a translation the L2 TLB absorbed. It rises to **P2 — Investigate**
once the sustained walk rate is above roughly 1 pki, and to **P1 — Act now** when the escalation fraction is
at or above 0.5 **and** `Backend-Dominated CPU Stalls` fired, since that is the combination in which huge
pages have a quantified target — or, on the same evidence, when `Huge Page Disabled` also fired, because a
costly problem then has a configuration-only fix. **`High L3 Cache Misses` firing alongside also justifies
P1**: walks and data compete for the same saturated bandwidth and one change relieves both. It drops to
**P4 — Informational** whenever the run multiplexed, and stays at **P3 at most** when only one `CPU{n}`
series is elevated or when the profile is `spr`, where the encoding the rule reads is stale.

**Execution risk: R0 — Read-only** to diagnose — the series, the per-CPU split, the read/store split, the
escalation fraction, the stall comparison and the THP configuration are all reads. Acting is
**R4 — Infrastructure change** for enabling THP, reserving huge pages, or changing NUMA placement, all of
which alter allocation behaviour machine-wide and can fail outright under fragmentation, and **R2 — Code
change** or **R3 — Rebuild** for the footprint and layout levers. Pre-reserved pages via `vm.nr_hugepages`
are the higher-risk end of R4: they take memory from the page cache permanently, so a workload that then
needs that memory regresses on a different axis.

**The score is amplified, non-monotonic, and unusable for ranking.** A sample of 2.00 and a sample of
0.05 both score exactly −1.00; exactly 1.00 scores −0.00 and renders **grey**. **Rank on the sustained
walk rate and the escalation fraction, never on score.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `data-tlb-tw-pki`, in any series including per-CPU, exceeded
`0.0` (`Greater 0.0`, so exactly zero does not fire).

```
STEP 0 — Does the perf_stat data exist, and does the metric cover the workload?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing: aperf
         needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent (P3, R0)
  IF `perf_stat` exists and this finding is ABSENT while `Data TLB Misses` FIRED
  THEN → the informative silence: misses occurred but no walk was counted, so the L2 TLB absorbed
         all of them -- tens of cycles, not hundreds, so huge pages have little to win (P4, R0)
  IF BOTH this finding and `Data TLB Misses` are absent
  THEN → `data-tlb-tw-pki` is defined on all 8 profiles, so two identically-zero translation
         metrics point at COLLECTION, not at clean translation (P3, R0)
  IF the profile is `intel`, `icelake` or `spr`
  THEN → the value covers LOADS ONLY (0x8 umask 0x1); the store side is data-st-tlb-tw-pki on
         0x49 and NO rule reads it. On `spr` the encoding is also the UN-REFRESHED generic-intel
         0x8 -- corroborating evidence only, cap at P3 (P3, R0)
       → verify: `data-st-tlb-tw-pki` in the report is comparable to or larger than
         `data-rd-tlb-tw-pki`; if it is, the finding understates the walk traffic and the
         magnitude bands below do not apply
  IF the finding fired on `grv`, `grv5`, `amd`, `milan` or `genoa`
  THEN → the counter covers both loads and stores, so the value is complete; the firing itself
         still carries almost no information (threshold 0.0): continue to STEP 1

STEP 1 — Recover the real magnitude. The description does NOT give it: the reported value is
         the worst-SCORING sample, which on a zero-threshold rule is frequently the LEAST
         severe firing sample.
  IF the score is exactly -0.00 and the finding renders GREY
  THEN → the only exceeding sample was exactly 1.0 (mod.rs:170 collapses it,
         AnalyticalFindings.tsx:35 paints score==0 grey). At 1 walk per thousand instructions that
         is NOT a non-event; read it as a value of 1.0 (P3, R0)
  IF the score is exactly -1.00
  THEN → AMBIGUOUS by construction: the preimage is the whole interval below 1.0 PLUS exactly 2.0,
         which differ by a factor of hundreds in cycle cost. Read the series (P4, R0)
  IF the series peak exceeds the reported value
  THEN → expected, not a bug in the report: `>=` plus the V-shaped score prefers a smaller
         sample. Use the PEAK for every branch below (P3, R0)
       → verify: `../tools/aperf_memory_hierarchy.py --select <series>` reproduces the
         template's choice; if it disagrees with the report, the series you read is not the
         series the rule saw (suspect a per-CPU series)

STEP 2 — Gate on measurement confidence. A zero threshold has NO noise margin.
  IF `mux_counter_schedule_rate` < 100
  THEN → extrapolation alone can produce a non-zero walk sample. Report low-confidence and do
         NOT act (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the value collapses toward zero the
         original finding was multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons touch scattered pages and generate their own walks, so the value is
         diluted with behaviour that is not the workload's (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES
         confirms the workload, one that falls confirms the daemons
  IF only one or two `CPU{n}` series are elevated
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one thread
         with a scattered working set fires it for the whole run: a thread, not the instance
         (P3, R0)
       → verify: the on-CPU profile names a thread with a distinct access pattern; a targeted
         fix should move that CPU's series and barely move the aggregate

STEP 3 — Is the backend actually the bottleneck? This decides whether ANY of it matters.
  IF `Backend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: issued loads and stores cannot proceed while the walk completes,
         and the walk cost is ADDITIVE to whatever the data access itself costs (P2, R4)
       → verify: `stall-backend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative
         to the frontend; a falling ratio with a flat absolute means the frontend got worse
  IF `Frontend-Dominated CPU Stalls` fired
  THEN → SECONDARY. Fix the frontend first and re-measure. Record and STOP (P4, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence
         of health since 600 pkc on both sides fires nothing, or the run is on generic `amd`
         where `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read
         the absolutes directly, or `ipc` alone on amd (P3, R0)

STEP 4 — Compute the escalation fraction. The set relation is VENDOR-DEPENDENT and is the
         REVERSE of the instruction side on AMD.
  IF `Data TLB Misses` did NOT fire but this finding did
  THEN → on grv/grv5 and amd/milan/genoa that is IMPOSSIBLE, since a walk implies a miss:
         suspect multiplexing or a truncated miss value below 0.005. On intel/icelake/spr it is
         legitimate, because the counters are disjoint and the non-escalating half can be
         genuinely zero (P3, R0)
       → verify: `--tlb --profile <p> --tlb-side data` raises InsufficientData on the nested
         profiles for exactly this input; if it raises, fix the collection first
  IF the profile is `grv`, `grv5`, `amd`, `milan` or `genoa`
  THEN → NESTED: arm64 by vendor semantics (0x5 refill, 0x34 walk), AMD by umask containment
         (walk umask 0xf0 a strict SUBSET of miss umask 0xff). `tw / mpki` IS the escalation
         fraction, bounded by 1.0, and the total miss rate is the mpki figure alone (P2, R0)
       → verify: `--tlb --profile <p> --tlb-side data` reports `relation: nested` and a
         fraction in [0, 1]; a raw ratio above 1.0 here means the collection is distorted
  IF the profile is `intel`, `icelake` or `spr`
  THEN → DISJOINT (0x8 umask 0x20 vs 0x1). Total misses is `mpki + tw`, the fraction is
         `tw / (mpki + tw)`, and a raw ratio above 1.0 is LEGITIMATE rather than a bug (P2, R0)
       → verify: `--tlb --profile intel --tlb-side data` returns a fraction in [0, 1] and a
         total larger than the reported miss rate; a hand ratio above 1.0 means the wrong
         relation was used
  IF the escalation fraction is >= 0.5
  THEN → the TLB hierarchy is saturated: most misses reach a full walk of 4-5 dependent memory
         references. HUGE PAGES are the primary lever, and they both remove translations and
         shorten each remaining walk by a level (P1, R4)
       → verify: `data-tlb-tw-pki` falls FASTER than `data-tlb-mpki` after enabling THP, since
         the walks are the tail huge pages remove first
  IF the escalation fraction is < 0.2
  THEN → the L2 TLB absorbs most misses, so the walk cost is small however large the miss
         count. Size the THP expectation on THIS figure, not on the miss figure (P3, R0)

STEP 5 — Are the walks compounding a memory problem? This is where the data side differs most
         from the instruction side.
  IF `High L3 Cache Misses` ALSO fired
  THEN → THE COMPOUNDING CASE: every walk level is a memory access competing for the SAME
         saturated DRAM bandwidth as the data access it is enabling, so each walk costs far
         more than 4-5 references implies. One huge-page change relieves both (P1, R4)
       → verify: stall-backend-pkc falls further than the walk-rate reduction alone predicts --
         the signature of relieved bandwidth rather than merely fewer walks
  IF `numa_miss` or `other_node` in `numastat` is material
  THEN → the WORST case: a walk whose levels land on a remote node pays remote latency four or
         five times over, and numastat has NO analytical rules so nothing flags it (P1, R4)
       → verify: after pinning or interleaving, other_node falls AND stall-backend-pkc falls;
         a falling other_node with a flat stall figure means placement was not the constraint
  IF `data-l1-mpki` is LOW while the walk rate is high
  THEN → the data CACHES well but is spread across many pages: a pure TRANSLATION problem, and
         the cleanest huge-page case in this playbook (P2, R4)
       → verify: data-tlb-tw-pki falls after THP while data-l1-mpki stays flat -- the signature
         of a translation-only fix. If BOTH data-l1-mpki and l2-mpki are instead elevated, the
         two costs are additive: run `--funnel` first and do the cheap fix before the layout one

STEP 6 — Is the cheap fix available, and will it allocate? MANDATORY manual check: aperf
         reports the THP kernel config but not the runtime `/sys` setting.
  IF `Huge Page Disabled` fired
  THEN → `CONFIG_TRANSPARENT_HUGEPAGE` is off at the KERNEL level, so no runtime setting can
         turn THP on: a kernel change, not an `echo` (P1, R4)
       → verify: after enabling, `AnonHugePages` in `meminfo` becomes non-zero AND
         `data-tlb-tw-pki` falls; a rising AnonHugePages with a flat walk rate means the huge
         pages went to text or to an inactive mapping
  IF THP is configured but `AnonHugePages` is far below the workload's footprint
  THEN → fragmentation is preventing allocation. Check the `memalloc` PageBlocks series for
         high-order free blocks; the fix is compaction settings, boot-time reservation, or the
         smaller folio sizes on kernels >= 6.9 (P2, R4)
       → verify: AnonHugePages rises toward the footprint, and only then re-read the walk rate
  IF the fix under consideration is `vm.nr_hugepages` rather than THP
  THEN → reserved pages are taken from the page cache PERMANENTLY, so a workload that needs
         that memory regresses on a different axis. The higher-risk end of R4 (P2, R4)
       → verify: `MemAvailable` and the page-cache figures in `meminfo` after reservation, plus
         the `vmstat` reclaim counters; a rise in reclaim means the reservation was too large

STEP 7 — What survives?
  VALID      : the per-CPU and aggregate `data-tlb-tw-pki` series read as magnitudes; the
              read/store split read by hand; the escalation fraction computed WITH the
              profile's set relation; the stall split read as absolute pkc; and every non-PMU
              finding in the run
  CAUTION    : the reported VALUE, which is the worst-scoring rather than the worst sample; and
              the nominal 4-5 references per walk, which is a floor and not a cost
  CONFOUNDED : the value on `intel`/`icelake`/`spr` for a store-heavy workload, where the
              metric covers loads only; the value on a multiplexed run, where a zero threshold
              has no noise margin; and the value on an idle-diluted run
  VOID       : any severity claim from the SCORE, which is non-monotonic and flat below 1.0;
              any `tw / mpki` fraction computed without the set relation; any SPR data-TLB
              value treated as authoritative rather than corroborating; and any
              cross-architecture comparison of this metric

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF the profile cannot be identified from `Instance Type`
  THEN → the set relation is unknown, so no escalation fraction is computable and STEP 4 is
         unreadable. Report the magnitude only (P3, R0)
```

## Runtime-specific consequences

A walk costs the same everywhere; what differs is **how badly the live data is scattered and whether the
runtime can be told to use bigger pages**.

| Runtime | Why the walks, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | The largest real case. A multi-gigabyte heap overwhelms the L2 TLB, not just the L1, and a copying collector *relocates* live objects so the page set churns under the whole hierarchy. Expected, not a defect — and the runtime with the most direct lever | `jvmArguments` for `-XX:+UseTransparentHugePages` / `-XX:+UseLargePages` and `-Xmx`; `GC` data for whether collection cycles align with the elevated intervals. Huge pages are the axis |
| **Python** | Object-per-value allocation scatters the live set by construction, so walks track object-graph traversal rather than array work. A NumPy/torch stack behaves oppositely — large contiguous arrays that are huge-page-friendly. Rarely a defect | Whether the walks track native-array work or pure-Python object graphs; the latter is not fixable by configuration. Data structure is the axis |
| **.NET** | Gen-0/gen-1 collections compact, so the live set stays comparatively dense and walks are usually lower than the equivalent JVM. The large-object heap does *not* compact, so a rising walk rate across a long recording is the signature | `DOTNET_GCgen0size`, server-vs-workstation GC, and whether the series *trends up* rather than being flat-elevated. Allocation profile is the axis |
| **Perl** | Every value is an SV from arenas with no compaction and no huge-page flag, so a large data set is inherently scattered across the whole address space. Structural, not a finding | Whether the hot data can move into a packed structure or an XS/C library. System-level THP is the only real lever, which makes it relatively more attractive here |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 6: the THP question needs no knowledge of who allocated the pages, and it is also the one
remediation that shortens each remaining walk by a page-table level rather than merely reducing the count.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — registry `architectures` lists every one and
`architecture_note` is empty. That silence hides two things that change what the number means.

| Profile | `Data_TLB_TW` encoding | Covers stores? | Relation to `Data_TLB` |
|---|---|---|---|
| `grv`, `grv5` | `armv8_pmuv3_0/event=0x34/` | **Yes**, one counter | **NESTED** in `0x5` by vendor semantics |
| `intel`, `icelake` | `cpu/event=0x8,umask=0x1/` | **No** — stores are on `0x49`, which no rule reads | **DISJOINT** from umask `0x20` |
| `spr` | `cpu/event=0x8,umask=0x1/` — **inherited, not refreshed** | **No**, and the refreshed `0x12`/`0x13` pair has no rule | **DISJOINT** from umask `0x20` |
| `amd`, `milan`, `genoa` | `cpu/event=0x45,umask=0xf0/` | **Yes**, one counter | **NESTED**: `0xf0` ⊂ miss umask `0xff` |

So the same finding, at the same value, means "loads only, half the picture" on Intel and "both sides,
complete" on arm64 and AMD — and **the walk relation is nested on AMD here but disjoint on the instruction
side**, which is why a single cross-vendor ratio formula is wrong somewhere no matter which one is chosen.
All 16 pairings are re-derived from `src/pmu_configs/*.json` by `test_aperf_memory_hierarchy.py`, so they
cannot drift silently.

**The walk depth is not a constant either.** 4-level paging gives up to four dependent references per walk
and a 5-level-paging kernel gives five, which is why `PAGE_TABLE_LEVELS = (4, 5)` makes the module report a
range. aperf collects no page-table-depth field and no page-size field, so **the per-walk cost is never
observable from a report** — hence the refusal to convert this metric into a cycle budget; only
`stall-backend-pkc` carries a real cycle cost, and it attributes it to the pipeline side. Finally, aperf has
no architecture field and no rule compares `Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an
Intel→Graviton comparison with matched `CPUs` and `MemTotal` fires **no gate**, yet the event, the store
coverage, the set relation, the TLB geometry and the page size all changed.

## Verification

Apply the fix and re-record at the **same geometry, counter mode, and instance type**, then check three
things in order. First, `AnonHugePages` in `meminfo` must actually have risen — an unchanged figure means
the setting was accepted and the allocation failed, so nothing was tested. Second, `data-tlb-tw-pki` should
fall **faster** than `data-tlb-mpki`, since huge pages remove the escalating tail first; a run where both
fall proportionally suggests something else changed, and on Intel `data-st-tlb-tw-pki` must fall with it or
the store side was never addressed. Third, `stall-backend-pkc` must fall in **absolute pkc**, not merely
relative to the frontend.

If `High L3 Cache Misses` also fired, expect the backend stall to fall **further than the walk-rate
reduction alone predicts** — the signature of relieved bandwidth rather than merely fewer walks, and its
absence means the compounding was not real. If the walk rate falls but the finding **persists**, that is
expected: with a zero threshold the rule fires until the metric is identically zero. This finding therefore
**cannot be verified by its own presence or by its score** — a materially improved run still fires it, and
a worse run can score milder. Verify on the magnitude, the escalation fraction, and the absolute stall.

## Do not

- **Do not treat the firing itself as a problem.** The threshold is 0.0, so its presence ranks nothing.
  Its *silence* while `Data TLB Misses` fired is the informative case: the L2 TLB absorbed every miss.
- **Do not treat the reported value as the worst sample, or as the average.** It is the worst-**scoring**
  sample: `[0.20, 1.90]` reports `0.20`, and a score tie is broken by `>=` in favour of whichever came
  last.
- **Do not rank severity by score.** A sample of 2.00 and one of 0.05 both score exactly −1.00 while
  differing by a factor of hundreds in cycle cost, and exactly 1.00 scores −0.00 and renders **grey with
  a neutral icon**.
- **Do not read this value as total data-TLB walk traffic on `intel`, `icelake` or `spr`.** It covers loads
  only; `data-st-tlb-tw-pki` (event `0x49`) carries the store side and **no rule reads it**. And **do not
  treat an `spr` value as authoritative** — the rule reads the un-refreshed generic-Intel `0x8`.
- **Do not compute `data-tlb-tw-pki / data-tlb-mpki` without the profile's set relation.** The counters are
  nested on `grv`/`grv5` *and* AMD — the **reverse** of the instruction side — but disjoint on Intel, where
  the total is `mpki + tw`. And **do not report a walk rate above the miss rate as a collection bug on
  Intel**: there it is expected, while on arm64 and AMD it is impossible and means multiplexing distorted one.
- **Do not read this in isolation from `data-tlb-mpki`.** The escalation fraction is what tells you whether
  the TLB hierarchy is saturated, and that determines whether huge pages will help. And **do not overlook
  the interaction with `l3-mpki`**: walks are memory accesses, so in a DRAM-bound workload they cost far
  more than their count implies, and that compounding is what raises this to P1.
- **Do not convert this metric into a cycle budget.** The walk depth is 4 or 5 levels depending on the
  kernel's paging mode, each level's latency depends on where it hits, and aperf reports neither;
  `stall-backend-pkc` is the only real cycle figure available. And **do not act on a non-zero value when
  `mux_counter_schedule_rate` is below 100** — a zero-threshold rule has no noise margin — or **read the
  value as characteristic of the instance**, since this template iterates every series including per-CPU
  (`processed_data_accessor.rs:104`).
- **Do not enable huge pages reflexively.** They cost allocation latency, can fail outright under
  fragmentation, and waste memory when partially used — an R4 change. `vm.nr_hugepages` is worse still:
  reserved pages leave the page cache permanently.
- **Do not confuse this with `Instruction TLB Table Walks`.** Separate TLBs, separate causes — data
  footprint vs code footprint — same huge-page remedy. And **do not optimize translation while the workload
  is frontend-bound.**

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:124` — `metric: "data-tlb-tw-pki"`,
  `comparator: Comparator::Greater`, `threshold: 0.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)` using `>=`, so a later tie wins and the reported
  value is the worst-**scoring** sample. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `threshold == 0.0` branch at `:170`
  returns the flat `rule_score` below value 1.0 and `(value − 1.0) * rule_score` above, making `|score|`
  V-shaped. `Score::Concerning = −1` at `:147`–`:157`. A score of exactly `0` is painted grey with the neutral
  icon by `getFindingColor` and `FindingIcon`
  (`src/report_frontend/src/components/analytics/AnalyticalFindings.tsx:35`).
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config by
  `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:765`–`:797`. `Data_TLB_TW` is
  `event=0x34` (grv, grv5), `event=0x8,umask=0x1` (intel, icelake, **and spr, un-refreshed**),
  `event=0x45,umask=0xf0` (amd, milan, genoa). The store-side `data-st-tlb-tw-pki` (`0x49`, and `0x13` on spr)
  has **no rule**. `perf_stat` opts **out** of the forced first zero via `use_first_accumulative_value()`
  (`:1295`).
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) — `--tlb` returns the
  corrected total and escalation fraction for the profile and side, emits the store-side and SPR caveats, and
  raises on the impossible nested case; `--funnel` localizes the cache boundary; `--select` reproduces the
  template's selection. `test_aperf_memory_hierarchy.py` re-derives all 16 TLB pairings from the umask bits.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate of R%
  is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and duplicates
  events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `TLB_MISS_OPTIMIZATION` (exact THP/folio/reserved-page commands and JVM flags),
  `DATA_FOOTPRINT_OPTIMIZATION` and `CPU_BACKEND_STALLS_INVESTIGATION` (which lists `data-tlb-tw-pki`), in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `data-tlb-misses.md` (the non-escalating half), `instruction-tlb-table-walks.md` (the
  code side, on the encoding SPR *did* refresh), `backend-dominated-cpu-stalls.md` (the severity gate),
  `high-l3-cache-misses.md` (the compounding case), `high-l1-data-cache-misses.md`,
  `high-l2-cache-misses.md`, `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../kernel_config/huge-page-disabled.md`, `../vmstat/increased-minor-page-faults.md`,
  `../cpu_utilization/underutilized-cpu.md`. Cross-cutting: [../GATES.md](../GATES.md),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md), [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down back-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-back-end-stalls)
- [Arm Neoverse N3 — DTLB MPKI metric group](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/MPKI-metrics-for-Neoverse-N3?lang=en#md407-mpki_mg__dtlb_mpki_m_MPKI)
- [LWN — large folios](https://lwn.net/Articles/937239/)
