---
rule_name: Data TLB Misses
data_type: perf_stat
data_key: data-tlb-mpki
template: time_series_data_point_threshold
condition: "any(data-tlb-mpki) > 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "This indicates the CPU has to do extra stalls to translate virtual addresses in the load and store instructions into physical addresses the DRAM understands, before issuing them to the memory system. It causes CPU backend stalls."
source: src/analytics/rules/perf_stat.rs:116
---

# Data TLB Misses

## What fired

**At least one** data point of `data-tlb-mpki` was **greater than 0.0**.

**The threshold is zero** — any non-zero data-TLB miss rate in any single sample fires this rule. It is
one of the four zero-threshold TLB rules and among the least selective findings in aperf; essentially
every real workload produces it. The *magnitude* is the signal, not the firing. Base score `Concerning`
(−1). Single-run rule.

## The collection gap — the metric is blind to stores on Intel, and the value is not the peak

**Gap 1 — on `intel`, `icelake` and `spr` this metric does not cover stores.** `data-tlb-mpki` resolves
to `cpu/event=0x8,umask=0x20/` while the *same* config separately defines `data-st-tlb-mpki` on event
`0x49` — the config's own evidence that the metric the rule reads is one side of the picture. **No aperf
rule reads `data-st-tlb-mpki`** (nor, on `spr`, the refreshed `data-rd-tlb-mpki` / `data-st-tlb-mpki` on
`0x12` / `0x13`), so a store-heavy workload's translation pressure is **invisible to this finding on
Intel**. arm64 (`0x5`) and AMD (`0x45` umask `0xff`) count both sides in one counter, so there the value
is complete. On Intel the graphs for the store side exist in the report even though no finding cites
them — read them by hand before concluding the pressure is mild.

**`spr` is worse: the encoding the rule reads is stale.** The SPR override refreshes `Instruction_TLB`
(`0x85` → `0x11`) and `L2` (`0xf1` → `0x25`), and *adds* `data-rd-tlb-*` / `data-st-tlb-*` on `0x12` /
`0x13` — yet leaves the data-TLB pair on the inherited generic-Intel `0x8`. The rules read the
un-refreshed encoding; the refreshed metrics have no rule. **Treat an SPR data-TLB value as
corroborating evidence only.**

**Gap 2 — the reported value is the worst-*scoring* sample, not the worst sample.**
`compute_finding_score` (`src/analytics/mod.rs:170`) special-cases a zero threshold:

```
if value < 1.0  →  score = rule_score            (flat, no magnitude)
else            →  score = (value - 1.0) * rule_score
```

so `|score|` is **V-shaped** — flat at 1.0 below value 1.0, zero at exactly 1.0, and only above value
2.0 does it exceed the flat branch. The template (`time_series_data_point_threshold_rule.rs:98`–`:117`)
keeps the sample with the largest `abs(finding_score)`, *not* the largest value, using `>=` so a later
tie overwrites:

| series | reports | score | the peak |
|---|---|---|---|
| `[0.30, 1.50]` | **0.30** | −1.00 | 1.50 — scores only −0.50, so it loses |
| `[0.0, 0.31, 0.42, 0.28]` | **0.28** | −1.00 | 0.42 — every sub-1.0 sample ties and `>=` takes the last |
| `[0.60, 2.00]` | **2.00** | −1.00 | 2.00 — a tie with 0.60, won by position |
| `[1.00]` | **1.00** | **−0.00** | renders **grey** with the neutral icon |

Both gaps are checked by `test_aperf_memory_hierarchy.py`, which ports the selection loop independently
and re-derives all 16 TLB pairings from the umask bits:

```
$ python3 ../tools/aperf_memory_hierarchy.py --select 0.30 1.50
reported_value: 0.3, finding_score: -1.0, series_max: 1.5, reports_the_peak: false
```

## Reasoning

`data-tlb-mpki` is "Translation Lookaside Buffer (TLB) misses for data accesses per thousand
instructions, indicating how often the CPU has to perform extra stalls to translate a virtual address
into physical address before issuing a load/store to the memory system." (`data-descriptions.ts`,
`desired: "lower"`)

Every load and store carries a *virtual* address that must be translated before the memory system can
be reached. The data TLB caches those translations; it is small — typically tens of entries at L1 level
— and each entry covers one page. With 4 KB pages, a 48-entry L1 DTLB covers about **192 KB of data**,
so any workload whose active data exceeds that will miss. The resulting stall is a **backend** stall:
the instruction is issued and cannot proceed because the address is not yet resolved. Critically,
**the translation cost is additive to the data-access cost** — a load that misses both the DTLB and L1D
pays for the translation *and then* for the cache miss. That is why translation is worth treating as a
separate axis from cache behaviour: it has its own, independent, and usually cheaper fix.

The determining factor is **how many distinct pages the workload touches**, not how many bytes it uses.
A workload that reads 1 MB sequentially touches 256 pages of 4 KB; one that reads 1 MB scattered across
a 10 GB heap may touch 256 *different* pages spread over the whole address space, thrashing the TLB far
more severely for the same byte count. Hence two levers: **touch fewer pages** (contiguous storage,
sequential access, smaller data), or **make each page cover more data** — **huge pages**, where one
2 MB page replaces 512 4 KB pages so a single DTLB entry covers 2 MB. That is why
`TLB_MISS_OPTIMIZATION` is attached to this metric and why it is usually the first thing to try: a
configuration change, no rebuild, and for large heaps, big buffers and databases the win can be
substantial. On kernels ≥ 6.9, THP is extended with **folios** giving 16 KB and 64 KB page sizes in
addition to 2 MB — easier to allocate under fragmentation and applicable in more places.

Common causes: large heaps with scattered access, random access over multi-gigabyte structures, hash
tables and trees, memory-mapped files, and allocation churn that keeps moving the active set to new
pages. **The silence is not evidence of clean translation**: `data-tlb-mpki` is defined on all 8 PMU
profiles, so an absent finding on a run that collected `perf_stat` means the metric was missing or
identically zero — a collection question first.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 1.50 (greater than the threshold of 0).
```

**Four things that sentence does not tell you.** **`1.50` is the worst-*scoring* sample, not the worst
sample and not the average** (see `The collection gap`); the peak may be higher and is not recoverable.
**It may be one CPU's series** — this template iterates **every** series including per-CPU
(`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based
`perf_stat` rules which read only `Aggregate` (`:432`), so one thread with a scattered working set fires
this for the whole run. **The value is truncated, not rounded** (`f64_to_fixed_2`,
`src/computations/mod.rs:138`), so `1.50` is anything in `[1.50, 1.51)`, and
`(greater than the threshold of 0)` is printed rather than computed. And **there is no `(n−1)/n`
dilution correction**: `perf_stat` opts out of the forced first zero via `use_first_accumulative_value()`
(`src/data/perf_stat.rs:1295`), so the first sample is real.

Score math — `compute_finding_score(value, 0.0, −1)`, the `threshold == 0.0` branch:

| worst-scoring sample | score | note |
|---|---|---|
| 0.05, 0.90 | **−1.00** | flat: any value below 1.0 gives the base score |
| **1.00** | **−0.00** | score collapses to zero; renders **grey** |
| 1.50 | **−0.50** | *milder* than a 0.05 sample |
| 2.00 | **−1.00** | collides with the entire sub-1.0 range |
| 12.00 | **−11.00** | |

Above 1.0 recover the sample as `value = |score| + 1`; below 1.0 it is not recoverable, since `|score| =
1.00` has two disjoint preimages — everything below 1.0, and exactly 2.0.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The metric is identically zero across every sample | no finding. Implausible on a real workload, so read it as a collection question rather than as clean translation |
| The workload is store-heavy on `intel`/`icelake`/`spr` | a value covering **loads only**; the store side is on `data-st-tlb-mpki`, which no rule reads |
| The only exceeding sample is exactly 1.0 | the finding exists at score **−0.00** and renders grey with a neutral icon, sorting below every positive finding |
| The run multiplexed heavily | extrapolation alone can produce a non-zero sample. A zero threshold has **no** noise margin |
| Only one `CPU{n}` series exceeded | reported for the run; the `Aggregate` series may be benign |

## Interpretation

Because the rule fires on any non-zero value, **the magnitude is the finding**:

| sustained value | Reading |
|---|---|
| < 0.5 | Essentially universal. Ignore unless the backend is dominant and everything else is clean |
| 0.5–2 | Mild translation pressure. Huge pages worth trying if backend-dominant |
| 2–10 | Real DTLB pressure; huge pages likely to give a measurable win |
| > 10 | Severe — the data footprint vastly exceeds DTLB coverage |

Combinations:

| elevated **and** | Reading |
|---|---|
| sustained across the series | Genuine and actionable; one isolated sample is first-touch, heap growth or a phase transition, and is not |
| `Data TLB Table Walks` also fired with a high value | Misses escalate to full page-table walks — the expensive tail. **Higher priority; huge pages likely to pay off** |
| `Backend-Dominated CPU Stalls` fired | **The confirmed case.** `Frontend-Dominated CPU Stalls` instead ⇒ secondary, fix the frontend first |
| `Huge Page Disabled` also fired | **Direct cheap fix available** — THP is off at the kernel-config level |
| `l3-mpki` also high | Translation *and* DRAM cost stacked on the same accesses; huge pages help both, since page-table walks are themselves memory accesses |
| `data-l1-mpki` low but DTLB high | Data is cached well but *scattered across pages* — a pure translation problem, and the cleanest case for huge pages |
| `Instruction TLB Misses` also fired | System-wide translation pressure; one huge-page change helps both sides |

**Known false positives — most firings fall here:**

- **Any non-zero value fires it.** The defining condition; a value of 0.02 is measurement floor. And the
  reported value understates the peak, so a small description value does not settle it either way.
- **A single transient sample.** First-touch of newly allocated memory always misses; so do startup,
  heap growth and phase transitions.
- **PMU multiplexing.** With a zero threshold there is no noise margin — extrapolation error alone can
  produce a non-zero sample. If `PMU Counter Collection Multiplexing` fired, this finding is
  low-confidence by default. **The most likely false-positive combination for all four zero-threshold
  TLB rules.**
- **One hot CPU.** The rule reads every per-CPU series, so a single scattered thread fires it for the run
  while the aggregate is benign.
- **Idle-diluted or kernel-heavy runs.** Background daemons touch scattered pages; and if `system` time
  dominates, part of the translation cost is kernel-side and not addressable in your application.
- **Large-heap workloads are inherently high-miss.** Databases, JVMs with multi-gigabyte heaps and
  in-memory caches exceed DTLB coverage by orders of magnitude. Expected — and precisely the case huge
  pages were designed for. Memory-mapped file access is the same story: touching a large mapping
  generates translations by construction.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `data-tlb-mpki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient, and whether one CPU or all — the description gives neither |
| `data-tlb-tw-pki` | `perf_stat` | **Read together** — whether misses escalate to full walks. The escalation fraction is the key number, computed with the profile's set relation. See `Data TLB Table Walks` |
| `data-rd-tlb-mpki`, `data-st-tlb-mpki` | `perf_stat` | **Mandatory on Intel** — the read/store split, and on `intel`/`icelake`/`spr` the only way to see store-side pressure at all. **No rules fire on these** |
| `data-rd-tlb-tw-pki`, `data-st-tlb-tw-pki` | `perf_stat` | Same split for walks. **No rules fire on these** |
| `stall-backend-pkc` vs `stall-frontend-pkc`, `ipc` | `perf_stat` | **Severity gate.** DTLB misses cost backend cycles, and `ipc` says whether the pipeline is suffering. See `Backend-Dominated CPU Stalls` |
| `data-l1-mpki`, `l2-mpki`, `l3-mpki` | `perf_stat` | Cache behaviour on the same accesses. Low cache misses with high DTLB misses = a pure translation problem |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate — critical.** Zero threshold means no noise margin |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | **The fix check.** See `Huge Page Disabled` |
| `AnonHugePages`, `HugePages_Total`, `HugePages_Free`, `Hugepagesize`, `ShmemHugePages` | `meminfo` | Whether huge pages are configured and actually in use |
| PageBlocks series | `memalloc` | High-order free blocks — whether fragmentation is preventing huge-page allocation. **No analytical rules — read manually** |
| `Kernel Version`, `Instance Type` | `systeminfo` | ≥ 6.9 enables 16 KB / 64 KB folios; and the instance type is the only clue to which PMU profile applied |
| `pgfault`, `pgminorfault` | `vmstat` | Allocation churn moving the active set to new pages. See `Increased Minor Page Faults` |
| `numa_miss`, `other_node` | `numastat` | Remote-node access; walks to remote memory are especially costly. **No analytical rules** |
| `resident_set_size_bytes` | `processes` | Process footprint — how many pages are in play. **No analytical rules — read manually** |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| On-CPU profile, Hotline output | `perf_profile` / `java_profile`, `hotline` | Which code performs the scattered accesses, and address-level attribution (native code on metal Graviton). Both need `--profile`; **neither has analytical rules** |

## Guidance

Ordered. Steps 1–2 eliminate most firings.

1. **Read the series, not the description.** The threshold is zero, so firing alone means nothing, and
   the reported value is the worst-*scoring* sample rather than the peak. A sustained peak **< 0.5** is
   measurement floor — stop. An **isolated spike** at run start, heap growth or a phase boundary is a
   first-touch artifact — stop. **Sustained** ⇒ continue, checking the per-CPU series first.

2. **Gate hard on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`) — a zero-threshold rule has no noise margin — and `avg(idle)` (`Underutilized CPU`).

3. **On Intel, read the store side by hand before going further.** `data-tlb-mpki` covers loads only on
   `intel`/`icelake`/`spr`, and `data-st-tlb-mpki` (event `0x49`) has no rule. A store-heavy workload can
   show a mild value here and severe real pressure. On `spr` also record that the encoding the rule reads
   is the un-refreshed generic-Intel `0x8`, so the value is corroborating evidence only.

4. **Confirm the backend is the bottleneck.** Compare `stall-backend-pkc` and `stall-frontend-pkc`, and
   read `ipc`. Backend dominant with low IPC ⇒ actionable; frontend dominant ⇒ record as secondary. On
   generic `amd` neither stall metric exists, so use `ipc` alone.

5. **Check whether misses escalate to walks, with the profile's set relation applied.** Misses absorbed
   by the L2 TLB are comparatively cheap; misses requiring a full page-table walk cost far more, and a
   high escalation fraction is the strongest predictor that huge pages will help:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --tlb --miss-pki 4.80 --walk-pki 4.10 \
         --profile grv --tlb-side data
   relation: nested, total_misses_pki: 4.8, escalation_fraction: 0.854, thp_leverage: high
   ```

   The data side is **nested** on `grv`/`grv5` *and* on `amd`/`milan`/`genoa` (umask `0xf0` ⊂ `0xff`),
   but **disjoint** on `intel`/`icelake`/`spr`, where the total miss rate is `mpki + tw` and a raw ratio
   above 1.0 is legitimate. Note this differs from the instruction side, where AMD is disjoint.

6. **Separate the translation problem from the cache problem.** Read `data-l1-mpki`, `l2-mpki`, `l3-mpki`.
   Cache misses low with DTLB misses high ⇒ the data is cached well but spread across many pages: the
   cleanest huge-page win, fix translation and leave the layout alone. Both high ⇒ two additive costs;
   huge pages address one and footprint reduction the other, and the huge-page change is far cheaper.

7. **Check whether huge pages are available, and whether they can allocate.** Read
   `CONFIG_TRANSPARENT_HUGEPAGE` (`kernel_config`, see `Huge Page Disabled`), `AnonHugePages` /
   `HugePages_Total` / `Hugepagesize` (`meminfo`), and `Kernel Version` — ≥ 6.9 offers the smaller folio
   sizes. If THP is off or unused, that is the first remediation and it needs no rebuild. If it is
   *enabled* but `AnonHugePages` sits far below the footprint and the `memalloc` PageBlocks series shows
   few high-order free blocks, the kernel cannot find contiguous memory: the fix is compaction settings
   or boot-time reservation, not more THP configuration.

8. **Only then remediate**, per `TLB_MISS_OPTIMIZATION`: enable THP with
   `echo always > /sys/kernel/mm/transparent_hugepage/enabled` (or `madvise`); on kernels ≥ 6.9 tune
   folio sizes under `/sys/kernel/mm/transparent_hugepage/hugepages-{16kB,64kB,2048kB}/enabled`; for
   `mmap`-based applications reserve pinned huge pages via `sysctl -w vm.nr_hugepages=X` or
   `hugepagesz=2M hugepages=512` in `/etc/default/grub`; for Java add `-XX:+UseTransparentHugePages`
   (THP ≥ `madvise`) or `-XX:+UseLargePages`. Complementary, from `DATA_FOOTPRINT_OPTIMIZATION`: store
   related data contiguously, access sequentially, reduce total footprint — all of which shrink the page
   span too. Use the read/store split to target it: store-driven pressure usually means allocation churn
   or write-scattered structures, load-driven means scattered reads.

## Priority and execution risk

**Priority: P3 — Monitor** by default. A zero threshold means the firing itself ranks nothing, and nearly
every real workload fires this rule. It rises to **P2 — Investigate** once the sustained value is above
roughly 2 pki, and to **P1 — Act now** when `Data TLB Table Walks` also fired with a high escalation
fraction **and** `Backend-Dominated CPU Stalls` fired — that is the combination in which huge pages have
a quantified target — or, on the same evidence, when `Huge Page Disabled` also fired, because a costly
problem then has a configuration-only fix. It drops to **P4 — Informational** whenever the run
multiplexed, and stays at **P3 at most** when only one `CPU{n}` series is elevated. **On `spr` it stays
at P3 at most regardless of magnitude**, because the encoding the rule reads is stale.

**Execution risk: R0 — Read-only** to diagnose — the series, the per-CPU split, the read/store split, the
escalation fraction, the stall comparison and the THP configuration are all reads. Acting is
**R4 — Infrastructure change** for enabling THP or reserving huge pages, which changes allocation
behaviour machine-wide and can fail outright under fragmentation, and **R2 — Code change** or
**R3 — Rebuild** for the footprint and layout levers. Pre-reserved pages via `vm.nr_hugepages` are the
higher-risk end of R4: they take memory from the page cache permanently, so a workload that then needs
that memory regresses on a different axis.

**The score is amplified, non-monotonic, and unusable for ranking.** A sample of 2.00 and a sample of
0.05 both score exactly −1.00; exactly 1.00 scores −0.00 and renders **grey**. **Rank on the sustained
value and the escalation fraction, never on score.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `data-tlb-mpki`, in any series including per-CPU, exceeded `0.0`
(`Greater 0.0`, so exactly zero does not fire).

```
STEP 0 — Does the perf_stat data exist, and does the metric cover the workload?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `perf_stat` exists and this finding is ABSENT
  THEN → `data-tlb-mpki` is defined on all 8 profiles and every real workload misses the DTLB,
         so an identically-zero metric points at COLLECTION, not at clean translation (P3, R0)
  IF the profile is `intel`, `icelake` or `spr` AND the workload is store-heavy
  THEN → the value covers LOADS ONLY (0x8 umask 0x20); the store side is data-st-tlb-mpki on
         0x49 and NO rule reads it. Read that graph by hand before ranking this finding
         (P2, R0)
       → verify: `data-st-tlb-mpki` in the report is comparable to or larger than
         `data-rd-tlb-mpki`; if it is, the finding understates the pressure and the magnitude
         bands below do not apply
  IF the profile is `spr`
  THEN → the data-TLB pair is the UN-REFRESHED generic-intel 0x8 even though the SPR override
         refreshed Instruction_TLB and L2 and added data-rd/st-tlb on 0x12/0x13. Corroborating
         evidence only; cap at P3 (P3, R0)
  IF the finding fired on any other profile
  THEN → the firing itself carries almost no information (threshold 0.0):
         continue to STEP 1

STEP 1 — Recover the real magnitude. The description does NOT give it: the reported value is
         the worst-SCORING sample, which on a zero-threshold rule is frequently the LEAST
         severe firing sample.
  IF the score is exactly -0.00 and the finding renders GREY
  THEN → the only exceeding sample was exactly 1.0 (mod.rs:170 collapses it,
         AnalyticalFindings.tsx:35 paints score==0 grey). Read it as a value of 1.0, which is
         mild but not a non-event (P3, R0)
  IF the score is exactly -1.00
  THEN → AMBIGUOUS by construction: the preimage is the whole interval below 1.0 PLUS exactly
         2.0. Read the series (P4, R0)
  IF the series peak exceeds the reported value
  THEN → expected, not a bug in the report: `>=` plus the V-shaped score prefers a smaller
         sample. Use the PEAK for every branch below (P3, R0)
       → verify: `../tools/aperf_memory_hierarchy.py --select <series>` reproduces the
         template's choice; if it disagrees with the report, the series you read is not the
         series the rule saw (suspect a per-CPU series)

STEP 2 — Gate on measurement confidence. A zero threshold has NO noise margin.
  IF `mux_counter_schedule_rate` < 100
  THEN → extrapolation alone can produce a non-zero sample. Report low-confidence and do NOT
         act (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the value collapses toward zero the
         original finding was multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons touch scattered pages, so the value is diluted with behaviour that
         is not the workload's (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES
         confirms the workload, one that falls confirms the daemons
  IF only one or two `CPU{n}` series are elevated
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one thread
         with a scattered working set fires it for the whole run: a thread, not the instance
         (P3, R0)
       → verify: the on-CPU profile names a thread with a distinct access pattern; a targeted
         fix should move that CPU's series and barely move the aggregate

STEP 3 — Is the backend actually the bottleneck? This decides whether ANY of it matters.
  IF `Backend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: address resolution is blocking issued instructions, and the
         translation cost is ADDITIVE to whatever the cache miss costs (P2, R4)
       → verify: `stall-backend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative
         to the frontend; a falling ratio with a flat absolute means the frontend got worse
  IF `Frontend-Dominated CPU Stalls` fired
  THEN → SECONDARY. Fix the frontend first and re-measure. Record and STOP (P4, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence
         of health since 600 pkc on both sides fires nothing, or the run is on generic `amd`
         where `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read
         the absolutes directly, or `ipc` alone on amd (P3, R0)

STEP 4 — Do the misses escalate to walks? The set relation is VENDOR-DEPENDENT and differs
         from the instruction side.
  IF `Data TLB Table Walks` did NOT fire but this finding did
  THEN → the L2 TLB absorbed every miss, so the cost is tens of cycles rather than hundreds and
         huge pages have little to win. Lowest-value branch in this playbook (P4, R0)
  IF the profile is `grv`, `grv5`, `amd`, `milan` or `genoa`
  THEN → NESTED: arm64 by vendor semantics (0x5 refill, 0x34 walk), AMD by umask containment
         (0x45 walk umask 0xf0 is a strict SUBSET of miss umask 0xff). `data-tlb-tw-pki /
         data-tlb-mpki` IS the escalation fraction, bounded by 1.0 (P2, R0)
       → verify: `--tlb --profile <p> --tlb-side data` reports `relation: nested` and a
         fraction in [0, 1]; a raw ratio above 1.0 here means the collection is distorted
  IF the profile is `intel`, `icelake` or `spr`
  THEN → DISJOINT (0x8 umask 0x20 vs 0x1). Total misses is `mpki + tw`, the fraction is
         `tw / (mpki + tw)`, and a raw ratio above 1.0 is LEGITIMATE rather than a bug. NOTE
         this is the OPPOSITE of AMD on this side (P2, R0)
       → verify: `--tlb --profile intel --tlb-side data` returns a fraction in [0, 1] and a
         total larger than the reported miss rate; a hand ratio above 1.0 means the wrong
         relation was used
  IF the escalation fraction is >= 0.5
  THEN → the TLB hierarchy is saturated: most misses reach a full walk of 4-5 dependent memory
         references. HUGE PAGES are the primary lever (P1, R4)
       → verify: `data-tlb-tw-pki` falls FASTER than `data-tlb-mpki` after enabling THP, since
         the walks are the tail huge pages remove first

STEP 5 — Translation problem or cache problem? They are additive and independently fixable.
  IF `data-l1-mpki` is LOW while this metric is high
  THEN → the data CACHES well but is spread across many pages: a pure TRANSLATION problem and
         the cleanest huge-page case available (P2, R4)
       → verify: data-tlb-mpki falls after THP while data-l1-mpki stays flat -- the signature
         of a translation-only fix
  IF `data-l1-mpki` AND `l2-mpki` are also above their thresholds
  THEN → two additive costs on the same accesses. Huge pages address translation, footprint
         reduction addresses caching; do the cheap one first (P2, R4)
       → verify: run `--funnel` to localize the cache boundary before spending on layout, and
         confirm the two metrics move independently
  IF `l3-mpki` is also elevated
  THEN → page-table walks are THEMSELVES memory accesses, so a saturated data hierarchy makes
         every walk more expensive than the nominal 4-5 references (P2, R3)
       → verify: stall-backend-pkc falls after the data-side fix even if the TLB miss rate is
         unchanged -- confirming the walks got cheaper rather than rarer
  IF `numa_miss` or `other_node` in `numastat` is material
  THEN → walks reaching remote memory cost substantially more, and numastat has NO analytical
         rules so nothing flags it. Read it by hand (P2, R4)
       → verify: after pinning or interleaving, other_node falls AND stall-backend-pkc falls

STEP 6 — Is the cheap fix available, and will it allocate? MANDATORY manual check: aperf
         reports the THP kernel config but not the runtime `/sys` setting.
  IF `Huge Page Disabled` fired
  THEN → `CONFIG_TRANSPARENT_HUGEPAGE` is off at the KERNEL level, so no runtime setting can
         turn THP on: a kernel change, not an `echo` (P1, R4)
       → verify: after enabling, `AnonHugePages` in `meminfo` becomes non-zero AND
         `data-tlb-mpki` falls; a rising AnonHugePages with a flat miss rate means the huge
         pages went to text or to an inactive mapping
  IF THP is configured but `AnonHugePages` is far below the workload's footprint
  THEN → fragmentation is preventing allocation. Check the `memalloc` PageBlocks series for
         high-order free blocks; the fix is compaction settings, boot-time reservation, or the
         smaller folio sizes on kernels >= 6.9 (P2, R4)
       → verify: AnonHugePages rises toward the footprint, and only then re-read the miss rate
  IF the fix under consideration is `vm.nr_hugepages` rather than THP
  THEN → reserved pages are taken from the page cache PERMANENTLY, so a workload that needs
         that memory regresses on a different axis. The higher-risk end of R4 (P2, R4)
       → verify: `MemAvailable` and the page-cache figures in `meminfo` after reservation, plus
         the `vmstat` reclaim counters; a rise in reclaim means the reservation was too large

STEP 7 — What survives?
  VALID      : the per-CPU and aggregate `data-tlb-mpki` series read as magnitudes; the
              read/store split read by hand; the escalation fraction computed WITH the
              profile's set relation; the stall split read as absolute pkc; and every non-PMU
              finding in the run
  CAUTION    : the reported VALUE, which is the worst-scoring rather than the worst sample; and
              the nominal 4-5 references per walk, which is a floor and not a cost
  CONFOUNDED : the value on `intel`/`icelake`/`spr` for a store-heavy workload, where the
              metric covers loads only; the value on a multiplexed run, where a zero threshold
              has no noise margin; and the value on an idle-diluted run
  VOID       : any severity claim from the SCORE, which is non-monotonic and flat below 1.0;
              any `tw / mpki` fraction computed without the set relation; any SPR data-TLB
              value treated as authoritative rather than corroborating; and any
              cross-architecture comparison of this metric

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF the profile cannot be identified from `Instance Type`
  THEN → the set relation is unknown, so no escalation fraction is computable and STEP 4 is
         unreadable. Report the magnitude only (P3, R0)
```

## Runtime-specific consequences

A DTLB miss costs the same everywhere; what differs by runtime is **how many distinct pages the live
data occupies and whether the runtime can be told to use bigger ones**.

| Runtime | Why the misses, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | The largest real case. A multi-gigabyte heap exceeds DTLB coverage by orders of magnitude, and a copying collector *relocates* live objects, so the page set changes under the TLB. Expected, not a defect — and the runtime with the most direct lever | `jvmArguments` for `-XX:+UseTransparentHugePages` / `-XX:+UseLargePages` and `-Xmx`; `java_profile` and `GC` data for whether collection cycles align with the elevated intervals. Huge pages are the axis |
| **Python** | Object-per-value allocation scatters the live set across the heap by construction, and a NumPy/torch stack then adds large contiguous arrays with entirely different behaviour. Rarely a defect; often just what the object model costs | Whether the pressure tracks native-array work (contiguous, huge-page-friendly) or pure-Python object graphs (scattered, and not fixable by configuration). Data structure is the axis |
| **.NET** | Gen-0/gen-1 collections are compacting, so the live set is comparatively dense, but the large-object heap is not compacted and fragments over a long run — a rising miss rate across a long recording is the signature | `DOTNET_GCgen0size` and server-vs-workstation GC; whether the series *trends up* rather than being flat-elevated. Allocation profile is the axis |
| **Perl** | Every value is an SV allocated from arenas, so a large data set is inherently scattered and there is no compaction and no huge-page flag. Structural, not a finding | Whether the hot data can move into a packed structure or an XS/C library. THP at the system level is the only real lever, which makes it relatively more attractive here |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 6: the THP question needs no knowledge of who allocated the pages, and it is also the one
remediation that requires no rebuild.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — registry `architectures` lists every one and
`architecture_note` is empty. That silence hides two things that change what the number means.

| Profile | `Data_TLB` encoding | Covers stores? | Relation to `Data_TLB_TW` |
|---|---|---|---|
| `grv`, `grv5` | `armv8_pmuv3_0/event=0x5/` — L1D TLB refill | **Yes**, one counter | **NESTED** in `0x34` by vendor semantics |
| `intel`, `icelake` | `cpu/event=0x8,umask=0x20/` | **No** — stores are on `0x49`, which no rule reads | **DISJOINT** from umask `0x1` |
| `spr` | `cpu/event=0x8,umask=0x20/` — **inherited, not refreshed** | **No**, and the refreshed `0x12`/`0x13` pair has no rule | **DISJOINT** from umask `0x1` |
| `amd`, `milan`, `genoa` | `cpu/event=0x45,umask=0xff/` | **Yes**, one counter | **NESTED**: walk umask `0xf0` ⊂ `0xff` |

So the same finding, at the same value, means "loads only, half the picture" on Intel and "both sides,
complete" on arm64 and AMD — and the walk relation is **nested on AMD here but disjoint on the
instruction side**, which is why a single cross-vendor ratio formula is wrong somewhere no matter which
one is chosen. All 16 pairings are re-derived from `src/pmu_configs/*.json` by
`test_aperf_memory_hierarchy.py`, so they cannot drift silently.

**The walk depth is not a constant either.** 4-level paging gives up to four dependent references per
walk and a 5-level-paging kernel gives five, which is why `PAGE_TABLE_LEVELS = (4, 5)` makes the module
report a range. aperf collects no page-table-depth field, so **the per-walk cost is never observable from
a report**. Only `stall-backend-pkc` carries a real cycle cost, and it attributes it to the pipeline
side, not to the translation. Finally, aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate**, yet the event, the store coverage, the set relation, the TLB
geometry and the page size all changed.

## Verification

Apply the fix and re-record at the **same geometry, same counter mode, and same instance type**, then
check three things in order. First, `AnonHugePages` in `meminfo` must actually have risen — an unchanged
figure means the setting was accepted and the allocation failed, so nothing was tested. Second,
`data-tlb-mpki` must fall, and on Intel `data-st-tlb-mpki` must fall with it, or the store side was never
addressed. Third, `stall-backend-pkc` must fall in **absolute pkc**, not merely relative to the frontend.

If the miss rate falls and the backend stall does not, translation was not the backend's constraint and
STEP 5's cache branch is still open. If `data-tlb-mpki` falls but the finding **persists**, that is
expected: with a zero threshold the rule fires until the metric is identically zero. This finding
therefore **cannot be verified by its own presence or by its score** — a materially improved run still
fires it, and a worse run can score milder. Verify on the magnitude, the escalation fraction, and the
absolute stall figure.

## Do not

- **Do not treat the firing itself as a problem.** The threshold is 0.0 and nearly every real workload
  fires this rule, so its presence ranks nothing.
- **Do not treat the reported value as the worst sample, or as the average.** It is the worst-**scoring**
  sample: `[0.30, 1.50]` reports `0.30`, and a score tie is broken by `>=` in favour of whichever came
  last.
- **Do not rank severity by score.** A sample of 2.00 and one of 0.05 both score exactly −1.00, and
  exactly 1.00 scores −0.00 and renders **grey with a neutral icon**.
- **Do not read this value as total data-TLB pressure on `intel`, `icelake` or `spr`.** It covers loads
  only; `data-st-tlb-mpki` (event `0x49`) carries the store side and **no rule reads it**.
- **Do not treat an `spr` value as authoritative.** The rule reads the un-refreshed generic-Intel `0x8`
  even though the SPR override refreshed the instruction and L2 encodings — corroborating evidence only.
- **Do not compute `data-tlb-tw-pki / data-tlb-mpki` without the profile's set relation.** The counters
  are nested on `grv`/`grv5` *and* AMD but disjoint on Intel, where the total is `mpki + tw`. And note
  this is the **reverse** of the instruction side on AMD.
- **Do not act on a non-zero value when `mux_counter_schedule_rate` is below 100.** A zero-threshold rule
  has no noise margin, and extrapolation alone can fire it. And **do not read the value as characteristic
  of the instance**: this template iterates every series including per-CPU
  (`processed_data_accessor.rs:104`), so one scattered thread fires it for the whole run.
- **Do not enable huge pages reflexively.** Confirm the backend is dominant and the magnitude is material.
  THP costs allocation latency, can fail outright under fragmentation, and wastes memory when pages are
  partially used — an R4 change. `vm.nr_hugepages` is worse still: reserved pages leave the page cache
  permanently.
- **Do not conflate translation cost with cache cost.** They are additive and independently fixable;
  read `data-l1-mpki`/`l2-mpki`/`l3-mpki` to see which you are dealing with.
- **Do not confuse this with `Instruction TLB Misses`.** Separate TLBs, separate causes — data footprint
  vs code footprint — though the huge-page fix helps both. And **do not optimize translation while the
  workload is frontend-bound.**
- **Do not compare this metric across architectures.** The event, the store coverage and the set relation
  all differ by vendor, and no aperf gate fires on an architecture change with matched `CPUs` and
  `MemTotal`.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:116` — `metric: "data-tlb-mpki"`,
  `comparator: Comparator::Greater`, `threshold: 0.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)` using `>=`, so a later tie wins and the reported
  value is the worst-**scoring** sample. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — the `threshold == 0.0` branch at
  `:170` returns the flat `rule_score` below value 1.0 and `(value − 1.0) * rule_score` above, making
  `|score|` V-shaped. `Score::Concerning = −1` at `:147`–`:157`. A score of exactly `0` is painted grey
  with the neutral icon by `getFindingColor` and `FindingIcon`
  (`src/report_frontend/src/components/analytics/AnalyticalFindings.tsx:35`).
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config by
  `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:765`–`:797`. `Data_TLB` is
  `event=0x5` (grv, grv5), `event=0x8,umask=0x20` (intel, icelake, **and spr, un-refreshed**),
  `event=0x45,umask=0xff` (amd, milan, genoa). The store-side `data-st-tlb-mpki` (`0x49`, and `0x13` on
  spr) has **no rule**. `perf_stat` opts **out** of the forced first zero via
  `use_first_accumulative_value()` (`:1295`).
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) — `--tlb`
  returns the corrected total and escalation fraction for the profile and side and emits the store-side
  and SPR caveats; `--funnel` localizes the cache boundary; `--select` reproduces the template's
  selection. `test_aperf_memory_hierarchy.py` re-derives all 16 TLB pairings from the umask bits.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate
  of R% is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and
  duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `TLB_MISS_OPTIMIZATION` (exact THP/folio/reserved-page commands and the JVM flags),
  `DATA_FOOTPRINT_OPTIMIZATION` and `CPU_BACKEND_STALLS_INVESTIGATION` (which lists `data-tlb-mpki`), in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `data-tlb-table-walks.md` (the escalating tail),
  `instruction-tlb-misses.md` and `instruction-tlb-table-walks.md` (the code side),
  `backend-dominated-cpu-stalls.md` (the severity gate), `high-l1-data-cache-misses.md`,
  `high-l2-cache-misses.md`, `high-l3-cache-misses.md`,
  `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../kernel_config/huge-page-disabled.md`, `../vmstat/increased-minor-page-faults.md`,
  `../cpu_utilization/underutilized-cpu.md`. Cross-cutting: [../GATES.md](../GATES.md),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md), [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down back-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-back-end-stalls)
- [Arm Neoverse N3 — L1D TLB MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/DTLB-Effectiveness-metrics-for-Neoverse-N3?lang=en#md544-dtlb_effectiveness_mg__l1d_tlb_mpki_m_DTLB_Effectiveness)
- [LWN — large folios](https://lwn.net/Articles/937239/)
