---
rule_name: Backend-Dominated CPU Stalls
data_type: perf_stat
data_key: stall-backend-pkc
template: time_series_stat_intra_run_comparison
condition: "(avg(stall-backend-pkc) - avg(stall-frontend-pkc)) / avg(stall-frontend-pkc) >= 0.1"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "Higher CPU backend stalls indicate bottlenecks on instruction executions instead of fetches, usually due to data cache misses and lacking resources to execute enough memory operations in parallel. Check the related misprediction metrics for data."
source: src/analytics/rules/perf_stat.rs:40
---

# Backend-Dominated CPU Stalls

## What fired

Within **this single run**, the average of `stall-backend-pkc` exceeded the average of
`stall-frontend-pkc` by **at least 10%** in relative terms.

**Intra-run** comparison — two *metrics against each other inside one run*, not one run against
another. Needs only one run (`requires_comparison: false`). Base score `Concerning` (−1), filed
under the `stall-backend-pkc` key.

## Reasoning

This is the mirror of `Frontend-Dominated CPU Stalls`, and the two are mutually exclusive: the
rule that fires tells you which half of the CPU pipeline is the bottleneck, which determines the
entire remediation path.

`stall-backend-pkc` is "Cycle count that were stalled due to resource constraints in the
backend unit of the processor per thousand cycles. CPU backend is responsible for executing the
micro-operations decoded from instructions by the frontend, and producing memory side effects."
(`data-descriptions.ts`, `desired: "lower"`)

Backend dominance means instructions **were available but could not complete**. The CPU knew
exactly what to do and was waiting for something — almost always **data**. The causes, in
descending order of how often they turn out to be the answer:

1. `data-l1-mpki` / `l2-mpki` / `l3-mpki` — **cache misses escalating through the hierarchy**: an
   L1D miss costs tens of cycles from L2, an L2 miss more from L3, an L3 miss a DRAM access of
   hundreds.
2. `data-tlb-mpki` / `data-tlb-tw-pki` (plus the read/store splits `data-rd-tlb-*`,
   `data-st-tlb-*`) — **translation misses and page-table walks**: the *data* address translation
   is not cached, so the load waits on additional memory references.
3. **Insufficient memory-level parallelism** — dependent load chains serialize, because each
   load's address depends on the previous load's result, so the core cannot overlap them however
   many outstanding requests the hardware supports. Linked lists, trees and hash-probe chains are
   the classic shapes; this is aperf's "lacking resources to execute enough memory operations in
   parallel".
4. `strex-spec-pki` — **atomic and lock serialization**: under contention atomics stall the
   pipeline while cache lines bounce between cores, and STREX/LDREX pairs are far worse than LSE.
5. **DRAM bandwidth saturation** — once the working set streams from DRAM the ceiling caps
   everything, and on shared hosts co-tenants contribute (the warning on `High L3 Cache Misses`) —
   and finally **long-latency execution units**: divides, square roots, some SIMD.

The distinguishing feature of backend problems, and the reason they are harder to fix than frontend
ones, is that they are **properties of the data layout and access pattern** — algorithmic and
structural — rather than of the binary. Compiler flags rarely help; restructuring data does. Hence
`DATA_FOOTPRINT_OPTIMIZATION`: reuse data, store related data contiguously, access memory
sequentially, tile large loops.

**This rule compares two stall counts; it does not say stalling is high.** 20 backend vs 15
frontend `pkc` fires it, and so does 600 vs 400; the first is a healthy CPU, so reading the
absolute values is mandatory. The two counters also **overlap** — an out-of-order core hides some
latency on each side — so they are not a partition and need not sum to 1000.

## Reading the description

`time_series_stat_intra_run_comparison` emits — **both placeholders are metric names, not run names**:

```
The {stat} in {comparison_metric} ({value}) is {pct} {baseline_metric} ({base_value}).

The average in stall-backend-pkc (512.40) is 65.00% greater than stall-frontend-pkc (310.55).
```

**Five things that sentence does not tell you.**

1. **`pkc / 10` is percent-of-cycles, and that conversion is the whole severity story.** Both
   metrics count stalled cycles per *thousand* cycles, so `512.40` means the backend held **51.2%**
   of every cycle the CPU executed and `310.55` means the frontend held **31.1%**. Do this division
   first: it turns a number with no intuition attached into the fraction of the machine that
   produced nothing.
2. **The percentage is the ratio between them, not a magnitude.** `65.00% greater than` says
   backend/frontend ≈ 1.65 and nothing about whether either side is large. A run at 20 vs 12 pkc
   (2.0% and 1.2% of cycles — a healthy CPU) prints the same relation word as one at 600 vs 364
   (60% and 36% — a machine mostly waiting on memory). The percentage from
   `delta_ratio_to_percentage_string` is the **absolute** relative excess plus `"greater than"`,
   always, since the rule only fires on excess.
3. **Both placeholders are metric names.** Unlike every other comparison template's output,
   neither position holds a run name. A reader scanning for "which run" finds a metric and
   mis-attributes the finding to a cross-run comparison; it is intra-run and needs only one run.
4. **The averages come from the `Aggregate` series, which is a ratio of *summed* counters**
   (`src/data/perf_stat.rs:1118`–`:1148`) — stall cycles summed across CPUs over cycles summed
   across CPUs, divided once. That weights busy CPUs correctly and needs **no CPU-count
   correction**, but one thread pointer-chasing at 900 pkc while fifteen sit at 50 reads as
   comfortable. Read the per-CPU (`CPU{n}`) series first.
5. **Both numbers are truncated, not rounded** (`f64_to_fixed_2`,
   `src/computations/mod.rs:138`), so `512.40` is anything in `[512.40, 512.41)`.

Score math — `compute_finding_score(cur_ratio, 0.1, −1)` where
`cur_ratio = (backend − frontend) / frontend`, so the score is exactly `cur_ratio / 0.1 × −1`:

| backend excess | +10% | +65% | +100% | +300% |
|---|---|---|---|---|
| score | **−1.00** | **−6.50** | **−10.00** | **−30.00** |
| recovered `\|score\|/10` | 0.10 | 0.65 | 1.00 | 3.00 |

The score is a linear restatement of the ratio and inherits its blindness to magnitude entirely.

**Every other sentence this rule can produce**, including the two that are silences:

| Situation | What you get |
|---|---|
| `avg(stall-frontend-pkc)` is exactly `0.0` | the template substitutes `cur_ratio = 1.0` (`time_series_stat_intra_run_comparison_rule.rs:90`–`:92`) rather than dividing by zero: a **fixed score of −10.00** and text reading `100.00% greater than stall-frontend-pkc (0)`. For this `GreaterEqual` rule the substitution **always fires**. A frontend stall average of exactly zero is implausible on real hardware — read it as a collection problem, not a memory bottleneck |
| The two sides are within 10% of each other | **nothing.** The dead zone is exactly `fe/be ∈ (1/1.1, 1.1)`, verified by exhaustive sweep over 159,201 `(fe, be)` pairs: neither stall rule fires, however high *both* stalls are. A pipeline at 600/600 pkc — 60% of cycles lost on each side — produces no stall finding at all |
| Frontend dominates instead | `Frontend-Dominated CPU Stalls` fires and this one does not. The same sweep confirms **zero double-fires**: the two are mutually exclusive by construction |
| Either metric is absent | the rule returns early; no finding. On the generic `amd` PMU profile `stall-backend-pkc` **does not exist**, so both stall rules are structurally silent there |
| The profile is `genoa`, `icelake` or `spr` | the sentence is printed from **non-commensurable** values. Genoa understates the backend by `5.99×`, so this rule fires *less* readily than the hardware warrants there — the reverse of the frontend rule's bias |

## Interpretation

**Absolute magnitude first** — the finding is a ratio and hides this entirely. `pkc` is per thousand
cycles, so 1000 would be a fully stalled CPU: below **100** backend stalling is minor and the
finding is directional information only; **100–300** is moderate and worth pursuing only if IPC is
also low; **300–600** is a substantial bottleneck with real headroom; above **600** the CPU is
memory-bound and most cycles produce nothing.

Then cross-check `ipc`. High (> 2) with backend dominance means the pipeline is coping — low
priority. Low (< 1) is **the actionable case**: memory-bound, so pursue the data-footprint path.
Falling versus a base run, alongside `Reduced Instructions per Cycle`, means this finding localizes
that regression to the backend.

**Known false positives — check these before restructuring data:**

- **Both stall counts are low.** The dominant false positive: a 10% excess over a small number is
  not a bottleneck.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, both counters are
  extrapolated and — being separately scheduled — may come from *different* time slices, so the
  comparison's **direction** can invert. Metric-vs-metric comparisons are more exposed to this
  than single-metric findings. If `Underutilized CPU` fired instead, both counters are diluted
  with idle-loop behaviour, which has its own unrepresentative stall profile.
- **Backend dominance is the normal state for many workloads.** Databases, analytics, in-memory
  caches, graph traversal, and anything with a working set larger than L3 are legitimately
  memory-bound — and if the data *cannot* be made to fit, backend stalls are physics and the lever
  is instance choice (more cache, more memory bandwidth) rather than code. "Expected", not
  "un-improvable", but not a defect either.
- **A single memory-heavy phase.** A load/ETL/checkpoint phase inside an otherwise compute-bound
  run can flip the aggregate. Check the series over time.
- **NUMA effects, or a co-tenant.** Remote-node access raises latency with no change in cache
  behaviour — check `numastat` (`numa_miss`, `other_node`), which has **no analytical rules**. A
  neighbour saturating DRAM does the same and is hard to prove from inside the instance; high
  `l3-mpki` with an unchanged access pattern is the hint.

## Corroborating data

aperf's message says to "check the related misprediction metrics for data". Those are the five
metrics in `CPU_BACKEND_STALLS_INVESTIGATION`:

| Check | Data type | What it tells you |
|---|---|---|
| `data-l1-mpki`, `l2-mpki` | `perf_stat` | Working-set data spilling L1D, then escalating to L2. See `High L1 Data Cache Misses` (fires >20.0) and `High L2 Cache Misses` (>10.0) |
| `l3-mpki` | `perf_stat` | **The key severity indicator** — misses here go to DRAM and consume bandwidth. See `High L3 Cache Misses` (fires >10.0) |
| `data-tlb-mpki`, `data-tlb-tw-pki`; `data-rd-tlb-*`, `data-st-tlb-*` | `perf_stat` | Data-address translation misses and the page-table walks that are their expensive tail — both rules fire on *any* non-zero value. The read/store split shows whether loads or stores drive it; **no rules fire on those** — read manually |
| `strex-spec-pki` | `perf_stat` | Atomic serialization under contention. See `Old-Style Atomic Instructions` (arm64 only) |
| `stall-frontend-pkc`; `ipc`; `mux_counter_schedule_rate` | `perf_stat` | The other half of the comparison, read as an absolute value; the **severity gate** (backend dominance with healthy IPC is informational); and the **confidence gate** (below 100 ⇒ the two counters may not be comparable) |
| `numa_hit`, `numa_miss`, `numa_foreign`, `local_node`, `other_node` | `numastat` | Remote-memory latency. **No analytical rules — read manually** |
| `MemAvailable`, `Cached`, `AnonHugePages`, `HugePages_Total`; `CONFIG_TRANSPARENT_HUGEPAGE` | `meminfo`, `kernel_config` | Memory pressure and huge-page availability; THP directly reduces data-TLB pressure. See `Huge Page Disabled` |
| `pgminorfault`, `pgmajfault`, `pgfault`; `idle`, `aggregate` | `vmstat`, `cpu_utilization` | Allocation churn (minor) and disk-backed stalls (major), plus the idle-dilution check |
| On-CPU and allocation profiles | `perf_profile` / `java_profile` | Which code is stalling, and (Java, `--profile-java`) allocation-rate-driven cache pollution. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output; PageBlocks / SlabInfo | `hotline`, `memalloc` | **The most direct tool for this finding** — hotline attributes cache misses to specific instructions/addresses so prefetches can be placed (native code on metal Graviton only); memalloc shows fragmentation reducing huge-page availability. **No analytical rules for either** |

## Guidance

Ordered. Steps 1–2 decide whether this is worth pursuing; most firings are directional information.

1. **Read the two absolute stall values, then gate on measurement confidence.** If
   `avg(stall-backend-pkc)` is low (roughly < 100 pkc), state that the pipeline is not stall-bound
   and that this finding only says which side is marginally larger — stop there. Otherwise check
   `mux_counter_schedule_rate` (`PMU Counter Collection Multiplexing`) and `avg(idle)`
   (`Underutilized CPU`): multiplexing is especially corrosive for a metric-vs-metric comparison,
   because a low schedule rate can flip which side appears dominant.

2. **Cross-check `ipc` for severity.** Low IPC + backend dominance = the confirmed, actionable
   case. Healthy IPC = note and move on. If `Reduced Instructions per Cycle` also fired, state
   that this finding localizes that regression to the backend.

3. **Walk the cache hierarchy outward — this is the highest-value step.** Read `data-l1-mpki`,
   then `l2-mpki`, then `l3-mpki`, and find where the escalation stops. High L1D misses with
   L2/L3 low is a **spatial locality** problem — the data is nearby but not packed, so the levers
   are struct layout, AoS vs SoA, and cache-line padding. Escalation to L2 means the working set
   exceeds L1 substantially: loop tiling and blocking. Escalation to **L3** means going to DRAM,
   the expensive case — bandwidth is involved, co-tenant contention becomes possible, and latency
   is hundreds of cycles, so reducing total footprint is the lever rather than reordering it. Read
   **translation separately**: non-zero `data-tlb-mpki` / `data-tlb-tw-pki` means translation is
   adding memory references on top of the data access, a distinct and often cheap fix (huge pages)
   independent of the cache work; the read/store split (`data-rd-tlb-*` vs `data-st-tlb-*`) says
   whether loads or stores drive it.

4. **Rule out serialization rather than capacity.** Elevated `strex-spec-pki`, or a known
   lock-heavy workload, means the stalls may be contention rather than footprint — a completely
   different fix (LSE, lock granularity, sharding); see `Old-Style Atomic Instructions`. Then
   **check the timeline and NUMA placement**: plot both stall series to make sure a single
   memory-heavy phase is not flipping the aggregate, and on large instances check `numastat` for
   remote-node access, which raises latency without changing cache behaviour.

5. **Attribute to code and address, then remediate** per `DATA_FOOTPRINT_OPTIMIZATION` and
   `TLB_MISS_OPTIMIZATION`. With `--profile`, find the stalling stacks; for native code on metal
   Graviton, `hotline` localizes misses precisely enough to insert prefetches. Then: reuse the same
   data (temporal locality); store related data contiguously (array list over linked list); access
   memory sequentially, iterating 2-D arrays row-by-row; tile large loops; insert prefetches at
   hotline-identified sites; enable THP/folios/reserved huge pages for the TLB component. If the
   working set genuinely cannot shrink, an instance with more cache and memory bandwidth is the
   remaining lever.

6. **Quantify the split, and correct it if the profile requires it.**
   `tools/aperf_perf_stat.py --stalls --frontend-pkc F --backend-pkc B --profile P` does the
   percent-of-cycles conversion, states the verdict, and applies the per-profile normalisation:

   ```
   $ python3 tools/aperf_perf_stat.py --stalls --frontend-pkc 310.55 --backend-pkc 512.40 --profile grv
   Frontend stalls consume 31.1% of cycles and backend stalls 51.2% (310.55 and 512.40 per
   thousand cycles) on graviton (<=4). Backend/frontend is 0.65, so Backend-Dominated CPU
   Stalls fires: the backend is the bottleneck and holds 51.2% of all cycles.
   ```

   On `genoa` the correction runs in **this rule's favour**: a raw reading of 310.55 fe / 85.20 be
   prints as *frontend*-dominated, but the corrected backend is **510.18 pkc (51.0% of cycles)**
   and the verdict flips to backend. Never accept a frontend verdict there without running this.

## Priority and execution risk

**Priority: P3 — Monitor** by default — a ≥10% excess over a small frontend number is arithmetic,
not a bottleneck. It rises to **P2 — Investigate** once `avg(stall-backend-pkc)` is above roughly
300 pkc (30% of cycles), and to **P1 — Act now** when that holds *and* `ipc` is low *and* the
escalation reaches **L3**, where every miss is a DRAM round-trip costing hundreds of cycles. It
drops to **P4 — Informational** for workloads memory-bound by nature (databases, analytics, graph
traversal, in-memory caches): expected is not the same as un-improvable, but it is also not a
defect. It stays at **P3** whenever the run multiplexed, because the two counters may have been
scheduled in different slices and the *direction* can invert, and is **P2 at most** when
`strex-spec-pki` is also elevated, because the finding may be serialization rather than footprint
and the two have unrelated fixes.

**Execution risk: R0 — Read-only** to diagnose: the split, the hierarchy walk, the TLB read/store
split, `numastat`, and the per-profile correction are all reads. Acting on the outcome is
**R5 — Restructure** for the dominant remediation, because data layout changes (AoS→SoA, array list
over linked list, loop tiling) are invasive source changes with correctness risk; **R3 — Rebuild**
for prefetch insertion or `-moutline-atomics`; **R4** for huge pages, NUMA pinning, or an instance
with more cache and memory bandwidth. **Do not inherit the R0 of the hierarchy walk into the
restructure:** rewriting a hot data structure is the highest-risk remediation in this playbook set,
and its verification is a re-record plus a correctness suite, not a re-read.

**The score is amplified, restates the ratio, and is blind to severity.** It is exactly
`cur_ratio / 0.1 × −1`, so `cur_ratio = |score| / 10` — and because `cur_ratio` is a *ratio
between two stall counts*, it is insensitive to how much stalling occurred: a healthy CPU at
**20 vs 12 pkc** scores `−6.67` while a severely memory-bound one at **600 vs 580 pkc** scores
`−0.34`, twenty times milder. `Concerning` (−1) also puts every firing 16× below
`Old-Style Atomic Instructions` and `Reduced Instructions per Cycle` in the panel regardless of
value. **Rank on `pkc/10`, never on score** — and recognize **exactly `−10.00`** as possibly the
zero-frontend substitution rather than a real 100% excess.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: within one run, `avg(stall-backend-pkc)` exceeded `avg(stall-frontend-pkc)` by
at least 10% relative (`GreaterEqual 0.1` on `(be − fe) / fe`, so exactly +10% does fire).

```
STEP 0 — Does the perf_stat data exist, and can this rule fire on this profile?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU (P3, R0)
  IF the run is on the generic `amd` PMU profile
  THEN → `stall-backend-pkc` does not exist there, so BOTH stall rules are structurally
         silent. COULD NOT FIRE — use the *-mpki family (P3, R0)
  IF the profile is `genoa`, `icelake` or `spr`
  THEN → the metrics are NOT commensurable and the bias runs AGAINST this rule: the backend
         is understated, so dominance is UNDER-reported and a frontend verdict may be a
         corrected backend one — see the architecture section, and the full branches: run
         `tools/aperf_perf_stat.py --stalls --profile <p>`

STEP 1 — Convert to percent-of-cycles FIRST; it decides whether anything below matters.
         Parse: The {stat} in {comparison_metric} ({value}) is {pct} {baseline_metric}
         ({base_value}) — both placeholders are METRIC names. pkc / 10 = percent of all
         cycles; recover the ratio as |score| / 10.
  IF avg(stall-backend-pkc) < 100 pkc (under 10% of cycles)
  THEN → NOT a bottleneck: which side is marginally larger on a pipeline barely stalling.
         Report and STOP — no restructuring discussion (P4, R0)
  IF 100-300 pkc
  THEN → moderate. Worth pursuing only if `ipc` is also low; see STEP 3 (P3, R0)
  IF 300-600 pkc
  THEN → substantial backend bottleneck with real headroom; continue (P2, R0)
  IF > 600 pkc
  THEN → severe: the CPU is memory-bound and most cycles produce nothing (P1, R0)
  IF the score is exactly -10.00
  THEN → suspect the zero-frontend substitution (time_series_stat_intra_run_comparison_rule.rs:90):
         avg(stall-frontend-pkc) was 0.0 and the ratio was hardcoded to 1.0, which a literal
         `(0)` base_value in the text confirms (P3, R0)
       → verify: a frontend average of exactly zero is implausible on real hardware. Check
         `mux_counter_schedule_rate` and whether the counter was collected at all; treat as
         a collection defect, not a backend finding

STEP 2 — Gate on confidence. Multiplexing is more corrosive here than to single-metric rules.
  IF `mux_counter_schedule_rate` < 100
  THEN → the counters are separately scheduled, so they may come from DIFFERENT time
         slices and the direction can invert. Report low-confidence rather than acting;
         `--mux --rate R` gives the factor (25% ⇒ 4.00x) (P3, R0)
       → verify: re-record with `--ungroup-pmu-events` or a smaller `--pmu-config`; if the
         direction FLIPS, the original split was noise
  IF `Underutilized CPU` fired
  THEN → both counters are diluted with idle-loop behaviour, which has its own
         unrepresentative stall profile (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; the split should
         sharpen, and a direction change means the idle loop drove it

STEP 3 — Cross-check `ipc` to establish whether the imbalance costs anything.
  IF `ipc` > 2 with backend dominance
  THEN → the core absorbs it via memory-level parallelism. Note it (P4, R0)
  IF `ipc` < 1 with backend dominance
  THEN → the ACTIONABLE case: the machine is memory-bound. Continue (P1, R0)
  IF `Reduced Instructions per Cycle` also fired
  THEN → this finding LOCALIZES that regression — say so explicitly; they are one finding
         reported twice. The IPC rule needs two runs and this one needs one, so this stays
         readable when that comparison is void (P1, R0)

STEP 4 — Walk the cache hierarchy OUTWARD and find where the escalation stops. This is where
         the cost per miss is decided.
  IF `data-l1-mpki` > 20 but `l2-mpki` and `l3-mpki` are low
  THEN → SPATIAL LOCALITY: the data is nearby but not packed. Struct layout, AoS vs SoA,
         cache-line padding, false sharing (P2, R5)
       → verify: data-l1-mpki falls AND stall-backend-pkc falls in absolute pkc. If L1 misses
         fall and the stall does not, capacity was not the driver
  IF `l2-mpki` > 10 but `l3-mpki` stays low
  THEN → the working set exceeds L1 substantially but still fits L3. Loop tiling and blocking
         are the levers; total footprint need not shrink (P2, R5)
       → verify: l2-mpki falls with stall-backend-pkc; the right tile size is where l2-mpki
         stops falling
  IF `l3-mpki` > 10
  THEN → misses are going to DRAM: hundreds of cycles apiece, bandwidth is involved, and a
         co-tenant can worsen it with no change of yours. Reducing TOTAL footprint is the
         lever, not reordering it (P1, R5)
       → verify: l3-mpki falls AND stall-backend-pkc falls. Flat l3-mpki across two runs of
         the same code means co-tenant contention, an instance-placement question (R4)
  IF `data-tlb-mpki` or `data-tlb-tw-pki` is non-zero
  THEN → translation is adding memory references ON TOP of the data access. Distinct, often
         cheap fix: huge pages. These rules fire on ANY non-zero value, so read the magnitude
         first, and the read/store split (`data-rd-tlb-*` vs `data-st-tlb-*`, on which NO rule
         fires) (P2, R4)
       → verify: `CONFIG_TRANSPARENT_HUGEPAGE` enabled and data-tlb-tw-pki drops toward zero
         afterwards — the walks are the expensive tail
  IF NONE of the cache levels stands out
  THEN → not capacity misses. Go to STEP 5 first (P3, R0)

STEP 5 — Rule out SERIALIZATION rather than capacity. Most often skipped, and it has a
         completely different fix.
  IF `strex-spec-pki` >= 10 (`Old-Style Atomic Instructions`, arm64 only)
  THEN → LL/SC atomic retry scaffolding is stalling the pipeline, and it grows SUPERLINEARLY
         with thread count. Rebuild with `-moutline-atomics` or `-march=armv8.2-a` for LSE
         (P1, R3). `--strex --pki N`: at 5.00 pki, 0.50% of the stream is retry scaffolding
       → verify: strex-spec-pki falls toward zero AND stall-backend-pkc falls. The metric is
         SPECULATIVE, counting failed retries, so a fall here is a fall in contention rather
         than in atomic count
  IF the workload is known lock-heavy but `strex-spec-pki` is absent or zero
  THEN → on x86 the metric does not exist, so this branch is UNREADABLE from aperf data;
         contention must come from the profile or lock instrumentation (P2, R0)
       → verify: `--profile` stacks concentrated in a locking primitive; a sharding or
         granularity change then lowers stall-backend-pkc
  IF neither capacity nor serialization explains it
  THEN → suspect long-latency units (divides, roots, some SIMD) or DRAM bandwidth
         saturation; neither has a dedicated aperf metric (P3, R0)
       → verify: the on-CPU profile concentrates in arithmetic-heavy code and the stall
         persists with a smaller working set, ruling out footprint

STEP 6 — Check the timeline and memory placement.
  IF backend dominance is confined to one PHASE of the run
  THEN → a load, ETL, or checkpoint phase is flipping the aggregate; the steady state is
         something else (P3, R0)
       → verify: re-report with `--time-range` scoped to steady state. If the finding
         disappears, the phase was the finding
  IF `numastat` shows significant `numa_miss` / `other_node`
  THEN → remote-node access raises latency with NO change in cache behaviour, so the walk above
         looks clean. numastat has NO analytical rules (P2, R4)
       → verify: pin with `numactl --cpunodebind --membind`, or first-touch per thread;
         other_node falls and stall-backend-pkc falls
  IF only a few CPU{n} series show it
  THEN → one or two threads, not the instance; the Aggregate ratio of sums hid it. Correlate
         with the on-CPU profile to name the thread, and expect a fix targeted at it to move
         the aggregate little (P3, R0)

STEP 7 — MANDATORY: which addresses and which code? Needs `--profile` (and `hotline` for
         native code on metal Graviton).
  IF `hotline` data exists
  THEN → the intended tool for THIS finding: it attributes misses to specific instructions and
         addresses, which is what makes prefetch insertion possible rather than speculative
         (P2, R3)
       → verify: prefetches at hotline-identified sites; data-l1-mpki or l3-mpki falls there
         and stall-backend-pkc falls with it
  IF only `--profile` stacks exist
  THEN → you can name the stalling FUNCTION but not the stalling ADDRESS — enough for a
         layout change, not for prefetch placement (P2, R5)
       → verify: the restructured structure shows lower mpki at the same call sites
  IF neither exists
  THEN → STOP. Any data-restructuring recommendation from here is speculative; the honest
         deliverable is a re-record with `--profile` (P2, R0)

STEP 8 — What survives?
  VALID      : the two absolute pkc values, the hierarchy mpki values read as magnitudes,
              and every non-PMU finding in the run
  CAUTION    : the DIRECTION of this finding when the run multiplexed, and on
              `genoa`/`icelake`/`spr` where the metrics are not commensurable
  CONFOUNDED : the split on an idle-diluted run; any steady-state claim from a window
              containing a distinct memory-heavy phase; and `l3-mpki` on a shared host, where
              a co-tenant contributes to the same number
  VOID       : any claim that stalling is HIGH on this finding alone — it is a ratio; and any
              cross-architecture reading of the split, since the backend metric is redefined
              per profile

INSUFFICIENT DATA
  IF NEITHER stall finding fired
  THEN → the two sides are within 10% (dead zone fe/be in (1/1.1, 1.1)). NOT evidence of a
         healthy pipeline: 600 pkc on both sides is 60% of cycles lost on each and fires
         nothing. Read both absolutes and `ipc` directly; the top-down method gives no
         direction here (P2, R0)
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. The average is readable but no percentile is: p90 and above
         are all the same single sample (P3, R0)
```

## Runtime-specific consequences

Backend stalls are a property of the *data* and how it is laid out, so the runtime matters through
its **allocator and object model** rather than through code generation — and for three of the four
runtimes the layout you would optimize is chosen by the runtime, not by your source.

| Runtime | Why the backend stalls, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **.NET** | GC compaction is a *help* here — the heap is defragmented, so allocation-adjacent objects are cache-adjacent. The problem is object-graph pointer chasing: every reference is an indirection, so a `List<T>` of reference types is a pointer array, not contiguous data | `DOTNET_gcServer` (per-core heaps, so per-thread locality), and whether hot types can become `struct` / `Span<T>` so the data is inline. Value types are the axis; compiler flags are not |
| **Python** | Every object is a heap box with a refcount header, so a list of ints is a pointer array and iterating it is pointer chasing by construction — **structurally** backend-bound, not a defect. Refcount writes also dirty cache lines on *read*-only traversals | Whether the hot data can move into NumPy arrays or a native extension, where it becomes contiguous. This is the one runtime where the fix is almost always "move the data out of Python objects" |
| **Java** | The largest real case. Object headers plus reference fields mean an array of objects is an array of pointers; GC then moves those objects, so locality changes over the run. The generational nursery is cache-friendly, tenured traversal is not | `jvmArguments` for GC choice — G1 vs Parallel changes compaction and therefore locality — plus `-XX:+UseCompressedOops` (smaller headers, more objects per line) and `-XX:+UseTransparentHugePages`. Check `java_profile` allocation profiles for churn that pollutes cache |
| **Perl** | Every value is an `SV` reached by pointer, and the op tree is itself a pointer structure walked per statement — so Perl is usually **backend**-bound, in contrast to the frontend playbook's mirror case. That is normal for Perl, not a finding | Whether hot loops can be pushed into XS or a C library. There is no GC-layout flag to tune, which makes the instance-level lever (more cache) relatively more attractive here |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is
inferred from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot
be identified, stop at STEP 7's profile check: "which addresses" is runtime-independent and is what
actually gates prefetching. For **all four**, a managed heap means the *allocator* decides
locality, so the honest first move is a GC/allocator setting, not a source rewrite.

## Architecture-specific considerations

This finding fires on **7 of 8** PMU profiles — registry `architectures`: `arm64`,
`arm64_graviton5`, `intel`, `intel_icelake`, `intel_sapphire_rapids`, `amd_milan`, `amd_genoa`. The
registry's `architecture_note` states both problems exactly: *"Generic AMD has no
`stall-backend-pkc`, which silences both stall rules. Normalisation differs on `intel_icelake`,
`intel_sapphire_rapids` (Slots) and `amd_genoa` (*167)."*

**This rule is filed under the non-portable metric.** `stall-frontend-pkc` — the *baseline* here —
is `Frontend_Stalls / Cycles * 1000` on every profile that has it, but `stall-backend-pkc`, the
metric this finding is named for, is redefined per profile. The bias therefore runs **against**
this rule wherever the backend is understated:

| Profile | `stall-backend-pkc` definition | Consequence for this finding |
|---|---|---|
| `grv`, `grv5`, `intel`, `milan` | `Backend_Stalls / Cycles * 1000` (milan sums two counters) | commensurable with the frontend metric; the ratio is meaningful as printed |
| `icelake`, `spr` | `Backend_Stalls / Slots * 1000` | per-**issue-slot**, not per-cycle, so backend dominance is understated by roughly the machine width — 5 on Ice Lake, 6 on Sapphire Rapids. This rule fires **less** readily than the hardware warrants, and the quantifier deliberately **refuses to invent** the width, reporting the pair as incommensurable instead |
| `genoa` | `Backend_Stalls / Cycles * 167` | the backend is understated by exactly `1000/167 = 5.99×`. A raw reading of 310.55 fe / 85.20 be prints as *frontend*-dominated; corrected, backend is **510.18 pkc (51.0% of cycles)** and this finding is the correct one |
| `amd` (generic) | **absent** | neither stall rule can fire. The silence is structural and says nothing about the pipeline |

The asymmetry is worth stating plainly: on `genoa`, `icelake` and `spr`, **a missing
`Backend-Dominated CPU Stalls` finding is weak evidence of anything**, because the metric that
would trigger it is scaled down. Run `tools/aperf_perf_stat.py --stalls --frontend-pkc F
--backend-pkc B --profile <p>` on every frontend verdict from those profiles before accepting it.

**The backend causes are not equally available either.** `strex-spec-pki` exists **only** on
`arm64` and `arm64_graviton5` (`grv_pmu_config.json`, `STREX_SPEC` event `0x6f`), so STEP 5's
serialization branch is structurally unreadable on x86 — its absence there is not evidence that
atomics are efficient. `l3-mpki` also changes meaning by host: on a shared instance the counter
includes co-tenant DRAM pressure, which no aperf metric separates. Compounding this, aperf has no
architecture field and no rule compares `Instance Type` ([../GATES.md](../GATES.md) §"The two
gaps"): an Intel→Graviton comparison with matched `CPUs` and `MemTotal` fires **no gate**, yet
cache sizes, DRAM channels and the backend metric's own definition all changed, so "backend stalls
improved" across that pair is not a measurement.

**Counter mode changes whether this rule is trustworthy at all.** Grouped is the default
(`src/data_collection.rs:379`) and creates one counter per event *per metric group*
(`src/data/perf_stat.rs:217`–`:221`), roughly doubling register pressure versus
`--ungroup-pmu-events`; `probe_pmu_counter_limit` (`:344`) binary-searches the limit, bounded to
16. Because the two stall counters are separately scheduled, a low schedule rate can invert this
comparison specifically ([../ARCHITECTURE.md](../ARCHITECTURE.md) §3.4). And the highest-leverage
remediation is invisible to every aperf metric: an instance family with more L3 per core or more
DRAM channels changes this finding with no code change — **R4**, reachable only via STEP 4
establishing that the escalation reaches L3.

## Verification

Apply the fix STEP 4 or STEP 5 localized, re-record at the **same geometry, same counter mode, and
same instance type**, and check the pair rather than either number alone: the cause metric should
fall (`data-l1-mpki`, `l2-mpki`, `l3-mpki`, `data-tlb-tw-pki`, or `strex-spec-pki`) **and**
`avg(stall-backend-pkc)` should fall with it in absolute pkc. If the cause metric falls and the
stall does not, that cause was not driving the stall and the remaining branches are still open —
the common outcome when a layout change fixes L1 while the real cost was at L3. If
`stall-backend-pkc` falls but the finding *persists*, the frontend fell too and the ratio survived:
a shrinking bottleneck can keep firing a ratio rule indefinitely. The finding disappearing while
both values stay high means the pipeline entered the dead zone, which is not an improvement. This
finding **cannot be verified by score** — a healthier machine can score worse. And because the
dominant remediation is **R5**, verification must include a correctness suite, not only a re-record:
a data-layout rewrite that lowers `l3-mpki` and changes results is not a win.

## Do not

- **Do not treat this as evidence that stalling is high**, and **do not skip the `pkc / 10`
  conversion.** It is a *ratio between two stall counts*, both of which can be small; the division
  is the only step that turns it into a severity. `512.40 pkc` is 51% of every cycle executed and
  `20 pkc` is 2% — the rule reports both identically.
- **Do not rank this finding by score.** The score is the ratio restated, so a healthy machine at
  20 vs 12 pkc scores `−6.67` while a severely memory-bound one at 600 vs 580 scores `−0.34` —
  twenty times milder. And `Concerning` (−1) puts every firing 16× below the `Poor` findings
  regardless of value. `−10.00` exactly may be the zero-frontend substitution.
- **Do not confuse this with a run-to-run comparison**, and **do not act on it when
  `mux_counter_schedule_rate` is well below 100.** It is intra-run: both placeholders are metric
  names, no base run is involved, one run suffices — and the two metrics need not **sum to 1000**,
  because out-of-order execution overlaps the two stall kinds. Because the counters are separately
  scheduled, multiplexing can invert the *direction*, not just blur magnitude.
- **Do not accept a *frontend* verdict on `genoa`, `icelake`, or `spr` without correcting it.**
  There the backend metric is scaled down — by exactly `5.99×` on genoa, by the machine width on
  Ice Lake and Sapphire Rapids — so this finding is **under**-reported and its absence is weak
  evidence: a raw 310.55 fe / 85.20 be on genoa is really 51.0% backend. And **do not expect this
  finding at all on generic `amd`**, where `stall-backend-pkc` does not exist.
- **Do not jump to "add more cache" or restructure data before walking the hierarchy**, and **do
  not assume it is a footprint problem at all.** An L1-only problem is a layout fix while an
  L3/DRAM one is a total-footprint or instance fix — not interchangeable, and the second is far
  more expensive. Lock contention and atomic serialization also present identically here: check
  `strex-spec-pki`, **arm64 only**, so on x86 STEP 5 is unreadable rather than negative.
- **Do not read a clean hierarchy walk as "no memory problem".** NUMA remote access and DRAM
  bandwidth saturation both raise backend stalls with cache counters looking normal, and `numastat`
  has **no analytical rules**. Likewise **do not attribute `l3-mpki` on a shared host entirely to
  your workload** — a co-tenant's DRAM pressure lands in the same counter. And **do not recommend
  prefetch insertion without `hotline` data**, the only source of the stalling *address*, or
  **inherit the R0 of the diagnosis into an R5 restructure** — rewriting a hot data structure is
  the riskiest remediation here and needs a correctness suite.
- **Do not conclude a balanced pipeline is healthy**, and **do not read the Aggregate ratio as
  characteristic of every CPU.** The dead zone is `fe/be ∈ (1/1.1, 1.1)`, so 600 pkc on both sides
  is 60% of cycles lost on each and fires nothing; and the Aggregate is a ratio of *summed*
  counters, so one thread at 900 pkc among fifteen at 50 reads as comfortable.
- **Do not treat backend dominance as a defect for memory-bound workloads.** Databases, analytics,
  graph traversal and in-memory caches live here by nature, as do Python and Java object graphs.
  Expected is not un-improvable, but it is not a bug either.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:40` — `metric: "stall-backend-pkc"`,
  baseline `stall-frontend-pkc`, `stat: Stat::Average`, `comparator: Comparator::GreaterEqual`,
  `threshold: 0.1`, `score: Score::Concerning`. Single-run: `requires_comparison` is false, so it
  is readable even when every cross-run comparison in the report is void.
- Rule template: `src/analytics/rule_templates/time_series_stat_intra_run_comparison_rule.rs` —
  calls `compute_finding_score`, so **this rule's score is amplified**. The zero-baseline
  substitution at `:90`–`:92` hardcodes `cur_ratio = 1.0`, which for a `GreaterEqual 0.1` rule
  **always fires**, at a fixed `−10.00`. Both description placeholders are metric names, unlike
  the cross-run template. Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`,
  over `Score::Concerning = −1` (`:147`–`:157`); recover `cur_ratio = |score| / 10`.
- Aggregate is a **ratio of sums**: `src/data/perf_stat.rs:1118`–`:1148` sums stall cycles and
  cycles across CPUs and divides once — correct for a ratio, so **no CPU-count correction
  applies**, but per-CPU outliers are invisible. `stats_series_idx`
  (`src/data/common/time_series_data_processor.rs:312`–`:342`) selects `Aggregate`
  (`utils.rs:241`); per-CPU series are `CPU{n}` (`utils.rs:237`). Both printed values are
  **truncated**, not rounded (`f64_to_fixed_2`, `src/computations/mod.rs:138`).
- Per-profile metric definitions: `src/pmu_configs/*.json`, merged as **overlays** onto the
  default by `extend_from_default` (`src/data/perf_stat.rs:200`–`:205`), selected at `:765`–`:790`.
  `stall-backend-pkc` is `/Cycles*1000` (grv, grv5, intel, and milan as a sum of two counters),
  `/Slots*1000` (icelake, spr), `/Cycles*167` (genoa), and **absent** from generic amd;
  `stall-frontend-pkc` is `Frontend_Stalls / Cycles * 1000` everywhere it exists.
  `strex-spec-pki` is defined **only** in `grv_pmu_config.json` (`STREX_SPEC`, event `0x6f`).
- Multiplexing compensation: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`,
  so a schedule rate of R% is an extrapolation factor of `100/R`. Grouped is the default
  (`src/data_collection.rs:379`), duplicates events per metric group (`perf_stat.rs:217`–`:221`),
  and the limit is probed at `:344`.
- Quantifier: [`../tools/aperf_perf_stat.py`](../tools/aperf_perf_stat.py) `--stalls` — does the
  percent-of-cycles conversion, applies the genoa correction, and refuses to invent the Slots
  width on icelake/spr; `--strex` sizes the serialization branch and `--profiles` prints the
  8-profile matrix. `tools/test_aperf_perf_stat.py` pins all of it, including the exhaustive
  sweep over `fe, be ∈ [1, 400)` — 159,201 pairs, **zero double-fires**, and no finding whenever
  `fe/be ∈ (1/1.1, 1.1)`. Upstream guides in
  `src/report_frontend/src/definitions/optimization-guides.ts`:
  `CPU_BACKEND_STALLS_INVESTIGATION`, `DATA_FOOTPRINT_OPTIMIZATION`, `TLB_MISS_OPTIMIZATION`.
- Related playbooks: `frontend-dominated-cpu-stalls.md` (the mutually exclusive mirror),
  `reduced-instructions-per-cycle.md` (the step above in the top-down method),
  `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `old-style-atomic-instructions.md` (STEP 5), `high-l1-data-cache-misses.md`,
  `high-l2-cache-misses.md`, `high-l3-cache-misses.md`, `data-tlb-misses.md`,
  `data-tlb-table-walks.md`, `../cpu_utilization/underutilized-cpu.md`,
  `../kernel_config/huge-page-disabled.md`. Cross-cutting:
  [../GATES.md](../GATES.md) (precedence, and the missing architecture gate),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) (P/R vocabulary, runtime inference),
  [../ARCHITECTURE.md](../ARCHITECTURE.md) (the 8 PMU profiles, counter mode).
- Graviton perfrunbook, the pages this tree follows in order —
  [top-down method](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#top-down-method-to-debug-hardware-performance),
  [drill down back-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-back-end-stalls),
  then [optimizing for large data footprint](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html#optimizing-for-large-data-footprint)
  — and [Arm Neoverse N3 — backend stalled cycles metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/Cycle-Accounting-metrics-for-Neoverse-N3?lang=en#md523-cycle_accounting_mg__backend_stalled_cycles_m_Cycle_Accounting)
