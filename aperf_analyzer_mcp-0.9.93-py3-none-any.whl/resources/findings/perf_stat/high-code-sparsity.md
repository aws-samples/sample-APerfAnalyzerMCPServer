---
rule_name: High Code Sparsity
data_type: perf_stat
data_key: code-sparsity
template: time_series_data_point_threshold
condition: "any(code-sparsity) > 0.5"
base_score: Bad
score_sign: negative
requires_comparison: false
aperf_message: "The code being executed by the CPU is not compact enough and could increase branch mispredictions. Check the related compiler flags."
source: src/analytics/rules/perf_stat.rs:84
---

# High Code Sparsity

## What fired

**At least one** data point of `code-sparsity` was **greater than 0.5**, in **any** series including
per-CPU. A single sample anywhere in the recording is enough. Base score `Bad` (−2) — twice the magnitude of
the `Concerning` (−1) used by most of the `perf_stat` family, reflecting that sparsity is a *root cause*
rather than a symptom. Single-run rule.

## The collection gap — this rule exists on 2 of 8 PMU profiles, and cannot fire on the other 6

`code-sparsity` is defined in exactly one file: `src/pmu_configs/grv_pmu_config.json`, as
`Code_Sparsity / Instructions * 1000` with `Code_Sparsity` = `armv8_pmuv3_0/event=0x11c/`. `grv_5` inherits
it through `extend_from_default`. **No Intel or AMD config defines it**, so on the six x86 profiles the
metric does not exist and the rule is structurally silent:

```
rule_can_fire('High Code Sparsity', 'grv')   → True      rule_can_fire(…, 'intel')    → False
rule_can_fire('High Code Sparsity', 'grv5')  → True      rule_can_fire(…, 'icelake')  → False
                                                          rule_can_fire(…, 'spr')      → False
                                                          rule_can_fire(…, 'amd')      → False
```

**The absence of this finding on an x86 run proves nothing about code layout.** That is the single most
important sentence in this playbook, because it is exactly the inference a reader will otherwise make: the
frontend symptom findings *are* present on x86 (`inst-l1-mpki`, `branch-mpki`, `inst-tlb-mpki` and
`inst-tlb-tw-pki` all exist on all eight profiles), so a report can show every symptom of scattered code
with the root-cause metric silently missing. `High L1 Instruction Cache Misses` documents the same gap from
the other side: its layout-vs-capacity discriminator is *this metric*, and on x86 it has none.

**A second, smaller gap: aperf documents nothing about what `0x11c` counts.** Grepping the upstream tree for
`0x11c` and `sparsity` returns four hits — the config line, the rule at `perf_stat.rs:84`–`:89`, the
display-order list at `:978`, and the `data-descriptions.ts` entry, which calls sparsity "a measure of how
compact the instruction code is packed" — a statement about the *intent*, not the counter. What the
arithmetic does settle is the **units**: the expression divides by `Instructions` and multiplies by 1000, so
this is a **per-thousand-instruction rate** like the four `mpki` metrics, not a dimensionless "fraction of
the binary that is cold", which is what the word *sparsity* invites. `0.5` is one counted event per 2000
instructions; `2.0` is one per 500 — a far tighter threshold in relative terms than the L1 thresholds of
20.0 look, consistent with the rule carrying `Bad` (−2) rather than `Concerning`.

**What is *not* defective:** the threshold is non-zero, `compute_finding_score` is monotonic and the
template reports the **series peak** — verified, `--select 0.6 0.3 2.0 0.9 --threshold 0.5 --rule-score -2`
selects `2.0`. Unlike the four zero-threshold TLB rules, the value in the description is the maximum. And
because both defining profiles resolve to the same event, `cross_architecture_comparable('code-sparsity',
'grv', 'grv5')` is **True** — the only comparison this metric supports, and the only one it needs.

## Reasoning

`code-sparsity` is "a measure of how compact the instruction code is packed and how closely related code is
placed. Lower sparsity helps branch prediction and the cache subsystem." (`data-descriptions.ts`,
`desired: "lower"`)

This is the most **causally upstream** metric in the frontend family, and that is why it deserves attention
out of proportion to its small score. Where `branch-mpki`, `inst-l1-mpki`, `inst-tlb-mpki` and
`inst-tlb-tw-pki` each measure a *symptom* of a badly-organized instruction stream, `code-sparsity`
measures the organization itself.

The mechanism is **granularity of transfer versus granularity of use**. The CPU does not fetch instructions
individually. It fetches a **64-byte cache line** at a time into L1I, covered by a **page-sized** (typically
4 KB) TLB entry, and predicts branches using tables indexed by instruction address. If the instructions
actually executed are densely packed, every fetched line is almost entirely useful, few pages are touched,
and branch history is concentrated in a small address range. If they are scattered — hot code interleaved
with cold, hot functions far apart in the binary, a hot loop spread across several pages — then:

- each 64-byte fetch delivers mostly bytes that will never execute ⇒ **L1I capacity is wasted**, driving
  `inst-l1-mpki`;
- the hot working set spans many pages ⇒ **ITLB coverage is exceeded**, driving `inst-tlb-mpki` and
  `inst-tlb-tw-pki`;
- branch history is spread thinly across a large address space ⇒ **predictor tables thrash**, driving
  `branch-mpki`.

**One layout fix improves all four.** That is the practical significance of this finding and the reason to
check it early: it converts four apparently separate problems into one.

Sparsity is a property of the **binary and its layout**, produced by:

| Cause | Signature | Lever |
|---|---|---|
| **Compiler/linker ordering** — functions emitted in source or arbitrary order rather than by execution temperature, so hot and cold code interleave | Sustained elevation in a native binary built without PGO | Profile-guided layout (AutoFDO). The decisive fix |
| **Cold paths inline with hot paths** — every `if (unlikely(err))` block between two hot instructions consumes line and page space | Sustained; often with elevated `branch-mpki` | Hot/cold splitting, `__builtin_expect`, `[[unlikely]]` |
| **Aggressive inlining and templating** — bloats and disperses hot paths | Large text section; `inst-l1-mpki` also high | Reduce inlining; `-Os`, `-flto` |
| **Dynamic linking / PLT indirection** — calls jump across mapping boundaries | Elevated with high `inst-tlb-mpki` | Static linking or `-Bsymbolic` where viable |
| **JIT-generated code** — methods allocated wherever the code cache has room, with no locality guarantee; recompilation scatters them further | **Recurring** bursts through the run | Code-cache sizing. Compiler flags do not apply |

The fix is therefore **profile-guided layout**: tell the compiler which paths are hot so it can place them
contiguously and move cold code out of line. That is exactly what `INSTRUCTION_FOOTPRINT_OPTIMIZATION`
prescribes (`-flto`, `-Os`, [AutoFDO](https://gcc.gnu.org/wiki/AutoFDO/Tutorial)), and aperf's own message
points at it: "Check the related compiler flags."

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 0.80 (greater than the threshold of 0.5).
```

`0.80` **is** the series peak — the template keeps the value with the largest absolute score — and it is
**not the average**. **It may also be one CPU's series**: this template iterates **every** series including
per-CPU (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based
`perf_stat` rules that read only `Aggregate` (`:432`). The value is **truncated, not rounded**
(`f64_to_fixed_2`, `src/computations/mod.rs:138`) — which bites harder here than anywhere else
in the family, because the values are small: `0.80` is anything in `[0.80, 0.81)`, a 1.25% band, and a true
value of `0.509` prints as `0.50` while still having fired. And there is **no `(n−1)/n` dilution
correction**: `perf_stat` opts out of the forced first zero via `use_first_accumulative_value()`
(`src/data/perf_stat.rs:1295`), so the startup interval — when the loader and cold initialization code run
and sparsity is naturally highest — is reported at full magnitude.

Score math — `compute_finding_score(value, 0.5, −2)`. The value is always above the threshold, so no
inversion applies and the score is linear in it:

| worst sample | score |
|---|---|
| 0.60 | `(0.6/0.5) × −2` = **−2.40** |
| 0.80 | `(0.8/0.5) × −2` = **−3.20** |
| 1.00, then 2.00 | `(1.0/0.5) × −2` = **−4.00**, `(2.0/0.5) × −2` = **−8.00** |

Recover the sample as `value = |score| / 2 × 0.5 = |score| / 4`. Note the divisor is **4** here, against
`× 20` for the L1 rules and `× 10` for L2/L3 — so scores from this rule are on a scale of their own and
cannot be ranked against any other `perf_stat` finding.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| The run is on **any x86 profile** | no finding, **ever** — the metric does not exist and the silence carries no information |
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The peak sits at or below 0.5 on arm64 | no finding, and here that **is** meaningful: the layout is compact enough for the threshold |
| Only one `CPU{n}` series exceeded | reported for the whole run; the `Aggregate` series may be well under 0.5 |
| The run multiplexed heavily | the peak is an extrapolation, and one distorted interval is sufficient to fire |
| Only the first interval is elevated | still reported, at full magnitude — `perf_stat` keeps the first sample, and startup is when sparsity peaks |
| The peak is just over threshold | truncation makes the printed value up to 0.01 below the true one, so `0.50` in the description can be a fired finding |

## Interpretation

| sustained value | Reading |
|---|---|
| ≤ 0.5 | Below threshold — no finding, and on arm64 that is real evidence of compact layout |
| 0.5–1.0 | Moderate scattering. Layout work has a plausible payoff if frontend-bound |
| 1.0–2.0 | Substantial. Expect the frontend symptom metrics to be elevated too |
| > 2.0 | Severe — the executed code is highly dispersed; layout is likely the dominant frontend problem |

The finding's value comes almost entirely from what it explains:

| `code-sparsity` high **and** | Reading |
|---|---|
| sustained across the series | Genuine layout problem. Actionable |
| bursts that **recur** through the run | JIT code-cache churn, not a compiler-flag problem. The cheapest fix in this playbook |
| `High L1 Instruction Cache Misses` fired | **Layout, not capacity.** Fix layout rather than shrinking the binary — cheaper and more effective |
| `High Branch Mispredictions` fired | Predictor is thrashing on a dispersed address space. Layout helps prediction directly |
| `Instruction TLB Misses` / `Table Walks` fired | Hot code spans excess pages. Layout reduces page span; huge pages address the remainder |
| `Frontend-Dominated CPU Stalls` fired | **The confirmed, high-value case.** One layout change addresses the bottleneck through several channels |
| all four symptom findings fired | Very strong case for profile-guided optimization. Report it as the single highest-leverage action available |
| `High L2 Cache Misses` fired | Part of that L2 traffic is **code**, so the data-side playbook will mis-attribute it |
| `Backend-Dominated CPU Stalls` fired | Real but secondary. Backend first |
| `ipc` healthy (> 2) | The core is absorbing it. Low priority |
| `system` time dominates | Much of the dispersed text is kernel and cannot be relaid out |

**Known false positives — check these before recommending a rebuild:**

- **A single transient sample.** As with every `time_series_data_point_threshold` rule, one spike fires it.
  Startup and JIT phases execute widely-scattered cold code, and `perf_stat` does not dilute the first
  sample away.
- **JIT warm-up and recompilation.** Freshly compiled Java or NodeJS methods land wherever the code cache
  has room, so sparsity is high until the working set settles. Repeated spikes across the run instead
  suggest an undersized code cache churning — real and fixable, but by cache sizing, not compiler flags.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, the sample is extrapolated, and a
  single distorted interval is enough to trigger this rule.
- **Idle-diluted run.** If `Underutilized CPU` fired, samples include background daemons whose code is
  genuinely scattered relative to your application. **One hot CPU** is the same class: the rule reads every
  per-CPU series, so one thread can fire it while the aggregate is fine.
- **Kernel-dominated or interpreted workloads.** High `system` time means much of the measured code is
  kernel text, which you cannot relayout (huge pages still help); an interpreter's dispatch loop plus a
  large runtime is dispersed by design.
- **Startup-only recording**, or **a binary you do not control.** A run that captured mostly process
  initialization measures the loader — at default `--period 10` a large fraction of the samples may be
  exactly that — and third-party, closed-source or vendor code is not rebuildable, so the finding can be
  true and still not actionable at the application level.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `code-sparsity` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs startup or JIT spikes; whether bursts recur; per-thread concentration |
| `inst-l1-mpki` | `perf_stat` | The capacity symptom. High together with sparsity ⇒ layout is the cause, not size. See `High L1 Instruction Cache Misses` |
| `branch-mpki` | `perf_stat` | The prediction symptom. See `High Branch Mispredictions` |
| `inst-tlb-mpki`, `inst-tlb-tw-pki` | `perf_stat` | The translation symptom, with an independent huge-page fix. See `Instruction TLB Misses`, `Instruction TLB Table Walks` |
| `stall-frontend-pkc` vs `stall-backend-pkc`, `ipc` | `perf_stat` | **Severity gate.** All of sparsity's effects are frontend-side. See `Frontend-Dominated CPU Stalls`; `ipc` says whether the pipeline is suffering |
| `l2-mpki` | `perf_stat` | L2 carries code as well as data, so scattered text inflates a data-side finding. See `High L2 Cache Misses` |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ the peak may be an extrapolation artifact |
| `user` vs `system` | `cpu_utilization` | Whether the dispersed code is yours or the kernel's |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| `Instance Type` | `systeminfo` | Confirms the run is on Graviton at all — the only place this metric exists |
| On-CPU profile / flamegraph | `perf_profile` / `java_profile` | **Required for the fix** — profile-guided layout needs a profile. Requires `--profile` (`--profile-java` for JVM). **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | Instruction-address-level map of what actually executed — the most direct view of sparsity, and available on exactly the instances where this metric exists. **No analytical rules, no `data-descriptions.ts` entry** |
| `Excessive Time in Symbol` | `java_profile` | Names the hot method whose compiled layout matters most |
| `Excessive Exceptions` | `java_profile` | Exception paths are cold code executed frequently — a direct sparsity contributor |
| `jvmArguments` | `java_profile` | `-XX:ReservedCodeCacheSize`, `-XX:+TieredCompilation` — the JIT levers |

## Guidance

Ordered. Step 1 disposes of transient firings; step 4 is where this finding earns its keep.

1. **Read the `code-sparsity` series before anything else.** **Isolated spike(s)** at startup or aligned
   with JIT events ⇒ warm-up artifact; stop. **Repeated spikes throughout** in a JIT workload ⇒ suspect
   code-cache churn and go to step 6. **Sustained above 0.5** ⇒ continue. Check per-CPU: concentration on a
   few CPUs points at specific threads rather than at the binary.

2. **Gate on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`) and `avg(idle)` (`Underutilized CPU`). Single-worst-sample rules are sensitive to one
   distorted interval. Also check the margin: at this scale a printed `0.50`–`0.55` is close enough to the
   threshold that truncation and noise matter, and a rebuild is a poor response to it.

3. **Confirm the frontend is the bottleneck.** Compare `stall-frontend-pkc` and `stall-backend-pkc`, and
   read `ipc`. Frontend dominant with low IPC ⇒ actionable; otherwise record as a secondary observation.
   Both stall metrics exist on Graviton, so unlike generic `amd` this check is always available here.

4. **Use this finding to reinterpret the other frontend findings — the highest-value step.** Check which of
   `High L1 Instruction Cache Misses`, `High Branch Mispredictions`, `Instruction TLB Misses` and
   `Instruction TLB Table Walks` also fired. Every one that did is plausibly a *consequence* of the sparsity
   rather than an independent problem. Report them as one root cause with several symptoms and recommend one
   layout fix instead of four investigations. This is the single most useful thing this playbook does — and
   it is worth stating explicitly in the report that an x86 run could not have offered it.

5. **Determine whose code is sparse.** With `--profile`, identify whether the hot dispersed code is
   application code, a library, the runtime or the kernel. For native code on metal Graviton — which is
   where this metric exists — `hotline` shows the executed address distribution directly. If it is not code
   you build, the remaining levers are huge pages and runtime tuning.

6. **Handle the JIT case separately if applicable.** For Java or NodeJS, sparsity is driven by the code
   cache: an undersized cache causes eviction and recompilation, permanently scattering hot methods. Check
   for `code cache full` messages, set `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M` as a
   starting point and try `-XX:+TieredCompilation`. Compiler flags do not apply, and this is the cheapest
   real fix here — R1 and restart-reversible.

7. **Only then remediate**, per `INSTRUCTION_FOOTPRINT_OPTIMIZATION`. **C/C++**: `-flto` (whole-program
   optimization lets the compiler see and order all call sites) and `-Os` (smaller code is denser code); the
   decisive tool is [AutoFDO](https://gcc.gnu.org/wiki/AutoFDO/Tutorial) or equivalent PGO — feed a real
   profile back into the build so hot paths are laid out contiguously and cold paths are moved out of line.
   **Java**: tiered compilation and code-cache sizing as above. **Complementary**: apply
   `TLB_MISS_OPTIMIZATION` (huge pages) for the translation component, which reduces the cost of whatever
   dispersion remains without touching the binary.

8. **Re-measure, and require the symptoms to move together.** Re-record and confirm `code-sparsity`,
   `inst-l1-mpki`, `branch-mpki` and `inst-tlb-*` all moved. If sparsity dropped but the symptoms did not,
   they had an independent cause after all — and if the profiled workload improved while another regressed,
   the layout was over-fitted to the profile.

## Priority and execution risk

**Priority: P2 — Investigate** by default, and its weight is out of proportion to its position in the
findings panel: `Bad` (−2) yields scores of a few units, sorting far below any `Critical` finding, while
this is the one metric in the frontend family that identifies a *cause*. It rises to **P1 — Act now** when
the elevation is sustained, `Frontend-Dominated CPU Stalls` fired and at least two of the four symptom
findings did too — the strongest case for profile-guided optimization aperf can produce, since one change
addresses several findings — and for the JIT code-cache-churn pattern, where the fix is R1 and immediate. It
drops to **P3 — Monitor** on healthy `ipc`, on an interpreted or kernel-dominated workload where the
dispersed text is not yours, when only one `CPU{n}` series is elevated, or when the peak sits within 0.05 of
the threshold, and to **P4 — Informational** whenever the run multiplexed or the elevation is confined to
startup or a single compilation burst.

**Execution risk: R0 — Read-only** to diagnose: the series, the per-CPU split, the symptom findings, the
stall comparison, the profile and hotline output are all reads. **R1 — Config change** for the JVM
code-cache and tiered-compilation flags, restart-reversible and the cheapest real fix here.
**R3 — Rebuild** for the compiler levers — `-flto`, `-Os`, AutoFDO, reduced inlining, hot/cold splitting.
Treat AutoFDO as R3 even though it changes no source: the layout it produces is profile-dependent, so an
unrepresentative profile can regress workloads that were not measured, and the change needs re-validation
rather than just re-measurement. **R4 — Infrastructure change** for huge pages backing text.

**The score is monotonic and comparable across runs of this same rule** — `value = |score| / 4` recovers the
peak exactly — and comparable between `grv` and `grv5`, the only two profiles that define the metric. It is
**not** comparable with any other `perf_stat` finding, since the threshold is 0.5 against 20.0 and 10.0
elsewhere and the base score is `Bad` rather than `Concerning`.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `code-sparsity`, in any series including per-CPU, exceeded `0.5`
(`Greater 0.5`). The reported value is the series peak — verified, unlike the four zero-threshold TLB
rules. The rule can only have fired on `grv` or `grv5`.

```
STEP 0 — Where did this finding come from, and what is missing when it is absent?
  IF this finding is PRESENT
  THEN → the run is on `grv` or `grv5`, because no other PMU config defines the metric. That is
         also the only cross-profile comparison it supports: continue to STEP 1 (P2, R0)
  IF this finding is ABSENT and `Instance Type` maps to an x86 profile
  THEN → the rule COULD NOT FIRE. `code-sparsity` exists in no Intel or AMD config, so the silence
         is not evidence that the code is compact, and the layout-vs-capacity question behind
         High L1 Instruction Cache Misses has no direct answer in this report
       → verify: `rule_can_fire('High Code Sparsity','<profile>')` returns False; substitute
         branch-mpki and inst-tlb-mpki rising together as an indirect proxy, labelled inferred
         (P3, R0)
  IF this finding is ABSENT on `grv`/`grv5` and `perf_stat` WAS collected
  THEN → the peak was at or below 0.5, and here that IS meaningful: layout is compact enough for
         the threshold, so a frontend problem in this run is more likely capacity than scattering
         (P3, R0)
  IF `perf_stat` is missing from the run entirely
  THEN → the rule returned early; NO finding was possible and the silence proves nothing. aperf
         needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent (P3, R0)

STEP 1 — Is it sustained, cold-start, or recurring bursts?
  IF the elevation is confined to the FIRST interval or the first few
  THEN → the loader and cold initialization code, which are dispersed by nature. `perf_stat` keeps
         the first sample rather than zeroing it, so startup is reported at full magnitude. Record
         and STOP (P4, R0)
       → verify: re-record with `--time-range` excluding the startup window; the finding should
         disappear entirely rather than shrink
  IF the bursts RECUR through the run in a JIT workload
  THEN → CODE-CACHE CHURN, not a binary-layout problem: eviction and recompilation relocate hot
         methods repeatedly. Go to STEP 5 -- compiler flags do not apply (P1, R0)
  IF only one or two `CPU{n}` series exceed 0.5
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so one thread
         executing dispersed code fires it for the whole run while the Aggregate series may be
         under 0.5 (P3, R0)
       → verify: the on-CPU profile names that thread; a targeted fix should move its series and
         barely move the aggregate
  IF the elevation is sustained across the run
  THEN → a genuine layout property of the executed code: continue to STEP 2 (P2, R0)

STEP 2 — Gate on measurement confidence and on MARGIN.
  IF `mux_counter_schedule_rate` < 100
  THEN → the peak is an extrapolation by a factor of 100/R, and because this rule fires on the
         single worst sample one distorted interval is enough. Report low-confidence and do NOT
         act on the magnitude (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the peak collapses, the original
         finding was a multiplexing artifact
  IF the printed peak is between 0.50 and about 0.55
  THEN → the margin is inside the noise. Values are truncated not rounded, the absolute scale is
         small, and a rebuild is a poor response to a marginal firing (P3, R0)
       → verify: re-record and check whether the finding fires at all; if it appears in one run
         and not the next, treat it as noise
  IF `Underutilized CPU` fired
  THEN → samples include background daemons whose code is scattered relative to yours, so the peak
         may not be the workload's (P4, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES confirms
         the workload, one that falls confirms the daemons

STEP 3 — Is the FRONTEND actually the bottleneck?
  IF `Frontend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: the frontend cannot feed the core, and unlike a data miss the machine
         cannot hide it behind other work. Go to STEP 4, which decides the leverage (P1, R0)
       → verify: `stall-frontend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative to
         the backend; a falling ratio with a flat absolute means the backend got worse
  IF `ipc` is healthy (> 2)
  THEN → the core is absorbing the dispersion. Low priority; record and stop unless STEP 5 finds
         code-cache churn (P3, R0)
  IF `Backend-Dominated CPU Stalls` fired
  THEN → real but SECONDARY. Backend first -- but read STEP 6, because part of the L2 traffic that
         backend investigation is reasoning about may be this finding's scattered code (P3, R0)
  IF NEITHER stall finding fired
  THEN → the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence of health
         since 600 pkc on both sides fires nothing. Read the absolute pkc values. Both metrics do
         exist on Graviton, so unlike generic amd this is answerable (P3, R0)

STEP 4 — WHAT DOES THIS EXPLAIN? The step that makes the finding worth its score.
  IF three or four of branch-mpki, inst-l1-mpki, inst-tlb-mpki, inst-tlb-tw-pki also fired
  THEN → ONE ROOT CAUSE, several symptoms. Report a single profile-guided-layout recommendation
         rather than four investigations, and expect all of them to move together (P1, R3)
       → verify: after the layout change ALL the fired symptom metrics fall; if only some move,
         the others had independent causes and the consolidation was wrong
  IF `High L1 Instruction Cache Misses` fired
  THEN → LAYOUT, not capacity: the hot code may already be small enough and is simply scattered,
         so relayout beats shrinking the binary. This is the discriminator that x86 runs cannot
         compute (P1, R3)
       → verify: inst-l1-mpki falls after relayout with NO reduction in text size; if it only
         responds to -Os, the cause was capacity after all
  IF `Instruction TLB Misses` or `Instruction TLB Table Walks` fired
  THEN → the hot code spans excess PAGES as well as lines. Huge pages for text are an INDEPENDENT
         and much cheaper fix that reduces the cost of whatever dispersion remains (P2, R4)
       → verify: `AnonHugePages` rises and inst-tlb-mpki falls while code-sparsity stays flat --
         the signature of a translation-only win
  IF NO symptom finding fired
  THEN → the layout is dispersed but nothing downstream is suffering, which is exactly what a
         non-frontend-bound workload looks like. Record as informational (P4, R0)

STEP 5 — Whose code is it, and is it rebuildable?
  IF the workload is Java or NodeJS with recurring bursts
  THEN → size the code cache (`-XX:ReservedCodeCacheSize`, `-XX:InitialCodeCacheSize`) and set
         tiered compilation. Restart-reversible, no rebuild, and the cheapest fix available
         (P1, R1)
       → verify: `code cache full` messages stop, compilation counts fall, and code-sparsity
         becomes flat rather than bursty; a flat-but-still-high value is a real layout problem
  IF `system` time dominates `cpu_utilization`
  THEN → much of the dispersed text is KERNEL and cannot be relaid out. The levers are reducing
         the syscall or interrupt rate, and huge pages (P3, R2)
       → verify: the on-CPU profile attributes the elevated intervals to kernel symbols; after
         reducing syscall volume, code-sparsity falls with no build change
  IF the hot dispersed code is a third-party or closed-source component
  THEN → the finding is TRUE but not actionable at the application level. Huge pages and runtime
         tuning are what remain (P3, R4)
       → verify: the profile attributes the hot addresses to a library you do not build; confirm
         no PGO-enabled build of it is available before stopping
  IF the hot dispersed code is yours AND you control the build
  THEN → profile-guided layout is the fix: AutoFDO or equivalent PGO, plus `-flto` and `-Os`, plus
         hot/cold splitting of error paths (P1, R3)
       → verify: code-sparsity and the symptom metrics fall on the PROFILED workload AND do not
         regress on a second, unprofiled one -- over-fitting is the specific risk of PGO

STEP 6 — Is this finding inflating a data-side one?
  IF `High L2 Cache Misses` also fired
  THEN → L2 carries BOTH code and data, so scattered text contributes traffic that reads as a data
         footprint problem. Establish the split before anyone restructures data (P2, R0)
       → verify: after the layout fix, l2-mpki falls together with code-sparsity and inst-l1-mpki;
         if l2-mpki barely moves, that traffic really was data

STEP 7 — What survives?
  VALID      : the reported value AS the series peak; the per-CPU split; `value = |score| / 4`;
              the grv-to-grv5 comparison; the consolidation of symptom findings into one root
              cause; the stall split read as absolute pkc; the startup-vs-sustained distinction;
              and every non-PMU finding in the run
  CAUTION    : the value read as a "fraction of cold code" -- it is a per-thousand-instruction
              rate, not a dimensionless fraction; any peak within ~0.05 of the threshold, given
              truncation and the small absolute scale; and any claim about what event 0x11c counts,
              which aperf does not document anywhere in its tree
  CONFOUNDED : the value on a multiplexed run; the value on an idle-diluted run; the value on a
              kernel-dominated or interpreted workload, where the dispersed text is not yours; and
              the value during a compilation burst
  VOID       : any score comparison with another perf_stat rule (threshold 0.5 and base score Bad
              versus 20.0/10.0 and Concerning); any comparison against an x86 run, where the
              metric does not exist; any inference from the ABSENCE of this finding on x86; and
              any claim that this value is the average

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "startup", which is the
         most important distinction for this finding, and recurring JIT bursts cannot be told from
         a single one (P3, R0)
  IF the run has no `--profile`
  THEN → the dispersed code cannot be attributed to application, library, runtime or kernel text,
         and PGO is impossible without a profile -- so both the diagnosis and the fix are blocked.
         This is the one input the playbook cannot work without (P3, R0)
  IF the run is on x86
  THEN → the metric does not exist, so this playbook cannot be entered at all. Read
         high-l1-instruction-cache-misses.md, which documents the same gap from the symptom side
         (P3, R0)
```

## Runtime-specific consequences

Sparsity is a property of the binary, so the question of *who produced the binary* decides the entire
remediation path — and for two of these runtimes the answer is "nobody you can influence with a flag".

| Runtime | Why the sparsity, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | The JIT places methods wherever the code cache has room, with no locality guarantee, and recompilation relocates them; tiered compilation keeps two versions of hot methods alive. Exception paths are cold code executed often. Recurring bursts are a **real, cheap-to-fix defect**; a single startup ramp is not | `jvmArguments` for `-XX:ReservedCodeCacheSize` and `-XX:+TieredCompilation`; `code cache full` in the logs; `Excessive Exceptions`. Axis: **code-cache sizing** (R1). Compiler flags do not apply |
| **Python** | The interpreter dispatch loop plus a large C runtime is dispersed by construction and exercised on every bytecode. **Structural, not a defect** | Whether hot work can move into a native extension or a vectorized library. Axis: **leave the interpreter loop**, not layout |
| **.NET** | Same JIT dynamic as Java, plus ReadyToRun and AOT publishing as explicit controls that move code generation — and therefore layout — out of the run | Whether R2R or AOT is in use; tiered-compilation settings. Axis: **AOT or R2R**, then code-cache-equivalent tuning |
| **C/C++/Rust (native)** | The runtime where this finding is fully actionable: layout is decided at build time and PGO can fix it. Sustained elevation here **is** a defect and has a known fix | Whether the build uses `-flto`, `-Os` and AutoFDO or equivalent PGO; whether error paths are annotated cold. Axis: **profile-guided layout** (R3) |

**The unknown-runtime case is the default** — aperf reports no language field, and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 4 and report the consolidation: which symptom findings this one explains, and that they should
be treated as one problem. That needs no knowledge of the runtime, and it is the playbook's highest-value
output.

## Architecture-specific considerations

This finding fires on **2 of 8** PMU profiles. The registry says so explicitly — `architectures` is
`["arm64", "arm64_graviton5"]` with `architecture_note`: *"arm64 only: code-sparsity exists in no Intel or
AMD PMU config."*

| Profile | `code-sparsity` definition | Can the rule fire? |
|---|---|---|
| `grv` | `Code_Sparsity / Instructions * 1000`, `Code_Sparsity` = `armv8_pmuv3_0/event=0x11c/` | **Yes** |
| `grv5` | The same, inherited via `extend_from_default` — `grv_5_pmu_config.json` overrides only `l3-mpki` | **Yes** |
| `intel`, `icelake`, `spr` | not defined | **No** |
| `amd`, `milan`, `genoa` | not defined | **No** |

So `cross_architecture_comparable('code-sparsity', 'grv', 'grv5')` is **True** and every other pair is
**False** — including `intel`/`icelake`, which are comparable for every metric that exists on both, because
`metric_definition` returns `None` here and the function short-circuits. `test_aperf_memory_hierarchy.py`
re-derives this from `src/pmu_configs/*.json`, so it cannot drift.

The consequence for cross-architecture work is asymmetric and worth stating plainly: a Graviton run can
*explain* its frontend findings and an x86 run cannot. When comparing the two, the Graviton side may show
one extra finding that looks like a regression and is really just better instrumentation, while the x86 side
looks clean on layout with exactly the same problem.

**No aperf gate protects any of this.** aperf has no architecture field and no rule compares `Instance Type`
([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with matched `CPUs` and
`MemTotal` fires **no gate**, yet the metric's very existence changed. Instruction density compounds it —
the same program compiled for two ISAs has different code volume, so even a hypothetical x86 equivalent of
this counter would not be comparable.

## Verification

Re-record at the **same geometry, same counter mode, same instance type and the same build inputs**, then
check in order. First, `code-sparsity` must fall — compare the **sustained** level, not the peak, and
exclude the startup window, because a fix that only smooths the cold-start ramp looks like a large win while
changing nothing about steady state. Second, and this is what distinguishes a real layout improvement from a
coincidence, **the symptom metrics must move with it**: `inst-l1-mpki`, `branch-mpki`, `inst-tlb-mpki` and
`inst-tlb-tw-pki` should all fall if the dispersion was driving them. Third, `stall-frontend-pkc` must fall
in **absolute pkc**, not merely relative to the backend. Fourth, throughput must improve — the frontend is
harder for the core to hide than the backend, so a real fix here usually does show end to end.

If sparsity dropped and the symptoms did not, they had independent causes and the consolidation in STEP 4 was
wrong — useful information, not a failed fix. If `l2-mpki` fell alongside, part of that data-side finding was
scattered code all along. And if a PGO rebuild improved the profiled workload while regressing a different
one, the layout was over-fitted to the profile: the specific failure mode that makes AutoFDO R3, detectable
only by measuring a workload the profile did not cover.

## Do not

- **Do not read the absence of this finding on an x86 run as evidence that the code is compact.** The
  metric exists in no Intel or AMD PMU config, so the rule is structurally unable to fire and the silence
  carries no information at all.
- **Do not treat this as a minor finding because the score is small.** `Bad` (−2) produces scores of a few
  units, sorting far below `Critical` findings, yet this is a root cause that can explain three or four
  other findings at once.
- **Do not treat the reported value as the average.** It is the series peak, and startup — when the loader
  and cold initialization code run — is reported at full magnitude because `perf_stat` keeps the first
  sample.
- **Do not read the value as a fraction of cold code**, and **do not act on a peak within about 0.05 of the
  threshold.** It is a per-thousand-instruction rate — `0.5` is one event per 2000 instructions — and values
  are truncated rather than rounded on a small absolute scale, so a marginal firing is inside the noise and
  a rebuild is an expensive response to it.
- **Do not investigate `branch-mpki`, `inst-l1-mpki` and the ITLB findings independently when sparsity is
  high.** They are likely one problem; treating them separately multiplies the work and can produce fixes
  that do not compose.
- **Do not apply `-Os` and expect it to fix scattering** — it reduces size, not temperature ordering; only
  profile-guided layout does that. And **do not reach for compiler flags on a JIT workload**: recurring
  bursts are code-cache churn, fixed by cache sizing at R1 rather than a rebuild at R3.
- **Do not recommend a rebuild for code you do not build.** Check whose code it is first: kernel text,
  vendor libraries and closed-source components are not relaid out by your build flags.
- **Do not optimize layout while the workload is backend-bound**, and **do not act on the value when
  `mux_counter_schedule_rate` is below 100** — the peak is then an extrapolation, and this rule is
  unusually exposed because it fires on a single sample.
- **Do not ship a PGO layout validated on one workload as a general improvement**, and **do not compare
  this score with any other `perf_stat` finding** — the threshold is 0.5 against 20.0 and 10.0 elsewhere,
  and the base score is `Bad` rather than `Concerning`.
- **Do not assert what event `0x11c` counts.** aperf ships no documentation for it; the only references in
  the tree are the config line, the rule, the display-order list and the description string.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:84` — `metric: "code-sparsity"`,
  `comparator: Comparator::Greater`, `threshold: 0.5`, `score: Score::Bad`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void. It is the only
  frontend `perf_stat` rule not scored `Concerning`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)`; with a non-zero threshold and a monotonic score
  that is the series **peak**. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — `delta = value / threshold`,
  inverted only below 1.0, times `rule_score`. `Score::Bad = −2` at `:147`–`:157`.
- Per-profile metric definition: `src/pmu_configs/grv_pmu_config.json` defines `Code_Sparsity` =
  `armv8_pmuv3_0/event=0x11c/` and `code-sparsity` = `Code_Sparsity / Instructions * 1000`. **No other
  config defines either**; `grv_5_pmu_config.json` overrides only `l3-mpki`, so `grv5` inherits this metric
  through `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), with profile selection at
  `:750`–`:797`. `perf_stat` opts **out** of the forced first zero via `use_first_accumulative_value()`
  (`:1295`), which is why startup dispersion is reported at full magnitude. Display order comes from the
  Graviton top-down list at `:968`–`:988`, where `code-sparsity` sits last among the frontend metrics.
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) —
  `rule_can_fire('High Code Sparsity', <profile>)` returns False on all six x86 profiles, which is the
  collection gap above; `--side` classifies a fired set into instruction-side versus data-side and returns
  the matching upstream guides; `cross_architecture_comparable` returns True only for `grv`/`grv5`;
  `--select` confirms the peak is reported. `test_aperf_memory_hierarchy.py` re-derives the definition and
  its absence elsewhere from `src/pmu_configs/`.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate of
  R% is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and
  duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `INSTRUCTION_FOOTPRINT_OPTIMIZATION` (the compiler and JVM remediations — `-flto`,
  `-Os`, AutoFDO, code-cache sizing), `CPU_FRONTEND_STALLS_INVESTIGATION` (which lists `code-sparsity`
  last, as the layout check after the three symptom metrics) and `TLB_MISS_OPTIMIZATION`, in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `high-l1-instruction-cache-misses.md` (the symptom this metric discriminates, and the
  playbook that loses its discriminator on x86), `high-branch-mispredictions.md`,
  `instruction-tlb-misses.md` and `instruction-tlb-table-walks.md` (the other three symptoms),
  `frontend-dominated-cpu-stalls.md` (the severity gate), `high-l2-cache-misses.md` (which carries
  scattered code as traffic), `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `old-style-atomic-instructions.md` (the other arm64-only `perf_stat` rule, with the same
  structural-silence caveat), `../kernel_config/huge-page-disabled.md`,
  `../java_profile/excessive-exceptions.md`, `../cpu_utilization/underutilized-cpu.md`. Cross-cutting:
  [../GATES.md](../GATES.md), [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md),
  [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down front-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-front-end-stalls)
- [Graviton perfrunbook — optimizing for large instruction footprint](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html#optimizing-for-large-instruction-footprint)
- [GCC AutoFDO tutorial](https://gcc.gnu.org/wiki/AutoFDO/Tutorial)
