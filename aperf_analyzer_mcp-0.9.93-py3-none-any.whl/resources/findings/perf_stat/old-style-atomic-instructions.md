---
rule_name: Old-Style Atomic Instructions
data_type: perf_stat
data_key: strex-spec-pki
template: time_series_data_point_threshold
condition: "any(strex-spec-pki) >= 10.0"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "The STREX instructions are being used extensively. It is an old-style atomic instruction less efficient than the newer LSE instructions."
source: src/analytics/rules/perf_stat.rs:132
---

# Old-Style Atomic Instructions

## What fired

**At least one** data point of `strex-spec-pki` was **greater than or equal to 10.0** speculatively
executed store-exclusive operations per thousand instructions. A single sample on a single CPU anywhere
in the recording is enough.

Base score `Poor` (**−16**) — **the most severe base score in the entire `perf_stat` family**, eight
times `Bad` and sixteen times `Concerning`. Single-run rule, `Comparator::GreaterEqual`, so exactly
10.0 fires.

The severity is deliberate and it reflects a different kind of problem from every other `perf_stat`
finding: this one is usually a **build configuration defect**, not a property of the workload. It is the
cheapest high-value fix aperf reports — a compiler flag, no code change.

**It is also arm64-only.** `strex-spec-pki` is defined in exactly one of the eight shipped PMU configs.
On x86 the rule is structurally silent, and that silence says nothing whatsoever about atomic
efficiency.

## The collection gap — verified by compiling against the flags upstream prescribes

**aperf's own remediation text contains two defects, and the first one makes the Rust flag fail the
build outright.** `LSE_OPTIMIZATION`
(`src/report_frontend/src/definitions/optimization-guides.ts:109`–`:115`) is what the report shows a
reader who clicks through from this finding. It prints:

```
export RUSTFLAGS="-Ctarget-features=+lse"
```

`target-features`, plural. Running it:

```
$ rustc -Ctarget-features=+lse main.rs
error: unknown codegen option: `target-features`
```

The option is **singular**, `-Ctarget-feature`. This does not silently fail to enable LSE — it
**aborts the compilation**, so a reader who pastes the guide's line gets a broken build and no
diagnosis. The working forms, in order of preference:

| form | status | notes |
|---|---|---|
| `-Ctarget-cpu=neoverse-n1` (or `-v2`, `-v3`) | **preferred** | Implies LSE plus the rest of the part's ISA; stable |
| `-Ctarget-feature=+lse` | works | `rustc` warns it is an "unknown and unstable feature" name but passes it to the backend |
| `-Ctarget-features=+lse` | **fails** | Upstream's text. `error: unknown codegen option` |

**The second defect is a description inverted against its own flag.** The same guide says
`-mno-outline-atomics` *"enables calls to out-of-line helpers to implement atomic operations"*. The
`-mno-` prefix **disables** them — it inlines LSE instructions directly, which is what you want on a
same-generation target and is why the flag belongs in the list. The flag is right; the sentence
describing it says the opposite.

That inversion matters because of a third fact the guide omits: **`-moutline-atomics` has been the
default on aarch64 since GCC 10.1.** So "rebuild with `-moutline-atomics`" is usually a **no-op** — a
binary showing high `strex-spec-pki` on Graviton2+ *already had* the runtime check and still took the
LL/SC path. That narrows the diagnosis sharply, and it is the single most useful inference on this
page: the cause is almost never a missing `-moutline-atomics`. It is one of

- an explicit `-march`/`-mcpu` baseline predating v8.1 (`armv8-a` without `+lse`), which forecloses LSE
  regardless of outlining;
- a toolchain older than GCC 9.4 / Clang 12, which cannot emit the helpers at all;
- a **prebuilt** object — a static archive, a vendored `.a`, a distro package, a bundled runtime — whose
  flags are not yours to set;
- or `-mno-outline-atomics` combined with a pre-LSE `-march`, which is the one combination that
  actively forces LL/SC.

`tools/aperf_perf_stat.py --strex --pki N` carries both corrections; `tools/test_aperf_perf_stat.py`
pins them, including the literal `rustc` error text so the claim stays falsifiable.

## Reasoning

`strex-spec-pki` is *"The number of store exclusive operations that have been speculatively executed
per thousand instructions. STREX is an old-style atomic instruction and part of the load-store pair. It
is less efficient than the newer LSE instructions, which perform atomic operations with a single
instruction and hardware managed atomicity. For workloads that involve heavy lock contentions,
switching to LSE instructions could lead to significant performance improvement."*
(`data-descriptions.ts`, `desired: "lower"`)

There are two ways to do an atomic operation on AArch64:

1. **Load-exclusive / store-exclusive (LDXR/STXR, "STREX") — the pre-v8.1 way.** The core loads with an
   exclusive monitor, computes, then attempts the store. **If any other core touched the line in
   between, the store fails and the whole sequence must be retried in a software loop.** The operation
   is not atomic in hardware; atomicity is emulated by retry.
2. **Large-System Extensions (LSE, Armv8.1+) — `LDADD`, `SWP`, `CAS`, and friends.** A *single*
   instruction performs the read-modify-write, with atomicity managed in hardware, close to the point of
   coherency.

The performance difference is not a constant factor — **it grows with contention**, which is what makes
this finding disproportionately important:

- **Uncontended**, the two approaches are roughly comparable.
- **Under contention**, the LL/SC loop degrades badly. Each failed attempt bounces the cache line
  between cores, burns cycles, and increases the chance the *next* attempt fails too. Multiple cores can
  livelock against each other, retrying and invalidating in turn. Throughput can *fall* as cores are
  added. LSE instructions have no retry loop, so contention costs coherence traffic but never spirals.

**Why this shows up at all on modern hardware:** every Graviton generation from Graviton2 onward
supports LSE. A binary using STREX on such a machine is almost always a **build artifact** — see the
narrowed cause list above.

**The `_SPEC` suffix is load-bearing.** The event counts *speculatively executed* operations, so it
includes attempts on mispredicted paths and — importantly — **every failed retry of the LL/SC loop**.
That is a feature for this diagnosis: the metric is a *contention* proxy, not an inventory of the
program's atomic operations. A rate far above what the source code's atomic count would predict is
itself the evidence of retry churn. It also means the metric cannot be converted into "atomics per
second" and must never be quoted as one.

The remaining causes, once the build question is settled:

- **A managed runtime built without LSE.** Older JVMs, or language runtimes whose distributed binaries
  target a conservative baseline, put STREX inside every lock and atomic.
- **Genuinely heavy atomic traffic.** Even with instruction selection ruled out, a high rate means the
  workload performs a great many atomic operations — reference counting, shared counters, contended
  locks, work-stealing queues. Then the algorithmic fix matters as much as the flag.
- **Non-atomic uses of exclusives.** Some low-level code uses load/store-exclusive for purposes other
  than a standard atomic RMW; these are not always replaceable by an LSE instruction.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than or equal to"`, and the threshold printing as `10` because Rust's
`{}` drops a whole float's `.0`:

```
At least one data point in aperf_record is 45.00 (greater than or equal to the threshold of 10).
```

`45.00` is the **worst single sample across every series, including per-CPU** — not the average.
`time_series_metric_values_iterator` (`processed_data_accessor.rs:104`) flattens all series, so **one
CPU in one interval above 10.0 fires this finding for the whole run** even when the `Aggregate` never
approaches it. Values at or above 1000 print with a K suffix (`formatted_number_string`,
`computations/mod.rs:176`–`:190`), so a severe run may read `1.20K`.

Score math — `compute_finding_score(value, 10.0, −16)`:

| worst sample | score | % of instructions |
|---|---|---|
| 10.0 | `(10/10) × −16` = **−16.00** | 1.0% |
| 15.0 | `(15/10) × −16` = **−24.00** | 1.5% |
| 45.0 | `(45/10) × −16` = **−72.00** | 4.5% |
| 200.0 | `(200/10) × −16` = **−320.00** | 20.0% |

Recover the sample as `value = |score| × 0.625`, and read **`pki / 10` as percent of the instruction
stream** — the conversion that turns this metric into a budget.

**The tie-break trap.** Selection uses `if abs_finding_score >= max_abs_finding_score`, so on ties the
**last** qualifying data point wins, which need not be the largest value. Combined with per-CPU
iteration, the reported number is "a qualifying point", not reliably "the maximum".

**These scores dwarf every other `perf_stat` finding and will dominate any score-ordered list.** A
merely-at-threshold 10.0 already scores −16.00, more severe than a catastrophic 60 MPKI L3 miss rate
(−12.00). Treat the ordering as "look at this one first because the fix is cheap", not as a claim that
it is the largest contributor to runtime. Confirm impact from the stall split and `ipc`.

## Interpretation

| worst sample | % of instructions | Reading |
|---|---|---|
| ~10 | 1% | At threshold. LSE is very likely unavailable to the binary; the atomic *rate* is modest, so the win may be small — but the fix is nearly free |
| 10–50 | 1–5% | Substantial atomic traffic on the slow path. A rebuild is high-value |
| 50–200 | 5–20% | Very heavy. Expect retry churn and coherence bouncing; throughput may already scale negatively with core count. The flag alone will not be enough |
| > 200 | > 20% | One instruction in five is atomic retry scaffolding. This is a data-structure problem that a flag can only partially mask |

Combinations:

| `strex-spec-pki` high **and** | Reading |
|---|---|
| sustained across the series | Genuine — the binary uses the LL/SC path throughout. **The actionable case** |
| one isolated sample | A brief contended phase (startup barrier, shutdown, lock convoy). Lower priority, same fix |
| `Backend-Dominated CPU Stalls` fired | **The confirmed case** — failed exclusive stores and their coherence traffic stall the backend |
| `data-l1-mpki` also high | Consistent with cache-line bouncing between cores. The atomics *are* the cache misses |
| `Reduced Instructions per Cycle` also fired | Retry loops execute instructions that accomplish nothing; IPC can look fine while useful work drops. Read them together |
| `avg(system)` high (`cpu_utilization`) | Contention may be escalating to kernel-side futex waits — lock contention, not just instruction selection |
| high core count / many threads | Contention scales with concurrency; the LL/SC penalty scales worse than linearly |
| `Underutilized CPU` also fired | Threads may be blocked on contended locks rather than spinning. Check both the lock design and instruction selection |
| `ipc` healthy and throughput acceptable | The atomics are uncontended. Still worth the rebuild, but do not expect a large gain |
| `PMU Counter Collection Multiplexing` fired, grouped mode | **Does not weaken the value.** The scale factor cancels in grouped mode, so the magnitude stands; only coverage is reduced |
| `PMU Counter Collection Multiplexing` fired, ungrouped mode | The value may be skewed by up to `100/rate` in either direction. A near-threshold reading is unproven |

**Known false positives:**

- **A single transient sample.** As with every `time_series_data_point_threshold` rule, one contended
  interval — a startup barrier, a shutdown join, a lock convoy — fires it.
- **Idle-diluted run.** If `Underutilized CPU` fired, part of the sample is background daemons — and
  system libraries in distro-built binaries are a classic STREX source unrelated to your workload.
- **Speculative counting inflates the number.** Includes mispredicted paths and every failed retry; not
  a count of atomic operations logically performed.
- **The STREX comes from a dependency you do not build.** A real finding, but *your* compiler flags will
  not fix it. Do not report a rebuild flag without establishing where the instructions originate.
- **Non-atomic uses of exclusives**, which have no LSE equivalent.
- **The atomics are uncontended.** The finding is valid, the payoff modest.
- **Ungrouped-mode multiplexing skew** pushing a genuinely sub-threshold value over 10.0.
- **Non-Arm hosts.** The metric does not exist; the rule cannot fire. Never carry a STREX conclusion
  across architectures.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `strex-spec-pki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient; all cores or a few threads |
| `stall-backend-pkc` vs `stall-frontend-pkc` | `perf_stat` | **Severity gate.** Failed exclusives and coherence traffic stall the backend. See `Backend-Dominated CPU Stalls` |
| `ipc` | `perf_stat` | Whether the pipeline is suffering. Retry loops can keep IPC high while doing no useful work. See `Reduced Instructions per Cycle` |
| `data-l1-mpki`, `l2-mpki` | `perf_stat` | Cache-line bouncing between cores shows here. See `High L1 Data Cache Misses` |
| `mux_counter_schedule_rate` **and** `pmu_counter_mode` | `perf_stat` | Confidence gate. In grouped mode the magnitude is unaffected; in ungrouped mode it can be skewed. The mode decides whether this matters at all |
| `system` vs `user` | `cpu_utilization` | High `system` suggests contention escalating into kernel futex waits |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check, and whether threads are blocked rather than spinning |
| `Instance Type`, `CPU Model`/`Model name` | `systeminfo` | Confirms the hardware supports LSE (Graviton2 and later do). If it does, STREX is a build artifact |
| `Kernel Version` | `systeminfo` | Toolchain/distro vintage context |
| `number_threads` | `processes` | Concurrency — the LL/SC penalty scales worse than linearly. **No analytical rules — read manually** |
| `ctxt`, `procs_running` | `vmstat` | Context-switch and runnable-task pressure accompanying lock contention |
| On-CPU profile | `perf_profile` / `java_profile` | **The key attribution step** — which functions and which object the atomics come from. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Lock/contention profile | `java_profile` | For Java, contended-monitor profiling localizes the hot locks (`--profile-java`) |
| Hotline output | `hotline` | Address-level attribution of the bouncing lines. Native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |

## Guidance

Ordered. Step 4 is the one that turns this finding into a one-line fix — or proves it is not yours to
fix.

1. **Read the `strex-spec-pki` series and check per-CPU.** Convert to percent of instructions
   (`pki / 10`) as you go; that is the number that says whether this is worth a rebuild cycle. An
   isolated spike at startup or shutdown means note it and lower the priority — the remediation is
   unchanged but the payoff is smaller. Sustained at or above 10 means continue. Concentration on a few
   CPUs points at specific threads or a specific lock.

2. **Gate on measurement confidence — and read the *mode*, not just the rate.** If
   `PMU Counter Collection Multiplexing` fired, check `pmu_counter_mode`. **Grouped (the default) does
   not weaken this value**: the scale factor cancels because the metric is degree-0 in its counters, so
   the magnitude stands. **Ungrouped can skew it** by up to `100/rate` in either direction, which for a
   near-threshold reading is decisive. Also check `avg(idle)` — an idle-diluted run puts distro system
   libraries in the sample.

3. **Confirm the hardware supports LSE.** Read the instance type and CPU model from `systeminfo`. Every
   Graviton generation from Graviton2 onward implements LSE. If the hardware supports it and the binary
   is still issuing STREX, the instructions are a build artifact — and because `-moutline-atomics` is
   the GCC 10.1+ default, the cause is an `-march` baseline, an old toolchain, or a prebuilt object,
   *not* a missing outline-atomics flag.

4. **Find out where the STREX instructions come from — the decisive step.** With `--profile`, identify
   the functions and the *object* they live in. Your own build means your flags apply. A statically
   linked or vendored dependency means your flags will not help and you need that dependency rebuilt. A
   language runtime or JVM means upgrade or use a v8.1+ build. System libraries in a mostly-idle run
   means it is likely not your workload at all. **Reporting a rebuild flag without this step is the most
   common way to give advice that changes nothing.**

5. **Enable LSE with the corrected flags.** `-mcpu=native` (or `-march=armv8.2-a`, or the `-mcpu`
   matching the target part) to permit LSE at all, plus `-mno-outline-atomics` to **inline** it rather
   than call the dispatch helpers. For Rust use `-Ctarget-cpu=neoverse-n1` or later —
   **not** the guide's `-Ctarget-features=+lse`, which rustc rejects as an unknown codegen option.
   Verify by disassembly (`LDADD`/`SWP`/`CAS` where `LDXR`/`STXR` were), then re-record.
   **Portability caveat:** raising the baseline produces a binary that will not run on pre-v8.1 Arm
   hardware. If one binary must span generations, keep outline atomics — the runtime dispatch selects
   LSE where available, at the cost of a call per atomic.

6. **Confirm the backend impact.** Compare `stall-backend-pkc` with `stall-frontend-pkc` and read `ipc`,
   so the reported severity reflects measured cost rather than only the (very large) rule score.

7. **Then attack the contention itself, not just the instruction.** LSE removes the retry loop; it does
   not remove the coherence traffic. Above ~50 pki the durable fixes are algorithmic: per-thread or
   sharded counters aggregated at read time, batched updates, finer-grained or lock-free structures,
   shorter critical sections, cache-line padding for concurrently-written fields (overlaps with false
   sharing — see `High L1 Data Cache Misses`), and sometimes *fewer* threads. For Java, contended-monitor
   profiling finds the specific hot locks.

## Priority and execution risk

**Priority: P2 — Investigate** by default, and it is the rare `perf_stat` finding whose default is
justified by the *cheapness of the fix* rather than the size of the cost: a flag change with a known
mechanism. It rises to **P1 — Act now** when the value is sustained above ~50 pki (5% of instructions)
**and** `Backend-Dominated CPU Stalls` fired **and** the instructions are attributed to code you build —
at that point the win is large and the change is a build flag. It drops to **P3 — Monitor** when the
value comes from a single transient interval, or when the instructions belong to a prebuilt dependency
you cannot rebuild, and to **P4 — Informational** when `ipc` is healthy and throughput is acceptable
(uncontended atomics), or when the run is idle-diluted enough that system libraries are the likely
source. **It is P4 on any x86 run by construction — the metric does not exist there.**

**Execution risk: R0 — Read-only** to resolve: the series, the per-CPU spread, the percent-of-instruction
conversion, the mode check, and profile attribution are all reads. Acting is **R3 — Rebuild** for the
dominant remediation, because raising `-march`/`-mcpu` changes the binary that runs in production and
**narrows the hardware it can execute on** — a pre-v8.1 host will fault on an LSE instruction, which
makes this an R3 with a genuine deployment blast radius rather than a free win. It is **R2** for a
runtime or JVM upgrade, and **R5** where the remediation becomes algorithmic: replacing a contended lock
with a lock-free structure or sharding shared state changes concurrency semantics and needs a
correctness suite before a performance one. **Do not inherit the R0 of the reading into the rebuild.**

**The score is the largest in `perf_stat` and must not be compared across findings.** `Poor` (−16) means
a just-at-threshold 10.0 scores −16.00 — larger than any cache or TLB finding reaches at realistic
values, and larger than `High Branch Mispredictions` at a catastrophic 50 mpki (−5.00). The score
restates the value exactly (`|score| × 0.625 = pki`), so it carries no information the value does not;
what it distorts is **rank**. Rank on percent-of-instructions and the stall split.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `strex-spec-pki` data point on any series, including per-CPU, was
`>= 10.0`.

```
STEP 0 — Can this rule even fire here? The answer is architectural, not statistical.
  IF the run is on any Intel or AMD profile
  THEN → `strex-spec-pki` is defined in exactly ONE of the 8 shipped PMU configs
         (grv_pmu_config.json, STREX_SPEC event 0x6f). The rule COULD NOT FIRE and its
         silence is structural, not evidence of efficient atomics (P4, R0)
  IF `perf_stat` is missing from the run
  THEN → no PMU passthrough; the rule returned early and proves nothing (P3, R0)
  IF the run is on `grv` or `grv5`
  THEN → the metric exists and the hardware supports LSE from Graviton2 onward, so a
         firing finding is a BUILD artifact until proven otherwise. Continue (P2, R0)

STEP 1 — Convert to percent of the instruction stream FIRST; pki / 10 = percent.
         Recover the sample from the score as |score| x 0.625.
  IF the worst sample is 10-15 pki (1-1.5% of instructions)
  THEN → at threshold. LSE is probably unavailable to the binary but the atomic RATE is
         modest; the fix is nearly free, the payoff small. Report both (P3, R0)
  IF 15-50 pki (1.5-5%)
  THEN → substantial slow-path atomic traffic; a rebuild is high-value. Continue (P2, R0)
  IF 50-200 pki (5-20%)
  THEN → heavy: expect retry churn and coherence bouncing, and expect the flag alone to be
         insufficient. Continue to STEP 5 as well (P1, R0)
  IF > 200 pki (over 20% of instructions)
  THEN → one instruction in five is retry scaffolding. This is a data-structure problem a
         flag can only partially mask (P1, R0)
       → verify: values >= 1000 print with a K suffix (`1.20K`, computations/mod.rs:176), so
         confirm you are not reading a truncated figure

STEP 2 — Gate on confidence. The MODE decides whether the value is in question at all.
  IF `PMU Counter Collection Multiplexing` fired and `pmu_counter_mode` is grouped
  THEN → the value STANDS: the scale factor cancels for a degree-0 metric, so only coverage
         was lost. Do not discount the magnitude (P2, R0)
  IF it fired and the mode is ungrouped
  THEN → the metric may be skewed by up to 100/rate in either direction. A reading between
         10 and 10 x that factor is UNPROVEN (P3, R0)
       → verify: re-record GROUPED with a trimmed `--pmu-config`; if the value survives it
         was real
  IF `Underutilized CPU` also fired
  THEN → the sample is diluted with background daemons, and distro-built system libraries
         are a classic STREX source unrelated to your workload (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; if the value collapses,
         the atomics were not your workload's
  IF only one or two `CPU{n}` series exceed 10 while the Aggregate is far below
  THEN → one thread or one lock, not the instance. The rule fired off a per-CPU series
         (processed_data_accessor.rs:104) (P3, R0)
       → verify: correlate with the on-CPU profile to name the thread; an instance-wide
         rebuild claim is not supported by a single-CPU sample
  IF the reported value looks lower than samples you can see in the series
  THEN → selection uses `>=` on the absolute score, so on ties the LAST qualifying point
         wins and it need not be the largest. Read the series for the true maximum (P3, R0)

STEP 3 — Does the hardware support LSE? This splits "build defect" from "impossible".
  IF the instance is Graviton2 or later
  THEN → LSE is present in hardware, so the binary CHOSE LL/SC. Because -moutline-atomics
         is the GCC 10.1+ DEFAULT, the cause is NOT a missing outline flag: it is an -march
         baseline predating v8.1, a toolchain older than GCC 9.4/Clang 12, a prebuilt
         object, or -mno-outline-atomics combined with a pre-LSE -march (P2, R0)
  IF the instance is Graviton1 (A1) or a pre-v8.1 part
  THEN → LSE does not exist on this hardware and STREX is the ONLY option. No flag can
         help; only an algorithmic reduction in atomic traffic or a newer instance can
         (P3, R0)
       → verify: `Instance Type` and `CPU Model` in systeminfo. Do not recommend
         `-march=armv8.2-a` for a part that cannot execute it

STEP 4 — MANDATORY manual check: whose instructions are they? A flag fixes only your own.
  IF they are in APPLICATION code you build
  THEN → your flags apply: `-mcpu=native` (or `-march=armv8.2-a`) plus
         `-mno-outline-atomics` to INLINE LSE. Rust: `-Ctarget-cpu=neoverse-n1` (P2, R3)
       → verify: disassemble and confirm LDADD/SWP/CAS replaced LDXR/STXR, then re-record
         and confirm `strex-spec-pki` fell. If the disassembly changed but the metric did
         not, the instructions were never yours
  IF the upstream guide's Rust line was used verbatim
  THEN → `-Ctarget-features=+lse` (PLURAL) is rejected by rustc with
         "unknown codegen option", so the build FAILED rather than silently missing LSE.
         Use the singular `-Ctarget-feature=+lse`, or better `-Ctarget-cpu=` (P2, R1)
       → verify: `rustc -Ctarget-features=+lse` reproduces the error in one command
  IF they are in a STATICALLY LINKED or vendored dependency
  THEN → your compiler flags cannot reach it. You need that dependency rebuilt or a newer
         package; until then the finding is real and unfixable by you (P3, R3)
       → verify: name the object in the profile. If it is a `.a` or a bundled `.so`, a
         rebuild of YOUR code will not move the metric -- predict that before spending the
         cycle
  IF they are in a language runtime or JVM
  THEN → upgrade to a build targeting v8.1+, or switch distributions. Older JVMs put STREX
         inside every lock and atomic (P2, R2)
       → verify: after the upgrade the metric falls without any application change
  IF no `--profile` data exists
  THEN → STOP. Any rebuild recommendation from here is speculative; the honest deliverable
         is a re-record with `--profile` (P2, R0)

STEP 5 — Only above ~50 pki: the flag is necessary but not sufficient.
  IF a single shared counter or one hot lock dominates the profile
  THEN → shard it, make it per-thread and aggregate at read time, or batch the updates. LSE
         removes the retry loop but not the serialization (P1, R5)
       → verify: `strex-spec-pki` AND `data-l1-mpki` both fall. If the atomics fall and L1
         misses do not, the bouncing line was not the atomic
  IF `data-l1-mpki` is also high and threads write adjacent fields
  THEN → false sharing compounds it: pad concurrently-written fields onto separate cache
         lines (P2, R3)
       → verify: `data-l1-mpki` falls while the instruction count rises slightly (padding
         costs footprint). If neither moves, the adjacency was not the problem
  IF throughput falls as threads are added
  THEN → the LL/SC retry loop is livelocking. Fewer threads can deliver MORE throughput;
         test that before any code change, since it is a config knob (P1, R1)
       → verify: a thread-count sweep. If throughput peaks below the core count, contention
         is the binding constraint and the rebuild alone will not lift it
  IF the atomics are uncontended (`ipc` healthy, throughput acceptable)
  THEN → the rebuild is still worth doing but expect a small gain. Do not promise one
         (P4, R3)
       → verify: state the expected delta BEFORE re-recording. If `strex-spec-pki` falls to
         near zero and throughput is unchanged, the atomics were never on the critical path

STEP 6 — What survives?
  VALID      : the pki value as percent-of-instructions on a grouped-mode run; the recovered
               sample `|score| x 0.625`; the inference that Graviton2+ hardware plus a
               firing finding means a build artifact
  CAUTION    : the value on an ungrouped multiplexed run or an idle-diluted one; any
               instance-wide claim resting on one CPU{n} series
  CONFOUNDED : any reading of the metric as a COUNT of atomic operations -- the _SPEC suffix
               counts mispredicted attempts and every failed retry; and the reported value
               as a maximum, since ties keep the last point
  VOID       : any comparison across an arm64/x86 boundary (the metric exists on 1 of 8
               configs); any severity RANKING against other perf_stat findings, whose base
               scores differ by 8-16x; and the upstream `-Ctarget-features=+lse` line,
               which does not compile

INSUFFICIENT DATA
  IF the value is 5-10 and no finding fired
  THEN → below threshold. Since the count includes failed retries, a low value is decent
         evidence the atomics are both LSE-based and uncontended (P4, R0)
  IF the run is on x86 and the question was "are my atomics efficient?"
  THEN → aperf cannot answer it. No x86 config defines an atomic-instruction metric at all;
         a re-record on arm64 is the only path (P3, R0)
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 samples per series, and this rule needs only ONE above 10.0. A single
         contended startup interval is enough to fire it on an otherwise-clean run (P3, R0)
```

## Runtime-specific consequences

Atomic instruction selection is a property of **whoever compiled the code that runs** — which for three
of the four runtimes is not the application author.

- **Native code (C, C++, Rust, Go).** The only case where the reader's own flags are the fix, and the
  case the upstream guide addresses. Rust's flag is the one the guide gets wrong; Go does not accept
  `-march`-style tuning and selects atomics by GOARM64/runtime detection, so a Go binary showing STREX
  usually needs a newer toolchain rather than a flag.
- **Java.** `strex-spec-pki` here reflects the **JVM's own** compiled code — interpreter, JIT-generated
  code, and the runtime's internal locks — not bytecode you wrote. An old JVM build puts STREX in every
  monitor enter/exit. The fix is a JVM upgrade or a v8.1+ build (R2), never an application change. Use
  contended-monitor profiling (`--profile-java`) to establish whether *your* locks are the ones being
  contended before concluding the JVM is at fault.
- **Python, Ruby, Node and other interpreters.** The atomics belong to the interpreter binary and its
  extension modules, typically distro-packaged with a conservative baseline. Reference counting in
  CPython is a large source of atomic traffic in free-threaded builds. Your code cannot change the
  instruction selection; a rebuilt interpreter can.
- **Containers.** The image, not the host, determines the binary's baseline. A container built for
  `linux/arm64` on a generic baseline will issue STREX on Graviton3 all day. Check the image's build
  flags, not the instance.
- **Any runtime with a work-stealing scheduler** (Go, Tokio, ForkJoinPool) performs many uncontended-path
  atomics by design. A moderate value on such a workload is expected and does not imply a defect.

## Architecture-specific considerations

This finding is **arm64-only, and more narrowly defined than the registry's architecture list suggests.**

- **`strex-spec-pki` is defined in exactly one of the eight shipped PMU configs** —
  `src/pmu_configs/grv_pmu_config.json`, as `STREX_SPEC / Instructions * 1000` on event
  `armv8_pmuv3_0/event=0x6f/`. `grv_5_pmu_config.json` inherits it through `extend_from_default` (its
  overlay adds only `L3_READ` and redefines `l3-mpki`). No Intel or AMD config defines it or any
  equivalent, so on x86 **the rule cannot fire and no atomic-efficiency conclusion is available at all**.
- **LSE availability by part.** Graviton1 (A1, Cortex-A72, Armv8.0) has **no LSE** — STREX is the only
  option there and no flag helps. Graviton2 (Neoverse N1, v8.2), Graviton3 (V1), Graviton4 (V2) and
  Graviton5 all implement LSE. So the same finding means "unfixable" on A1 and "build defect" everywhere
  later.
- **`-march=armv8.2-a` is the guide's flag, but `-mcpu=` is usually better.** `-mcpu=neoverse-n1` /
  `-neoverse-v1` / `-neoverse-v2` enables LSE *and* tunes scheduling for the part. `-march=armv8.2-a`
  enables the ISA without the tuning. Either forecloses running on A1.
- **`is_graviton()` is `self.part.is_some()`** (`src/data/common/utils.rs:20`–`:100`) — **any** CPU
  exposing a `CPU part` line in `/proc/cpuinfo` is treated as Graviton, so a non-Graviton AArch64 part
  (Ampere, an on-prem Neoverse, an Apple VM) gets the Graviton event set. `STREX_SPEC` at `0x6f` is
  architectural in PMUv3, so it generally collects correctly — but a part that does not implement it
  drops the event with an `error!` at `:255` and the metric silently never appears.
- **`is_graviton_5()` checks part `0xd84`**; other Graviton generations are not distinguished, so the
  playbook cannot tell you from the report alone whether the part is N1 or V2. Read `CPU Model` from
  `systeminfo` for that.
- **The event is speculative on every part that has it.** There is no retired-store-exclusive counterpart
  in the shipped configs, so the retry inflation is not removable by choosing a different event.

## Verification

The falsifiable claim is narrow: *these specific instructions come from this specific object, and
changing its build flags removes them.* Verify in that order.

1. **Convert and bound.** `python3 tools/aperf_perf_stat.py --strex --pki N` gives percent of
   instructions, the score, both template traps, and the two corrected flag facts. Cross-check the
   recovered sample against `|score| × 0.625`.
2. **Read the series, not the description.** Per-CPU and `Aggregate`; establish sustained vs transient
   and find the true maximum, which the tie-break may have hidden.
3. **Check the mode before discounting anything.** `pmu_counter_mode` grouped ⇒ the magnitude is sound.
   Ungrouped ⇒ bound the value to `[V/F, V×F]` and treat a near-threshold reading as unproven.
4. **Attribute with `--profile`.** Name the function *and the object*. This is the step that decides
   whether a flag can work; skipping it is how this finding produces advice that changes nothing.
5. **Reproduce the upstream Rust defect in one command** if the reader has been given that guidance:
   `rustc -Ctarget-features=+lse` → `error: unknown codegen option`. Then confirm the singular form is
   accepted.
6. **Rebuild and disassemble before re-recording.** `objdump` the hot object and confirm
   `LDADD`/`SWP`/`CAS` where `LDXR`/`STXR` were. **If the disassembly did not change, the rebuild did not
   apply** — a stale artifact, a cached layer, or a prebuilt dependency — and re-recording will waste a
   cycle.
7. **Re-record and predict the direction.** `strex-spec-pki` should fall sharply. If it falls and
   `stall-backend-pkc` does **not**, the atomics were not the bottleneck and the severity claim was
   overstated — say so.
8. **For the contention branch, sweep thread count before changing code.** If throughput peaks below the
   core count, contention is the binding constraint; that is a config-level finding (R1) that no rebuild
   will deliver.

## Do not

- **Do not paste the upstream Rust flag.** `-Ctarget-features=+lse` (plural) is rejected by rustc as an
  unknown codegen option and **fails the build**. Use `-Ctarget-cpu=neoverse-n1`, or the singular
  `-Ctarget-feature=+lse`.
- **Do not repeat the guide's description of `-mno-outline-atomics`.** It says the flag *enables* calls to
  out-of-line helpers; `-mno-` **disables** them, inlining LSE. The flag is right, the sentence is
  inverted.
- **Do not recommend "rebuild with `-moutline-atomics`" as the fix.** It has been the GCC 10.1+ default
  on aarch64, so a firing finding means the binary already had the runtime check and still chose LL/SC.
  Look at the `-march` baseline, the toolchain vintage, or a prebuilt dependency instead.
- **Do not recommend a rebuild flag before locating the instructions.** If they come from a dependency, a
  runtime, or system libraries, your compiler flags change nothing.
- **Do not recommend `-march=armv8.2-a` on Graviton1.** The part has no LSE; the flag produces a binary
  that cannot run there and fixes nothing.
- **Do not treat the reported value as the run's average, or as a maximum.** It is one qualifying data
  point from any series including per-CPU, and ties keep the *last* one.
- **Do not read the count as the number of atomic operations performed.** The `_SPEC` event counts
  mispredicted attempts and every failed retry. Never convert it to atomics-per-second.
- **Do not let the score set the priority order uncritically.** `Poor` (−16) makes a just-at-threshold
  value score −16.00, larger than any cache or TLB finding reaches. It flags a cheap fix, not the
  dominant cost. Confirm with the stall split.
- **Do not compare this score with any other `perf_stat` finding.** The base scores differ by 8–16×.
- **Do not discount the value for grouped-mode multiplexing.** The factor cancels; the magnitude stands.
  Only ungrouped mode can skew it.
- **Do not treat the rebuild as risk-free.** Raising the baseline narrows the hardware the binary can run
  on. That is R3 with a deployment blast radius, not a free win.
- **Do not stop at the flag when the rate is very high.** LSE removes the retry loop; the underlying
  contention still costs coherence traffic and needs an algorithmic fix.
- **Do not carry this finding to non-Arm hosts.** The metric exists in 1 of 8 configs; its absence on x86
  is structural and says nothing about atomic efficiency.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:131`–`:138` (`Comparator::GreaterEqual`, threshold
  `10.0`, `Score::Poor`).
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — per-CPU
  iteration and the `>=` tie-break that keeps the *last* tied point.
- Metric and event: `src/pmu_configs/grv_pmu_config.json` — `strex-spec-pki = STREX_SPEC / Instructions
  * 1000`, event `armv8_pmuv3_0/event=0x6f/`. Inherited by `grv_5_pmu_config.json` via
  `extend_from_default` (`src/data/perf_stat.rs:200`).
- Upstream guide **with two verified defects**: `LSE_OPTIMIZATION`,
  `src/report_frontend/src/definitions/optimization-guides.ts:109`–`:115` — the plural
  `-Ctarget-features` that rustc rejects, and the inverted description of `-mno-outline-atomics`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`. Value formatting:
  `formatted_number_string`, `src/computations/mod.rs:176`–`:190` (K suffix above 1e3).
- CPU detection: `src/data/common/utils.rs:20`–`:100` — `is_graviton()` is `self.part.is_some()`;
  `is_graviton_5()` checks part `0xd84`.
- Quantifier: [`../tools/aperf_perf_stat.py`](../tools/aperf_perf_stat.py) `--strex --pki N`;
  `tools/test_aperf_perf_stat.py` pins the flag corrections, including the literal `rustc` error text.
- [Graviton — Large System Extensions (LSE)](https://aws.github.io/graviton/c-c++.html#large-system-extensions-lse)
- [Arm Neoverse V2 — `STREX_SPEC` event](https://developer.arm.com/documentation/109528/0200/PMU-events-by-functional-group-in-Neoverse-V2/Spec-Operation--SPEC-OPERATION--events-for-Neoverse-V2?lang=en#md761-spec_operation_fg__STREX_SPEC_e)
- [GCC AArch64 options — `-march`, `-mcpu`, `-moutline-atomics`](https://gcc.gnu.org/onlinedocs/gcc/AArch64-Options.html#index-march)
- [rustc codegen options — `-Ctarget-feature`, `-Ctarget-cpu`](https://doc.rust-lang.org/rustc/codegen-options/index.html#target-feature)
- Related playbooks: `pmu-counter-collection-multiplexing.md` (the confidence gate, and why grouped mode
  does not weaken this value), `backend-dominated-cpu-stalls.md` (the severity gate),
  `reduced-instructions-per-cycle.md`, `high-branch-mispredictions.md`.
