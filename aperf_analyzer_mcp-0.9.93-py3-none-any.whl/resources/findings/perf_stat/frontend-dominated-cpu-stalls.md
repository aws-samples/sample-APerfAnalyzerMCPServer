---
rule_name: Frontend-Dominated CPU Stalls
data_type: perf_stat
data_key: stall-frontend-pkc
template: time_series_stat_intra_run_comparison
condition: "(avg(stall-frontend-pkc) - avg(stall-backend-pkc)) / avg(stall-backend-pkc) >= 0.1"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "Higher CPU frontend stalls indicate bottlenecks on instruction fetches instead of executions, usually due to speculating the wrong destination for a branch, or getting stalled when fetching instructions from memory. Check the related misprediction metrics for instructions."
source: src/analytics/rules/perf_stat.rs:29
---

# Frontend-Dominated CPU Stalls

## What fired

Within **this single run**, the average of `stall-frontend-pkc` exceeded the average of
`stall-backend-pkc` by **at least 10%** in relative terms.

This is an **intra-run** comparison — `time_series_stat_intra_run_comparison` compares two
*metrics against each other inside one run*, not one run against another. **It needs only one
run** (`requires_comparison: false`), which makes it one of the most broadly applicable
`perf_stat` findings. Base score `Concerning` (−1), filed under the `stall-frontend-pkc` key.

## Reasoning

Every CPU cycle either retires instructions or stalls. Both stall metrics count stalled cycles
per thousand cycles (`pkc`), so together they account for the cycles that produced nothing.
`stall-frontend-pkc` is *"Cycle count that were stalled due to resource constraints in the
frontend unit of the processor per thousand cycles. CPU frontend is responsible for fetching,
predicting, and decoding instructions into micro-operations, before they are sent to the backend
for execution."* (`data-descriptions.ts`, `desired: "lower"`); `stall-backend-pkc` is the same
for the execution side.

This rule answers one question: **which side of the pipeline is the bottleneck?** That
determines the entire remediation path, and the two paths share almost nothing. It is step 2 of
the top-down method, immediately after `ipc`.

Frontend dominance means the CPU **could not supply instructions fast enough to keep the
execution units fed**. The machine was not waiting on data; it was waiting on *code*. There are
four causes, and each has its own metric:

1. **Branch mispredictions** (`branch-mpki`) — the CPU speculated a wrong target, ran down the
   wrong path, and paid the full frontend latency to flush and refill.
2. **Instruction cache misses** (`inst-l1-mpki`) — the code working set does not fit in L1I, so
   fetches go to L2 or further.
3. **Instruction TLB misses and table walks** (`inst-tlb-mpki`, `inst-tlb-tw-pki`) — the
   virtual→physical translation for the *instruction* address is not cached, so the fetch waits
   on a page-table lookup.
4. **Sparse code layout** (`code-sparsity`) — hot code scattered across many pages and cache
   lines wastes every fetch and TLB entry, and degrades prediction.

The common theme — and the thing that makes frontend problems tractable — is that they are
**properties of the binary and its layout**, not of the data. That is why the remediations are
compiler and JIT flags (`-flto`, `-Os`, FDO/AutoFDO, JVM code-cache sizing) rather than
algorithmic changes. Big C++ binaries with heavy templating, deep virtual dispatch,
interpreters, and JIT-compiled runtimes are the usual candidates.

**Crucially, this rule is a comparison of two stall counts, not a statement that stalling is
high.** A run with 20 frontend stalls and 15 backend stalls per thousand cycles fires it. So
does a run with 600 and 400. The first is a healthy CPU; the second is severely bottlenecked.
The finding cannot tell them apart, so reading the absolute values is mandatory. The two
counters also **overlap in reality** — out-of-order cores hide some frontend latency behind
backend work and vice versa — so they are not a clean partition and need not sum to 1000.

## Reading the description

`time_series_stat_intra_run_comparison` emits — note that **both placeholders are metric
names, not run names**:

```
The {stat} in {comparison_metric} ({value}) is {pct} {baseline_metric} ({base_value}).

The average in stall-frontend-pkc (420.15) is 42.00% greater than stall-backend-pkc (295.88).
```

**Five things that sentence does not tell you.**

1. **`pkc / 10` is percent-of-cycles, and that conversion is the whole severity story.** Both
   metrics count stalled cycles per *thousand* cycles, so `420.15` means the frontend held
   **42.0%** of every cycle the CPU executed and `295.88` means the backend held **29.6%**. Do
   this division first: it turns a number with no intuition attached into the fraction of the
   machine that produced nothing.
2. **The percentage is the ratio between them, not a magnitude.** `42.00% greater than` says
   frontend/backend ≈ 1.42, and nothing about whether either side is large. A run at 20 vs
   15 pkc (2.0% and 1.5% of cycles — a healthy CPU) prints the same relation word as one at 600
   vs 400 (60% and 40% — a machine mostly not working).
3. **Both placeholders are metric names.** Unlike every other comparison template's output,
   neither position holds a run name. A reader scanning for "which run" finds a metric and
   mis-attributes the finding to a cross-run comparison; it is intra-run and needs only one run.
4. **The averages come from the `Aggregate` series, which is a ratio of *summed* counters**
   (`src/data/perf_stat.rs:1118`–`:1148`) — stall cycles summed across CPUs over cycles summed
   across CPUs, divided once. That weights busy CPUs correctly and needs **no CPU-count
   correction**, but one CPU stalling at 900 pkc while fifteen sit at 50 pkc reads as a
   comfortable aggregate. Read the per-CPU (`CPU{n}`) series first.
5. **Both numbers are truncated, not rounded** (`f64_to_fixed_2`,
   `src/computations/mod.rs:138`), so `420.15` is anything in `[420.15, 420.16)`.

Score math — `compute_finding_score(cur_ratio, 0.1, −1)` where
`cur_ratio = (frontend − backend) / backend`:

| frontend excess | score | recovered `\|score\|/10` |
|---|---|---|
| +10% (0.10) | `(0.10/0.1) × −1` = **−1.00** | 0.10 |
| +42% (0.42) | `(0.42/0.1) × −1` = **−4.20** | 0.42 |
| +100% (1.0) | `(1.0/0.1) × −1` = **−10.00** | 1.00 |
| +300% (3.0) | `(3.0/0.1) × −1` = **−30.00** | 3.00 |

Recover the ratio as `cur_ratio = |score| / 10`. The score is a linear restatement of the ratio
and therefore inherits its blindness to magnitude entirely.

**Every other sentence this rule can produce**, including the two that are silences:

| Situation | What you get |
|---|---|
| `avg(stall-backend-pkc)` is exactly `0.0` | the template substitutes `cur_ratio = 1.0` (`time_series_stat_intra_run_comparison_rule.rs:90`–`:92`) rather than dividing by zero: a **fixed score of −10.00** and text reading `100.00% greater than stall-backend-pkc (0)`. For this `GreaterEqual` rule the substitution **always fires**. A backend stall average of exactly zero is implausible on real hardware — read it as a collection problem, not a frontend bottleneck |
| The two sides are within 10% of each other | **nothing.** The dead zone is exactly `be/fe ∈ (1/1.1, 1.1)`, verified by exhaustive sweep over 159,201 `(fe, be)` pairs: neither stall rule fires, however high *both* stalls are. A pipeline at 600/600 pkc — 60% of cycles lost on each side — produces no stall finding at all |
| Backend dominates instead | `Backend-Dominated CPU Stalls` fires and this one does not. The same sweep confirms **zero double-fires**: the two are mutually exclusive by construction |
| `stall-frontend-pkc` or `stall-backend-pkc` absent | the rule returns early; no finding. On the generic `amd` PMU profile `stall-backend-pkc` **does not exist**, so both stall rules are structurally silent there |

## Interpretation

**Absolute magnitude first** — the finding is a ratio and hides this entirely. `pkc` is per
thousand cycles, so 1000 would be a fully stalled CPU: below **100** frontend stalling is minor
and the finding is directional information only; **100–300** is moderate and worth pursuing only
if IPC is also low; **300–600** is a substantial bottleneck with real headroom; above **600** the
CPU spends most of its cycles unable to fetch instructions.

Then cross-check `ipc`. **The pair of readings is what matters:**

| `ipc` | frontend-dominated | Reading |
|---|---|---|
| High (> 2) | yes | Pipeline is working well despite the imbalance. Low priority |
| Low (< 1) | yes | **The actionable case.** Frontend is the confirmed bottleneck; pursue the instruction-footprint path |
| Falling vs base run | yes | Combine with `Reduced Instructions per Cycle`: this localizes that regression to the frontend |

**Known false positives — check these before recommending compiler changes:**

- **Both stall counts are low.** The dominant false positive. A 10% excess over a small number
  is not a bottleneck — and a tight microbenchmark loop that fits entirely in L1I with perfectly
  predicted branches produces exactly that. Always read the absolute values from the description.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, both stall counters are
  extrapolated, and — being two separately-scheduled counters — they may have been sampled in
  *different* time slices, so the comparison's **direction** can invert. That is a more serious
  concern for intra-run metric-vs-metric comparisons than for single-metric findings.
- **Idle-dominated or throttled run.** If `Underutilized CPU` fired, both counters are diluted
  with idle-loop behaviour, which has its own unrepresentative stall profile. `pkc` is per
  *cycle* and so frequency-independent, but a throttled CPU (T-family out of credits, thermal)
  executes fewer cycles overall, so the same `pkc` is less absolute impact.
- **Startup / JIT phase captured, or an interpreted workload.** Class loading, dynamic linking,
  and JIT compilation are genuinely frontend-heavy — cold code, first-touch fetches, poor layout
  — so a window including startup shows dominance the steady state does not have. Interpreter
  dispatch loops and JIT-compiled code are frontend-bound by design: improvable via code-cache
  sizing, but not a defect.

## Corroborating data

aperf's own message says to "check the related misprediction metrics for instructions". Those
are exactly the five metrics in `CPU_FRONTEND_STALLS_INVESTIGATION`:

| Check | Data type | What it tells you |
|---|---|---|
| `branch-mpki` | `perf_stat` | Mispredicted branches flushing the pipeline. See `High Branch Mispredictions` (fires ≥10.0) |
| `inst-l1-mpki` | `perf_stat` | Code footprint spilling out of L1I. See `High L1 Instruction Cache Misses` (fires >20.0) |
| `inst-tlb-mpki`, `inst-tlb-tw-pki` | `perf_stat` | Instruction-address translation misses, and the page-table walks that are their expensive tail. Both rules fire on *any* non-zero value |
| `code-sparsity` | `perf_stat` | How compactly hot code is packed. See `High Code Sparsity` (fires >0.5) |
| `stall-backend-pkc` | `perf_stat` | The other half of the comparison — read its absolute value, not just the ratio |
| `ipc` | `perf_stat` | **Severity gate.** Frontend dominance with healthy IPC is informational; with low IPC it is the bottleneck |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ the two counters may not be comparable |
| `idle`, `user`, `system` | `cpu_utilization` | Dilution check; heavy `system` time means much of the measured code is kernel code, whose footprint you do not control the same way |
| On-CPU profile | `perf_profile` / `java_profile` | Which code is executing — needed to know *whose* footprint to shrink. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | Instruction-level attribution for native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |
| `Excessive Exceptions` | `java_profile` | JVM exception churn generates unpredictable control flow and cold code paths — a frontend-stall contributor |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | THP can back text pages on newer kernels, reducing instruction-TLB pressure. See `Huge Page Disabled` |

## Guidance

Ordered. Steps 1–2 decide whether this is worth pursuing at all; most firings of this rule are
directional information, not bottlenecks.

1. **Read the two absolute stall values from the description** and divide by 10 for
   percent-of-cycles. If `avg(stall-frontend-pkc)` is low (roughly < 100 pkc), state that the
   pipeline is not stall-bound and that this finding only indicates *which* side is marginally
   larger. Do not proceed to compiler changes.

2. **Gate on measurement confidence.** Check `mux_counter_schedule_rate`
   (`PMU Counter Collection Multiplexing`) and `avg(idle)` (`Underutilized CPU`). Multiplexing
   is especially corrosive here because the two counters being compared may have been sampled
   in different time slices — a low schedule rate can invert the comparison.

3. **Cross-check `ipc` to establish severity.** Low IPC + frontend dominance = the confirmed,
   actionable case. Healthy IPC + frontend dominance = note and move on. If
   `Reduced Instructions per Cycle` also fired, this finding is the localization of that
   regression — say so explicitly.

4. **Walk the four frontend causes in order of specificity**, reading the metrics even where no
   companion finding fired: `branch-mpki` high ⇒ unpredictable control flow (data-dependent
   branching, deep virtual dispatch, large switch/jump tables, polymorphic call sites);
   `inst-l1-mpki` high ⇒ the hot code does not fit in L1I, a footprint problem;
   `inst-tlb-mpki` / `inst-tlb-tw-pki` non-zero ⇒ the code spans more pages than the ITLB
   covers, so huge pages for text; `code-sparsity` > 0.5 ⇒ hot code is scattered, a layout
   problem. If **none** stands out, the stalls are spread thin and the fix is general footprint
   reduction rather than one targeted change.

5. **Check the timeline before attributing to steady state.** Plot both stall series; dominance
   confined to the start of the run is startup/JIT warm-up. Re-scope with `--time-range` and
   re-evaluate.

6. **Identify whose code it is.** With `--profile`, determine whether the frontend-heavy code
   is application code, a library, the runtime/interpreter, or the kernel — the remediation
   differs completely. For native code on metal Graviton, `hotline` gives instruction-level
   attribution.

7. **Only then remediate**, per `INSTRUCTION_FOOTPRINT_OPTIMIZATION`. For **C/C++**, `-flto` and
   `-Os`, and [AutoFDO](https://gcc.gnu.org/wiki/AutoFDO/Tutorial) for profile-guided layout. For
   **Java**, size the code cache — `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M`,
   raising from there, since a `code cache full` message means it is too small — and try
   `-XX:+TieredCompilation`. For **translation-driven** cases, apply `TLB_MISS_OPTIMIZATION`
   (THP, folios on kernels ≥ 6.9, reserved huge pages).

8. **Quantify the split, and correct it if the profile requires it.**
   `tools/aperf_perf_stat.py --stalls --frontend-pkc F --backend-pkc B --profile P` does the
   percent-of-cycles conversion, states the verdict, and applies the per-profile normalisation:

   ```
   $ python3 tools/aperf_perf_stat.py --stalls --frontend-pkc 420.15 --backend-pkc 295.88 --profile grv
   Frontend stalls consume 42.0% of cycles and backend stalls 29.6% (420.15 and 295.88 per
   thousand cycles) on graviton (<=4). Backend/frontend is 0.42, so Frontend-Dominated CPU
   Stalls fires: the frontend is the bottleneck and holds 42.0% of all cycles.
   ```

   On `genoa`, `icelake` and `spr` the same call reports the two sides as **incommensurable** and
   corrects the backend value — which frequently reverses the verdict. Never report this
   finding's direction on those profiles without running it.

## Priority and execution risk

**Priority: P3 — Monitor** by default, which is lower than the finding's `Concerning` framing
suggests: a ≥10% excess over a small backend number is arithmetic, not a bottleneck. It rises to
**P2 — Investigate** once `avg(stall-frontend-pkc)` is above roughly 300 pkc (30% of cycles), and
to **P1 — Act now** when that holds *and* `ipc` is low *and* one of the four frontend causes is
clearly elevated — at which point the remediation is a compiler or JIT flag with a known payoff.
It drops to **P4 — Informational** on an interpreted or JIT-hosted workload, which is
frontend-bound by design. It stays at **P3** whenever the run multiplexed, because the two
counters may have been scheduled in different slices and the *direction* can invert.

**Execution risk: R0 — Read-only** to diagnose: the split, the percent-of-cycles conversion, the
four companion metrics, and the per-profile correction are all reads. Acting on the outcome is
**R3 — Rebuild** for the dominant remediation (`-flto`, `-Os`, AutoFDO, a different `-march`),
**R2** for a JVM code-cache or tiered-compilation flag, **R4** where the fix is huge pages for
text or an instance change, and **R5** where hot-path code is restructured to reduce branch
entropy. **Do not inherit the R0 of the split into the rebuild:** a profile-guided rebuild
changes the binary that runs in production, and the verification is a re-record, not a re-read.

**The score is amplified, restates the ratio, and is blind to severity in a way that matters more
here than anywhere else in `perf_stat`.** It is exactly `cur_ratio / 0.1 × −1`, so
`cur_ratio = |score| / 10` — and because `cur_ratio` is a *ratio between two stall counts*, the
score is insensitive to how much stalling occurred. A run at **20 vs 15 pkc** (a healthy CPU
losing 2% of cycles to the frontend) scores `−3.33`, while a run at **600 vs 580 pkc** (60% of
cycles lost, a severely bottlenecked machine) scores `−0.34` — **ten times milder**. The
healthier machine ranks worse. On top of that, `Concerning` (−1) puts every firing 16× below
`Old-Style Atomic Instructions` and `Reduced Instructions per Cycle` in the Analytical Findings
panel regardless of value. **Rank on `pkc/10`, never on score.** One score is worth recognizing
on sight: **exactly `−10.00`** may be the zero-backend substitution, not a real 100% excess.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: within one run, `avg(stall-frontend-pkc)` exceeded `avg(stall-backend-pkc)` by
at least 10% relative (`GreaterEqual 0.1` on `(fe − be) / be`, so exactly +10% does fire).

```
STEP 0 — Does the perf_stat data exist, and can this rule fire on this profile?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves
         nothing about the pipeline. aperf needs bare metal or an instance family
         exposing a virtualized PMU (P3, R0)
  IF the run is on the generic `amd` PMU profile
  THEN → `stall-backend-pkc` does not exist there, so BOTH stall rules are
         structurally silent. COULD NOT FIRE — go straight to the *-mpki family
         for direction (P3, R0)
  IF the profile is `genoa`, `icelake` or `spr`
  THEN → the two metrics are NOT commensurable; the reported direction may be
         wrong. Correct the backend value BEFORE STEP 1 — see the architecture
         section, and the full branches: run
         `tools/aperf_perf_stat.py --stalls --profile <p>`
  ELSE continue.

STEP 1 — Convert to percent-of-cycles FIRST. This decides whether anything below
         matters.
  Parse: The {stat} in {comparison_metric} ({value}) is {pct} {baseline_metric}
         ({base_value}).   Both placeholders are METRIC names, not run names.
  pkc / 10 = percent of all cycles. Recover the ratio as |score| / 10.

  IF avg(stall-frontend-pkc) < 100 pkc (under 10% of cycles)
  THEN → NOT a bottleneck. The finding is directional information only: which side
         is marginally larger on a pipeline that is barely stalling. Report and
         STOP — do not open a compiler flag discussion (P4, R0)
  IF 100-300 pkc (10-30% of cycles)
  THEN → moderate. Worth pursuing only if `ipc` is also low; continue to STEP 2
         and re-check at STEP 3 (P3, R0)
  IF 300-600 pkc (30-60% of cycles)
  THEN → substantial frontend bottleneck with real headroom; continue (P2, R0)
  IF > 600 pkc (over 60% of cycles)
  THEN → severe: the CPU spends most of its cycles unable to fetch instructions,
         and a layout or footprint fix pays for itself (P1, R0)
  IF the score is exactly -10.00
  THEN → suspect the zero-backend substitution (time_series_stat_intra_run_comparison_rule.rs:90):
         avg(stall-backend-pkc) was 0.0 and the ratio was hardcoded to 1.0. Read
         the base_value in the text — a literal `(0)` confirms it (P3, R0)
       → verify: a backend stall average of exactly zero is implausible on real
         hardware. Check `mux_counter_schedule_rate` and whether the counter was
         collected at all; treat as a collection defect, not a frontend finding

STEP 2 — Gate on measurement confidence. Multiplexing is more corrosive to THIS
         rule than to any single-metric one.
  IF `mux_counter_schedule_rate` < 100
  THEN → the two counters are separately scheduled, so they may have been sampled
         in DIFFERENT time slices and the comparison's direction can invert.
         Report low-confidence rather than acting (P3, R0)
       → run `tools/aperf_perf_stat.py --mux --rate R` for the extrapolation
         factor; at 33.3% every value is scaled 3.00x from a third of the window
       → verify: re-record with `--ungroup-pmu-events` or a smaller
         `--pmu-config`; if the direction FLIPS, the original split was noise
  IF `Underutilized CPU` fired
  THEN → both counters are diluted with idle-loop behaviour, which has its own
         unrepresentative stall profile (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; the split
         should sharpen, and a direction change means the idle loop drove it

STEP 3 — Cross-check `ipc` to establish whether the imbalance is costing anything.
  IF `ipc` > 2 with frontend dominance
  THEN → the core is absorbing it. Note the direction and move on (P4, R0)
  IF `ipc` < 1 with frontend dominance
  THEN → the ACTIONABLE case: frontend is the confirmed bottleneck. Continue to
         STEP 4 (P1, R0)
  IF `Reduced Instructions per Cycle` also fired
  THEN → this finding is the LOCALIZATION of that regression. Say so explicitly;
         the two are one finding reported twice (P1, R0)
       → note the IPC rule needs two runs and this one needs one, so this is
         readable even when the comparison is void

STEP 4 — Walk the four frontend causes in order of specificity. Read the metrics
         even where no companion finding fired.
  IF `branch-mpki` >= 10 (`High Branch Mispredictions`)
  THEN → unpredictable control flow: data-dependent branching, deep virtual
         dispatch, large switch/jump tables, polymorphic call sites (P2, R3)
       → quantify with `tools/aperf_perf_stat.py --branch --mpki M --profile P`:
         at 25 mpki on grv that is ~275 cycles lost per thousand instructions
       → verify: after the fix, branch-mpki falls AND stall-frontend-pkc falls.
         If mpki falls and the stall does not, mispredictions were not the driver
  IF `inst-l1-mpki` > 20 (`High L1 Instruction Cache Misses`)
  THEN → the hot code does not fit in L1I: an instruction-FOOTPRINT problem, so
         the lever is size, not layout (P2, R3)
       → verify: rebuild with `-Os`/`-flto`, then inst-l1-mpki and
         stall-frontend-pkc both fall
  IF `inst-tlb-mpki` or `inst-tlb-tw-pki` is non-zero
  THEN → the code spans more pages than the ITLB covers. Distinct, often cheap
         fix: huge pages for text. Note these rules fire on ANY non-zero value,
         so read the magnitude before acting (P2, R4)
       → verify: `CONFIG_TRANSPARENT_HUGEPAGE` enabled and, after the change,
         inst-tlb-tw-pki drops toward zero — the table walks are the expensive tail
  IF `code-sparsity` > 0.5 (`High Code Sparsity`)
  THEN → hot code is scattered: a LAYOUT problem. Linker ordering, AutoFDO (P2, R3)
       → verify: code-sparsity falls and branch-mpki usually falls with it — layout
         improves prediction and fetching together
  IF NONE of the four stands out
  THEN → the frontend stalls are spread thin across all four causes. The fix is
         general footprint reduction rather than one targeted change (P3, R3)
       → verify: `-flto` plus AutoFDO is the broad lever; re-record and expect a
         modest fall in all four metrics rather than a large fall in one

STEP 5 — Check the timeline before attributing to steady state.
  IF frontend dominance is confined to the START of the run
  THEN → startup, class loading, dynamic linking, or JIT warm-up — all genuinely
         frontend-heavy, none of it steady-state behaviour (P4, R0)
       → verify: re-report with `--time-range` scoped past warm-up. If the finding
         disappears, nothing needs remediation
  IF dominance is sustained across the whole window
  THEN → representative; continue to STEP 6 (P2, R0)
  IF only a few CPU{n} series show it
  THEN → one or two threads, not the instance; the Aggregate ratio of sums hid it
         (P3, R0)
       → verify: correlate with the on-CPU profile to identify the thread; a fix
         targeted at one thread will not move the aggregate much

STEP 6 — MANDATORY manual check: whose code is it? Needs `--profile`; aperf
         cannot answer it from metrics, and the answer decides who owns the fix.
  IF it is APPLICATION code you build
  THEN → your compiler flags apply: INSTRUCTION_FOOTPRINT_OPTIMIZATION (P2, R3)
       → verify: re-profile; the hot stacks shift and stall-frontend-pkc falls
  IF it is a RUNTIME or interpreter (JVM, CPython, Perl)
  THEN → frontend-bound by design; the levers are runtime flags, not your source
         (P3, R2)
       → verify: for Java a `code cache full` message means the cache must be
         larger; after sizing it, stall-frontend-pkc falls
  IF it is KERNEL code (high `system` in cpu_utilization)
  THEN → you do not control its footprint. Reduce syscall rate instead (P3, R2)
       → verify: batching, io_uring, or larger buffers lower `system` time and the
         frontend stall together
  IF no `--profile` data exists
  THEN → STOP. Any compiler-flag recommendation from here is speculative; the
         honest deliverable is a re-record with `--profile` (P2, R0)

STEP 7 — What survives?
  VALID      : the two absolute pkc values and the four frontend metrics, read as
               magnitudes; every non-PMU finding in the run
  CAUTION    : the DIRECTION of this finding when the run multiplexed, and on
               `genoa`/`icelake`/`spr` where the two metrics are not commensurable
  CONFOUNDED : the split on an idle-diluted run, and any steady-state claim from a
               window that included warm-up
  VOID       : any claim that stalling is HIGH on the strength of this finding
               alone — it is a ratio; and any cross-architecture reading of the
               split, since the backend metric is redefined per profile

INSUFFICIENT DATA
  IF NEITHER stall finding fired
  THEN → the two sides are within 10% (dead zone be/fe in (1/1.1, 1.1)). This is
         NOT evidence of a healthy pipeline: 600 pkc on both sides is 60% of
         cycles lost on each and produces no finding (P2, R0)
       → read both absolute values and `ipc` directly; the top-down method simply
         gives no direction here
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. The average is readable but no percentile is:
         p90 and above are all the same single sample (P3, R0)
```

## Runtime-specific consequences

Frontend stalls are a property of the *instruction stream*, so the runtime matters more here than
for any other `perf_stat` finding: three of the four runtimes generate their own instruction
stream at run time, so the footprint you would optimize is not the one you compiled.

| Runtime | Why the frontend stalls, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **.NET** | Tiered JIT produces two bodies for every hot method, so the code footprint is larger than the source suggests, and tier-0→tier-1 promotion invalidates I-cache lines mid-run. R2R/AOT images are larger but laid out once | `DOTNET_TieredCompilation`, `DOTNET_TieredPGO` (which lays out hot paths from observed profiles — the .NET equivalent of AutoFDO), and whether the window covered promotion. ReadyToRun trades footprint for layout stability |
| **Python** | CPython's eval loop is a single indirect branch per opcode — **structurally** frontend-bound, and not a defect. The interpreter itself is small and stays in L1I; what spills it is a large C-extension surface | Whether the hot path is bytecode or a native extension. A footprint fix targets the extension, never the Python. Computed-goto builds (default since 3.11's specializing interpreter) already reduce the mispredict rate |
| **Java** | The largest real case. JIT'd code lives in the code cache, and if the cache is too small the JVM flushes and recompiles continuously — a permanent frontend stall with no source-level cause. Class loading and deoptimization are frontend-heavy by nature | `jvmArguments` in the profile metadata. Size the code cache: `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M` and raise from there; a `code cache full` message means it is too small. `-XX:+TieredCompilation` changes how many bodies exist per method |
| **Perl** | A tree-walking interpreter: the op dispatch is a small, hot loop that fits L1I easily, so Perl is usually **backend**-bound (pointer chasing between ops) rather than frontend-bound. Frontend dominance in a Perl workload points at a large XS/native surface, not at Perl | The XS module set and `perl -V` build options. There is no code cache or JIT tier to tune, which makes a frontend finding here more likely to be genuinely about a linked C library |

**The unknown-runtime case is the default** — aperf reports no language field and the runtime is
inferred from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it
cannot be identified, stop at STEP 6's profile check: "whose code is it" is runtime-independent
and is what actually gates the remediation. For **all four**, dominance confined to the first
seconds is warm-up, and the fix is `--time-range`, not a rebuild.

## Architecture-specific considerations

This finding fires on **7 of 8** PMU profiles — registry `architectures`: `arm64`,
`arm64_graviton5`, `intel`, `intel_icelake`, `intel_sapphire_rapids`, `amd_milan`, `amd_genoa`.
The registry's `architecture_note` states the two problems exactly: *"Generic AMD has no
`stall-backend-pkc`, which silences both stall rules. Normalisation differs on `intel_icelake`,
`intel_sapphire_rapids` (Slots) and `amd_genoa` (*167)."*

**`stall-frontend-pkc` is defined identically on every profile that has it** —
`Frontend_Stalls / Cycles * 1000` — so the metric this rule is filed under is portable.
**`stall-backend-pkc` is not**, and since this rule is a comparison, a non-portable denominator
makes the *verdict* non-portable:

| Profile | `stall-backend-pkc` definition | Consequence for this finding |
|---|---|---|
| `grv`, `grv5`, `intel`, `milan` | `Backend_Stalls / Cycles * 1000` | commensurable with the frontend metric; the ratio is meaningful as printed |
| `icelake`, `spr` | `Backend_Stalls / Slots * 1000` | per-**issue-slot**, not per-cycle. The correction factor is the machine width — 5 on Ice Lake, 6 on Sapphire Rapids — and the quantifier module deliberately **refuses to invent it**, reporting the pair as incommensurable instead |
| `genoa` | `Backend_Stalls / Cycles * 167` | the backend side is understated by exactly `1000/167 = 5.99×`. A raw reading of 300 fe / 100 be looks frontend-dominated; corrected, backend is **598.80 pkc (59.9% of cycles)** and the verdict **flips to backend-dominated** |
| `amd` (generic) | **absent** | neither stall rule can fire. The silence is structural and says nothing about the pipeline |

So on three of the seven profiles where this rule *can* fire, a firing may be an artifact of the
metric definition rather than of the workload. Run
`tools/aperf_perf_stat.py --stalls --frontend-pkc F --backend-pkc B --profile <p>` before
reporting the direction; on `genoa` it corrects the value, and on `icelake`/`spr` it tells you
the comparison cannot be made from aperf data alone.

**The frontend causes themselves are not equally available.** `code-sparsity` exists in only two
of the eight profiles, so STEP 4's fourth branch is unreadable on the rest — its absence is not
evidence of good layout. `branch-mpki` exists everywhere but means different things: arm64 counts
`BR_MIS_PRED` (`0x10`), a **speculative** event, over a retired-instruction denominator, while
Intel uses `BR_MISP_RETIRED` (`0xC5`) and AMD `0xC3`, both retired — so arm64 reads
systematically higher for identical source and the uniform threshold of 10.0 is not
architecture-neutral. Compounding this, aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with
matched `CPUs` and `MemTotal` fires **no gate**, yet the denominator changed definition, so
"frontend stalls improved" across that pair is not a measurement.

**Counter mode changes whether this rule is trustworthy at all.** Grouped is the default
(`src/data_collection.rs:379`) and creates one counter per event *per metric group*
(`src/data/perf_stat.rs:217`–`:221`), roughly doubling register pressure versus
`--ungroup-pmu-events`; `probe_pmu_counter_limit` (`:344`) binary-searches the limit, bounded to
16. Because the two stall counters are separately scheduled, a low schedule rate can invert this
comparison specifically — the failure mode is a wrong *direction*, not merely an imprecise
magnitude ([../ARCHITECTURE.md](../ARCHITECTURE.md) §3.4). And the highest-leverage remediation
here is invisible to every aperf metric: a generic `-march=armv8-a` binary on Graviton 3, or a
framework built for another vendor's kernels (`microsoft/onnxruntime` versus
`amd/ZenDNN-onnxruntime`), runs a different instruction stream with a different footprint. That
is **R3 — rebuild**, and STEP 6's profile check is the only way to reach it.

## Verification

Apply the fix STEP 4 localized, re-record at the **same geometry, same counter mode, and same
instance type**, and check the pair rather than either number alone: the cause metric should fall
(`branch-mpki`, `inst-l1-mpki`, `inst-tlb-tw-pki`, or `code-sparsity`) **and**
`avg(stall-frontend-pkc)` should fall with it in absolute pkc. If the cause metric falls and the
stall does not, that cause was not driving the stall and the remaining three branches are still
open. If `stall-frontend-pkc` falls but the finding *persists*, the backend fell too and the
ratio survived — check the two absolute values, because a shrinking bottleneck can keep firing a
ratio rule indefinitely. The finding disappearing while both values stay high means the pipeline
entered the dead zone, which is not an improvement. This finding **cannot be verified by score**:
a healthier machine can score worse (20 vs 15 pkc scores `−3.33`; 600 vs 580 scores `−0.34`). The
only verification that means anything is the absolute `pkc/10` percentage moving in the right
direction, and on `genoa`/`icelake`/`spr` it must be the *corrected* backend value on both sides.

## Do not

- **Do not treat this as evidence that stalling is high.** It is a *ratio between two stall
  counts*. Both can be small. Read the absolute `pkc` values.
- **Do not skip the `pkc / 10` conversion.** It is the only step that turns the finding into a
  severity: `420.15 pkc` is 42% of every cycle the CPU executed, and `20 pkc` is 2%. The rule
  reports both identically.
- **Do not rank this finding by score.** The score is the ratio restated, so a healthy machine
  at 20 vs 15 pkc scores `−3.33` while a severely bottlenecked one at 600 vs 580 scores `−0.34`
  — ten times milder. And `Concerning` (−1) puts every firing 16× below the `Poor` findings
  regardless of value.
- **Do not confuse this with a run-to-run comparison.** It is intra-run: two metrics inside one
  run. Both description placeholders are metric names, nothing about a base run is involved, and
  it fires with a single run. Nor should you **expect the two metrics to sum to 1000** —
  out-of-order execution overlaps the two stall kinds; they are not a partition.
- **Do not act on the comparison when `mux_counter_schedule_rate` is well below 100.** The two
  counters are separately scheduled, so multiplexing can invert the *direction* here — not just
  blur the magnitude.
- **Do not read the direction on `genoa`, `icelake`, or `spr` without correcting it.** Genoa
  understates the backend by exactly `5.99×`, which flips a 300/100 reading to backend-dominated;
  Ice Lake and Sapphire Rapids normalise the backend per issue slot, and the correction factor is
  the machine width, which aperf does not report. And do not expect this finding at all on
  generic `amd` — `stall-backend-pkc` does not exist there, so the silence means nothing.
- **Do not change compiler flags before confirming which of the four frontend causes applies.**
  `-Os` does not help a branch-misprediction problem, and huge pages do not help an L1I
  capacity problem. In particular, **do not read `code-sparsity`'s absence as good layout** — the
  metric exists in only two of eight profiles, so STEP 4's fourth branch is often unreadable.
- **Do not conclude a balanced pipeline is healthy.** The dead zone is `be/fe ∈ (1/1.1, 1.1)`:
  600 pkc on both sides is 60% of cycles lost on each, and produces no stall finding at all.
- **Do not read the Aggregate ratio as characteristic of every CPU.** It is a ratio of *summed*
  counters, so one thread stalling at 900 pkc among fifteen at 50 pkc reads as comfortable.
- **Do not treat `−10.00` as a 100% excess without checking the text.** A base value printed as
  literal `(0)` is the zero-backend substitution and indicates a collection defect.
- **Do not recommend a rebuild without `--profile` data.** STEP 6 exists because a footprint fix
  aimed at the wrong binary — a runtime, a linked library, or the kernel — changes nothing.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:29` — `metric: "stall-frontend-pkc"`,
  baseline `stall-backend-pkc`, `stat: Stat::Average`, `comparator: Comparator::GreaterEqual`,
  `threshold: 0.1`, `score: Score::Concerning`. Single-run: `requires_comparison` is false, so it
  is readable even when every cross-run comparison in the report is void.
- Rule template: `src/analytics/rule_templates/time_series_stat_intra_run_comparison_rule.rs` —
  calls `compute_finding_score`, so **this rule's score is amplified**. The zero-baseline
  substitution at `:90`–`:92` hardcodes `cur_ratio = 1.0`, which for a `GreaterEqual 0.1` rule
  **always fires**, at a fixed `−10.00`. Both description placeholders are metric names, unlike
  the cross-run template. Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`,
  over `Score::Concerning = −1` (`:147`–`:157`); recover `cur_ratio = |score| / 10`.
- Aggregate is a **ratio of sums**: `src/data/perf_stat.rs:1118`–`:1148` sums stall cycles and
  cycles across CPUs and divides once — correct for a ratio, so **no CPU-count correction
  applies**, but per-CPU outliers are invisible. `stats_series_idx`
  (`src/data/common/time_series_data_processor.rs:312`–`:342`) selects the `Aggregate` series
  (named at `utils.rs:241`); per-CPU series are `CPU{n}` (`utils.rs:237`).
- Per-profile metric definitions: `src/pmu_configs/*.json`, merged as **overlays** onto the
  default by `extend_from_default` (`src/data/perf_stat.rs:200`–`:205`), selected at `:765`–`:790`.
  `stall-frontend-pkc` is `Frontend_Stalls / Cycles * 1000` on every profile that has it;
  `stall-backend-pkc` is `/Cycles*1000` (grv, grv5, intel, milan), `/Slots*1000` (icelake, spr),
  `/Cycles*167` (genoa), and **absent** from generic amd.
- Multiplexing compensation: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`,
  so a schedule rate of R% is an extrapolation factor of `100/R`. Counter mode default
  `GROUPED_PMU_MODE`, `src/data_collection.rs:379`; grouped duplicates events per metric group at
  `src/data/perf_stat.rs:217`–`:221`; the limit is probed at `:344`. Both printed values are
  **truncated**, not rounded (`f64_to_fixed_2`, `src/computations/mod.rs:138`).
- Quantifier: [`../tools/aperf_perf_stat.py`](../tools/aperf_perf_stat.py) `--stalls` — does the
  percent-of-cycles conversion, applies the genoa correction, and refuses to invent the Slots
  width on icelake/spr; `--profiles` prints the full 8-profile matrix.
  `tools/test_aperf_perf_stat.py` pins all of it, including the exhaustive sweep over
  `fe, be ∈ [1, 400)` — 159,201 pairs, **zero double-fires**, and no finding whenever
  `be/fe ∈ (1/1.1, 1.1)`.
- Upstream guides: `CPU_FRONTEND_STALLS_INVESTIGATION` (names the five metrics to check) and
  `INSTRUCTION_FOOTPRINT_OPTIMIZATION` (the remediations), in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `backend-dominated-cpu-stalls.md` (the mutually exclusive mirror),
  `reduced-instructions-per-cycle.md` (the step above in the top-down method),
  `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `high-branch-mispredictions.md`, `high-l1-instruction-cache-misses.md`,
  `instruction-tlb-misses.md`, `instruction-tlb-table-walks.md`, `high-code-sparsity.md`,
  `../cpu_utilization/underutilized-cpu.md`, `../kernel_config/huge-page-disabled.md`.
- Cross-cutting: [../GATES.md](../GATES.md) (precedence, and the missing architecture gate),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) (P/R vocabulary, runtime inference),
  [../ARCHITECTURE.md](../ARCHITECTURE.md) (the 8 PMU profiles, counter mode).
- Graviton perfrunbook, the three pages this tree follows in order:
  [top-down method](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#top-down-method-to-debug-hardware-performance),
  [drill down front-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-front-end-stalls),
  [optimizing for large instruction footprint](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html#optimizing-for-large-instruction-footprint)
- [Arm Neoverse N3 — frontend stalled cycles metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/Cycle-Accounting-metrics-for-Neoverse-N3?lang=en#md523-cycle_accounting_mg__frontend_stalled_cycles_m_Cycle_Accounting)
- [GCC AutoFDO tutorial](https://gcc.gnu.org/wiki/AutoFDO/Tutorial) — the profile-guided layout
  path STEP 4's `code-sparsity` and `branch-mpki` branches both route to.
