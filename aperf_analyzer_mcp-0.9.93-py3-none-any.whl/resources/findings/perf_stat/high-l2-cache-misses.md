---
rule_name: High L2 Cache Misses
data_type: perf_stat
data_key: l2-mpki
template: time_series_data_point_threshold
condition: "any(l2-mpki) > 10.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "This indicates the working set data footprint could be an issue and can cause CPU backend stalls."
source: src/analytics/rules/perf_stat.rs:100
---

# High L2 Cache Misses

## What fired

**At least one** data point of `l2-mpki` was **greater than 10.0** L2 cache misses per thousand
instructions, in **any** series including per-CPU. A single sample anywhere in the recording is enough.

Base score `Concerning` (−1). Single-run rule. The threshold is **half** that of
`High L1 Data Cache Misses` (20.0) and **equal** to that of `High L3 Cache Misses`, which uses `Bad` (−2)
— so an identical value scores twice as severely at L3.

## The processing caveat — identical expressions, different counters

**`l2-mpki` is the metric where expression equality is provably not enough.** The expression is
`L2 / Instructions * 1000` on `grv`, `grv5`, `intel`, `icelake` **and `spr`** — byte-identical across all
five. But `intel_sapphire_rapids_pmu_config.json` overrides the `L2` *event* from `0xf1` umask `0x1f` to
`0x25` umask `0x1f`, and that override is the only thing it changes about this metric. So:

```
cross_architecture_comparable('l2-mpki', 'intel', 'icelake')  →  True
cross_architecture_comparable('l2-mpki', 'intel', 'spr')      →  False   # same expression, 0xf1 vs 0x25
```

This is why the quantifier resolves the expression down to raw encodings before answering, rather than
comparing metric strings — a report that names `l2-mpki` on two runs may be naming two counters. It is
also the one place in the memory-hierarchy family where a **same-vendor, same-family** comparison is
void; `data-l1-mpki` is unaffected (`0x51` umask `0x1` on all five x86 profiles).

| Profiles | `L2` event | What is counted |
|---|---|---|
| `grv`, `grv5` | `armv8_pmuv3_0/event=0x17/` | L2D cache **refills** — lines brought into L2, prefetch included |
| `intel`, `icelake` | `cpu/event=0xf1,umask=0x1f/` | Lines **filled into** L2, all sources, prefetch included |
| `spr` | `cpu/event=0x25,umask=0x1f/` | The same quantity on refreshed SPR encoding — **not** comparable to `0xf1` |
| `amd`, `milan`, `genoa` | `cpu/event=0x64,umask=0x9/`, named `L2_Demand_Misses` in the config | **Demand** request misses. The config's own name says the prefetch side is excluded |

**That asymmetry has a visible consequence.** Where arm64 and Intel count fills including prefetch and
AMD counts demand misses only, the same workload produces a *larger* `l2-mpki` on the fill-counting
profiles. It is also the mechanism behind `hierarchy_funnel`'s own caveat: when `l2_of_l1` exceeds 1.0
the module reports *"more L2 misses were counted than L1 misses. Suspect PMU multiplexing … or prefetch
traffic counted at L2 but not L1"* — a ratio above 1.0 is a **counting** artifact on Intel and arm64, not
an impossible measurement.

**What is *not* defective here:** the threshold is non-zero, so `compute_finding_score` is monotonic and
the template reports the **series peak** — verified, `--select 25 12 45 30 --threshold 10 --rule-score -1`
returns `reported_value: 45.0, series_max: 45.0, reports_the_peak: true`. Unlike the four zero-threshold
TLB rules, the value in the description can be trusted as the maximum.

## Reasoning

`l2-mpki` is "Number of level 2 cache accesses missed per thousand instructions executed"
(`data-descriptions.ts`, `desired: "lower"`).

L2 is the middle tier — typically 1–2 MB per core on Neoverse-class parts, with a hit cost around 15–20
cycles. It serves both data and instruction misses from L1, and it is the **last per-core level**: beyond
it lies the shared system-level cache and then DRAM. That makes this metric the **hinge of the backend
investigation**, and the reason reading it matters more than reading either neighbour alone:

- **L1D misses that L2 satisfies are cheap.** An out-of-order core often hides ~15 cycles behind other
  work. High `data-l1-mpki` with low `l2-mpki` frequently has no end-to-end problem worth fixing — it is
  a *spatial locality* inefficiency, addressable by struct layout.
- **L2 misses that L3 satisfies are moderate.** Tens of cycles, still on-chip, no DRAM bandwidth
  consumed, no co-tenant exposure.
- **L2 misses that L3 also misses are expensive.** Hundreds of cycles to DRAM plus shared bandwidth.

So a high `l2-mpki` says the working set has **outgrown the per-core cache** — 1–2 MB, not 64 KB. That is
a materially different statement from an L1 miss and it constrains the fix: struct reordering and field
packing, the L1-level levers, will not bring a multi-megabyte working set back into L2. What works here
is **reducing the data touched per unit of work**: loop tiling so each tile fits in L2, streaming with
explicit prefetch instead of random access, and shrinking representations.

The causes are the L1 family at a larger scale:

| Cause | Lever |
|---|---|
| **Working set genuinely exceeds L2** — hash tables, indexes, large intermediate buffers, per-request state × concurrency. The common case | Tiling, then footprint |
| **Loop nest with no blocking** — a traversal that sweeps a large array repeatedly, evicting everything between passes | Tiling; the highest-value technique at this level |
| **Random access over a multi-megabyte structure** — prefetchers cannot help, so every access may miss | Flattening, or explicit prefetch |
| **Too many concurrent threads per core** — each thread's working set competes for the same L2 | Concurrency. Reducing it can *raise* throughput, which is counterintuitive and cheap to test |
| **Cache pollution from streaming data** — a one-pass scan evicting the small hot set the rest of the workload reuses | Non-temporal hints, or separating the passes |

And note the metric counts **all** L2 misses, so instruction fetches that missed L1I contribute too. If
`inst-l1-mpki` is also high, part of `l2-mpki` is instruction traffic and the fix is on the frontend and
layout side, not the data side. Skipping that check is the most common way to spend effort on the wrong
half of the problem.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 18.00 (greater than the threshold of 10).
```

`18.00` **is** the series peak — but it is **not the average**, and a run that touched 18 MPKI once
during a load phase reports identically to one that sat there throughout. **It may also be one CPU's
series**: this template iterates **every** series including per-CPU (`time_series_metric_values_iterator`,
`processed_data_accessor.rs:104`), unlike the stat-based `perf_stat` rules that read only `Aggregate`
(`:432`). The value is **truncated, not rounded** (`f64_to_fixed_2`,
`src/computations/mod.rs:138`), so `18.00` is anything in `[18.00, 18.01)`. And there is **no
`(n−1)/n` dilution correction**: `perf_stat` opts out of the forced first zero via
`use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`), so the first sample is real.

Score math — `compute_finding_score(value, 10.0, −1)`. The value is always above the threshold, so no
inversion applies and the score is linear in it:

| worst sample | score |
|---|---|
| 12.0 | `(12/10) × −1` = **−1.20** |
| 18.0 | `(18/10) × −1` = **−1.80** |
| 25.0, then 45.0 | `(25/10) × −1` = **−2.50**, `(45/10) × −1` = **−4.50** |

Recover the sample as `value = |score| × 10`.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The peak sits at or below 10.0 | no finding. On AMD that is weaker evidence than it looks: demand misses only |
| Only one `CPU{n}` series exceeded | reported for the whole run; the `Aggregate` series may be well under 10 |
| The run multiplexed heavily | the peak is an extrapolation, and one distorted interval is sufficient to fire |
| The profile is `spr` | the same expression on a different event (`0x25`, not `0xf1`) — not comparable with a generic-Intel or Ice Lake run |
| The workload prefetches heavily on `grv`/`intel` | the value includes prefetch fills, so it can exceed `data-l1-mpki` legitimately |

**Watch the threshold and base-score differences when comparing findings.** `data-l1-mpki` uses 20.0 and
`l2-mpki` uses 10.0, so equal *scores* mean different *values*: −2.00 on L1D is 40 MPKI, −2.00 here is
20 MPKI. And `l3-mpki` shares this threshold with a base score of `Bad` (−2), so at equal values L3 scores
double. **Compare values, never scores, across different rules.**

## Interpretation

| sustained value | Reading |
|---|---|
| 10–20 | Moderate. The working set exceeds L2, but the cost may be absorbed if L3 hits |
| 20–40 | Substantial per-core cache pressure |
| > 40 | Heavy — a large fraction of instructions reach beyond per-core cache |

The escalation pattern is the diagnosis:

| `l2-mpki` high **and** | Reading |
|---|---|
| sustained across the series | Genuine. One isolated sample is a load phase, checkpoint, GC cycle or warm-up, and is not |
| `l3-mpki` low | **The tolerable case.** Misses are served by the shared L3 — on-chip, moderate cost, no DRAM bandwidth. Tiling to fit L2 is worthwhile but not urgent |
| `l3-mpki` high | **The expensive case.** Data is coming from DRAM. Total footprint reduction required. Go to `High L3 Cache Misses` |
| `data-l1-mpki` low but `l2-mpki` high | Unusual. Check `inst-l1-mpki` for instruction traffic, and on `grv`/`intel` remember prefetch fills are counted here but not at L1 |
| `inst-l1-mpki` high | Part of the L2 traffic is **instruction** fetches. Split the diagnosis: the frontend and layout path may be the real fix |
| `data-tlb-mpki` non-zero | Translation cost stacked on the data cost — an independent and cheaper huge-page fix |
| `Backend-Dominated CPU Stalls` fired | **The confirmed case** |
| `Frontend-Dominated CPU Stalls` fired | Secondary — and combined with high `inst-l1-mpki`, a strong hint the L2 traffic is code, not data |
| `ipc` healthy (> 2) | The core is hiding the latency. Low priority |
| `number_threads` high | Threads per core divide the same L2. The code may be innocent, and reducing concurrency is the cheapest experiment available |

**Known false positives — check these before restructuring:**

- **A single transient sample.** The dominant false positive for every
  `time_series_data_point_threshold` rule. Load phases, checkpoints, GC cycles and cache warm-up all
  spike it, and the peak is exactly what gets reported.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, the peak is an extrapolation and
  one distorted interval fires the rule.
- **One hot CPU.** The rule reads every per-CPU series, so a few threads with large working sets fire it
  for the run while the aggregate is benign. **Idle-diluted runs** are the same class: background daemons
  contribute their own miss behaviour.
- **The workload legitimately has a multi-megabyte working set.** Databases, in-memory caches, analytics
  and JVM heaps operate above L2 by design. Expected, and possibly not reducible. **Streaming or one-pass
  work** is the same story: copying, hashing, compressing or scanning large buffers has no reuse, so the
  misses are the cost of the work. So is **GC**, which sweeps large regions and evicts everything.
- **The traffic is instruction, not data.** If `inst-l1-mpki` is high, some of `l2-mpki` is code fetches
  and the data-side remediations will not help.
- **High thread count per core.** Concurrent threads dividing the same L2 raise per-thread miss rates
  with no change in the code. Not a defect — but reducing concurrency may improve throughput.
- **Prefetch fills on `grv`/`grv5`/`intel`/`icelake`/`spr`.** Those profiles count lines filled into L2
  from all sources, so an aggressive prefetcher raises this metric while *improving* performance.
- **Misses terminate in L3.** If `l3-mpki` is low, the end-to-end cost is moderate and the finding may
  not justify significant restructuring effort.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `l2-mpki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient; per-thread concentration |
| `l3-mpki` | `perf_stat` | **The key discriminator** — whether misses stop on-chip or go to DRAM. See `High L3 Cache Misses` |
| `data-l1-mpki` | `perf_stat` | The tier below; whether pressure starts at L1 or appears at L2. Feed both plus `l3-mpki` to `--funnel`. See `High L1 Data Cache Misses` |
| `inst-l1-mpki` | `perf_stat` | **Whether the L2 traffic is instructions rather than data** — it changes the entire remediation path. See `High L1 Instruction Cache Misses` |
| `stall-backend-pkc` vs `stall-frontend-pkc`, `ipc` | `perf_stat` | **Severity gate.** See `Backend-Dominated CPU Stalls`; `ipc` says whether the core is absorbing the latency |
| `data-tlb-mpki`, `data-tlb-tw-pki` | `perf_stat` | Independent translation cost on the same accesses, with a cheaper fix. See `Data TLB Misses` |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ the peak may be an extrapolation artifact |
| `MemAvailable`, `Cached`, `AnonHugePages` | `meminfo` | Memory pressure, and whether huge pages are reducing the translation component |
| `pgminorfault`, `pgfault` | `vmstat` | Allocation churn evicting live data. See `Increased Minor Page Faults` |
| `numa_hit`, `numa_miss`, `other_node` | `numastat` | Remote-node access raising the cost of each miss without changing the rate. **No analytical rules — read manually** |
| `number_threads`, `resident_set_size_bytes` | `processes` | Threads per core competing for the same L2, and per-process footprint — the R1 lever. **No analytical rules** |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| `Instance Type` | `systeminfo` | L2 size per core is an instance property, and the instance type is the **only** clue to which PMU profile — and therefore which `L2` event — applied |
| On-CPU profile | `perf_profile` / `java_profile` | Which code performs the missing accesses. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | Instruction- and address-level miss attribution for prefetch placement. Native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |
| Memory allocation profile | `java_profile` | Allocation-driven cache pollution (`--profile-java`) |

## Guidance

Ordered. Step 1 disposes of transients; step 5 decides how expensive the problem actually is, and
therefore how much effort is justified.

1. **Read the `l2-mpki` series before anything else.** An **isolated spike** at startup, a phase boundary
   or aligned with GC ⇒ transient; stop. **Sustained above 10** ⇒ continue. Check per-CPU: concentration
   on a few CPUs points at specific threads and a much cheaper fix than restructuring.

2. **Establish which counter is behind `l2-mpki` on this run.** Read `Instance Type` and map it to a
   profile. On **`spr`** the event is `0x25`, not the generic-Intel `0xf1`, so the value is **not**
   comparable with an `intel` or `icelake` run even though the metric expression is identical. On **AMD**
   the config counts `L2_Demand_Misses` — prefetch-driven misses are excluded, so the value understates a
   prefetch-heavy workload relative to arm64 or Intel, where fills from all sources are counted.

3. **Gate on measurement confidence.** Check `mux_counter_schedule_rate` (`PMU Counter Collection
   Multiplexing`) and `avg(idle)` (`Underutilized CPU`).

4. **Confirm the backend is the bottleneck.** Compare `stall-backend-pkc` and `stall-frontend-pkc`, and
   read `ipc`. Backend dominant with low IPC ⇒ actionable; otherwise record as secondary. On generic
   `amd` neither stall metric exists, so use `ipc` alone.

5. **Read `l3-mpki` — this determines the cost, and therefore the effort justified.** Use the funnel
   rather than the three findings separately:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --funnel --data-l1 45 --l2 22 --l3 14 --profile intel
   l2_of_l1: 0.489, l3_of_l2: 0.636, l3_of_l1: 0.311, boundary: dram, l3_ratio_valid: true
   ```

   `boundary: l2` means L1 misses are largely not absorbed by L2 but most do not reach DRAM — the working
   set sits between L2 and L3 capacity, and improving spatial locality has a good chance of pulling it
   back inside L2. `boundary: dram` means escalate to `High L3 Cache Misses`: total footprint reduction
   is required, and bandwidth and co-tenant contention now matter.

6. **Separate instruction traffic from data traffic.** Read `inst-l1-mpki`. If it is high, part of
   `l2-mpki` is code fetches, and the effective fix is instruction-footprint and layout work
   (`High Code Sparsity`, `INSTRUCTION_FOOTPRINT_OPTIMIZATION`) rather than data restructuring.

7. **Establish the working-set size relative to L2.** From the code or the allocation profile, estimate
   how much data one unit of work touches. If it exceeds per-core L2 — typically 1–2 MB, and an instance-
   type property aperf does not report — **tiling is the primary lever**: restructure loops so each tile
   fits, then move to the next tile.

8. **Check concurrency, translation and NUMA — the three cheap levers.** `number_threads` (`processes`):
   many threads per core divide L2 between them, so reducing thread count or pinning for cache affinity
   can raise throughput even though it lowers parallelism. `data-tlb-mpki` / `data-tlb-tw-pki` non-zero
   adds an independent huge-page fix. `numastat` shows whether misses are served from a remote node,
   which multiplies their cost without changing the rate — and it has no analytical rules, so nothing
   flags it.

9. **Attribute, then remediate**, per `DATA_FOOTPRINT_OPTIMIZATION`. With `--profile` find the stalling
   stacks; for native code on metal Graviton, `hotline` identifies the specific missing accesses, which is
   the prerequisite for prefetch placement. Then, in order of leverage at this level: **loop tiling and
   blocking** ("break large loops into smaller ones") — the highest-value technique here; **store related
   data contiguously** and **access it sequentially**; **reuse data before it is evicted**; **shrink
   representations** so more of the working set fits; **insert prefetches** at hotline-identified sites
   for unavoidable random access; **non-temporal stores** for streaming data that pollutes cache without
   being reused; and, if the working set genuinely cannot shrink, an instance with more cache per core.

## Priority and execution risk

**Priority: P2 — Investigate** by default. The threshold of 10.0 is meaningful and the reported value is
the true peak, but `Concerning` (−1) is the correct weight: an L2 miss that L3 absorbs is a tens-of-cycles
event, not a DRAM round trip. It rises to **P1 — Act now** only when `High L3 Cache Misses` also fired
**and** `Backend-Dominated CPU Stalls` fired — at which point the finding to act on is really the L3 one,
and this playbook's role is to establish that the chain escalates. It drops to **P3 — Monitor** when
`l3-mpki` is low (the misses stop on-chip, so the cost is moderate and restructuring may not be
justified), when only one `CPU{n}` series is elevated, when `inst-l1-mpki` is high enough that the traffic
may be instruction rather than data, or when the elevation is confined to a load or GC phase. It drops to
**P4 — Informational** whenever the run multiplexed.

**Execution risk: R0 — Read-only** to diagnose: the series, the per-CPU split, the funnel, the stall
comparison, `number_threads` and `numastat` are all reads. Acting starts cheap and ends expensive.
**R1 — Config change** for a thread-count reduction or `numactl` pinning, both reversible in a restart and
both worth trying first. **R4 — Infrastructure change** for huge pages, or for an instance with more L2 per
core. **R2 — Code change** to **R3 — Rebuild** for the levers that actually fix this level: tiling,
struct-of-arrays conversion, representation shrinking and prefetch placement all change program semantics
enough to need correctness re-validation, not just re-measurement.

**The score is monotonic and comparable across runs of this same rule** — `value = |score| × 10` recovers
the peak exactly. It is **not** comparable with `High L1 Data Cache Misses` (threshold 20.0) or
`High L3 Cache Misses` (same threshold, base score `Bad`), and **not** comparable between `intel` and
`spr`, where the same expression resolves to a different event.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `l2-mpki`, in any series including per-CPU, exceeded `10.0`
(`Greater 10.0`). The reported value is the series peak — verified, unlike the four zero-threshold TLB
rules.

```
STEP 0 — Does the data exist, and WHICH `L2` event is behind the metric?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `Instance Type` maps to `spr`
  THEN → the expression is byte-identical to generic Intel but the EVENT is 0x25, not 0xf1.
         cross_architecture_comparable('l2-mpki','intel','spr') is False, so this value cannot
         be compared with an intel or icelake run even within the same vendor (P2, R0)
       → verify: `resolved_events('l2-mpki','spr')` returns event=0x25,umask=0x1f while the
         same call on `intel` returns 0xf1; if you compared the two runs, discard the delta
  IF `Instance Type` maps to `amd`, `milan` or `genoa`
  THEN → the config counts L2_Demand_Misses (0x64 umask 0x9): DEMAND requests only. A
         prefetch-heavy workload is UNDERSTATED relative to arm64 or Intel, which count fills
         from all sources (P2, R0)
       → verify: `metric_definition('l2-mpki','amd')` names L2_Demand_Misses rather than L2;
         corroborate the real pressure from stall-backend-pkc rather than from this value
  IF the profile is `grv`, `grv5`, `intel` or `icelake`
  THEN → the counter is LINE FILLS into L2 including prefetch, so the value can legitimately
         exceed data-l1-mpki: continue to STEP 1

STEP 1 — Is it sustained, and is it the instance or a few threads?
  IF the elevation is one or two isolated samples
  THEN → a load phase, a checkpoint, a GC cycle or cache warm-up. The template reports the
         PEAK, so one spike produces the largest number the run ever saw. Record and STOP
         (P4, R0)
  IF only one or two `CPU{n}` series exceed 10.0
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so a few threads
         with large working sets fire it for the whole run while the Aggregate series may be
         well under 10 (P3, R0)
       → verify: the on-CPU profile names those threads; a targeted fix should move their series
         and barely move the aggregate
  IF every CPU is elevated roughly uniformly AND `number_threads` is high
  THEN → threads per core are dividing the same L2, so the code may be innocent. This is the
         cheapest experiment in the playbook (P2, R1)
       → verify: halving the thread count lowers per-thread l2-mpki AND raises per-core
         throughput; if throughput falls, L2 was not the constraint

STEP 2 — Gate on measurement confidence.
  IF `mux_counter_schedule_rate` < 100
  THEN → the peak is an extrapolation by a factor of 100/R, and one distorted interval fires the
         rule. Report low-confidence and do NOT act on the magnitude (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the peak collapses, the original
         finding was a multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons contribute their own miss behaviour, so the peak may not be the
         workload's (P3, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES confirms
         the workload, one that falls confirms the daemons

STEP 3 — Is the backend actually the bottleneck?
  IF `Backend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: data access is blocking issued instructions. How MUCH it costs is
         still open and STEP 4 decides it (P2, R0)
       → verify: `stall-backend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative to
         the frontend; a falling ratio with a flat absolute means the frontend got worse
  IF `ipc` is healthy (> 2)
  THEN → the core is hiding the latency behind other work, which is exactly what a 15-20 cycle
         L2 hit cost allows. Record as low priority (P3, R0)
  IF `Frontend-Dominated CPU Stalls` fired
  THEN → SECONDARY, and a strong hint when combined with high inst-l1-mpki that the L2 traffic
         is CODE. Go to STEP 5 before touching the data path (P4, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence
         of health since 600 pkc on both sides fires nothing, or the run is on generic `amd`
         where `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read
         the absolutes, or `ipc` alone on amd (P3, R0)

STEP 4 — Where does the miss chain TERMINATE? This decides the cost, and the effort justified.
  IF `l3-mpki` is BELOW its threshold of 10.0
  THEN → the TOLERABLE case: misses are served by the shared L3, on-chip, tens of cycles, no
         DRAM bandwidth and no co-tenant exposure. `--funnel` reports `boundary: l2`. Tiling to
         fit L2 is worthwhile but NOT urgent, and a large restructuring is not justified on this
         evidence (P3, R2)
       → verify: `--funnel --data-l1 <v> --l2 <v> --l3 <v> --profile <p>` reports
         `boundary: l2`; after tiling, l2-mpki falls while l3-mpki stays flat
  IF `High L3 Cache Misses` also fired
  THEN → the EXPENSIVE case: the chain runs to DRAM, so hundreds of cycles per miss plus shared
         bandwidth. The finding to act on is the L3 one; this playbook's job was to establish
         that the chain escalates. Go to `High L3 Cache Misses` (P1, R0)
  IF `l2_of_l1` exceeds 1.0
  THEN → more L2 misses were counted than L1 misses. On `grv`/`intel` that is PREFETCH traffic
         counted at L2 but not at L1, which is a counting artifact rather than an impossible
         measurement; otherwise suspect multiplexing. Treat the funnel as low-confidence
         (P4, R0)
  IF `data-l1-mpki` is BELOW its threshold while this finding fired
  THEN → the pressure appears AT L2 rather than building through L1. Check inst-l1-mpki in
         STEP 5, and on fill-counting profiles check the prefetcher before restructuring
         anything (P3, R0)

STEP 5 — Data traffic, or INSTRUCTION traffic? l2-mpki counts both.
  IF `inst-l1-mpki` is above its own threshold of 20.0
  THEN → part of this value is CODE fetch that missed L1I, and no data-side remediation touches
         it. The effective fix is instruction footprint and layout:
         INSTRUCTION_FOOTPRINT_OPTIMIZATION, and check High Code Sparsity (P2, R3)
       → verify: after the layout fix, l2-mpki falls together with inst-l1-mpki; if l2-mpki
         barely moves, the traffic was data after all
  IF `High Code Sparsity` also fired
  THEN → on arm64 only, and it is the ROOT CAUSE case: scattered hot code wastes both L1I lines
         and L2 capacity, so one layout change addresses several findings at once (P2, R3)
       → verify: code-sparsity, inst-l1-mpki and l2-mpki all move together after profile-guided
         layout; if only code-sparsity moves, the L2 traffic was independent
  IF `inst-l1-mpki` is low and the workload is data-heavy
  THEN → the traffic is data. Continue to STEP 6 for the working-set question (P2, R0)

STEP 6 — Is the working set reducible, and are the cheap levers available?
  IF one unit of work touches more than per-core L2 (typically 1-2 MB)
  THEN → TILING is the primary lever: restructure loops so each tile fits, then move to the next
         tile. aperf does NOT report L2 size, so this needs the instance type and the vendor
         documentation (P2, R2)
       → verify: l2-mpki falls roughly in proportion to the tile size reduction; if it does not,
         the access pattern is random rather than blockable
  IF the access pattern is streaming or one-pass with no reuse
  THEN → the misses are the COST OF THE WORK, not a defect. Non-temporal stores stop it polluting
         the hot set, but nothing makes a no-reuse scan hit cache (P3, R2)
       → verify: after non-temporal hints, l2-mpki for the OTHER phases of the workload falls
         even if the streaming phase is unchanged
  IF `data-tlb-mpki` or `data-tlb-tw-pki` is non-zero
  THEN → an independent translation cost on the same accesses, with a configuration-only fix
         that is far cheaper than restructuring. Do it first (P2, R4)
       → verify: `AnonHugePages` in `meminfo` rises and stall-backend-pkc falls while l2-mpki
         stays flat -- the signature of a translation-only win
  IF `numa_miss` or `other_node` in `numastat` is material
  THEN → remote-node access multiplies the cost of every miss without changing the rate, and
         numastat has NO analytical rules so nothing flags it (P2, R1)
       → verify: after `numactl` pinning or interleaving, other_node falls AND stall-backend-pkc
         falls; l2-mpki itself will not move

STEP 7 — What survives?
  VALID      : the reported value AS the series peak; the per-CPU split; `value = |score| × 10`;
              the funnel boundary; the stall split read as absolute pkc; number_threads and
              numastat read by hand; and every non-PMU finding in the run
  CAUTION    : the value on AMD, which excludes prefetch-driven misses; the value on
              fill-counting profiles, which INCLUDES prefetch and can exceed data-l1-mpki; and
              any working-set estimate, since aperf does not report L2 size
  CONFOUNDED : the value on a multiplexed run; the value on an idle-diluted run; the value when
              inst-l1-mpki is also high, since the metric mixes code and data; and any
              comparison against a run with a different thread count
  VOID       : any comparison between an `spr` run and an `intel`/`icelake` one -- same
              expression, different event; any cross-vendor comparison; any score comparison
              with `High L1 Data Cache Misses` (threshold 20.0) or `High L3 Cache Misses` (same
              threshold, base score Bad); and any claim that this is the average

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF the profile cannot be identified from `Instance Type`
  THEN → STEP 0 is unanswerable, so it is unknown whether the counter includes prefetch and
         whether the value is comparable to anything. Report the magnitude only (P3, R0)
  IF `l3-mpki` is absent from the report
  THEN → STEP 4 cannot run, so the COST of the misses is unknown and no restructuring is
         justified. This is the one input this playbook cannot work without (P3, R0)
```

## Runtime-specific consequences

An L2 miss costs the same everywhere; what differs by runtime is **how large one unit of work's data is
and whether tiling is even expressible** in the language.

| Runtime | Why the misses, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | Objects are individually heap-allocated and reached through references, so a "1 MB" collection is a pointer graph spread over far more than 1 MB of lines. A copying collector also relocates live objects, so a tiled loop's locality is not stable across a collection. Rarely a defect, and the least tileable runtime | `GC` data for whether the elevated intervals align with collections; `jvmArguments` for heap size and collector. Data representation — primitive arrays over object collections — is the axis, not tiling |
| **Python** | Pure-Python containers have the same problem in a stronger form: every element is a boxed object. A NumPy or torch stack is the opposite — contiguous, tileable, and where blocking actually works | Whether the hot loop is native-array work or object iteration. The first responds to blocking, the second only to moving the data into arrays. Representation is the axis |
| **.NET** | Value types and `Span<T>` make contiguous layout expressible, so tiling and struct-of-arrays are genuinely available — the runtime in this list where the L2-level levers apply most directly | Whether hot data uses `struct` and array types rather than reference types; server-vs-workstation GC. Layout and tiling are the axes |
| **Perl** | Every value is an SV from arenas, with no contiguity guarantee and no tiling story. Structural, not a finding | Whether the hot data can move into a packed structure or an XS/C library. Otherwise the axis is capacity: fewer threads, or more cache per core |

**The unknown-runtime case is the default** — aperf reports no language field, and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 4 and report the cost: whether the chain terminates on-chip or at DRAM is the conclusion that
needs no knowledge of who allocated the memory, and it is the one that decides whether anything is worth
doing.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — the registry `architectures` lists every one and
`architecture_note` is empty. That silence hides the sharpest comparability trap in the family, because
the metric *expression* is identical on five of the eight.

| Profile | `L2` event | Semantics | Comparable with… |
|---|---|---|---|
| `grv`, `grv5` | `armv8_pmuv3_0/event=0x17/` | L2D refills, prefetch included | each other only |
| `intel`, `icelake` | `cpu/event=0xf1,umask=0x1f/` | Lines filled into L2, all sources | each other only |
| `spr` | `cpu/event=0x25,umask=0x1f/` | Same quantity, refreshed encoding | **nothing else** — same expression as `intel`, different event |
| `amd`, `milan`, `genoa` | `cpu/event=0x64,umask=0x9/` (`L2_Demand_Misses`) | **Demand** misses; prefetch excluded | each other only |

So `cross_architecture_comparable('l2-mpki', …)` returns True for `intel`/`icelake`, `grv`/`grv5` and the
three AMD profiles, and **False for `intel`/`spr`** — the only same-vendor False in the memory-hierarchy
family, and the reason the quantifier compares resolved encodings rather than expression strings.
`test_aperf_memory_hierarchy.py` re-derives all of it from `src/pmu_configs/*.json`, so it cannot drift.

**No aperf gate protects any of this.** aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate**, yet the event, the prefetch accounting and the L2 size per core
all changed. The capacity point applies within a vendor too — L2 per core is a microarchitecture property
aperf does not report at all, so "does the working set fit L2" always needs the vendor documentation.

## Verification

Re-record at the **same geometry, same counter mode, same instance type and the same thread count**, then
check in order. First, `l2-mpki` must fall — compare the sustained level, not the peak, because the
reported value is the maximum and a fix that only smooths one spike will look like a large win. Second,
check `l3-mpki` did not rise: a tiling change that reduces L2 misses by streaming more data can trade a
cheap miss for an expensive one. Third, `stall-backend-pkc` must fall in **absolute pkc**, not merely
relative to the frontend. Fourth, throughput must actually improve — at 15–20 cycles per L2 hit it is
entirely possible to reduce this metric and gain nothing, because the misses were already hidden.

If `l2-mpki` falls and nothing else moves, the misses were being absorbed and STEP 4 already said so. If
`inst-l1-mpki` moved with it, the traffic was partly code and the layout fix was doing the work. If the
metric is unchanged but throughput rose after a thread-count reduction, the constraint was L2 *capacity
sharing* rather than the access pattern — a result this metric cannot show directly, since per-thread miss
rates fall while the aggregate is unchanged.

## Do not

- **Do not treat the reported value as the run's average.** It is the series peak, and one load-phase or
  GC spike produces the largest number the run ever saw.
- **Do not compare an `spr` value with an `intel` or `icelake` one.** The expression is byte-identical and
  the event is not (`0x25` vs `0xf1`), so `cross_architecture_comparable` returns False. Expression
  equality is not comparability.
- **Do not compare scores across different `perf_stat` rules.** Thresholds differ (20.0 for L1D, 10.0 for
  L2 and L3) and so do base scores (`Concerning` here, `Bad` at L3), so equal scores mean different
  values twice over.
- **Do not assume `l2-mpki` is all data traffic.** Instruction misses from L1I flow through L2 too; check
  `inst-l1-mpki` before choosing a remediation path.
- **Do not treat a value above `data-l1-mpki` as a collection bug on `grv`/`grv5`/`intel`/`icelake`/`spr`.**
  Those profiles count fills from all sources, so prefetch traffic legitimately appears at L2 and not at
  L1. On AMD the reverse bias applies: demand misses only, so the value understates.
- **Do not apply L1-level fixes here.** Struct field reordering will not bring a multi-megabyte working
  set into a 1 MB cache; tiling and footprint reduction will.
- **Do not restructure before reading `l3-mpki`.** If L3 absorbs the misses the cost is tens of cycles and
  the effort is probably not justified — this is the single most important gate in the playbook.
- **Do not act on a GC, load-phase or warm-up spike**, and **do not act on the value when
  `mux_counter_schedule_rate` is below 100** — the peak is then an extrapolation.
- **Do not read the value as characteristic of the instance.** This template iterates every series
  including per-CPU (`processed_data_accessor.rs:104`), so a few threads fire it for the whole run.
- **Do not overlook the thread count.** Threads per core divide the same L2, it is R1 to test, and it is
  the one lever that can raise throughput by *reducing* parallelism.
- **Do not optimize data layout while the workload is frontend-bound**, and **do not read the small score
  as small impact** — `Concerning` (−1) caps the score near −5 even for severe values.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:100` — `metric: "l2-mpki"`,
  `comparator: Comparator::Greater`, `threshold: 10.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void. Note
  `High L3 Cache Misses` (`:108`) uses the **same** threshold with `Score::Bad`, and
  `High L1 Data Cache Misses` (`:92`) uses `20.0`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)`; with a non-zero threshold and a monotonic score
  that is the series **peak**. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — `delta = value / threshold`,
  inverted only below 1.0, times `rule_score`. `Score::Concerning = −1` at `:147`–`:157`.
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config by
  `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:750`–`:797`. The expression is
  `L2 / Instructions * 1000` on grv, grv5, intel, icelake **and spr**, and
  `L2_Demand_Misses / Instructions * 1000` on amd, milan, genoa. `L2` is `event=0x17` (arm64),
  `event=0xf1,umask=0x1f` (intel, icelake) and `event=0x25,umask=0x1f` (**spr only** — the sole change the
  SPR override makes to this metric); `L2_Demand_Misses` is `event=0x64,umask=0x9`. `perf_stat` opts
  **out** of the forced first zero via `use_first_accumulative_value()` (`:1295`).
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) — `--funnel`
  localizes the boundary and emits the `l2_of_l1 > 1.0` prefetch caveat; `resolved_events` resolves an
  expression to raw encodings, and `cross_architecture_comparable` checks **both** layers, which is what
  makes `intel`/`spr` False; `--select` confirms the peak is reported.
  `test_aperf_memory_hierarchy.py` re-derives the expressions and encodings from `src/pmu_configs/`.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate
  of R% is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and
  duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `DATA_FOOTPRINT_OPTIMIZATION` (the remediation attached to this metric — reuse,
  contiguous storage, sequential access, breaking large loops into smaller ones) and
  `CPU_BACKEND_STALLS_INVESTIGATION` (which lists `l2-mpki`), in
  `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `high-l1-data-cache-misses.md` (the tier below) and `high-l3-cache-misses.md` (the
  tier above, and the cost decider — read all three via `--funnel`),
  `high-l1-instruction-cache-misses.md` and `high-code-sparsity.md` (the instruction traffic that also
  flows through L2), `backend-dominated-cpu-stalls.md` (the severity gate), `data-tlb-misses.md` (the
  independent translation cost), `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../kernel_config/huge-page-disabled.md`, `../vmstat/increased-minor-page-faults.md`,
  `../cpu_utilization/underutilized-cpu.md`. Cross-cutting: [../GATES.md](../GATES.md),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md), [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down back-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-back-end-stalls)
- [Arm Neoverse N3 — L2 cache MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/L2-Cache-Effectiveness-metrics-for-Neoverse-N3?lang=en#md550-l2_cache_effectiveness_mg__l2_cache_mpki_m_L2_Cache_Effectiveness)
