---
rule_name: PMU Counter Collection Multiplexing
data_type: perf_stat
data_key: mux_counter_schedule_rate
template: time_series_data_point_threshold
condition: "any(mux_counter_schedule_rate) < 100.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: " The PMU events were collected under multiplexing. The accuracy of the values might be impacted and there is increased CPU utilization for the collection."
source: src/analytics/rules/perf_stat.rs:140
---

# PMU Counter Collection Multiplexing

## What fired

**At least one** data point of `mux_counter_schedule_rate` was **below 100.0**. A single sample on a
single CPU anywhere in the recording is enough.

Base score `Concerning` (−1). Single-run rule (`requires_comparison: false`), `Comparator::Less`,
threshold `100.0`.

This is a **META finding**: a statement about the measurement apparatus, not the workload. It is the
validity gate for every other `perf_stat` finding in the same run — read it first, and read it
differently from the rest, because **its headline claim is weaker than it looks in the default
collection mode**.

## The processing caveat — verified by reading the collection code

**In grouped mode — the default — the multiplexing correction cancels exactly, and the reported metric
values are bit-for-bit what they would have been without multiplexing.** This contradicts the natural
reading of aperf's own message ("the accuracy of the values might be impacted") and it is the single
most important fact in this playbook.

Two independent properties combine to produce the cancellation:

1. **One scale factor per metric group, applied to the whole counter vector.** `src/data/perf_stat.rs`
   `:1093`–`:1097` computes `f = time_enabled / time_running` **once** per `(CPU, metric group)` and
   maps it over every element of `counter_values`. Grouped mode creates one group **per metric**
   (`:243`–`:272`), holding exactly that metric's events. So a metric's numerator and denominator
   always carry the *same* `f`.
2. **Every shipped metric expression is homogeneous of degree 0.** All 31 distinct expression forms
   across the 107 profile-metric definitions in `src/pmu_configs/*.json` are a ratio of degree-1
   counter terms times a constant — `Branch_Mispredictions / Instructions * 1000`,
   `Instructions / Cycles`, `(L3 / L3_READ * L2) / Instructions * 1000`, and so on.

Scale every input by a common `f` and a degree-0 expression does not move:

| collection | raw mispredicts | raw instructions | `time_running` | reported `branch-mpki` |
|---|---|---|---|---|
| no multiplexing | 14 000 | 1 000 000 | 1.0 | **14.00** |
| multiplexed to 1/3 | 14 000 | 1 000 000 | 0.333 | **14.00** |

The `f = 3.0` scales both counters and divides out. **A `branch-mpki` of 7.0 at a 50% schedule rate is
still 7.0.** What multiplexing costs in grouped mode is **duty cycle**, not magnitude: the value is an
accurate measurement of the *fraction of the interval that was actually sampled*. The error mode is
therefore **phase blindness** — a short-lived phase can be missed entirely — and never a scaling bias.

**Ungrouped mode is the opposite, and this inverts the usual advice.** With `--ungroup-pmu-events`,
`process_single_raw_pmu_event_counter_data` gives each *event* its own independent `time_running`
(`:1216`: `counter_value * time_enabled / time_running`). The factors no longer match, so the metric
is reported as `(num/den) × (tr_den / tr_num)` — a genuine multiplicative skew:

| numerator event scheduled | denominator event scheduled | reported / true |
|---|---|---|
| 100% | 50% | **0.50×** |
| 50% | 100% | **2.00×** |
| 70% | 100% | **1.4286×** |

That last row is exactly `10.0 / 7.0`. `High Branch Mispredictions` is `GreaterEqual 10.0`, so a
**true** `branch-mpki` of 7.0 lands precisely on the threshold and **fires** at a 70%/100% two-event
spread. aperf's own source says as much at `:277`–`:280`. So `--ungroup-pmu-events` relieves register
pressure while introducing a cross-event skew that grouped mode **structurally cannot have** — it is a
trade-off, not a fix, and a threshold crossing observed under it may be pure artifact.

One consequence worth stating plainly: because grouped mode co-schedules a metric's own events, the
common worry that **`ipc`'s numerator and denominator came from different time slices is false in the
default mode**. That exposure exists only *between* metrics (comparing `ipc` against `l2-mpki`), and
only in ungrouped mode *within* one.

**And the collection-time warning is recoverable, contrary to appearances.** `warn_multiplexing`
(`:59`–`:64`, called from both paths at `:224` and `:289`) is a `debug!`, invisible on stdout at
default verbosity. But `init_logger` (`src/bin/aperf.rs:65`–`:104`) wraps **only the stdout appender**
in a `ThresholdFilter`; the `aperflog` `FileAppender` is attached at `LevelFilter::Debug`
**unconditionally**. `src/data_collection.rs:213`–`:214` copies that runlog into the archive, and the
frontend surfaces it as **"APerf Logs"**. Because `src/analytics/rules/aperf_runlog.rs` is a bare
`impl AnalyzeData for AperfRunlog {}`, **no rule reads it** — so it is a manual grep, and it will name
the metrics that lost counters.

## Reasoning

`mux_counter_schedule_rate` is *"The percentage of collection time when a counter was actually
scheduled on a core"* (`data-descriptions.ts`, `desired: "higher"`). 100% means every counter aperf
asked for fit simultaneously in hardware.

Hardware provides a small fixed number of programmable PMU counters — typically 6 on Neoverse cores
plus a dedicated cycle counter. aperf requests far more, because grouped mode instantiates each
metric's events **separately per metric**: an event shared by five metrics is allocated five times.
Summed over the shipped configs the grouped request is 22–32 counters against a probed limit bounded
to 16 (`PMU_COUNTER_LIMIT_UPPER_BOUND`, `:339`):

| profile | grouped counters | unique events (ungrouped) |
|---|---|---|
| `grv` / `grv5` | 28 / 30 | 15 / 16 |
| `intel` / `icelake` / `spr` | 28 / 28 / 32 | 15 / 16 / 18 |
| `amd` / `genoa` / `milan` | 22 / 24 / 25 | 12 / 13 / 14 |

**The default configuration therefore multiplexes on every supported platform** — which is why
`warn_multiplexing`'s TODO says so outright. This finding is close to unconditional, and its mere
presence carries almost no information. Only the *rate* and its *distribution* do.

When the request exceeds hardware the kernel time-slices the counter groups, running each for a
fraction of the window. Two real consequences follow — note that "the values are wrong" is not one of
them in grouped mode:

1. **Reduced temporal resolution.** At a 40% schedule rate each group observed roughly 2 in every 5
   ticks. A phase occupying less than that share of an interval can be sampled entirely or missed
   entirely. Bursty and phased workloads are exposed; steady ones are not.
2. **Collection overhead.** Reprogramming counters on every scheduler tick is kernel work that appears
   as `system` time and can perturb a latency-sensitive workload — an observer effect.

`probe_pmu_counter_limit` (`:344`–`:402`) binary-searches the real limit at record time between 1 and
16, so the rate is a property of the CPU *and* of what else on the box is using the PMU.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

The comparator renders from its `strum` string, here `"less than"`; the threshold prints as `100`
because Rust's `{}` drops a whole float's `.0`:

```
At least one data point in aperf_record is 62.00 (less than the threshold of 100).
```

`62.00` is the **worst single sample across every series, including per-CPU** — not the average, and
not necessarily the aggregate. `time_series_metric_values_iterator`
(`processed_data_accessor.rs:104`) flattens all series, so **one CPU that multiplexed fires this
finding for the whole run even when the `Aggregate` rate is 100**. A run that sat at 99% except for one
sample reports identically to a run that sat at 62% throughout.

Score math — `compute_finding_score(value, 100.0, −1)`. The value is always below the threshold, so
`delta = value/100 < 1` is reciprocated and the score is `−100 / value`:

| worst sample | score | recovered rate |
|---|---|---|
| 99% | **−1.01** | 99.0% |
| 62% | **−1.61** | 62.1% |
| 50% | **−2.00** | 50.0% |
| 25% | **−4.00** | 25.0% |
| **0%** | **−2.00** | **not recoverable — see below** |

So `|score|` **is** the extrapolation factor, and `worst_sample = 100 / |score|`.

**Two selection traps.** First, a sample of exactly `0` takes the `value == 0.0` branch of
`compute_finding_score`, returning `2 × −1 = −2.00` — *milder-looking* than a 25% sample at −4.00, even
though 0% is the worst possible outcome. Since selection keeps the largest `|score|`, **any sample
below 50% out-scores a 0% sample, so a CPU whose counter was never scheduled can be hidden by a merely
degraded one.** Second, `time_series_data_point_threshold_rule.rs` selects with
`if abs_finding_score >= max_abs_finding_score`, so on ties the **last** qualifying point wins, which
need not be the largest. **Never rank multiplexing severity by score; read the series.**

A rate of exactly 0 also means `time_running` was 0, in which case `:1086` skips the metric value
entirely while `:1081`–`:1084` still records the rate — so the 0 data point exists and fires this rule,
but there is no PMU value on that CPU to qualify. That is also what feeds `zero_time_running_metrics`
and the `warn!` at `:1336`.

## Interpretation

The mode decides what the rate costs. Read `pmu_counter_mode` first.

| Worst sample | Grouped (default): coverage loss only | Ungrouped: coverage **and** value skew |
|---|---|---|
| 95–100% | Negligible. Note and proceed | Negligible; skew under 1.05× |
| 75–95% | Fine for absolutes; do not chase sub-10% deltas | Skew to 1.33×; recheck any finding within 33% of its threshold |
| 40–75% | Absolutes still valid; phases under ~2 intervals may be invisible | Skew to 2.5×; treat threshold crossings as unproven |
| < 40% | Trend only. Values remain unbiased but poorly sampled | Unusable for any threshold judgement |
| 0% | The counter was never scheduled; its metric does not exist for that interval | Same, plus `eval_vec` arity errors at `debug!` |

Then establish **how much** of the run and **how many** CPUs were affected. A dip during a transient —
another `perf` session starting, CPU hotplug — is a different finding from a sustained low rate.

**Known false positives — the finding is true but not actionable:**

- **The default configuration, on any platform.** 22–32 grouped counters against ≤16 registers means
  this fires on essentially every default run. Presence alone is not evidence of a problem.
- **A single transient dip.** One 90% sample in an otherwise-100% run. "Any data point" fires.
- **Startup / shutdown intervals.** The first and last intervals often show a partial rate as groups
  are set up and torn down.
- **Grouped mode with a steady workload.** The cancellation is exact and uniformity makes the duty
  cycle representative. The values are simply correct — though you cannot *prove* uniformity from the
  multiplexed data alone.
- **Your conclusion does not rest on PMU data.** If the argument is built on `cpu_utilization` and
  `diskstats`, this touches nothing. Scope the caveat to PMU-derived claims.
- **One idle CPU on a partly-loaded box.** A core with no work can show a degenerate rate while every
  loaded core reads 100.

**True positive with real consequence:** a phased or bursty workload at a low rate (grouped — phases
invisible), or **any** near-threshold finding in ungrouped mode (value skew can manufacture the
crossing).

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `pmu_counter_mode` / the record command line | `systeminfo`, `aperf_run_stats` | **Do this first.** Grouped ⇒ coverage loss only; ungrouped ⇒ values may be skewed |
| `mux_counter_schedule_rate` full series, per-CPU | `perf_stat` | Sustained vs transient; all CPUs or a few; whether any sample is 0 |
| "APerf Logs" — grep for `multiplex` | `aperf_runlog` | The archived `debug!`, naming which metrics lost counters. **No analytical rules** — manual read |
| Every other `perf_stat` metric | `perf_stat` | The values this finding qualifies: `ipc`, all `*-mpki`, all `*-pki`, both `stall-*-pkc`, `code-sparsity` |
| Any `perf_stat` finding within ~30% of its threshold | `perf_stat` | In ungrouped mode these are the ones skew can manufacture; in grouped mode they are unaffected |
| The four TLB rules (`threshold: 0.0`) | `perf_stat` | Fire on any non-zero value, so they are the most exposed to ungrouped skew and to a single fabricated sample |
| `system` | `cpu_utilization` | Multiplexing adds kernel work; a rise can be collection overhead rather than workload |
| `aggregate`, `idle` | `cpu_utilization` | An idle run makes PMU ratios unreliable for an independent reason (`Underutilized CPU`) |
| Per-datatype collection times | `aperf_stats` | Confirms collection overhead. **No analytical rules** — manual read |
| `Kernel Version`, instance type | `systeminfo` | Register count is a CPU property; a virtualized PMU may expose fewer counters than metal |
| `perf_profile` | `perf_profile` | Sampling profiles use the PMU too; heavy multiplexing hints at a competing `perf` session. **No analytical rules** |

## Guidance

Ordered. Steps 1 and 2 decide whether anything else matters.

1. **Read `pmu_counter_mode` before the rate.** It changes the meaning of every number below. Grouped
   (the default, `src/data_collection.rs:379`) ⇒ the scale factor cancels and the metric magnitudes are
   sound; the loss is temporal coverage. Ungrouped ⇒ per-event factors do not cancel and any metric can
   be skewed by up to the extrapolation factor in either direction.

2. **Read the full `mux_counter_schedule_rate` series, per-CPU.** The description gives one sample.
   A worst sample ≥ 95%, or a single isolated dip, means record a one-line caveat and stop. Sustained
   below ~75%, or any 0 sample, means continue. If only a few CPUs were affected, aggregate metrics are
   diluted rather than wrong.

3. **Grep the archived runlog for `multiplex`.** It is in the report under "APerf Logs" and names the
   affected metrics, which is strictly more than the rate alone tells you. No rule reads it, so this is
   a manual step.

4. **Qualify the affected findings — but qualify them correctly.** Every `perf_stat` finding in the run
   is downstream of this one: `Reduced Instructions per Cycle`, both stall rules,
   `High Branch Mispredictions`, the four cache rules, the four TLB rules, `High Code Sparsity`,
   `Old-Style Atomic Instructions`. In **grouped** mode say *"sampled at R% duty cycle; short phases
   may be invisible"* — **not** *"the values may be inflated"*, which is false. In **ungrouped** mode
   say *"may be skewed by up to F×"* and single out anything within `F` of its threshold.

5. **Prefer relative comparisons, and check both rates.** If two runs multiplexed at similar rates in
   the same mode, deltas are more trustworthy than absolutes. A comparison run with a much better rate
   may simply have been recorded ungrouped — verify `pmu_counter_mode` in both before attributing the
   difference to the workload.

6. **To raise the rate, shrink the request — do not reach for `--ungroup-pmu-events` first.** A custom
   `--pmu-config` holding only the metrics you need cuts counters without introducing skew; ungrouping
   cuts the count roughly in half (28 → 15 on `grv`) but buys cross-event skew. Also confirm no other
   `perf` session is competing for the PMU — a common and easily fixed cause.

7. **Check collection overhead.** If `system` time is materially higher than expected, some of it is
   the multiplexing. On a latency-sensitive workload that perturbation may itself be the observable
   effect.

## Priority and execution risk

**Priority: P4 — Informational** by default, and that default is unusually well earned: with 22–32
grouped counters requested against a probed limit of at most 16, this finding fires on essentially every
default run on every supported platform, and in grouped mode it costs no accuracy at all. It rises to
**P2 — Investigate** in three specific situations — the run is **ungrouped** and some other finding sits
within the skew bound of its threshold; the workload is **phased** and the duty cycle is low enough to
hide a phase; or **any sample is exactly 0**, meaning a metric was fabricated for that interval. It sits
at **P3 — Monitor** for a sustained grouped rate below 40%, where the values remain exact but are too
coarse to support phase-level claims. It never reaches P1: this finding is never itself the problem.

**Execution risk: R0 — Read-only** to resolve completely. Establishing the mode, reading the per-CPU
series, grepping the archived runlog, and `--time-range` re-scoping are all reads of data already in the
archive. The two remediations are collection changes, not production changes: a trimmed `--pmu-config`
re-record is **R1 — Config** and `--ungroup-pmu-events` is **R2 — Restart** in the sense that it changes
the collector's error mode rather than the system's behaviour. **Maximum execution risk on this entire
playbook is R2, and no branch of it justifies touching the application** — a workload change can never
be the right response to a counter-scheduling artifact.

**The score is actively misleading and must not be used to rank.** It is `−100 / value`, so `|score|` is
the extrapolation factor and `worst_sample = 100 / |score|` — but the `value == 0.0` branch of
`compute_finding_score` returns `2 × −1 = −2.00`, so a counter that was **never scheduled** scores
milder than a 25% rate at −4.00, and **any sample below 50% out-scores a 0**. Since selection keeps the
largest `|score|`, the worst possible outcome in a run can be hidden from the description by a merely
degraded sample. Rank on the **series**, never on score. Note also that `Concerning` (−1) puts even a
10% rate at −10.00, below every `Poor` and `Critical` finding in the panel — including the
`Old-Style Atomic Instructions` (`Poor`) and `Underutilized CPU` (`Critical`) findings whose validity
this one qualifies.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `mux_counter_schedule_rate` data point on any series, including per-CPU,
was below `100.0`.

```
STEP 0 — Which collection mode? This decides whether VALUES or only COVERAGE is at stake.
  IF `pmu_counter_mode` is grouped (the default)
  THEN → the scale factor CANCELS: :1093 applies one f per metric group and every shipped
         metric is degree-0, so magnitudes are exact. Only coverage is lost. Go to STEP 2
         and qualify with "duty cycle", never "inflated" (P4, R0)
  IF `pmu_counter_mode` is ungrouped (`--ungroup-pmu-events` was passed)
  THEN → per-event factors do NOT cancel (:1216); every metric may be skewed by up to the
         extrapolation factor in either direction. Go to STEP 1 (P2, R0)
  IF the mode cannot be determined from the report
  THEN → assume ungrouped and treat values as suspect; the default is grouped, so this is
         conservative. Recover it from the record command line or `aperf_run_stats` (P3, R0)
       → verify: `tools/aperf_perf_stat.py --mux --rate R --counter-mode unknown` states the
         ambiguity explicitly rather than silently picking a branch

STEP 1 — UNGROUPED ONLY: is any other finding close enough to its threshold to be an artifact?
         Skew bound F = 100 / rate. A true value V is reported anywhere in [V/F, V*F].
  IF a `perf_stat` finding fired with its value within F of its threshold
  THEN → the crossing is UNPROVEN. Report it as unverified, not as a result. A true
         branch-mpki of 7.0 reaches the 10.0 GreaterEqual threshold at a 70%/100% spread
         (P2, R0)
       → verify: re-record GROUPED with a trimmed `--pmu-config`. If the finding vanishes it
         was skew; if it survives, the value was real
  IF one of the four TLB rules fired (`threshold: 0.0`, any non-zero value)
  THEN → most exposed of all: no margin exists to absorb skew, and one fabricated sample is
         enough. Treat as unproven until re-recorded grouped (P2, R0)
  IF every fired finding sits far from its threshold
  THEN → skew cannot have manufactured the verdicts; proceed to STEP 2 for coverage (P3, R0)

STEP 2 — How much of the run, and how many CPUs? The description gave you ONE sample.
  IF the worst sample is >= 95%, or is one isolated dip in an otherwise-100% series
  THEN → immaterial. One-line caveat, no further action. This is the common case and the
         default config guarantees the finding fires (P4, R0)
  IF only a few CPUs multiplexed while `Aggregate` reads 100
  THEN → the rule fired off a per-CPU series (processed_data_accessor.rs:104). Aggregate
         metrics are diluted, not wrong; scope any caveat to those CPUs (P4, R0)
  IF the rate is sustained below 75% across CPUs
  THEN → material coverage loss; continue to STEP 3 (P3, R0)
  IF any sample is exactly 0
  THEN → that counter was NEVER scheduled: :1086 skipped the metric, so its value is absent
         for that interval while :1081 still recorded the 0 rate. Any metric depending on it
         is fabricated there (P2, R0)
       → verify: a 0 scores only -2.00 and ANY sample below 50% out-scores it, so search the
         series directly for zeros; the description will not surface them
  IF the first or last interval alone is low
  THEN → group setup/teardown. Exclude those samples and re-read (P4, R0)

STEP 3 — Was the workload uniform? In grouped mode this is the ONLY thing the rate costs.
  IF `aggregate` CPU utilization and the PMU metrics are flat over time
  THEN → the duty cycle is representative and the values are usable as absolutes even at a
         low rate. Report the rate as a resolution caveat only (P4, R0)
  IF the run shows visible phases, bursts or periodicity
  THEN → a phase occupying less than F intervals can be missed entirely. Claims about
         specific phases are unsupported; run-wide averages remain sound (P2, R0)
       → verify: re-scope with `--time-range` to one phase. The stat is re-derived from the
         surviving samples (`compute_time_diff_index`, processed_data_accessor.rs:597) with
         no re-record; if a phase's metrics differ sharply from the run average, the run
         average was hiding it
  IF `Underutilized CPU` also fired
  THEN → two independent validity problems compound: idle dilution AND coarse sampling.
         Fix the scoping first, since it needs no re-record (P2, R0)

STEP 4 — Only if a quantitative answer is still needed: raise the rate.
  IF you need specific metrics rather than the full default set
  THEN → re-record with a custom `--pmu-config` holding only those metrics. This is the
         PREFERRED fix: fewer counters, no new error mode (P2, R1)
       → verify: `mux_counter_schedule_rate` reaches 100 and the metric values agree with the
         multiplexed run. In grouped mode they SHOULD already agree — a disagreement means
         the duty cycle was unrepresentative, which is itself the answer
  IF you need the whole default metric set at a higher rate
  THEN → `--ungroup-pmu-events` roughly halves the counters (28 -> 15 on grv) but replaces
         coverage loss with cross-event skew. Accept only if you will not judge anything
         near a threshold (P3, R2)
       → verify: compare the two runs metric by metric. Values that move by more than
         sampling noise identify exactly which metrics the skew touches
  IF another `perf` session or agent is running on the box
  THEN → it is competing for the same registers. Stop it and re-record; this is the one
         cause with a complete fix (P2, R1)
       → verify: `probe_pmu_counter_limit` (:344) binary-searches the limit at record time,
         so with the competitor gone it should probe higher and the rate should rise without
         any change to the requested event set
  IF the instance is virtualized and exposes fewer counters than the CPU has
  THEN → the probed limit is a property of the hypervisor's PMU passthrough. A metal
         instance of the same family is the only way to raise it (P3, R2)
       → verify: compare the probed limit between the virtualized and metal runs. If it does
         not change, the hypervisor was not the constraint and the event set was

STEP 5 — Comparing two runs.
  IF both runs multiplexed at similar rates in the SAME mode
  THEN → deltas are more trustworthy than either absolute. Report both rates alongside the
         delta (P3, R0)
  IF the runs used DIFFERENT modes
  THEN → the difference in rate is a collection artifact, not a workload change. In grouped
         mode magnitudes are exact and in ungrouped they are skewed, so the two runs'
         absolutes are not commensurable at all. Re-record to match before comparing
         (P2, R1)
       → verify: re-record the faster run in the SLOWER run's mode. If the metric difference
         vanishes it was the mode; if it survives, the workload really did change
  IF the rates differ sharply in the same mode
  THEN → something changed about PMU availability, not necessarily the workload: a competing
         consumer, a different instance size, or hotplug (P3, R0)

STEP 6 — What survives?
  VALID      : in GROUPED mode, every perf_stat metric MAGNITUDE at any schedule rate --
               the factor cancels exactly; the recovered worst sample `100 / |score|` for
               any non-zero value; every non-PMU finding in the run
  CAUTION    : in grouped mode, any claim about a specific PHASE at a low rate; in
               ungrouped mode, every metric magnitude, bounded to [V/F, V*F]
  CONFOUNDED : in ungrouped mode, any threshold crossing within F of its threshold -- the
               four `threshold: 0.0` TLB rules most of all; and any rate comparison across
               instance families, whose configs request different event counts
  VOID       : any metric on an interval whose rate was 0 (:1086 skipped it); any severity
               RANKING by score, since 0% scores milder than 25%; and the claim that a
               grouped metric's numerator and denominator came from different time slices

INSUFFICIENT DATA
  IF `pmu_counter_mode` cannot be recovered from the report or the command line
  THEN → the central question of this playbook is unanswerable. Report the rate as a
         coverage caveat only and do NOT assert anything about magnitudes in either
         direction (P3, R0)
  IF `perf_stat` is absent from the run
  THEN → no PMU passthrough, so this rule could not fire and its silence proves nothing
         about counter scheduling (P4, R0)
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 rate samples per series. One low interval is 10% of the run, and the
         flat unweighted mean over (CPU, metric-group) pairs (:999-:1030) makes a single
         degenerate group visible in the aggregate rate (P3, R0)
```

## Runtime-specific consequences

**Everything below is about the collector, not the runtime** — multiplexing is decided by hardware
register count and the requested event set, so no language runtime changes the mechanism. The
consequences differ only in what a lost duty cycle hides.

- **JIT'd runtimes (Java, .NET).** Behaviour changes qualitatively as compilation proceeds:
  interpreted, then profiled, then optimized. These are genuine phases, so a low rate in a short run
  can miss the steady state entirely and over-weight warmup. Prefer a longer recording over a higher
  schedule rate — the values themselves are already sound in grouped mode.
- **Garbage-collected runtimes.** GC pauses are bursty by construction and have a wildly different PMU
  signature from application code. A low duty cycle may sample disproportionately inside or outside
  collections, and neither the rate nor the metric reveals which.
- **Native code, steady-state services.** The best case: uniform behaviour makes the duty cycle
  representative and grouped-mode values usable as absolutes even at a low rate.
- **Short-lived processes and batch jobs.** Setup and teardown intervals are a larger share of the
  recording, and those are exactly the intervals with partial schedule rates.
- **Containers.** Neither cgroups nor namespaces partition PMU registers; a co-tenant container's
  `perf` session competes for the same counters and shows up here with no attribution.

## Architecture-specific considerations

The finding is defined on **all 8 PMU profiles** and multiplexes on every one of them by default — but
severity is architecture-dependent for a reason unrelated to the workload: **a profile with more
metrics multiplexes harder.**

- **Grouped mode duplicates shared events per metric.** `Instructions` appears in the denominator of
  nearly every `*-mpki` metric, and each metric gets its own group, so it is allocated once per
  metric. This is why the grouped counter counts (22–32) run roughly double the unique-event counts
  (12–18), and why ungrouping halves the request.
- **Register count is the divisor.** Neoverse cores expose ~6 programmable counters plus a dedicated
  cycle counter; `probe_pmu_counter_limit` (`:344`–`:402`) binary-searches the real limit between 1 and
  16 at record time using an architecture-specific probe event —
  `armv8_pmuv3_0/event=0x3/` on Graviton, `cpu/event=0x51,umask=0x1/` on Intel,
  `cpu/event=0xc2,umask=0x0/` on AMD. On x86 an oversized group fails with `EINVAL`; elsewhere the
  probe checks `time_running >= time_enabled`.
- **`spr` requests the most (32 grouped counters), `amd` the fewest (22).** Two runs on different
  instance families can show materially different schedule rates for the same workload. Never read a
  rate difference across families as a workload difference.
- **CPU detection is brittle exact-string matching** (`src/data/common/utils.rs:20`–`:100`).
  `is_intel_icelake()` compares against the literal `"Intel(R) Xeon(R) Platinum 8375C CPU @ 2.90GHz"`;
  SPR against `"Intel(R) Xeon(R) Platinum 8488C"`. An unlisted part falls back to the generic vendor
  config, which requests a *different* event count — so the expected rate changes with a CPU aperf
  merely failed to recognize.
- **`is_graviton()` is just `self.part.is_some()`** — any CPU exposing a `CPU part` line in
  `/proc/cpuinfo` is treated as Graviton. On a non-Graviton AArch64 part the Graviton event set is
  requested wholesale, and unsupported events are dropped with an `error!` at `:255` rather than
  surfacing here.
- **Virtualized PMUs.** A hypervisor may expose fewer counters than the physical CPU, or none. On
  instances without PMU passthrough `perf_stat` is absent entirely and no finding — including this one
  — is possible; silence proves nothing.

## Verification

Confirm the mode and the distribution before qualifying anything, and confirm the fix by agreement
rather than by the rate alone.

1. **Establish the mode.** `pmu_counter_mode` in the run metadata, or `--ungroup-pmu-events` in the
   record command. Everything downstream depends on it.
2. **Read the series, not the description.** Per-CPU and `Aggregate`. Confirm: sustained or transient,
   all CPUs or some, and whether any sample is exactly 0 — a 0 is *out-scored* by any sample below 50%
   and will not appear in the description.
3. **Quantify.** `python3 tools/aperf_perf_stat.py --mux --rate R --counter-mode grouped|ungrouped`
   gives the factor, the trust band, and the mode-specific caveat set. Cross-check the recovered rate
   against `100 / |score|`.
4. **Grep the archived runlog** ("APerf Logs") for `multiplex` to learn *which* metrics lost counters.
5. **Test uniformity.** Re-scope with `--time-range` to a single phase. If the phase's PMU values
   differ sharply from the run average, the duty cycle was hiding real structure — no re-record needed.
6. **If you re-record grouped with fewer metrics, the values should MATCH the multiplexed run.** That
   is the falsifiable prediction of the cancellation argument: in grouped mode a trimmed config raises
   the rate to 100 and leaves the magnitudes alone. **A disagreement beyond sampling noise means the
   duty cycle was unrepresentative** — which is a finding about the workload's phases, not about the
   collector.
7. **If you re-record ungrouped, expect the values to MOVE**, and treat whichever metrics move as the
   ones the per-event skew touches.

## Do not

- **Do not say "the values may be inflated" in grouped mode.** The scale factor cancels exactly; the
  magnitudes are what they would have been without multiplexing. Say "sampled at R% duty cycle".
- **Do not treat the finding's presence as evidence of a problem.** 22–32 grouped counters against ≤16
  registers means it fires on essentially every default run on every supported platform — as
  `warn_multiplexing`'s own TODO admits.
- **Do not read the score as severity.** A 0% rate scores −2.00, milder-looking than 25% at −4.00, and
  any sample below 50% out-scores a 0. Read the values.
- **Do not assume the worst sample is representative.** The template reports one data point out of
  every series including per-CPU; a 100%-throughout run with one bad sample is indistinguishable in the
  description from a run multiplexed the whole time.
- **Do not reach for `--ungroup-pmu-events` as the first fix.** It halves the counter request but
  replaces a benign coverage loss with a real value skew that grouped mode cannot have. Trim the
  `--pmu-config` instead.
- **Do not claim `ipc`'s numerator and denominator came from different time slices.** In grouped mode
  they are in the same group by construction (`:243`–`:272`), so they never do.
- **Do not re-apply the correction.** `:1093` and `:1216` already scale the counters. Multiplying by
  `100/rate` again double-compensates.
- **Do not fix this by tuning the workload.** It is a collection-configuration property. Nothing here
  justifies an application change.
- **Do not compare PMU absolutes across runs recorded in different modes,** or across instance families
  whose configs request different event counts.
- **Do not conflate this with `Underutilized CPU`.** They are independent validity problems that
  compound: an idle run *and* a coarsely sampled one carries two separate sources of error.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:139`–`:146` (`Comparator::Less`, threshold
  `100.0`, `Score::Concerning`).
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — worst-sample
  selection, and the `>=` tie-break that keeps the *last* tied point.
- Grouped collection and scaling: `src/data/perf_stat.rs:243`–`:272` (one group per metric),
  `:1078`–`:1101` (the shared factor), `:1133`–`:1148` (the CPU-sum aggregate).
- Ungrouped collection: `:283`–`:337` (event counters), `:1157`–`:1278` (per-event scaling at `:1216`),
  and the source's own skew comment at `:277`–`:280`.
- The rate metric itself: `update_counter_schedule_rate_metric`, `:999`–`:1030` — a flat unweighted
  mean over `(CPU, metric-group)` pairs.
- Counter-limit probe: `probe_pmu_counter_limit`, `:344`–`:402`; `PMU_COUNTER_LIMIT_UPPER_BOUND` at
  `:339`. The collection-time warning: `warn_multiplexing`, `:59`–`:64`, called from `:224` and `:289`.
- Runlog reachability: `init_logger`, `src/bin/aperf.rs:65`–`:104`; archived at
  `src/data_collection.rs:213`–`:214`; `impl AnalyzeData for AperfRunlog {}` in
  `src/analytics/rules/aperf_runlog.rs` (no rules).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — note the `value == 0.0` branch.
- Metric definitions: `src/pmu_configs/*.json`, merged by `extend_from_default` (`:200`, `:765`–`:790`).
- Quantifier: [`../tools/aperf_perf_stat.py`](../tools/aperf_perf_stat.py) `--mux --rate R
  --counter-mode M` and `ungrouped_skew_bound`; `tools/test_aperf_perf_stat.py` pins the degree-0
  homogeneity of all 31 expression forms and both scaling paths.
- [Arm — perf and the PMU on Armv8 CPUs, part 2](https://developer.arm.com/community/arm-community-blogs/b/architectures-and-processors-blog/posts/p2-perf-pmu-feature-armv8-cpus)
  (the `helpfulLinks` entry aperf attaches to this metric; covers multiplexing and scaling).
- [Graviton perfrunbook — debugging hardware performance](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html)
- Related playbooks: `reduced-instructions-per-cycle.md`, `frontend-dominated-cpu-stalls.md`,
  `backend-dominated-cpu-stalls.md`, `high-branch-mispredictions.md`,
  `old-style-atomic-instructions.md` — all qualified by this one.
