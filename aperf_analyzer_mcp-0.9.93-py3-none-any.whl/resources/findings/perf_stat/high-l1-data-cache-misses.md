---
rule_name: High L1 Data Cache Misses
data_type: perf_stat
data_key: data-l1-mpki
template: time_series_data_point_threshold
condition: "any(data-l1-mpki) > 20.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "This indicates the working set data footprint could be an issue and can cause CPU backend stalls."
source: src/analytics/rules/perf_stat.rs:92
---

# High L1 Data Cache Misses

## What fired

**At least one** data point of `data-l1-mpki` was **greater than 20.0** per thousand instructions, in
**any** series including per-CPU. A single sample anywhere in the recording is enough.

Base score `Concerning` (−1). Single-run rule. The threshold is **twice** that of `High L2 Cache Misses`
and `High L3 Cache Misses` (both 10.0), so equal scores across those rules mean very different values.

## The processing caveat — the metric counts line FILLS, not misses

The description says "level 1 data cache misses", and on **no profile** is that what the counter measures.
Every one of the eight resolves to a **line-fill** or **replacement** event:

| Profiles | Expression names | Event | What the hardware counts |
|---|---|---|---|
| `grv`, `grv5` | `L1_Data` | `armv8_pmuv3_0/event=0x3/` | L1D cache **refills** — lines brought in |
| `intel`, `icelake`, `spr` | `L1_Data` | `cpu/event=0x51,umask=0x1/` | L1D **replacements** — lines allocated |
| `amd`, `milan`, `genoa` | **`L1_Data_Fills`** | `cpu/event=0x44,umask=0xff/` | L1 data **fills**, all sources (the config's own name says so) |

**Fills ≤ misses.** Several misses to the same line while one fill is outstanding merge into that single
fill, so a workload with many hits-under-miss on the same line reports a *lower* `data-l1-mpki` than its
true miss count. The metric is therefore a **lower bound on misses** and a faithful measure of **memory
traffic** — the more useful of the two here, since traffic is what costs cycles and bandwidth, but it means
"misses per thousand instructions" should be read as "lines pulled into L1D per thousand instructions".

**Two consequences worth acting on.** First, **false sharing is fully counted**: each invalidation forces a
fresh refill, so a ping-ponged line inflates this metric even though the working set is tiny — the basis for
the discriminator in STEP 4. Second, on **AMD** the `l3-mpki` event is `0x44` umask **`0x8`**
(`L1_Any_Fills_DRAM`), a strict **umask subset** of this metric's `0x44` umask `0xff`. So on AMD
`l3_of_l1 = l3-mpki / data-l1-mpki` is a genuine fraction — "what share of L1D fills came from DRAM" —
while `l3_of_l2` is not, because AMD's `l2-mpki` is a different event entirely (`0x64` umask `0x9`, demand
misses). On Intel it is **exactly inverted**: `l3_of_l2` is the valid fraction and `l3_of_l1` is not, since
Intel's `l3-mpki` includes instruction and prefetch misses that never appear as L1D replacements.
`hierarchy_funnel` computes both ratios on every profile and its `l3_ratio_valid` flag describes
`l3_of_l2` only — so the containment argument above is the only thing licensing `l3_of_l1` on AMD, and it
does not generalize.

**Unlike its sibling `l2-mpki`, this metric survives the SPR refresh:** the encoding stays `0x51` umask
`0x1` across `intel`, `icelake` and `spr`, so `cross_architecture_comparable('data-l1-mpki','intel','spr')`
is **True** where the same call for `l2-mpki` is **False**. Do not carry the L2 comparability table over.

**What is *not* defective:** the threshold is non-zero, `compute_finding_score` is monotonic and the
template reports the **series peak** — verified, `--select 25 12 45 30 --threshold 20 --rule-score -1`
selects `45.0`. Unlike the four zero-threshold TLB rules, the value in the description is the maximum.

## Reasoning

`data-l1-mpki` is "Level 1 data cache misses per thousand instructions, indicating data access patterns and
cache efficiency for frequently accessed data" (`data-descriptions.ts`, `desired: "lower"`).

L1D is the smallest and fastest data cache — typically 32–64 KB per core, 3–5 cycle hit. It is small
enough that **almost every workload misses it constantly**, which is why the threshold is 20.0 rather than
the 10.0 used one level down: a high value here is normal and, on its own, not a problem.

**The escalation pattern is the diagnosis, not the value.** What matters is where the misses terminate:

- **Served by L2** (~15–20 cycles, `l2-mpki` low): a **spatial locality** inefficiency. The data is close
  by; the code is just not touching it in the order it is laid out. Struct field reordering, hot/cold
  splitting and array-of-structs → struct-of-arrays conversion are the levers, and they are cheap.
- **Served by L3** (`l2-mpki` high, `l3-mpki` low): a **capacity** problem at the per-core level. Tiling.
  Go to `High L2 Cache Misses`.
- **Served by DRAM** (`l3-mpki` high): a **footprint** problem. Go to `High L3 Cache Misses`.

So this finding's job is to hand off correctly. Acting on it in isolation — restructuring layout when the
misses were reaching DRAM anyway — is the characteristic waste here. There is one exception, and it is the
highest-value finding this playbook can produce:

| Cause | Signature | Lever |
|---|---|---|
| **False sharing** | High `data-l1-mpki` with a **small** working set and multiple threads writing nearby addresses. Misses per *line* are enormous while data volume is trivial | **Padding to a cache line**, or per-thread accumulators. A few lines of code, no footprint change, and the metric collapses |
| **Poor spatial locality** | Misses land in L2; the structure is larger than a line but only one field is read | Field reordering, hot/cold splitting, AoS→SoA |
| **Random access** | Pointer chasing, hash lookups, indirection through indices. Prefetchers cannot predict | Flattening, index-based layouts, explicit prefetch |
| **Working set exceeds L1D** | `l2-mpki` also elevated. The common, benign case | Tiling — but at the L2 level, not here |
| **Streaming with no reuse** | Copy, hash, scan, compress. Each line touched once | Not a defect. Non-temporal stores stop it evicting the hot set |

And a caveat that limits every reading: this is a rate **per instruction, not per memory access**. aperf
does not collect the load/store count, so a value of 40 could be a memory-light loop missing on nearly
every access or a memory-heavy loop with a good hit rate, and nothing in the report distinguishes them.
Combined with the fills-not-misses point above, the metric measures **traffic per unit of work** and should
be reasoned about that way.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 32.00 (greater than the threshold of 20).
```

`32.00` **is** the series peak — but it is **not the average**, and a run that touched 32 MPKI once during
a load phase reports identically to one that sat there throughout. **It may also be one CPU's series**:
this template iterates **every** series including per-CPU (`time_series_metric_values_iterator`,
`processed_data_accessor.rs:104`), unlike the stat-based `perf_stat` rules that read only `Aggregate`
(`:432`). The value is **truncated, not rounded** (`f64_to_fixed_2`,
`src/computations/mod.rs:138`), so `32.00` is anything in `[32.00, 32.01)`. And there is **no
`(n−1)/n` dilution correction**: `perf_stat` opts out of the forced first zero via
`use_first_accumulative_value()` (`src/data/perf_stat.rs:1295`), so the first sample is real.

Score math — `compute_finding_score(value, 20.0, −1)`. The value always exceeds the threshold, so no
inversion applies and the score is linear in it:

| worst sample | score |
|---|---|
| 24.0 | `(24/20) × −1` = **−1.20** |
| 32.0 | `(32/20) × −1` = **−1.60** |
| 50.0, then 80.0 | `(50/20) × −1` = **−2.50**, `(80/20) × −1` = **−4.00** |

Recover the sample as `value = |score| × 20`. **The multiplier is 20 here and 10 at L2 and L3**, so a score
of −2.00 means 40 MPKI in this rule and 20 MPKI in those.

**Every other sentence this rule can produce**, including the silences:

| Situation | What you get |
|---|---|
| `perf_stat` was not collected | no finding, and the silence proves nothing — aperf needs metal or a virtualized PMU, and a `perf_event_paranoid` refusal is silent |
| The peak sits at or below 20.0 | no finding — but the counter measures fills, so a hits-under-miss-heavy workload can be under the threshold with a far higher true miss count |
| Only one `CPU{n}` series exceeded | reported for the whole run; the `Aggregate` series may be well under 20. On a false-sharing bug this is the **expected** shape |
| The run multiplexed heavily | the peak is an extrapolation, and one distorted interval is sufficient to fire |
| The profile is `amd`, `milan` or `genoa` | the expression names `L1_Data_Fills`, not `L1_Data` — and this is the one profile family where `l3_of_l1` is a valid fraction |
| The profile is `spr` | comparable with `intel` and `icelake` here, unlike `l2-mpki` |

## Interpretation

| sustained value | Reading |
|---|---|
| 20–40 | Common. Many healthy workloads live here; the escalation pattern decides whether it matters |
| 40–80 | Substantial L1D traffic. Worth attributing |
| > 80 | Very high — check false sharing **first**, before assuming a footprint problem |

The escalation pattern is the diagnosis:

| `data-l1-mpki` high **and** | Reading |
|---|---|
| sustained across the series | Genuine. One isolated sample is a load phase, checkpoint, GC cycle or warm-up, and is not |
| `l2-mpki` **low** | **Locality, not capacity.** Misses are absorbed at ~15–20 cycles. Layout work — field reordering, hot/cold splitting, AoS→SoA. The cheapest and most common actionable case |
| `l2-mpki` high, `l3-mpki` low | Per-core capacity. Tiling. Go to `High L2 Cache Misses` |
| `l3-mpki` high | Footprint, reaching DRAM. Go to `High L3 Cache Misses` — layout work alone will not help |
| the working set is **small** and threads write nearby addresses | **False sharing.** Highest-leverage outcome in this playbook: padding fixes it, footprint reduction does not |
| `strex-spec-pki` elevated (arm64) | Contended atomics on shared lines — the same root cause as false sharing, seen from the exclusive-store side |
| `data-tlb-mpki` non-zero | Translation cost stacked on the same accesses, with an independent and cheaper huge-page fix |
| `Backend-Dominated CPU Stalls` fired | **The confirmed case** — the misses are blocking issue |
| `ipc` healthy (> 2) | The core is hiding a 3–5 cycle L1D miss behind other work, which is exactly what it is built to do. Low priority |
| `number_threads` high | Threads per core divide L1D and L2, so per-thread miss rates rise with no change in the code |

**Known false positives — check these before restructuring:**

- **A single transient sample.** The dominant false positive for every
  `time_series_data_point_threshold` rule. Load phases, checkpoints, GC cycles and cache warm-up all spike
  it, and the peak is exactly what gets reported.
- **PMU multiplexing.** If `PMU Counter Collection Multiplexing` fired, the peak is an extrapolation and
  one distorted interval fires the rule.
- **One hot CPU.** The rule reads every per-CPU series, so a few threads fire it for the whole run while
  the aggregate is benign. **Idle-diluted runs** are the same class: background daemons contribute their
  own fill behaviour.
- **A high value that L2 absorbs.** The most common false positive *in substance* rather than in
  measurement: 40 MPKI with `l2-mpki` at 3 costs almost nothing end to end.
- **Streaming or one-pass work.** Copying, hashing, compressing or scanning large buffers has no reuse, so
  the fills are the cost of the work. **GC** is the same story — it sweeps large regions by design.
- **Interpreted or reference-heavy runtimes.** A pointer-graph object model produces high L1D traffic
  structurally; see the runtime table.
- **High thread count per core.** Not a defect — but reducing concurrency may improve throughput.
- **A memory-light workload.** Because the denominator is instructions rather than memory accesses, a loop
  that issues few loads but misses on most of them looks identical to a load-heavy loop with a good hit
  rate, and aperf collects nothing that separates them.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `data-l1-mpki` full series and per-CPU | `perf_stat` | **Do this first.** Sustained vs transient; per-thread concentration, which is also the false-sharing shape |
| `l2-mpki` | `perf_stat` | **The key discriminator** — locality (L2 absorbs) vs capacity (it does not). See `High L2 Cache Misses` |
| `l3-mpki` | `perf_stat` | Whether the chain reaches DRAM. Feed all three to `--funnel`. See `High L3 Cache Misses` |
| `strex-spec-pki` | `perf_stat` | **arm64 only** — contended exclusive stores, the same root cause as false sharing from the atomics side |
| `stall-backend-pkc` vs `stall-frontend-pkc`, `ipc` | `perf_stat` | **Severity gate.** See `Backend-Dominated CPU Stalls`; `ipc` says whether the core absorbs the latency |
| `data-tlb-mpki`, `data-tlb-tw-pki` | `perf_stat` | Independent translation cost on the same accesses, with a cheaper fix. See `Data TLB Misses` |
| `mux_counter_schedule_rate` | `perf_stat` | **Confidence gate.** Below 100 ⇒ the peak may be an extrapolation artifact |
| `number_threads`, `resident_set_size_bytes` | `processes` | Threads per core sharing L1D/L2, and per-process footprint. **No analytical rules** |
| `pgminorfault`, `pgfault` | `vmstat` | Allocation churn evicting live data. See `Increased Minor Page Faults` |
| `numa_hit`, `numa_miss`, `other_node` | `numastat` | Remote-node service raising the cost of each fill without changing the rate. **No analytical rules — read manually** |
| `MemAvailable`, `AnonHugePages` | `meminfo` | Memory pressure, and whether huge pages cut the translation component |
| `idle`, `aggregate` | `cpu_utilization` | Dilution check |
| `Instance Type` | `systeminfo` | The **only** clue to which PMU profile — and therefore whether the expression named `L1_Data` or `L1_Data_Fills`. L1D size and line size are also instance properties aperf does not report |
| On-CPU profile | `perf_profile` / `java_profile` | Which code performs the missing accesses. Requires `--profile`. **No analytical rules for `perf_profile`** |
| Hotline output | `hotline` | Address-level attribution — the fastest way to *see* a false-shared line. Native code on metal Graviton. **No analytical rules, no `data-descriptions.ts` entry** |
| Memory allocation profile | `java_profile` | Allocation-driven cache pollution (`--profile-java`) |

## Guidance

Ordered. Step 1 disposes of transients; step 4 is the discriminator that decides whether this is a cheap
layout fix, a false-sharing bug, or a problem belonging to another playbook entirely.

1. **Read the `data-l1-mpki` series before anything else.** An **isolated spike** at startup, a phase
   boundary or aligned with GC ⇒ transient; stop. **Sustained above 20** ⇒ continue. Check per-CPU:
   concentration on a few CPUs points at specific threads — and if their working set is small, at false
   sharing.

2. **Note which config entry produced the metric.** Read `Instance Type`. On **`amd`/`milan`/`genoa`** the
   expression names `L1_Data_Fills` (`0x44` umask `0xff`); on the other five it names `L1_Data` (`0x3` on
   arm64, `0x51` umask `0x1` on x86). All are fill or replacement counters, so the value is memory
   **traffic** per thousand instructions and a lower bound on true misses. Unlike `l2-mpki`, `spr` is
   comparable with `intel` and `icelake`.

3. **Gate on measurement confidence, then on severity.** Check `mux_counter_schedule_rate` (`PMU Counter
   Collection Multiplexing`) and `avg(idle)` (`Underutilized CPU`). Then compare `stall-backend-pkc` with
   `stall-frontend-pkc` and read `ipc`: a healthy IPC with high L1D traffic means the core is absorbing
   3–5 cycle misses, which is low priority by design. On generic `amd` neither stall metric exists, so use
   `ipc` alone.

4. **Read `l2-mpki` — this is the discriminator.** Use the funnel rather than the three findings
   separately:

   ```
   $ python3 ../tools/aperf_memory_hierarchy.py --funnel --data-l1 45 --l2 22 --l3 14 --profile intel
   l2_of_l1: 0.489, l3_of_l2: 0.636, l3_of_l1: 0.311, boundary: dram, l3_ratio_valid: true
   ```

   `boundary: l1` means L2 absorbs the misses: a **locality** problem, fixable by layout, and the cheapest
   outcome available. `boundary: l2` or `dram` means capacity or footprint, and the finding to act on is
   the next one up. On AMD read `l3_of_l1` rather than `l3_of_l2` — the umask containment makes it the
   valid fraction there, the inverse of Intel.

5. **Rule false sharing in or out — do this before any footprint work.** If total data volume is small,
   multiple threads write to nearby addresses, and per-CPU series are unevenly elevated, pad the contended
   structure to a cache line or give each thread its own accumulator. On arm64 check `strex-spec-pki`:
   elevated exclusive-store speculation on the same lines is the same bug from the atomics side. `hotline`
   shows the offending address directly. This is a handful of lines of code and it collapses the metric —
   no other lever here has that ratio.

6. **Attribute the accesses.** With `--profile` find the stacks that stall; for native code on metal
   Graviton, `hotline` identifies the specific missing accesses and is the prerequisite for prefetch
   placement.

7. **Remediate layout**, per `DATA_FOOTPRINT_OPTIMIZATION`, in order of leverage at *this* level:
   **reorder struct fields** so co-accessed data shares a line; **split hot from cold fields** so a line
   holds only what the loop reads; **convert array-of-structs to struct-of-arrays** for column-wise
   traversal; **access memory sequentially** so the prefetcher can work; **flatten pointer chases** into
   index-based layouts; and **insert prefetches** at hotline-identified sites where randomness is
   unavoidable. Note what is *not* on this list: tiling and total footprint reduction belong at L2 and L3.

8. **Check the cheap adjacent levers.** `data-tlb-mpki` / `data-tlb-tw-pki` non-zero adds an independent
   huge-page fix that is configuration-only. `number_threads` (`processes`) high means threads per core
   divide the cache, and reducing it is R1 and reversible. `numastat` shows remote-node service, which
   multiplies the cost of each fill without changing the rate — and has no analytical rules, so nothing
   flags it.

## Priority and execution risk

**Priority: P3 — Monitor** by default, and this is the one memory-hierarchy finding whose default is *not*
P2. L1D is 32–64 KB with a 3–5 cycle hit cost; missing it constantly is normal, out-of-order execution
hides much of it, and the rule fires on a single sample above 20.0. It rises to **P2 — Investigate** when
the elevation is sustained **and** `Backend-Dominated CPU Stalls` fired with low `ipc`, and to
**P1 — Act now** in exactly one case: **false sharing** — a small working set with unevenly elevated
per-CPU series, where a padding change is R2 and the payoff is immediate. It drops to
**P4 — Informational** whenever the run multiplexed, when only one `CPU{n}` series is elevated with no
false-sharing signature, or when `l2-mpki` is low enough that the misses cost tens of cycles at most. When
`l3-mpki` is high, the priority belongs to **that** finding and this one is context.

**Execution risk: R0 — Read-only** to diagnose: the series, the per-CPU split, the funnel, the stall
comparison, `strex-spec-pki`, `number_threads` and `numastat` are all reads. **R1 — Config change** for a
thread-count reduction or `numactl` pinning, reversible in a restart. **R2 — Code change** for the layout
levers — padding, field reordering, hot/cold splitting — with **R3 — Rebuild** for AoS→SoA conversion and
prefetch placement, which change data structures broadly enough to need correctness re-validation.
**R4 — Infrastructure change** for huge pages. Note the risk ordering inverts the usual advice here: the
single most valuable action, cache-line padding, is also among the cheapest.

**The score is monotonic and comparable across runs of this same rule** — `value = |score| × 20` recovers
the peak exactly. It is **not** comparable with `High L2 Cache Misses` or `High L3 Cache Misses`
(threshold 10.0, and `Bad` at L3), and not comparable across vendors.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one sample of `data-l1-mpki`, in any series including per-CPU, exceeded `20.0`
(`Greater 20.0`). The reported value is the series peak — verified, unlike the four zero-threshold TLB
rules — and it counts line **fills**, so it is a lower bound on true misses.

```
STEP 0 — Does the data exist, and what did the counter measure?
  IF `perf_stat` is missing from the run
  THEN → the rule returned early; NO finding was possible and the silence proves nothing.
         aperf needs metal or a virtualized PMU, and a perf_event_paranoid refusal is silent
         (P3, R0)
  IF `Instance Type` maps to `amd`, `milan` or `genoa`
  THEN → the expression names L1_Data_Fills (0x44 umask 0xff), all fill sources. That umask is a
         strict SUPERSET of AMD's l3-mpki event (0x44 umask 0x8), so here -- and only here --
         `l3_of_l1` is a genuine fraction while `l3_of_l2` is not (P3, R0)
       → verify: `resolved_events('data-l1-mpki','amd')` returns event=0x44,umask=0xff and the
         same call for `l3-mpki` returns umask=0x8; read l3_of_l1 from `--funnel`, not l3_of_l2
  IF `Instance Type` maps to `intel`, `icelake` or `spr`
  THEN → the encoding is 0x51 umask 0x1 on ALL THREE, so unlike l2-mpki this metric IS comparable
         across the SPR refresh. Do not carry over the L2 comparability table (P3, R0)
  IF the profile cannot be identified
  THEN → the value is still readable as traffic per thousand instructions, but no cross-run
         comparison is licensed: continue to STEP 1 and report the magnitude only (P4, R0)

STEP 1 — Is it sustained, and is it the instance or a few threads?
  IF the elevation is one or two isolated samples
  THEN → a load phase, a checkpoint, a GC cycle or cache warm-up. The template reports the PEAK,
         so one spike produces the largest number the run ever saw. Record and STOP (P4, R0)
  IF only one or two `CPU{n}` series exceed 20.0
  THEN → this template iterates EVERY series (processed_data_accessor.rs:104), so a few threads
         fire it for the whole run while the Aggregate series may be well under 20. Do NOT dismiss
         it yet -- this is also the false-sharing shape, so go to STEP 4 (P3, R0)
       → verify: the on-CPU profile names those threads and the elevated CPUs are the ones running
         them; if the CPUs are unrelated to the workload, it is background noise
  IF every CPU is elevated roughly uniformly AND `number_threads` is high
  THEN → threads per core are dividing L1D and L2 between them, so the code may be innocent
         (P3, R1)
       → verify: halving the thread count lowers per-thread data-l1-mpki AND raises per-core
         throughput; if throughput falls, cache sharing was not the constraint

STEP 2 — Gate on measurement confidence.
  IF `mux_counter_schedule_rate` < 100
  THEN → the peak is an extrapolation by a factor of 100/R, and one distorted interval fires the
         rule. Report low-confidence and do NOT act on the magnitude (P4, R0)
       → verify: re-record with `--ungroup-pmu-events`; if the peak collapses, the original finding
         was a multiplexing artifact
  IF `Underutilized CPU` fired
  THEN → background daemons contribute their own fill behaviour, so the peak may not be the
         workload's (P4, R0)
       → verify: re-scope with `--time-range` to the loaded interval; a value that RISES confirms
         the workload, one that falls confirms the daemons

STEP 3 — Is the miss cost actually being paid?
  IF `ipc` is healthy (> 2)
  THEN → the core is hiding a 3-5 cycle L1D miss behind other work, which is exactly what
         out-of-order execution is for. High L1D traffic with high IPC is not a problem. Record and
         STOP unless STEP 4 finds false sharing (P4, R0)
  IF `Backend-Dominated CPU Stalls` fired AND `ipc` < 1
  THEN → the CONFIRMED case: data access is blocking issue. WHERE the misses terminate is still
         open, and STEP 4 decides which playbook owns the fix (P2, R0)
       → verify: `stall-backend-pkc` falls in ABSOLUTE pkc after the fix, not merely relative to
         the frontend
  IF `Frontend-Dominated CPU Stalls` fired
  THEN → the data path is not the bottleneck. Record as secondary and read
         high-l1-instruction-cache-misses.md and high-code-sparsity.md instead (P4, R0)
  IF NEITHER stall finding fired
  THEN → either the pipeline is in the dead zone `fe/be in (1/1.1, 1.1)`, which is NOT evidence of
         health since 600 pkc on both sides fires nothing, or the run is on generic `amd` where
         `stall-backend-pkc` does not exist and BOTH rules are structurally silent. Read the
         absolutes, or `ipc` alone on amd (P3, R0)

STEP 4 — FALSE SHARING, or a real footprint? The highest-leverage branch in this playbook.
  IF the total working set is SMALL and multiple threads write to nearby addresses
  THEN → FALSE SHARING. Each invalidation forces a fresh refill and this metric counts refills, so
         a single ping-ponged line inflates it without any footprint problem. Pad the structure to
         a cache line or give each thread its own accumulator (P1, R2)
       → verify: data-l1-mpki COLLAPSES after padding while the working set is unchanged, and
         throughput rises; if the metric barely moves, the sharing was not the cause
  IF `strex-spec-pki` is elevated (arm64 only)
  THEN → contended exclusive stores on shared lines -- the same root cause seen from the atomics
         side. Reduce contention or shard the counter (P1, R2)
       → verify: strex-spec-pki and data-l1-mpki fall together; hotline confirms the address is no
         longer contended
  IF `l2-mpki` is BELOW its threshold of 10.0
  THEN → LOCALITY, not capacity: the misses are absorbed at ~15-20 cycles. `--funnel` reports
         `boundary: l1`. Layout work is the lever and it is cheap -- but the end-to-end payoff is
         bounded by that hit cost, so measure throughput, not just the metric (P3, R2)
       → verify: `--funnel --data-l1 <v> --l2 <v> --l3 <v> --profile <p>` reports `boundary: l1`;
         after field reordering, data-l1-mpki falls and l2-mpki stays flat
  IF `High L2 Cache Misses` also fired but `l3-mpki` is low
  THEN → per-core CAPACITY. Tiling, not layout, and the finding to act on is that one. Go to
         `High L2 Cache Misses` (P2, R0)
  IF `High L3 Cache Misses` also fired
  THEN → FOOTPRINT reaching DRAM: hundreds of cycles plus shared bandwidth. Layout work alone will
         not help. Go to `High L3 Cache Misses` (P1, R0)

STEP 5 — Is the access pattern reducible at all?
  IF the pattern is streaming or one-pass with no reuse
  THEN → the fills are the COST OF THE WORK, not a defect. Non-temporal stores stop the scan
         evicting the hot set, but nothing makes a no-reuse pass hit cache (P3, R2)
       → verify: after non-temporal hints, data-l1-mpki for the OTHER phases falls even if the
         streaming phase is unchanged
  IF the pattern is pointer chasing or hash lookup
  THEN → prefetchers cannot predict it. Flatten into index-based layouts, or place explicit
         prefetches at hotline-identified sites (P2, R3)
       → verify: hotline shows the missing accesses moved off the hot list; data-l1-mpki falls AND
         stall-backend-pkc falls in absolute pkc
  IF the runtime is reference-heavy (Java objects, Python objects, Perl SVs)
  THEN → the object model produces this traffic structurally, so layout levers are largely
         unavailable and the axis is DATA REPRESENTATION: primitive arrays, packed buffers, or a
         native library (P3, R3)
       → verify: the elevated intervals do NOT align with GC (which would make it collector
         behaviour); after moving hot data into arrays, data-l1-mpki falls
  IF `data-tlb-mpki` or `data-tlb-tw-pki` is non-zero
  THEN → an independent translation cost on the same accesses, with a configuration-only fix that
         is cheaper than any code change. Do it first (P2, R4)
       → verify: `AnonHugePages` in `meminfo` rises and stall-backend-pkc falls while data-l1-mpki
         stays flat -- the signature of a translation-only win
  IF `numa_miss` or `other_node` in `numastat` is material
  THEN → remote-node service multiplies the cost of every fill without changing the rate, and
         numastat has NO analytical rules so nothing flags it (P2, R1)
       → verify: after `numactl` pinning or interleaving, other_node falls AND stall-backend-pkc
         falls; data-l1-mpki itself will not move

STEP 6 — What survives?
  VALID      : the reported value AS the series peak and AS a lower bound on true misses; the
              per-CPU split; `value = |score| × 20`; the funnel boundary; comparisons between
              `intel`, `icelake` and `spr`; `l3_of_l1` on amd/milan/genoa via umask containment;
              the stall split read as absolute pkc; and every non-PMU finding in the run
  CAUTION    : the value as a MISS count, since fills merge concurrent misses to one line; any
              per-access rate, since aperf does not collect the load/store count; `l3_of_l1` on
              non-AMD profiles; and any working-set claim, since aperf does not report L1D size
  CONFOUNDED : the value on a multiplexed run; the value on an idle-diluted run; any comparison
              against a run with a different thread count; and the value on a reference-heavy
              runtime, where the object model dominates the signal
  VOID       : any cross-vendor comparison; any score comparison with `High L2 Cache Misses` or
              `High L3 Cache Misses` (threshold 10.0, and `Bad` at L3, so equal scores mean
              different values twice over); and any claim that this value is the average

INSUFFICIENT DATA
  IF the run is at default `--interval 1 --period 10`
  THEN → about 10 PMU samples. "Sustained" is barely distinguishable from "transient", and no
         percentile is readable: p90 and above are the same single sample (P3, R0)
  IF `l2-mpki` is absent from the report
  THEN → STEP 4's discriminator cannot run, so it is unknown whether this is a cheap locality
         problem or a footprint one. This is the one input the playbook cannot work without
         (P3, R0)
  IF the run has no `--profile` and no hotline output
  THEN → the accesses cannot be attributed to code or to an address, so false sharing can be
         suspected from the per-CPU shape but not confirmed, and prefetch placement is impossible
         (P3, R0)
```

## Runtime-specific consequences

L1D traffic is dominated by **data representation**, which is a property of the runtime far more than of
the code — so the same source-level structure produces very different values across this table.

| Runtime | Why the traffic, and whether it is a defect | What to check, and the effective axis |
|---|---|---|
| **Java** | Objects are individually heap-allocated and reached through references, so a "small" collection is a pointer graph touching many more lines than its logical size. Header words and field padding waste line space, and a copying collector relocates live objects so locality is not stable. Usually **structural, not a defect** | `GC` data for whether elevated intervals align with collections; `jvmArguments` for collector and heap. Axis: **representation** — primitive arrays and flattened records over object graphs. `@Contended` for genuine false sharing |
| **Python** | Every element of a pure-Python container is a boxed object with a refcount that is *written* on access, so read-only traversal still dirties lines — and refcount churn on shared objects is a false-sharing generator under threads. A NumPy or torch stack is the opposite: contiguous and layout-tunable | Whether the hot loop is native-array work or object iteration. Axis: **move the data into arrays**. Layout levers only exist below the array boundary |
| **.NET** | The runtime where the L1D levers genuinely apply: `struct`, `Span<T>`, array-of-struct layouts and explicit field ordering are all expressible, so field reordering and AoS→SoA are real options rather than advice | Whether hot data uses value types rather than reference types; server-vs-workstation GC. Axis: **layout**, plus padding for false sharing |
| **Perl** | Every value is an SV from arenas with no contiguity guarantee, so traversal is pointer chasing by construction. Structural, not a finding | Whether hot data can move into a packed structure or an XS/C library. Otherwise the axis is capacity, not layout |

**The unknown-runtime case is the default** — aperf reports no language field, and the runtime is inferred
from `processes` names ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3). When it cannot be identified,
stop at STEP 4 and report the discriminator: whether L2 absorbs the misses, and whether the per-CPU shape
suggests false sharing, are both answerable from the PMU data alone and are the two conclusions that
actually decide what to do.

## Architecture-specific considerations

This finding fires on **all 8** PMU profiles — the registry `architectures` lists every one and
`architecture_note` is empty. Unlike its sibling `l2-mpki`, the encodings are stable within each vendor.

| Profile | Config entry and event | Semantics | Comparable with… |
|---|---|---|---|
| `grv`, `grv5` | `L1_Data` = `armv8_pmuv3_0/event=0x3/` | L1D refills | each other |
| `intel`, `icelake`, `spr` | `L1_Data` = `cpu/event=0x51,umask=0x1/` | L1D replacements | **all three** — the SPR refresh did not move this event |
| `amd`, `milan`, `genoa` | `L1_Data_Fills` = `cpu/event=0x44,umask=0xff/` | L1 data fills, all sources | each other |

So `cross_architecture_comparable('data-l1-mpki', 'intel', 'spr')` is **True**, where the same call for
`l2-mpki` is **False** — the two sibling metrics have different comparability tables and conflating them is
a real error. `test_aperf_memory_hierarchy.py` re-derives both from `src/pmu_configs/*.json`, so neither
can drift.

The AMD umask containment is the other architecture-specific fact with consequences: `0x44` umask `0xff`
here versus `0x44` umask `0x8` for `l3-mpki` makes `l3_of_l1` a genuine "share of L1D fills served from
DRAM" on AMD only. On Intel the valid funnel ratio is `l3_of_l2` instead, because `0x2e` umask `0x41`
counts instruction and prefetch misses that never appear as L1D replacements.

**No aperf gate protects any of this.** aperf has no architecture field and no rule compares
`Instance Type` ([../GATES.md](../GATES.md) §"The two gaps"): an Intel→Graviton comparison with matched
`CPUs` and `MemTotal` fires **no gate**, yet the event, the fill accounting, the L1D size and the line size
all changed. Line size matters directly for false sharing — the padding target is a hardware constant aperf
does not report.

## Verification

Re-record at the **same geometry, same counter mode, same instance type and the same thread count**, then
check in order. First, `data-l1-mpki` must fall — compare the sustained level, not the peak, because the
reported value is the maximum and a fix that only smooths one spike will look like a large win. Second,
`l2-mpki` must not rise: a layout change that spreads accesses over more lines can trade an L1D fill for an
L2 miss, which is a net loss. Third, `stall-backend-pkc` must fall in **absolute pkc**, not merely relative
to the frontend. Fourth — and this is the step most often skipped here — **throughput must actually
improve**. At a 3–5 cycle hit cost with out-of-order execution absorbing much of it, halving this metric
can produce no measurable end-to-end gain at all.

The false-sharing fix is the exception: if padding was the change, expect a large drop in `data-l1-mpki`, a
fall in `strex-spec-pki` on arm64, unchanged footprint, and a throughput gain that scales with thread
count. If the metric collapses but throughput is flat, the contended line was not on the critical path. If
`data-l1-mpki` falls and nothing else moves, STEP 4 already told you why: the misses were being absorbed by
L2.

## Do not

- **Do not treat the reported value as the run's average.** It is the series peak, and one load-phase or GC
  spike produces the largest number the run ever saw.
- **Do not read the metric as a miss count.** Every profile counts line **fills** or **replacements**, so
  concurrent misses to one line merge into a single event and the value is a **lower bound** on misses.
- **Do not compute a per-access miss rate.** The denominator is instructions, and aperf does not collect
  the load/store count, so a memory-light loop missing on nearly every access looks identical to a
  memory-heavy loop with a good hit rate.
- **Do not act on this finding before reading `l2-mpki`.** If L2 absorbs the misses the cost is ~15–20
  cycles and layout work is the right — and bounded — response; if it does not, the fix belongs to another
  playbook. This is the single most important gate here.
- **Do not skip the false-sharing check when the working set is small.** It is the one outcome in this
  playbook with a P1 priority and an R2 fix, and footprint reduction will not touch it.
- **Do not apply L2-level or L3-level fixes here.** Tiling and total footprint reduction address capacity;
  this level is about locality and traffic.
- **Do not carry the `l2-mpki` comparability table over.** `intel`/`spr` is **True** for this metric and
  **False** for that one, so the same reasoning gives opposite answers.
- **Do not read `l3_of_l1` as a valid fraction outside `amd`/`milan`/`genoa`**, where the umask containment
  licenses it. Elsewhere use `l3_of_l2` and the module's `l3_ratio_valid` flag.
- **Do not act on a GC, load-phase or warm-up spike**, and **do not act on the value when
  `mux_counter_schedule_rate` is below 100** — the peak is then an extrapolation.
- **Do not read the value as characteristic of the instance.** This template iterates every series
  including per-CPU (`processed_data_accessor.rs:104`), so a few threads fire it for the whole run.
- **Do not optimize data layout while the workload is frontend-bound**, and **do not read the small score
  as small impact** — `Concerning` (−1) caps the score near −5 even for severe values.
- **Do not treat a high value in a reference-heavy runtime as a defect.** Object graphs and refcounted
  boxes produce this traffic structurally; the axis is representation, not layout.

## References

- Rule definition: `src/analytics/rules/perf_stat.rs:92` — `metric: "data-l1-mpki"`,
  `comparator: Comparator::Greater`, `threshold: 20.0`, `score: Score::Concerning`. Single-run
  (`requires_comparison: false`), so readable when every cross-run comparison is void. Note
  `High L2 Cache Misses` (`:100`) and `High L3 Cache Misses` (`:108`) both use `10.0`, and the latter uses
  `Score::Bad`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs:98`–`:117` — the
  selection loop keeps the largest `abs(finding_score)`; with a non-zero threshold and a monotonic score
  that is the series **peak**. It iterates **every** series including per-CPU
  (`time_series_metric_values_iterator`, `processed_data_accessor.rs:104`), unlike the stat-based rules
  which read only `Aggregate` (`:432`).
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — `delta = value / threshold`,
  inverted only below 1.0, times `rule_score`. `Score::Concerning = −1` at `:147`–`:157`.
- Per-profile metric definition: `src/pmu_configs/*.json`, merged as overlays onto the generic config by
  `extend_from_default` (`src/data/perf_stat.rs:198`–`:203`), selected at `:750`–`:797`. The expression is
  `L1_Data / Instructions * 1000` on grv, grv5, intel, icelake, spr and
  `L1_Data_Fills / Instructions * 1000` on amd, milan, genoa. `L1_Data` resolves to `event=0x3` (arm64) and
  `event=0x51,umask=0x1` (**all three** Intel profiles — the SPR override does not touch it);
  `L1_Data_Fills` resolves to `event=0x44,umask=0xff`, a strict umask superset of the
  `event=0x44,umask=0x8` used by `l3-mpki` on the same profiles. `perf_stat` opts **out** of the forced
  first zero via `use_first_accumulative_value()` (`:1295`).
- Quantifier: [`../tools/aperf_memory_hierarchy.py`](../tools/aperf_memory_hierarchy.py) — `--funnel`
  localizes the boundary and reports `l2_of_l1`, `l3_of_l2` and `l3_of_l1` with the `l3_ratio_valid` flag
  (which describes `l3_of_l2`); `resolved_events` and `cross_architecture_comparable` establish the
  `intel`/`spr` True result that distinguishes this metric from `l2-mpki`; `--side` splits an
  instruction/data co-elevation; `--select` confirms the peak is reported.
  `test_aperf_memory_hierarchy.py` re-derives the expressions and encodings from `src/pmu_configs/`.
- Multiplexing: `src/data/perf_stat.rs:1093` scales by `time_enabled / time_running`, so a schedule rate of
  R% is an extrapolation factor of `100/R`. Grouped is the default (`src/data_collection.rs:379`) and
  duplicates events per metric group (`perf_stat.rs:217`–`:221`).
- Upstream guides: `DATA_FOOTPRINT_OPTIMIZATION` (the remediation attached to this metric — store related
  data together, access it sequentially, reuse before eviction) and `CPU_BACKEND_STALLS_INVESTIGATION`
  (which lists `data-l1-mpki`), in `src/report_frontend/src/definitions/optimization-guides.ts`.
- Related playbooks: `high-l2-cache-misses.md` (the discriminator, and the tier above) and
  `high-l3-cache-misses.md` (the cost decider — read all three via `--funnel`),
  `high-l1-instruction-cache-misses.md` (the instruction side of the same level),
  `backend-dominated-cpu-stalls.md` (the severity gate), `data-tlb-misses.md` and
  `data-tlb-table-walks.md` (the independent translation cost on the same accesses),
  `pmu-counter-collection-multiplexing.md` (the confidence gate),
  `../vmstat/increased-minor-page-faults.md`, `../kernel_config/huge-page-disabled.md`,
  `../cpu_utilization/underutilized-cpu.md`. Cross-cutting: [../GATES.md](../GATES.md),
  [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md), [../ARCHITECTURE.md](../ARCHITECTURE.md).
- [Graviton perfrunbook — drill down back-end stalls](https://aws.github.io/graviton/perfrunbook/debug_hw_perf.html#drill-down-back-end-stalls)
- [Arm Neoverse N3 — L1D cache MPKI metric](https://developer.arm.com/documentation/109530/0100/Metrics-by-metric-group-in-Neoverse-N3/L1D-Cache-Effectiveness-metrics-for-Neoverse-N3?lang=en#md553-l1d_cache_effectiveness_mg__l1d_cache_mpki_m_L1D_Cache_Effectiveness)
