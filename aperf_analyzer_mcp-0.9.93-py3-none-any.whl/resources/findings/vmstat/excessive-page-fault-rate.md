---
rule_name: Excessive Page Fault Rate
data_type: vmstat
data_key: pgfault
template: time_series_stat_threshold
condition: "p99(pgfault) > 100000.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "Very high page fault rate (>100k/s at P99) may indicate memory thrashing or an application allocating memory excessively."
source: src/analytics/rules/vmstat.rs:44
---

# Excessive Page Fault Rate

## What fired

The **p99** of `pgfault` exceeded **100,000**. `pgfault` is the **total** fault count — "Total page faults
including both minor faults (memory already in RAM) and major faults (requiring disk I/O)"
(`data-descriptions.ts`, `desired: "lower"`).

Base score `Concerning` (**−1**), the mildest negative score aperf defines. Single-run rule, no base run
needed.

On a default recording this finding reads as **"the worst single second of the run had more than 100,000
page faults"** — a much weaker claim than the rule name and message suggest. The section below is the
arithmetic that establishes it, and it is why the mild `Concerning` weight is appropriate.

## The processing defect — "p99" is the maximum, and the threshold is not per second

Two independent properties of the implementation change what the number means, and both contradict the
rule's own message (">100k/**s** at P99").

**1. `Stat::P99` is nearest-rank with a floor index, so on short runs it is the maximum.**
`Statistics::from_values` (`src/computations/mod.rs:54`) computes
`p99 = sorted_values[(0.99 * n as f64).floor() as usize]` — no interpolation, no rank correction:

| samples (n) | p99 index | max index | p99 == max? |
|---|---|---|---|
| 10 (default `--period 10 --interval 1`) | 9 | 9 | **yes** |
| 30 | 29 | 29 | **yes** |
| 100 | 99 | 99 | **yes** |
| 101 | 99 | 100 | no — 1 below the max |
| 300 | 297 | 299 | no — 2 below |
| 600 (`--period 600`) | 594 | 599 | no — 5 below |
| 1000 | 990 | 999 | no — 9 below |

**Below 101 samples "p99" *is* the maximum**, and the outlier rejection the statistic was chosen for does
not happen at all. Getting a p99 that discards anything needs `--period` well above 100 intervals — 600
seconds at the default interval discards the top 5 samples. **The default run is 10 samples**
(`src/record.rs:35`, `:45`), so the finding reports one interval.

**2. The value is a per-interval count, not a per-second rate.** `add_accumulative_data_point` returns
`data_value - prev_value` with **no division by elapsed time**. At the default `--interval 1` a per-interval
count and a per-second rate coincide, which is how the message gets away with "/s"; at any other interval
they diverge by exactly the interval factor:

| `--interval` | printed value that just fires | actual fault rate at that threshold |
|---|---|---|
| 0.5 | 100,001 | **200k/s** — half as sensitive as advertised |
| 1 (default) | 100,001 | 100k/s — the only setting where the message is right |
| 5 | 100,001 | **20k/s** — fires at a fifth of the advertised rate |
| 10 | 100,001 | **10k/s** |

A report taken with `-i 5` can therefore carry this finding at an actual 20k faults/s, which is
unremarkable on any instance. **Read `--interval` before quoting a rate from this finding.**

## Reasoning

**What 100,000 faults per second actually means.** `pgfault` is dominated by minor faults on virtually every
system — majors are typically a rounding error in the total. A minor fault costs roughly a microsecond of
kernel work: the trap, the page-table walk, the TLB refill, and for a fresh anonymous page, zeroing 4 KiB.
At 100,000 per second that is on the order of **0.1 seconds of CPU per second**, i.e. roughly one tenth of a
core, spread across whichever threads are faulting. On a 64-vCPU instance that is unremarkable. On a 2-vCPU
instance it is 5% of the machine. **The threshold is absolute and takes no account of instance size**, which
is the single biggest reason this finding needs interpretation rather than action.

**What the rate is a proxy for.** The message names two possibilities and they are very different:

1. **"An application allocating memory excessively."** Every first touch of newly allocated anonymous memory
   is a minor fault. A workload allocating and freeing aggressively — short-lived buffers, an allocator that
   returns memory to the kernel and re-faults it, per-request arenas — generates fault volume proportional to
   its allocation churn. **This is the common case**, it is CPU cost rather than latency, and it is usually
   fixable in the allocator configuration rather than the application.
2. **"Memory thrashing."** Pages being reclaimed and immediately re-faulted. This is the serious case, but
   `pgfault` is a poor detector for it because the metric is dominated by minor faults. **Thrashing shows up
   in `pgmajfault`, `workingset_refault_*`, and `pswpin`** — not here. If those are quiet, a high `pgfault`
   is allocation churn, not thrashing.

**The huge-page multiplier is the most useful lens on the absolute number.** A 2 MiB transparent huge page is
faulted in with **one** fault where base pages would take 512. So 100,000 faults/s means very different things
depending on THP:

- With THP working on anonymous memory, 100,000 faults/s could represent ~200 GiB/s of first-touch — which is
  implausible, so a high count with THP active means the faults are *not* large anonymous first-touches. They
  are file-backed mappings, COW resolutions, or small scattered allocations.
- Without THP, 100,000 faults/s is ~400 MiB/s of first-touch memory — entirely plausible for an
  allocation-heavy workload, and exactly what a THP regression looks like.

So `thp_fault_fallback` and `Huge Page Disabled` are the first things to reach for: **a workload that lost
THP can cross this threshold with no change in its own behaviour at all.**

**Why `Concerning` (−1) is right, and why the score is nearly useless.** The cost is bounded, kernel-side, and
proportional — there is no cliff. And because the score is `(value / 100000) × −1`, crossing the threshold
scores −1.00 and a five-fold overshoot scores −5.00. Combined with the fact that most negative aperf findings
start at −16 or worse, **this finding will sit at the very bottom of a score-ordered list even when the rate
is extreme.** Read the value, not the score.

## Reading the description

`time_series_stat_threshold` emits:

```
The {stat} in {run_name} is {value}.
```

For this rule:

```
The p99 in aperf_record is 342.15K.
```

Five things to know:

1. **The description contains neither the comparator nor the threshold.** You must know from the rule that
   the condition was `p99 > 100000`. The line reads as a bare fact.
2. **Values use K/M/G/T suffixes** and are **truncated**, not rounded, to two decimals. `342.15K` is
   anything from 342,150 to 342,159.
3. **The value is a per-interval delta**, so it is faults per second only at `--interval 1` — see the
   defect section. At `--interval 5` a value of 120K is 24k/s, well under the message's stated 100k/s, yet
   the finding fires.
4. **On runs of ≤100 samples the value is the maximum**, not a percentile.
5. `pgfault` is the **total**; the split into `pgminorfault` (derived) and `pgmajfault` is where the meaning
   lives.

Score math — `compute_finding_score(value, 100000, −1)`, general branch, `delta = value/100000`:

| p99 value | rate at `--interval 1` | score |
|---|---|---|
| 100,001 | 100k/s — just fires (`Greater`) | **−1.00** |
| 110,000 | 110k/s | −1.10 |
| 150,000 | 150k/s | −1.50 |
| 200,000 | 200k/s | −2.00 |
| 300,000 | 300k/s | −3.00 |
| 500,000 | 500k/s | −5.00 |
| 1,000,000 | 1M/s | −10.00 |
| 5,000,000 | 5M/s | −50.00 |

Linear and unbounded, but starting from −1.00 — so **a 5M/s fault rate scores −50, still below what a single
`Poor` finding contributes at −16 per unit ratio.** The score's only real use is comparing two runs of the
same rule against each other. Read the description value for magnitude. The `value == 0.0` doubling branch is
unreachable: a zero p99 cannot satisfy `> 100000`.

## Interpretation

**Split the total first — this determines everything:**

| Evidence | Reading |
|---|---|
| `pgmajfault` **near zero** relative to `pgfault` | **Almost always the case.** The rate is minor faults: allocation churn. Cost is `system` CPU, not latency. Not thrashing, whatever the message suggests |
| `pgmajfault` a **material fraction** | Rare and serious. The finding understates the problem — work `Major Page Faults Detected` and `Increased Major Page Faults` instead |
| `pswpin` non-zero | **Swapping.** Go to the major-fault playbooks; this finding is the wrong lens |
| `workingset_refault_file`/`_anon` rising | **Genuine thrash** — the message's first hypothesis confirmed. Otherwise, discount it |
| `MemAvailable` ample, no reclaim activity | **No pressure at all.** The rate is pure allocation behaviour |

**Then apply the huge-page lens:**

| Evidence | Reading |
|---|---|
| **`thp_fault_fallback` high or rising** | **THP allocation is failing to fragmentation.** Each 2 MiB region now costs up to 512 faults instead of 1 — a plausible sole cause for crossing the threshold. Read manually — no rule fires |
| `Huge Page Disabled` also fired | THP is not compiled in. Same multiplier, config-level. See that playbook |
| `thp_collapse_alloc` healthy, `thp_fault_fallback` low | THP is working, so these faults are not big anonymous first-touches — look at file mappings, COW, and small scattered allocations |
| `compact_stall` high | Fragmentation is forcing compaction, which is usually why THP started failing |

**Then judge the magnitude in context:**

| Observation | Reading |
|---|---|
| Value just over 100K on a large instance | **Noise.** The threshold is absolute; a 64-vCPU box handling 100k faults/s is spending ~0.15% of the machine |
| Value just over 100K on a 2-vCPU instance | ~5% of the machine in fault handling. Worth a look |
| Value in the millions | Real cost regardless of instance size. Something is churning hard |
| `system` CPU high | **The cost materialized.** This is where fault handling lands |
| `system` CPU unremarkable | **The rate is not costing anything measurable.** The most common outcome, and a complete answer |
| Run has ≤100 samples | The "p99" is the **maximum** — one bad interval, not a sustained rate |
| Faults confined to startup | Demand paging plus initial allocation. Benign and one-time |
| Faults sustained | Steady-state allocation churn. The case worth tuning |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Increased Minor Page Faults` | The rate also grew versus the base run. **Read them together** — the absolute rate is high *and* rising |
| `Major Page Faults Detected` | Majors exist. Check what fraction of `pgfault` they are; if material, that finding is the real one |
| `Increased Major Page Faults` | **Work that one first.** Storage-blocking faults beat fault volume every time |
| `Huge Page Disabled` | Can explain the whole finding via the 512× multiplier |
| `Reduced Memory Availability` | Pressure is real; re-examine whether some of the rate is thrash after all |
| `Underutilized CPU` | Minor faults consume CPU, they do not idle it. Two different causes |
| High `system` CPU with no other explanation | Fault handling and page zeroing are plausible contributors at these rates |
| No `pgfault` in the report | The rule cannot fire; absence proves nothing |

**Known false positives — most firings:**

- **A large instance where the absolute threshold is irrelevant.** The threshold does not scale with vCPU
  count or memory size.
- **`--interval` greater than 1**, making the value a multi-second sum compared against a per-second
  threshold. **The clearest artifact in this rule.**
- **A short run where p99 == max**, so one bad interval fires it.
- **Startup allocation and demand paging** producing one high interval.
- **Healthy allocation-heavy workloads.** High fault rates are normal for JVM-style heap churn, per-request
  arena allocators, and `fork`-heavy pipelines. Not a defect.
- **A lost-THP regression misread as an application problem** — the application did not change.
- **Co-tenant activity.** `vmstat` is system-wide.
- **The message's "thrashing" framing taken at face value** when `pgmajfault`, `pswpin`, and
  `workingset_refault_*` are all quiet.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`pgmajfault` vs `pgfault`** | `vmstat` | **Do this first.** If majors are negligible (usually), this is allocation churn, not thrashing. If material, the major-fault playbooks are the right ones |
| `pgminorfault` | `vmstat` | The minor component explicitly. Derived as `pgfault − pgmajfault` per interval |
| **`thp_fault_fallback`, `thp_collapse_alloc`, `compact_stall`** | `vmstat` | **The 512× multiplier check** — a THP regression alone can cross this threshold. **No rules fire** — read manually |
| `workingset_refault_file`, `workingset_refault_anon` | `vmstat` | Whether real thrash is occurring, as the message hypothesizes |
| `pswpin`, `pswpout` | `vmstat` | Swapping. If non-zero, work `Major Page Faults Detected` instead. Read manually |
| `pgsteal_*`, `pgscan_*`, `allocstall_*` | `vmstat` | Reclaim pressure — absent means no pressure, so the rate is pure allocation behaviour |
| `nr_anon_pages`, `nr_free_pages` | `vmstat` | Anonymous footprint and headroom. Gauges via `add_data_point` |
| The `pgfault` **series shape** | `vmstat` | Startup-only (benign) vs sustained (tune-worthy) vs one spike (the p99==max artifact) |
| `MemAvailable`, `MemFree`, `Cached` | `meminfo` | Whether there is any pressure at all. See `Reduced Memory Availability` |
| **`system`, `user`, `aggregate`, `idle`** | `cpu_utilization` | **Whether the fault cost materialized.** Unremarkable `system` CPU is a complete answer |
| vCPU count, memory size, instance type | `systeminfo` | **Required to judge an absolute threshold.** 100k/s means very different things at 2 vs 96 vCPUs |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | Whether THP exists at all. See `Huge Page Disabled` |
| THP mode (`/sys/kernel/mm/transparent_hugepage/enabled`), `vm.*` tunables | `sysctl` / out of band | Runtime THP setting and reclaim tuning. **No analytical rules — read manually** |
| **`--interval`, `--period`, sample count** | run metadata / `aperf_stats` | **Required.** Determines whether the value is a per-second rate and whether p99 is really the max. **No analytical rules — read manually** |
| Base page size (`getconf PAGESIZE`) | out of band | **Not collected.** A 64 KiB-page kernel takes 1/16 the faults for the same memory |
| Allocator, runtime, GC configuration | out of band | Allocation churn is usually an allocator-configuration question. aperf does not collect this |
| Top processes by CPU and memory | `processes` | **Who is faulting** — the workload or a co-tenant. **No analytical rules — read manually** |
| On-CPU profile | `perf_profile` | Fault-handling, page-zeroing, and allocator frames. Requires `--profile`. **No analytical rules** |

## Guidance

Ordered. **Steps 1–3 close most firings.**

1. **Check `--interval`.** The threshold is compared against a per-interval delta while the message claims
   ">100k/s". At `--interval 1` (default) they agree; at `--interval 5` the rule fires at an actual 20k/s.
   **Do not quote a per-second rate without doing this conversion.**

2. **Check the sample count.** With **≤100 samples** — including every default `--period 10` run — `p99` is
   the **maximum**, so the finding means "one bad interval", not "a sustained rate". Look at the series shape
   before treating it as steady state.

3. **Split the total.** Compare `pgmajfault` against `pgfault`. Majors are almost always negligible, which
   means **this is minor-fault volume: allocation churn, costing `system` CPU, not thrashing.** If majors are
   a material fraction, or `pswpin` is non-zero, stop here and work `Major Page Faults Detected` /
   `Increased Major Page Faults` instead — storage-blocking faults dominate fault volume in importance.

4. **Test the message's thrashing hypothesis explicitly, then discard it or keep it.** Real thrash means
   `workingset_refault_file`/`_anon` rising, `pgsteal_*`/`pgscan_*` active, and `MemAvailable` falling. All
   quiet ⇒ **not thrashing**, regardless of what the message says.

5. **Apply the huge-page lens — the highest-value check here.** A 2 MiB THP is one fault where base pages
   take 512. Read `thp_fault_fallback`, `thp_collapse_alloc`, and `compact_stall`, and check whether
   `Huge Page Disabled` fired. **A workload that lost THP can cross this threshold with no change in its own
   behaviour** — and that is a genuine, fixable regression.

6. **Put the number in instance context.** The threshold is absolute. 100k faults/s is ~0.1 core of kernel
   work: negligible on 64 vCPUs, ~5% of a 2-vCPU instance. Read the vCPU count from `systeminfo` before
   deciding this matters.

7. **Check whether the cost materialized.** Look at `system` CPU. **If it is unremarkable, the fault rate is
   not costing anything measurable** — that is a complete and legitimate resolution of this finding.

8. **Ignore the score.** It starts at −1.00 and reaches only −50 at 5M faults/s, so it will sit at the bottom
   of any score-ordered list. Use the description value.

9. **Attribute the faults.** `vmstat` is system-wide. Read `processes` to confirm the workload is responsible
   rather than a co-tenant, build job, or agent.

10. **If the rate is real, sustained, expensive, and THP is fine, tune the allocation churn:** look at whether
    the allocator returns memory to the kernel and re-faults it (arena/trim policy), whether short-lived
    buffers can be pooled or reused, whether per-request allocation can be amortized, and whether large
    allocations can be made THP-eligible (size and alignment). This is allocator and application work, not a
    kernel-tuning exercise.

11. **Check `Increased Minor Page Faults`.** If it also fired, the rate is both high and rising — the
    combination worth acting on.

## Priority and execution risk

**Priority: P4 — Informational** by default, which is where most firings belong: an absolute, instance-blind
threshold on a metric dominated by cheap minor faults, evaluated as a maximum over ten samples. It rises to
**P2 — Investigate** when `system` CPU is genuinely elevated on a small instance, or when the value is in the
millions. It is **P1 — Act now** in exactly two situations: `thp_fault_fallback` shows THP allocation
failing (the 512× multiplier is a real, fixable regression), or `pgmajfault`/`pswpin` reveal that part of the
volume is storage-blocking — in which case the *other* playbook is the one to work.

**Execution risk: R0 — Read-only** for the entire diagnosis: the interval, the sample count, the major/minor
split, the THP counters, and `system` CPU are all reads of the existing report. Acting spans four levels:
**R1** to change the THP mode (`/sys/kernel/mm/transparent_hugepage/enabled`, revertible instantly), **R2**
for an allocator or runtime setting that needs a restart (`MALLOC_TRIM_THRESHOLD_`, arena counts,
`-XX:+AlwaysPreTouch`), **R3** to restructure allocation in the application, and **R4** to resize the
instance. Note the asymmetry: the *diagnosis* is free, and the most common outcome is that no action is
warranted at all.

**What the score is worth: almost nothing as a severity.** `time_series_stat_threshold` amplifies, so the
score does carry the value — `value = |score| × 100000` inverts it exactly — but the base of −1 means a 5M/s
rate scores −50, below a *single* `Poor` finding's −16 per unit ratio. **The score ranks this finding last in
any score-ordered list regardless of how extreme the rate is.** Use it to recover the value, never to
prioritize.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `p99(pgfault) > 100000.0` in this run — one metric, one run, no baseline.

```
STEP 0 — What does the printed number actually mean?
  Sample count n follows from --period / --interval; p99 index is floor(0.99 x n).
  IF n <= 100 (every default --period 10 run)
  THEN → the value is the MAXIMUM, not a percentile: ONE interval (P4, R0)
       → read the pgfault series shape before treating it as a sustained rate
  IF --interval is not 1
  THEN → the value is a per-INTERVAL count while the message says ">100k/s".
         Divide by the interval to recover the rate (P4, R0)
       → at -i 5 a printed 120K is 24k/s, BELOW the message's own threshold
  ELSE the printed value is faults per second over the worst interval.

STEP 1 — Split the total. Is any of it major?
  IF pgmajfault is a material fraction of pgfault (rule of thumb: > 1%)
  THEN → fault volume is not the subject; storage-blocking stalls are (P1, R0)
       → major-page-faults-detected.md, see that playbook
  IF pswpin is non-zero
  THEN → swapping. This finding is the wrong lens entirely (P1, R0)
       → increased-major-page-faults.md, see that playbook
  IF pgmajfault is negligible and pswpin is zero
  THEN → the volume is MINOR faults: allocation churn, costing system CPU and
         not latency. This is the usual case (P4, R0)
       → continue to STEP 2

STEP 2 — Test the message's thrashing hypothesis, then keep or discard it.
  IF workingset_refault_file or workingset_refault_anon is rising
  AND pgsteal_* / pgscan_* are active AND MemAvailable is falling
  THEN → GENUINE thrash — the message's first hypothesis confirmed. Reduce the
         footprint or size up; the headroom finding is the explanation (P1, R4)
       → ../meminfo/reduced-memory-availability.md carries the attribution
       → verify: on the resized or reduced run, refaults and pgsteal_* fall and
         p99(pgfault) drops with them
  IF all of those are quiet
  THEN → NOT thrashing, whatever the message says. Allocation churn (P3, R0)
       → continue to STEP 3

STEP 3 — Apply the huge-page multiplier. Highest-value check in this tree.
  One 2 MiB THP fault covers 512 base pages, so losing THP multiplies the count
  for identical memory with no application change.
  IF thp_fault_fallback is high or rising, with compact_stall elevated
  THEN → THP allocation is failing to fragmentation. A real, fixable regression
         and a plausible SOLE cause for crossing the threshold (P1, R1)
       → set /sys/kernel/mm/transparent_hugepage/enabled to always for the
         anonymous path, or reduce fragmentation; instantly revertible
       → verify: thp_fault_fallback falls, thp_collapse_alloc rises, and
         p99(pgfault) drops by close to the same factor
  IF `Huge Page Disabled` also fired
  THEN → THP is not compiled in: the multiplier is structural, not tunable
         (P2, R0)
       → ../kernel_config/huge-page-disabled.md, see that playbook
  IF thp_collapse_alloc is healthy and thp_fault_fallback is low
  THEN → THP works, so these are not large anonymous first-touches. Look at file
         mappings, COW after fork, and small scattered allocations (P3, R0)
  ELSE continue to STEP 4.

STEP 4 — MANDATORY manual check: vCPU count. Did the cost materialize?
  100k faults/s is ~0.1 core of kernel work. The threshold is ABSOLUTE and takes
  no account of instance size.
  IF systeminfo CPUs >= 32 AND cpu_utilization system is unremarkable
  THEN → ~0.15% of the machine. The rate is not costing anything measurable and
         this is a COMPLETE resolution (P4, R0)
  IF systeminfo CPUs <= 4 AND system CPU is elevated
  THEN → fault handling is a material share of a small machine (P2, R2)
       → pool short-lived buffers, raise the allocator trim threshold, amortize
         per-request allocation; restart-only and revertible
       → verify: system CPU falls and p99(pgfault) drops at unchanged throughput
  IF system CPU is elevated with no other explanation in the report
  THEN → fault handling and page zeroing are plausible contributors (P2, R0)
       → confirm in perf_profile: clear_page / handle_mm_fault frames. Requires
         --profile, which the default run does not enable
  ELSE continue to STEP 5.

STEP 5 — Attribute the faults, then decide whether to tune.
  IF `processes` shows the workload is not the dominant consumer
  THEN → a co-tenant, build job, log shipper, or agent. vmstat is system-wide
         (P4, R0)
  IF the pgfault series is confined to the first intervals
  THEN → startup demand paging plus initial allocation. Benign and one-time
         (P4, R0)
  IF faults are SUSTAINED, system CPU is real, THP is healthy and majors are
     negligible
  THEN → steady-state allocation churn is the thing to tune, in the allocator
         first and the application second (P3, R3)
       → make large allocations THP-eligible by size and alignment; stop the
         allocator returning and re-faulting memory; reuse buffers
       → verify: p99(pgfault) and system CPU both fall at unchanged throughput.
         If throughput falls too, the churn was doing useful work
  ELSE → the rate is real but unexplained and uncosted. Record the value and the
         interval, and move on (P4, R0)

STEP 6 — What survives?
  VALID  : every other finding in the report. This rule reads one metric in one
           run and contaminates nothing
  VALID  : the value AS the worst interval's fault count, recoverable exactly as
           |score| x 100000
  CAUTION: the phrase "p99" for any run under 101 samples, and the phrase "/s"
           for any run not at --interval 1. Both are the defect section's subject
  CAUTION: comparing this value against another run's, or another instance's,
           without matching --interval and base page size
  VOID   : "memory thrashing", asserted from this finding alone. pgfault is
           dominated by minor faults; thrash lives in pgmajfault, pswpin and
           workingset_refault_*
  VOID   : the score as a severity ranking. It starts at -1.00 and reaches only
           -50 at 5M faults/s, below every Poor finding in the report

INSUFFICIENT DATA
  IF the run has fewer than ~5 usable samples
  THEN → "p99" rests on four numbers and the first is forced to 0. No
         distributional claim is available at all (P4, R1)
       → re-record with a longer --period; 600 intervals is the first geometry
         where p99 discards anything
       → verify: on the longer run either the p99 falls well below the maximum
         (the finding was one spike) or both stay high (the rate is sustained)
  IF the report has no pgfault metric (vmstat absent or /proc/vmstat unreadable)
  THEN → the rule COULD NOT FIRE. Silence is not evidence of a low fault rate
         (P4, R0)
```

## Runtime-specific consequences

Every first touch of newly allocated anonymous memory is a minor fault, so **the runtime's allocator and GC
determine this metric far more than application code does.** A managed runtime that commits and re-touches
memory generates fault volume no amount of application tuning will remove; one that pre-touches or uses huge
pages generates almost none. Runtime is not reported by aperf — infer it from `processes`
([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3) and treat the inference as a hint.

| Runtime | Why it drives `pgfault` | What to check, and the lever |
|---|---|---|
| **Java** | A compacting collector re-touches heap pages after every move, and a growing heap faults in each new region on first use. Region-based collectors (G1, ZGC) fault in regions as they are committed | `-XX:+AlwaysPreTouch` moves the whole heap's faults into startup and out of steady state; `-XX:+UseTransparentHugePages` makes the heap `madvise(MADV_HUGEPAGE)`-eligible for the 512× reduction; `-Xms == -Xmx` stops repeated commit/decommit cycles (P3, R2) |
| **.NET** | Server GC creates one heap per core, so arena count scales with vCPUs; gen0 budget determines how often fresh pages are touched | `DOTNET_GCgen0size` to enlarge gen0 and reduce churn, `DOTNET_GCLargePages` where hugetlb is configured, `DOTNET_gcServer` to control heap count (P3, R2) |
| **Python** | pymalloc requests arenas with `mmap` and **returns empty arenas to the kernel**, so a churning workload re-faults the same address space repeatedly. The GIL forces process-based scaling, and each `fork` adds COW resolution | `PYTHONMALLOC=malloc` to hand arena policy to glibc, then `MALLOC_TRIM_THRESHOLD_`/`M_ARENA_MAX`; reduce worker recycling frequency (P3, R2) |
| **Perl** | Long-lived interpreters retain their arenas, so steady-state fault volume is genuinely low. Preforking servers are the exception: COW resolution after each `fork` is minor-fault work proportional to worker churn | Raise the requests-per-worker limit so workers are recycled less often; `perl -V` build options matter more than runtime flags (P4, R2) |

**When the runtime cannot be established, do not guess.** The runtime-agnostic reading is the one in STEP 5:
sustained fault volume with real `system` CPU cost is allocator churn, and the allocator is where to look
first regardless of language.

## Architecture-specific considerations

**The base page size is the dominant architecture variable, and aperf does not collect it.** A fault brings in
one page, so the same bytes of first-touch memory cost a number of faults inversely proportional to page
size. An absolute threshold of 100,000 therefore means **16× more memory touched on a 64 KiB-page kernel than
on a 4 KiB one.** aarch64 kernels can be built with 4, 16, or 64 KiB base pages: Amazon Linux and Ubuntu
arm64 ship 4 KiB, RHEL-family aarch64 ships 64 KiB. x86_64 is always 4 KiB. Capture `getconf PAGESIZE` out
of band; confirm the architecture from `pmu_config.json` ([../ARCHITECTURE.md](../ARCHITECTURE.md) §1).

The PMD-sized huge page follows the base page (512 × base), so the multiplier in STEP 3 is 2 MiB on a
4 KiB-page kernel and 512 MiB on a 64 KiB-page one — the same 512× ratio, but a very different allocation
that fragmentation defeats far sooner.

| Observed | Reading | Action |
|---|---|---|
| Value just over 100K, x86_64 (4 KiB pages) | The threshold as designed: ~400 MiB/s of first-touch without THP | Judge against vCPU count; usually P4, R0 |
| Value just over 100K, aarch64 with **64 KiB** pages | ~6.4 GiB/s of first-touch — the same finding describes a **16× heavier** workload | Treat as materially more significant than the x86 reading (P2, R0) |
| Value elevated **after an Intel→Graviton migration** | The highest-value case, and **no aperf gate fires on it** ([../GATES.md](../GATES.md)). Page size, THP size, and the rebuilt allocator all changed at once | Capture the page size in both runs before attributing anything to the code (P2, R0) |
| Value elevated, `Old-Style Atomic Instructions` or `Reduced Instructions per Cycle` also fired | A generic or emulated arm64 build. Allocator behaviour is often part of the same mismatch | See [../ARCHITECTURE.md](../ARCHITECTURE.md) §5 (P1, R3) |

**Cross-architecture comparison of this finding is unsound twice over**: the fault count scales with page
size, and the THP fallback behaviour that STEP 3 keys on differs in allocation size. Two runs can show a 16×
difference in `pgfault` while touching identical memory. There is no aperf field that catches it.

## Verification

**Predict before you act.** If the cause is a lost THP, predict that `thp_fault_fallback` is non-zero *now*
and that setting THP to `always` drops `p99(pgfault)` by close to 512× on the anonymous share — a fall of a
few percent means the faults were never large anonymous first-touches and STEP 3 mis-routed. If the cause is
allocator churn, predict that both `p99(pgfault)` **and** `system` CPU fall together at unchanged throughput;
a fault-rate drop with no `system` CPU change confirms the rate was never costing anything, which is the
same conclusion STEP 4 reaches for free. If the finding **persists unchanged** after a genuine allocator or
THP change, re-check `--interval` and the sample count first: on a 10-sample run the metric is one interval,
so it can move by a factor of two between identical runs. And re-record at `--period 600` before treating any
"p99" claim as distributional — that is the only geometry in which the statistic is one.

## Do not

- **Do not quote the value as a per-second rate without checking `--interval`.** The threshold is per
  interval; the message's ">100k/s" holds only at `--interval 1`.
- **Do not treat the value as a percentile on a short run.** With ≤100 samples, `p99` is the **maximum** —
  `sorted_values[floor(0.99 × n)]` with no interpolation.
- **Do not accept the "memory thrashing" framing without evidence.** `pgfault` is dominated by minor faults;
  thrash lives in `pgmajfault`, `pswpin`, and `workingset_refault_*`.
- **Do not read the score as severity.** It starts at −1.00 and reaches −50 at 5M/s, below most single
  findings.
- **Do not expect the description to state the condition.** `time_series_stat_threshold` omits the comparator
  and threshold.
- **Do not judge an absolute threshold without the instance size.** 100k faults/s is trivial on 64 vCPUs and
  material on 2.
- **Do not compare this value across architectures or page sizes.** A 64 KiB-page kernel takes 1/16 the
  faults for identical memory, and aperf collects no page size.
- **Do not act if `system` CPU is unremarkable.** The cost did not materialize.
- **Do not overlook huge pages.** Losing THP multiplies fault counts by up to 512 with no application change.
- **Do not work this finding ahead of the major-fault findings.** Storage-blocking faults matter more than
  fault volume.
- **Do not treat a high fault rate as inherently pathological.** JVM heap churn, arena allocators, and
  `fork`-heavy pipelines are legitimately fault-heavy.
- **Do not blame the workload without checking `processes`.** `vmstat` is system-wide.
- **Do not conclude "no excessive fault rate" from the absence of this finding.** One quiet interval in ten
  is enough to keep the maximum under the threshold.

## References

- Rule: `src/analytics/rules/vmstat.rs:44` — `time_series_stat_threshold!` with `metric: "pgfault"`,
  `stat: Stat::P99`, `comparator: Comparator::Greater`, `threshold: 100000.0`, `Score::Concerning`.
- Rule template: `src/analytics/rule_templates/time_series_stat_threshold_rule.rs` — description is
  `format!("The {} in {} is {}.", stat, run_name, formatted_number_string(metric_stat))`, with **no**
  comparator or threshold; runs independently for every run, and `continue`s when the metric is absent.
- **Percentile computation:** `Statistics::from_values`, `src/computations/mod.rs:27`–`:67` —
  `p99 = sorted_values[(0.99 * n as f64).floor() as usize]`, no interpolation, so **p99 == max for n ≤ 100**;
  `std` uses the population divisor; `n == 0` returns `Statistics::default()`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Concerning = −1`,
  `src/analytics/mod.rs:147`. Threshold is non-zero, so the general branch applies and the `value == 0.0`
  doubling at `:180` is unreachable.
- Formatting: `formatted_number_string`, `src/computations/mod.rs:176` — K/M/G/T suffixes, values
  **truncated** to 2 decimals.
- Delta processing: `src/data/vmstat.rs` — `nr_*` via `add_data_point` (gauges), all others via
  `add_accumulative_data_point`, which returns `data_value - prev_value` with **no division by elapsed
  time**; first sample forced to 0 (`ignore_first_accumulative_value: true`,
  `time_series_data_processor.rs:73`), decreases return `None` at `:214` and are dropped.
- Aggregation: `time_series_data_processor_with_custom_aggregate!`; one `values` series per metric, so no
  auto-generated `average` series and no fractional values.
- Default sampling: `--interval 1`, `--period 10` (`src/record.rs:35`, `:45`; `interval >= period` is a hard
  error) — about 10 samples, so p99 is the maximum.
- Metric semantics: `pgfault` ("Total page faults including both minor faults … and major faults …",
  `unit: "Count"`), `pgminorfault`, `pgmajfault`, `thp_fault_fallback`, `thp_collapse_alloc`, `compact_stall`,
  `workingset_refault_*` in `src/report_frontend/src/definitions/data-descriptions.ts` (`vmstat` block,
  `defaultUnit: "Pages"`). **No `vmstat` metric carries an `optimization` guide**, so aperf offers no
  upstream remediation text for this finding.
- Related playbooks: `major-page-faults-detected.md`, `increased-major-page-faults.md`,
  `increased-minor-page-faults.md`, `../kernel_config/huge-page-disabled.md`,
  `../meminfo/reduced-memory-availability.md`, `../meminfo/inconsistent-physical-memory.md`,
  `../cpu_utilization/underutilized-cpu.md`.
- [Linux memory concepts — page faults](https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html#page-faults)
- [proc_vmstat(5)](https://www.man7.org/linux/man-pages/man5/proc_vmstat.5.html)
- [Transparent Hugepage Support](https://www.kernel.org/doc/html/latest/admin-guide/mm/transhuge.html)
- [arm64 memory layout and page sizes](https://www.kernel.org/doc/html/latest/arch/arm64/memory.html)
