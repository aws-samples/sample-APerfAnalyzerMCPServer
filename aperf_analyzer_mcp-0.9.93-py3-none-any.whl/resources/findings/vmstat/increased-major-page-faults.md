---
rule_name: Increased Major Page Faults
data_type: vmstat
data_key: pgmajfault
template: time_series_stat_run_comparison
condition: "delta_avg(pgmajfault) >= 0.2"
base_score: Poor
score_sign: negative
requires_comparison: true
aperf_message: "A significant increase in major page faults indicates growing disk-backed paging activity, which degrades performance."
source: src/analytics/rules/vmstat.rs:34
---

# Increased Major Page Faults

## What fired

The **average** of `pgmajfault` in this run is **at least 20% higher** than in the **base run**.

`abs: false` — **directional**. A decrease never fires it, however large. Comparator is `GreaterEqual`, so
exactly 20% fires.

Base score `Poor` (**−16**). **Comparison-only rule** — it cannot fire on a single-run report and never
fires on the base run.

**This is the most actionable finding in the `vmstat` family.** Where `Major Page Faults Detected` says
"faults exist" (at a threshold of *any*, so it fires almost everywhere) and
`Increased Minor Page Faults` says "cheap faults moved", this one says **the expensive, storage-blocking
faults got measurably worse than the baseline** — a regression in the one page-fault metric that costs
milliseconds rather than microseconds.

If both this and `Major Page Faults Detected` fired, **this is the one to work.** It has a baseline, which
means it can distinguish "this workload always does this" from "this got worse".

## The processing caveat — the zero base scores the worst regression the lowest

`time_series_stat_run_comparison` substitutes ratio `1.0` when the base stat is 0, with the comment "treat
current stat as 100% larger". For most metrics that is an unremarkable guard. Here it inverts the severity
ordering of the two most important cases:

| base run | this run | ratio used | score | what actually happened |
|---|---|---|---|---|
| 0 faults/interval | 5 faults/interval | 1.0 (capped) | **−80.00** | a clean baseline **started** faulting — categorical |
| 0 faults/interval | 5000 faults/interval | 1.0 (capped) | **−80.00** | identical score, a thousand times the stalls |
| 100 faults/interval | 300 faults/interval | 2.0 | **−160.00** | a 3× rise on an already-faulting workload |

So **"0 → anything" always scores −80.00**, regardless of magnitude, and any workload that merely tripled
from a non-zero base outranks it. The categorical regression — the one where storage-blocking stalls appeared
where there were none — is scored **half** as severe as a proportional worsening of a pre-existing problem.

Two rules follow. **Read the base value in the description before reading the score.** And when the base is
0, the score carries **no magnitude information at all**: go to the raw `pgmajfault` series in this run to
find out whether five faults appeared or five thousand.

The complementary trap is a *near*-zero base: a base mean of 0.1 faults per interval against a current mean
of 3 is a ratio of 29 and a score of −2320, from three faults per second. **Ratios on tiny bases are
arithmetic, not evidence.** Read both absolute values.

## Reasoning

`pgmajfault` is "Page faults that require loading data from storage devices indicating memory pressure and
I/O activity." (`data-descriptions.ts`, `desired: "lower"`.)

**Why a 20% increase in major faults is worth `Poor` (−16) when a 20% increase in minor faults is only
`Concerning` (−1).** The two differ by roughly three orders of magnitude in cost per event. A minor fault is
resolved from memory in about a microsecond. A major fault **blocks the faulting thread on storage** —
hundreds of microseconds to low milliseconds on EBS, worse on a cold or throttled volume — and the stall is
synchronous and unavoidable: it happens inside an ordinary memory access with no I/O call in the source to
attribute it to. A 20% increase in a metric that costs milliseconds per event is a latency regression; a 20%
increase in one that costs microseconds is a CPU-accounting curiosity. The 16× score gap between the two
rules is the right ratio.

**Why the comparison form matters more than the threshold form.** `Major Page Faults Detected` fires on a
single fault anywhere in the run, so on real systems it fires constantly — startup demand paging alone
triggers it. That makes its *presence* nearly uninformative. This rule has a **baseline**, so it separates
the workload's normal fault behaviour from a change in it. A workload that always takes 500 major faults per
second is flagged by the threshold rule every time and by this rule never; a workload that went from 10 to
40 is flagged by this rule, which is the signal you actually want.

**What causes major faults to increase between two runs, ordered by how often it is the real answer:**

1. **The working set grew past the page cache.** The most common cause. More resident data, a larger index,
   a bigger model, more concurrent connections — anything that increases memory demand squeezes the cache
   until file-backed pages start being evicted and re-read. Fingerprint: `workingset_refault_file` up,
   `pgsteal_*`/`pgscan_*` up, `MemAvailable` down. Often paired with `Reduced Memory Availability`.
2. **Swapping started, or got worse.** Anonymous memory being written to and read back from swap.
   Fingerprint: **`pswpin` non-zero or increased** — the single decisive check. **The most damaging case**,
   because the pages being fetched are the application's live heap, so the stalls land directly on the hot
   path rather than on file reads that might have been prefetched.
3. **Less memory available for the same work.** Not the workload growing but something else taking memory —
   a co-tenant, a sidecar, a monitoring agent, a container limit change, or a leak elsewhere. Same
   fingerprint as (1) but `nr_anon_pages` for the workload itself is flat.
4. **The instance is smaller.** If the runs are on different instance sizes, the fault difference is
   structural. `Inconsistent Physical Memory` should also have fired; **fix that first** — this finding is
   then a downstream symptom of an invalid comparison, not a regression.
5. **Storage got slower, changing behaviour.** A throttled or cold EBS volume does not itself cause more
   faults, but it lengthens each one, which changes reclaim timing and can cascade. Check `diskstats`
   latency in both runs.
6. **A code or configuration change altered the I/O path.** Switching from `read()` to `mmap`, enabling a
   memory-mapped cache, changing readahead, or adding a memory-mapped index converts explicit I/O into
   faults. **The fault increase is then real but the total I/O may be unchanged** — a re-attribution, not a
   regression. Fingerprint: faults up, `diskstats` read volume roughly flat.
7. **The runs did different amounts of work.** More work, more data touched, more faults. Check whether the
   comparison-validity findings fired.
8. **Different phase mix or run length.** `Stat::Average` is a mean of per-interval deltas — a rate — but a
   long idle startup dilutes it and a truncated teardown concentrates it.

**Why the rule is directional.** `abs: false` means a *decrease* is silent. That is intentional — fewer major
faults is better — but it means a large improvement is invisible to the findings list. If you are evaluating
a memory optimization, read `pgmajfault` directly in both runs rather than waiting for a finding.

**Processing is clean here.** `vmstat` sends `pgmajfault` through `add_accumulative_data_point`, correct for
a monotonic counter, with the first sample forced to 0 and decreases skipped. There is **no auto-generated
`average` series** (`vmstat` uses the custom-aggregate processor and each metric has a single `values`
series), so values are real integer page counts, never fractional and never averaged across devices.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run_name} ({value}) is {delta_ratio_string} {base_run_name} ({base_value}).
```

Both placeholders are **run names**, not metric names. Example:

```
The average in run_b (412.00) is 84.30% greater than run_a (223.50).
```

Four things to know:

1. **Values use K/M/G/T suffixes** (`formatted_number_string`) and are **truncated**, not rounded, to two
   decimals.
2. **The values are per-interval means, not per-second rates**, unless `--interval 1` (the default). A
   report taken with `--interval 5` shows five times the count for identical behaviour — so compare the
   interval settings of the two runs before trusting the ratio at all. **Two runs recorded at different
   intervals will produce a spurious finding here.**
3. **The ratio and the score agree in direction.** With `abs: false`, the comparison, the score, and the
   description all use the same signed ratio, and the rule only fires when it is positive — so the text
   always says `greater than`.
4. **If the base-run average is 0, the ratio is substituted with `1.0`**, regardless of how large the current
   value is — see the caveat section for why that inverts the severity ordering.
   `100.00% greater than run_a (0)` means **the base run took no major faults at all**: a categorical
   difference reported with the *smallest possible* firing ratio.

Score math — `compute_finding_score(ratio, 0.2, −16)`, general branch, `delta = ratio/0.2`:

| ratio | meaning | score |
|---|---|---|
| 0.20 | 20% more — fires (`GreaterEqual`) | **−16.00** |
| 0.25 | 25% | −20.00 |
| 0.30 | 30% | −24.00 |
| 0.50 | 50% | −40.00 |
| 1.00 | 2×, **or base run = 0** | −80.00 |
| 2.00 | 3× | −160.00 |
| 5.00 | 6× | −400.00 |
| 10.00 | 11× | −800.00 |
| 100.00 | 101× | −8000.00 |

**The score is unbounded and linear in the ratio, and it is worth ranking on** — 16× the minor-fault rule at
every ratio, which correctly reflects the cost difference. Recover the ratio exactly with
`ratio = |score| × 0.2 / 16`. The one exception is the zero base, where the score is pinned at −80.00 and
tells you nothing about magnitude.

## Interpretation

**Run the two decisive checks first:**

| Evidence | Reading |
|---|---|
| **`pswpin` non-zero or increased** | **Swapping.** The application's live anonymous memory is being read back from disk. The most damaging cause, the clearest remediation, and the first thing to fix. Read manually — **no rule fires on `pswpin`** |
| `pswpin` zero in both runs | Not swapping. The faults are file-backed: page cache, executables, or `mmap`. (If `SwapTotal` is 0, swapping is excluded outright) |
| **`MemAvailable` down** in this run | Memory pressure increased; the cache is being squeezed. See `Reduced Memory Availability` — the strongest corroboration this finding has |
| `MemAvailable` unchanged | **Not a pressure problem.** Look at cause 6 (an I/O-path change re-attributing reads to faults) or cause 7 (different work) |

**Then read the shape and the base value:**

| Observation | Reading |
|---|---|
| Base value **0** | **A clean baseline started faulting.** Categorical regression, reported at the minimum ratio. Do not let the modest score hide it |
| Faults confined to **startup** in both runs but larger here | Demand paging of a bigger binary or more libraries. Usually benign |
| Faults **sustained** in this run, absent in base | The real thing: something is now re-reading from storage continuously |
| Faults **increasing** across this run | A growing working set or a leak progressively squeezing the cache |
| Ratio just at 20% | The tripwire. Check `--interval` in both runs, sample count, and phase mix first |
| Ratio 10× or more | Structural: a different instance size, swap starting, or an `mmap`-based I/O path introduced |

| Evidence | Reading |
|---|---|
| `workingset_refault_file` up in step | **Page-cache thrash**: pages evicted then immediately re-read. Direct evidence for cause 1 |
| `workingset_refault_anon` up | Anonymous refaulting — corroborates swapping |
| `pgsteal_direct` / `pgscan_direct` up | **Synchronous reclaim**: allocations are stalling to free memory. Worse than background kswapd reclaim |
| `allocstall_*` up | Pressure severe enough to block allocators outright |
| `oom_kill` non-zero | Past degradation — processes were killed. Read manually |
| `nr_anon_pages` up | The workload itself grew (cause 1) |
| `nr_anon_pages` flat, faults up | **Something else took the memory** (cause 3) — a co-tenant, agent, or sidecar |
| `diskstats` read volume up in step | The faults are real extra I/O |
| `diskstats` read volume **flat** while faults rose | **Re-attribution, not regression**: the same reads now arrive as faults instead of `read()` calls. Cause 6 |
| `diskstats` latency up | Each fault costs more, independently of how many there are — a compounding factor |
| `iowait` up | Confirms threads are blocked on storage |
| `thp_fault_fallback` up | Fragmentation; related memory health but **not** a cause of major faults |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Major Page Faults Detected` | Expected — this run has faults. **This finding is the one with a baseline, so work this one** |
| `Reduced Memory Availability` | **The strongest corroboration.** Less memory available plus more major faults is the textbook pressure regression. Read them as one finding |
| `Inconsistent Physical Memory` | **The runs have different RAM.** Fix that first — this finding is then a structural artifact, not a regression |
| `Inconsistent Number of CPUs` / `Kernel Version Mismatch` | The runs are not comparable in other ways too. Fix those first |
| `Increased Minor Page Faults` | The whole fault load grew. If minors grew much more than majors, the change is mostly allocation behaviour with a capacity side-effect |
| `Excessive Page Fault Rate` | The absolute total rate is very high as well |
| `Underutilized CPU` | Consistent with threads blocked on fault I/O rather than running — corroborating, not competing |
| `Inconsistent Inbound/Outbound Network Traffic` | The runs may have done different work; check the comparison-validity gates |
| High `system` CPU | Reclaim and fault handling are kernel work |

**Known false positives:**

- **Different `--interval` between the runs.** The values are per-interval deltas, so mismatched intervals
  produce a large spurious ratio. **Check this before anything else if the ratio is suspiciously round.**
- **Different instance sizes** — `Inconsistent Physical Memory` should also have fired.
- **An I/O-path change** (`read()` → `mmap`) re-attributing existing reads to faults with no extra I/O.
- **Different run lengths or phase mix** diluting or concentrating the mean.
- **Short runs.** The first interval is 0 and few samples make a noisy mean.
- **A near-zero base** where a handful of faults becomes a large ratio. Read the absolute values.
- **Co-tenant activity.** `vmstat` is system-wide.
- **The runs did different work** — check the comparison-validity findings.
- **The base run is the wrong baseline.** aperf picks it by ordering, not by intent.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`pswpin`, `pswpout` in both runs** | `vmstat` | **Do this first.** Swapping is the most damaging cause and has a distinct remediation. **No rules fire** — read manually |
| **`MemAvailable` in both runs** | `meminfo` | **The pressure question.** Unchanged availability means this is not a capacity regression. See `Reduced Memory Availability` |
| `pgmajfault` **series shape** in both runs | `vmstat` | Startup-only vs sustained vs increasing. A mean hides all three — and it is the **only** magnitude source when the base is 0 |
| `workingset_refault_file`, `workingset_refault_anon` | `vmstat` | **Direct thrash evidence**, and the file/anon split separates cache pressure from swapping |
| `pgsteal_direct`, `pgscan_direct`, `pgsteal_kswapd`, `pgscan_kswapd` | `vmstat` | Whether reclaim is synchronous (worse) or background |
| `allocstall_*`, `pgscan_direct_throttle` | `vmstat` | Allocation stalls under severe pressure. Read manually |
| `oom_kill` | `vmstat` | Whether pressure already killed processes |
| `nr_free_pages`, `nr_anon_pages`, `nr_inactive_file` | `vmstat` | Headroom, and whether the workload itself grew. Gauges via `add_data_point` |
| `pgfault`, `pgminorfault` | `vmstat` | The fault mix. See `Increased Minor Page Faults`, `Excessive Page Fault Rate` |
| `MemTotal` | `meminfo` | **Whether the runs are comparable at all.** See `Inconsistent Physical Memory` |
| `SwapTotal`, `SwapFree`, `Cached`, `Buffers` | `meminfo` | Whether swap exists, and how much cache remains. Read manually |
| Read throughput, IOPS, await/latency per device | `diskstats` | **Whether faults became extra I/O (regression) or replaced existing I/O (re-attribution)**, and whether the volume is throttled. **No analytical rules — read manually** |
| `iowait`, `idle`, `system`, `aggregate` | `cpu_utilization` | Whether threads are blocked on storage. See `Underutilized CPU` |
| Resident set per process, top consumers, process set | `processes` | Whether the workload or something else took the memory. **No analytical rules — read manually** |
| `vm.swappiness`, `vm.min_free_kbytes`, `vm.vfs_cache_pressure`, readahead | `sysctl` | Reclaim and swap tuning differences between runs. **No analytical rules — read manually** |
| Instance type, memory size, `Kernel Version`, `CPUs` | `systeminfo` | Structural comparability. See `Kernel Version Mismatch`, `Inconsistent Number of CPUs` |
| **`--interval` and `--period` in both runs**, sample count | run metadata / `aperf_stats` | **Required — mismatched intervals produce a spurious ratio.** No analytical rules — read manually |
| On-CPU profile in both runs | `perf_profile` | Fault-handling and reclaim frames, and whether the I/O path changed. Requires `--profile`. **No analytical rules** |
| Base page size (`getconf PAGESIZE`) in both runs | out of band | **Not collected.** A 64 KiB-page kernel takes 1/16 the faults for the same storage traffic |

## Guidance

Ordered. **This is the `vmstat` finding worth the most attention — it has a baseline, and its subject costs
milliseconds.**

1. **Verify the two runs used the same `--interval`.** The values are per-interval deltas, so mismatched
   intervals manufacture a large ratio out of identical behaviour. Cheapest possible refutation.

2. **Check `pswpin` in both runs.** Non-zero or increased means **swapping** — live anonymous memory being
   read back from disk. This is the most damaging cause, it lands on the hot path rather than on file reads,
   and it has its own remediation. If `SwapTotal` is 0 in `meminfo`, swapping is excluded.

3. **Check `MemAvailable` in both runs.** Down ⇒ a genuine capacity regression; pair this finding with
   `Reduced Memory Availability` and report them together. Unchanged ⇒ **not a pressure problem**, so go to
   step 5.

4. **Read the base value.** `0` means a **clean baseline started faulting** — categorical, and reported at
   the minimum ratio of 1.0 (score −80.00) because of the zero substitution. Do not let the modest score
   hide the severity, and go to the raw series for the magnitude the score cannot carry.

5. **Distinguish regression from re-attribution.** Compare `diskstats` read volume across the runs:
   - **Reads up in step with faults** ⇒ real extra I/O. A regression.
   - **Reads roughly flat while faults rose** ⇒ the same I/O now arrives as page faults instead of `read()`
     calls — an `mmap`-based cache, a memory-mapped index, or a readahead change. **Real, but a
     re-attribution rather than added work**, and the remediation is about access pattern, not capacity.

6. **Confirm the runs are structurally comparable.** Check `MemTotal`, `CPUs`, `Kernel Version`, and the
   instance type. If `Inconsistent Physical Memory`, `Inconsistent Number of CPUs`, or
   `Kernel Version Mismatch` fired, **fix those first** — fault behaviour is not comparable across different
   memory sizes.

7. **Identify who took the memory.** If `nr_anon_pages` grew, the workload did. If it is flat while faults
   rose, something else did — a co-tenant, a sidecar, a monitoring agent, a container-limit change, or a leak
   elsewhere. Read `processes` in both runs.

8. **Characterize the reclaim pressure.** `pgsteal_direct`/`pgscan_direct` mean allocations are stalling to
   reclaim synchronously — materially worse than background kswapd reclaim. `allocstall_*` and
   `pgscan_direct_throttle` mean the pressure is blocking allocators. `oom_kill` non-zero means it has
   already gone past degradation.

9. **Check whether each fault also got more expensive.** Rising `diskstats` latency, or a throttled/cold
   volume, compounds the fault-count increase. `iowait` in `cpu_utilization` confirms the stalls.

10. **Rule out work and phase differences.** Check the comparison-validity findings and compare the series
    shapes — a long idle startup dilutes the mean, a truncated teardown concentrates it.

11. **Then remediate by cause:** swapping ⇒ reduce footprint or size up (and question whether swap belongs on
    this host); working set past cache ⇒ size up, shrink the resident data, or evict competing consumers;
    memory taken by others ⇒ fix the other consumer; re-attribution ⇒ tune access pattern and readahead;
    structural ⇒ re-run with matched instances.

12. **Remember the rule is directional.** A large *improvement* is invisible to it. When evaluating a memory
    optimization, read `pgmajfault` directly in both runs.

## Priority and execution risk

**Priority: P1 — Act now** for the central case, and this is one of the few aperf findings where that is the
*default* rather than the escalation: storage-blocking faults measurably worse than a baseline is a latency
regression that application profiling cannot see. It is **P1** whenever `pswpin` rose (live heap being read
back from disk), whenever the base was 0 and the current series shows sustained faults, or whenever
`allocstall_*` / `oom_kill` are non-zero. It drops to **P2 — Investigate** when `MemAvailable` is unchanged
and `diskstats` read volume is flat — the `read()`→`mmap` re-attribution, where the faults are real but the
I/O is not new. It is **P3 — Monitor** when the ratio is marginal on a near-zero base (three faults per
second is a ratio, not a problem) or when the faults are confined to startup in both runs. And it is
**P4 — Informational** in exactly one situation: `Inconsistent Physical Memory` also fired, which makes this
a structural artifact of an invalid comparison rather than a regression at all. **When
`Reduced Memory Availability` also fired, report the two as one finding** — availability is the cause and
faults are the consequence.

**Execution risk: R0 — Read-only** for the entire diagnosis, including the decisive `pswpin`,
`MemAvailable`, and `diskstats` comparisons. Remediation splits by cause and the spread is wide: **R1** for
`vm.swappiness` or readahead (single write, revertible, though effects appear gradually), **R2** to bound the
largest consumer's footprint so the cache survives (`-Xmx`, `innodb_buffer_pool_size`, `shared_buffers`,
`DOTNET_GCHeapHardLimit` — restart-only and revertible), **R3** to restructure the data set or the access
pattern for locality, **R4** to resize the instance or change the storage volume, and **R5** in the one case
where the answer is to remove swap from a latency-sensitive host — irreversible in effect, because it
converts recoverable stalls into OOM kills.

**What the score is worth: rank on it, with one exception.**
`time_series_stat_run_comparison` amplifies, so `compute_finding_score` makes the score exactly
`ratio / 0.2 × −16`, and `ratio = |score| × 0.2 / 16` inverts it. At 16× the minor-fault rule's weight for
the same ratio, the relative ordering against `Increased Minor Page Faults` is meaningful and correct. **The
exception is a base of 0**, where the score is pinned at −80.00 and carries no magnitude — read the series.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `delta_avg(pgmajfault) >= 0.2` versus the base run — two runs required, and this run is not
the base.

```
STEP 0 — Cheapest refutations first: sampling geometry and comparability.
  IF the two runs used different --interval
  THEN → the metric is a per-INTERVAL delta, so mismatched intervals manufacture
         the ratio out of identical behaviour. The finding is an ARTIFACT
         (P4, R1)
       → re-record both runs at the same interval
       → verify: at matched intervals either the ratio holds or it vanishes
  IF `Inconsistent Physical Memory` fired
  THEN → the runs have different RAM, so fault behaviour differs structurally.
         This is a downstream symptom, not a regression (P4, R0)
       → ../meminfo/inconsistent-physical-memory.md, see that playbook
  IF `Inconsistent Number of CPUs` or `Kernel Version Mismatch` fired
  THEN → reclaim heuristics, THP defaults and per-core heap sizing all differ.
         Treat the ratio as CONFOUNDED (P2, R0)
  ELSE continue to STEP 1.

STEP 1 — Read the BASE value. It decides how to read the score.
  IF the base value prints as 0
  THEN → a CLEAN BASELINE STARTED FAULTING: categorical, and pinned at ratio 1.0
         so the score is -80.00 whether five faults appeared or five thousand
         (P1, R0)
       → the score carries no magnitude here; read the raw pgmajfault series in
         this run to size it, then continue to STEP 2
  IF the base value is near zero (well under 1 fault per interval)
  THEN → the ratio is arithmetic on a tiny denominator. Three faults per second
         against 0.1 is a ratio of 29 and a score of -2320 (P3, R0)
       → read both ABSOLUTE values before treating this as severe
  ELSE the base is substantial, so the ratio is a genuine proportional
       worsening. Recover it as |score| x 0.2 / 16. Continue to STEP 2.

STEP 2 — MANDATORY manual check: `pswpin` in BOTH runs. No rule fires on it.
  IF meminfo SwapTotal is 0
  THEN → no swap exists; swapping is excluded by construction
       → continue to STEP 3
  IF pswpin became non-zero, or rose, in this run
  THEN → SWAPPING started or worsened. The pages being fetched are the
         application's LIVE HEAP, so the stalls land on the hot path rather than
         on file reads that readahead might have covered. The most damaging cause
         (P1, R2)
       → bound the largest anonymous consumer (-Xmx, GCHeapHardLimit, worker
         count) so the resident set fits; restart-only and revertible
       → verify: pswpin returns to 0, workingset_refault_anon falls, and the
         pgmajfault average returns to the base run's level
  IF pswpin is zero in both runs
  THEN → the faults are FILE-backed: page cache, executables, libraries, or mmap
       → continue to STEP 3

STEP 3 — Is this a capacity regression? MemAvailable decides.
  IF MemAvailable fell and workingset_refault_file rose with pgsteal_* /
     pgscan_* active
  THEN → THE WORKING SET GREW PAST THE PAGE CACHE — the most common cause. File
         pages are evicted and immediately re-read (P1, R2)
       → ../meminfo/reduced-memory-availability.md carries the attribution; cap
         the competing consumer, shrink the resident data set, or size up
       → verify: workingset_refault_file and pgmajfault fall together while
         cached bytes rise, and iowait drops with them
  IF pgsteal_direct / pgscan_direct rose, or allocstall_* / oom_kill are non-zero
  THEN → reclaim is SYNCHRONOUS and allocations are stalling; oom_kill means it
         already passed graceful degradation. Tuning will not recover this
         (P1, R4)
       → size up, or cut the resident set hard
       → verify: allocstall_* and oom_kill return to 0 and direct reclaim gives
         way to kswapd
  IF MemAvailable is UNCHANGED between the runs
  THEN → NOT a pressure problem. The cause is an I/O-path change or a work
         difference (P2, R0)
       → continue to STEP 4
  ELSE continue to STEP 4.

STEP 4 — Regression, or re-attribution of existing I/O?
  IF diskstats read volume rose in step with the faults
  THEN → REAL EXTRA I/O. A genuine regression, and diskstats names the device
         (P1, R0)
       → the cause is established in STEP 2 or STEP 3; remediate there
  IF diskstats read volume is roughly FLAT while the faults rose
  THEN → RE-ATTRIBUTION: the same reads now arrive as page faults instead of
         read() calls. A switch to mmap, a memory-mapped index or cache, or a
         readahead change. Real, but not added work (P2, R3)
       → judge the access pattern instead of the count: sequential enough for
         readahead, or random and therefore one round-trip per page
       → verify: faults per unit of work fall when access becomes sequential
         while total read bytes stay flat
  IF diskstats latency rose as well
  THEN → each fault also got more expensive — a throttled or cold volume
         compounding the count increase. The volume may be the fix, not the
         memory (P1, R4)
       → verify: on a provisioned or warmed volume, iowait falls even at an
         unchanged fault count
  ELSE continue to STEP 5.

STEP 5 — Who took the memory, and did the runs do the same work?
  IF nr_anon_pages grew in this run
  THEN → the workload itself grew. If the change under test added a cache, index
         or batch size, the faults are its cost (P2, R0)
  IF nr_anon_pages is FLAT while the faults rose
  THEN → SOMETHING ELSE took the memory: a co-tenant, sidecar, monitoring agent,
         container-limit change, or a leak outside the workload (P2, R0)
       → read `processes` in both runs; vmstat is system-wide and has no
         per-process attribution
  IF the comparison-validity findings show differing work volume between runs
  THEN → more work touches more data and faults more. The ratio is not
         attributable to the change under test (P3, R0)
       → ../GATES.md lists which gates apply
  IF the pgmajfault series is confined to startup in BOTH runs
  THEN → demand paging of a bigger binary or more libraries. Usually benign
         (P3, R0)
  ELSE → the increase is attributed and its cause is established upstream.
         Remediate at that step (P1, R0)

STEP 6 — What survives?
  VALID  : `Reduced Memory Availability`, when it also fired — read the two as
           one finding, availability as cause and faults as consequence
  VALID  : `Major Page Faults Detected` as the threshold-form complement, though
           this finding supersedes it: only this one has a baseline
  VALID  : the ratio when the base is substantial, recoverable as
           |score| x 0.2 / 16
  CAUTION: the ratio on a near-zero base. Three faults per second can score
           -2320
  CAUTION: the ratio when the runs differ in kernel, vCPU count, or base page
           size — the last of which aperf does not collect
  CONFOUNDED: any ratio computed across different --interval settings
  VOID   : the SCORE as a magnitude when the base value is 0. It is pinned at
           -80.00 for every zero-base case, from five faults to five thousand
  VOID   : this finding as a regression when `Inconsistent Physical Memory`
           fired. Different RAM makes it structural
  VOID   : `thp_fault_fallback` as a cause. THP affects TLB pressure and minor
           faults, not storage-backed faulting
  VOID   : any claim that major faults were UNCHANGED from this rule's silence.
           abs: false makes improvements invisible

INSUFFICIENT DATA
  IF either run has fewer than ~5 usable samples
  THEN → the first interval is forced to 0 and the mean rests on a handful of
         deltas, so a 20% ratio is indistinguishable from sampling (P4, R1)
       → re-record both runs with a longer --period
       → verify: on the longer runs either the ratio holds or it collapses below
         0.2
  IF the report has only one run
  THEN → the rule COULD NOT FIRE; it needs a base run (P4, R0)
  IF pgmajfault is absent in the base run
  THEN → the template returns early with a debug! and nothing comparable exists
         (P4, R0)
```

## Runtime-specific consequences

The runtime decides **which** cause is reachable: a large managed heap makes swapping the live risk, while a
runtime that relies on the page cache makes cache eviction the risk. It also decides how expensive a swapped
page is — a collector that walks the whole heap amplifies a handful of swapped pages into a full-heap
fault storm. Runtime is not reported by aperf — infer it from `processes`
([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3) and treat the inference as a hint.

| Runtime | Why the average rises between runs | What to check, and the lever |
|---|---|---|
| **Java** | **The amplifier.** Once any heap page is swapped out, the next full GC touches every page and faults them all back — a stall proportional to heap size, not to request size. A heap raised between runs, or off-heap growth (metaspace, direct buffers, thread stacks, code cache) squeezing the cache, produces exactly this finding | Compare `-Xmx` plus off-heap across the runs against `MemTotal` minus the cache the data set needs; `-XX:+AlwaysPreTouch` makes the commit explicit; `-XX:+UseLargePages` with hugetlb makes the heap unswappable (P1, R2) |
| **.NET** | Server GC's per-core heaps mean **a vCPU difference alone raises the footprint** — the case `Inconsistent Number of CPUs` gates. A gen2 collection has the same touch-everything amplification as Java | `DOTNET_GCHeapHardLimit` or `GCHeapHardLimitPercent` to bound it; `DOTNET_gcServer=0` on small instances to collapse the per-core heaps (P1, R2) |
| **Python** | **Cache eviction, not swap.** Preforking workers each hold private data, and `mmap`-ed models or data sets make the page cache the working set — so more workers directly evicts the data the workers need, and the finding appears with no change to any single worker | Count workers × per-worker RSS against memory minus the mapped data set size; reduce worker count before touching anything else (P1, R2) |
| **Perl** | Preforking servers accumulate private memory as COW pages diverge, so the footprint grows with worker *age*; a run that lived longer squeezes the cache more, which can produce this finding with no configuration difference at all | Compare worker ages and recycling limits across runs before attributing the ratio to the change under test (P2, R2) |

**When the runtime cannot be established**, STEP 2 and STEP 3 are still decisive: `pswpin` non-zero is
swapping and falling `MemAvailable` with rising file refaults is cache eviction, in any language.

## Architecture-specific considerations

**Base page size divides the fault count, and aperf does not collect it.** Each major fault fetches one page,
so a 64 KiB-page kernel takes **1/16 the faults** of a 4 KiB one to move identical bytes from storage — each
fault fetching 16× as much and stalling correspondingly longer. For this comparison rule that is a direct
hazard: **two runs on kernels with different page sizes can show a 16× ratio with identical storage
traffic**, and no aperf finding catches it. aarch64 ships 4 KiB on Amazon Linux and Ubuntu arm64, 64 KiB on
the RHEL family; x86_64 is always 4 KiB. Capture `getconf PAGESIZE` per run out of band; confirm the
architecture from `pmu_config.json` ([../ARCHITECTURE.md](../ARCHITECTURE.md) §1).

| Observed | Reading | Action |
|---|---|---|
| Ratio near 16× with one run on aarch64 and one on x86_64 | Suspect the **page-size divisor** before any memory cause. Compare bytes, not faults | Read `diskstats` read bytes in both runs; if flat, the ratio is the divisor (P2, R0) |
| Ratio elevated **after an Intel→Graviton migration** | **No aperf gate fires on this** ([../GATES.md](../GATES.md)). Default thread stacks are 2 MB on aarch64 vs 1 MB on x86_64 ([../ARCHITECTURE.md](../ARCHITECTURE.md) §4.1), and with THP `always` the full 2 MB commits — a thread-heavy service gains hundreds of MB of anonymous footprint, squeezing the cache into exactly this finding | Compare `meminfo` `AnonPages` across runs first; set THP to `madvise` or tune `-Xss` (P1, R2) |
| Ratio elevated where the two runs used **different instance families** for the same nominal memory | Memory bandwidth, NUMA topology (AMD NPS) and EBS baselines all differ; `numastat` has **no rules**, so read it manually | Match families before comparing, or treat the ratio as CONFOUNDED (P2, R0) |
| Ratio elevated with `Reduced Memory Availability` on the same architecture and kernel | The confounds are excluded and the two findings agree. **This is the clean, actionable case** | Work STEP 3 with confidence (P1, R2) |

**Same-architecture, same-kernel, same-family comparison is the only configuration in which this ratio is
cleanly attributable.** Anything else needs the page size and instance family captured out of band.

## Verification

**Predict before you act.** If the cause is swapping, predict that `pswpin` is non-zero *now* and that
bounding the largest anonymous consumer drives it to exactly 0 while the `pgmajfault` average returns to the
base run's level — if `pswpin` clears but the faults persist, you fixed swap and the real subject is cache
eviction, which is STEP 3. If the cause is cache eviction, predict that `workingset_refault_file` and
`pgmajfault` fall **together** while cached bytes rise; a fault drop with no refault change means the cache
was never the constraint. If the cause is re-attribution, predict that total `diskstats` read bytes are
already flat across the two runs — that check is available *now*, before any change, and it is the cheapest
disconfirmation in this playbook. And if the base value was 0, verification must begin with the raw series:
the score cannot tell you whether you are chasing five faults or five thousand.

## Do not

- **Do not work `Major Page Faults Detected` in preference to this.** That rule fires on a single fault
  anywhere; this one has a baseline and tells you something changed.
- **Do not compare runs recorded at different `--interval` values.** The metric is a per-interval delta.
- **Do not read `100.00% greater than <base> (0)` as merely 2×, or read its score as a magnitude.** The base
  run took **no** major faults — categorical — and the score is pinned at −80.00 for every zero-base case,
  from five faults to five thousand. Go to the raw series.
- **Do not assume more faults means more I/O.** Flat `diskstats` reads with rising faults is a
  re-attribution of existing I/O into the fault path.
- **Do not assume memory pressure.** Unchanged `MemAvailable` with more faults points elsewhere.
- **Do not treat this as a regression when `Inconsistent Physical Memory` also fired.** Different RAM makes
  the comparison structurally invalid; fix that first.
- **Do not conflate minor and major faults, or treat `thp_fault_fallback` as a cause.** Minors cost
  microseconds in memory and majors block on storage, so a large minor-fault increase is not evidence for
  this finding; THP likewise affects TLB pressure and minor-fault counts, not storage-backed faulting.
- **Do not blame the workload without checking `processes`.** `vmstat` is system-wide.
- **Do not rely on this rule to detect an improvement.** `abs: false` makes it one-directional.
- **Do not act on a near-zero base with a small absolute count.** Read the absolute values in the
  description, not just the ratio.
- **Do not remove swap as a reflex fix.** It converts recoverable stalls into OOM kills — R5, not R1.
- **Do not compare across kernels with different base page sizes.** A 16× ratio can represent identical
  storage traffic, and aperf collects no page size.
- **Do not assume the base run is the correct baseline.** aperf picks it by ordering, not by intent.

## References

- Rule: `src/analytics/rules/vmstat.rs:34` — `time_series_stat_run_comparison!` with
  `metric: "pgmajfault"`, `stat: Stat::Average`, `comparator: Comparator::GreaterEqual`, `threshold: 0.2`,
  `abs: false`, `Score::Poor`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — base run from
  `get_base_run_name()`, **early `return` with a `debug!` if the base run lacks the metric**, `continue` if
  the current run lacks it; `original_delta_ratio = 0.0` if equal, **`1.0` if the base stat is 0**
  ("treat current stat as 100% larger"), else `(cur − base)/base`; with `abs: false` the comparison, score,
  and description share the same signed ratio.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Poor = −16`,
  `src/analytics/mod.rs:147`. Threshold is non-zero, so the general branch applies.
- Formatting: `delta_ratio_to_percentage_string` and `formatted_number_string`,
  `src/computations/mod.rs:162` and `:176` — K/M/G/T suffixes, values **truncated** to 2 decimals.
- Delta processing: `src/data/vmstat.rs` — `nr_*` via `add_data_point` (gauges), all others via
  `add_accumulative_data_point`; first sample forced to 0
  (`ignore_first_accumulative_value: true`, `src/data/common/time_series_data_processor.rs:73`), decreasing
  samples `return None` at `:214` and are counted in `decreasing_accumulative_data` with an end-of-collection
  warning.
- Aggregation: `time_series_data_processor_with_custom_aggregate!`; one `values` series per metric, so no
  auto-generated `average` series and no fractional values.
- Default sampling: `--interval 1`, `--period 10` (`src/record.rs:35`, `:45`; `interval >= period` is a hard
  error).
- Metric semantics: `pgmajfault`, `pswpin`, `pswpout`, `workingset_refault_file`,
  `workingset_refault_anon`, `pgsteal_direct`, `pgscan_direct`, `allocstall_*`, `oom_kill` in
  `src/report_frontend/src/definitions/data-descriptions.ts` (`vmstat` block). **No `vmstat` metric carries
  an `optimization` guide**, so aperf offers no upstream remediation text for this finding.
- Related playbooks: `major-page-faults-detected.md`, `increased-minor-page-faults.md`,
  `excessive-page-fault-rate.md`, `../meminfo/reduced-memory-availability.md`,
  `../meminfo/inconsistent-physical-memory.md`, `../systeminfo/inconsistent-number-of-cpus.md`,
  `../systeminfo/kernel-version-mismatch.md`, `../cpu_utilization/underutilized-cpu.md`.
- [Linux memory concepts — page faults](https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html#page-faults)
- [proc_vmstat(5)](https://www.man7.org/linux/man-pages/man5/proc_vmstat.5.html)
- [Reclaim, swappiness and `vm` tunables](https://docs.kernel.org/admin-guide/sysctl/vm.html)
- [EBS volume performance and burst credits](https://docs.aws.amazon.com/ebs/latest/userguide/ebs-volume-types.html)
