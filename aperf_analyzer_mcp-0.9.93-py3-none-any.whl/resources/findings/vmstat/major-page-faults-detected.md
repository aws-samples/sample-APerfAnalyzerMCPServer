---
rule_name: Major Page Faults Detected
data_type: vmstat
data_key: pgmajfault
template: time_series_data_point_threshold
condition: "any(pgmajfault) > 0.0"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "Major page faults require disk I/O to resolve and can severely impact latency. Investigate memory pressure or insufficient page cache."
source: src/analytics/rules/vmstat.rs:16
---

# Major Page Faults Detected

## What fired

**At least one** per-interval delta of `pgmajfault` was **greater than 0** — the system took at least one
major page fault during the recording.

Base score `Poor` (**−16**). Single-run rule, no base run needed.

**This is aperf's most sensitive analytical rule.** The threshold is *any*: one major fault in one interval
of a ten-second recording fires it. That is deliberate — a major fault is a synchronous stall on storage
I/O in the middle of a memory access — but it means the finding appears on a large fraction of real reports
and **the score, not the presence, is what carries the information.**

## The processing defect — the worst run and the mildest score identically

Two independent implementation properties decide what this finding is worth, and both cut against the
obvious reading.

**1. The zero-threshold branch discards the first fault.** `compute_finding_score` short-circuits when
`threshold == 0.0`, returning `rule_score` for `value < 1.0` and `(value − 1.0) × rule_score` otherwise.
Because the comparator is `Greater` and page-fault deltas are integers, the reachable values start at 1 —
and `(1 − 1) × −16` is **−0.00**:

| worst-interval faults | score | consequence |
|---|---|---|
| 1 | **−0.00** | sorts among the *neutral* findings, indistinguishable from Score::Neutral |
| 2 | −16.00 | the nominal `Poor` weight is reached only at **two** faults |
| 10 | −144.00 | not −160: the off-by-one persists at every value |
| 1000 | −15984.00 | five orders of magnitude from the same finding text |

So a one-fault run and a thousand-fault run carry **the same finding name, the same message, and the same
severity label**, differing only in a score that any severity-ordered triage puts at opposite ends of the
list. **Read the score before reading anything else**, and recover the count exactly with
`v = |score| / 16 + 1`.

**2. The startup burst — the most common cause — is partly invisible.**
`ignore_first_accumulative_value: true` (`time_series_data_processor.rs:73`) forces the first sample's delta
to 0, and every fault taken before `aperf record` started is outside the window entirely. On a default
`--period 10` run that suppresses the leading edge of demand paging. This cuts both ways: it removes the
single biggest false-positive source, and it hides genuine first-touch cost. **A report with no such
finding is not evidence that the workload took no major faults.**

## Reasoning

`pgmajfault` is "Page faults that require loading data from storage devices indicating memory pressure and
I/O activity." (`data-descriptions.ts`, `desired: "lower"`, `defaultUnit: "Pages"` for the `vmstat`
section.)

**What a major fault costs, and why "any" is a defensible threshold.** A page fault is the CPU trapping
into the kernel because a virtual address has no valid mapping. A **minor** fault is resolved from memory
already resident — the page is in the page cache, on a free list, or shared with another process — and
costs microseconds. A **major** fault must fetch the page from a storage device, and the faulting thread is
**blocked** for the duration. On EBS that is typically hundreds of microseconds to low milliseconds; on a
cold or throttled volume, far worse. There is no way for the application to overlap that stall: it happens
inside an ordinary memory access, with no I/O call in the source code to attribute it to. That invisibility
is why aperf flags it at all rather than waiting for a rate threshold.

**The four causes, and how to tell them apart.** This is the substance of the diagnosis, because the
remediation is completely different for each:

1. **Ordinary demand paging of executables and libraries at startup.** The first execution of any code path
   faults in its text pages from the file system. **This is the most common cause by a wide margin** and it
   is entirely benign — a fixed one-time cost with no steady-state consequence. Fingerprint: faults
   concentrated in the first intervals, then zero; `pswpin` zero; free memory ample.
2. **Page cache too small for the working set.** File-backed pages the application re-reads keep being
   evicted and re-faulted. Fingerprint: faults **sustained** across the run, `workingset_refault_file`
   rising in step, `pgsteal_*`/`pgscan_*` active, `MemAvailable` low. This is a **capacity** problem —
   either the instance is undersized for the data set or something else on the box is consuming the cache.
3. **Swapping.** Anonymous memory has been written to swap and is being read back. Fingerprint: `pswpin`
   **non-zero** — this is the single check that identifies it — plus `pswpout`,
   `workingset_refault_anon`, and low `MemAvailable`. **The most damaging case**, because unlike file-backed
   faulting the pages being fetched are the application's own live heap, so the stalls land on the hot path.
   Note many EC2 instances have no swap configured at all, in which case `pswpin` will be zero and this
   cause is excluded outright.
4. **`mmap`-based I/O by design.** Databases, memory-mapped indexes, model weight loading, and
   `mmap`-reading tools deliberately fault pages in rather than calling `read()`. Fingerprint: sustained
   faults with **ample** free memory and no reclaim activity. Here the faults *are* the I/O and the finding
   is describing intended behaviour — the question becomes whether the access pattern is efficient
   (sequential with readahead) rather than whether faults exist.

**Why the finding is worth keeping despite the false-positive rate.** Major faults are the mechanism by
which memory pressure becomes latency, and they are nearly invisible in application-level profiling — a
major fault shows up as time inside an innocuous instruction, not as an I/O wait the developer wrote. A
`p99` latency outlier with no explanation in the profile is very often this. So the rule's job is to put
the possibility on the table; narrowing it to one of the four causes above is yours.

**The counter is a delta, correctly.** `vmstat` passes every non-`nr_` metric through
`add_accumulative_data_point` (`src/data/vmstat.rs`) and every `nr_` metric through plain `add_data_point`.
That is the right split — `pgmajfault` is a monotonic counter and `nr_*` are gauges — making `vmstat` one of
aperf's cleanly handled data types, unlike `ena_stat`. Two consequences remain: the **first sample is forced
to 0** (see the defect section), and a **counter decrease is skipped** (producing a gap, not a negative
value — only possible across a reboot).

Also note `vmstat` uses `time_series_data_processor_with_custom_aggregate!` and each metric has a single
series named `values`, so `stats_series_idx` takes the `all_series.len() == 1` branch. **There is no
auto-generated `average` series here**, so — unlike `ena_stat`/`efa_stat` — values are never fractional
and never averaged across devices. Every number is a real integer page count.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator string `"greater than"`:

```
At least one data point in aperf_record is 47 (greater than the threshold of 0).
```

Three things to know:

1. **The value is the *worst single interval*, not the run total.** The template scans every data point and
   keeps the one with the largest `abs(score)`. With one interval of 47 and thirty of 2, you see `47`.
2. **It is a per-interval delta.** With the default `--interval 1` that is faults per second. With
   `--interval 5` it is faults per five seconds — the same workload reports five times the number. Check
   the interval before comparing values across reports.
3. **Faults before the recording are invisible**, because the first sample is forced to 0. On a short
   default run (`--period 10`) that matters: **the startup demand-paging burst is often exactly what you
   miss**, which cuts both ways — it suppresses the most common false positive, and it hides real
   first-touch cost.

Score math — `compute_finding_score(value, 0.0, −16)` takes the **`threshold == 0.0` branch**. For
`value < 1.0` it returns the rule score; otherwise `(value − 1.0) × rule_score`. Since page-fault deltas are
integers and the comparator excludes 0, the reachable values are 1, 2, 3, …:

| worst-interval faults | score | note |
|---|---|---|
| 1 | **−0.00** | **the zero trap** — `(1−1) × −16 = −0` |
| 2 | −16.00 | the nominal `Poor` weight is reached only at *two* faults |
| 3 | −32.00 | |
| 5 | −64.00 | |
| 10 | −144.00 | |
| 50 | −784.00 | |
| 100 | −1584.00 | |
| 1000 | −15984.00 | |
| 10000 | −159984.00 | |

Two properties to carry away:

- **The score understates by exactly one fault.** It is `(v − 1) × 16`, not `v × 16`. Recover the value
  with `v = |score| / 16 + 1`.
- **A single-fault run scores exactly −0.00 and will sort among the neutral findings**, even though the
  finding text and message are identical to a catastrophic one. If you triage by score alone you will skip
  it — which is usually correct, but know that is what is happening.

Beyond that the score is **unbounded and linear**, so it *is* worth ranking on: −16 is two faults in the
worst second, −1584 is a hundred. That is a real distinction and this is one of the aperf scores worth
trusting.

## Interpretation

**Start with the score and the series shape** — they separate the four causes faster than anything else:

| Observation | Reading |
|---|---|
| Score **−0.00** (one fault, one interval) | Almost always noise: a single library page, a one-off `mmap` touch. Note and move on |
| Faults **only in the first intervals**, then zero | **Startup demand paging.** Benign, one-time. The most common firing |
| Faults **sustained** at a low, steady rate | Either `mmap`-based I/O by design or a page cache slightly too small. Check `MemAvailable` and reclaim activity to tell which |
| Faults **sustained and high** | Real pressure. Go to the swap check immediately |
| Faults **increasing** over the run | A growing working set or a leak progressively squeezing the cache |
| Faults in **bursts** | Correlate the timestamps with a phase change, a new file being read, or a reclaim event |
| Very high value in **one** interval only | A single large `mmap` region being touched, a file being read in, or a reclaim storm. Check what happened at that timestamp |

**Then run the two decisive checks:**

| Evidence | Reading |
|---|---|
| **`pswpin` non-zero** | **Swapping.** The application's own anonymous memory is being read back from swap. The most damaging cause and the one to fix first. Read manually — **no rule fires on `pswpin`** |
| `pswpin` zero | Not swapping. The faults are file-backed — executables, libraries, page cache, or `mmap` |
| **`MemAvailable` low / falling** | Memory pressure is real; the page cache is being squeezed. See `Reduced Memory Availability` |
| `MemAvailable` ample | **No pressure** — so the faults are demand paging or intentional `mmap` I/O, not a capacity problem. This single check eliminates causes 2 and 3 |
| `workingset_refault_file` rising with the faults | **Page cache thrash**: pages evicted and immediately re-read. Direct evidence for cause 2 |
| `workingset_refault_anon` rising | Anonymous pages being refaulted — corroborates swapping |
| `pgsteal_*` / `pgscan_*` active | The kernel is reclaiming; the cache is under contention. `pgscan_direct` in particular means allocations are stalling to reclaim synchronously |
| `pgscan_direct_throttle`, `allocstall_*` non-zero | Allocation stalls — pressure severe enough to block allocators |
| `oom_kill` non-zero | **Past the point of degradation.** Processes were killed. Read manually — no rule fires on it |
| Disk read activity rising with the faults | Confirms the faults are hitting storage and shows which device. **No analytical rules for `diskstats` — read manually** |
| `nr_free_pages` low | Little headroom; reclaim is close behind |
| `thp_fault_fallback` high | Huge-page allocation failing to fragmentation — a separate memory-health signal worth noting |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Increased Major Page Faults` | The comparison-mode counterpart: faults grew ≥20% versus the base run. **Read them together** — this one says faults exist, that one says they got worse |
| `Excessive Page Fault Rate` | Total fault rate is also very high. If `pgmajfault` is a tiny fraction of `pgfault`, the two findings have different subjects: minor-fault volume vs. major-fault stalls |
| `Increased Minor Page Faults` | The working set or allocation pattern changed. If majors rose too, the change pushed past cache capacity |
| `Reduced Memory Availability` | **The strongest corroboration.** Less memory available and major faults happening is the classic pressure signature |
| `Inconsistent Physical Memory` | The runs have different amounts of RAM — of course the fault behaviour differs. **Fix that first**; this finding is a downstream symptom |
| `Huge Page Disabled` | More TLB pressure, but *not* a cause of major faults. Related memory tuning, different mechanism — do not conflate |
| High `iowait` in `cpu_utilization` | Confirms threads are blocked on storage. Together with major faults, it locates the stall |
| `Underutilized CPU` | Consistent with threads blocked on fault I/O rather than running |
| High `system` CPU | Fault handling and reclaim are kernel work; heavy reclaim shows up here |

**Known false positives — a large share of firings:**

- **Startup demand paging.** Executable and library text faulted in on first execution. Benign, one-time.
  The most common cause of this finding.
- **A single fault scoring −0.00.** Real, logged, and almost certainly irrelevant.
- **`mmap`-based I/O by design.** Databases and memory-mapped readers fault deliberately; the faults are
  the intended I/O path, not a symptom.
- **First-touch of a large allocation** backed by a file.
- **A short recording catching a one-time event** — a log rotation, a config reload, a JIT warm-up.
- **Faults on a co-tenant workload's behalf.** `vmstat` is system-wide; another process on the instance can
  be responsible. Cross-check `processes` (**no analytical rules — read manually**).
- **Container image layers** being faulted in on first access.

**Not a false positive, and worth stating plainly:** if `pswpin` is non-zero, the finding is real regardless
of how small the count is. Swap-in on a latency-sensitive workload is worth chasing at any rate.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`pswpin`, `pswpout`** | `vmstat` | **Do this first.** Non-zero `pswpin` means swapping — the most damaging cause and a completely different remediation. **No rules fire on these** — read manually |
| The `pgmajfault` **series shape** | `vmstat` | Startup-only (benign) vs sustained (capacity) vs increasing (growth) vs burst (event). The fastest cause discriminator after `pswpin` |
| `workingset_refault_file`, `workingset_refault_anon` | `vmstat` | **Direct evidence of thrash** — pages evicted then immediately re-read. File vs anon splits cause 2 from cause 3 |
| `pgsteal_kswapd`, `pgsteal_direct`, `pgsteal_file`, `pgsteal_anon` | `vmstat` | Whether the kernel is reclaiming, and whether reclaim is background (kswapd) or synchronous (direct — worse) |
| `pgscan_direct`, `pgscan_kswapd`, `pgscan_direct_throttle` | `vmstat` | Reclaim scanning pressure; `direct` means allocations are stalling |
| `allocstall_normal`, `allocstall_dma32`, `allocstall_movable` | `vmstat` | Allocation stalls — pressure severe enough to block allocators. Read manually |
| `nr_free_pages`, `nr_inactive_file`, `nr_anon_pages` | `vmstat` | Headroom and the anon/file balance. Gauges, added with `add_data_point` — not deltas |
| `oom_kill` | `vmstat` | Whether pressure already killed processes. Read manually |
| `pgfault`, `pgminorfault` | `vmstat` | The fault mix — majors as a fraction of the total tells you how much of the fault cost is I/O-bound. See `Excessive Page Fault Rate` |
| `thp_fault_fallback`, `compact_stall` | `vmstat` | Fragmentation and compaction pressure — a parallel memory-health signal |
| `MemAvailable`, `MemFree`, `MemTotal`, `Cached`, `Buffers` | `meminfo` | **The capacity question.** Ample available memory eliminates causes 2 and 3 outright. See `Reduced Memory Availability` |
| `SwapTotal`, `SwapFree` | `meminfo` | Whether swap exists at all — if `SwapTotal` is 0, swapping is excluded by construction. Read manually |
| Read throughput, IOPS, queue depth, latency per device | `diskstats` | Whether the faults are saturating a volume, and which one. **No analytical rules — read manually** |
| `iowait`, `idle`, `system`, `aggregate` | `cpu_utilization` | Whether threads are blocked on storage. See `Underutilized CPU` |
| Resident set per process, top memory consumers | `processes` | **Who is faulting**, and whether it is the workload or a co-tenant. **No analytical rules — read manually** |
| `vm.swappiness`, `vm.min_free_kbytes`, `vm.vfs_cache_pressure`, readahead | `sysctl` | Reclaim and swap tuning. **No analytical rules — read manually** |
| Instance type, memory size | `systeminfo` | Whether the instance is sized for the working set |
| `--interval`, `--period`, sample count | run metadata / `aperf_stats` | **Required to interpret the value** — it is per interval, not per second, unless the interval is 1 |
| On-CPU profile | `perf_profile` | Fault handling and reclaim frames. Requires `--profile`. **No analytical rules** |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | Related memory tuning, not a cause. See `Huge Page Disabled` |

## Guidance

Ordered. **Steps 1–3 resolve most firings in under a minute.**

1. **Read the score.** `−0.00` means the worst interval had exactly **one** major fault — the zero-threshold
   branch. That is noise on any real workload; note it and stop. Otherwise recover the count with
   `|score| / 16 + 1` and carry on.

2. **Check `pswpin`.** Non-zero means **swapping** — the application's own anonymous memory is being read
   back from disk. This is the most damaging cause, has a different remediation from every other, and is
   worth chasing at any rate on a latency-sensitive workload. If `SwapTotal` is 0 in `meminfo`, swapping is
   excluded outright.

3. **Check `MemAvailable`.** Ample available memory **eliminates memory pressure as the cause**, which
   leaves demand paging or intentional `mmap` I/O — neither of which is a capacity problem. Low or falling
   available memory confirms pressure; see `Reduced Memory Availability`.

4. **Read the series shape.** Faults confined to the **first intervals** ⇒ startup demand paging, benign,
   done. **Sustained** ⇒ go to step 5. **Increasing** ⇒ a growing working set or a leak. **Bursts** ⇒
   correlate the timestamp with a phase change or a reclaim event.

5. **Distinguish page-cache thrash from intentional `mmap` I/O** — the two sustained causes:
   - `workingset_refault_file` rising in step with the faults, plus active `pgsteal_*`/`pgscan_*`, means
     **thrash**: pages are being evicted and immediately re-read. A capacity problem.
   - Sustained faults with **no** reclaim activity and ample free memory means **`mmap` by design**. The
     faults *are* the I/O. Shift the question to whether the access pattern is sequential enough for
     readahead to help.

6. **Confirm the stall is real, and where it lands.** Check `iowait` in `cpu_utilization` and read
   throughput/latency in `diskstats`. Major faults with no `iowait` and no disk reads deserve a second look
   — something does not add up.

7. **Attribute the faults to a process.** `vmstat` is system-wide. Read `processes` to confirm the workload
   is responsible rather than a co-tenant, a backup job, or a log shipper.

8. **Check the interval before comparing across reports.** The value is a per-interval delta; a report taken
   with `--interval 5` shows five times the count for identical behaviour.

9. **Then remediate by cause:**
   - **Swapping** ⇒ reduce the memory footprint or move to a larger instance. Consider whether swap should
     exist on this host at all for a latency-sensitive workload.
   - **Page-cache thrash** ⇒ the working set exceeds available cache. Size up, reduce the resident data set,
     stop competing consumers, or make the access pattern more local.
   - **Startup demand paging** ⇒ nothing to fix. If startup latency itself matters, pre-warming or
     pre-faulting the binary is the lever.
   - **`mmap` by design** ⇒ tune the access pattern and readahead, not the fault count.

10. **Re-read the related findings in this light.** `Increased Major Page Faults` tells you whether this got
    *worse* than the base run; `Reduced Memory Availability` tells you whether pressure explains it;
    `Inconsistent Physical Memory` means the runs are not comparable and must be fixed first.

## Priority and execution risk

**Priority: P4 — Informational** at a score of **−0.00**, which is the single most common firing: one fault
in one interval, no action. Startup-only faults with ample memory are also **P4**. Sustained faults with a
small score and no reclaim activity — the `mmap` case — are **P3 — Monitor**: intended behaviour whose access
pattern might repay tuning. A material score with `workingset_refault_file` rising and `MemAvailable` falling
is **P2 — Investigate**, and it becomes **P1 — Act now** when `pswpin` is non-zero on a latency-sensitive
workload, or when `oom_kill` or `allocstall_*` show pressure has already passed the point of graceful
degradation. **`pswpin` non-zero promotes this finding at any count** — swap-in stalls land on live heap, on
the hot path, invisible to application profiling. Priority spans the full range on this one finding, which is
why the score has to be read first.

**Execution risk: R0 — Read-only** for the whole diagnosis; every discriminator in the decision tree is
already in the report. Remediation splits sharply by cause: **R1** to change `vm.swappiness` or readahead
(revertible with a single write, though swappiness changes behaviour gradually rather than instantly),
**R2** to cap a runtime's heap or cache so the working set fits (`-Xmx`, a database's `shared_buffers` or
`innodb_buffer_pool_size` — restart-only and revertible), **R3** to restructure the data set or access
pattern for locality, and **R4** to resize the instance or disable swap on the host. Note that *disabling*
swap is not the safe-sounding option it appears to be: it converts swap-in stalls into OOM kills.

**What the score is worth: a lot, once the off-by-one is accounted for.** `time_series_data_point_threshold`
amplifies, so `compute_finding_score` makes the score a faithful, unbounded, linear function of the worst
interval's fault count — `v = |score| / 16 + 1` inverts it exactly. Rank on it freely **within** this rule.
Do not rank it against comparison-rule scores, whose base is a ratio rather than a count.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one per-interval `pgmajfault` delta `> 0.0` in this run — one metric, one run, no
baseline.

```
STEP 0 — Read the score. It is the only thing separating noise from catastrophe.
  The finding text is identical at every magnitude; only the score differs.
  IF the score is -0.00
  THEN → the worst interval had exactly ONE major fault: (1-1) x -16 = -0. A
         single library page or one mmap touch. Note and STOP (P4, R0)
  ELSE recover the count as |score| / 16 + 1 and continue to STEP 1.
       -16 is 2 faults, -144 is 10, -1584 is 100, -15984 is 1000.

STEP 1 — MANDATORY manual check: `pswpin`. Is this swapping?
  No aperf rule fires on pswpin, so this check is manual and it is decisive.
  IF meminfo SwapTotal is 0
  THEN → no swap exists on this host; swapping is excluded by construction
       → continue to STEP 2
  IF pswpin is non-zero
  THEN → SWAPPING: the application's own anonymous heap is being read back from
         storage, stalling on the hot path, invisible to application profiling.
         The most damaging cause and it outranks the count (P1, R4)
       → reduce the resident footprint (cap the heap or cache) or size up; treat
         removing swap as a last resort since it converts stalls into OOM kills
       → verify: on the changed run pswpin returns to 0, workingset_refault_anon
         falls, and the tail latency that prompted the investigation improves
  IF pswpin is zero but pswpout is non-zero
  THEN → pages were written OUT but not read back yet. Pressure is building and
         this finding is its leading edge (P2, R2)
       → cap the largest anonymous consumer before swap-in begins
       → verify: pswpout stops growing and MemAvailable stabilizes
  ELSE the faults are FILE-backed — executables, libraries, page cache, or mmap.
       Continue to STEP 2.

STEP 2 — Is there any memory pressure at all? One check eliminates two causes.
  IF MemAvailable is ample and pgsteal_* / pgscan_* / allocstall_* are all quiet
  THEN → NO pressure. Neither "page cache too small" nor "swapping" applies, so
         the faults are demand paging or intentional mmap I/O (P4, R0)
       → continue to STEP 3
  IF oom_kill is non-zero, or allocstall_* / pgscan_direct_throttle are non-zero
  THEN → pressure has already passed graceful degradation: allocations are
         stalling and processes were killed (P1, R4)
       → size up, or cut the resident set hard; tuning will not recover this
       → verify: oom_kill and allocstall_* return to 0 and the fault count falls
         with them
  IF MemAvailable is low or falling with pgsteal_* active
  THEN → pressure is real and the page cache is being squeezed (P2, R0)
       → ../meminfo/reduced-memory-availability.md carries the attribution
       → continue to STEP 3 to separate thrash from design

STEP 3 — Read the pgmajfault series shape.
  IF faults appear only in the first intervals, then go to zero
  THEN → STARTUP DEMAND PAGING: executable and library text faulted in on first
         execution. Benign, one-time, and the single most common firing of this
         rule (P4, R0)
       → if startup latency itself is the concern, pre-faulting the binary is
         the only lever; the steady state is already clean
  IF faults come in isolated bursts
  THEN → correlate the timestamp with a phase change, a log rotation, a config
         reload, a JIT warm-up, or a new file being read (P4, R0)
  IF faults are INCREASING across the run
  THEN → a growing working set or a leak is progressively squeezing the cache.
         The trajectory matters more than the current count (P2, R0)
       → re-record over a longer --period to establish the slope
  IF faults are SUSTAINED at a steady rate
  THEN → continue to STEP 4, the one branch where the two remaining causes look
         alike
  ELSE → a single high interval: one large mmap region touched, one file read in,
         or one reclaim storm. Check what happened at that timestamp (P3, R0)

STEP 4 — Sustained faults: page-cache thrash, or mmap by design?
  IF workingset_refault_file rises in step with the faults AND pgsteal_* /
     pgscan_* are active
  THEN → THRASH: file pages are evicted and immediately re-read. The working set
         exceeds the available cache — a capacity problem, not a code one
         (P2, R2)
       → cap the competing consumer's memory so cache survives, reduce the
         resident data set, or size up; restart-only and revertible
       → verify: workingset_refault_file and pgmajfault both fall while cached
         bytes rise; iowait drops with them
  IF the faults are sustained with NO reclaim activity and ample free memory
  THEN → mmap-BASED I/O BY DESIGN. The faults ARE the I/O path, which the
         database or memory-mapped reader chose deliberately. The count is not
         the defect (P3, R3)
       → shift the question to access-pattern efficiency: sequential enough for
         readahead, or random and therefore one storage round-trip per page
       → verify: after making access sequential or raising readahead, disk read
         throughput rises while pgmajfault per unit of work falls
  ELSE → sustained faults with partial reclaim evidence. Treat as thrash and
         re-check after capping the largest consumer (P2, R0)

STEP 5 — Did the stall land, and on whom?
  IF cpu_utilization iowait is elevated and diskstats shows read activity
     tracking the faults
  THEN → CONFIRMED: threads are blocked on storage, and diskstats names the
         device. This is the latency mechanism made visible (P2, R0)
  IF there is no iowait and no disk read activity anywhere in the run
  THEN → the arithmetic does not close. Either the count is tiny (see STEP 0) or
         the faults resolved from a cache above the device (P4, R0)
  IF `processes` shows the workload is not the dominant memory consumer
  THEN → a co-tenant, backup job, container image pull, or log shipper is
         faulting. vmstat is system-wide (P4, R0)
  IF --interval is not 1
  THEN → the printed value is faults per interval, not per second. Divide before
         comparing against any other report (P4, R0)
  ELSE → the faults are attributed to the workload and the cause is established
         in STEP 3 or STEP 4. Remediate there (P2, R0)

STEP 6 — What survives?
  VALID  : every other finding in the report. This rule reads one metric in one
           run and contaminates nothing
  VALID  : the worst-interval count, recoverable exactly as |score| / 16 + 1
  VALID  : `Increased Major Page Faults` as the complement — this one says faults
           exist, that one says they grew
  CAUTION: the value as a rate. It is a per-interval delta, so faults per second
           only at --interval 1
  CAUTION: any claim about the startup burst. The first sample's delta is forced
           to 0 and pre-recording faults are outside the window
  CAUTION: "memory pressure" when MemAvailable is ample. STEP 2 eliminates it
  VOID   : the finding's PRESENCE as a severity signal. The threshold is any
           fault; presence alone carries no magnitude
  VOID   : `Huge Page Disabled` as a cause. THP reduces TLB pressure; it neither
           causes nor cures major faults
  VOID   : cross-report comparison of the value at differing --interval

INSUFFICIENT DATA
  IF the run has fewer than ~5 usable samples
  THEN → the first delta is forced to 0, so a 1-2 sample run reports at most one
         usable interval. Neither shape nor sustainment is determinable (P4, R1)
       → re-record with a longer --period
       → verify: on the longer run the shape resolves into startup-only,
         sustained, increasing, or burst
  IF the report has no pgmajfault metric (vmstat absent or /proc/vmstat
     unreadable)
  THEN → the rule COULD NOT FIRE. Silence is not evidence of zero major faults
         (P4, R0)
  IF the aperf log carries "skipped N data points due to unexpected decrease"
     for pgmajfault
  THEN → intervals were dropped, so both the count and the shape are incomplete
         (P3, R0)
```

## Runtime-specific consequences

The runtime determines **which** of the four causes is even reachable: a large managed heap makes swapping
the live risk, while a runtime that leans on the page cache makes thrash the risk. Runtime is not reported
by aperf — infer it from `processes` ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3) and treat the
inference as a hint.

| Runtime | Which cause it invites | What to check, and the lever |
|---|---|---|
| **Java** | **Swapping is the acute risk.** A large heap is live anonymous memory; once any of it is swapped out, the collector's next full pass touches every page and faults it all back in — a stall proportional to heap size, not to the request | Confirm `-Xmx` plus off-heap (metaspace, direct buffers, thread stacks, code cache) fits with cache headroom; `-XX:+AlwaysPreTouch` makes the commit explicit at startup; `-XX:+UseLargePages` with hugetlb makes the heap unswappable outright (P1, R2) |
| **.NET** | Server GC's per-core heaps plus a generous gen0 budget grow the anonymous footprint quietly as vCPU count rises; the same collector-touches-everything amplification as Java | `DOTNET_GCHeapHardLimit` or `GCHeapHardLimitPercent` to bound it, `DOTNET_gcServer=0` on small instances to collapse the per-core heaps (P2, R2) |
| **Python** | **Thrash, not swap.** Preforking servers share COW text but each worker's data diverges; the model or data set is often `mmap`-ed, so cause 4 and cause 2 are easy to confuse | Count workers × per-worker RSS against memory minus the cache the data set needs; for `mmap`-ed models, judge the access pattern rather than the fault count (P2, R2) |
| **Perl** | Preforking servers with long-lived interpreters accumulate per-worker private memory as COW pages diverge, so the footprint grows with worker age rather than with load | Lower the requests-per-worker limit so workers are recycled before their private footprint squeezes the cache (P3, R2) |

**When the runtime cannot be established**, the runtime-agnostic reading holds: `pswpin` non-zero is
swapping regardless of language, and sustained file refaults with reclaim activity are a capacity problem
regardless of what allocated the memory.

## Architecture-specific considerations

**The base page size sets the fault count for identical I/O, and aperf does not collect it.** A major fault
brings in one page, so a 64 KiB-page kernel takes **1/16 the faults** of a 4 KiB one to load the same bytes —
each fault fetching 16× as much and stalling correspondingly longer. Since this rule's threshold is *any*
fault, page size does not change **whether** it fires, but it changes the score by up to 16× for identical
storage traffic. aarch64 kernels ship 4 KiB on Amazon Linux and Ubuntu arm64, and 64 KiB on the RHEL family;
x86_64 is always 4 KiB. Capture `getconf PAGESIZE` out of band and confirm the architecture from
`pmu_config.json` ([../ARCHITECTURE.md](../ARCHITECTURE.md) §1).

| Observed | Reading | Action |
|---|---|---|
| Score materially lower on aarch64 than x86_64 for the same workload | If the aarch64 kernel uses **64 KiB** pages, this is the page-size divisor, not an improvement. The storage traffic may be identical | Compare `diskstats` read bytes, not fault counts (P3, R0) |
| Faults appear **after an Intel→Graviton migration** | **No aperf gate fires on this** ([../GATES.md](../GATES.md)). Larger default thread stacks on aarch64 (2 MB vs 1 MB, per [../ARCHITECTURE.md](../ARCHITECTURE.md) §4.1) raise the anonymous footprint, which can push a previously-fitting working set into reclaim | Compare `meminfo` `AnonPages` across the runs before blaming storage; tune `-Xss` or set THP to `madvise` (P2, R2) |
| Faults with `Inconsistent Physical Memory` also fired | The runs have different RAM. Fault behaviour differs for a structural reason | ../meminfo/inconsistent-physical-memory.md gates the comparison (P1, R0) |
| Faults on an instance whose storage is EBS gp2/gp3 near its IOPS ceiling | The per-fault stall is far worse than the nominal figure; burst credit exhaustion multiplies it | Read `diskstats` latency per device; the fix may be the volume, not the memory (P1, R4) |

**Cross-architecture comparison of the score is unsound** whenever the page sizes differ: a 16× score gap
can represent identical bytes read from storage. There is no aperf field that catches it.

## Verification

**Predict before you check.** If the cause is swapping, predict that `pswpin` is non-zero *now* and that
capping the largest anonymous consumer drives it to exactly 0 while `workingset_refault_anon` falls with it
— if `pswpin` persists after the cap, the footprint was not what you thought it was. If the cause is
page-cache thrash, predict that `workingset_refault_file` and `pgmajfault` fall **together** while cached
bytes rise; a fault drop with no change in refaults means the cache was never the constraint. If the cause
is `mmap` by design, predict that fault count per unit of work falls when access becomes sequential while
total disk read bytes stay flat or rise. And if the finding persists at a **score near −0.00**, verification
is unnecessary — the run took one or two major faults, and nothing in that is measurable.

## Do not

- **Do not treat the presence of this finding as a problem.** The threshold is *any* fault. The score, the
  series shape, and `pswpin` carry the information — not the fact that it fired.
- **Do not read a `−0.00` score as a bug in aperf.** It is the zero-threshold branch:
  `(1 − 1) × −16 = −0`. One fault in the worst interval scores zero by construction.
- **Do not read the score as `faults × 16`.** It is `(faults − 1) × 16` — the nominal `Poor` weight is not
  reached until *two* faults.
- **Do not read the value as a run total.** It is the worst single interval.
- **Do not read the value as a per-second rate** unless `--interval 1`. It is a per-interval delta.
- **Do not conclude "no major faults" from the absence of this finding.** The first sample is forced to 0,
  so faults before the recording — including the startup burst — are invisible.
- **Do not assume memory pressure.** Ample `MemAvailable` with sustained faults means demand paging or
  intentional `mmap` I/O, and no amount of memory tuning will change it.
- **Do not conflate major with minor faults.** Minor faults cost microseconds and are resolved in memory;
  majors block on storage. `Excessive Page Fault Rate` is about the former's volume, this is about the
  latter's stalls.
- **Do not blame the workload without checking `processes`.** `vmstat` is system-wide.
- **Do not treat `Huge Page Disabled` as a cause.** THP reduces TLB pressure; it does not cause or cure
  major faults.
- **Do not skip the finding just because `pswpin` is zero.** Page-cache thrash produces no swap activity and
  is still a genuine capacity problem.
- **Do not disable swap as a reflex fix.** It converts swap-in stalls into OOM kills, which is a worse
  failure mode for most workloads.
- **Do not compare scores across kernels with different base page sizes.** A 64 KiB-page kernel takes 1/16
  the faults for identical storage traffic, and aperf collects no page size.

## References

- Rule: `src/analytics/rules/vmstat.rs:16` — `time_series_data_point_threshold!` with
  `metric: "pgmajfault"`, `comparator: Comparator::Greater`, `threshold: 0.0`, `Score::Poor`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — the worst data
  point is selected by largest `abs(compute_finding_score(...))` using `>=`, so the **last** tied point
  wins; the sign is reapplied at the end; the finding is keyed on the metric name.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — **`threshold == 0.0` branch**:
  returns the rule score if `value < 1.0`, else `(value − 1.0) × rule_score`. The branch **returns early**,
  before the `value == 0.0` doubling, which is unreachable here anyway. `Score::Poor = −16`,
  `src/analytics/mod.rs:147`.
- Delta processing: `src/data/vmstat.rs` — `nr_*` metrics via `add_data_point` (gauges), all others via
  `add_accumulative_data_point` (counters); first sample forced to 0
  (`ignore_first_accumulative_value: true`, `src/data/common/time_series_data_processor.rs:73`), decreasing
  samples `return None` at `:214` and are counted in `decreasing_accumulative_data` with an end-of-collection
  warning.
- Aggregation: `time_series_data_processor_with_custom_aggregate!`; each metric has a single `values`
  series, so `stats_series_idx` takes the `all_series.len() == 1` branch
  (`src/data/common/time_series_data_processor.rs:312`). **No auto-generated `average` series**, so values
  are never fractional.
- Default sampling: `--interval 1`, `--period 10` (`src/record.rs:35`, `:45`; `interval >= period` is a hard
  error).
- Metric semantics: `pgmajfault`, `pgfault`, `pgminorfault`, `pswpin`, `pswpout`, `workingset_refault_*`,
  `pgsteal_*`, `pgscan_*`, `allocstall_*`, `oom_kill`, `nr_free_pages` in
  `src/report_frontend/src/definitions/data-descriptions.ts` (`vmstat` block; the summary itself notes
  "the values were computed using the delta of two snapshots, so that first value is always zero").
  **No `vmstat` metric carries an `optimization` guide**, so aperf offers no upstream remediation text for
  this finding.
- Related playbooks: `increased-major-page-faults.md`, `increased-minor-page-faults.md`,
  `excessive-page-fault-rate.md`, `../meminfo/reduced-memory-availability.md`,
  `../meminfo/inconsistent-physical-memory.md`, `../kernel_config/huge-page-disabled.md`,
  `../cpu_utilization/underutilized-cpu.md`.
- [Linux memory concepts — page faults](https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html#page-faults)
- [proc_vmstat(5)](https://www.man7.org/linux/man-pages/man5/proc_vmstat.5.html)
- [Reclaim, swappiness and `vm` tunables](https://docs.kernel.org/admin-guide/sysctl/vm.html)
- [Multi-gen LRU and working-set refault accounting](https://docs.kernel.org/admin-guide/mm/multigen_lru.html)
