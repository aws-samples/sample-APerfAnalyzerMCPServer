---
rule_name: Increased Minor Page Faults
data_type: vmstat
data_key: pgminorfault
template: time_series_stat_run_comparison
condition: "delta_avg(pgminorfault) >= 0.2"
base_score: Concerning
score_sign: negative
requires_comparison: true
aperf_message: "A significant increase in minor page faults may indicate changes in memory access patterns or working set size."
source: src/analytics/rules/vmstat.rs:24
---

# Increased Minor Page Faults

## What fired

The **average** of `pgminorfault` in this run is **at least 20% higher** than in the **base run**.

`abs: false` — this rule is **directional**. A *decrease* never fires it, however large. Comparator is
`GreaterEqual`, so exactly 20% does fire.

Base score `Concerning` (**−1**), the mildest negative score aperf defines. **Comparison-only rule** — it
cannot fire on a single-run report and never fires on the base run.

**This is a change-detector, not a problem-detector.** Minor faults are cheap and normal; every process
takes millions of them. What the rule flags is that the *rate* moved, which almost always means something
about the workload changed: more allocation, a different memory layout, more processes or threads, a
different huge-page situation. The mild score is honest about that — it is a lead, not a verdict.

## The collection gap — the metric does not exist in the kernel

`pgminorfault` **is not a `/proc/vmstat` field.** No such counter exists. aperf synthesizes it in
`src/data/vmstat.rs` as `pgfault_delta − pgmajfault_delta` per interval, then adds the result with plain
`add_data_point` — correctly, since both operands are already deltas. Three consequences that no other
`vmstat` metric shares:

| Situation | What happens to `pgminorfault` |
|---|---|
| Both `pgfault` and `pgmajfault` deltas present | the value is emitted — the normal case |
| Either counter absent from a snapshot | **no value emitted for that interval** — the series has a hole |
| Either delta dropped for an unexpected decrease (`time_series_data_processor.rs:214`) | **no value emitted**, even though the *other* counter's value survived in its own series |
| First interval | 0, because both inputs are forced to 0 |

So **a gap in this series is structural, not data loss**, and it is *silent*: the aperf log warns about the
decrease in `pgfault` or `pgmajfault`, never about the derived metric that vanished as a result. The mean
that `Stat::Average` computes is then a mean over whichever intervals survived — and because the two runs can
lose different intervals, **the 20% comparison can be between two differently-sampled subsets.** Check the
aperf log for skipped-data-point warnings on `pgfault` and `pgmajfault` before trusting a marginal ratio.

The same derivation explains the most misleading reading of this finding: a base value of exactly `0` almost
never means the base system took no minor faults. It means the derivation produced nothing there — and the
run-comparison template substitutes ratio `1.0` for a zero base, printing `100.00% greater`. **That is a data
failure rendered as a 2× regression.**

## Reasoning

`pgminorfault` is "Page faults resolved without disk I/O where the page is already present in memory.
**Derived as total page faults minus major page faults.**" (`data-descriptions.ts`, `desired: "lower"`.)

**What a minor fault costs.** The CPU traps into the kernel because a virtual address has no valid page
table entry, and the kernel resolves it **without touching storage**: allocating a zero page for a
first-touch anonymous allocation, mapping a page already in the page cache, resolving a copy-on-write after
a fork, or attaching a shared page. Cost is on the order of a microsecond — the trap, the page-table walk,
the TLB refill, and for anonymous pages the zeroing of a fresh page. Individually negligible; at millions
per second it becomes measurable **kernel CPU time**, not latency stalls.

**So why flag a 20% increase at all?** Because minor-fault rate is one of the most sensitive proxies for
"the memory behaviour of this workload changed", and it moves for reasons that matter:

1. **More memory allocation.** Every first touch of newly allocated anonymous memory is a minor fault. A
   20% rise often just means the workload allocated 20% more — a new cache, a larger buffer pool, a bigger
   batch size. Frequently the intended effect of the change under test.
2. **Allocator behaviour changed.** An allocator that returns memory to the kernel (`MADV_DONTNEED`,
   `munmap`) and re-faults it is doing measurable extra work versus one that retains it. A glibc-to-jemalloc
   switch, a `malloc_trim` policy change, or an arena-count change moves this metric substantially with no
   change in application logic. **This is the cause most often missed.**
3. **Huge pages stopped working.** A 2 MiB transparent huge page covers 512 base pages with **one** fault.
   Lose THP — to fragmentation, to a config change, to an allocation pattern that no longer qualifies — and
   the fault count for the same memory rises by up to 512×. A large jump here with
   `thp_fault_fallback` rising is this, and it is a genuine regression with a clear fix.
4. **More processes or threads.** Process creation faults in the new address space; `fork`-heavy workloads
   (build systems, CGI-style servers, shell pipelines) generate minor faults in proportion to process count.
   Copy-on-write resolution after fork is minor-fault work too.
5. **A different working set or access order.** Touching more distinct pages, or touching them in a less
   local order, raises the fault count even at constant total memory.
6. **Page-cache mapping churn.** Repeatedly `mmap`ing/`munmap`ing files, or re-mapping the same file,
   generates minor faults each time even though the data stays cached.

**Why `Concerning` (−1) is right.** A minor fault does not block on I/O, so a 20% increase is a hint about
CPU cost and memory behaviour, not evidence of a stall. The impact is bounded and shows up as `system` CPU
time. **The finding earns its place by being an early, sensitive indicator** — it moves before major faults
do, so a rise here alongside a rise in majors tells you the working set grew past cache capacity, and a rise
here *alone* tells you the change is confined to allocation behaviour.

**Why the rule is directional.** `abs: false` means a decrease is silent. That is a deliberate asymmetry —
fewer minor faults is generally better (`desired: "lower"`) — but it also means **a large *drop* is
invisible**, and drops are informative: they can mean huge pages started working, or that an allocator
began retaining memory, or that the workload did less. If you are comparing runs, read the metric directly
rather than relying on the finding to tell you it moved.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run_name} ({value}) is {delta_ratio_string} {base_run_name} ({base_value}).
```

Both placeholders are **run names**, not metric names. Example:

```
The average in run_b (1.42M) is 34.60% greater than run_a (1.05M).
```

Four things to know:

1. **Values use K/M/G/T suffixes** (`formatted_number_string`) and are **truncated**, not rounded, to two
   decimals. `1.42M` is anything from 1,420,000 to 1,429,999.
2. **The ratio and the score agree in direction here.** Unlike the `abs: true` rules, `abs: false` means the
   ratio used for the comparison, the score, and the description are the same signed number — and the rule
   only fires when it is positive. So the description will always say `greater than`.
3. **`equal to`** cannot appear; equal stats give ratio 0, which does not satisfy `>= 0.2`.
4. **If the base-run average is 0, the ratio is substituted with `1.0`** ("treat the current stat as 100%
   larger"), regardless of the current value. `100.00% greater than run_a (0)` therefore means **the base run
   recorded no minor faults at all** — which for this metric almost certainly means the derivation failed
   there (a missing `pgfault` or `pgmajfault`), not that the system took zero faults. Treat it as a data
   problem, not a 2× regression.

Score math — `compute_finding_score(ratio, 0.2, −1)`, general branch, `delta = ratio/0.2`:

| ratio | meaning | score |
|---|---|---|
| 0.20 | 20% more — fires (`GreaterEqual`) | **−1.00** |
| 0.25 | 25% | −1.25 |
| 0.30 | 30% | −1.50 |
| 0.50 | 50% | −2.50 |
| 1.00 | 2×, **or base run = 0** | −5.00 |
| 2.00 | 3× | −10.00 |
| 5.00 | 6× | −25.00 |
| 10.00 | 11× | −50.00 |

**The score is linear in the ratio and starts at −1.00**, so it is the *lowest-magnitude* scoring family in
aperf. A 10× increase still scores only −50 — less than a single `Poor` finding at −16 would suggest, and
two orders of magnitude below the run-comparison rules that use `Critical`. That is proportionate: minor
faults cost CPU, not stalls.

Practical consequence: **this finding will sit near the bottom of a score-ordered list even when the ratio
is large.** Read the ratio in the description, not the score, to judge how much the workload changed.

## Interpretation

**First, decide whether the increase is the point of the experiment:**

| Observation | Reading |
|---|---|
| The change under test allocated more memory | **The increase is the intended effect.** A larger cache, buffer pool, or batch size *should* raise minor faults. Not a defect |
| Ratio just at 20% | The tripwire. Check sample count and phase mix before treating it as real |
| Ratio very large (5×, 10×) | Something structural changed — most likely huge pages, the allocator, or process count. Go to the THP check |
| Base value shown as **`0`** | **Suspect a derivation failure in the base run**, not a real zero. `pgminorfault` requires both `pgfault` and `pgmajfault` in the same snapshot |

**Then localize — these four checks cover almost every real cause:**

| Evidence | Reading |
|---|---|
| **`thp_fault_fallback` up**, `thp_collapse_alloc` down | **Huge pages stopped working.** One THP fault covers 512 base pages, so losing THP multiplies the fault count for identical memory. A real regression with a clear fix. Read manually — no rule fires on these |
| `Huge Page Disabled` fired in one run only | Same cause, config-level: THP is not compiled in. See that playbook |
| `nr_anon_pages` up proportionally | **More anonymous memory** — the workload genuinely allocated more. Usually the benign explanation |
| `nr_anon_pages` flat while faults rose | **Same memory, more faults** — allocator churn or mapping churn, not growth. The most interesting case |
| Process/thread count up | `fork`-heavy work; new address spaces and copy-on-write resolution generate minor faults in proportion. Check `processes` |
| `system` CPU up in step | **The cost is real and measurable.** This is where minor-fault overhead lands. If `system` did not move, the increase is not costing much |
| `pgfault` up but `pgmajfault` flat | The increase is **entirely** minor — a memory-behaviour change with no I/O consequence. The good case |
| `pgmajfault` also up | The working set grew past what the page cache can hold. See `Increased Major Page Faults` — that is the finding that matters |
| `MemAvailable` down | More memory in use; consistent with genuine allocation growth. See `Reduced Memory Availability` |
| `compact_stall` up | Fragmentation is forcing compaction — often the reason THP allocation started failing |
| `pgactivate`/`pgdeactivate` shifted | LRU churn changed; the access pattern is different, not just the volume |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Increased Major Page Faults` | **Read that one first.** Majors block on storage; minors do not. A rise in both means the working set outgrew the cache |
| `Excessive Page Fault Rate` | The absolute rate is also very high — the increase landed on top of an already-heavy fault load, so the CPU cost is material |
| `Major Page Faults Detected` | Majors exist in this run. Combined with rising minors, look at whether the memory growth pushed past cache capacity |
| `Reduced Memory Availability` | Consistent with genuine allocation growth |
| `Inconsistent Physical Memory` or `Inconsistent Number of CPUs` | **The runs are not comparable.** Fix those first — different RAM or CPU count changes fault behaviour by construction |
| `Huge Page Disabled` | If it fired in only one run, that alone can explain a multi-fold increase |
| `Underutilized CPU` | Minor faults do not idle the CPU; if both fired, they have different causes |
| High `system` CPU with no other explanation | Fault handling and page zeroing are plausible contributors at high rates |

**Known false positives — most firings:**

- **The change under test allocated more memory.** The most common cause and usually intended.
- **Different run lengths or phase mix.** `Stat::Average` is a mean of per-interval deltas — a rate — so
  duration alone should not move it, but a long idle startup or a truncated teardown dilutes or concentrates
  the mean.
- **Different process/thread counts** between runs, including test-harness differences.
- **A base run with a failed derivation** showing 0 and triggering the ratio-1.0 substitution.
- **Short runs.** The first interval is 0 and few samples make a noisy mean.
- **Co-tenant activity.** `vmstat` is system-wide; another process can move the number.
- **An allocator or runtime version change** between runs — a real cause, but not an application defect.
- **The base run is the wrong baseline.** aperf picks it by ordering, not by intent.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `pgmajfault`, and whether `Increased Major Page Faults` fired | `vmstat` | **Do this first.** Majors are the ones that block on storage. If they moved too, that is the finding to work |
| **`pgfault` and `pgmajfault` skip warnings in the aperf log** | `aperf_stats` / log | **Whether the derived series has holes.** A dropped delta in either operand silently removes this interval. **No rules fire — read manually** |
| `thp_fault_fallback`, `thp_collapse_alloc`, `thp_deferred_split_page` | `vmstat` | **The multiplier check** — losing THP raises the fault count up to 512× for the same memory. **No rules fire** — read manually |
| `nr_anon_pages` | `vmstat` | Whether anonymous memory actually grew (real allocation) or stayed flat (churn). A gauge, added with `add_data_point` |
| `pgfault` | `vmstat` | The total, and how much of it is minor. See `Excessive Page Fault Rate` |
| `compact_stall`, `htlb_buddy_alloc_success` | `vmstat` | Fragmentation pressure — often why THP allocation began failing |
| `pgactivate`, `pgdeactivate`, `pgrefill` | `vmstat` | Whether the LRU/access pattern changed, not just the volume |
| `pgsteal_*`, `pgscan_*` | `vmstat` | Reclaim activity — mapping churn under pressure produces both |
| `pswpin`, `pswpout` | `vmstat` | Should be zero here; non-zero moves the investigation to `Major Page Faults Detected` |
| `MemAvailable`, `MemFree`, `Cached`, `AnonPages` | `meminfo` | Whether the memory footprint grew. See `Reduced Memory Availability` |
| `MemTotal` | `meminfo` | **Whether the runs are comparable at all.** See `Inconsistent Physical Memory` |
| `system`, `user`, `aggregate` | `cpu_utilization` | **Where minor-fault cost lands.** If `system` did not move, the increase is not expensive |
| Process/thread count, top memory consumers | `processes` | Whether the runs ran the same set of processes. **No analytical rules — read manually** |
| `CONFIG_TRANSPARENT_HUGEPAGE` | `kernel_config` | Whether THP is available at all. See `Huge Page Disabled` |
| THP enablement (`/sys/kernel/mm/transparent_hugepage/enabled`), `vm.*` tunables | `sysctl` / out of band | Runtime THP mode and reclaim tuning. **No analytical rules for `sysctl` — read manually** |
| Allocator, runtime, and library versions | out of band | An allocator change moves this metric substantially with no application change. aperf does not collect this |
| Run duration, sample count, `--interval`/`--period` | run metadata / `aperf_stats` | Whether the means rest on comparable sampling. **No analytical rules — read manually** |
| On-CPU profile in both runs | `perf_profile` | Fault-handling and page-zeroing frames; also allocator frames. Requires `--profile`. **No analytical rules** |
| `Kernel Version`, `CPUs` | `systeminfo` | Comparability. See `Kernel Version Mismatch`, `Inconsistent Number of CPUs` |
| Base page size (`getconf PAGESIZE`) in both runs | out of band | **Not collected.** A 4 KiB→64 KiB change divides the fault count by 16 for identical memory |

## Guidance

Ordered. **This finding is a lead, not a verdict — spend proportionate effort on it.**

1. **Check whether `Increased Major Page Faults` also fired.** If it did, **work that finding instead**.
   Major faults block on storage; minor faults cost microseconds of CPU. A rise in both means the working
   set outgrew the page cache, and the major-fault side is where the latency is.

2. **Ask whether the increase is the intended effect of the change under test.** A larger cache, buffer
   pool, batch size, or thread count *should* raise minor faults. If the change added memory on purpose,
   this finding is confirming it worked — not reporting a defect.

3. **Read the ratio from the description, not the score.** The score family here starts at −1.00 and reaches
   only −50 at an 11× increase, so it will sit near the bottom of a score-ordered list regardless. The ratio
   is the real magnitude.

4. **Check for a base value of `0`.** That triggers the ratio-1.0 substitution and, for this derived metric,
   almost certainly means the derivation failed in the base run (a missing `pgfault` or `pgmajfault`) rather
   than a true zero. Verify before treating it as a 2× regression.

5. **Check huge pages — the one cause that can explain a multi-fold jump.** Compare `thp_fault_fallback` and
   `thp_collapse_alloc` across the runs, and check whether `Huge Page Disabled` fired in only one. **One THP
   fault covers 512 base pages**, so losing THP multiplies the fault count for identical memory. Look at
   `compact_stall` too: fragmentation is the usual reason THP allocation starts failing.

6. **Separate growth from churn.** Compare `nr_anon_pages`:
   - **Up proportionally** ⇒ the workload genuinely allocated more. Usually benign; see step 2.
   - **Flat while faults rose** ⇒ **same memory, more faults**. That is allocator or mapping churn —
     memory being returned to the kernel and re-faulted, or files being repeatedly mapped. Check for an
     allocator, runtime, or `malloc_trim`/arena configuration change between the runs.

7. **Check process and thread counts.** `fork`-heavy workloads generate minor faults in proportion to
   process creation, and copy-on-write resolution adds more. A test-harness difference can account for the
   whole delta.

8. **Quantify the cost before acting.** Look at `system` CPU in both runs. **If `system` CPU did not move,
   the increase is not costing anything measurable** and the finding is informational. If it did, the
   fault-handling and page-zeroing overhead is real and worth reducing.

9. **Confirm the runs are comparable.** Check `MemTotal`, `CPUs`, and `Kernel Version`. If
   `Inconsistent Physical Memory`, `Inconsistent Number of CPUs`, or `Kernel Version Mismatch` fired, fix
   those first — fault behaviour is not comparable across different memory sizes or kernels.

10. **Rule out sampling and phase artifacts.** Short runs, differing `--interval`/`--period`, a long idle
    startup, or a truncated teardown all move the mean. Compare the series *shape*, not just the average.
    Check the aperf log for skipped data points on `pgfault`/`pgmajfault` — those silently hole this series.

11. **Remember the rule is directional.** A large *decrease* is invisible to it. If you are looking for what
    changed between runs, read `pgminorfault` directly in both.

## Priority and execution risk

**Priority: P4 — Informational** for the majority of firings, and the reasoning is not laziness: the metric
is derived, the score family bottoms out at −1.00, minor faults cost `system` CPU rather than latency, and
the most common cause is that the change under test allocated more memory on purpose. It rises to
**P3 — Monitor** when the ratio is large and `system` CPU moved with it — real, bounded, kernel-side cost
worth reducing. **P2 — Investigate** when `nr_anon_pages` is flat while the faults rose, which means the
same memory is being faulted more often: allocator or mapping churn, a genuine efficiency loss with no
compensating benefit. It reaches **P1 — Act now** in one case only: `thp_fault_fallback` rising with
`thp_collapse_alloc` falling, because the 512× multiplier makes a lost-THP regression a real cost the
workload did not ask for and can get back with one write. If `Increased Major Page Faults` also fired, **that
finding's priority governs** and this one is context.

**Execution risk: R0 — Read-only** for the whole diagnosis; the THP counters, `nr_anon_pages`, `system` CPU,
and the comparability findings are all already in both reports. Acting ranges from **R1** (set THP to
`always` or `madvise` — one write, instantly revertible) through **R2** (allocator or runtime configuration
needing a restart: `MALLOC_TRIM_THRESHOLD_`, `M_ARENA_MAX`, `-XX:+AlwaysPreTouch`, a jemalloc/tcmalloc
switch) to **R3** (restructuring allocation or mapping patterns in the application). **R4** does not apply —
resizing an instance does not reduce minor faults, since they are not a capacity symptom.

**What the score is worth: read it only to recover the ratio.** `time_series_stat_run_comparison` amplifies,
so `compute_finding_score` makes the score exactly `ratio / 0.2 × −1` and `ratio = |score| × 0.2` inverts it.
But the base of −1 puts an 11× increase at −50, below a *single* `Poor` finding's −16 per unit ratio, so
**the score is useless for cross-rule ranking and will bury this finding in any score-ordered list.**
Note the score does not distinguish a real 2× from the zero-base substitution: both are −5.00.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `delta_avg(pgminorfault) >= 0.2` versus the base run — two runs required, and this run is
not the base.

```
STEP 0 — Is the derived metric intact in BOTH runs?
  pgminorfault = pgfault_delta - pgmajfault_delta, emitted only when both exist.
  IF the base value prints as 0
  THEN → almost certainly a DERIVATION FAILURE in the base run, rendered as
         "100.00% greater" by the zero-base substitution. Not a 2x regression
         (P4, R0)
       → read pgfault and pgmajfault directly in the base run to confirm
  IF the aperf log carries "skipped N data points due to unexpected decrease"
     for pgfault or pgmajfault in either run
  THEN → this series has SILENT holes: the log names the operand, never the
         derived metric. The two means may cover different interval subsets
         (P3, R0)
       → compare the surviving sample counts before trusting a marginal ratio
  ELSE both series are intact. Continue to STEP 1.

STEP 1 — Is there a major-fault finding to work instead?
  IF `Increased Major Page Faults` also fired
  THEN → majors block on STORAGE; minors cost microseconds of CPU. A rise in
         both means the working set outgrew the page cache (P2, R0)
       → increased-major-page-faults.md, see that playbook
  IF `Major Page Faults Detected` fired in this run
  THEN → majors exist. Check whether the memory growth pushed past cache
         capacity before treating the minor rise as the subject (P3, R0)
       → major-page-faults-detected.md, see that playbook
  ELSE the increase is entirely minor: a memory-behaviour change with no I/O
       consequence. The good case. Continue to STEP 2.

STEP 2 — MANDATORY manual check: are the runs comparable at all?
  IF `Inconsistent Physical Memory` or `Inconsistent Number of CPUs` fired
  THEN → different RAM or vCPU count changes fault behaviour by construction.
         The ratio is not attributable to the change under test (P1, R0)
       → ../meminfo/inconsistent-physical-memory.md, see that playbook
  IF `Kernel Version Mismatch` fired
  THEN → fault accounting, THP defaults and reclaim heuristics all differ across
         kernels. Treat the ratio as CONFOUNDED (P2, R0)
  IF the base page size differs between the runs (getconf PAGESIZE, out of band)
  THEN → a 4 KiB->64 KiB change divides the count by 16 for identical memory.
         aperf collects no page size, so nothing catches this (P2, R0)
  ELSE continue to STEP 3.

STEP 3 — Huge pages: the only cause that explains a multi-fold jump.
  One 2 MiB THP fault covers 512 base pages.
  IF thp_fault_fallback rose and thp_collapse_alloc fell, with compact_stall up
  THEN → THP allocation is failing to FRAGMENTATION. The workload pays up to
         512x the faults for identical memory and did not ask for it (P1, R1)
       → set /sys/kernel/mm/transparent_hugepage/enabled to always, or reduce
         fragmentation; one write, instantly revertible
       → verify: thp_fault_fallback falls, thp_collapse_alloc rises, and the
         pgminorfault average returns toward the base run's
  IF `Huge Page Disabled` fired in ONE run only
  THEN → THP is not compiled in there. Config-level, same 512x mechanism, and it
         alone can account for the whole ratio (P2, R0)
       → ../kernel_config/huge-page-disabled.md, see that playbook
  ELSE THP is not the explanation. Continue to STEP 4.

STEP 4 — Growth or churn? Compare nr_anon_pages across the runs.
  IF nr_anon_pages rose roughly in proportion to the fault ratio
  THEN → the workload GENUINELY ALLOCATED MORE. If the change under test added a
         cache, buffer pool, or batch size, this finding is confirming it worked
         (P4, R0)
  IF nr_anon_pages is FLAT while the faults rose
  THEN → SAME MEMORY, MORE FAULTS: allocator or mapping churn. Memory returned
         to the kernel and re-faulted, or files repeatedly mapped. A real
         efficiency loss with no compensating benefit (P2, R2)
       → raise MALLOC_TRIM_THRESHOLD_ / M_ARENA_MAX, stop the allocator
         returning memory, or reuse mappings; restart-only and revertible
       → verify: the pgminorfault average falls toward the base run's with
         nr_anon_pages unchanged, and system CPU falls with it
  IF process or thread count rose between the runs
  THEN → fork-heavy work: new address spaces plus copy-on-write resolution
         generate minor faults in proportion. A harness difference can account
         for the whole delta (P4, R0)
       → confirm in `processes`, which has no rules of its own
  ELSE continue to STEP 5.

STEP 5 — Did the cost materialize, and is it worth reducing?
  IF system CPU did not move between the runs
  THEN → the increase is NOT costing anything measurable. This is a complete
         resolution and the most common one (P4, R0)
  IF system CPU rose in step with the fault rate
  THEN → real, bounded, kernel-side cost: trap handling plus page zeroing
         (P3, R3)
       → reduce allocation churn at the source: pool short-lived buffers,
         amortize per-request allocation, make large allocations THP-eligible
       → verify: system CPU and the pgminorfault average fall together at
         unchanged throughput; if throughput falls too, the churn was useful
  IF `Excessive Page Fault Rate` also fired
  THEN → the increase landed on an already-heavy absolute load, so the CPU cost
         is material even at a modest ratio (P3, R0)
       → excessive-page-fault-rate.md, see that playbook
  ELSE → the ratio is real but uncosted and unexplained. Record it and move on
         (P4, R0)

STEP 6 — What survives?
  VALID  : every other finding in the report. This rule reads one derived metric
           and contaminates nothing
  VALID  : the ratio AS a change signal, recoverable exactly as |score| x 0.2
  VALID  : the conclusion "no I/O consequence" when pgmajfault is flat
  CAUTION: any ratio computed over series with logged skip warnings on pgfault or
           pgmajfault — the two means may cover different intervals
  CAUTION: the ratio when `Kernel Version Mismatch` fired, or when the base page
           size differs
  CAUTION: reading the increase as a defect when the change under test added
           memory deliberately
  VOID   : "100.00% greater than <base> (0)" as a 2x regression. It is the
           zero-base substitution over a failed derivation
  VOID   : the score as a severity ranking. It reaches only -50 at 11x, below
           every Poor finding in the report
  VOID   : any claim that minor faults were UNCHANGED from this rule's silence.
           abs: false makes decreases invisible, however large

INSUFFICIENT DATA
  IF either run has fewer than ~5 usable samples
  THEN → the first interval is 0 by construction and the mean rests on a handful
         of noisy deltas. A 20% ratio is not distinguishable from sampling
         (P4, R1)
       → re-record both runs with a longer --period
       → verify: on the longer runs either the ratio holds (real) or it collapses
         below 0.2 (sampling)
  IF the report has only one run
  THEN → the rule COULD NOT FIRE; it needs a base run. Silence proves nothing
         (P4, R0)
  IF pgfault or pgmajfault is absent in either run
  THEN → the derived metric does not exist there, so nothing comparable is
         available (P4, R0)
```

## Runtime-specific consequences

Minor faults are generated almost entirely by the runtime's allocator and by process creation, so **the
runtime determines the baseline rate and the levers**. Application code rarely faults directly; it asks the
allocator for memory and the allocator decides whether that becomes a fault. Runtime is not reported by
aperf — infer it from `processes` ([../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) §1.3) and treat the
inference as a hint.

| Runtime | Why the rate moves between runs | What to check, and the lever |
|---|---|---|
| **Java** | A heap that grows during the run faults in each new region on first use, and a compacting collector re-touches pages after every move. A GC change (Parallel→G1→ZGC) alters the fault pattern with no application change at all | Compare `-Xms`/`-Xmx` and the collector across runs; `-XX:+AlwaysPreTouch` moves the faults into startup so the steady-state comparison is clean; `-XX:+UseTransparentHugePages` recovers the 512× reduction (P2, R2) |
| **.NET** | Server GC allocates one heap per core, so **a vCPU-count difference alone changes the fault rate** — exactly the case `Inconsistent Number of CPUs` gates. Gen0 budget sets the churn frequency | `DOTNET_GCgen0size` to enlarge gen0, `DOTNET_gcServer` to fix the heap count across runs so the comparison is apples to apples (P2, R2) |
| **Python** | pymalloc **returns empty arenas to the kernel**, so the same address space is re-faulted repeatedly — the purest form of the STEP 4 churn case. Preforking workers add COW resolution proportional to recycling frequency | `PYTHONMALLOC=malloc` hands arena policy to glibc, then `MALLOC_TRIM_THRESHOLD_`; raise the requests-per-worker limit to recycle less often (P2, R2) |
| **Perl** | Long-lived interpreters retain their arenas, so the steady-state rate is genuinely low and stable — which makes a 20% move here more likely to be real than in the other runtimes. Preforking servers are the exception, via COW | Compare worker counts and recycling limits before anything else; `perl -V` build options matter more than runtime flags (P3, R2) |

**When the runtime cannot be established**, STEP 4 is still the right discriminator: flat `nr_anon_pages`
with rising faults is churn regardless of language, and the allocator is where to look.

## Architecture-specific considerations

**Base page size divides the fault count, and aperf does not collect it.** Every fault maps one page, so the
same first-touch volume costs 16× fewer faults on a 64 KiB-page kernel than on a 4 KiB one. For a
*comparison* rule this is more dangerous than for a threshold rule: **two runs on different kernels can show
a 16× ratio with identical memory behaviour**, and `Kernel Version Mismatch` will not necessarily fire if
both kernels report the same version string from different builds. aarch64 ships 4 KiB on Amazon Linux and
Ubuntu arm64, 64 KiB on the RHEL family; x86_64 is always 4 KiB. Capture `getconf PAGESIZE` per run out of
band; confirm the architecture from `pmu_config.json` ([../ARCHITECTURE.md](../ARCHITECTURE.md) §1).

| Observed | Reading | Action |
|---|---|---|
| Ratio near 16× between an x86_64 base and an aarch64 run, or the reverse | Suspect the **page-size divisor** before any application cause. The PMD huge page also changes size (512 × base) | Capture both page sizes; compare bytes faulted, not fault counts (P2, R0) |
| Ratio elevated **after an Intel→Graviton migration** | **No aperf gate fires on this** ([../GATES.md](../GATES.md)). Default thread stacks are 2 MB on aarch64 vs 1 MB on x86_64 ([../ARCHITECTURE.md](../ARCHITECTURE.md) §4.1), and with THP `always` the full 2 MB can be committed — more first-touch per thread | Set THP to `madvise` or tune `-Xss`; compare `AnonPages` across runs first (P2, R2) |
| Ratio elevated with `Old-Style Atomic Instructions` or `Reduced Instructions per Cycle` | A generic or emulated arm64 build; the allocator was likely rebuilt too, so churn behaviour changed with it | See [../ARCHITECTURE.md](../ARCHITECTURE.md) §5 (P2, R3) |
| Ratio elevated on the same architecture and kernel | The page-size and THP-size confounds are excluded. The ratio is attributable | Proceed to STEP 4 with confidence (P3, R0) |

**Same-architecture, same-kernel comparison is the only configuration in which this ratio is cleanly
attributable.** Anything else needs the page size captured out of band, and aperf has no field for it.

## Verification

**Predict before you check.** If the cause is lost THP, predict that `thp_fault_fallback` is elevated in this
run *and not* in the base, and that restoring THP returns the average to within noise of the base run — a
partial recovery means only some of the allocation was THP-eligible, which is a size-and-alignment question,
not a THP one. If the cause is allocator churn, predict that the average falls **while `nr_anon_pages` stays
flat** and `system` CPU falls with it; if `nr_anon_pages` moves too, you changed the footprint rather than
the churn. If the cause is genuine allocation growth, predict that nothing you do to the allocator helps and
that `nr_anon_pages` scales with the ratio — at which point the correct outcome is to accept the finding. And
if the base value was `0`, verification starts by reading `pgfault` and `pgmajfault` directly in the base
run: a derivation failure cannot be fixed by tuning anything.

## Do not

- **Do not treat this as a latency problem.** Minor faults are resolved in memory and cost microseconds.
  The cost is `system` CPU time, not stalls.
- **Do not work this finding before `Increased Major Page Faults`** if both fired. Majors block on storage.
- **Do not read the score as magnitude.** It starts at −1.00 and reaches only −50 at 11×; read the ratio in
  the description.
- **Do not read `100.00% greater than <base> (0)` as a 2× regression.** It is the base-stat-zero
  substitution, and for this derived metric a zero base usually means the derivation failed.
- **Do not forget the metric is derived.** `pgminorfault = pgfault − pgmajfault`, computed per interval; if
  either input is missing or its delta is skipped, no value is emitted for that interval — silently.
- **Do not assume more faults means more memory.** Flat `nr_anon_pages` with rising faults is churn, not
  growth — a completely different cause.
- **Do not overlook huge pages.** Losing THP can multiply the fault count for identical memory by up to 512.
- **Do not act without checking `system` CPU.** If the cost did not materialize, there is nothing to fix.
- **Do not compare runs with different `MemTotal`, CPU count, kernel, or base page size.** The first three
  have findings; the fourth aperf does not collect at all.
- **Do not rely on this rule to detect a decrease.** `abs: false` makes it one-directional.
- **Do not blame the application without checking `processes`.** `vmstat` is system-wide.
- **Do not assume the base run is the correct baseline.** aperf picks it by ordering, not by intent.

## References

- Rule: `src/analytics/rules/vmstat.rs:24` — `time_series_stat_run_comparison!` with
  `metric: "pgminorfault"`, `stat: Stat::Average`, `comparator: Comparator::GreaterEqual`,
  `threshold: 0.2`, `abs: false`, `Score::Concerning`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — base run from
  `get_base_run_name()`, **early `return` with a `debug!` if the base run lacks the metric**, `continue` if
  the current run lacks it; `original_delta_ratio = 0.0` if equal, **`1.0` if the base stat is 0**
  ("treat current stat as 100% larger"), else `(cur − base)/base`; with `abs: false` the comparison, score,
  and description all use the same signed ratio.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Concerning = −1`,
  `src/analytics/mod.rs:147`. Threshold is non-zero, so the general branch applies.
- Formatting: `delta_ratio_to_percentage_string` and `formatted_number_string`,
  `src/computations/mod.rs:162` and `:176` — K/M/G/T suffixes, values **truncated** to 2 decimals.
- **Derivation:** `src/data/vmstat.rs` computes `pgminorfault = pgfault_delta − pgmajfault_delta` per
  interval and adds it with plain `add_data_point`; it is emitted only when **both** input deltas are
  `Some`. There is no `pgminorfault` field in `/proc/vmstat`.
- Delta processing: `nr_*` metrics via `add_data_point` (gauges), all others via
  `add_accumulative_data_point`; first sample forced to 0
  (`ignore_first_accumulative_value: true`, `src/data/common/time_series_data_processor.rs:73`), decreasing
  samples `return None` at `:214` and are counted in `decreasing_accumulative_data` with a `debug!` per
  occurrence plus an end-of-collection warning.
- Aggregation: `time_series_data_processor_with_custom_aggregate!`; one `values` series per metric, so no
  auto-generated `average` series and no fractional values.
- Default sampling: `--interval 1`, `--period 10` (`src/record.rs:35`, `:45`).
- Metric semantics: `pgminorfault`, `pgfault`, `pgmajfault`, `thp_fault_fallback`, `thp_collapse_alloc`,
  `nr_anon_pages`, `compact_stall` in `src/report_frontend/src/definitions/data-descriptions.ts`
  (`vmstat` block). **No `vmstat` metric carries an `optimization` guide**, so aperf offers no upstream
  remediation text for this finding.
- Related playbooks: `increased-major-page-faults.md`, `major-page-faults-detected.md`,
  `excessive-page-fault-rate.md`, `../meminfo/reduced-memory-availability.md`,
  `../meminfo/inconsistent-physical-memory.md`, `../kernel_config/huge-page-disabled.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`, `../systeminfo/kernel-version-mismatch.md`.
- [Linux memory concepts — page faults](https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html#page-faults)
- [proc_vmstat(5)](https://www.man7.org/linux/man-pages/man5/proc_vmstat.5.html)
- [Transparent Hugepage Support](https://www.kernel.org/doc/html/latest/admin-guide/mm/transhuge.html)
- [glibc malloc tunables](https://www.gnu.org/software/libc/manual/html_node/Memory-Allocation-Tunables.html)
