---
rule_name: ENA Express Enabled with UDP
data_type: ena_stat
data_key: ena_srd_mode
template: time_series_data_point_threshold
condition: "any(ena_srd_mode) == 3.0"
base_score: Good
score_sign: positive
requires_comparison: false
aperf_message: "ENA Express is enabled for both TCP and UDP."
source: src/analytics/rules/ena_stat.rs:80
---

# ENA Express Enabled with UDP

## What fired

**At least one** data point of `ena_srd_mode` was **equal to 3.0** — read literally, "ENA Express on,
UDP on": SRD is accelerating both TCP and UDP traffic.

Base score `Good` (**+2**), **positive**. Single-run rule, `Comparator::Equal` (`ena_stat.rs:80`). With
an `Equal` comparator the score is **always exactly +2.00**.

This is the **only positive-scoring rule in the entire `ena_stat` family** — one of very few in all of
aperf. It is a confirmation, not a problem: nothing needs fixing when it fires. **But it is effectively
unreachable on aperf 1.3.0, and its absence is not evidence of anything.** Read the next section first —
this rule's practical importance is almost entirely about what its *silence* does and does not mean.

## The processing defect — verified by running the engine

`ena_srd_mode` is a **mode enum** (0/1/2/3), but every `ena_stat` metric is passed through
`add_accumulative_data_point` at `src/data/ena_stat.rs:343`, which stores **per-interval differences**
and forces the first sample to 0 (`ignore_first_accumulative_value: true`,
`time_series_data_processor.rs:73`; the only opt-out in the tree, `use_first_accumulative_value()`, is
called once, from `perf_stat.rs:1295`). A mode does not accumulate, so a device sitting in the ideal
mode 3 reports raw `3, 3, 3, …` and aperf stores `[0.0, 0.0, 0.0, …]`.

**Verified by running the real rule engine**: a device with a constant `ena_srd_mode = 3` produced a
series of `[0.0, 0.0]` and emitted the finding **`Disabled ENA Express`** with score **`−1.0`** and the
description `At least one data point in aperf_record is 0 (equal to the threshold of 0)`.

So on aperf 1.3.0:

| device state | raw samples | series aperf stores | finding produced |
|---|---|---|---|
| ENA Express **on, UDP on** — the ideal state | 3, 3, 3, … | `[0.0, 0.0, 0.0, …]` | **`Disabled ENA Express`**, score **−1.0** |

**The best possible configuration is reported as a negative finding, and this positive rule never
fires.** That is the inversion, and it is the single most useful thing to know about the `ena_srd_mode`
rule family.

The only way this rule *can* fire is a **delta of exactly 3**, i.e. `0 → 3`: ENA Express being switched
on with UDP support, from fully off, during the recording. That is the one mode transition where the
message's conclusion happens to be right about the end state — but it describes a configuration change
mid-run, not a steady state. **And only an increase can do it**: a decreasing sample is dropped
entirely (`get_delta_and_set_previous_value` returns `None` at `time_series_data_processor.rs:214`, and
`add_data_point_impl` returns early at `:150`), so no `3 → 0` or `3 → 1` transition ever writes a data
point. aperf emits exactly one `warn!` about it at the end of processing (`:297`–`:302`):

```
<data_name>.<metric>.<series>: skipped N data points due to unexpected decrease of accumulative data.
```

Two further observable artifacts. **A constant mode renders as exactly two data points**:
`compress_all_zero_time_series_metric` (`:410`–`:427`) compresses every series to its first and last
point when the metric's min and max are both 0.0, which all-zero deltas guarantee. So a two-point
`ena_srd_mode` chart is a positive signal that the mode never changed — and therefore that this rule
*could not* have fired. And **the `average` series may not exist**: `ena_stat` aggregates with
`time_series_data_processor_with_average_aggregate` (`ena_stat.rs:315`), but `:312`–`:319` removes the
auto-generated aggregate when there are exactly two series, so the cross-interface mean only appears
with **three or more** series.

**Two practical consequences:**

1. **Absence of this finding is not evidence that ENA Express is off.** It is the expected outcome even
   on a perfectly configured instance.
2. **Presence of this finding means the mode stepped from 0 to 3 during the recording** — so the run
   spans a configuration change, and metrics before and after the step are not comparable.

The rest of this playbook covers what to do with the finding when the device genuinely is in mode 3 —
which is mostly verification, since there is nothing to remediate.

## Reasoning

`ena_srd_mode` "Indicates whether ENA Express is configured. 0 = ENA Express off, UDP off; 1 = ENA
Express on, UDP off; 2 = ENA Express off, UDP on (only happens after disabling the previously enabled
ENA Express with UDP); 3 = ENA Express on, UDP on." (`data-descriptions.ts:3859`, `desired: "fixed"`)

Mode 3 is the fully-enabled state. ENA Express is powered by **SRD** (Scalable Reliable Datagram), the
transport also used by EFA, and it provides:

- **Multipath / dynamic routing** — packets are sprayed across many network paths instead of being
  pinned to one flow-hashed path, so a single congested or degraded path cannot throttle a connection.
- **Much lower tail latency** — the largest and most reliable benefit. p99/p99.9 improves far more than
  the mean, because SRD routes around transient congestion rather than waiting for TCP recovery.
- **Higher single-flow throughput** — lifting the one-path ceiling that limits a single TCP flow on
  standard ENA.

In mode 3 both TCP and UDP get this treatment. Reaching mode 3 requires two deliberate settings (ENA
Express itself, then UDP support), on **both endpoints**, in the **same Availability Zone** — so the
rule is really acknowledging that someone did the work.

**Why a positive finding is worth having at all.** aperf's findings list is overwhelmingly negative, and
a positive entry serves two purposes: it confirms an intended optimization is actually in effect at
recording time (not just in the launch template), and it stops a reviewer from "recommending" something
already enabled. That is the whole job of this rule.

**What it does *not* claim** — and this is where over-reading it is easy:

- **It does not mean SRD is actually carrying your traffic.** Mode 3 is configuration, not behaviour.
  Packets over the **SRD MTU limit of 8900** fall back to standard ENA; so do packets when the network
  card's SRD resources are exhausted, and during live migrations or live server updates — the three
  fallback causes upstream names in `ena_srd_eligible_tx_pkts`. The metrics that show whether SRD is
  *working* are `ena_srd_tx_pkts` versus `ena_srd_eligible_tx_pkts`, and
  `ena_srd_resource_utilization` — see `Low SRD Usage Rate` and `High SRD Resource Utilization`.
- **It does not mean the network is healthy.** ENA Express does not raise the bandwidth, PPS,
  connection-tracking, or link-local allowances. All four can be breached in mode 3.
- **It does not mean UDP acceleration is helping.** SRD sprays packets across paths, and for UDP there
  is no transport layer restoring order, so reordering is exposed directly to the application. An
  application that assumes near-ordered UDP delivery can behave *worse* in mode 3 than in mode 1.
- **It is not a claim about cross-AZ or internet traffic**, which cannot use ENA Express regardless of
  the setting.

**And aperf ships no guidance for any of this.** `optimization-guides.ts` contains only the four EC2
network *allowance* guides (`:117`, `:125`, `:134`, `:146`); there is **no ENA Express or SRD guide**, so
everything below comes from the metric descriptions and AWS documentation.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"equal to"`:

```
At least one data point in aperf_record is 3 (equal to the threshold of 3).
```

**The value carries no information** — with `Equal` it is always the threshold. And per the defect
above, that `3` is a **delta between consecutive mode samples**, not the mode itself.

Score math — `compute_finding_score(3.0, 3.0, +2)`, the general branch: `delta = 3/3 = 1`, so
`score = 1 × +2`:

| value | score | note |
|---|---|---|
| 3.0 (the only possible value) | **+2.00** | positive; sorts at the opposite end of the list |

**Always +2.00**, and **positive** — so in a score-ordered list (ascending, `analytics.tsx:40`) it sorts
last, away from every other `ena_stat` finding. Note that `Good` (+2) is not aperf's top positive score;
`Great` is +16 and `Optimal` is +256, neither of which any `ena_stat` rule uses.

## Interpretation

**If the finding is present**, the mode stepped `0 → 3` during the recording:

| Observation | Reading |
|---|---|
| Finding present | ENA Express with UDP was **switched on mid-recording**. The end state is correct, but the run **spans a configuration change** — metrics before and after the step are not comparable. Locate the step in the series |
| Finding absent | **Says nothing.** This is the expected outcome on 1.3.0 even in mode 3. Do not infer that ENA Express is off |
| `Disabled ENA Express` present instead | **The normal case for a mode-3 instance.** The inversion described above. Verify the real mode out of band |
| `ena_srd_mode` chart shows exactly **two** points | The all-zero compression fired (`:410`–`:427`): the mode was constant, so this rule **could not** have fired |

**Whether SRD is actually doing anything** is a separate question from the mode, and the more useful
one:

| Evidence | Reading |
|---|---|
| `ena_srd_tx_pkts` / `ena_srd_rx_pkts` non-zero and substantial | **SRD is genuinely carrying traffic.** The configuration is working, not just set |
| `ena_srd_tx_pkts` near zero despite mode 3 | Configuration is on but SRD is not being used — check eligibility, MTU, and peer configuration. See `Low SRD Usage Rate` |
| `ena_srd_eligible_tx_pkts` ≫ `ena_srd_tx_pkts` | **Silent fallback to standard ENA.** The stated benefit is not being delivered. See `Low SRD Usage Rate` |
| `ena_srd_resource_utilization` approaching 100% | Fallback and drops are imminent or occurring. See `High SRD Resource Utilization` |
| Any allowance finding fired | Unrelated ceilings, unaffected by SRD. Fix those independently |
| Mean packet size near or above 8900 | Oversized packets fall back to standard ENA — the MTU cap in action |
| UDP application reporting reordering or jitter problems | Mode 3 exposes multipath reordering to UDP. Consider mode 1 (TCP-only) for that workload |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Disabled ENA Express` **also fired** | **Expected on 1.3.0** — the flat-delta series contains zeros, so the == 0 rule fires alongside any transition rule. An artifact, not a contradiction |
| `Low SRD Usage Rate` | **Directly qualifies this positive finding.** Configuration is ideal; delivery is not |
| `High SRD Resource Utilization` | Same — the configuration is right but the card is at its resource ceiling |
| Bandwidth / PPS allowance findings | ENA Express does not raise these. A mode-3 instance can still be shaped |
| Tail-latency improvement in application metrics after the step | Corroborates the benefit landing |
| `Underutilized CPU` | Still network-bound; SRD helps latency and single-flow throughput, not allowances |

**Known false positives — in the sense of over-reading a positive finding:**

- **The rule fires on a +3 transition, not on steady-state mode 3.** On aperf 1.3.0 that is the only
  way it can fire, and it means the configuration changed mid-run.
- **Multi-interface averaging**, but only with **≥3 series**: the rule scans the auto-generated
  `average` series, and a mean across interfaces can land on exactly 3.0 with no single interface
  stepping by 3. With exactly two series the aggregate is removed (`:312`–`:319`).
- **Interface flap or counter reset** producing a spurious delta. Check `total_resets` /
  `interface_down` / `interface_up`.
- **Mode 3 with SRD not actually in use** — the most important over-read. Configuration set, benefit not
  delivered. Confirm with `ena_srd_tx_pkts`.
- **Mode 3 on traffic that cannot use it** — cross-AZ, internet-facing, or peers without ENA Express
  enabled. The setting is correct and irrelevant.
- **Mode 3 harming a reordering-sensitive UDP application.** A positive score on a configuration that is
  making one workload worse.
- **The finding is per interface.** On a multi-ENI instance one interface can be in mode 3 while another
  is not.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `ena_srd_tx_pkts`, `ena_srd_rx_pkts` | `ena_stat` | **Do this first.** Whether SRD is actually carrying traffic, as opposed to merely being configured. Read manually — no rule fires on these |
| `ena_srd_eligible_tx_pkts` vs `ena_srd_tx_pkts` | `ena_stat` | **The qualifier for this finding** — a large gap means silent fallback to standard ENA. See `Low SRD Usage Rate` |
| `ena_srd_resource_utilization` | `ena_stat` | Whether the card is near its concurrent-SRD ceiling. See `High SRD Resource Utilization` |
| `ena_srd_mode` series, and its **point count** | `ena_stat` | **Deltified** — locate the +3 step to time the configuration change; a two-point chart means no step happened |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the delta is a real transition or a counter discontinuity. "A reset reinitializes the driver and temporarily disrupts network connectivity" |
| The four allowance counters | `ena_stat` | Separate ceilings; mode 3 does not raise any of them |
| `tx_bytes`/`tx_cnt`, `rx_bytes`/`rx_cnt` | `ena_stat` | **Mean packet size** — values near or above 8900 mean packets are falling back past the SRD MTU cap. Sum **per queue**: `queue_<n>_` metrics are flattened to per-queue series (`ena_stat.rs:327`–`:341`) |
| TCP retransmits, out-of-order counters | `netstat` | Path conditions SRD is mitigating; also whether reordering is surfacing |
| UDP packet and error counters | **not collected** | Whether the UDP half of mode 3 carries meaningful traffic — **aperf reads only `/proc/net/netstat` (`netstat.rs:33`), which has `TcpExt:` and `IpExt:` and no UDP section**, and `/proc/net/snmp` is read by no collector. Measure UDP on the instance (`ss -su`, `nstat -z \| grep -i udp`, or `/proc/net/snmp`) |
| Instance type and size | `systeminfo` | ENA Express support, and the same-AZ constraint context |
| MTU configuration | `systeminfo` / `sysctl` | 8900 SRD cap vs a 9001 interface MTU. **No analytical rules for `sysctl` — read manually** |
| `idle`, `aggregate` | `cpu_utilization` | Whether the workload is still network-bound. See `Underutilized CPU` |
| The aperf `warn!` log for skipped decreases | run log | A skipped decrease on `ena_srd_mode` means the mode **fell** mid-run — a disabling change this rule can never report |
| Out of band: EC2 API / `ethtool` on the ENI | — | **The authoritative mode.** aperf cannot answer this on 1.3.0 |

## Guidance

Ordered. There is nothing to remediate; the work is verification and not over-claiming.

1. **Do not act on the finding's absence.** On aperf 1.3.0 a correctly configured mode-3 instance does
   **not** produce this finding — it produces `Disabled ENA Express` instead. Absence carries no
   information.

2. **If the finding is present, read it as a configuration change during the run** (`0 → 3`), not a
   steady state. Locate the step in the `ena_srd_mode` series and flag that metrics either side are not
   comparable — that affects every other finding in the report.

3. **Verify the real mode out of band** (EC2 API or `ethtool` on the ENI) before reporting a mode either
   way.

4. **Ignore the score.** Always exactly +2.00, and positive, so it sorts at the opposite end of the list
   from everything else.

5. **Check whether SRD is actually being used — the step that gives this finding meaning.** Read
   `ena_srd_tx_pkts` and `ena_srd_rx_pkts`. Configuration on with near-zero SRD packets means the benefit
   is not being delivered, and mode 3 is cosmetic.

6. **Check for silent fallback.** Compare `ena_srd_eligible_tx_pkts` with `ena_srd_tx_pkts` and read
   `ena_srd_resource_utilization`. If `Low SRD Usage Rate` or `High SRD Resource Utilization` fired, this
   positive finding is **qualified** — the configuration is ideal but the outcome is not. Report both
   together; reporting only the positive one is misleading.

7. **Check the MTU.** The SRD limit is 8900. With a 9001 interface MTU, larger packets fall back to
   standard ENA — a common reason a mode-3 instance sees little benefit. Derive the mean packet size from
   `tx_bytes`/`tx_cnt`, summing the per-queue series.

8. **Do not credit ENA Express for things it does not do.** If any allowance finding fired, those
   ceilings are untouched by SRD and need their own remediation. If `Underutilized CPU` fired, the
   workload is still network-bound.

9. **Sanity-check the UDP half.** If UDP traffic is negligible, mode 3 is harmless but no better than
   mode 1. If a UDP application is sensitive to reordering, mode 3 may be actively hurting it — SRD
   exposes multipath reordering directly to UDP, and mode 1 keeps the TCP benefit without it. aperf
   cannot measure UDP at all, so this check happens on the instance.

10. **Confirm the benefit in tail latency, not the mean.** That is where SRD pays off. If p99 did not
    improve, investigate steps 5–7 rather than assuming the configuration is enough.

## Priority and execution risk

**Priority: P4 — Informational** in the ordinary case, and that is the correct home for a positive
finding: nothing is wrong, and the entry exists to stop a reviewer recommending an optimization already
in place. But two situations lift it, and both are about the finding being *misleading* rather than the
configuration being wrong. It becomes **P2 — Plan** when the finding is present at all, because on
1.3.0 presence means the mode stepped `0 → 3` **during the recording**: the run spans a configuration
change, so every before/after comparison in the whole report is suspect, and that invalidation outranks
anything this finding says about SRD. It also becomes **P2** when the finding is present or the mode is
confirmed 3 *and* `Low SRD Usage Rate` or `High SRD Resource Utilization` also fired — the configuration
is ideal while the benefit is not being delivered, and reporting the positive alone would be actively
wrong. It rises to **P1 — Act now** only in the UDP-reordering case: mode 3 on a reordering-sensitive UDP
application is a positive-scored finding describing a configuration that is degrading correctness, and
reverting to mode 1 keeps the TCP benefit. It never reaches P0.

**Execution risk: R0 — Read-only** for everything this playbook asks: reading the SRD counters, locating
the step in the series, the point-count check, the mean-packet-size arithmetic, the out-of-band mode
query, and the run-log check for skipped decreases. Acting is rare here because there is usually nothing
to fix. When there is: **R1** for adding tail-latency and UDP-ordering measurement, and for re-recording
a run that does not straddle the configuration step. **R2 — reverting UDP support** to reach mode 1, a
network-configuration change on the ENI that must be coordinated with the peers, and **R2** for
reconciling a 9001 MTU down to the 8900 SRD cap. **R3** if resolving the eligible-vs-actual gap needs an
instance resize to obtain more card SRD resources — a replacement, with everything that implies. **Do
not let the R0 of the verification imply the enablement or reversion is also cheap.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `ena_srd_mode` interval delta, on any series, was `== 3.0` — which on
aperf 1.3.0 requires a `0 → 3` transition during the recording, not a steady state.

```
STEP 0 — Is this finding even present? Its ABSENCE is what most readers arrive with.
  IF the finding is ABSENT and the question was "is ENA Express enabled with UDP?"
  THEN → STOP. Absence is the EXPECTED outcome on 1.3.0 even for a perfectly configured
         mode-3 instance: the enum is deltified, so a constant 3 stores [0.0, 0.0, ...] and
         fires `Disabled ENA Express` instead — engine-verified. NO finding either way;
         verify the mode out of band (P4, R0)
  IF the finding is absent and `Disabled ENA Express` fired instead
  THEN → the normal presentation for ANY constant mode, including 3. Read
         `disabled-ena-express.md`; the refutation path there is the one to follow.
         See that playbook (P4, R0)
  IF the finding is PRESENT
  THEN → a delta of exactly +3 occurred, so the mode stepped 0 -> 3 mid-recording. Continue
         to STEP 1 (P2, R0)

STEP 1 — Is the +3 delta a real transition, or an artifact?
  IF `total_resets`, `interface_down` or `interface_up` is non-zero
  THEN → the driver reset or the link flapped, so the counter baseline moved for reasons
         unrelated to configuration. A reset "reinitializes the driver and temporarily
         disrupts network connectivity", so treat the step as unproven (P3, R0)
       → verify: confirm the current mode out of band; if it is not 3, the delta was a
         discontinuity, not an enablement
  IF the metric has THREE OR MORE series and only the `average` series shows the +3
  THEN → a cross-interface MEAN landed on 3.0 with no single interface stepping by 3. With
         exactly two series the aggregate is removed (:312-:319), so this needs >=3 (P3, R0)
       → verify: read each interface's series individually; at least one must step by +3
  IF a single real interface series steps by exactly +3
  THEN → a genuine 0 -> 3 enablement during the run. Continue to STEP 2 (P2, R0)

STEP 2 — The run spans a CONFIGURATION CHANGE. This invalidates more than this finding.
  IF the step lands in the middle of the run
  THEN → metrics before and after are NOT comparable, and that applies to every other
         finding in the report, not just this one. Any average, any p99, any intra-run
         comparison crosses a boundary where the network data path changed (P2, R1)
       → verify: re-record entirely before or entirely after the change; then confirm the
         `ena_srd_mode` series is flat (two points after compression) in the new run
  IF the step lands in the first one or two intervals
  THEN → the enablement effectively preceded the workload, so the run is usable. Note the
         boundary and continue to STEP 3 (P3, R0)

STEP 3 — Mode 3 is CONFIGURATION. Is SRD actually carrying traffic? This is what gives the
         finding meaning.
  IF `ena_srd_tx_pkts` and `ena_srd_rx_pkts` are substantial
  THEN → SRD is genuinely carrying traffic; the configuration is working, not merely set.
         Continue to STEP 4 (P4, R0)
  IF `ena_srd_tx_pkts` is near ZERO despite mode 3
  THEN → configuration on, benefit absent. The setting is cosmetic for this workload —
         because the peers lack it, the traffic is cross-AZ or internet-facing, or nothing
         eligible is being sent. Go to STEP 4 to find which (P3, R0)
  IF `ena_srd_eligible_tx_pkts` substantially exceeds `ena_srd_tx_pkts`
  THEN → SILENT FALLBACK to standard ENA on eligible traffic — the configured benefit is
         being lost. This is the single most important qualifier on a positive finding. Go
         to STEP 4, then read `low-srd-usage-rate.md` (P2, R0)

STEP 4 — Which of the three upstream fallback causes is it? They have different fixes.
  IF `ena_srd_resource_utilization` is high, or `High SRD Resource Utilization` fired
  THEN → the card's SRD resource pool is consumed by CONCURRENT CONNECTIONS, not bandwidth,
         so all four allowance counters can read zero while this saturates. The fix is to
         scale OUT, per the metric's own description (P2, R3)
       → verify: after scaling, the eligible-vs-actual gap narrows AND utilization falls; if
         only utilization falls, connections moved but eligibility did not improve
  IF the mean packet size (`tx_bytes`/`tx_cnt` summed PER QUEUE) is near or above 8900
  THEN → packets exceed the SRD MTU cap of 8900 and fall back individually. With a 9001
         interface MTU this is guaranteed for full-size frames, and it is a one-line fix
         (P2, R2)
       → verify: lower the interface MTU to 8900 or below, then confirm `ena_srd_tx_pkts`
         tracks `ena_srd_eligible_tx_pkts` closely. A persistent gap means a different cause
  IF the gap is confined to a short window with no other correlate
  THEN → live migration or a live server update, the third upstream cause. Transient and
         bounded; there is nothing to fix and nothing to report beyond the window (P4, R0)
  OTHERWISE
  THEN → eligibility itself is the limit: the traffic is cross-AZ, internet-facing, or the
         peers do not have ENA Express enabled. Configuration is correct and irrelevant to
         this traffic. Continue to STEP 5 (P4, R0)

STEP 5 — Is mode 3 actually BETTER than mode 1 for this workload? Sometimes it is worse.
  IF a UDP application reports reordering, jitter or late-arrival problems
  THEN → mode 3 is likely HARMING it. SRD sprays packets across paths and UDP has no
         transport layer restoring order, so reordering reaches the application directly.
         Mode 1 keeps the TCP benefit without exposing UDP to it (P1, R2)
       → verify: application-level out-of-order and late-arrival metrics before and after
         reverting to mode 1 — NOT throughput, which can improve while ordering degrades
  IF UDP traffic is negligible
  THEN → mode 3 is harmless but no better than mode 1. aperf cannot measure UDP at all
         (netstat.rs:33 reads only /proc/net/netstat, which has no UDP section), so confirm
         on the instance with `ss -su` or /proc/net/snmp (P4, R0)
       → verify: instance-side UDP counters; the in-report proxy `tx_cnt` - `ena_srd_tx_pkts`
         is only an UPPER bound on non-SRD traffic, since ineligible TCP lands in it too
  IF UDP traffic is substantial and reordering-tolerant
  THEN → mode 3 is the right configuration and the finding is a genuine confirmation.
         Continue to STEP 6 (P4, R0)

STEP 6 — Do not credit SRD with what it does not do.
  IF any of the four allowance findings fired
  THEN → those are hardware ceilings on bytes, packets, connections or link-local traffic,
         and ENA Express raises NONE of them. A mode-3 instance is shaped exactly like any
         other. Fix them in their own playbooks (P1, R0)
  IF `Underutilized CPU` fired
  THEN → still network-bound. SRD lifts single-flow throughput and tail latency, not the
         instance allowance, so check which bound applies before crediting the change
         (P2, R0)
       → verify: measured throughput against the documented allowance for the instance type;
         at the ceiling, SRD cannot be the lever
  IF application p99 did NOT improve after the enablement
  THEN → the benefit is not landing. Revisit STEP 3-4 rather than assuming configuration is
         sufficient — and check that the baseline was a PERCENTILE, since a mean-latency
         comparison shows nothing even when SRD is working perfectly (P3, R1)
       → verify: re-measure p99 and p99.9 specifically; a flat mean with a falling tail is
         the expected signature

STEP 7 — What survives?
  VALID      : that a +3 delta occurred, hence a 0 -> 3 configuration change during the run;
               the same-AZ and both-endpoints requirements; the 8900 MTU cap; and the
               finding's role as a guard against recommending an already-enabled setting
  CAUTION    : "mode 3" read from a +3 delta on the `average` series of >=3 interfaces; a
               transition claimed on a run with `total_resets` non-zero; and any mean packet
               size derived from one queue rather than the per-queue sum
  CONFOUNDED : every metric in the run when the step lands mid-recording, since the data path
               changed underneath; and any average over the `ena_srd_mode` series, diluted
               by the forced first zero
  VOID       : the ABSENCE of this finding as evidence that ENA Express is off — a constant
               mode 3 fires `Disabled ENA Express` instead, engine-verified; the score, a
               constant +2.00; the claim that SRD is carrying traffic, which needs
               `ena_srd_tx_pkts` and not the mode; and any claim about UDP volume, which
               aperf does not collect at all

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205);
         `lo`, `docker*`, `veth*`, `br-*` and `virbr*` are skipped, so a container with only
         virtual interfaces collects nothing (P4, R0)
  IF `ena_srd_*` metrics are absent while other `ena_stat` metrics are present
  THEN → the driver or instance type does not expose the SRD counters, so ENA Express is
         almost certainly unsupported here (P4, R0)
  IF the series has fewer than 3 points
  THEN → the first point is a structural zero, so 2 snapshots cover 1 real interval and a
         transition cannot be located. Re-record with `--period 300` (P4, R0)
  IF UDP behaviour is the question
  THEN → aperf collects NO UDP counters anywhere. Measure on the instance; the report cannot
         answer it (P3, R0)
```

## Runtime-specific consequences

Mode 3 is the only mode where the runtime's behaviour can make the configuration a *net negative*, so
the runtime matters more here than for any other `ena_srd_mode` finding.

- **TCP workloads.** Pure benefit. SRD's multipath spraying is resolved below the socket, so TCP sees
  fewer congestion events and less spurious recovery, and the gain shows up as reduced tail latency with
  no application change.
- **UDP workloads.** The decisive case, and mode 3's only real risk. SRD sprays datagrams across paths
  and nothing restores order, so a protocol that assumes near-ordered delivery — many custom binary
  protocols, some media transports, naive sequence-number handling — can degrade. A reordering-tolerant
  protocol (QUIC, most telemetry, DNS) gains. aperf cannot tell you which you have.
- **Java.** No configuration to change, but the measurement trap is acute: JVM latency reports usually
  quote a mean beside a p99, and only the percentile moves meaningfully. A 50 ms GC pause swamps a
  network improvement of a few hundred microseconds, so `java_profile` GC evidence must be ruled out
  before crediting or blaming SRD. For UDP over `DatagramChannel`, reordering surfaces as
  application-level sequence gaps, not as any JVM metric.
- **RPC meshes and sidecar proxies.** Every hop is a separate connection consuming its own SRD card
  resources, so a mesh multiplies concurrent SRD connections for the same logical traffic — the fastest
  route to `High SRD Resource Utilization` and therefore to the fallback this finding does not mention.
- **Containers.** ENA Express is a property of the **ENI**, so every container on the instance shares
  mode 3 and none can opt out — including a reordering-sensitive UDP container next to a TCP one.
- **HPC / MPI / distributed training.** These want SRD through **EFA** rather than ENA Express — the same
  transport exposed directly to the application, with far larger gains for collective communication. See
  the `efa_stat` playbooks.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in availability.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and the delta defect that
  makes this rule unreachable applies identically on both.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container
  with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot fire.
- **ENA Express support is a property of instance type and generation, not of the CPU architecture.**
  Graviton and Intel/AMD families both include supporting and non-supporting types; a Graviton migration
  neither grants nor removes mode 3. Check the specific type, never the architecture.
- **UDP support is a second, independent setting** on top of ENA Express, so an instance can be in mode 1
  on a fully supporting type. Mode 3 is never the default.
- **Multi-ENI instances** can have different modes per interface, and with **≥3 series** the
  auto-generated `average` mixes them into a meaningless mean that can itself land on 3.0. With exactly
  two series the aggregate is dropped (`:312`–`:319`).
- **`.metal` and the largest family sizes** give the full non-shared network allowance — which changes
  the ceilings SRD does *not* affect, and is worth separating in any before/after comparison.

## Verification

The falsifiable claim is *ENA Express with UDP support is in effect, and SRD is carrying this workload's
traffic with a measurable tail-latency benefit*. The finding establishes only a fragment of that, so
verification is mostly about the rest.

1. **Do not verify absence.** If the finding is missing, that is the expected state on 1.3.0 even in
   mode 3 — engine-verified. Nothing follows from it, in either direction.
2. **If present, locate the step.** Find the +3 point in the `ena_srd_mode` series and check whether it
   falls mid-run. If it does, every before/after comparison in the report crosses a data-path change and
   must be discarded or re-recorded.
3. **Rule out the discontinuity.** `total_resets`, `interface_down` and `interface_up` must all be zero
   for the step to be a configuration change rather than a counter baseline moving.
4. **Establish the mode authoritatively**, via the EC2 API or `ethtool` on the ENI, and record it. Also
   grep the run log for `"skipped N data points due to unexpected decrease"` on `ena_srd_mode` — its
   presence means the mode *fell* during the run, which no rule in this family can report.
5. **Prove SRD is carrying traffic, not merely configured.** `ena_srd_tx_pkts` and `ena_srd_rx_pkts`
   substantial, and `ena_srd_eligible_tx_pkts` close to `ena_srd_tx_pkts`. A large gap falsifies the
   benefit even though the configuration is ideal.
6. **Predict the MTU consequence quantitatively.** With a 9001 interface MTU, predict that full-size
   frames fall back past the 8900 SRD cap, and check it as an eligible-vs-actual gap. No gap means the
   traffic was already under the limit and the MTU is not the issue.
7. **Baseline and compare the right numbers.** Capture p99 and p99.9 latency and single-flow throughput,
   not means. For UDP, capture application-level ordering metrics on the instance — aperf has no UDP
   counters. Then predict specifics: the tail falls by more than the mean, `ena_srd_resource_utilization`
   stays well below 95, and **this finding does not reappear** in a run that does not straddle the change.

## Do not

- **Do not treat the absence of this finding as evidence that ENA Express is off.** On aperf 1.3.0 a
  fully-enabled instance reports `Disabled ENA Express` instead — verified by running the engine.
- **Do not read this as "the device is in mode 3".** The mode series is deltified, so the rule fires only
  on a **+3 transition** (`0 → 3`), i.e. a configuration change mid-recording.
- **Do not expect a mode *decrease* to appear anywhere.** Decreasing samples are dropped entirely
  (`:214`), leaving a gap and one `warn!` line, so a `3 → 0` or `3 → 1` change is invisible.
- **Do not read the score as a magnitude.** It is a constant +2.00.
- **Do not read mode 3 as proof that SRD is carrying traffic.** Configuration is not behaviour; check
  `ena_srd_tx_pkts` and the eligible-vs-actual gap.
- **Do not report this positive finding without checking `Low SRD Usage Rate` and
  `High SRD Resource Utilization`.** Either one means the configured benefit is not being delivered, and
  the positive alone would be misleading.
- **Do not credit ENA Express with raising an allowance.** Bandwidth, PPS, connection-tracking, and
  link-local ceilings are unaffected and can all be breached in mode 3.
- **Do not assume mode 3 is better than mode 1 for every workload.** UDP acceleration exposes multipath
  reordering to the application; a reordering-sensitive UDP protocol can do worse, and this positive
  finding will still fire.
- **Do not try to measure the UDP half from the report.** aperf collects no UDP counters anywhere; the
  `tx_cnt` − `ena_srd_tx_pkts` proxy is only an upper bound on non-SRD traffic.
- **Do not ignore the 8900 MTU cap.** With a 9001 MTU, oversized packets silently fall back to standard
  ENA — and the eligible-vs-actual gap is the only in-report sign of it.
- **Do not ignore that the run spans a configuration change** when this finding is present. That
  invalidates comparisons across the whole report, not just this metric.
- **Do not look for upstream aperf guidance.** No ENA Express or SRD optimization guide exists in
  `optimization-guides.ts`; only the four network *allowance* guides do.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:80`–`:86` (`Comparator::Equal`, threshold `3.0`,
  `Score::Good` — the only positive-scoring `ena_stat` rule). Siblings at `:56`, `:64`, `:72`; the two
  sound SRD rules at `:88`, `:99`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates
  every series including the auto-generated aggregate, keeping the largest `|score|`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — general branch, `delta = 3/3 = 1`.
  `Score::Good = 2` at `src/analytics/mod.rs:147`–`:157`, where `Great = 16` and `Optimal = 256`. The
  frontend sorts findings ascending by score (`src/report_frontend/src/utils/analytics.tsx:40`), so a
  positive finding sorts last.
- **The defect:** `add_accumulative_data_point` applied to every `ena_stat` metric at
  `src/data/ena_stat.rs:343`; `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189`–`:224`.
- Forced first zero: `ignore_first_accumulative_value: true` at
  `src/data/common/time_series_data_processor.rs:73`, taken at `:218`; the only opt-out,
  `use_first_accumulative_value()` (`:81`–`:83`), is called once, from `src/data/perf_stat.rs:1295`.
- Dropped decrease and its warning: `time_series_data_processor.rs:214` (`return None`), early return at
  `:150`, single `warn!` at `:297`–`:302`.
- All-zero compression to two points: `compress_all_zero_time_series_metric`,
  `time_series_data_processor.rs:410`–`:427`.
- Average aggregate and the two-series collapse: `src/data/ena_stat.rs:315`;
  `time_series_data_processor.rs:249`–`:256` and `:312`–`:319`. Queue-name flattening, `:327`–`:341`.
- Metric semantics: `ena_srd_mode` at `src/report_frontend/src/definitions/data-descriptions.ts:3859`
  (`desired: "fixed"`); `ena_srd_eligible_tx_pkts` at `:3871` names the three fallback causes — card
  resource limits, packets over the SRD MTU limit, and live migrations or live server updates;
  `ena_srd_resource_utilization` at `:3884`.
- No UDP collection: `NetstatRaw` reads only `/proc/net/netstat` (`src/data/netstat.rs:33`), which
  carries `TcpExt:` and `IpExt:`; `/proc/net/snmp` is read by no collector.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL` and the
  `ETHTOOL_GSSET_INFO`/`GSTRINGS`/`GSTATS` sequence, `:31`–`:33`, `:216`.
- **No upstream guidance exists:** `src/report_frontend/src/definitions/optimization-guides.ts` contains
  only the four EC2 network allowance guides (`:117`, `:125`, `:134`, `:146`) — nothing for SRD.
- Related playbooks: `disabled-ena-express.md` (the finding that fires instead),
  `enabled-ena-express-without-udp.md`, `disabled-ena-express-with-previously-enabled-udp.md`,
  `low-srd-usage-rate.md`, `high-srd-resource-utilization.md`.
- [ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express.html)
- [Configure ENA Express (including UDP support)](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express-configure.html)
- [Scalable Reliable Datagram (SRD)](https://aws.amazon.com/blogs/hpc/in-the-search-for-performance-theres-more-than-one-way-to-build-a-network/)
