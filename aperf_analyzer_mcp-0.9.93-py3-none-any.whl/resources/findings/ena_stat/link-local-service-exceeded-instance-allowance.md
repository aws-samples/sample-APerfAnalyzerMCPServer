---
rule_name: Link-Local Service Exceeded Instance Allowance
data_type: ena_stat
data_key: linklocal_allowance_exceeded
template: time_series_data_point_threshold
condition: "any(linklocal_allowance_exceeded) > 0.0"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "EFA is dropping packets because the PPS of the traffic to local proxy services exceeded the maximum for the network interface. Consider caching DNS responses locally or reducing the rate of metadata queries."
source: src/analytics/rules/ena_stat.rs:48
---

# Link-Local Service Exceeded Instance Allowance

## What fired

**At least one** interval delta of `linklocal_allowance_exceeded` was **greater than 0.0** — packets to the EC2
**link-local proxy services** (DNS, IMDS, Time Sync) were dropped because their packets-per-second maximum **for
the network interface** was exceeded. Base score `Critical` (**−256**). Single-run rule, `Comparator::Greater`,
threshold `0.0` (`ena_stat.rs:48`–`:54`).

Like the other four allowance rules this is hardware enforcement, not a heuristic — but two facts make it the odd
one out, and both invert advice correct everywhere else in the family. **The allowance is FIXED for all instance
types** (`optimization-guides.ts:146`), where every other allowance here scales with instance size, so **a resize
is definitionally useless** — the one allowance finding where "get a bigger instance" cannot work even in
principle, leaving only levers that reduce the traffic or move it off these services. **And it is per NETWORK
INTERFACE, not per instance**: the description says *"the maximum for the network interface"*
(`data-descriptions.ts:3841`) where the other four say *"for the instance"*, so the per-interface series is the
meaningful one and attaching an ENI genuinely adds budget — again uniquely here.

> **The message names the wrong device — but carries real advice.** aperf says *"EFA is dropping packets"*; all
> five allowance rules (`ena_stat.rs:21`, `:29`, `:37`, `:45`, `:53`) say "EFA" when they mean **ENA**, and the
> metric comes from an `ethtool -S` ioctl on the ENA interface (`:235`). Unusually, **this is the only one of
> the five whose message carries remediation** — *"Consider caching DNS responses locally or reducing the rate
> of metadata queries"* — and that advice is correct.

## The collection gap — aperf cannot name the service, and cannot see the UDP damage

Upstream's guide is unambiguous about the decisive step: *"you need to identify the link-local service through
tools, such as `iftop` or `tcpdump`, to root-cause and reduce the traffics"* (`optimization-guides.ts:146`).
**aperf collects neither, and cannot.** DNS, IMDS and Time Sync share one counter with no per-destination
breakdown, and their fixes are unrelated — a local resolver cache, IMDS token reuse, an NTP poll interval. So
the most important question this finding raises is one the report cannot answer, and the honest triage path
routes **out of aperf** at that point.

Three collection facts, each checked against the collectors rather than assumed:

**1. `netstat` cannot corroborate DNS at all.** `NetstatRaw::collect_data` reads exactly one file —
`/proc/net/netstat` (`netstat.rs:33`) — which carries only the `TcpExt:` and `IpExt:` sections. **The UDP
counters live in `/proc/net/snmp`, and no aperf collector reads that path** (a tree-wide grep for `proc/net`
returns the single `netstat.rs:33` hit). DNS is predominantly UDP/53, so aperf has **no UDP datagram or UDP-error
counter anywhere**. What `netstat` *can* give you is the TCP side — `TCPTimeouts`, `TCPSynRetrans`, `ListenDrops`
and the retransmit family from `TcpExt`, plus `InOctets`/`InNoRoutes` from `IpExt` — useful for the
connection-rate argument, useless for the DNS query rate.

**2. No resolver configuration is collected.** Nothing reads `/etc/resolv.conf`, `nsswitch.conf` or any resolver
cache state, so `ndots`, the `search` list and the local-cache presence — three of the highest-leverage fixes
below — are invisible in the report. `sysctl` collects the whole tree (`sysctl.rs:44`–`:60`, skipping only
`rss_key`) but **has no DNS or resolver keys at all**.

**3. aperf itself queries IMDS — once.** `SystemInfo` makes five IMDS calls at `systeminfo.rs:97`–`:106`
(`ami-id`, `instance-id`, `local-hostname`, `instance-type`, `placement/region`) and `is_static()` returns `true`
(`:147`), so they happen **once per run**, not per interval — negligible against any allowance, but with one
diagnostic use: if those five fields render as **`N/A`**, the call failed (`:135`–`:141` substitutes `"N/A"` and
warns), weak corroboration that IMDS traffic was being dropped at collection time.

The three properties of the counter *itself* are the family's, and only the third is subtle. The series is a
**per-interval delta** (`add_accumulative_data_point`, `ena_stat.rs:343`); its **first point is a forced zero**
covering no elapsed time (`ignore_first_accumulative_value` defaults `true` at
`time_series_data_processor.rs:73`, `None` arm at `:218`, only `perf_stat` opting out at `perf_stat.rs:1295`),
so an n-snapshot run covers **(n−1) × interval** seconds and any average is diluted by (n−1)/n; and the
auto-generated `average` series — a **mean** across interfaces (`ena_stat.rs:315`, dropped on single-ENI runs at
`:315`–`:319`) — is scanned alongside the real ones and can out-score them. Brute-forcing 1,596 combinations over
2/3/4/8 ENIs found that artifact in 22 cases with **the peak per-interface delta equal to 1 in every one**, so **a
fractional value means the true per-interface peak was exactly ONE dropped packet**. The queue split at `:332`
fires only for `queue_<n>_...` names, which no allowance metric matches, so these are always one series per
interface.

## Reasoning

`linklocal_allowance_exceeded` is the *"Number of packets dropped because the PPS of the traffic to local
proxy services exceeded the maximum for the network interface. This impacts traffic to the DNS service,
the Instance Metadata Service, and the Amazon Time Sync Service, but does not impact traffic to custom DNS
resolvers."* (`data-descriptions.ts:3841`, `desired: "lower"`)

EC2 exposes several instance-local services on **well-known, non-routable link-local addresses** (IPv4
`169.254.0.0/16`, IPv6 `fe80::/10`), served by a proxy on the Nitro card with its own PPS budget separate from
the instance's general PPS allowance. The three that matter:

| Service | IPv4 | IPv6 |
|---|---|---|
| **Instance Metadata Service (IMDS)** | `169.254.169.254` | `fd00:ec2::254` |
| **Amazon Route 53 Resolver** (VPC DNS) | `169.254.169.253`, *or the VPC's primary private IPv4 CIDR base + 2* | `fd00:ec2::253` |
| **Amazon Time Sync Service** | `169.254.169.123` | `fd00:ec2::123` |

Two further properties drive the investigation, on top of the fixed, per-interface allowance already covered
above — and each departs from the other allowance rules.

**1. It is a PPS limit on a narrow slice of traffic, so every other counter can look perfect.** Not bytes, not
the instance's general packet rate. Tiny DNS and metadata queries at a high rate exhaust it while bandwidth, PPS
and conntrack all sit at zero — and because the queries are ~100-byte packets, the byte volume is invisible:
10 000 queries/s is roughly **0.008 Gbps, under 0.1 % of a 10 Gbps allowance**. Same argument as the conntrack
finding, same consequence: a resize chosen from the bandwidth dashboards is the wrong instrument.

**2. The failure is almost always misattributed.** A dropped DNS query surfaces as a **resolution timeout** —
typically seconds, resolver retry defaults being measured in seconds rather than milliseconds — so the
application reports "slow database", "slow S3" or "intermittent connection failures"; a dropped IMDS request
surfaces as a credential-refresh failure or an SDK initialisation stall; dropped Time Sync packets surface as
clock drift, possibly hours later. **The packet count therefore understates the damage badly**: a handful of
drops per second can produce a very visible latency tail, and unlike the bandwidth findings packets dropped is
not proportional to impact.

The scoping caveat is in the description itself: only the **VPC-provided** services count. Traffic to a **custom
DNS resolver** — your own BIND/Unbound, a Route 53 Resolver endpoint, a resolver on another instance — does
**not**, which cuts both ways: "we run our own DNS" is a legitimate reason for this counter to read zero, and
moving to one is itself a structural remediation.

Common causes, each addressed in *Guidance* step 5: **no DNS caching on the instance** (the dominant one — every
`getaddrinfo` becomes a query on the wire), **a zero or very low TTL respected literally**, **resolving per
request** rather than per connection or pool, **negative results not cached**, **IMDS polling** on a timer rather
than on expiry with **IMDSv2 doubling the request count**, **container density** multiplying all of the above
against one interface's fixed allowance, **search-domain expansion** (Kubernetes' `ndots:5` is often a 4–5×
multiplier nobody intended), **dual-stack lookups** asking A and AAAA in parallel, **NTP misconfiguration**, and
a **retry storm**, self-reinforcing because the retries also count against the allowance.

## Reading the description

`time_series_data_point_threshold` emits, with the comparator `"greater than"`:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
At least one data point in aperf_record is 12 (greater than the threshold of 0).
```

The value is the **worst single interval delta across every series**, not a total and not an average. Values at
or above 1000 print with a K/M/G/T suffix (`formatted_number_string`, `computations/mod.rs:176`–`:190`), which
matters here more than elsewhere: a runaway resolver easily reaches four figures, so `12K` is plausible.

**Score math takes the `threshold == 0.0` branch** of `compute_finding_score` (`analytics/mod.rs:170`):

```
if value < 1.0  →  score = rule_score               (flat −256)
else            →  score = (value - 1.0) * rule_score
```

| worst delta | score | note |
|---|---|---|
| 0.50 | **−256.00** | fractional ⇒ multi-interface mean; true peak was 1 dropped packet |
| **1.00** | **−0.00** | **one dropped query in an interval scores zero** |
| 2.00 | **−256.00** | collides with the 0.50 score |
| 12.00 | **−2 816.00** | linear from here up: 100.00 ⇒ **−25 344.00** |

Recover the delta as `|score| / 256 + 1`, but **−256.00 is ambiguous** — produced both by the flat branch (any
sub-unit value) and by exactly 2.0 on the linear branch. Disambiguate from the value text, never from the score.
Two traps, both confirmed against the engine: **`1.00 → −0.00` renders NEUTRAL** — `FindingIcon` returns the
`face-neutral` icon for `score == 0` and `getFindingColor` greys it (`AnalyticalFindings.tsx:35`, `:44`–`:52`), and
findings sort ascending by score (`analytics.tsx:40`), so this `Critical` finding lands **mid-list below every
`Concerning` finding**, off the first page at the default page size of 5. And **the score is non-monotonic**: every
delta in [1.0, 2.0) scores closer to zero than any sub-unit delta.

**The conversion trap specific to this rule: one dropped packet is worth seconds, not microseconds.** A delta of 3
can mean three requests each stalled for a multi-second resolver or SDK timeout, so the user-visible impact lives in
application latency percentiles rather than in this counter.

## Interpretation

Enforcement is a fact, so the question is **how much of the run was over the link-local budget**:

| Pattern in the series | Reading |
|---|---|
| One interval, small delta | A brief burst of lookups. Real; check whether it aligns with startup or a fan-out event |
| Sustained non-zero | **Permanently over the link-local PPS budget.** Expect a persistent latency tail from resolver timeouts |
| Ramping up over the run | Query rate scaling with load ⇒ resolution happens **per request**. The strongest signal that caching pays |
| Bursts at startup only | Cold caches and credential initialisation. Often acceptable; check where in the series it falls |
| Periodic bursts | Cache TTL expiry landing together, a cron job, or a credential-refresh cycle |
| Fractional value | Multi-interface mean out-scored the real series. **True per-interface peak was one dropped packet** |
| `total_resets` non-zero | The series has silent gaps; every total is a lower bound |

Combinations that change the diagnosis:

| also fired / observed | Reading |
|---|---|
| **All four other allowance counters zero** | **The characteristic case.** General network health is fine and only the link-local proxy budget is exhausted — so nothing about instance size is wrong, and nothing about instance size can help |
| `PPS Exceeded Instance Allowance` also fired | The same chatter counts against the instance-wide PPS ceiling too. Fixing the query rate helps both; only the PPS one has a scaling escape |
| `Connection Tracking Exceeded Instance Allowance` also fired | High connection churn usually means high resolution rate — one root cause (no reuse, no caching) at two ceilings |
| Application reports intermittent multi-second latency with no CPU or I/O explanation | **The signature.** Resolver timeouts are seconds long and invisible in CPU and disk data |
| Credential or SDK initialisation failures, or clock offset and NTP complaints | Which service is being dropped: the former means IMDS (check the IMDSv2 token pattern), the latter Time Sync (the one branch with a trivially cheap fix) |
| `systeminfo` fields render as `N/A` | aperf's own five IMDS calls failed (`systeminfo.rs:135`–`:141`) — weak corroboration that IMDS was being dropped |
| `Underutilized CPU` | Idle CPU with latency spikes — waiting on resolution, not computing (see `underutilized-cpu.md`) |
| High process or container count (`processes`) | Density multiplying per-container DNS and IMDS traffic against one fixed, per-interface allowance |

**Known false positives — none of them make the enforcement unreal:**

- **A single interval with a tiny delta**, or **a fractional value** — the latter not false about *whether* it
  happened but reporting a true per-interface peak of one dropped packet. Even one drop can cost a caller seconds,
  so judge from the application side rather than dismissing on size.
- **A startup burst.** Cold DNS caches and first-time credential fetches are inherently bursty and not steady
  state. Check where in the series the exceedance falls.
- **Traffic not generated by the workload under test.** Monitoring agents, log shippers, service-mesh sidecars and
  package managers are all heavy DNS and IMDS users, and on a dense host the workload can be a minority of the
  queries. Check `processes`.
- **Counter reset, interface flap, or too short a run.** A decrease is *dropped*
  (`time_series_data_processor.rs:202`–`:214`) rather than emitted as a spike, so a reset yields a gap — check
  `total_resets`, `interface_down`, `interface_up`; and with the first point a structural zero, 2–3 snapshots
  can miss enforcement entirely. **Absence proves less than usual** for the same reason a custom resolver does:
  its DNS traffic never counts against this allowance, so a zero counter says nothing about the query rate.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `linklocal_allowance_exceeded` full series, **per interface** | `ena_stat` | **Do this first.** The allowance is per *network interface*, so the per-interface series is the meaningful one. Sustained vs startup burst vs ramp |
| All four other allowance counters | `ena_stat` | **All zero is the characteristic pattern** — the instance is healthy, only the link-local budget is exhausted, and scaling up cannot fix it |
| `pps_allowance_exceeded`, `conntrack_allowance_exceeded` | `ena_stat` | Whether the same chatter also breaches the instance-wide PPS ceiling (`pps-exceeded-instance-allowance.md`); connection churn and resolution rate usually share a root cause |
| `tx_cnt`, `rx_cnt`, `tx_bytes`, `rx_bytes` per queue | `ena_stat` | Total packet rate for context, and confirmation that byte volume is trivial. Sum **per queue**; the aggregate is a mean |
| Number of ENA interfaces, then `total_resets`, `interface_down`, `interface_up` | `ena_stat` | ENI count is both a capacity lever and the test for whether a fractional value is a mean; the reset counters say whether the series is continuous |
| `TCPTimeouts`, `TCPSynRetrans`, retransmits, `ListenDrops` | `netstat` | The TCP-side correlation. **Note the gap: aperf reads only `/proc/net/netstat` (`netstat.rs:33`), which has no UDP section, so DNS itself is invisible here** |
| Process list, container and agent processes, process count | `processes` | **Who is querying.** Container density and sidecars multiply the traffic. **No analytical rules — read manually** |
| `idle`, `aggregate`, then `iowait` | `cpu_utilization` | Idle CPU with latency spikes = waiting on resolution, not computing. `system`/`softirq` stay modest — link-local packet rates are small in absolute terms |
| `Instance Type` | `systeminfo` | Recorded for completeness, but **the link-local allowance does not vary with it**. If this and the other four fields read `N/A`, aperf's own IMDS calls failed |
| On-CPU or blocking profile | `perf_profile` / `java_profile` | Whether resolution or credential-fetch paths are hot or blocking. Requires `--profile` |
| `iftop` / `tcpdump` against the three fixed addresses | **not collected** | **The decisive evidence, and aperf cannot produce it** — upstream's prescribed identification step. Run it on the instance |

## Guidance

Ordered. **Step 2 is where this finding differs from every other allowance**, and **step 3 leaves aperf**.

1. **Read the full series, per interface, and quantify rate and duration.**
   `python3 tools/aperf_ena_allowance.py --metric linklocal_allowance_exceeded --series <deltas>` gives the
   exceeding-interval count, peak rate, total, and the sustained/pervasive verdict. Sustained ⇒ permanently
   over budget, expect a persistent latency tail. Ramping with load ⇒ resolution is per request and caching
   pays most. Startup burst only ⇒ cold caches, often acceptable. Fractional ⇒ true per-interface peak was one
   dropped packet. **Never triage by score**: one dropped query per interval scores −0.00 and renders neutral,
   greyed out, mid-list. If `pps_allowance_exceeded` or `conntrack_allowance_exceeded` also fired, read its page
   too — usually one root cause (no reuse) at two ceilings, and pooling comes first.

2. **Confirm the characteristic pattern, then rule the resize out.** The other four allowance counters all zero
   means the instance is not undersized for traffic and the constraint is purely the link-local proxy budget.
   **Do not consider vertical scaling** — upstream states the allowance is fixed for all instance types
   (`optimization-guides.ts:146`), making this the one allowance finding where a resize is *definitionally*
   useless rather than merely a poor instrument. The capacity levers that do exist are **scaling out** and
   **adding an ENI**, the allowance being per interface — both workarounds for a traffic-rate problem.

3. **Identify which link-local service is being hit — the decisive step, and one aperf cannot take for you.**
   One counter covers three services with unrelated fixes, so settle this before recommending any
   remediation. Per upstream, use `iftop` or `tcpdump` against the fixed addresses:
   `169.254.169.253`/`fd00:ec2::253`, or the VPC's primary private IPv4 CIDR base + 2, ⇒ **VPC DNS**, the most
   common answer; `169.254.169.254`/`fd00:ec2::254` ⇒ **IMDS**; `169.254.169.123`/`fd00:ec2::123` ⇒ **Time
   Sync**. If neither tool can be run, say so and stop — a guess sends the fix to the wrong subsystem.

4. **Quantify the application-visible damage, and find out whose traffic it is.** A dropped query costs the
   caller a multi-second timeout, so correlate the exceeding intervals with application latency outliers;
   intermittent multi-second latency with no CPU or I/O explanation is this finding's signature, and aperf
   collects no UDP counters to corroborate it with. Then check `processes` for sidecars, log shippers,
   monitoring agents and container density: on a busy container host the workload may be a minority of the
   queries, and the fix belongs to the platform rather than the application.

5. **Remediate — reduce the traffic**, per `EC2_NETWORK_LINK_LOCAL_ALLOWANCE_RECOMMENDATIONS` and aperf's own
   message. Branch on step 3's answer; the risk ratings do **not** follow the cost ordering:
   - **DNS — run a local caching resolver** (systemd-resolved, dnsmasq, Unbound, or NodeLocal DNSCache on
     Kubernetes): the highest-leverage fix, collapsing repeated identical queries and absorbing bursts. Then
     **fix in-process caching** — sane JVM `networkaddress.cache.ttl` and `negative.ttl`, the runtime's resolver
     cache enabled, resolution once per connection or pool rather than per request — so that failing lookups
     stop retrying at full rate too.
   - **DNS — cut query multiplication.** Trim the `search` list and set `ndots` in `resolv.conf` so external
     names do not traverse several failed cluster-local lookups first: frequently a 4–5× reduction for one
     configuration line. Drop dual-stack lookups if only one family is in use. Cheap, but it changes resolution
     semantics — a wrong `ndots` breaks short-name lookups.
   - **DNS — move to a custom resolver.** Traffic to your own resolver or a Route 53 Resolver endpoint does
     **not** count against this allowance at all: the structural escape when the query rate is genuinely
     irreducible, at the cost of owning resolver availability.
   - **IMDS — stop paying per request.** Refresh credentials on expiry rather than on a timer, share one
     credential source across processes and containers, **cache the IMDSv2 token for its full lifetime** rather
     than fetching one per request (this alone halves the request count, and IMDSv2 costing a `PUT` plus a `GET`
     is why a v1→v2 migration doubles the traffic), and fetch instance identity once at startup.
   - **Time Sync — raise the NTP poll interval** and remove aggressive polling. The cheapest, safest branch.

## Priority and execution risk

**Priority: P1 — Act now** whenever the exceedance is sustained (≥5 consecutive intervals) or pervasive (≥25 % of
intervals), because the enforcement is measured rather than inferred and each dropped packet costs a caller seconds
rather than microseconds. It rises to **P0 — Emergency** when a sustained streak coincides with **IMDS** drops that
are failing credential refresh, because expired credentials fail *everything* the instance does against AWS APIs,
not just the request that triggered the refresh — a broader blast radius than a DNS timeout. It drops to **P3 —
Monitor** for a single exceeding interval with no correlated latency excursion, and to **P4 — Informational** when
the value is fractional (true peak one dropped packet) or the queries are attributable to a monitoring agent or
sidecar rather than the workload. Note the same score asymmetry as the rest of the family: the P4 case reads
**−256.00** and the P3 case can read **−0.00**. One priority quirk is specific to this finding: because a resize
cannot help, there is no "buy your way out" option to defer to, so the P1 work is always a configuration change —
which makes it cheaper to act on than an equally-scored bandwidth finding.

**Execution risk: R0 — Read-only** to resolve *within aperf*: the series, the per-interface split, the
rate-and-duration arithmetic and the `processes` attribution are all reads. **R1** for the step-3 identification,
because `iftop` and `tcpdump` must run on the instance — capture is low-risk but not free, costing CPU on a busy
interface and possibly restricted by policy. Acting: **R1** for raising an NTP poll interval, for IMDS token caching
and on-expiry refresh, and for in-process DNS cache TTLs — reversible configuration, and the correct place to start.
**R2** for installing a local caching resolver, since it interposes a new component in every name lookup on the box
and a misconfigured cache fails *all* resolution rather than degrading it; **R2** likewise for `ndots` and
`search`-list changes, which alter resolution semantics and can break short-name lookups, and for adding an ENI or
scaling out. **R3** for migrating to a custom DNS resolver: you take on resolver availability, and an outage there is
a total outage. **Do not inherit the R0 of the reading into the resolver change**, and note that the one thing *not*
on this list at any risk level is a resize.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `linklocal_allowance_exceeded` interval delta, on any series including the
auto-generated `average`, was `> 0.0`.

```
STEP 0 — Is the reported VALUE trustworthy? Check before reading anything into it.
  IF the value is FRACTIONAL (e.g. 0.50, 0.33)
  THEN → the `average` series out-scored the real ones; simulation puts the true per-interface peak
         at EXACTLY 1 packet -- one dropped query, reported at -256.00 (P4, R0)
       → verify: read the per-interface series directly; the peak must be 1
  IF `total_resets` or `interface_down` is non-zero
  THEN → the driver reset mid-run. A DECREASE is dropped entirely while the baseline advances, so
         events between snapshots are LOST and every total below is a lower bound (P2, R0)
  IF the series has fewer than 4 points
  THEN → the first point is a structural zero, so 2-3 snapshots cover 1-2 real intervals: neither
         rate nor duration is establishable. Re-record with `--period 300` (P2, R0)
       → verify: series length minus 1 equals the intervals actually covered
  OTHERWISE
  THEN → a genuine worst-interval delta on one interface. Continue (P2, R0)

STEP 1 — Rate and duration, PER INTERFACE -- the only allowance of the five that is.
  IF SUSTAINED (>=5 consecutive) or PERVASIVE (>=25% of intervals)
  THEN → permanently over the link-local budget: expect a persistent latency tail from resolver
         or SDK timeouts. A live defect, not an observation. Go to STEP 2 (P1, R0)
  IF the series RAMPS with offered load
  THEN → resolution or metadata fetch is PER REQUEST, not per connection or process -- the
         strongest signal that caching is the fix. Go to STEP 2 (P1, R0)
  IF confined to the FIRST few intervals
  THEN → cold caches and first credential fetches; confirm steady state first (P3, R0)
       → verify: re-record starting after warm-up; the exceedance should not reappear

STEP 2 — Routing: are the OTHER FOUR counters zero, and can capacity ever help?
  IF all four are ZERO
  THEN → the characteristic case: volume, packet rate and connection count all within budget,
         only the link-local proxy saturated. Go to STEP 3 (P1, R0)
  IF `pps_allowance_exceeded` or `conntrack_allowance_exceeded` is also non-zero
  THEN → one root cause, two ceilings: the same chatter counts against the instance-wide PPS
         budget, and no-reuse drives churn and resolution rate alike. Read
         connection-tracking-exceeded-instance-allowance.md too, pooling first. STEP 3 (P1, R0)
       → verify: both fall after the changes; only one falling means the rates are independent
  IF capacity is the instinct
  THEN → a resize CANNOT help: the allowance is fixed for all instance types
         (optimization-guides.ts:146), the only allowance finding where that holds even in
         principle. The levers are horizontal -- scale OUT, or ADD AN ENI since the allowance is
         per interface -- and both leave the rate untouched, so do STEP 3 first (P2, R2)
       → verify: after adding the interface, the PER-INTERFACE exceeding count falls; if
         unchanged the traffic did not spread across interfaces

STEP 3 — WHICH link-local service? aperf cannot answer this, and the answer decides everything.
  IF `iftop` or `tcpdump` can be run on the instance
  THEN → capture against the three fixed addresses and route on the destination -- upstream's
         prescribed step, with no substitute in the report (P1, R1)
       → verify: the captured rate to that address accounts for the drop rate; a large shortfall
         means a second service contributes too
  IF neither tool can be run
  THEN → the finding CANNOT be root-caused from this report. Say so rather than guessing between
         DNS, IMDS and Time Sync -- a guess sends the fix to the wrong subsystem. One weak proxy:
         `systeminfo` reading `N/A` means aperf's own IMDS calls failed. STOP (P2, R0)
  IF destination is 169.254.169.253 / fd00:ec2::253 / VPC CIDR base + 2
  THEN → VPC DNS, the most common answer. Go to STEP 4 (P1, R0)
  IF destination is 169.254.169.254 / fd00:ec2::254
  THEN → IMDS. Go to STEP 5 (P1, R0)
  IF destination is 169.254.169.123 / fd00:ec2::123
  THEN → Amazon Time Sync. Raise the chrony or NTP poll interval and drop aggressive polling:
         cheapest and safest of the three, drift the only symptom at risk (P2, R1)
       → verify: the poll rate falls and the exceeding intervals vanish while `chronyc tracking`
         offset stays in tolerance -- growing offset means you over-relaxed

STEP 4 — DNS: cut the query rate, in cost order.
  IF the runtime or resolver configuration multiplies queries -- `networkaddress.cache.ttl` of 0,
     per-request resolution, negatives uncached, A and AAAA on single-stack, `search` domains
  THEN → set sane positive and negative TTLs, resolve once per connection or pool, disable the
         unused address family, trim the search list and lower `ndots` -- Kubernetes' `ndots:5`
         alone is often 4-5x. All reversible; only the search-list trim breaks short names (P1, R2)
       → verify: query rate falls with request rate held constant AND short names and FQDNs both
         still resolve; an unchanged ratio means resolution is still per request somewhere
  IF no local caching resolver is present
  THEN → install one (systemd-resolved, dnsmasq, Unbound, NodeLocal DNSCache on Kubernetes): the
         highest leverage available. But it interposes a new component in EVERY lookup, so a
         misconfigured cache fails all resolution rather than degrading it (P1, R2)
       → verify: exceeding intervals reach ZERO at the same offered load AND cache hit rate is
         non-trivial; zero hits means the names were distinct and caching was the wrong lever
  IF the query rate is irreducible after all of the above
  THEN → move to a CUSTOM resolver: that traffic does not count against this allowance at all. The
         structural escape, but resolver availability becomes yours (P2, R3)
       → verify: this counter goes to zero AND resolution latency does not regress; falling while
         latency rises means you moved the problem

STEP 5 — IMDS: stop paying per request.
  IF credential refresh is FAILING, not merely frequent
  THEN → an availability incident: expired credentials fail every AWS API call the instance
         makes, not just the triggering request. Escalate ahead of the rate work (P0, R1)
       → verify: credential-refresh errors stop; still failing means a second cause
  IF a token is fetched per request, or credentials refresh on a TIMER rather than on expiry
  THEN → cache the token for its full lifetime and refresh on expiry. IMDSv2 costs a PUT then a
         GET, so token reuse alone HALVES the count -- and an IMDSv1-to-v2 migration doubles this
         traffic with no application change (P1, R1)
       → verify: request count halves and tracks credential lifetime, not the poll interval
  IF many processes or containers each fetch their own credentials and identity
  THEN → share one credential source and fetch instance identity ONCE at startup. On a dense
         host the dominant term, and a platform fix rather than an application one (P1, R1)
       → verify: request rate stops scaling with container count

STEP 6 — Did anything actually suffer, and whose traffic is it?
  IF latency shows intermittent MULTI-SECOND outliers with no CPU or I/O explanation
  THEN → the signature of this finding: resolver and SDK timeouts are seconds long and invisible
         in CPU and disk data, so this converts the counter into an impact statement (P1, R0)
       → verify: the outliers align in time with the exceeding intervals; if not, another cause
  IF a monitoring agent, log shipper, sidecar or package manager dominates `processes`
  THEN → the queries may be mostly not the workload's. Reduce that component's rate or move it,
         cheaper than any change to the serving path (P2, R1)
       → verify: re-record with the agent quiesced; the exceeding intervals should vanish
  IF exceeding intervals do NOT align with any latency or error excursion
  THEN → enforcement happened but nothing observable suffered. Record it and move on (P3, R0)

STEP 7 — What survives?
  VALID      : that the Nitro card dropped packets to the link-local proxy services against the
               PER-INTERFACE PPS ceiling -- enforcement, not inference; the exceeding-interval
               COUNT, the peak rate, the run TOTAL as a sum of one interface's series, the
               longest streak; that a resize cannot help, the allowance being fixed for all
               instance types; and the DNS/IMDS/Time-Sync scope, which excludes custom resolvers
  CAUTION    : any total on a run with `total_resets` non-zero (lower bound only); a
               sustained/pervasive verdict on <=10 intervals; and any impact claim resting on
               packet COUNT, since one drop costs seconds and the counter is not proportional
               to harm
  CONFOUNDED : any AVERAGE over the raw series, diluted by (n-1)/n by the forced first zero; the
               reported value when FRACTIONAL, a multi-interface mean hiding a one-packet peak;
               and any attribution to DNS, IMDS or Time Sync made WITHOUT a packet capture
  VOID       : any RANKING by score -- non-monotonic in [1.0, 2.0), -256.00 has two disjoint
               preimages, and a one-packet interval scores -0.00 and renders NEUTRAL mid-list;
               any recommendation to RESIZE, which cannot change a fixed allowance; any
               conclusion that the DNS query rate is low because this counter is zero, since
               custom-resolver traffic is not counted; and any citation of `netstat` UDP
               counters, which aperf does not collect

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205).
         In a container with only virtual interfaces nothing is collected, so absence proves
         nothing (P3, R0)
  IF `iftop`/`tcpdump` output is unavailable
  THEN → the service cannot be identified, so STEP 4-5 are guesses. STEP 0-2 still stand: rate,
         duration, and the fact that a resize cannot help (P2, R0)
  IF the question was "is my DNS query rate healthy?" and the finding did NOT fire
  THEN → absence is weak evidence twice over: the default `--period 10` observes ~9 real
         intervals, and a custom resolver's traffic is not counted here at all. Re-record with
         `--period 300` and confirm which resolver is in use (P3, R0)
```

## Runtime-specific consequences

The allowance is enforced below the OS, so every runtime is dropped identically — but each one's resolution
and credential behaviour decides how many packets it offers, and that is the whole finding.

- **Java.** The JVM's own DNS cache is the classic offender: `networkaddress.cache.ttl` of `0` means every
  lookup hits the resolver, a very long TTL breaks failover, and `negative.ttl` matters as much since uncached
  failures retry at full rate. The symptom is a multi-second stall inside `InetAddress` resolution, with
  `java_profile` showing threads parked in name resolution or credential fetch rather than in application work
  — and because resolution blocks, it looks like thread-pool exhaustion several layers up.
- **Go, Node and Python.** Most default to **no process-level DNS cache at all**, delegating to the OS resolver,
  which on a stock EC2 AMI also does not cache. So a per-request `getaddrinfo` becomes a per-request wire query,
  and the fix is necessarily *outside* the process — a local caching resolver.
- **AWS SDKs of any language.** Credential providers are the IMDS half of this finding. A provider refreshing
  on a timer, or instantiated per request rather than per process, multiplies IMDS calls directly; under
  IMDSv2 each fetch is a `PUT` plus a `GET`, so the same code costs twice the packets it did under v1. A
  client created per request is the single most common cause.
- **Containers and orchestrators.** Every container's SDK, sidecar and log agent resolves and fetches
  independently against **one interface's** fixed allowance with no per-container accounting, so density
  multiplies the offered rate while each container's own metrics look reasonable. Kubernetes adds `ndots:5`
  by default, often a 4–5× multiplier; NodeLocal DNSCache exists precisely for this.
- **Anything NTP-synced.** Time Sync drops surface as clock drift rather than latency, so they may go unnoticed
  for hours — and a stack that alerts on drift will blame the clock, not the network.

## Architecture-specific considerations

Architecture-independent in mechanism, and — uniquely in this family — **instance-independent in
threshold**.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and unlike the `perf_stat`
  family there is no per-architecture config to consult.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*` and
  `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container with
  only virtual interfaces **`ena_stat` collects nothing** and the rule cannot fire — silence is structural,
  not health, which matters here because containers are exactly where this finding is common.
- **The allowance does not vary with instance type or size.** This is the one page in the family where the
  `systeminfo` instance type is *not* the threshold's determinant. A `.metal` and the smallest size in the
  same family share the same fixed link-local budget, and a Graviton migration changes nothing either.
- **The allowance is per network interface**, unlike the other four, so ENI count is a genuine capacity
  parameter — and it also determines whether the `average` series can produce a fractional value at all (a
  single-ENI run drops the aggregate, `time_series_data_processor.rs:315`–`:319`).
- **There is no burst-credit behaviour.** The budget is a flat packet rate, so "zero then permanently
  non-zero" means the offered query rate rose, never that a credit balance drained — a different reading of
  the same shape than on the bandwidth pages. **ENA Express (SRD)** does not change this allowance either; an
  `ena_srd_*` finding alongside this one is a separate matter.

## Verification

The falsifiable claim is *packets to a specific link-local service were dropped for this fraction of the run, and
reducing that service's query rate removes the drops*. Verify in that order.

1. **Confirm the value is not the multi-interface artifact, and that the series is continuous.** A fractional
   reading means the true per-interface peak was one dropped packet — read the per-interface series; and
   `total_resets`, `interface_down`, `interface_up` must be zero or every total is a lower bound.
2. **Quantify rate and duration, and check the run is long enough.** `tools/aperf_ena_allowance.py --metric
   linklocal_allowance_exceeded --series <deltas>` — exceeding count, peak rate, total, sustained/pervasive
   verdict; check the score against `|score| / 256 + 1` and expect the −256.00 ambiguity. At the default
   `--period 10` roughly 9 real intervals are observed, which cannot separate a steady-state overrun from a run
   that captured only warm-up — re-record longer before ruling on duration.
3. **Confirm the constraint is link-local, not general.** The other four allowance counters at zero while byte
   volume sits far below the bandwidth ceiling is the characteristic pattern — and the reason the resize is off
   the table on evidence rather than on assertion.
4. **Name the service before predicting anything.** Capture with `iftop`/`tcpdump` against the three fixed
   addresses and check that the captured rate to that address accounts for the observed drop rate; a large
   shortfall means a second service contributes and a single-service fix will fall short. Predict in advance
   that the report holds **no** UDP corroboration — see *Do not* — so its absence is not a result.
5. **Find the damage, and rule out the impostors.** Look for latency outliers aligned in time with the exceeding
   intervals, plus `TCPTimeouts`/`TCPSynRetrans` and credential-refresh error rates; if nothing moved, drops
   happened but no caller observed it — report that plainly. A slow *upstream* resolver, pool exhaustion and CPU
   saturation all produce similar tails, so if one is present, predict *before* the fix that repairing it leaves
   this counter unchanged; a change falsifies the attribution.
6. **After remediation, predict zero — and predict the absence of a new symptom.** At the same offered load the
   exceeding-interval count must be **zero**, not merely lower. For the R2 and R3 changes state the second
   prediction too: short names and FQDNs both still resolving after an `ndots` change, resolution latency flat
   after a local cache or custom resolver, clock offset in tolerance after relaxing the NTP poll.

## Do not

- **Do not resize the instance, or blame its size for the latency tail.** The link-local allowance is **fixed for
  all instance types** (`optimization-guides.ts:146`) — the most common wrong response to this finding, and wrong
  by definition rather than by degree; the only capacity levers are scaling out and adding an ENI. Idle CPU with
  multi-second outliers is this finding's signature, not an under-provisioning signal (`underutilized-cpu.md`).
- **Do not dismiss this finding because the score is small or zero, and do not rank it by score.** One dropped
  query in an interval scores −0.00 and renders with a neutral face, greyed out, sorted mid-list, while the
  rule is `Critical`. The formula is non-monotonic in [1.0, 2.0), −256.00 is produced both by any sub-unit
  value and by exactly 2.0, and a 100-packet interval scores −25 344.00.
- **Do not read the packet count as the size of the impact.** Each drop is an unanswered DNS, IMDS or NTP
  request and the caller pays a multi-second timeout, so unlike the bandwidth findings a small delta does not
  mean small harm.
- **Do not read the value as a run total, or average the raw series.** It is a per-interval delta; sum one
  interface's series for the total, and the forced first zero dilutes any average by (n−1)/n. And **do not read
  a fractional value as a real packet count** — it is a multi-interface mean that out-scored the real series,
  meaning the true per-interface peak was exactly one dropped packet.
- **Do not guess which service is responsible.** DNS, IMDS and Time Sync share one counter and have entirely
  unrelated fixes. Identify the destination with `iftop`/`tcpdump` first, and if you cannot, say the finding is
  not root-causable from this report.
- **Do not look for UDP counters, or resolver configuration, in the report.** aperf reads only
  `/proc/net/netstat` (`netstat.rs:33`), which carries `TcpExt:` and `IpExt:` and **no UDP section** — those
  live in `/proc/net/snmp`, which no collector reads — so DNS's own packets are invisible; and nothing collects
  `/etc/resolv.conf` or `nsswitch.conf`, while `sysctl` has no DNS keys, so `ndots`, the `search` list and
  cache presence must be read on the instance.
- **Do not treat the cheap fixes as risk-free.** A local caching resolver interposes a new component in every
  lookup on the box (R2), an `ndots` change alters resolution semantics and can break short names (R2), and a
  custom resolver makes resolver availability your problem (R3).
- **Do not chase EFA because the message says "EFA".** All five allowance messages name the wrong device; this is
  an ENA metric read by `ethtool -S`. The remediation half of the same message is correct.
- **Do not treat absence of the finding as proof of health, or as evidence of a low query rate.** The first
  point is a structural zero, the default `--period 10` observes about 9 real intervals, and queries to a
  **custom** resolver are explicitly not counted — removing DNS from this counter's scope entirely.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:48`–`:54` (`Comparator::Greater`, threshold `0.0`,
  `Score::Critical`; `"EFA"` at `:53` is an upstream defect, but its caching advice is correct and is the only
  remediation any of the five carries), template
  `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` (largest `|score|` over every series,
  aggregate included), and score formula `compute_finding_score`, `src/analytics/mod.rs:167`–`:176`.
- Delta processing: forced first zero at `time_series_data_processor.rs:218`/`:73`, dropped decrease at
  `:202`–`:214`, both inside `get_delta_and_set_previous_value` (`:189`–`:224`); the `average` aggregate, its
  `sum/count` mode and its single-ENI suppression, `src/data/ena_stat.rs:315`, `:249`–`:256`, `:315`–`:319`.
- Metric description: `linklocal_allowance_exceeded`,
  `src/report_frontend/src/definitions/data-descriptions.ts:3838`–`:3845` — *"the maximum for the **network
  interface**"* where the other four say "for the instance", and the explicit exclusion of custom resolvers.
- Upstream guide: `EC2_NETWORK_LINK_LOCAL_ALLOWANCE_RECOMMENDATIONS`,
  `src/report_frontend/src/definitions/optimization-guides.ts:146` — source of *"The link-local allowance is
  fixed for all instance types"*, the `iftop`/`tcpdump` step, the ranges and the three service addresses.
- The collection gap: `NetstatRaw::collect_data` reads only `/proc/net/netstat` (`src/data/netstat.rs:33`),
  which has no UDP section — a tree-wide search for `proc/net` returns that single hit, so `/proc/net/snmp` is
  never read; `SysctlData` collects the whole tree except `rss_key` (`src/data/sysctl.rs:30`–`:60`) and has no
  resolver keys. aperf's own IMDS use: five one-shot calls at `src/data/systeminfo.rs:97`–`:106`, `is_static()`
  true at `:147`, `"N/A"` substituted on failure at `:135`–`:141`.
- Zero-score rendering: `AnalyticalFindings.tsx:35`, `:44`–`:52`; ascending score sort,
  `src/report_frontend/src/utils/analytics.tsx:40`. Collection: `Ethtool::new` filter, `ena_stat.rs:190`–`:205`;
  `SIOCETHTOOL` ioctl, `:31`–`:33`. Quantifier:
  [`../tools/aperf_ena_allowance.py`](../tools/aperf_ena_allowance.py) `--metric
  linklocal_allowance_exceeded` (`aggregate_masks_the_peak()`).
- [Instance Metadata Service (IMDS)](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instancedata-data-retrieval.html),
  [Amazon Route 53 Resolver / VPC DNS](https://docs.aws.amazon.com/vpc/latest/userguide/AmazonDNS-concepts.html),
  [Amazon Time Sync Service](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/set-time.html),
  [Monitor network performance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
- Related: `pps-exceeded-instance-allowance.md` (the same packets against the instance-wide ceiling),
  `connection-tracking-exceeded-instance-allowance.md` (the other per-request overhead, usually one root
  cause), `underutilized-cpu.md` (idle CPU with a latency tail).
