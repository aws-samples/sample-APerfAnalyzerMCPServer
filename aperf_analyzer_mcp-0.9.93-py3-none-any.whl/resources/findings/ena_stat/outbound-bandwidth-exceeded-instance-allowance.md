---
rule_name: Outbound Bandwidth Exceeded Instance Allowance
data_type: ena_stat
data_key: bw_out_allowance_exceeded
template: time_series_data_point_threshold
condition: "any(bw_out_allowance_exceeded) > 0.0"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "EFA is queuing or dropping packets due to exceeding the instance's outbound bandwidth allowance."
source: src/analytics/rules/ena_stat.rs:24
---

# Outbound Bandwidth Exceeded Instance Allowance

## What fired

**At least one** interval delta of `bw_out_allowance_exceeded` was **greater than 0.0** — the Nitro
card queued or dropped at least one outbound packet because the instance's aggregate outbound
bandwidth allowance was exceeded.

Base score `Critical` (**−256**). Single-run rule, `Comparator::Greater`, threshold `0.0`
(`ena_stat.rs:24`).

Like its inbound twin, this is **not a heuristic** — it is a hardware enforcement counter. The Nitro
card incremented it because it actually shaped or dropped traffic. The question is never *whether*
shaping happened, only **RATE and DURATION**: a 3-packet blip and a 40-minute shaping event fire this
rule identically.

> **The message names the wrong device.** aperf says *"EFA is queuing or dropping packets"*. All five
> `ena_stat` allowance rules (`ena_stat.rs:21`, `:29`, `:37`, `:45`, `:53`) say "EFA" when they mean
> **ENA**. The metric is read by the `ethtool` ioctl on the ENA interface (`ena_stat.rs:235`); Elastic
> Fabric Adapter is a different device with its own data type and rules. The `data-descriptions.ts`
> entries for these same metrics (`:3817`–`:3851`) are correct. Do not let the finding text redirect
> the investigation toward EFA.

## The processing caveat — verified by simulating the collection loop

Three properties of `ena_stat`'s processing change what the number means, and one of them makes the
reported value **fractional and misleading** in a narrow but reachable case.

**1. The series is already a per-interval delta.** `add_accumulative_data_point`
(`ena_stat.rs:343`) stores `current − previous` between `ethtool` snapshots. At the default
`--interval 1` (`record.rs:35`) each point is "packets shaped in about one second". Summing the series
gives the run total; the reported value is one interval.

**2. The first point is a forced zero covering no elapsed time.**
`get_delta_and_set_previous_value` finds no previous value, takes the `None` arm
(`time_series_data_processor.rs:218`), and returns `0.0` because `ignore_first_accumulative_value`
defaults to `true` (`:73`). Only `perf_stat` opts out (`perf_stat.rs:1295`); `ena_stat` never does. An
n-snapshot run therefore yields an n-point series over **(n−1) × interval** seconds, so any *average*
over the raw series is diluted by (n−1)/n. Sums, peaks and streaks are unaffected.

**3. The auto-generated `average` series can WIN the rule's selection and print a fractional packet
count.** `ena_stat` aggregates with `time_series_data_processor_with_average_aggregate`
(`ena_stat.rs:315`), so a multi-ENI instance gains an `average` series that is the **mean** across
interfaces, and the rule iterates every series including it. Because the `threshold == 0.0` branch
pins every value below 1.0 at the flat **−256.00** while exactly 1.0 scores **−0.00**, a one-packet
peak is out-scored by its own sub-unit mean:

| series | value | \|score\| | selected? |
|---|---|---|---|
| `eth0` | 1.0 | **0.00** | no |
| `eth1` | 0.0 | — | does not fire |
| `average` | **0.5** | **256.00** | **yes — reported** |

Brute-forcing 1,596 combinations over 2/3/4/8 ENIs with peaks in {0, 1, 2, 3, 5, 10, 47, 1000} found
the artifact in exactly 22 cases, and **the peak per-interface delta was 1 in every one**. At a peak of
2 the real series scores −256.00 and wins outright, so the window is not a range — it is the single
value 1.0:

> **A fractional value in the description means the true per-interface peak was exactly ONE packet.**
> The mildest possible reading of a `Critical` finding, reported with the most severe score a small
> delta can produce.

Two scope limits, both verified: the queue split at `ena_stat.rs:332` fires only for names of the form
`queue_<n>_...`, and none of the five allowance metrics match — so these are always **one series per
interface**, never per queue. And on a single-ENI instance the aggregate is **dropped before
rendering** (`time_series_data_processor.rs:315`–`:319` retains only non-aggregate series when
`len() == 2`), so the artifact needs **two or more ENIs** to exist at all.

`tools/aperf_ena_allowance.py` carries all of this; `aggregate_masks_the_peak()` returns the verdict,
and `tools/test_aperf_ena_allowance.py` re-derives the 1.0 bound over 2,044 combinations.

## Reasoning

`bw_out_allowance_exceeded` is the *"Number of packets queued or dropped because the outbound
aggregate bandwidth exceeded the maximum for the instance."* (`data-descriptions.ts:3824`,
`desired: "lower"`)

The Nitro card enforces a bandwidth ceiling on egress **independently of and simultaneously with** the
inbound ceiling. Exceeding it means packets are first queued — adding latency and jitter — then
dropped. Both increment this counter.

**Three things make the outbound case different from the inbound case, and more actionable:**

1. **You control the sender.** The shaped traffic is generated by your own instance, so throttling,
   batching, compressing, or simply sending less is directly available. Inbound shaping has no
   equivalent lever, which is why the remediation order on this page starts with payload size rather
   than with a resize.
2. **The feedback loop is tighter and genuinely self-reinforcing.** Your retransmissions must leave
   through the *same* shaped egress path. Dropped outbound packets trigger retransmits, which consume
   more of the egress budget you have already exhausted, which causes more drops. Inbound shaping does
   not close this loop locally.
3. **Egress is often the invisible ceiling.** Services that receive small requests and return large
   responses — file servers, media delivery, query APIs returning big result sets, replication
   sources — hit the egress ceiling long before the ingress one, while a dashboard showing request rate
   looks entirely healthy.

For TCP a dropped packet is a congestion signal, not merely lost data: the *local* congestion-control
state backs off, so the instance throttles itself below the allowance. Throughput collapses, tail
latency rises by at least an RTT per recovery (often a full RTO), and clients see timeouts. The
relation between drop count and impact is strongly non-linear.

Common causes: instance too small for the egress volume (allowance scales with size); **burst-credit
exhaustion** — smaller sizes sustain above-baseline egress only while credits last, so a workload that
passed a ten-minute test starts being shaped an hour in with no change in traffic; large response
payloads (uncompressed bodies, whole objects where a projection would do); fan-out amplification, one
inbound request producing many outbound calls; replication, backup or log shipping competing with
serving traffic; retransmission amplification, self-sustaining once started; and **aggregate across
interfaces** — the allowance is per *instance* while the counter is per *interface*, so a multi-ENI
instance can exceed the ceiling with no single interface looking saturated.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 7 (greater than the threshold of 0).
```

The value is the **worst single interval delta across every series**, not a total and not an average.
Values at or above 1000 print with a K/M/G/T suffix (`formatted_number_string`,
`computations/mod.rs:176`–`:190`), so a severe run may read `12.40K`.

**Score math takes the `threshold == 0.0` branch** of `compute_finding_score` (`analytics/mod.rs:170`):

```
if value < 1.0  →  score = rule_score               (flat −256)
else            →  score = (value - 1.0) * rule_score
```

| worst delta | score | note |
|---|---|---|
| 0.50 | **−256.00** | fractional ⇒ multi-ENI mean; true peak was 1 packet |
| **1.00** | **−0.00** | **one packet in an interval scores zero** |
| 2.00 | **−256.00** | collides with the 0.50 score |
| 7.00 | **−1536.00** | |
| 12 400 | **−3 174 144.00** | |

Recover the delta as `|score| / 256 + 1`, but **−256.00 is ambiguous**: it is produced both by the
flat branch (any value below 1.0) and by exactly 2.0 on the linear branch. Disambiguate from the
description's value text, never from the score.

**Two traps, both confirmed by running the engine:**

- **`1.00 → −0.00` renders as NEUTRAL.** `FindingIcon` returns the `zero` icon (`face-neutral`) for
  `score == 0` and `getFindingColor` greys it out (`AnalyticalFindings.tsx:35`, `:44`–`:52`). Findings
  sort ascending by score (`analytics.tsx:40`), so this `Critical` finding lands **mid-list**, below
  every `Concerning` finding, with a neutral face beside it. At the default page size of 5 it will not
  be on the first page.
- **The score is non-monotonic.** Every delta in [1.0, 2.0) scores *closer to zero* than any delta
  below 1.0. A larger value can score better.

**Never triage this rule by score. Check whether the finding exists at all.** And do not compare these
scores with anything else in the report: a 7-packet interval scores −1536.00, six times the base
`Critical` value.

## Interpretation

Enforcement is a fact, so the question is **how much of the run was affected**:

| Pattern in the series | Reading |
|---|---|
| One interval, small delta | A brief burst exceeded the allowance. Real but possibly harmless; correlate with a known event |
| Sustained non-zero across the run | **The instance is egress-bandwidth-limited.** A leading bottleneck |
| Zero, then non-zero from some point on, never recovering | **Burst-credit exhaustion.** The traffic did not change; the allowance did |
| Periodic bursts | Aligned with a batch job, replication cycle, log flush, or GC-driven backlog drain |
| Ramp that grows over the run | Suspect retransmission amplification — the loop feeding itself |
| Fractional value | Multi-ENI mean out-scored the real series. **True per-interface peak was one packet** |

Combinations that change the diagnosis:

| also fired / observed | Reading |
|---|---|
| `Inbound Bandwidth Exceeded Instance Allowance` | Both directions shaped. Strongly indicates the instance is undersized rather than a payload problem |
| `PPS Exceeded Instance Allowance` **only**, bandwidth zero | Not this finding's case — small packets. See that playbook |
| `PPS Exceeded Instance Allowance` **and** this | Both ceilings hit; a resize addresses both |
| `tx_queue_stop` / `tx_queue_wakeup` elevated | The transmit path is backing up in the driver too — consistent with egress saturation |
| `tx_linearize`, `tx_dma_mapping_err`, `tx_prepare_ctx_err` non-zero | **Different** transmit-path problems (packet layout, DMA), not the allowance. Separate fixes |
| TCP retransmits elevated (`netstat`) | Confirms the self-reinforcing loop: retransmits consuming the exhausted egress budget |
| `Underutilized CPU` | **The classic bandwidth-bound signature**: CPU idle because the workload waits on the network. Do not "fix" the CPU |
| `Increased I/O Wait Time` | On NFS/EFS-backed storage, writes traverse the shaped egress path. Same event, two views |
| `total_resets` non-zero | The series has silent gaps — the total is a lower bound by an unknown amount |
| `ena_srd_*` findings | ENA Express affects throughput and tail latency but does not change the allowance |

**Known false positives — none of them make the enforcement unreal:**

- **A single interval with a tiny delta.** Enforcement happened; a one-off microburst may have no
  measurable application impact. Judge from the series, not the firing.
- **A fractional value.** Not a false positive about *whether* it happened, but the magnitude is a mean
  and the true per-interface peak was one packet.
- **Egress not generated by the workload under test.** Backup agents, log shippers, monitoring
  pipelines, and package updates all produce egress. Check `processes`.
- **The recording captured a bulk-transfer, warm-up, or teardown phase** rather than steady state.
- **Counter reset or interface flap.** A decrease is *dropped* (`:202`–`:214`) rather than emitted as a
  bogus spike, so a reset yields a gap; `total_resets` or `interface_down` non-zero means the series is
  not continuous.
- **A very short run.** The first point is a structural zero, so a 2–3 snapshot recording can miss
  enforcement entirely. Absence is not evidence.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `bw_out_allowance_exceeded` full series, **per interface** | `ena_stat` | **Do this first.** Sustained vs burst vs credit exhaustion, and the real per-interface counts behind any fractional value |
| `tx_bytes`, `tx_cnt` per queue | `ena_stat` | Actual egress volume, packet rate, and mean packet size — how close to the ceiling |
| `bw_in_allowance_exceeded` | `ena_stat` | Whether both directions are shaped. See `Inbound Bandwidth Exceeded Instance Allowance` |
| `pps_allowance_exceeded` | `ena_stat` | Whether the packet-rate ceiling is also hit. See `PPS Exceeded Instance Allowance` |
| `tx_queue_stop`, `tx_queue_wakeup` | `ena_stat` | Driver-level transmit backpressure. **No rules fire on these** — read manually |
| `tx_linearize`, `tx_linearize_failed`, `tx_dma_mapping_err`, `tx_prepare_ctx_err` | `ena_stat` | **Different** transmit failures, not allowance. Read manually |
| `tx_doorbells` vs `tx_cnt` | `ena_stat` | Batching efficiency — many doorbells per packet means poor batching, which raises CPU cost but not the allowance |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the counter series is continuous |
| `num_of_active_io_queues` | `ena_stat` | Transmit parallelism available |
| `Instance Type` | `systeminfo` | **The allowance is a property of this value.** Required to know the ceiling |
| TCP retransmit and error counters | `netstat` | The self-reinforcing loop — retransmits competing for exhausted egress |
| `idle`, `aggregate`, `iowait` | `cpu_utilization` | Idle CPU with shaped egress = bandwidth-bound. See `Underutilized CPU` |
| `softirq`, `system` | `cpu_utilization` | Network-stack cost of the transmit path |
| Per-process activity | `processes` | Whether an unrelated agent is producing the egress. **No analytical rules — read manually** |
| `interrupts` distribution | `interrupts` | Transmit-completion interrupt concentration. **No analytical rules — read manually** |

## Guidance

Ordered. Step 1 is not "is it real" — it is "how much of the run".

1. **Read the full series, per interface, and quantify rate and duration.**
   `python3 tools/aperf_ena_allowance.py --metric bw_out_allowance_exceeded --series <deltas>` gives
   exceeding-interval count, peak rate, total, and the sustained/pervasive verdict. Sustained non-zero
   ⇒ egress-bandwidth-limited, highest priority. Zero then permanently non-zero ⇒ burst-credit
   exhaustion. Isolated burst ⇒ correlate before escalating. Fractional ⇒ the true peak was one packet.

2. **Never triage by score.** One packet per interval scores −0.00 and renders with a neutral face;
   seven score −1536.00. Presence of the finding is the signal.

3. **Establish the actual ceiling.** Read `Instance Type` from `systeminfo` and compare measured egress
   (`tx_bytes` summed across **queues**, over the interval) against the documented allowance for that
   type. This converts "we were shaped" into "we need N Gbps" — the number that sizes the fix. Never
   sum the aggregate; it is a mean.

4. **Separate allowance drops from other transmit-path failures.** Check `tx_linearize`,
   `tx_linearize_failed`, `tx_dma_mapping_err`, `tx_prepare_ctx_err`, and `tx_queue_stop`. Those have
   unrelated fixes and coexist with shaping; misattributing them buys a pointless instance upgrade.

5. **Quantify the consequence, not just the cause.** Read TCP retransmits in `netstat` and check
   `Underutilized CPU`. Retransmits contending for already-exhausted egress is the mechanism that turns
   a small drop count into a throughput collapse, and it is the number that justifies remediation.

6. **Check whether the egress is even yours.** Inspect `processes` for backup, log-shipping, or
   monitoring agents. Shaping caused by a sidecar is fixed by scheduling it, not by resizing.

7. **Remediate**, per `EC2_NETWORK_BANDWIDTH_ALLOWANCE_RECOMMENDATIONS` — and note that unlike the
   inbound case, the first four levers are entirely under your control, so try them before spending:
   - **Reduce payload size** — compress responses, return projections instead of whole objects,
     eliminate over-fetching. Usually the cheapest and largest win, and it needs no infrastructure
     change.
   - **Reduce fan-out** — batch or coalesce outbound calls; cache to avoid re-sending the same data.
   - **Pace your own egress** so the sender backs off *before* the Nitro card drops. This avoids both
     the TCP-recovery penalty and the retransmission-amplification loop, which no amount of extra
     bandwidth undoes once it has started.
   - **Move bulk transfers off the serving path** — schedule backups, replication catch-up, and log
     shipping outside peak, or isolate them on their own instance.
   - **Scale up** — allowance scales with instance size. The direct fix when the counter is
     persistently above zero and payload reduction is exhausted.
   - **Scale out or rebalance** — behind a load balancer, add instances; but check first for traffic
     concentration (uneven hashing, a hot shard), which is far cheaper to rebalance than to resize.

## Priority and execution risk

**Priority: P1 — Act now** when the exceedance is sustained (≥5 consecutive intervals) or pervasive
(≥25% of intervals), because the enforcement is measured rather than inferred and the TCP consequences
are non-linear and self-reinforcing on the egress side. It rises to **P0 — Emergency** when shaping is
pervasive *and* the application is missing its SLO *and* `Underutilized CPU` also fired — the
bandwidth-bound collapse, where the instance is doing nothing but waiting to transmit. It drops to
**P3 — Monitor** for a single exceeding interval with no correlated latency excursion, and to
**P4 — Informational** when the value is fractional (true peak one packet) or when the egress is
attributable to a sidecar rather than the workload. Note the asymmetry with the score: the P4 case is
precisely where the score reads **−256.00**, and the P3 case is where it can read **−0.00**.

**Execution risk: R0 — Read-only** to resolve: the series, the per-interface split, the rate and
duration arithmetic, the ceiling lookup, and the `netstat` correlation are all reads. Acting spans the
range, and on the egress side the cheap options come first. **R1** for reducing payload size, enabling
compression, batching, or rescheduling a bulk transfer — reversible, and the highest-value-per-risk
option this finding offers. **R2** for scaling out behind a load balancer or rebalancing a hash, which
changes traffic distribution but not the application. **R3 — Resize** for an instance change, because
it requires a stop/start or replacement, moves instance-store data, and may change the CPU generation
along with the bandwidth. **R4** where egress pacing or a rate limiter is introduced into the response
path, since a misconfigured limit delays or sheds responses that would otherwise have succeeded. **Do
not inherit the R0 of the reading into the resize.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `bw_out_allowance_exceeded` interval delta, on any series including the
auto-generated `average`, was `> 0.0`.

```
STEP 0 — Is the reported VALUE trustworthy? Check this before reading anything into it.
  IF the value is FRACTIONAL (e.g. 0.50, 0.33)
  THEN → the auto-generated `average` series out-scored every real interface. Brute force
         over 1,596 multi-ENI combinations puts this artifact at a true per-interface peak
         of EXACTLY 1 packet, so the event is a ONE-PACKET microburst reported with a
         -256.00 score -- the mildest reading this rule can produce (P4, R0)
       → verify: read the per-interface series directly; the peak must be 1
  IF `total_resets` or `interface_down` is non-zero
  THEN → the ENA driver reset mid-run. A counter DECREASE is dropped entirely
         (time_series_data_processor.rs:202-:214) while the baseline still advances, so
         events between those snapshots are LOST. Every total below is a lower bound
         (P2, R0)
  IF the series has fewer than 4 points
  THEN → the first point is a structural zero, so 2-3 snapshots cover 1-2 real intervals.
         Neither rate nor duration is establishable. Re-record with `--period 300`
         (P2, R0)
       → verify: series length minus 1 equals the number of intervals actually covered
  OTHERWISE
  THEN → the value is a genuine worst-interval delta. Continue (P2, R0)

STEP 1 — Rate and duration. This, not the firing, is the finding.
         `tools/aperf_ena_allowance.py --metric bw_out_allowance_exceeded --series <deltas>`
  IF exceeding in >=5 CONSECUTIVE intervals AND >=25% of intervals
  THEN → the egress ceiling is this workload's steady state. A sizing or payload problem,
         not an excursion. Go to STEP 3 (P1, R0)
  IF the exceeding count GROWS monotonically across the run
  THEN → suspect retransmission amplification: drops force retransmits, which consume the
         same exhausted egress budget. Pacing breaks the loop; more bandwidth alone may not
         (P1, R1)
       → verify: `netstat` retransmits rise in step with the exceeding intervals. Flat
         retransmits mean the growth is offered load, not amplification
  IF sustained (>=5 consecutive) but not pervasive
  THEN → a real ceiling during one phase. Identify the phase before resizing for it; a
         bulk-transfer phase may be acceptable or reschedulable (P2, R0)
  IF exactly ONE exceeding interval
  THEN → a microburst. Correlate with application latency before spending anything
         (P3, R0)
       → verify: application p99 in that second. No excursion means no action
  IF intermittent (several intervals, longest streak < 5)
  THEN → bursty. Fix the traffic SHAPE first: pacing, batching, compression, smaller
         payloads (P2, R1)
       → verify: re-record and confirm the exceeding-interval count falls; if the peak
         merely moved, the burst was shifted rather than removed

STEP 2 — Is this the ALLOWANCE, or a different transmit-path failure?
  IF `tx_linearize_failed`, `tx_dma_mapping_err` or `tx_prepare_ctx_err` is non-zero
  THEN → those are packet-layout and DMA failures, NOT allowance shaping, and their fixes
         are unrelated. Attributing them to the allowance buys a useless upgrade. Fix them
         separately and re-measure (P2, R1)
       → verify: after the transmit-path fix, `bw_out_allowance_exceeded` should be
         UNCHANGED -- it is a distinct mechanism. If it moved, the attribution was wrong
  IF `tx_queue_stop` is elevated but the allowance counters are near zero
  THEN → the driver ring is filling without the Nitro card shaping: a queue-count, CPU, or
         doorbell-batching problem. Check `num_of_active_io_queues` and `tx_doorbells` per
         `tx_cnt` (P2, R1)
       → verify: after raising the queue count or improving batching, `tx_queue_stop` falls
         while `bw_out_allowance_exceeded` is unchanged. Both moving means one mechanism
  OTHERWISE
  THEN → allowance shaping is the mechanism. Continue (P1, R0)

STEP 3 — Size the fix. "We were shaped" is not actionable; "we need N Gbps" is.
  IF per-queue `tx_bytes` are available
  THEN → sum the PER-QUEUE series (never the aggregate, which is a mean, ena_stat.rs:315),
         convert to Gbit/s, and compare against the documented allowance for the
         `Instance Type` in systeminfo. That ratio sizes the instance (P1, R0)
  IF mean packet size (`tx_bytes` / `tx_cnt`) is LARGE and payloads are uncompressed
  THEN → reduce what you send before buying bandwidth: compression, projections instead of
         whole objects, no over-fetching. This is the egress-only lever and it is cheap
         (P1, R1)
       → verify: `tx_bytes` per request falls measurably; if only `tx_cnt` changed, the
         payload was not the issue
  IF measured egress is well BELOW the documented allowance yet shaping occurred
  THEN → either burst credits were exhausted (the ceiling fell, the traffic did not rise)
         or sub-second bursts are hidden by the 1s interval. Same fix, different reasons --
         say which (P2, R0)
       → verify: a zero-then-permanently-nonzero series shape confirms credit exhaustion;
         a flat-average-with-spikes shape confirms sub-second bursting
  IF the instance is multi-ENI
  THEN → the allowance is per INSTANCE while the counter is per INTERFACE, so the ceiling
         can be exceeded while no single interface looks saturated. Sum across interfaces
         (P1, R0)

STEP 4 — Quantify the CONSEQUENCE. This is what justifies the spend.
  IF `netstat` retransmits are elevated AND `Underutilized CPU` also fired
  THEN → the bandwidth-bound collapse: drops trigger local TCP backoff, throughput falls
         below the allowance, and the CPU idles waiting to transmit. Do NOT "fix" the idle
         CPU -- it is the symptom (P0, R3)
       → verify: after the resize, retransmits fall AND CPU utilization RISES. If CPU stays
         idle, the bottleneck was elsewhere
  IF shaping intervals do NOT align with any latency or error excursion
  THEN → enforcement happened but no client observed it. Record it and move on; a Critical
         score is not by itself a business case (P3, R0)

STEP 5 — Whose egress is it, and which lever?
  IF a backup, log-shipping, or monitoring agent is active in `processes`
  THEN → reschedule it out of the serving window, or move it to its own instance. Cheaper
         than resizing and it does not touch the serving path (P2, R1)
       → verify: re-record without the agent; the exceeding intervals should vanish
  IF egress is concentrated on ONE instance in a fleet
  THEN → an uneven hash or a hot shard, not a global sizing problem. Rebalance instead of
         resizing the whole fleet (P1, R2)
       → verify: compare `tx_bytes` across fleet members; a single outlier confirms
         concentration
  IF payload and fan-out reduction are exhausted and the egress is steady-state
  THEN → scale UP from the STEP 3 number (R3: stop/start or replacement, instance-store
         data moves, CPU generation may change), or scale OUT behind a load balancer
         (P1, R3)
       → verify: after the change, re-record and confirm ZERO exceeding intervals at the
         same offered load. Nonzero means the new size is still short
  IF responses can be paced or rate-limited at the source
  THEN → pacing avoids the drop, and therefore the TCP-recovery penalty and the
         amplification loop, entirely. But a misconfigured limit delays or sheds responses
         that would have succeeded (P2, R4)
       → verify: shaping stops AND the application's p99 and success rate do not degrade

STEP 6 — What survives?
  VALID      : that the Nitro card queued or dropped outbound packets -- this is hardware
               enforcement, not inference; the exceeding-interval COUNT, the peak per-second
               rate, the run TOTAL as a sum of the series, and the longest streak
  CAUTION    : any total on a run with `total_resets` non-zero (lower bound only); a
               sustained/pervasive verdict on a run of <=10 intervals, where the default
               `--period 10` cannot distinguish sustained shaping from a run that ended
               mid-burst; and any retransmission-amplification claim not corroborated by
               `netstat`
  CONFOUNDED : any AVERAGE over the raw series, diluted by (n-1)/n by the forced first
               zero; the reported value when FRACTIONAL, which is a multi-ENI mean hiding a
               one-packet peak; and any instance-total egress read off the `average` series,
               which is a mean and understates by the series count
  VOID       : any RANKING of this finding by score -- the formula is non-monotonic in
               [1.0, 2.0), -256.00 has two disjoint preimages, and a one-packet interval
               scores -0.00 and renders NEUTRAL mid-list; and any claim that transmit-path
               failures (tx_linearize, tx_dma_mapping_err, tx_queue_stop) are allowance
               shaping

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:205).
         Absence proves nothing about the allowance (P3, R0)
  IF the finding did NOT fire and the question was "am I egress-limited?"
  THEN → absence is weak evidence at the default `--period 10`: the first point is a
         structural zero, so ~9 real intervals were observed. Re-record with
         `--period 300` before concluding health (P3, R0)
  IF `Instance Type` is missing from systeminfo
  THEN → the allowance cannot be looked up, so shaping cannot be converted into a target
         throughput. The shape verdict from STEP 1 still stands (P2, R0)
```

## Runtime-specific consequences

The allowance is enforced below the OS, so every runtime is shaped identically — but what each does
*in response* differs, and that changes the symptom you will be shown.

- **Any TCP workload.** The kernel's congestion control reacts to the drop, not the application, so the
  application's own metrics under-report the cause. On egress the backoff is *local*, which is why
  measured throughput ends up below the allowance rather than pinned at it.
- **UDP workloads.** No backoff and no retransmission: the packet is simply gone. Shaping shows up as
  silent data loss rather than latency, and the drop count maps far more directly to lost work.
- **Java.** Shaped egress blocks NIO writes and fills write buffers; the visible symptom is often a
  rising queue depth or thread-pool exhaustion several layers from the network. `java_profile` will show
  threads parked in socket writes rather than doing work.
- **Containers.** The allowance belongs to the **instance**, not the container. Several containers
  sharing one ENI compete for one ceiling with no per-container accounting, so a chatty log shipper
  shapes the primary workload and neither container's own metrics show why.
- **Multi-ENI setups.** Adding an interface does **not** add allowance — it is per instance. The most
  expensive misconception on this page, because attaching an ENI looks like it should help and cannot.
- **NFS/EFS-backed storage.** Writes leave through the shaped egress path, so shaping appears as I/O
  wait rather than network trouble; see `Increased I/O Wait Time`. One event, two views.

## Architecture-specific considerations

This finding is architecture-independent in mechanism but instance-dependent in threshold.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically. Unlike the `perf_stat`
  family there is no per-architecture config to consult.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` to exist (`ena_stat.rs:190`–`:205`). Inside
  a container with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot fire —
  silence there is structural.
- **The allowance is a property of instance type and size, not of the CPU.** A same-size Graviton and
  x86 instance in the same family generally carry the same network allowance, so a Graviton migration
  does not change this ceiling.
- **Burst vs baseline bandwidth is size-dependent.** Smaller sizes in a family run a baseline well
  below their burst ceiling and rely on credits; the largest size in a family typically has no burst
  behaviour at all. That is why the "zero then permanently non-zero" signature appears on small
  instances and essentially never on `.metal` or the largest size.
- **`.metal` and the largest family sizes** give the full non-shared allowance, which is why moving to
  them removes credit-exhaustion behaviour rather than merely raising the number.
- **ENA Express (SRD)** changes single-flow throughput and tail latency but **not** the instance
  allowance. An `ena_srd_*` finding alongside this one is a separate matter; do not expect enabling it
  to stop the shaping.

## Verification

The falsifiable claim is *the instance's egress ceiling was reached for this fraction of the run, and
reducing what we send — or raising the ceiling — removes the shaping*. Verify in that order.

1. **Confirm the value is not the multi-ENI artifact.** A fractional reading means the true
   per-interface peak was one packet; read the per-interface series and confirm.
2. **Confirm the series is continuous.** `total_resets`, `interface_down`, `interface_up` all zero.
   Otherwise every total is a lower bound.
3. **Quantify rate and duration.** `tools/aperf_ena_allowance.py --metric bw_out_allowance_exceeded
   --series <deltas>` — exceeding count, peak rate, total, sustained/pervasive verdict. Check the score
   against `|score| / 256 + 1` and expect the −256.00 ambiguity.
4. **Convert to a throughput target.** Sum the **per-queue** `tx_bytes` (never the aggregate mean),
   express in Gbit/s, and compare with the documented allowance for the instance type.
5. **Test the payload lever before the resize.** Compute `tx_bytes / tx_cnt`. If the mean packet is
   large and uncompressed, predict that compression cuts egress by a stated factor — this is the one
   prediction this finding lets you make without spending anything.
6. **Correlate with the consequence.** Retransmits in `netstat` and idle CPU in `cpu_utilization`. If
   neither moved during the exceeding intervals, the shaping had no observed cost — report that plainly
   rather than escalating.
7. **Rule out the impostors.** `tx_linearize_failed`, `tx_dma_mapping_err`, `tx_queue_stop`. If any is
   non-zero, predict *before* the fix that repairing it leaves `bw_out_allowance_exceeded` unchanged; a
   change falsifies the attribution.
8. **Re-record with a longer period.** At the default `--period 10` roughly 9 real intervals are
   observed, which cannot separate sustained shaping from a run that ended mid-burst. `--period 300`
   can.
9. **After remediation, predict zero.** At the same offered load the exceeding-interval count must be
   **zero**, not merely lower. A lower-but-nonzero count means the new size or the payload reduction is
   still short, and saying so is more useful than declaring success.

## Do not

- **Do not dismiss this finding because the score is small or zero.** A one-packet interval scores
  −0.00 and renders with a neutral face, greyed out, sorted mid-list. The rule is `Critical` and the
  enforcement is measured.
- **Do not rank this finding by score.** The formula is non-monotonic in [1.0, 2.0), and −256.00 is
  produced both by any sub-unit value and by exactly 2.0.
- **Do not read the value as a run total.** It is a per-interval delta; sum the series for the total.
- **Do not read a fractional value as a real packet count.** It is a multi-ENI mean that out-scored the
  real series, and it means the true per-interface peak was exactly one packet.
- **Do not average anything here.** The forced first zero dilutes an average over the raw series by
  (n−1)/n, and the `average` series is a mean across series (`ena_stat.rs:315`) so reading instance
  egress off it understates the total by the series count. Sum the per-queue series.
- **Do not chase EFA because the message says "EFA".** All five allowance messages name the wrong
  device; this is an ENA metric read by the `ethtool` ioctl.
- **Do not compare this score against other findings.** `Critical` (−256) times the delta multiplier
  produces values orders of magnitude larger than any other rule.
- **Do not attribute every transmit problem to the allowance.** `tx_linearize`, `tx_dma_mapping_err`,
  `tx_prepare_ctx_err`, and `tx_queue_stop` are distinct mechanisms with distinct fixes.
- **Do not "fix" the idle CPU.** Idle CPU alongside this finding is a *symptom* of being
  bandwidth-bound.
- **Do not attach another ENI expecting more allowance.** The ceiling is per instance, not per
  interface.
- **Do not scale up before checking payload size and fan-out.** Egress is the one allowance where
  sending less is usually available, and it is far cheaper than a larger instance.
- **Do not assume more bandwidth alone ends a retransmission-amplification loop.** Once retransmits are
  competing for the egress budget, pacing is what breaks the cycle.
- **Do not conclude the ceiling was not hit because average egress looks well under the limit.**
  Enforcement acts on sub-second bursts that a 1-second average hides, and burst credits move the
  effective ceiling during the run.
- **Do not treat absence of the finding on a short run as proof of health.** The first point is a
  structural zero, so the default `--period 10` observes about 9 real intervals.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:24`–`:30` (`Comparator::Greater`, threshold `0.0`,
  `Score::Critical`). The `"EFA"` in the message at `:29` is an upstream defect.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates
  every series including the auto-generated aggregate, keeps the largest `|score|` with `>=`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`–`:176` — the `threshold == 0.0`
  branch, flat below 1.0 and linear above.
- Delta processing: `add_accumulative_data_point` (`src/data/ena_stat.rs:343`) and
  `get_delta_and_set_previous_value` (`src/data/common/time_series_data_processor.rs:189`–`:224`) — the
  forced first zero at `:218`/`:73`, and the dropped decrease at `:202`–`:214`.
- Average aggregate and its single-ENI suppression: `src/data/ena_stat.rs:315`;
  `src/data/common/time_series_data_processor.rs:249`–`:256` and `:315`–`:319`.
- Frontend rendering of a zero score: `AnalyticalFindings.tsx:35` (`getFindingColor`), `:44`–`:52`
  (`FindingIcon`), and the ascending score sort at `src/report_frontend/src/utils/analytics.tsx:40`.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL` ioctl,
  `:31`–`:33`.
- Upstream guide: `EC2_NETWORK_BANDWIDTH_ALLOWANCE_RECOMMENDATIONS`,
  `src/report_frontend/src/definitions/optimization-guides.ts:117`–`:123`.
- Quantifier: [`../tools/aperf_ena_allowance.py`](../tools/aperf_ena_allowance.py)
  `--metric bw_out_allowance_exceeded`; `aggregate_masks_the_peak()` for the fractional-value artifact,
  re-derived over 2,044 combinations in `tools/test_aperf_ena_allowance.py`.
- [EC2 instance network bandwidth](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-instance-network-bandwidth.html)
- [Monitor network performance for your EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
- [ENA network performance tuning](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-nitro-perf.html)
- Related playbooks: `inbound-bandwidth-exceeded-instance-allowance.md`,
  `pps-exceeded-instance-allowance.md`, `underutilized-cpu.md` (the bandwidth-bound signature),
  `increased-io-wait-time.md` (the same event on NFS/EFS-backed storage).
