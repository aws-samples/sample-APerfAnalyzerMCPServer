---
rule_name: Inbound Bandwidth Exceeded Instance Allowance
data_type: ena_stat
data_key: bw_in_allowance_exceeded
template: time_series_data_point_threshold
condition: "any(bw_in_allowance_exceeded) > 0.0"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "EFA is queuing or dropping packets due to exceeding the instance's inbound bandwidth allowance."
source: src/analytics/rules/ena_stat.rs:16
---

# Inbound Bandwidth Exceeded Instance Allowance

## What fired

**At least one** interval delta of `bw_in_allowance_exceeded` was **greater than 0.0** — the Nitro
card queued or dropped at least one inbound packet because the instance's aggregate inbound
bandwidth allowance was exceeded.

Base score `Critical` (**−256**) — the most severe base score aperf defines. Single-run rule,
`Comparator::Greater`, threshold `0.0`.

Unlike almost every other aperf finding, this one is **not a heuristic**. It is a hardware
enforcement counter: the Nitro card incremented it because it actually shaped or dropped traffic.
There is no interpretation step for *whether* it happened. The entire diagnostic question is
**RATE and DURATION** — a 3-packet blip and a 40-minute shaping event fire this rule identically.

> **The message names the wrong device.** aperf says *"EFA is queuing or dropping packets"*. All five
> `ena_stat` allowance rules (`ena_stat.rs:21`, `:29`, `:37`, `:45`, `:53`) say "EFA" when they mean
> **ENA**. The metric is read by `ethtool -S` ioctl on the ENA interface (`ena_stat.rs:235`); Elastic
> Fabric Adapter is a different device with its own data type and its own rules. The
> `data-descriptions.ts` entries for the same metrics (`:3817`–`:3851`) are correct. Do not let the
> finding text redirect the investigation toward EFA.

## The processing caveat — verified by simulating the collection loop

Three properties of `ena_stat`'s processing change what the number means, and one of them makes the
reported value **fractional and wrong** in a narrow but reachable case.

**1. The series is already a per-interval delta.** `add_accumulative_data_point`
(`ena_stat.rs:343`) stores `current − previous` between `ethtool` snapshots. At the default
`--interval 1` (`record.rs:35`) each point is "packets shaped in about one second". Summing the
series gives the run total; reading the last point does not.

**2. The first point is a forced zero covering no elapsed time.**
`get_delta_and_set_previous_value` finds no previous value, takes the `None` arm at
`time_series_data_processor.rs:218`, and returns `0.0` because `ignore_first_accumulative_value`
defaults to `true` (`:73`). Only `perf_stat` opts out (`perf_stat.rs:1295`); `ena_stat` never does.
So an n-snapshot run yields an n-point series over **(n−1) × interval** seconds, and any *average*
over the raw series is diluted by (n−1)/n. Sums, peaks and streaks are unaffected — which is why the
quantifier reports those.

**3. The auto-generated `average` series can WIN the rule's selection and print a fractional packet
count.** This is the sharp one. `ena_stat` aggregates with
`time_series_data_processor_with_average_aggregate` (`:315`), so a multi-ENI instance gains an
`average` series that is the **mean** across interfaces, and the rule iterates every series
including it (`processed_data_accessor.rs:104`). Because the `threshold == 0.0` branch pins every
value below 1.0 at the flat **−256.00** while exactly 1.0 scores **−0.00**, a one-packet peak on one
interface is out-scored by its own sub-unit mean:

| series | value | \|score\| | selected? |
|---|---|---|---|
| `eth0` | 1.0 | **0.00** | no |
| `eth1` | 0.0 | — | does not fire |
| `average` | **0.5** | **256.00** | **yes — reported** |

Brute-forcing 1,596 combinations over 2/3/4/8 ENIs with peaks in {0, 1, 2, 3, 5, 10, 47, 1000} found
the artifact in exactly 22 cases, and **the peak per-interface delta was 1 in every one of them**. At
a peak of 2 the real series scores −256.00 and wins outright. So the window is not a range — it is
the single value 1.0, and the consequence is precise:

> **A fractional value in the description means the true per-interface peak was exactly ONE packet.**
> That is the mildest possible reading of a `Critical` finding, reported with the most severe score a
> small delta can produce. The score and the truth point in opposite directions.

Two scope limits, both verified: the queue split at `ena_stat.rs:332` fires only for names of the
form `queue_<n>_...`, and none of the five allowance metrics match — so these are always **one series
per interface**, never per queue. And on a single-ENI instance the aggregate is **dropped before
rendering** (`time_series_data_processor.rs:315`–`:319` retains only non-aggregate series when
`len() == 2`), so the artifact needs **two or more ENIs** to exist at all.

`tools/aperf_ena_allowance.py` carries all of this;
`aggregate_masks_the_peak()` returns the verdict and
`tools/test_aperf_ena_allowance.py` re-derives the 1.0 bound by sweeping 2,044 combinations.

## Reasoning

`bw_in_allowance_exceeded` is the *"Number of packets queued or dropped because the inbound aggregate
bandwidth exceeded the maximum for the instance."* (`data-descriptions.ts:3817`, `desired: "lower"`)

Every EC2 instance has a bandwidth ceiling enforced by the Nitro card, applied to inbound and
outbound **simultaneously and independently**. The allowance is a property of the instance type and
size. When arriving traffic exceeds it the card first *queues* — adding latency and jitter — then
*drops*. Both increment this counter.

This is why the finding matters more than its rate suggests: **for TCP a dropped packet is not a lost
packet, it is a congestion signal.** The sender's congestion control reads the loss as congestion and
backs off, then retransmits. The user-visible effect is disproportionate to the drop count:

- Throughput collapses well below the allowance because the sender throttled itself.
- Tail latency rises sharply — a retransmission costs at least one RTT, often an RTO.
- The application sees timeouts and stalls, not "slightly less bandwidth".

So a small non-zero value is a real problem, and the relation between drop count and impact is
non-linear.

Two properties are specific to *inbound* and separate it from the outbound case:

1. **You do not control the sender.** Outbound shaping is fixed by sending less. Inbound shaping is
   caused by what other parties send *to* you, so the levers differ: admission control, backpressure,
   load balancing across more instances, or a larger instance.
2. **Burst credits mask the ceiling.** Smaller instance types sustain above-baseline bandwidth only
   while credits last. A workload that passed a ten-minute test can start being shaped an hour in
   with no change in traffic. The signature is a counter at zero that begins incrementing steadily
   and never recovers.

Common causes: instance too small for the traffic (the baseline case — allowance scales with size);
burst-credit exhaustion; traffic concentration behind a load balancer or a hot shard; large inbound
transfers (S3 downloads, replication catch-up, backup restores) competing with serving traffic;
retransmission amplification, self-sustaining once it starts; and **aggregate across interfaces** —
the allowance is per *instance* while the counter is per *interface*, so a multi-ENI instance can
exceed the ceiling while no single interface looks busy.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 7 (greater than the threshold of 0).
```

The value is the **worst single interval delta across every series**, not a total and not an average.
Values at or above 1000 print with a K/M/G/T suffix (`formatted_number_string`,
`computations/mod.rs:176`–`:190`), so a severe run may read `12.40K`.

**Score math takes the `threshold == 0.0` branch** of `compute_finding_score` (`analytics/mod.rs:170`):

```
if value < 1.0  →  score = rule_score               (flat −256)
else            →  score = (value - 1.0) * rule_score
```

| worst delta | score | note |
|---|---|---|
| 0.50 | **−256.00** | fractional ⇒ multi-ENI mean; true peak was 1 packet |
| **1.00** | **−0.00** | **one packet in an interval scores zero** |
| 2.00 | **−256.00** | collides with the 0.50 score |
| 5.00 | **−1024.00** | |
| 12 400 | **−3 174 144.00** | |

Recover the delta as `|score| / 256 + 1`, but **−256.00 is ambiguous**: it is produced both by the
flat branch (any value below 1.0) and by exactly 2.0 on the linear branch. Disambiguate from the
description's value text, never from the score.

**Two traps, both confirmed by running the engine:**

- **`1.00 → −0.00` renders as NEUTRAL.** `FindingIcon` returns the `zero` icon (`face-neutral`) for
  `score == 0` and `getFindingColor` greys it out (`AnalyticalFindings.tsx:35`, `:44`–`:52`).
  Findings sort ascending by score (`analytics.tsx:40`), so this `Critical` finding lands
  **mid-list**, below every `Concerning` finding in the report, with a neutral face beside it. At the
  default page size of 5 it will not be on the first page.
- **The score is non-monotonic.** Every delta in [1.0, 2.0) scores *closer to zero* than any delta
  below 1.0. A larger value can score better.

**Never triage this rule by score. Check whether the finding exists at all.** And do not compare
these scores with anything else in the report: a 5-packet interval scores −1024.00, four times the
base `Critical` value.

## Interpretation

Enforcement is a fact, so the question is **how much of the run was affected**:

| Pattern in the series | Reading |
|---|---|
| One interval, small delta | A brief burst exceeded the allowance. Real but possibly harmless; correlate with a known event |
| Sustained non-zero across the run | **The instance is bandwidth-limited on ingress.** A leading bottleneck; scale |
| Zero, then non-zero from some point on, never recovering | **Burst-credit exhaustion.** The traffic did not change; the allowance did |
| Periodic bursts | Aligned with a batch job, cron, replication cycle, or GC-driven backlog drain |
| Fractional value | Multi-ENI mean out-scored the real series. **True per-interface peak was one packet** |

Combinations that change the diagnosis:

| also fired / observed | Reading |
|---|---|
| `Outbound Bandwidth Exceeded Instance Allowance` | Both directions shaped. Strongly indicates the instance is undersized rather than a traffic-shape problem |
| `PPS Exceeded Instance Allowance` **only**, bandwidth zero | Not this finding's case — small packets. See that playbook |
| `PPS Exceeded Instance Allowance` **and** this | Both ceilings hit; a resize addresses both |
| `Increased I/O Wait Time` (`cpu_utilization`) | On NFS/EFS-backed storage, shaped ingress *is* the I/O wait. The same event from two sides |
| `netstat` retransmit counters elevated | Confirms the drops are triggering TCP recovery — the expensive consequence |
| `Underutilized CPU` | **The classic bandwidth-bound signature**: CPU idle because the workload waits on the network. Do not "fix" the CPU |
| `rx_page_alloc_fail`, `rx_skb_alloc_fail`, `rx_empty_rx_ring` non-zero | **Different** receive-path drops — memory pressure or NAPI starvation, not allowance. Separate fixes |
| `suspected_poll_starvation` non-zero | The driver could not keep up polling: interrupt affinity or CPU contention, not the allowance |
| `total_resets` non-zero | The series has silent gaps — the total is a lower bound by an unknown amount |
| `ena_srd_*` findings | ENA Express affects throughput but does not change the allowance |

**Known false positives — none of them make the enforcement unreal:**

- **A single interval with a tiny delta.** Enforcement happened; a one-off microburst may have no
  measurable application impact. Judge from the series, not the firing.
- **A fractional value.** Not a false positive about *whether* it happened, but the magnitude is a
  mean and the true per-interface peak was one packet — the mildest event this rule can report.
- **Traffic not generated by the workload under test.** A backup agent, monitoring pipeline, package
  update, or noisy co-tenant process. Check `processes`.
- **The recording captured a load or warm-up phase** that saturates ingress by design.
- **Counter reset or interface flap.** A decrease is *dropped* (`:202`–`:214`) rather than emitted as
  a bogus spike, so a reset yields a gap; `total_resets` or `interface_down` non-zero means the
  series is not continuous.
- **A very short run.** The first point is a structural zero, so a 2–3 snapshot recording can miss
  enforcement entirely. Absence is not evidence.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `bw_in_allowance_exceeded` full series, **per interface** | `ena_stat` | **Do this first.** Sustained vs burst vs credit exhaustion, and the real per-interface counts behind any fractional value |
| `rx_bytes`, `rx_cnt` per queue | `ena_stat` | Actual ingress volume and packet rate — how close to the ceiling, and the mean packet size |
| `bw_out_allowance_exceeded` | `ena_stat` | Whether both directions are shaped. See `Outbound Bandwidth Exceeded Instance Allowance` |
| `pps_allowance_exceeded` | `ena_stat` | Whether the packet-rate ceiling is also hit. See `PPS Exceeded Instance Allowance` |
| `rx_page_alloc_fail`, `rx_skb_alloc_fail`, `rx_empty_rx_ring`, `rx_refil_partial` | `ena_stat` | **Different** receive-path drops (memory/buffer starvation). No rules fire on these — read manually |
| `suspected_poll_starvation`, `missing_intr` | `ena_stat` | NAPI/interrupt problems that also drop packets. Read manually |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the counter series is continuous |
| `num_of_active_io_queues` | `ena_stat` | Receive parallelism available |
| `Instance Type` | `systeminfo` | **The allowance is a property of this value.** Required to know what the ceiling is |
| TCP retransmit and error counters | `netstat` | Whether drops are triggering TCP recovery — how a small drop count becomes a large slowdown |
| `idle`, `aggregate`, `iowait` | `cpu_utilization` | Idle CPU with shaped ingress = bandwidth-bound. See `Underutilized CPU`, `Increased I/O Wait Time` |
| `softirq`, `system` | `cpu_utilization` | Network processing cost; high `softirq` with drops suggests the receive path is also CPU-limited |
| Per-process activity | `processes` | Whether an unrelated agent is consuming ingress. **No analytical rules — read manually** |
| `interrupts` distribution | `interrupts` | Whether receive interrupts concentrate on a few CPUs. **No analytical rules — read manually** |

## Guidance

Ordered. Step 1 is not "is it real" — it is "how much of the run".

1. **Read the full series, per interface, and quantify rate and duration.**
   `python3 tools/aperf_ena_allowance.py --metric bw_in_allowance_exceeded --series <deltas>` gives
   exceeding-interval count, peak rate, total, and the sustained/pervasive verdict. Sustained
   non-zero ⇒ ingress-bandwidth-limited, highest priority. Zero then permanently non-zero ⇒
   burst-credit exhaustion. Isolated burst ⇒ correlate before escalating. Fractional ⇒ the true peak
   was one packet.

2. **Never triage by score.** A one-packet interval scores −0.00 and renders with a neutral face
   mid-list; a five-packet interval scores −1024.00. Presence of the finding is the signal.

3. **Establish the actual ceiling.** Read `Instance Type` from `systeminfo` and compare measured
   ingress (`rx_bytes` summed across queues, over the interval) against the documented allowance for
   that type. This converts "we were shaped" into "we need N Gbps" — the number that sizes the fix.
   Sum the **per-queue** series; the aggregate is a mean.

4. **Separate allowance drops from other receive-path drops.** Check `rx_page_alloc_fail`,
   `rx_skb_alloc_fail`, `rx_empty_rx_ring`, `rx_refil_partial`, `suspected_poll_starvation`. Those
   are buffer and CPU problems with entirely different fixes, and they coexist with allowance
   shaping. Attributing a buffer-starvation drop to the allowance buys a pointless instance upgrade.

5. **Quantify the consequence, not just the cause.** Read `netstat` retransmit counters and check
   `Underutilized CPU`. Idle CPU plus retransmissions is what turns a modest drop count into a
   throughput collapse, and it is the number that justifies the remediation.

6. **Check whether the traffic is even yours.** Inspect `processes` for backup, monitoring, or update
   agents. Shaping caused by a sidecar is fixed by scheduling it, not by resizing.

7. **Remediate**, per `EC2_NETWORK_BANDWIDTH_ALLOWANCE_RECOMMENDATIONS` — and pick by the *shape*
   established in step 1, not by the firing:
   - **Sustained and pervasive ⇒ scale up.** Bandwidth allowance scales with instance size. Size from
     the step-3 number, not by guessing one notch.
   - **Concentrated on one instance ⇒ scale out or rebalance.** Behind a load balancer, add
     instances; check for an uneven hash or a hot shard first, since rebalancing is far cheaper than
     resizing the fleet.
   - **Bursty ⇒ fix the traffic shape.** Compression, smaller payloads, caching to avoid refetching,
     pacing.
   - **Bulk transfer during serving ⇒ move it off the path.** Schedule backups, restores, and
     replication catch-up outside peak, or give them their own instance.
   - **Sender-driven ⇒ admission control or backpressure**, so senders slow down before the Nitro
     card has to drop — this avoids the TCP-recovery penalty entirely, and it is the ingress-specific
     lever you would not reach for on the outbound side.

## Priority and execution risk

**Priority: P1 — Act now** when the exceedance is sustained (≥5 consecutive intervals) or pervasive
(≥25% of intervals), because the enforcement is measured rather than inferred and the TCP
consequences are non-linear. It rises to **P0 — Emergency** when shaping is pervasive *and* the
application is missing its SLO *and* `Underutilized CPU` also fired — the classic bandwidth-bound
collapse, where the instance is doing nothing but waiting. It drops to **P3 — Monitor** for a single
exceeding interval with no correlated latency excursion, and to **P4 — Informational** when the value
is fractional (true peak one packet) or when the traffic is attributable to a sidecar rather than the
workload. Note the asymmetry with the score: the P4 case is precisely where the score reads
**−256.00**, and the P3 case is where it can read **−0.00**.

**Execution risk: R0 — Read-only** to resolve: the series, the per-interface split, the rate and
duration arithmetic, the ceiling lookup, and the `netstat` correlation are all reads. Acting spans
the range and the choice matters more here than in most findings. **R1** for a traffic-shape or
scheduling change (move the backup window, enable compression, pace the sender) — reversible
configuration. **R2** for scaling out behind a load balancer or rebalancing a hash, which changes
traffic distribution but not the application. **R3 — Resize** for an instance change, because it
requires a stop/start or a replacement, moves instance-store data, and may change the CPU
generation along with the bandwidth. **R4** where admission control or backpressure is introduced
into the request path, since a misconfigured limit sheds load that would otherwise have succeeded.
**Do not inherit the R0 of the reading into the resize.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `bw_in_allowance_exceeded` interval delta, on any series including the
auto-generated `average`, was `> 0.0`.

```
STEP 0 — Is the reported VALUE trustworthy? Check this before reading anything into it.
  IF the value is FRACTIONAL (e.g. 0.50, 0.33)
  THEN → the auto-generated `average` series out-scored every real interface. Brute force
         over 1,596 multi-ENI combinations puts this artifact at a true per-interface peak
         of EXACTLY 1 packet, so the event is a ONE-PACKET microburst reported with a
         -256.00 score. This is the mildest reading this rule can produce (P4, R0)
       → verify: read the per-interface series directly; the peak must be 1
  IF `total_resets` or `interface_down` is non-zero
  THEN → the ENA driver reset mid-run. A counter DECREASE is dropped entirely
         (time_series_data_processor.rs:202-:214) while the baseline still advances, so
         events between those snapshots are LOST. Every total below is a lower bound
         (P2, R0)
  IF the series has fewer than 4 points
  THEN → the first point is a structural zero, so 2-3 snapshots cover 1-2 real intervals.
         Neither rate nor duration is establishable. Re-record with `--period 300`
         (P2, R0)
       → verify: series length minus 1 equals the number of intervals actually covered
  OTHERWISE
  THEN → the value is a genuine worst-interval delta. Continue (P2, R0)

STEP 1 — Rate and duration. This, not the firing, is the finding.
         `tools/aperf_ena_allowance.py --metric bw_in_allowance_exceeded --series <deltas>`
  IF exceeding in >=5 CONSECUTIVE intervals AND >=25% of intervals
  THEN → the ingress ceiling is this workload's steady state. A sizing problem, not an
         excursion. Go to STEP 3 and size the fix from measured throughput (P1, R0)
  IF sustained (>=5 consecutive) but not pervasive
  THEN → a real ceiling during one phase. Identify the phase before resizing for it; a
         load-phase ceiling may be acceptable (P2, R0)
  IF exactly ONE exceeding interval
  THEN → a microburst. Correlate with application latency before spending anything; one
         interval of shaping is often invisible to callers (P3, R0)
       → verify: application p99 in that second. No excursion means no action
  IF intermittent (several intervals, longest streak < 5)
  THEN → bursty. Fix the traffic SHAPE before buying a bigger instance: pacing,
         compression, smaller payloads, batching (P2, R1)
       → verify: re-record and confirm the exceeding-interval count falls; if the peak
         merely moved, the burst was shifted rather than removed

STEP 2 — Is this the ALLOWANCE, or a different receive-path drop wearing the same symptom?
  IF `rx_page_alloc_fail`, `rx_skb_alloc_fail`, `rx_empty_rx_ring` or `rx_refil_partial`
     is non-zero
  THEN → those are memory/buffer starvation drops, NOT allowance shaping, and they have
         entirely different fixes. Attributing them to the allowance buys a useless
         upgrade. Fix them separately and re-measure (P2, R1)
       → verify: after the buffer fix, `bw_in_allowance_exceeded` should be UNCHANGED --
         it is a distinct mechanism. If it moved, the attribution was wrong
  IF `suspected_poll_starvation` or `missing_intr` is non-zero
  THEN → the driver could not keep up polling: interrupt affinity or CPU contention, not
         the ceiling. Check `interrupts` distribution and `softirq` (P2, R1)
       → verify: after spreading receive interrupts, `suspected_poll_starvation` falls while
         `bw_in_allowance_exceeded` is unchanged. Both moving means one mechanism, not two
  OTHERWISE
  THEN → allowance shaping is the mechanism. Continue (P1, R0)

STEP 3 — Size the fix. "We were shaped" is not actionable; "we need N Gbps" is.
  IF per-queue `rx_bytes` are available
  THEN → sum the PER-QUEUE series (never the aggregate, which is a mean, ena_stat.rs:315),
         convert to Gbit/s, and compare against the documented allowance for the
         `Instance Type` in systeminfo. That ratio sizes the instance (P1, R0)
  IF measured ingress is well BELOW the documented allowance yet shaping occurred
  THEN → either burst credits were exhausted (the ceiling fell, the traffic did not rise)
         or sub-second bursts are hidden by the 1s interval. Both point at the same fix
         but for different reasons -- say which (P2, R0)
       → verify: a zero-then-permanently-nonzero series shape confirms credit exhaustion;
         a flat-average-with-spikes shape confirms sub-second bursting
  IF the instance is multi-ENI
  THEN → the allowance is per INSTANCE while the counter is per INTERFACE, so the ceiling
         can be exceeded while no single interface looks busy. Sum across interfaces
         (P1, R0)

STEP 4 — Quantify the CONSEQUENCE. This is what justifies the spend.
  IF `netstat` retransmits are elevated AND `Underutilized CPU` also fired
  THEN → the bandwidth-bound collapse: drops trigger TCP backoff, throughput falls below
         the allowance, and the CPU idles waiting. Do NOT "fix" the idle CPU -- it is the
         symptom (P0, R3)
       → verify: after the resize, retransmits fall AND CPU utilization RISES. If CPU stays
         idle, the bottleneck was elsewhere
  IF shaping intervals do NOT align with any latency or error excursion
  THEN → enforcement happened but no caller observed it. Record it and move on; a Critical
         score is not by itself a business case (P3, R0)

STEP 5 — Whose traffic is it? A resize cannot fix someone else's ingress.
  IF a backup, monitoring, or update agent is active in `processes`
  THEN → reschedule it out of the serving window, or move it to its own instance. Cheaper
         than resizing and it does not change the serving path (P2, R1)
       → verify: re-record without the agent; the exceeding intervals should vanish
  IF ingress is concentrated on ONE instance in a fleet
  THEN → an uneven hash or a hot shard, not a global sizing problem. Rebalance instead of
         resizing the whole fleet (P1, R2)
       → verify: compare `rx_bytes` across fleet members; a single outlier confirms
         concentration
  IF the traffic is the workload's own steady-state ingress
  THEN → scale UP from the STEP 3 number (R3: stop/start or replacement, instance-store
         data moves, CPU generation may change), or scale OUT behind a load balancer
         (P1, R3)
       → verify: after the change, re-record and confirm ZERO exceeding intervals at the
         same offered load. Nonzero means the new size is still short
  IF senders can be slowed at the source
  THEN → admission control or backpressure avoids the drop, and therefore the TCP-recovery
         penalty, entirely. But a misconfigured limit sheds load that would have succeeded
         (P2, R4)
       → verify: shaping stops AND the application's success rate does not fall

STEP 6 — What survives?
  VALID      : that the Nitro card queued or dropped inbound packets -- this is hardware
               enforcement, not inference; the exceeding-interval COUNT, the peak per-second
               rate, the run TOTAL as a sum of the series, and the longest streak
  CAUTION    : any total on a run with `total_resets` non-zero (lower bound only); a
               sustained/pervasive verdict on a run of <=10 intervals, where the default
               `--period 10` cannot distinguish sustained shaping from a run that ended
               mid-burst
  CONFOUNDED : any AVERAGE over the raw series, diluted by (n-1)/n by the forced first
               zero; the reported value when FRACTIONAL, which is a multi-ENI mean hiding a
               one-packet peak; and any instance-total bandwidth read off the `average`
               series, which is a mean and understates by the series count
  VOID       : any RANKING of this finding by score -- the formula is non-monotonic in
               [1.0, 2.0), -256.00 has two disjoint preimages, and a one-packet interval
               scores -0.00 and renders NEUTRAL mid-list; and any claim that other
               receive-path drops (rx_page_alloc_fail, poll starvation) are allowance
               shaping

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:205).
         Absence proves nothing about the allowance (P3, R0)
  IF the finding did NOT fire and the question was "am I bandwidth-limited?"
  THEN → absence is weak evidence at the default `--period 10`: the first point is a
         structural zero, so ~9 real intervals were observed. Re-record with
         `--period 300` before concluding health (P3, R0)
  IF `Instance Type` is missing from systeminfo
  THEN → the allowance cannot be looked up, so shaping cannot be converted into a target
         throughput. The shape verdict from STEP 1 still stands (P2, R0)
```

## Runtime-specific consequences

The allowance is enforced below the OS, so every runtime is shaped identically — but what each does
*in response* differs, and that changes the symptom you will be shown.

- **Any TCP workload.** The kernel's congestion control reacts to the drop, not the application. The
  symptom surfaces as latency and timeouts, and the application's own metrics will under-report the
  cause.
- **UDP workloads.** No backoff and no retransmission: the packet is simply gone. Shaping shows up as
  silent data loss rather than latency, which is worse to diagnose and means the drop count maps much
  more directly to lost work.
- **Java.** A shaped ingress stream stalls NIO reads, and thread pools fill with blocked readers. The
  visible symptom is often thread-pool exhaustion or a rising queue depth, several layers away from
  the network. `java_profile` will show threads parked in socket reads.
- **Containers.** The allowance belongs to the **instance**, not the container. Several containers
  sharing one ENI compete for one ceiling with no per-container accounting, so a noisy sidecar shapes
  the primary workload and neither container's own metrics show why.
- **Multi-ENI setups.** Adding an interface does **not** add allowance — it is per instance. This is
  the most expensive misconception on this page, because attaching an ENI looks like it should help
  and cannot.
- **NFS/EFS-backed storage.** Shaped ingress appears as I/O wait rather than network trouble; see
  `Increased I/O Wait Time`. The two findings are one event seen from two sides.

## Architecture-specific considerations

This finding is architecture-independent in mechanism but instance-dependent in threshold.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically. Unlike the `perf_stat`
  family there is no per-architecture config to consult.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`,
  `br-*` and `virbr*`, then requires `/sys/class/net/<if>/device` to exist (`ena_stat.rs:190`–`:205`).
  Inside a container with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot
  fire — silence there is structural.
- **The allowance is a property of instance type and size, not of the CPU.** A same-size Graviton and
  x86 instance in the same family generally carry the same network allowance, so a Graviton migration
  does not change this ceiling.
- **Burst vs baseline bandwidth is size-dependent.** Smaller sizes in a family have a baseline well
  below their burst ceiling and rely on credits; the largest size in a family typically has no burst
  behaviour at all. That is why the "zero then permanently non-zero" signature appears on small
  instances and essentially never on `.metal` or the largest size.
- **`.metal` and the largest family sizes** give the full non-shared allowance, which is why moving to
  them removes credit-exhaustion behaviour rather than merely raising the number.
- **ENA Express (SRD)** changes single-flow throughput and tail latency but **not** the instance
  allowance. An `ena_srd_*` finding alongside this one is a separate matter; do not expect enabling it
  to stop the shaping.

## Verification

The falsifiable claim is *the instance's ingress ceiling was reached for this fraction of the run, and
raising it removes the shaping*. Verify in that order.

1. **Confirm the value is not the multi-ENI artifact.** A fractional reading means the true
   per-interface peak was one packet; read the per-interface series and confirm.
2. **Confirm the series is continuous.** `total_resets`, `interface_down`, `interface_up` all zero.
   Otherwise every total is a lower bound.
3. **Quantify rate and duration.** `tools/aperf_ena_allowance.py --metric bw_in_allowance_exceeded
   --series <deltas>` — exceeding count, peak rate, total, sustained/pervasive verdict. Check the
   score against `|score| / 256 + 1` and expect the −256.00 ambiguity.
4. **Convert to a throughput target.** Sum the **per-queue** `rx_bytes` (never the aggregate mean),
   express in Gbit/s, and compare with the documented allowance for the instance type.
5. **Correlate with the consequence.** Retransmits in `netstat` and idle CPU in `cpu_utilization`. If
   neither moved during the exceeding intervals, the shaping had no observed cost — report that
   plainly rather than escalating.
6. **Rule out the impostors.** `rx_page_alloc_fail`, `rx_empty_rx_ring`, `suspected_poll_starvation`.
   If any is non-zero, predict *before* the fix that repairing it will leave
   `bw_in_allowance_exceeded` unchanged; a change falsifies the attribution.
7. **Re-record with a longer period.** At the default `--period 10` roughly 9 real intervals are
   observed, which cannot separate sustained shaping from a run that ended mid-burst.
   `--period 300` can.
8. **After remediation, predict zero.** At the same offered load the exceeding-interval count must be
   **zero**, not merely lower. A lower-but-nonzero count means the new size is still short, and
   saying so is more useful than declaring success.

## Do not

- **Do not dismiss this finding because the score is small or zero.** A one-packet interval scores
  −0.00 and renders with a neutral face, greyed out, sorted mid-list. The rule is `Critical` and the
  enforcement is measured.
- **Do not rank this finding by score.** The formula is non-monotonic in [1.0, 2.0), and −256.00 is
  produced both by any sub-unit value and by exactly 2.0.
- **Do not read the value as a run total.** It is a per-interval delta; sum the series for the total.
- **Do not read a fractional value as a real packet count.** It is a multi-ENI mean that out-scored
  the real series, and it means the true per-interface peak was exactly one packet.
- **Do not average the raw series.** The forced first zero dilutes any average by (n−1)/n.
- **Do not read instance bandwidth off the `average` series.** It is a mean across series
  (`ena_stat.rs:315`), so it understates the instance total by the series count. Sum the per-queue
  series.
- **Do not chase EFA because the message says "EFA".** All five allowance messages name the wrong
  device; this is an ENA metric read by `ethtool -S`.
- **Do not compare this score against other findings.** `Critical` (−256) times the delta multiplier
  produces values orders of magnitude larger than any other rule.
- **Do not attribute every receive drop to the allowance.** `rx_page_alloc_fail`,
  `rx_empty_rx_ring`, and `suspected_poll_starvation` are separate mechanisms with separate fixes.
- **Do not "fix" the idle CPU.** Idle CPU alongside this finding is a *symptom* of being
  bandwidth-bound.
- **Do not attach another ENI expecting more allowance.** The ceiling is per instance, not per
  interface.
- **Do not conclude the ceiling was not hit because average bandwidth looks well under the limit.**
  Enforcement acts on sub-second bursts that a 1-second average hides, and burst credits move the
  effective ceiling during the run.
- **Do not treat absence of the finding on a short run as proof of health.** The first point is a
  structural zero, so the default `--period 10` observes about 9 real intervals.
- **Do not resize before checking whether the traffic is yours.** A backup agent or a hot shard is
  fixed by scheduling or rebalancing, at a fraction of the cost.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:16`–`:22` (`Comparator::Greater`, threshold
  `0.0`, `Score::Critical`). The `"EFA"` in the message at `:21` is an upstream defect.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates
  every series including the auto-generated aggregate, keeps the largest `|score|` with `>=`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`–`:176` — the `threshold == 0.0`
  branch, which is flat below 1.0 and linear above.
- Delta processing: `add_accumulative_data_point` (`src/data/ena_stat.rs:343`) and
  `get_delta_and_set_previous_value` (`src/data/common/time_series_data_processor.rs:189`–`:224`) —
  the forced first zero at `:218`/`:73`, and the dropped decrease at `:202`–`:214`.
- Average aggregate and its single-ENI suppression:
  `src/data/ena_stat.rs:315`; `src/data/common/time_series_data_processor.rs:249`–`:256` and
  `:315`–`:319`.
- Frontend rendering of a zero score: `AnalyticalFindings.tsx:35` (`getFindingColor`), `:44`–`:52`
  (`FindingIcon`), and the ascending score sort at `src/report_frontend/src/utils/analytics.tsx:40`.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL`
  ioctl, `:31`–`:33`.
- Upstream guide: `EC2_NETWORK_BANDWIDTH_ALLOWANCE_RECOMMENDATIONS`,
  `src/report_frontend/src/definitions/optimization-guides.ts:117`–`:123`.
- Quantifier: [`../tools/aperf_ena_allowance.py`](../tools/aperf_ena_allowance.py)
  `--metric bw_in_allowance_exceeded`; `aggregate_masks_the_peak()` for the fractional-value artifact,
  re-derived over 2,044 combinations in `tools/test_aperf_ena_allowance.py`.
- [EC2 instance network bandwidth](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ec2-instance-network-bandwidth.html)
- [Monitor network performance for your EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
- [ENA network performance tuning](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-nitro-perf.html)
- Related playbooks: `outbound-bandwidth-exceeded-instance-allowance.md`,
  `pps-exceeded-instance-allowance.md`, `underutilized-cpu.md` (the bandwidth-bound signature),
  `increased-io-wait-time.md` (the same event on NFS/EFS-backed storage).
