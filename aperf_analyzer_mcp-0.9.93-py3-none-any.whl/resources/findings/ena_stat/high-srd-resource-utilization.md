---
rule_name: High SRD Resource Utilization
data_type: ena_stat
data_key: ena_srd_resource_utilization
template: time_series_stat_threshold
condition: "p99(ena_srd_resource_utilization) > 95.0"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "Concurrent SRD connections are having a high resource utilization, which can lead to fallback from SRD to standard ENA transmission and packet drops."
source: src/analytics/rules/ena_stat.rs:99
---

# High SRD Resource Utilization

## What fired

The **p99** of `ena_srd_resource_utilization` was **greater than 95.0** — the instance consumed more than
95% of the network card's memory allowance for **concurrent SRD connections** in at least 1% of samples.

Base score `Poor` (**−16**). Single-run rule (`Stat::P99`, `Comparator::Greater`, threshold `95.0`,
`ena_stat.rs:99`). This is the **only `ena_stat` rule that uses a percentile**, and the choice is
deliberate: p99 catches the peaks at which fallback actually happens, which an average would smooth away.
It is also, with `Low SRD Usage Rate`, one of only two SRD rules whose logic is sound — and it is the
*cause* that rule's message points at.

**One caveat on the data, though — read the next section.** The same delta-processing pipeline that breaks
the `ena_srd_mode` rules also applies here, and `ena_srd_resource_utilization` is a **percentage gauge**,
not a counter.

## The processing caveat — verified by running the engine

`ena_srd_resource_utilization` is a gauge: "The percentage of the maximum allowed memory utilization for
concurrent SRD connections that the instance has consumed." A percentage does not accumulate. But
`src/data/ena_stat.rs:343` passes **every** `ena_stat` metric through `add_accumulative_data_point`, which
stores **per-interval differences** and forces the first sample to 0
(`ignore_first_accumulative_value: true`, `time_series_data_processor.rs:73`; the only opt-out in the tree,
`use_first_accumulative_value()` at `:81`–`:83`, is called once, from `perf_stat.rs:1295`). So raw
utilization samples of `40, 60, 90` are stored as `[0.0, 20.0, 30.0]` — **rates of change, not utilization
levels.** Verified by probing the pipeline directly. Consequences for this rule specifically:

- **A steady high utilization is invisible.** An instance pinned at 99% for the whole run produces deltas
  of ~0 and **does not fire this rule** — the dangerous steady state is exactly the one it misses.
- **When it does fire, the p99 is a change of more than 95 percentage points in one interval** —
  utilization jumping from near 0 to near 100 within a single sample. That is a real and severe event, so a
  firing is not spurious; it is rarer and more specific than the message implies.
- **A decrease produces no data point at all.** `get_delta_and_set_previous_value` (`:189`–`:224`) sees
  `prev_value > data_value`, emits a `debug!`, increments a per-key counter, and `return None` at `:214`;
  `add_data_point_impl` returns early at `:150`. So **every release of pool capacity is a gap in the series,
  not a negative value**, which is why the downward half of an oscillation is rarely visible. The only trace
  is one `warn!` at `:297`–`:302`:

```
<data_name>.<metric>.<series>: skipped N data points due to unexpected decrease of accumulative data.
```

- **A constant utilization renders as exactly two data points.** `compress_all_zero_time_series_metric`
  (`:410`–`:427`) compresses every series to its first and last point when the metric's min and max are both
  0.0. A two-point `ena_srd_resource_utilization` chart therefore means the underlying gauge **never
  moved** — and says nothing at all about the level it was parked at.
- **The engine confirms the arithmetic path works**: a p99 of 98 produced score `−16.50526315789474` with
  the description `The p99 in aperf_record is 98.` — so the rule mechanics are correct, and it is the input
  semantics that are off.

**Practical rule: if this finding fires, take it seriously — a near-full-range jump in SRD resource use is
severe. If it does *not* fire, that is not evidence of headroom.** Read the series manually as *changes*: a
run of small positive deltas with no gaps means utilization is climbing and never releasing.
`Low SRD Usage Rate` is the more reliable detector of the *consequence* (eligible packets falling back),
which is why that playbook recommends checking both.

## Reasoning

`ena_srd_resource_utilization` is "The percentage of the maximum allowed memory utilization for concurrent
SRD connections that the instance has consumed. **As utilization approaches 100%, you can expect to see
performance issues. ENA Express falls back from SRD to standard ENA transmission, and the possibility of
dropped packets increases. High resource utilization is a sign that it's time to scale the instance out to
improve network performance.**" (`data-descriptions.ts:3884`, `desired: "lower"`,
`unit: "Utilization (%)"`)

That description carries both mechanism and remediation, unusually direct for an aperf metric — the action
("scale out") comes from AWS, not inference. It has to: **aperf ships no ENA Express or SRD optimization
guide at all**, only the four EC2 *allowance* guides (`optimization-guides.ts:117`, `:125`, `:134`, `:146`).

**What the resource actually is.** SRD maintains state on the card for every concurrent SRD connection; the
pool is finite and sized by instance type. The property that makes this finding surprising in practice:
**the pool is consumed by the number of concurrent connections, not by bandwidth or packet rate.** So an
instance can exhaust SRD resources while every allowance counter reads zero and the CPU is idle, and a
high-fan-out service with thousands of modest connections is more exposed than one saturating its bandwidth.

**Two consequences, and the message names both — they escalate.** First, **fallback to standard ENA**: packets
eligible for SRD go out over standard ENA instead, losing multipath routing and the tail-latency benefit, with
nothing erroring and the eligible-versus-actual gap `Low SRD Usage Rate` measures as the only visible evidence.
Then **dropped packets** as utilization saturates — "optimization not delivering" becomes "traffic being
lost", and for TCP a drop is a congestion signal, so the throughput cost outruns the drop count.

Common causes:

- **Too many concurrent SRD connections for the instance size.** The baseline case; pool capacity scales
  with instance type.
- **High connection churn.** Establishing and tearing down connections consumes and releases pool entries,
  keeping utilization high without a high steady connection count. **Connections not pooled or reused** is the
  same cause from the application side — a new connection per request, and the root cause of most
  connection-tracking problems too. See `Connection Tracking Exceeded Instance Allowance`. **Fan-out topology**
  compounds it: one inbound request opening many outbound SRD connections multiplies pool use per unit of work.
- **UDP support enabled on a high-connection workload.** Mode 3 puts UDP traffic on SRD too, increasing
  concurrent SRD usage. See `Enabled ENA Express without UDP` for the trade-off.
- **A workload phase that opens many connections at once** — startup, a deploy, a cache warm, a reconnect
  storm after a peer restart.

**Why `Poor` (−16):** the same weight as `Low SRD Usage Rate`, and the two describe one problem from two
sides — this is the cause, that is the effect.

## Reading the description

`time_series_stat_threshold` emits:

```
The {stat} in {run_name} is {value}.
```

For this rule:

```
The p99 in aperf_record is 98.
```

Note what the template does **not** include: **the comparator and the threshold are absent**, unlike
`time_series_data_point_threshold`. You have to know the threshold is 95.0 — the description alone does not
say what was exceeded. Three properties of the value:

1. **It is the p99 of the whole run**, not a per-sample reading. So >95 means at least 1% of samples were
   above it, and the other 99% may be far lower.
2. **Per the caveat above, it is a p99 of per-interval *deltas*** — a change in utilization, not a level.
3. It passes through `formatted_number_string`, so it is truncated (not rounded) to 2 decimals via
   `f64_to_fixed_2`, with K/M/G/T suffixes for large values — irrelevant here since it is a percentage.

Score math — `compute_finding_score(p99, 95.0, −16)`, general branch (`delta = p99/95`):

| p99 | score |
|---|---|
| 95.5 | **−16.08** |
| 96 | **−16.17** |
| 98 | **−16.51** |
| 99 | **−16.67** |
| 100 | **−16.84** |

**The score is almost completely flat.** Because the metric is a percentage and the threshold is 95, the
ratio can never exceed 100/95 ≈ 1.0526, so the score is bounded between −16.00 and **−16.84** — a range of
5%. Verified: p99 = 98 produced `−16.50526315789474`. **So it conveys essentially nothing about severity
here.** Unlike `Low SRD Usage Rate` (unbounded, monotonic, worth ranking on), a marginal 95.5 and a saturated
100 are indistinguishable, and since findings sort ascending by score (`analytics.tsx:40`) this one lands in a
narrow band whatever the state of the card. **Read the p99 value and the series; ignore the score.** A
different failure mode from the allowance rules' `→ −0.00` trap, but the same instruction.

## Interpretation

| p99 (as reported) | Reading |
|---|---|
| 95–98 | Over the threshold. Given the delta semantics, this is a large single-interval swing in SRD resource use — investigate the series |
| 98–100 | A near-full-range jump. Fallback is very likely and drops are plausible |
| Rule did **not** fire | **Not evidence of headroom.** A steadily saturated instance produces near-zero deltas. Read the series manually |

Series shape (remembering the values are changes, and that decreases are gaps rather than negatives):

| Pattern | Reading |
|---|---|
| One large positive delta, then near-zero | Utilization jumped and **stayed high** — the dangerous steady state, visible only as the initial step |
| Large positive deltas separated by gaps | Utilization oscillating; the gaps are the releases the pipeline discards. Connection churn |
| Small positive deltas with no gaps | **Monotonic climb.** Pool entries accumulating without release — the strongest signal for missing connection reuse |
| Exactly two data points | The all-zero compression fired, so the gauge **never moved**. Says nothing about the level — could be 2% or 99% |
| Deltas concentrated at the start, or aligned with a load event | Startup connection establishment, or a reconnect storm, deploy or batch phase. Often benign |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Low SRD Usage Rate` also fired | **The diagnosis is complete: cause and effect.** Resource exhaustion here, eligible packets falling back there. Scale out — the clearest actionable case in the SRD family |
| `Low SRD Usage Rate` did **not** fire | Utilization spiked but eligible packets are still mostly getting SRD. A warning rather than a realized loss — worth acting on before it becomes one |
| `Disabled ENA Express` also fired | **Expected artifact** — the deltified mode series fires that rule on every instance. This finding proves ENA Express is *enabled*; trust it over the mode rules. `ENA Express Enabled with UDP` alongside means ideal configuration but constrained delivery, and the UDP half is adding pool pressure |
| Allowance findings all zero | **The characteristic case.** SRD resources are exhausted by *connection count*, so bandwidth and PPS can look perfectly healthy |
| `Connection Tracking Exceeded Instance Allowance` also fired | **Strong corroboration** — both are per-connection capacity limits with the same root cause (churn, no pooling). One fix addresses both |
| High connection counts / churn (`netstat`) | The direct driver of SRD resource consumption |
| TCP retransmits elevated | Consistent with the drop escalation the message warns about; tail latency worse than expected is the earlier, drop-free form of the same consequence |
| `Underutilized CPU` | Idle CPU with SRD saturation — the limit is card state, not compute |

**Known false positives:**

- **The delta-semantics caveat cuts both ways.** A firing means a large *change*, not necessarily a high
  *level* — though a >95-point jump in one interval is severe regardless.
- **p99 on a short run.** With few samples, p99 is effectively the maximum, so a single interval decides the
  finding. Check the sample count.
- **Startup connection establishment**, which produces one large delta while steady state may be fine, and
  **a transient reconnect storm** after a peer restart or deploy — real but bounded.
- **Live migration or live server update.** Named upstream as a cause of SRD disruption; transient and
  unfixable.
- **Multi-interface averaging, with ≥3 series.** Stats come from `stats_series_idx` via
  `time_series_metric_stats` (`processed_data_accessor.rs:119`–`:130`), which is the auto-generated `average`
  series when several interfaces exist — so the p99 can be a percentile of cross-interface means, and one
  interface may be entirely responsible. At exactly two series the aggregate is removed
  (`time_series_data_processor.rs:312`–`:319`), so this needs three or more.
- **A short-lived workload phase** unrepresentative of production.

**And the more important inverse — a known false *negative*:** a steadily saturated instance produces
near-zero deltas and **does not fire this rule at all**. Absence of the finding says nothing about headroom.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `ena_srd_resource_utilization` full series, **and its point count** | `ena_stat` | **Do this first, and read the values as *changes*.** One large step then flat = high and staying high; small deltas with no gaps = pool entries not being released; two points = the gauge never moved |
| `ena_srd_eligible_tx_pkts` vs `ena_srd_tx_pkts` | `ena_stat` | **Whether the consequence has materialized.** A gap means eligible packets are already falling back. See `Low SRD Usage Rate` |
| `ena_srd_tx_pkts`, `ena_srd_rx_pkts`, and `ena_srd_mode` | `ena_stat` | Whether SRD is carrying traffic at all — positive proof ENA Express is enabled. The mode is **deltified and unreliable**; this finding is better evidence. See `disabled-ena-express.md` |
| The four allowance counters | `ena_stat` | **All zero is the characteristic pattern** — SRD resources are consumed by connection count, not traffic volume |
| `conntrack_allowance_exceeded`, `conntrack_allowance_available` | `ena_stat` | **The closest analogue.** Another per-connection capacity limit; both saturate from the same churn. See `Connection Tracking Exceeded Instance Allowance` |
| Connection counts, `TIME_WAIT`, establishment rate | `netstat` | **The driver.** Concurrent connections and churn are what consume the SRD pool |
| TCP retransmits and error counters | `netstat` | Whether the escalation from fallback to drops has begun |
| `tx_cnt`, `rx_cnt`, mean packet size | `ena_stat` | Traffic profile; small packets with many connections is the highest-pressure shape. Both are **per queue** (`ena_stat.rs:327`–`:341`), so sum the queue series |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the series is continuous, and whether an interface event coincides with the spike. "A reset reinitializes the driver and temporarily disrupts network connectivity" |
| The aperf `warn!` log for skipped decreases | run log | How many releases of pool capacity the pipeline discarded — the missing half of any oscillation |
| Sample count / recording length | `aperf_stats` / run metadata | Whether p99 rests on enough samples to mean anything. **No analytical rules — read manually** |
| Instance type and size | `systeminfo` | **The SRD pool size is a property of this value** — required to judge the scale-out decision |
| `number_threads`, per-process connections | `processes` | Thread-per-connection designs, and which process opens the connections. **No analytical rules — read manually** |
| `idle`, `aggregate` | `cpu_utilization` | Idle CPU with SRD saturation = card-state-limited, not compute-limited. See `Underutilized CPU` |
| Peer instance's `ena_stat`, if available | `ena_stat` (other run) | SRD is end-to-end; the peer has its own pool |

## Guidance

Ordered. **Step 1 matters more here than for most rules** because the metric's semantics are not what the
rule assumes.

1. **Read the series and interpret the values as per-interval *changes*, not levels.** A single large step
   followed by near-zero deltas means utilization jumped and **stayed** high — the dangerous case. Small
   positive deltas with no gaps mean a monotonic climb, i.e. pool entries are not being released. Exactly two
   points means the gauge never moved and the chart tells you nothing about the level. And **ignore the
   score**: bounded between −16.00 and −16.84, so a marginal firing and full saturation are
   indistinguishable.

2. **Check whether the consequence has already materialized, and whether drops have begun.** Compare
   `ena_srd_eligible_tx_pkts` with `ena_srd_tx_pkts`; if `Low SRD Usage Rate` also fired, **cause and effect
   are both confirmed**. Then read the `netstat` retransmit and error counters — the message escalates from
   fallback to dropped packets, and drops turn a latency problem into a throughput problem.

3. **Confirm the characteristic pattern: the allowance counters.** All four at zero is expected and
   informative — it proves the limit is *connection state on the card*, not bandwidth or packet rate, so
   nothing about traffic volume needs changing.

4. **Find the connection pressure — the actual driver.** Read the `netstat` connection counts and churn and
   the `processes` list. SRD pool use scales with **concurrent connections**, so the levers are pooling,
   reuse, and fan-out, not payload size. If `Connection Tracking Exceeded Instance Allowance` also fired,
   that is strong corroboration and one fix addresses both.

5. **Check the sample count.** p99 on a short recording is effectively the maximum, and one interval then
   decides the finding.

6. **Use this finding to correct the mode findings.** This metric only moves when SRD is in use, so the
   finding is positive proof that ENA Express is enabled regardless of what `Disabled ENA Express` says.

7. **Remediate**, following the metric description's own guidance and ordered by cost:
   - **Reduce concurrent SRD connections and churn** — pooling and keep-alive, reuse instead of one
     connection per request, and less fan-out so one unit of work does not open several. The cheapest durable
     fix; it addresses connection tracking at the same time, and long-lived connections stop the
     establish/tear-down cycle that keeps utilization pinned.
   - **Reconsider UDP support** if mode 3 is enabled and UDP traffic is high-connection-count: moving to
     mode 1 removes UDP from SRD and frees pool capacity, at the cost of the UDP tail-latency benefit. See
     `Enabled ENA Express without UDP`.
   - **Scale out.** The metric description is explicit: *"High resource utilization is a sign that it's time
     to scale the instance out to improve network performance."* Distributing connections across more
     instances multiplies the available pool. **Scaling up** also works, since the pool is sized by instance
     type.
   - **Consider whether ENA Express is the right tool** if the connection count is irreducible and the traffic
     is not tail-latency-sensitive: standard ENA has no such pool, so disabling removes the constraint along
     with the benefit. Land on a coherent mode — see `Disabled ENA Express with Previously Enabled UDP`.
   - **Check the peer side** — SRD is end-to-end and the receiving instance has its own pool.

8. **Do not conclude "no problem" from the absence of this finding.** A steadily saturated instance produces
   near-zero deltas and never fires it. Read the series and `Low SRD Usage Rate` instead.

## Priority and execution risk

**Priority: P2 — Plan** by default when this fires. The realized harm is silent degradation, not an outage:
eligible packets fall back to standard ENA and the tail-latency benefit the instance was configured for
stops arriving, with no error counter anywhere to show it. It rises to **P1 — Act now** when the escalation
the message names has actually begun — `Low SRD Usage Rate` also fired *and* `netstat` shows elevated
retransmits or drops, or application tail latency has regressed — because at that point SRD capacity is no
longer just failing to help, it is losing traffic, and for TCP each drop costs far more throughput than the
drop count suggests. It drops to **P3 — Monitor** when the deltas are confined to startup or to one
identified load event (a deploy, a cache warm, a reconnect storm after a peer restart) and the rest of the
run is clean, and to **P4 — Informational** when the p99 rests on a handful of samples, when the spike sits
inside a live-migration window, or when only the `average` series of three or more interfaces shows it.
**Note that the absence of this finding never lowers priority for anything**, because the deltified gauge
cannot report a steady saturation at all.

**Execution risk: R0 — Read-only** for the entire diagnosis: the series and its point count, the
eligible-versus-actual gap, the allowance counters, `netstat` connection counts and churn, the `processes`
list, the sample count, and the run log for skipped decreases. **R1** for re-recording a steady-state window
to separate startup from steady state, and for adding connection-count or SRD-utilization monitoring so the
level — which aperf cannot show — is observable next time. **R2** for the connection-side fixes that are the
cheapest real remediation: pooling and keep-alive, raising connection reuse, and reducing fan-out, all
application or client-configuration changes with bounded blast radius and the only remediation that lowers
pool consumption without buying capacity; **R2** also for dropping UDP support (mode 3 → mode 1) to free pool
entries, which removes acceleration from every UDP application on the ENI. **R3** for scaling up, since the
pool is sized by instance type and this is a replacement; **R3** for scaling out, which changes capacity and
cost and needs the traffic to actually distribute; and **R3** for disabling ENA Express entirely, the only
option that removes the constraint outright and the only one that also removes the benefit. **Do not carry
the R0 of the diagnosis into any of these.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: the p99 of `ena_srd_resource_utilization`, on the series at `stats_series_idx`, exceeded
95.0 — which given the deltification means a single-interval *change* of more than 95 percentage points, not
a utilization level.

```
STEP 0 — WHERE do the large deltas land? The metric is deltified, so a firing is a CHANGE.
  IF the large deltas are confined to the first one or two intervals
  THEN → startup connection establishment: utilization stepped up once as flows were opened and
         the p99 caught that step. Usually benign, but it says nothing about the LEVEL it
         settled at afterwards (P3, R1)
       → verify: re-record a steady-state window with `--period 300`; that run shows near-zero
         deltas whatever the level, so confirm the level out of band
  IF the deltas align with an identified load event — a deploy, a cache warm, a peer restart
  THEN → a reconnect storm: real and bounded, the pool absorbed a burst of connections and
         released them again (P3, R0)
       → verify: the same event in the `netstat` connection-establishment counters, and no
         sustained eligible-vs-actual gap after the window closes
  IF the run overlaps a live migration or live server update
  THEN → named upstream as a cause of SRD disruption. Transient and unfixable (P4, R1)
       → verify: a clean run outside the window shows no >95-point delta
  OTHERWISE
  THEN → the jump happened during steady-state workload — the case worth pursuing. Continue to
         STEP 1 (P2, R0)

STEP 1 — What does the SERIES SHAPE say? Read the values as changes, never as levels.
  IF the chart shows exactly TWO data points
  THEN → the all-zero compression fired (time_series_data_processor.rs:410-:427), so the gauge
         NEVER MOVED and cannot tell you whether the level was 2% or 99%. Go to STEP 2 (P3, R0)
  IF one large positive delta is followed by near-zero for the rest of the run
  THEN → utilization jumped and STAYED high — the dangerous steady state, and that single step
         is the only part of it the pipeline can show you (P2, R0)
  IF small positive deltas run the whole length with NO gaps
  THEN → a monotonic climb: pool entries taken and never released, the strongest available
         signal for missing connection reuse (P2, R0)
  IF large positive deltas are separated by gaps
  THEN → oscillation. The gaps are the releases the pipeline DISCARDS (:214 returns None), so
         only the upward half is visible. This is connection churn (P2, R0)
  OTHERWISE
  THEN → shape inconclusive. Continue to STEP 2 and let the consequence decide (P2, R0)

STEP 2 — Has the CONSEQUENCE materialized, and is this ceiling even the right one?
  IF `Low SRD Usage Rate` also fired
  THEN → cause and effect BOTH confirmed: SRD resources exhausted, eligible packets already
         falling back. The clearest actionable case in the SRD family. Continue to STEP 3
         (P2, R0)
  IF `netstat` shows elevated retransmits or drops alongside the gap
  THEN → the escalation the message names has begun: SRD capacity is no longer just failing to
         help, it is losing traffic, and for TCP each drop costs far more throughput than the
         count suggests (P1, R0)
       → verify: correlate the drop window against the utilization deltas, then confirm both
         recede together after remediation
  IF any allowance finding also fired
  THEN → a separate ceiling that OUTRANKS this finding: SRD does not raise any allowance and
         shaping does not consume SRD pool. Fix that first. see that playbook (P2, R0)
  IF all four allowance counters read zero
  THEN → expected and informative: the limit is CONNECTION STATE ON THE CARD, so nothing about
         traffic volume needs changing. Continue to STEP 3 (P2, R0)
  OTHERWISE
  THEN → no measurable consequence yet; a warning ahead of a realized loss and cheaper to act
         on now. Continue to STEP 3 (P3, R0)

STEP 3 — Find the DRIVER. Pool use scales with concurrent connections, not bytes.
  IF `netstat` shows a high concurrent connection count
  THEN → the direct driver: pool capacity is per connection, so the count is the number to
         reduce. Continue to STEP 4 (P2, R0)
  IF `netstat` shows high churn — a large `TIME_WAIT` population or establishment rate
  THEN → connection-per-request behaviour: each establish/tear-down cycle takes and returns a
         pool entry, pinning utilization without a high steady count. Continue to STEP 4
         (P2, R0)
  IF `processes` shows a thread-per-connection design or heavy outbound fan-out
  THEN → one unit of work opens several SRD connections, multiplying pool use per request — the
         highest-leverage thing to change. Continue to STEP 4 (P2, R0)
  IF `Connection Tracking Exceeded Instance Allowance` also fired
  THEN → strong corroboration: two per-connection limits saturating from the same churn, so one
         connection-side fix addresses both. Continue to STEP 4 (P2, R0)
  IF `ena_srd_mode` indicates UDP support and UDP traffic is high-connection-count
  THEN → mode 3 puts UDP on SRD too, so UDP is adding pool pressure. Note it as a lever and
         read `enabled-ena-express-without-udp.md`. see that playbook (P3, R0)
  OTHERWISE
  THEN → no connection-side driver visible in the report. Continue to STEP 4 (P3, R0)

STEP 4 — Can the pool consumption be REDUCED before capacity is bought?
  IF connections are not pooled or reused
  THEN → enable pooling and keep-alive and reuse connections instead of one per request. The
         cheapest durable fix, and it lowers connection tracking too (P2, R2)
       → verify: concurrent connection count and `TIME_WAIT` both fall and the utilization
         deltas shrink; if they do not, the pool pressure is elsewhere
  IF fan-out is reducible — batching, coalescing, or fewer downstream calls per request
  THEN → fewer SRD connections per unit of work, so the saving scales with traffic rather than
         with instance count (P2, R2)
       → verify: outbound connections per request fall in the application's own metrics before
         re-reading `ena_stat`
  IF UDP support is enabled and the UDP traffic does not need SRD
  THEN → drop to mode 1 to free pool entries. This removes acceleration from EVERY UDP
         application on the ENI, since the setting is per-ENI (P3, R2)
       → verify: `processes` for UDP-owning processes first; then confirm the utilization
         deltas fall and no UDP application regresses
  OTHERWISE
  THEN → the connection count is irreducible. Continue to STEP 5 (P2, R0)

STEP 5 — Buy capacity, or stop paying for SRD. Both are instance-level decisions.
  IF the traffic distributes across instances
  THEN → SCALE OUT, AWS's own recommendation for this metric: more cards means more pool, and
         distributing connections is what actually multiplies capacity (P2, R3)
       → verify: per-instance concurrent connection count falls proportionally, and the
         eligible-vs-actual gap narrows on each instance
  IF the traffic cannot be distributed
  THEN → SCALE UP: the pool is sized by instance type, so a larger instance carries a larger
         pool. A replacement, not a configuration change (P2, R3)
       → verify: the eligible-vs-actual gap narrows on the new type, and tail latency improves
         at p99 and p99.9 rather than at the mean
  IF the connection count is irreducible AND the traffic is not tail-latency-sensitive
  THEN → ENA Express may be the wrong tool: standard ENA has no such pool, so disabling removes
         the constraint along with the benefit. Land on a coherent mode (0, 1 or 3) (P3, R3)
       → verify: tail latency does not regress after disabling; read
         `disabled-ena-express-with-previously-enabled-udp.md` before leaving the UDP flag set
  IF neither resources nor churn explains the spike locally
  THEN → SRD is end-to-end and the receiving instance has its OWN pool, so the limit may not be
         on this instance at all (P3, R0)
       → verify: the peer's `ena_stat` if a recording exists; its eligible-vs-actual gap and
         utilization deltas tell the same story from the other side

STEP 6 — What survives?
  VALID      : that a single-interval change in SRD resource use exceeded 95 percentage points;
               that the SRD pool is consumed by CONCURRENT CONNECTIONS rather than bandwidth,
               so all four allowance counters can read zero while it saturates; the
               fallback-then-drops escalation; and AWS's own scale-out recommendation, which
               comes from the metric description rather than from inference
  CAUTION    : a p99 resting on a handful of samples, where it is effectively the maximum; a
               p99 taken from the `average` series of >=3 interfaces, where one interface may
               be wholly responsible; and any conclusion about the utilization LEVEL drawn from
               a series that only contains changes
  CONFOUNDED : the whole series when a live migration or interface reset falls inside the run;
               and any oscillation amplitude, since the downward half is discarded at :214 and
               only the upward half appears
  VOID       : "utilization was above 95%" — the reported p99 is a per-interval CHANGE, not a
               level; the score as a severity signal, bounded to -16.00 .. -16.84 whatever the
               state of the card; and above all the inference that ABSENCE of this finding
               means headroom, since a steadily saturated instance produces near-zero deltas
               and cannot fire the rule at all

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205);
         `lo`, `docker*`, `veth*`, `br-*` and `virbr*` are skipped, so a container with only
         virtual interfaces collects nothing (P4, R0)
  IF `ena_srd_*` metrics are absent while other `ena_stat` metrics are present
  THEN → the driver or instance type does not expose the SRD counters, so ENA Express is
         unsupported here and there is no pool to exhaust (P4, R0)
  IF the series has fewer than 3 points
  THEN → the first point is a structural zero, so 2 snapshots cover 1 real interval and p99 is
         that interval. Re-record with `--period 300` (P4, R0)
  IF the instance type is unknown
  THEN → the pool size is a property of the instance type, so the scale-out and scale-up
         decisions cannot be sized. Read `systeminfo` or the EC2 API first (P3, R0)
```

## Runtime-specific consequences

The pool is consumed by concurrent connections, so what matters is how many connections a runtime holds
open — not how fast it is.

- **High-fan-out services and RPC meshes.** The most exposed shape by a wide margin: every hop is its own
  SRD connection, so a mesh multiplies pool use per request. Sidecar proxies concentrate this on one ENI.
- **Connection-per-request clients.** The classic driver. Each request takes and returns a pool entry, so
  utilization stays pinned even at modest concurrency. Pooling is the fix, and it is the same fix connection
  tracking needs. **Thread-per-connection designs** are the same shape, and the thread count in `processes`
  is a direct proxy for the concurrent connection count.
- **UDP workloads under mode 3.** UDP traffic is on SRD too, so a high-connection UDP application competes
  for the same pool. Dropping to mode 1 is a real lever, at the cost of UDP acceleration.
- **Java.** Connection pools are usually explicit and configurable (HTTP client pools, JDBC pools, gRPC
  channels), which makes this one of the cheaper runtimes to fix — but check `java_profile` before blaming
  the network for a latency regression, since a 50 ms GC pause swamps any SRD effect.
- **Bulk-transfer workloads.** The least exposed: few flows, high bandwidth. If this finding fires on one,
  suspect churn or fan-out elsewhere on the instance rather than the transfer itself.
- **Containers.** ENA Express and its pool are properties of the **ENI**, shared by every container on the
  host, so one container's connection churn exhausts the pool for all of them and no per-container limit
  will show it.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in capacity.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and the delta caveat that makes
  a steady saturation invisible applies identically on both.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*` and
  `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`), so inside a container with
  only virtual interfaces **`ena_stat` collects nothing** and the rule cannot fire.
- **The pool size is a property of instance type and size, not of CPU architecture.** A Graviton migration
  at the same size neither grants nor removes SRD capacity — so if this finding appeared after such a
  migration, look for a change in connection behaviour, not in the card. Scale-up is a type change and the
  pool scales with it, which makes instance size the one lever guaranteed to work when the connection count
  is genuinely irreducible.
- **`.metal` and the largest family sizes** give the full non-shared network allowance. That changes the
  ceilings SRD does *not* affect, so keep it separate from any SRD before/after comparison.
- **Multi-ENI instances** each have their own SRD state, and with **≥3 series** the auto-generated `average`
  mixes them into a mean the p99 is then taken over. At exactly two series the aggregate is dropped
  (`:312`–`:319`), so read per-interface series before attributing the spike.

## Verification

The falsifiable claim is *this instance's network card is running out of SRD connection state, and that is
costing eligible packets their SRD path*. The second half is measurable in-report; the first is only
measurable as a change.

1. **Read the series before anything else, as changes.** One step then flat = jumped and stayed high; small
   deltas with no gaps = monotonic climb; gaps = discarded releases; exactly two points = the gauge never
   moved and the chart proves nothing about the level.
2. **Test the consequence, which is the falsifiable part.** `ena_srd_eligible_tx_pkts` above
   `ena_srd_tx_pkts` is the realized loss. If `Low SRD Usage Rate` also fired, cause and effect are both
   confirmed; if the gap is absent, this is a warning and not yet a loss.
3. **Predict the characteristic pattern and check it.** All four allowance counters should read zero. If one
   fired instead, the limit is bandwidth or packet rate, that finding outranks this one, and the SRD story is
   a side effect.
4. **Confirm the driver independently.** Concurrent connections, `TIME_WAIT`, and establishment rate in
   `netstat`, plus thread and connection counts in `processes`. A firing with no connection pressure anywhere
   is a signal to re-check the series and the sample count rather than to remediate.
5. **Rule out the artifacts.** The sample count (p99 on a short run is the maximum); `total_resets`,
   `interface_down` and `interface_up` for a discontinuity; the run log for skipped decreases; and whether
   the p99 comes from the `average` series of three or more interfaces.
6. **Predict the tail, then measure it — and do not close on absence.** Predict that p99 and p99.9 latency
   improve after remediation while the **mean barely moves**: SRD's benefit is a tail effect, and a flat mean
   is the usual reason a correct change gets judged a failure. The one claim this rule cannot make is that
   utilization was low, so if the question is headroom, add off-instance monitoring of the level (R1) rather
   than reading the deltified series — and expect `Disabled ENA Express` to keep firing regardless.

## Do not

- **Do not treat absence of this finding as evidence of SRD resource headroom.** The metric is a percentage
  gauge processed as a delta counter, so a steadily saturated instance produces near-zero values and never
  fires the rule.
- **Do not read the reported value as a utilization level.** It is a p99 of per-interval *changes*.
- **Do not read a two-point series as "stable and healthy".** The all-zero compression means the gauge never
  moved; the level could be 2% or 99%.
- **Do not rank on the score.** It is bounded between −16.00 and −16.84 regardless of how saturated the
  instance is.
- **Do not read the p99 as a typical value**, and do not act on one from a very short recording without
  checking the sample count. 99% of samples can be far lower, and on a short run the p99 is the maximum.
- **Do not expect the description to tell you the threshold.** `time_series_stat_threshold` omits both
  comparator and threshold; the threshold is 95.0.
- **Do not look for a bandwidth or packet-rate cause.** SRD resources are consumed by **concurrent
  connections**; all four allowance counters can be zero.
- **Do not stop at "scale out".** Connection pooling and reduced fan-out lower pool consumption directly and
  cost nothing in infrastructure.
- **Do not believe `Disabled ENA Express` over this finding.** This metric only moves when SRD is active.
- **Do not assume the limit is on this instance.** SRD is end-to-end; the peer's card has its own pool.
- **Do not ignore the escalation.** The message names fallback *and* dropped packets; check whether drops
  have already started — and do not judge the remediation by mean latency, since the benefit concentrates in
  the tail.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:99` — `time_series_stat_threshold`, `Stat::P99`,
  `Comparator::Greater`, threshold `95.0`, `Score::Poor`. The only `ena_stat` rule using a percentile, and
  with `:88` one of only two whose logic is sound.
- Rule template: `src/analytics/rule_templates/time_series_stat_threshold_rule.rs` — description is
  `format!("The {} in {} is {}.", stat, run_name, formatted_number_string(metric_stat))`, with **no**
  comparator or threshold. It reads a single series via `time_series_metric_stats`
  (`src/data/common/processed_data_accessor.rs:119`–`:130`) rather than iterating every series.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — general branch; the percentage domain
  bounds the score at ≈ −16.84. `Score::Poor = −16` at `:147`–`:157`; findings sort ascending by score
  (`src/report_frontend/src/utils/analytics.tsx:40`). Truncation, not rounding: `f64_to_fixed_2`,
  `src/computations/mod.rs:138`, used by `formatted_number_string` at `:176`.
- **The processing caveat:** `add_accumulative_data_point` in
  `src/data/common/time_series_data_processor.rs`, applied unconditionally to every `ena_stat` metric at
  `src/data/ena_stat.rs:343`, deltifies this percentage gauge. Forced first zero:
  `ignore_first_accumulative_value: true` at `:73`, taken at `:218`; the only opt-out,
  `use_first_accumulative_value()` (`:81`–`:83`), is called once, from `src/data/perf_stat.rs:1295`.
- **Why releases are invisible:** the `prev_value > data_value` arm returns `None` at
  `time_series_data_processor.rs:214`, `add_data_point_impl` returns early at `:150`, and the only trace is
  one `warn!` at `:297`–`:302`. All-zero compression to two points:
  `compress_all_zero_time_series_metric`, `:410`–`:427`.
- Average aggregate and the two-series collapse: `src/data/ena_stat.rs:315`;
  `time_series_data_processor.rs:249`–`:256` and `:312`–`:319`. Queue-name flattening, `:327`–`:341`.
- Metric semantics: `ena_srd_resource_utilization` at
  `src/report_frontend/src/definitions/data-descriptions.ts:3884` (`desired: "lower"`,
  `unit: "Utilization (%)"`) — the source of the fallback/drop mechanism and the scale-out recommendation;
  `ena_srd_eligible_tx_pkts` at `:3871` names the three fallback causes.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL` and the
  `ETHTOOL_GSSET_INFO`/`GSTRINGS`/`GSTATS` sequence, `:31`–`:33`, `:216`. **No upstream guidance exists:**
  `src/report_frontend/src/definitions/optimization-guides.ts` contains only the four EC2 network allowance
  guides (`:117`, `:125`, `:134`, `:146`) — nothing for SRD.
- Related playbooks: `low-srd-usage-rate.md` (the effect this is the cause of),
  `connection-tracking-exceeded-instance-allowance.md` (the closest analogue), `disabled-ena-express.md`,
  `enabled-ena-express-without-udp.md`, `ena-express-enabled-with-udp.md`,
  `disabled-ena-express-with-previously-enabled-udp.md`.
- [ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express.html)
- [Configure ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express-configure.html)
- [Monitor network performance for your EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
