---
rule_name: Enabled ENA Express without UDP
data_type: ena_stat
data_key: ena_srd_mode
template: time_series_data_point_threshold
condition: "any(ena_srd_mode) == 1.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "ENA Express is enabled but only for TCP traffics. Verify if ENA Express with UDP needs to be enabled too."
source: src/analytics/rules/ena_stat.rs:64
---

# Enabled ENA Express without UDP

## What fired

**At least one** data point of `ena_srd_mode` was **equal to 1.0** — read literally, "ENA Express on,
UDP off": SRD is accelerating TCP traffic but UDP traffic still uses standard ENA.

Base score `Concerning` (**−1**). Single-run rule, `Comparator::Equal` (`ena_stat.rs:64`). With an
`Equal` comparator the score is **always exactly −1.00**.

**This rule is effectively unreachable on aperf 1.3.0, and when it does fire it means something other
than what it says.** Read the next section first.

## The processing defect — verified by running the engine

`ena_srd_mode` is a **mode enum** (0/1/2/3), but every `ena_stat` metric is passed through
`add_accumulative_data_point` at `src/data/ena_stat.rs:343`, which stores **per-interval differences**
and forces the first sample to 0 (`ignore_first_accumulative_value: true`,
`time_series_data_processor.rs:73`; the only opt-out in the tree, `use_first_accumulative_value()`, is
called once, from `perf_stat.rs:1295`). A mode does not accumulate, so:

- **A device with ENA Express on and UDP off** reports raw `1, 1, 1, …` → aperf stores
  `[0.0, 0.0, 0.0, …]` → the rule that fires is **`Disabled ENA Express`** (== 0), not this one.
- **This rule can therefore never fire on a steady-state mode of 1.**

What *can* make it fire is a **delta that happens to equal 1** — i.e. the mode changing mid-recording
by exactly +1:

| transition during the run | delta | rule that fires |
|---|---|---|
| 0 → 1 (ENA Express turned on for TCP) | +1 | **this rule** — coincidentally the right conclusion |
| 1 → 2 | +1 | **this rule** — wrong; the device ended in mode 2 |
| 2 → 3 (UDP support re-enabled) | +1 | **this rule** — wrong; the device ended in mode 3, the *ideal* state |
| any decrease (e.g. 3 → 2) | **no data point at all** | none |

Verified behaviour: with a constant `ena_srd_mode = 3` the engine produced the series `[0.0, 0.0]` and
emitted **`Disabled ENA Express`** with score `−1.0` and the description `is 0 (equal to the threshold of
0)`. The mode-specific rules never see raw values.

The decrease row is stronger than "skipped". `get_delta_and_set_previous_value`
(`time_series_data_processor.rs:189`–`:224`) sees `prev_value > data_value`, emits a `debug!`, increments
a per-key counter, and `return None` at `:214`; `add_data_point_impl` then returns early at `:150`, so
**no series entry is created** — a gap, not a zero. One `warn!` is emitted at the end of processing
(`:297`–`:302`):

```
<data_name>.<metric>.<series>: skipped N data points due to unexpected decrease of accumulative data.
```

That log line is the only in-report evidence that the mode fell during the run. Two further observable
artifacts: **a constant mode renders as exactly two data points**, because
`compress_all_zero_time_series_metric` (`:410`–`:427`) compresses every series to its first and last
point when the metric's min and max are both 0.0 — so a two-point `ena_srd_mode` chart proves the mode
never changed and this rule could not have fired. And **the `average` series may not exist**: `ena_stat`
aggregates with `time_series_data_processor_with_average_aggregate` (`ena_stat.rs:315`), but `:312`–`:319`
removes the auto-generated aggregate when there are exactly two series, so the cross-interface mean only
appears with **three or more** series.

**So if you are reading this finding, the correct interpretation is: the ENA Express mode changed by +1
at some point during the recording.** That is genuinely interesting — a configuration change mid-run
invalidates comparisons across the recording — but it is not "ENA Express is enabled without UDP".
Verify the actual mode out of band.

The rest of this playbook covers the question the rule *intended* to ask, which is a good one whenever
the device really is in mode 1.

## Reasoning

`ena_srd_mode` "Indicates whether ENA Express is configured. 0 = ENA Express off, UDP off; 1 = ENA
Express on, UDP off; 2 = ENA Express off, UDP on (only happens after disabling the previously enabled
ENA Express with UDP); 3 = ENA Express on, UDP on." (`data-descriptions.ts:3859`, `desired: "fixed"`)

Mode 1 is the **default when ENA Express is enabled**: TCP gets SRD, UDP does not. Enabling UDP support
is a separate, explicit setting. So mode 1 is not a misconfiguration — it is what you get if you turn
ENA Express on and stop there. The rule's phrasing reflects that precisely: *"Verify if ENA Express
with UDP needs to be enabled too."*

**Why UDP support is worth a separate question.** SRD's value is multipath routing and reduced tail
latency. For TCP, SRD also absorbs reordering internally so the TCP stack does not see it. For UDP the
trade-off is different, and that difference is the substance of this finding:

- **UDP-heavy latency-sensitive workloads gain the most** and are exactly the ones left behind by mode
  1. Real-time media, game servers, telemetry, QUIC/HTTP-3, gRPC over QUIC, and custom UDP RPC
  protocols all ride on UDP and see no benefit at all in mode 1.
- **DNS is UDP**, though at packet rates too low for SRD to matter much — and note that VPC DNS is
  link-local traffic anyway (see `Link-Local Service Exceeded Instance Allowance`).
- **UDP applications must tolerate reordering.** SRD sprays packets across paths; for UDP that
  reordering is exposed to the application, because there is no transport layer restoring order.
  Applications that already assume UDP may arrive out of order are fine. Applications that were written
  against a single-path network and quietly depend on mostly-ordered delivery can behave worse. **This
  is the one real risk of enabling UDP support, and it is why the rule asks rather than tells.**
- **UDP support consumes the same SRD resources.** Adding UDP traffic to SRD increases concurrent SRD
  usage — see `High SRD Resource Utilization` and `Low SRD Usage Rate`. On an instance already near the
  resource ceiling, enabling UDP can push both TCP and UDP into fallback.

The score is `Concerning` (−1), the mildest negative aperf defines, which is the right weight: mode 1
is a legitimate configuration and for a TCP-only workload it is *optimal*.

**And aperf offers no guidance on the decision.** `optimization-guides.ts` contains only the four EC2
network *allowance* guides (`:117`, `:125`, `:134`, `:146`) — there is **no ENA Express or SRD guide at
all**, so everything below comes from the metric descriptions and AWS documentation.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"equal to"`:

```
At least one data point in aperf_record is 1 (equal to the threshold of 1).
```

**The value carries no information** — with `Equal` it is always the threshold. And per the defect
above, that `1` is a **delta between consecutive mode samples**, not the mode itself.

Score math — `compute_finding_score(1.0, 1.0, −1)`, the general branch: `delta = 1/1 = 1`, so
`score = 1 × −1`:

| value | score | note |
|---|---|---|
| 1.0 (the only possible value) | **−1.00** | the comparator admits no other value |

**Always −1.00.** Nothing to rank; nothing recoverable from the score.

## Interpretation

**First, resolve what actually happened**, since the firing means a +1 transition rather than a state:

| Verified real mode at end of run | Reading |
|---|---|
| **1** — on, UDP off | The transition was 0 → 1: ENA Express was turned on during the recording. The finding's question now applies — read the UDP table below. Also treat the run as spanning a configuration change |
| **2** — off, UDP previously on | The transition was 1 → 2, i.e. **ENA Express was turned off mid-run**. Far more significant than this finding suggests; see `Disabled ENA Express with Previously Enabled UDP` |
| **3** — on, UDP on | The transition was 2 → 3: the configuration moved to the **ideal** state. A negative finding reporting an improvement |
| **0** — off, UDP off | Inconsistent with a +1 delta; suspect an interface flap or counter discontinuity. Check `total_resets` / `interface_down` / `interface_up` |

Any of these also means the recording **spans a configuration change**, so metrics before and after are
not comparable. That is worth flagging on its own.

Once the real mode is known to be 1, the question is whether UDP support should be enabled:

| Workload characteristic | Enable UDP support? |
|---|---|
| **No UDP traffic to speak of** | **No.** Mode 1 is optimal. The finding is informational |
| UDP-based RPC, QUIC/HTTP-3, gRPC-over-QUIC | **Likely yes** — these are latency-sensitive and entirely excluded in mode 1 |
| Real-time media, game servers, voice | **Likely yes**, if tail latency matters and reordering is already handled |
| Telemetry / metrics over UDP, fire-and-forget | **Marginal.** Loss-tolerant, latency-insensitive; little to gain |
| UDP application assumes near-ordered delivery | **Careful.** SRD sprays across paths; UDP reordering is exposed to the application |
| Already near the SRD resource ceiling | **No, not yet.** Adding UDP increases SRD resource pressure. Fix that first |
| UDP traffic is cross-AZ or internet-facing | **No benefit** — ENA Express requires both endpoints in the same AZ |
| Peer endpoints not under your control | **No** — both ends must have it enabled |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Disabled ENA Express` **also fired** | **Expected on 1.3.0** — the flat-delta series contains zeros, so the == 0 rule fires alongside any transition rule. Not a contradiction, an artifact |
| `High SRD Resource Utilization` fired | **Do not enable UDP support yet.** SRD resources are already stressed; adding UDP traffic will worsen fallback for TCP too |
| `Low SRD Usage Rate` fired | Eligible packets are already falling back to standard ENA. Resolve that before adding UDP to the mix |
| `ena_srd_tx_pkts` / `ena_srd_rx_pkts` non-zero | Confirms SRD is active — consistent with a mode of 1 or 3 |
| `tx_cnt` − `ena_srd_tx_pkts` is small | **The one decisive test available in the report.** In mode 1 only TCP rides SRD, so this difference bounds the non-SRD traffic *from above*; if it is small, UDP is necessarily small and **the finding is moot** |
| `tx_cnt` − `ena_srd_tx_pkts` is large | Inconclusive, not confirmation: the gap also holds ineligible TCP (cross-AZ, non-Express peers, oversized packets). Measure UDP on the instance before acting |
| `ena_srd_mode` chart shows exactly **two** points | The all-zero compression fired (`:410`–`:427`): the mode was constant, so this rule **could not** have fired |
| Any allowance finding | Separate ceilings; SRD does not raise them. Fix those first |
| `Underutilized CPU` with UDP-heavy traffic | Network-bound on a path SRD is not accelerating in mode 1 |

**Known false positives:**

- **The rule fires on a +1 delta, not on mode 1.** On aperf 1.3.0 this is the *only* way it can fire.
  The most likely reason you are reading it.
- **The transition was 1 → 2 or 2 → 3**, so the conclusion in the message is wrong about the current
  state — and in the 1 → 2 case it hides a more serious condition.
- **Multi-interface averaging**, but only with **≥3 series**: the rule scans the auto-generated `average`
  series, so a mean across interfaces can land on exactly 1.0 without any single interface transitioning
  by 1. With exactly two series the aggregate is removed (`:312`–`:319`).
- **Interface flap or counter reset.** Decreasing samples produce no data point at all, but a reset can
  produce a spurious *increase*. Check `total_resets` / `interface_down` / `interface_up`.
- **The workload has no UDP traffic**, in which case even a correct firing is informational only.
- **UDP traffic is cross-AZ**, where ENA Express does not apply regardless of the setting.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| UDP packet, datagram, and error counters | **not collected** | **The decisive number, and aperf does not have it.** `NetstatRaw` reads only `/proc/net/netstat` (`netstat.rs:33`), which carries `TcpExt:` and `IpExt:` and **no UDP section** — the UDP counters live in `/proc/net/snmp`, which no collector reads. Measure on the instance: `ss -su`, `nstat -z \| grep -i udp`, or `/proc/net/snmp` |
| `tx_cnt` − `ena_srd_tx_pkts`, `rx_cnt` − `ena_srd_rx_pkts` | `ena_stat` | **The closest in-report proxy.** An upper bound on non-SRD traffic, so a *small* gap rules UDP out; a large gap is inconclusive, since ineligible TCP lands in it too. `tx_cnt`/`rx_cnt` are **per queue** (`ena_stat.rs:327`–`:341`), so sum the queue series |
| `ena_srd_tx_pkts`, `ena_srd_rx_pkts` | `ena_stat` | Whether SRD is actually carrying traffic. Read manually — no rule fires on these |
| `ena_srd_resource_utilization` | `ena_stat` | **Gate before enabling UDP.** Near the ceiling means adding UDP will cause fallback. See `High SRD Resource Utilization` |
| `ena_srd_eligible_tx_pkts` vs `ena_srd_tx_pkts` | `ena_stat` | Existing fallback rate. See `Low SRD Usage Rate` |
| `ena_srd_mode` series, and its **point count** | `ena_stat` | **Deltified** — look for where the +1 step occurs to locate the configuration change in time; a two-point chart means no step happened |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the delta is a real transition or a counter discontinuity. "A reset reinitializes the driver and temporarily disrupts network connectivity" |
| The four allowance counters | `ena_stat` | Separate ceilings, unaffected by SRD |
| `tx_cnt`, `rx_cnt`, mean packet size | `ena_stat` | Packet-rate profile; small-packet UDP is where SRD resource pressure grows fastest |
| Instance type and size | `systeminfo` | ENA Express support and the AZ constraint context |
| MTU configuration | `systeminfo` / `sysctl` | SRD MTU cap is 8900; oversized packets fall back. **No analytical rules for `sysctl` — read manually** |
| Per-process activity | `processes` | Which process owns the UDP traffic. **No analytical rules — read manually** |
| On-CPU profile | `perf_profile` / `java_profile` | Whether UDP send/receive paths are hot. Requires `--profile` |
| The aperf `warn!` log for skipped decreases | run log | A skipped decrease on `ena_srd_mode` means the mode **fell** mid-run — a change no rule in this family can report |
| Out of band: EC2 API / `ethtool` on the ENI | — | **The authoritative mode and UDP setting.** aperf cannot answer this on 1.3.0 |

## Guidance

Ordered. **Step 1 is establishing what the firing actually means** — it is not the state the message
describes.

1. **Treat this as "the ENA Express mode changed by +1 during the recording", not as a mode reading.**
   Locate the step in the `ena_srd_mode` series to find *when*. A configuration change mid-run means
   metrics before and after are not comparable — flag that regardless of the UDP question.

2. **Verify the real mode out of band** (EC2 API or `ethtool` on the ENI). If it is 2, you have a more
   serious condition — ENA Express was turned off mid-run; see
   `Disabled ENA Express with Previously Enabled UDP`. If it is 3, the configuration moved to the ideal
   state and this negative finding is reporting an improvement.

3. **Ignore the score.** Always exactly −1.00.

4. **If the mode really is 1, quantify the UDP traffic before recommending anything** —
   **but not from `netstat`, which has no UDP counters at all.** `NetstatRaw` reads only
   `/proc/net/netstat` (`netstat.rs:33`), carrying `TcpExt:` and `IpExt:`; the UDP counters are in
   `/proc/net/snmp`, which no aperf collector reads. Two options, in order:
   - **From the report, as an upper bound.** In mode 1 only TCP rides SRD, so `tx_cnt` −
     `ena_srd_tx_pkts` bounds the non-SRD packet count from above. **A small gap rules UDP out and
     closes the finding** — mode 1 is optimal and the finding is informational. A large gap proves
     nothing on its own, because ineligible TCP (cross-AZ, non-Express peers, packets over 8900) is in
     it too.
   - **On the instance, for the actual number.** `ss -su`, `nstat -z | grep -i udp`, or
     `/proc/net/snmp` directly. Required before recommending the change; the report cannot substitute.

5. **Gate on SRD resource headroom.** Check `ena_srd_resource_utilization` and the eligible-vs-actual
   gap. If `High SRD Resource Utilization` or `Low SRD Usage Rate` fired, **do not enable UDP support
   yet** — adding UDP traffic to a resource-constrained SRD path pushes TCP into fallback too. Resolve
   that first. And note that a *low* utilization reading is not headroom: because the gauge is
   deltified, a steadily saturated card produces near-zero deltas and never fires its rule.

6. **Check applicability**, same as for enabling ENA Express at all: instance-type support, both
   endpoints in the **same Availability Zone**, and peers you control that can enable it too. Any "no"
   makes the recommendation unactionable.

7. **Assess reordering tolerance — the real risk.** SRD sprays packets across paths; with UDP there is
   no transport layer restoring order, so the application sees reordering directly. Confirm the
   protocol handles it (sequence numbers, jitter buffer, idempotent handling) before enabling.

8. **If enabling UDP support:**
   - Enable it on **both endpoints**.
   - Re-check the **8900 MTU cap** — oversized packets fall back to standard ENA.
   - Measure **tail latency** for the UDP path specifically; that is where the gain appears.
   - Watch `ena_srd_resource_utilization` and the eligible-vs-actual gap afterwards; the added UDP
     load is the thing most likely to push utilization over.

9. **If mode 1 is deliberate, record that.** The rule says "Verify if ENA Express with UDP needs to be
   enabled too" — a documented "no, no meaningful UDP traffic" is a complete resolution.

## Priority and execution risk

**Priority: P2 — Plan** whenever this finding is *present*, and the reason has nothing to do with UDP: on
aperf 1.3.0 presence means the mode stepped by **+1 during the recording**, so the run spans a
configuration change and every before/after comparison in the whole report crosses a data-path boundary.
That invalidation outranks the UDP question and is the finding's real content. It rises to **P1 — Act
now** in the one case the message actively conceals: a `1 → 2` transition, where **ENA Express was turned
off mid-run** — a `Bad` (−2) condition wearing a `Concerning` label, and a configuration regression
someone should know about. Once the mode is confirmed as a steady 1 and the run boundary is accounted
for, the UDP question itself is **P3 — Monitor** when UDP traffic is substantial, latency-sensitive and
reordering-tolerant within one AZ, and **P4 — Informational** when UDP traffic is negligible — which the
in-report upper bound can establish on its own, and which is the common case. It drops to **P4** outright
when `High SRD Resource Utilization` or `Low SRD Usage Rate` also fired, because the answer is then "not
yet" regardless of the UDP volume.

**Execution risk: R0 — Read-only** for the whole diagnosis: locating the step, the out-of-band mode
query, the `tx_cnt` − `ena_srd_tx_pkts` upper bound, the resource-headroom check, and the run-log check
for skipped decreases. The instance-side UDP measurement (`ss -su`, `nstat`, `/proc/net/snmp`) is also
R0. Acting is where risk appears. **R1** for re-recording a run that does not straddle the configuration
step, and for adding UDP tail-latency and ordering measurement. **R2 — enabling UDP support**: a network
configuration change on the ENI that must be applied on **both endpoints**, and one that exposes
multipath reordering directly to every UDP application on the instance — including ones you did not
consider, since the setting is per-ENI and not per-process. **R2** also for reconciling a 9001 MTU down
to the 8900 SRD cap. **R3** if the resource-headroom gate fails and resolving it needs a resize to obtain
more card SRD resources. **Do not inherit the R0 of the measurement into the enablement.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `ena_srd_mode` interval delta, on any series, was `== 1.0` — which on
aperf 1.3.0 requires a mode change of exactly +1 during the recording, not a steady state.

```
STEP 0 — What the firing actually means. It is a TRANSITION, not a state.
  IF the `ena_srd_mode` chart shows exactly TWO data points
  THEN → contradiction: the all-zero compression fired
         (time_series_data_processor.rs:410-:427), which requires a CONSTANT mode, so no +1
         step occurred on a real series. The delta came from the aggregate. Go to STEP 1
         (P3, R0)
  IF `total_resets`, `interface_down` or `interface_up` is non-zero
  THEN → the driver reset or the link flapped, so the counter baseline moved for reasons
         unrelated to configuration. "A reset reinitializes the driver and temporarily
         disrupts network connectivity", so treat the step as unproven (P3, R0)
       → verify: confirm the current mode out of band; if it matches the pre-run mode, the
         delta was a discontinuity and there was no configuration change
  OTHERWISE
  THEN → a genuine +1 mode step occurred during the run. Continue to STEP 1 (P2, R0)

STEP 1 — WHICH transition was it? Three are possible and they mean opposite things.
         aperf cannot tell you; the out-of-band mode can.
  IF the mode is confirmed 2 at the end of the run
  THEN → the transition was 1 -> 2: ENA EXPRESS WAS TURNED OFF mid-recording, leaving the UDP
         flag set. A Bad (-2) condition wearing this Concerning label, and the one case this
         message actively conceals. Read
         `disabled-ena-express-with-previously-enabled-udp.md` (P1, R0)
       → verify: whether the disabling was intentional; an unplanned drop from mode 3 is a
         configuration regression and the UDP question below is irrelevant
  IF the mode is confirmed 3 at the end of the run
  THEN → the transition was 2 -> 3: the configuration moved to the IDEAL state. This negative
         finding is reporting an improvement. Read `ena-express-enabled-with-udp.md` for what
         mode 3 does and does not guarantee (P3, R0)
  IF the mode is confirmed 1 at the end of the run
  THEN → the transition was 0 -> 1: ENA Express was turned on for TCP during the run, and the
         finding's question genuinely applies. Continue to STEP 2 (P2, R0)
  IF the mode is confirmed 0
  THEN → inconsistent with a +1 delta. The step came from the `average` series across >=3
         interfaces, or from a counter discontinuity. Go to STEP 0 (P3, R0)

STEP 2 — The run spans a CONFIGURATION CHANGE. This costs more than the UDP question.
  IF the step lands in the middle of the run
  THEN → metrics before and after are NOT comparable, and that applies to every other finding
         in the report. Any average, any p99, any intra-run comparison crosses a boundary
         where the network data path changed (P2, R1)
       → verify: re-record entirely after the change; then confirm `ena_srd_mode` is flat
         (two points after compression) in the new run
  IF the step lands in the first one or two intervals
  THEN → the enablement effectively preceded the workload, so the run is usable. Note the
         boundary and continue to STEP 3 (P3, R0)

STEP 3 — Is there enough UDP traffic for the question to matter? Answer from the report
         first; it can close the finding for free.
  IF `tx_cnt` - `ena_srd_tx_pkts` is SMALL (summed across queue series)
  THEN → in mode 1 only TCP rides SRD, so this gap is an UPPER BOUND on non-SRD traffic. A
         small gap means UDP is necessarily small, mode 1 is optimal, and the finding is
         closed as informational (P4, R0)
  IF `tx_cnt` - `ena_srd_tx_pkts` is LARGE
  THEN → INCONCLUSIVE, not confirmation. Ineligible TCP is in the same gap — cross-AZ, peers
         without ENA Express, packets over the 8900 SRD MTU. Measure UDP on the instance:
         aperf collects NO UDP counters (netstat.rs:33 reads only /proc/net/netstat, which has
         TcpExt: and IpExt: and no UDP section). Continue to STEP 4 (P3, R0)
       → verify: `ss -su`, `nstat -z | grep -i udp`, or /proc/net/snmp on the instance; the
         report cannot substitute for this
  IF UDP traffic is measured and negligible
  THEN → STOP. Mode 1 is the correct configuration. Record "no meaningful UDP traffic" as the
         resolution the rule asks for. NO finding (P4, R0)

STEP 4 — Gate on SRD RESOURCE HEADROOM before recommending more SRD load.
  IF `High SRD Resource Utilization` or `Low SRD Usage Rate` fired
  THEN → do NOT enable UDP support yet. The SRD pool is consumed by concurrent connections,
         and adding UDP pushes TCP into fallback too. Resolve those first, then return
         (P2, R0)
       → verify: after that work, `ena_srd_tx_pkts` tracks `ena_srd_eligible_tx_pkts` closely;
         a persistent gap means the headroom is still absent
  IF `ena_srd_resource_utilization` reads LOW or is flat near zero
  THEN → this is NOT proof of headroom. The gauge is deltified like every ena_stat metric, so
         a STEADILY saturated card produces near-zero deltas and its rule never fires. Read
         `high-srd-resource-utilization.md` before trusting a low reading (P3, R0)
       → verify: the raw utilization on the instance, not the report series
  OTHERWISE
  THEN → headroom is plausible. Continue to STEP 5 (P3, R0)

STEP 5 — Would UDP over SRD actually help, or hurt? The risk is REORDERING.
  IF the UDP protocol assumes near-ordered delivery
  THEN → enabling UDP support may make it WORSE. SRD sprays packets across paths and UDP has
         no transport layer restoring order, so reordering reaches the application directly.
         Mode 1 keeps the TCP benefit without that exposure — stay in mode 1 (P3, R0)
  IF the UDP traffic is latency-sensitive AND reordering-tolerant (QUIC/HTTP-3, media with a
     jitter buffer, sequence-numbered RPC) and within one AZ
  THEN → the case the rule was written for. Enable UDP support on BOTH endpoints; the gain is
         tail latency on the UDP path, which mode 1 excludes entirely (P3, R2)
       → verify: UDP p99/p99.9 before and after, plus application-level out-of-order metrics.
         A mean-latency comparison shows nothing even when SRD is working
  IF the UDP traffic is fire-and-forget telemetry or metrics
  THEN → marginal. Loss-tolerant and latency-insensitive traffic gains little, and it still
         consumes SRD card resources. Record as informational and stop (P4, R0)
  IF the UDP traffic is cross-AZ, internet-facing, or to peers without ENA Express
  THEN → STOP. ENA Express requires both endpoints in the same AZ with the setting enabled, so
         SRD cannot carry this traffic whatever the mode. NO finding (P4, R0)

STEP 6 — If enabling, the two constraints that bite silently.
  IF the interface MTU is 9001
  THEN → the SRD cap is 8900, so full-size datagrams fall back to standard ENA and the UDP
         benefit does not materialize. Reconcile the MTU deliberately rather than discovering
         the fallback as unexplained variance (P2, R2)
       → verify: after the change, `ena_srd_tx_pkts` tracks `ena_srd_eligible_tx_pkts`; a
         persistent gap means a different fallback cause
  IF other UDP applications share the instance
  THEN → the setting is per-ENI, not per-process, so EVERY UDP application on the instance is
         exposed to multipath reordering — including ones not considered here. Enumerate them
         before enabling (P2, R2)
       → verify: `processes` for UDP-owning processes, then each one's ordering assumptions
  OTHERWISE
  THEN → enable on both endpoints and watch the follow-on counters (P3, R2)
       → verify: `ena_srd_resource_utilization` stays well below 95 and the eligible-vs-actual
         gap does not widen; a widening gap means the added UDP load exhausted the pool

STEP 7 — What survives?
  VALID      : that a +1 mode delta occurred, hence a configuration change during the run;
               that mode 1 is the DEFAULT when ENA Express is enabled and not a
               misconfiguration; the small-gap upper bound closing the UDP question; the
               same-AZ and both-endpoints requirements; and the 8900 MTU cap
  CAUTION    : a +1 delta on the `average` series of >=3 interfaces, where no single interface
               stepped; a transition claimed on a run with `total_resets` non-zero; and the
               `tx_cnt` gap read from one queue rather than the per-queue sum
  CONFOUNDED : every metric in the run when the step lands mid-recording, since the data path
               changed underneath; any average over the `ena_srd_mode` series, diluted by the
               forced first zero; and a LARGE `tx_cnt` - `ena_srd_tx_pkts` gap read as UDP
               volume, since ineligible TCP is in it too
  VOID       : "the device is in mode 1" — the series is deltified, so the firing is a +1 step
               that may have ended in mode 2 or 3; the score, a constant -1.00; any UDP volume
               claim taken from `netstat`, which collects no UDP counters at all; and a low
               `ena_srd_resource_utilization` reading taken as headroom, since the gauge is
               deltified and a steady saturation reads as zero

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205);
         `lo`, `docker*`, `veth*`, `br-*` and `virbr*` are skipped, so a container with only
         virtual interfaces collects nothing (P4, R0)
  IF `ena_srd_*` metrics are absent while other `ena_stat` metrics are present
  THEN → the driver or instance type does not expose the SRD counters, so ENA Express is
         almost certainly unsupported here (P4, R0)
  IF the series has fewer than 3 points
  THEN → the first point is a structural zero, so 2 snapshots cover 1 real interval and the
         step cannot be located in time. Re-record with `--period 300` (P4, R0)
  IF UDP volume is the question and no instance-side measurement is available
  THEN → aperf collects NO UDP counters anywhere. Only the upper bound is available, so a
         large gap leaves the finding unresolved (P3, R0)
```

## Runtime-specific consequences

Mode 1 divides the workload in two: TCP gets SRD, UDP does not. Which runtimes notice depends entirely
on which half carries the latency-critical traffic.

- **TCP-only workloads.** Mode 1 is optimal and this finding is pure noise. SRD absorbs reordering below
  the socket, so TCP sees the full benefit with no application change and no reordering exposure.
- **QUIC / HTTP-3 / gRPC-over-QUIC.** The clearest case for enabling UDP support: entirely UDP-borne,
  latency-sensitive, and reordering-tolerant by design — QUIC carries its own sequencing and
  loss-recovery, so multipath spraying is exactly what it was built to survive. Mode 1 excludes it
  completely.
- **Real-time media and voice.** Usually worth enabling, since a jitter buffer already handles
  reordering, and tail latency is the metric that matters. Verify the buffer depth tolerates the added
  spread before enabling.
- **Custom UDP RPC protocols.** The risk case. A protocol written against a single-path network may
  quietly assume mostly-ordered arrival, and multipath spraying breaks that assumption with no error —
  just degraded behaviour. Check for sequence numbers and out-of-order handling in the code, not in the
  docs.
- **Java.** `DatagramChannel`/`DatagramSocket` traffic is invisible to every aperf data type, so the UDP
  volume question cannot be answered from `java_profile` either. Reordering surfaces as application-level
  sequence gaps, not as any JVM metric, and a GC pause of tens of milliseconds swamps any SRD latency
  gain — rule GC out before crediting or blaming the change.
- **DNS-heavy code paths.** UDP, but at packet rates too low for SRD to matter, and VPC DNS is
  **link-local** traffic against a separate allowance anyway. See
  `Link-Local Service Exceeded Instance Allowance`.
- **Containers.** The setting is per-ENI, so enabling UDP support exposes **every** container on the
  instance to multipath reordering, including ones whose protocols you did not audit.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in availability.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and the delta defect that
  makes this rule unreachable applies identically on both.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container
  with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot fire.
- **ENA Express support is a property of instance type and generation, not of the CPU architecture.**
  Graviton and Intel/AMD families both include supporting and non-supporting types; a Graviton migration
  neither grants nor removes it. Check the specific type, never the architecture.
- **UDP support is a second, independent setting** layered on ENA Express, so mode 1 is reachable on any
  fully supporting type — and is what you get by default.
- **Per-packet processing cost is where architecture matters**, not SRD availability. UDP is often
  small-packet-heavy, so the receive path can saturate before SRD matters at all; check `softirq` and
  the `interrupts` distribution before attributing UDP latency to the absence of SRD.
- **Multi-ENI instances** can differ per interface, and with **≥3 series** the auto-generated `average`
  mixes their modes into a mean that can itself land on 1.0. With exactly two series the aggregate is
  dropped (`:312`–`:319`).

## Verification

The falsifiable claim is *ENA Express is on for TCP only, and this workload has enough
reordering-tolerant UDP traffic that enabling UDP support would reduce its tail latency*. aperf can
establish almost none of that, so verification is mostly about substituting real measurements.

1. **Discard the state reading.** The firing is a +1 delta, not a mode. Nothing about the current
   configuration follows from it until step 3.
2. **Locate the step.** Find the +1 point in the `ena_srd_mode` series. If it falls mid-run, every
   before/after comparison in the report crosses a data-path change and must be discarded or re-recorded.
3. **Rule out the discontinuity, then get the mode.** `total_resets`, `interface_down` and `interface_up`
   must be zero; then query the ENI via the EC2 API or `ethtool`. A confirmed mode of 2 redirects the
   whole analysis — ENA Express was turned *off* mid-run. Also grep the run log for
   `"skipped N data points due to unexpected decrease"` on `ena_srd_mode`, the only in-report sign the
   mode fell.
4. **Bound the UDP volume from the report first.** `tx_cnt` − `ena_srd_tx_pkts`, summed across the queue
   series. A small gap **falsifies the premise** — UDP is negligible, mode 1 is optimal, and the finding
   closes with no instance access needed. This is the cheapest possible resolution.
5. **Measure UDP on the instance if the gap is large.** `ss -su`, `nstat -z | grep -i udp`, or
   `/proc/net/snmp`. A large gap alone proves nothing: ineligible TCP shares it.
6. **Test the resource-headroom gate honestly.** A low `ena_srd_resource_utilization` is not headroom,
   because the gauge is deltified and a steadily saturated card reads near zero. Check the raw value on
   the instance.
7. **Baseline the right numbers, then predict specifics.** Capture UDP p99/p99.9 and application-level
   out-of-order counts *before* enabling. Afterwards predict: the UDP tail falls by more than the mean,
   out-of-order counts may **rise** without harming a tolerant protocol, and
   `ena_srd_resource_utilization` stays below 95. If the tail did not move but throughput did, the gain
   came from elsewhere. And note **this finding will not reappear** either way — the delta defect is
   unchanged.

## Do not

- **Do not read this as "the device is in mode 1".** On aperf 1.3.0 the mode series is deltified, so
  this rule fires only on a **+1 transition** — which may have ended in mode 2 or 3.
- **Do not miss the 1 → 2 case.** That transition means ENA Express was **turned off** during the
  recording, a `Bad` condition wearing a `Concerning` label.
- **Do not expect a mode *decrease* to appear anywhere.** Decreasing samples produce no data point at all
  (`:214`), leaving a gap and one `warn!` line.
- **Do not read the score as severity.** It is a constant −1.00.
- **Do not recommend enabling UDP support before measuring UDP traffic.** With little UDP traffic,
  mode 1 is the correct configuration — and the in-report upper bound can establish that for free.
- **Do not look for the UDP counters in `netstat` — aperf collects none.** Only `/proc/net/netstat` is
  read (`netstat.rs:33`), which has `TcpExt:` and `IpExt:` and no UDP section; `/proc/net/snmp` is never
  read. Their absence is a collection gap, **not** evidence that UDP traffic is negligible.
- **Do not read a large `tx_cnt` − `ena_srd_tx_pkts` gap as UDP volume.** Ineligible TCP — cross-AZ,
  non-Express peers, oversized packets — lands in the same gap; it is an upper bound only.
- **Do not enable UDP support while SRD resource utilization is already high.** It increases SRD
  resource pressure and can push TCP traffic into fallback as well.
- **Do not read a low `ena_srd_resource_utilization` as headroom.** The gauge is deltified, so a steadily
  saturated card produces near-zero deltas and its rule never fires.
- **Do not enable it for an application that assumes ordered UDP delivery** without confirming it
  tolerates reordering — SRD's multipath spraying exposes reordering directly to UDP applications, and
  the setting is per-ENI, so every UDP application on the instance is affected.
- **Do not ignore that the run spans a configuration change.** Metrics either side of the step are not
  comparable, and that affects every other finding in the report.
- **Do not expect UDP support to raise any allowance.** Bandwidth, PPS, tracking, and link-local
  ceilings are unaffected, and they outrank this finding.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:64`–`:70` (`Comparator::Equal`, threshold `1.0`,
  `Score::Concerning`). Siblings at `:56`, `:72`, `:80`; the two sound SRD rules at `:88`, `:99`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates
  every series including the auto-generated aggregate, keeping the largest `|score|`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — general branch, `delta = 1/1 = 1`.
- **The defect:** `add_accumulative_data_point` applied to every `ena_stat` metric at
  `src/data/ena_stat.rs:343`; `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189`–`:224`.
- Forced first zero: `ignore_first_accumulative_value: true` at
  `src/data/common/time_series_data_processor.rs:73`, taken at `:218`; the only opt-out,
  `use_first_accumulative_value()` (`:81`–`:83`), is called once, from `src/data/perf_stat.rs:1295`.
- Dropped decrease and its warning: `time_series_data_processor.rs:214` (`return None`), early return at
  `:150`, single `warn!` at `:297`–`:302`.
- All-zero compression to two points: `compress_all_zero_time_series_metric`,
  `time_series_data_processor.rs:410`–`:427`.
- Average aggregate and the two-series collapse: `src/data/ena_stat.rs:315`;
  `time_series_data_processor.rs:249`–`:256` and `:312`–`:319`. Queue-name flattening, `:327`–`:341`.
- Metric semantics: `ena_srd_mode` at `src/report_frontend/src/definitions/data-descriptions.ts:3859`
  (`desired: "fixed"`); `ena_srd_eligible_tx_pkts` at `:3871` names the three fallback causes;
  `ena_srd_resource_utilization` at `:3884`.
- No UDP collection: `NetstatRaw` reads only `/proc/net/netstat` (`src/data/netstat.rs:33`), which
  carries `TcpExt:` and `IpExt:`; `/proc/net/snmp` is read by no collector.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL` and the
  `ETHTOOL_GSSET_INFO`/`GSTRINGS`/`GSTATS` sequence, `:31`–`:33`, `:216`.
- **No upstream guidance exists:** `src/report_frontend/src/definitions/optimization-guides.ts` contains
  only the four EC2 network allowance guides (`:117`, `:125`, `:134`, `:146`) — nothing for SRD.
- Related playbooks: `disabled-ena-express.md` (the finding that fires instead),
  `disabled-ena-express-with-previously-enabled-udp.md` (the concealed 1 → 2 case),
  `ena-express-enabled-with-udp.md`, `low-srd-usage-rate.md`, `high-srd-resource-utilization.md`.
- [ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express.html)
- [Configure ENA Express (including UDP support)](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express-configure.html)
