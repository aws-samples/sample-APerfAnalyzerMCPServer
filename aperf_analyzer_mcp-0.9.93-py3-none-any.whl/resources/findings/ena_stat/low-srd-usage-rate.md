---
rule_name: Low SRD Usage Rate
data_type: ena_stat
data_key: ena_srd_eligible_tx_pkts
template: time_series_stat_intra_run_comparison
condition: "(avg(ena_srd_eligible_tx_pkts) - avg(ena_srd_tx_pkts)) / avg(ena_srd_tx_pkts) >= 0.3"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "A large number of SRD-eligible packets are not transmitted using SRD, potentially caused by resource utilization issues."
source: src/analytics/rules/ena_stat.rs:88
---

# Low SRD Usage Rate

## What fired

The **average** of `ena_srd_eligible_tx_pkts` was **at least 30% greater** than the average of
`ena_srd_tx_pkts` — packets that qualified for SRD transmission were **not** actually sent over SRD, so they
fell back to standard ENA and lost the ENA Express benefit. Base score `Poor` (**−16**). Single-run rule (an
*intra-run* comparison of two metrics — no base run required).

Unlike the four `ena_srd_mode` rules, **this rule is sound.** Both counters go through the same delta
processing, so the deltification cancels in the ratio. It and `High SRD Resource Utilization` are the two
`ena_stat` SRD rules you can trust — and this one is the fastest proof that ENA Express is actually enabled,
since neither counter moves otherwise.

## The pattern actually works — verified by running the engine

Every `ena_stat` metric goes through `add_accumulative_data_point` (`src/data/ena_stat.rs:343`) with
`ignore_first_accumulative_value: true` (`time_series_data_processor.rs:73`, taken at `:218`);
`use_first_accumulative_value()` (`:81`–`:83`) has exactly one caller tree-wide, in
`src/data/perf_stat.rs:1295`. So every series in this data type is stored as **per-interval differences** —
a defect for the four `ena_srd_mode` rules and a caveat for `ena_srd_resource_utilization`. **For this rule
it is harmless**, and that is worth stating, because it is the only SRD rule of which it is true.

Both operands are genuine monotonic packet counters, so the difference is exactly what you want: a
per-interval packet rate. And the rule compares them as a *ratio*, `(comparison − baseline) / baseline`
(`time_series_stat_intra_run_comparison_rule.rs:96`), so **any processing applied identically to both
operands cancels**. Confirmed against real engine output — eligible averaging 150 against actual averaging
100 produced

```
The average in ena_srd_eligible_tx_pkts (150) is 50% greater than ena_srd_tx_pkts (100).
```

and a score of `−26.666666666666668`, exactly `(0.5 / 0.3) × −16`. The structural first-sample zero cancels
exactly too: both averages divide by the same point count, so the ratio reduces to
`(Σeligible − Σactual) / Σactual`. Four artifacts do survive, and only one can distort the ratio:

| Artifact | Where | Effect on this rule |
|---|---|---|
| First sample forced to 0 | `:218` | **None** — identical in both series, cancels in the ratio |
| A decreasing sample is **dropped**, not clamped | `:214`, early return at `:150` | **The one real hazard** — it can leave the two series covering different intervals |
| All-zero metrics compressed to two points | `:410`–`:427` | **A useful fingerprint** — `ena_srd_tx_pkts` as exactly two points at zero means no SRD ever ran |
| Aggregate removed at exactly 2 series | `:312`–`:319` | The cross-interface averaging caveat needs **≥3** interfaces, not 2 |

The hazard in detail: `get_delta_and_set_previous_value` (`:189`–`:224`) sees `prev_value > data_value`,
emits a `debug!`, increments a per-key counter and `return None` at `:214`; `add_data_point_impl` then
returns early at `:150`, so **no series entry is created at all** — a gap, not a zero. A reset from an
interface event or driver reload need not hit both counters in the same interval, and when it hits only one,
the averages cover different sets of intervals and the ratio is biased toward the surviving series. The only
trace is one `warn!` at `:297`–`:302`:

```
{data_name}.{metric}.{series}: skipped N data points due to unexpected decrease of accumulative data.
```

Trust the ratio — but check `total_resets` and the run log before trusting it to two decimal places.

## Reasoning

Two metrics, one ratio:

- `ena_srd_eligible_tx_pkts` — "Number of transmitted packets that were eligible for SRD. **If the
  metric's value is much larger than `ena_srd_tx_pkts`** (the number of packages actually transmitted
  with SRD), eligible packets are not able to transmit via SRD and falling back to standard ENA
  transmission. This could happen when the **network card attached to the instance has used up its
  maximum resources**, or if **packets are over the MTU limit**. Packets can also fall into this gap
  during **live migrations or live server updates**. Additional troubleshooting is required to determine
  the root cause." (`desired: "higher"`)
- `ena_srd_tx_pkts` — "The number of SRD packets transmitted within a given time period. ENA Express is
  powered by AWS Scalable Reliable Datagram (SRD) technology, a high performance network transport
  protocol that uses dynamic routing to increase throughput and minimize tail latency."
  (`desired: "higher"`)

The gap between them is **silent fallback**. Nothing fails; nothing is dropped by this mechanism alone. The
packets go out over standard ENA instead, losing multipath routing and the tail-latency benefit that is the
entire reason ENA Express was enabled. **That silence is why the rule matters:** every configuration check
says ENA Express is on, application latency is worse than expected, no error counter anywhere explains it,
and this finding is the only thing in aperf that names the discrepancy. Note the direction — **eligible >
actual** means the card wanted to use SRD and could not: eligibility is decided first (is the peer
SRD-capable, is this the right traffic class), and *transmission* is decided second and is what fails.

Upstream names three causes, and they have very different fixes:

1. **Network-card SRD resources exhausted.** Concurrent SRD connections consume a finite memory pool on
   the card; when it is used up, additional flows cannot use SRD. This is the cause aperf's message points
   at ("potentially caused by resource utilization issues") and the only one with a dedicated metric —
   `ena_srd_resource_utilization`, read by `High SRD Resource Utilization`. **Check it first**, but note
   that its own deltification means a *steady* saturation produces near-zero values and never fires.
2. **Packets over the MTU limit.** SRD caps at **8900 bytes**, below the 9001 standard jumbo MTU, so an
   interface at 9001 produces packets SRD cannot carry and they fall back silently. On a bulk-transfer
   workload with jumbo frames this can account for nearly the entire gap, and the fix is a one-line MTU
   change rather than anything to do with capacity.
3. **Live migration or live server update.** Transient, infrastructure-driven, and nothing to fix. The
   signature is a bounded window rather than a sustained gap — which is why reading the series comes first.

Beyond the upstream list, in practice: **peer-side capacity**, since SRD is end-to-end and the receiving
card has its own pool, so yours can be fine while the peer's is exhausted; **connection count**, since SRD
resources scale with *concurrent connections* rather than bytes, so a high-fan-out or high-churn service
exhausts the pool at modest bandwidth while every allowance counter stays at zero; and **ramp-up**, where
flows are still being established early in a run and a transient gap is normal.

**Why `Poor` (−16) rather than `Concerning`:** the gap means a deliberately enabled optimization is not
working — the instance is paying the configuration cost for standard ENA behaviour — and, unlike the mode
rules, this is measured behaviour rather than a configuration reading.

## Reading the description

`time_series_stat_intra_run_comparison` emits a description in which **both placeholders are metric
names**, not run names:

```
The {stat} in {comparison_metric} ({comparison_value}) is {percentage} {baseline_metric} ({baseline_value}).
```

The real example above — `The average in ena_srd_eligible_tx_pkts (150) is 50% greater than
ena_srd_tx_pkts (100).` — reads as follows:

- **`ena_srd_tx_pkts` is the *baseline*** and `ena_srd_eligible_tx_pkts` is the *comparison* — so the
  ratio is `(eligible − actual) / actual`, normalized by the **actual SRD count**, not by the eligible
  count. A gap of "50% greater" means eligible is 1.5× actual, i.e. **one third of eligible packets fell
  back** — not one half. This is the single easiest thing to misread in this finding.
- Both numbers are **averages of per-interval deltas** (`add_accumulative_data_point`, first sample
  forced to 0), so they are per-interval packet rates, not run totals.
- Values pass through `formatted_number_string`, so large counts appear as `1.50K`, `2.34M`, `1.20G` with
  **truncation** to 2 decimals, not rounding; the percentage comes from `delta_ratio_to_percentage_string`,
  also truncated, rendering `"equal to"`, `"{pct}% greater than"` or `"{pct}% less than"`.
- `abs: false`, so only *positive* ratios (eligible above actual) can fire — the reverse case cannot.
- **A special case worth knowing:** if `ena_srd_tx_pkts` averages exactly **0** while eligible packets
  exist, the template cannot divide, so it substitutes a ratio of **1.0** (`:91`–`:94`) — reported as
  "100% greater than" with a baseline of `0`. That means **no SRD at all**, the most severe form of this
  finding, and the score is a flat −53.33 regardless of how large the eligible count is.

Score math — `compute_finding_score(ratio, 0.3, −16)`, general branch (`delta = ratio/0.3`, inverted if
below 1):

| ratio | eligible ÷ actual | fraction of eligible falling back | score |
|---|---|---|---|
| 0.30 | 1.30× | 23% | **−16.00** |
| 0.40 | 1.40× | 29% | **−21.33** |
| 0.50 | 1.50× | 33% | **−26.67** |
| 0.75 | 1.75× | 43% | **−40.00** |
| **1.00** | 2.00× | 50% — **or no SRD at all** | **−53.33** |
| 2.00 | 3.00× | 67% | **−106.67** |
| 3.00 | 4.00× | 80% | **−160.00** |
| 9.00 | 10.0× | 90% | **−480.00** |

Recover the ratio as `ratio = |score| × 0.3 / 16 = |score| / 53.33`. **The score is unbounded upward**, so
a badly-degraded instance can produce scores in the hundreds — larger than any `perf_stat` finding and
comparable to the allowance rules. Unlike the allowance rules there is no `→ −0.00` trap, and unlike
`High SRD Resource Utilization` there is no percentage ceiling flattening it into a 5% band: the score rises
monotonically with the gap, so **for this rule the score is meaningful and worth ranking on** — and since
findings sort ascending by score (`analytics.tsx:40`), a severe case correctly floats to the top.

## Interpretation

Read the ratio as a fallback fraction — `fallback = ratio / (1 + ratio)` of eligible packets:

| ratio (from the description) | Reading |
|---|---|
| just over 0.30 | ~23% of eligible packets falling back. Real but modest; check whether it is transient |
| 0.5 – 1.0, then above 1.0 | 33–50% falling back, so half the intended benefit is missing; above 1.0 the majority falls back and ENA Express is configured but largely not operating |
| exactly 1.0 with baseline `0` | **No SRD transmission at all.** The worst case, and it is *not* distinguishable by score from a genuine 2× gap — read the baseline value in the description |

Then the series shape, which decides which of the three upstream causes applies:

| Pattern | Reading |
|---|---|
| Gap confined to a bounded window | **Live migration or live server update.** Transient, infrastructure-driven, nothing to fix. Confirm the rest of the run is clean |
| Gap only at the start of the run | Flow establishment / ramp-up. Usually benign |
| Gap sustained across the whole run | **Structural** — either resource exhaustion or the MTU cap, and the next two rows separate them |
| Gap growing with load | **Resource exhaustion** — SRD capacity scales with concurrent connections. Correlate with `ena_srd_resource_utilization` |
| Gap constant regardless of load | **MTU cap** is the better hypothesis — a fixed fraction of packets is simply too large |
| Either series has visible gaps, or the two have different point counts | **A dropped decrease** (`:214`). The averages may cover different intervals; check `total_resets` before trusting the ratio |

Combinations:

| also fired / observed | Reading |
|---|---|
| `High SRD Resource Utilization` also fired | **The diagnosis is settled: resource exhaustion.** aperf's own message points here, and the two findings corroborate each other. Scale out |
| `ena_srd_resource_utilization` well below 95%, with movement in the series | **Resource exhaustion is *not* the cause** — despite the message. Go to the MTU cap and the migration window instead. The most valuable negative result in this playbook |
| `ena_srd_resource_utilization` flat, or exactly two data points | **Inconclusive, not negative.** The gauge is deltified, so a steady saturation produces near-zero values and the all-zero compression reduces it to two points. Use connection counts as the evidence instead |
| Mean packet size (`tx_bytes`/`tx_cnt`) near or above 8900 | **MTU cap.** Packets exceed the SRD limit and fall back. A one-line fix |
| `Disabled ENA Express` also fired | **Expected artifact.** The `ena_srd_mode` series is deltified to zeros, so that rule fires on any instance. This finding proves ENA Express is actually *enabled* — trust it over the mode rules |
| `ENA Express Enabled with UDP` also fired | The configuration is ideal, the delivery is not. **Report both**; the positive finding alone misleads |
| Any allowance finding fired | Separate ceilings, and any of them outranks this one. SRD fallback does not cause shaping and shaping does not cause fallback — though both degrade the same workload |
| High connection count / churn (`netstat`), or `Connection Tracking Exceeded Instance Allowance` | Consistent with resource exhaustion: SRD capacity is per concurrent connection, not per byte. Two per-connection limits saturating from the same churn, and one connection-side fix addresses both |
| Tail latency worse than expected with no other explanation, and `Underutilized CPU` | **The symptom this finding explains.** Standard ENA tail latency on an instance configured for SRD, and idle CPU confirms network-bound: the single-flow throughput ceiling SRD was meant to lift is back in force |

**Known false positives:**

- **Live migration or live server update** — named upstream, transient and unfixable; identify it from a
  bounded window in the series.
- **Ramp-up at the start of a run**, flows still being established: the rule averages the *whole* run, so a
  short severe transient can lift it past 0.3 even when steady state is clean. **A very short recording**
  is the same hazard amplified — the forced first-sample zero cancels, but the startup interval does not.
- **Tiny absolute counts.** A ratio from a handful of packets per interval is statistically meaningless, and
  `formatted_number_string` makes small numbers easy to skim past — read the absolute values first.
- **An interface reset inside the run**, which drops the decreasing sample outright and can leave the two
  averages covering different intervals; and **peer-side limits**, a real gap whose cause is on the
  receiving instance's card, so nothing here will fix it.
- **The MTU cap on a workload that is supposed to use jumbo frames.** Whether this is a false positive
  depends on which you value more: 9001-byte frames or SRD. It is a trade-off, not a defect.
- **The stats come from one series** — `stats_series_idx` via `time_series_metric_stats`
  (`processed_data_accessor.rs:119`–`:130`), which is the auto-generated `average` when **three or more**
  interfaces exist, since at exactly two the aggregate is removed (`:312`–`:319`). So on a multi-ENI
  instance the ratio can be a ratio of cross-interface means, with one interface entirely responsible.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `ena_srd_resource_utilization` | `ena_stat` | **Do this first.** Movement above ~95% ⇒ resource exhaustion; well below *with visible movement* ⇒ it is not, despite aperf's message. Flat or two points ⇒ inconclusive. See `High SRD Resource Utilization` |
| `tx_bytes`/`tx_cnt` — **mean packet size** | `ena_stat` | **The second check.** Near or above **8900** ⇒ the SRD MTU cap explains the gap. A configuration fix, not a capacity one |
| `ena_srd_eligible_tx_pkts` and `ena_srd_tx_pkts` full series | `ena_stat` | **Where the three causes separate**: bounded window ⇒ migration; sustained ⇒ structural; growing with load ⇒ resources |
| Absolute values of both counters, and their **point counts** | `ena_stat` | Whether the ratio rests on meaningful packet counts, and whether a dropped decrease left the two series covering different intervals |
| `ena_srd_rx_pkts` | `ena_stat` | Receive-side SRD activity — asymmetry hints at a peer-side or directional problem |
| `ena_srd_mode` | `ena_stat` | **Deltified and unreliable** — this finding is better evidence that ENA Express is on. See `disabled-ena-express.md` |
| The four allowance counters, plus `conntrack_allowance_exceeded` and `conntrack_allowance_available` | `ena_stat` | Separate ceilings — rule out shaping as a competing explanation for the latency. Connection tracking is the other *per-connection* limit, driven by the same churn |
| `tx_cnt`, `rx_cnt` per queue | `ena_stat` | Packet-rate profile and per-queue skew. Both are **per queue** (`ena_stat.rs:327`–`:341`), so sum the queue series |
| `total_resets`, `interface_down`, `interface_up`, and the `warn!` log | `ena_stat` / run log | Whether the counter series are continuous, and how many decreases the pipeline discarded |
| MTU configuration | `systeminfo` / `sysctl` | **9001 vs the 8900 SRD cap** — the concrete configuration behind the MTU hypothesis. **No analytical rules for `sysctl` — read manually** |
| Instance type and size | `systeminfo` | ENA Express support; SRD resource capacity scales with instance size, so this bounds the scale-out decision |
| Connection counts and churn, TCP retransmits | `netstat` | Concurrent-connection pressure (the driver of SRD resource use) and the latency consequence |
| `idle`, `aggregate` | `cpu_utilization` | Whether the workload is network-bound. See `Underutilized CPU` |
| Peer instance's `ena_stat`, if available | `ena_stat` (other run) | SRD is end-to-end; the peer's resource pool can be the limit |

## Guidance

Ordered. **Steps 3 and 4 are the two checks that separate the causes** — aperf's message names only the
first, and the second is at least as common.

1. **Read the description carefully — the ratio is normalized by the *actual* SRD count.** "50% greater"
   means eligible is 1.5× actual, i.e. **one third** of eligible packets fell back. Also read the absolute
   values: a ratio built on a handful of packets is noise. If the baseline shows `0`, there is **no SRD
   transmission at all** and the ratio was substituted as 1.0.

2. **Read the full series for both counters.** This is where the three upstream causes separate — a bounded
   window means live migration (transient, stop); only at the start means ramp-up (usually benign, but the
   rule averages the whole run); sustained means structural; growing with load points at resources (step 3);
   flat regardless of load points at the MTU cap (step 4). Check the two point counts match while you are
   there — a dropped decrease can leave the averages covering different intervals.

3. **Check `ena_srd_resource_utilization` — the cause aperf's message asserts.** Above ~95%, or if
   `High SRD Resource Utilization` fired, the diagnosis is settled and scaling out is the remediation.
   **Well below 95% *with visible movement* is an equally important result: it rules the stated cause out**,
   and the message should not be repeated as the conclusion. But a flat or two-point series is
   *inconclusive*, not negative — that gauge is deltified too, so a steady saturation cannot show up in it,
   and the `netstat` connection count is the evidence to use instead.

4. **Check the mean packet size against the 8900 SRD MTU limit.** Derive it from `tx_bytes`/`tx_cnt` and
   read the interface MTU. A 9001 MTU producing packets above 8900 explains a constant fallback fraction
   with no capacity problem at all — a one-line fix rather than an instance change, named upstream, and easy
   to overlook because nothing looks broken.

5. **Use this finding to correct the mode findings, and rank by score — unlike the rest of `ena_stat`.**
   Both counters only move when SRD is in use, so this is **positive proof that ENA Express is enabled**
   regardless of what `Disabled ENA Express` says; and if `ENA Express Enabled with UDP` fired, report it
   *with* this finding, since the configuration is ideal and the delivery is not. The score rises
   monotonically with the gap and has no zero trap and no percentage ceiling, so −480 really is much worse
   than −16.

6. **Quantify the consequence, then consider the peer side.** The fallback is silent: no drops, no errors.
   Read the `netstat` retransmit and out-of-order counters and application tail latency — standard-ENA tail
   latency on an instance configured for SRD is the symptom, and what justifies the remediation. If neither
   resources nor MTU explains the gap locally, the peer's card may be the limit; read its `ena_stat`.

7. **Remediate by cause:**
   - **Resource exhaustion** ⇒ **scale out**. The metric description is explicit: "High resource
     utilization is a sign that it's time to scale the instance out to improve network performance."
     Also reduce **concurrent connections** — pooling and reuse — since SRD capacity is per connection,
     not per byte. Larger instances have larger pools, so scaling up helps too.
   - **MTU cap** ⇒ reconcile the MTU deliberately. Lower it under 8900 if SRD's tail-latency benefit
     matters more than 9001-byte frames, or accept the fallback for the oversized portion if jumbo frames
     are load-bearing. State the trade-off rather than picking silently.
   - **Live migration / live update** ⇒ nothing to do; note it and re-record. **Peer-side limits** ⇒ the
     fix belongs on the peer. **Ramp-up only** ⇒ re-record a steady-state window, since the average over a
     short run is misleading.

8. **Re-measure tail latency after any change**, not the mean — that is where SRD's benefit appears and
   where its absence hurts.

## Priority and execution risk

**Priority: P2 — Plan** by default. The harm is silent and structural rather than acute: a deliberately
enabled optimization is not delivering and no error counter anywhere reports it, but nothing is being lost
either, so this is work to schedule rather than to interrupt for. It rises to **P1 — Act now** when the gap
is large (a ratio above 1.0, or the baseline-`0` case meaning no SRD at all) **and** the consequence is
visible — `netstat` retransmits elevated, or application tail latency regressed against its SLO — because at
that point the instance is both paying for SRD and running worse than the standard-ENA baseline it could have
had, and for TCP each retransmit costs far more throughput than the count suggests. It drops to
**P3 — Monitor** when the gap is confined to ramp-up, when the MTU trade-off is deliberate and documented, or
when the cause is on the peer and nothing here can move it. It drops to **P4 — Informational** when the ratio
rests on a handful of packets per interval, when the gap sits inside a live-migration window, when the run is
short enough that startup dominates both averages, or when the ratio comes from the `average` series of three
or more interfaces.

**Execution risk: R0 — Read-only** for the whole diagnosis: both series and their point counts, the absolute
values in the description, `ena_srd_resource_utilization`, mean packet size, the interface MTU as read,
`total_resets` and the run log, `netstat` connection counts and churn, and the allowance counters. **R1** for
re-recording a steady-state window to separate ramp-up from structure, for recording the peer instance, and
for adding SRD monitoring so the utilization *level* — which aperf cannot show — is observable next time.
**R2** for the two real fixes: connection pooling, keep-alive and reduced fan-out, which lower pool
consumption without buying capacity and relieve connection tracking at the same time; and **lowering the
interface MTU** under 8900, which is reversible but applies to every flow on the interface, so confirm no
peer depends on 9001-byte frames first. **R3** for scaling out, for scaling up (a replacement, since the pool
is sized by instance type), and for disabling ENA Express entirely — the only option that removes both the
cap and the pool, along with the benefit. **Do not carry the R0 of the diagnosis into any of these.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: the average of `ena_srd_eligible_tx_pkts` was at least 30% greater than the average of
`ena_srd_tx_pkts`, both taken from the series at `stats_series_idx`. Unlike the rest of `ena_stat`, the
ratio is trustworthy — the deltification cancels between the two counters.

```
STEP 0 — Is the RATIO REAL? Read both absolute values in the description before anything else.
  IF the baseline reads `ena_srd_tx_pkts (0)` alongside "100% greater than"
  THEN → there is NO SRD TRANSMISSION AT ALL. The template could not divide by zero so it
         substituted a ratio of 1.0 (:91-:94), pinning the score at a flat -53.33 however large
         the eligible count — the score UNDERSTATES the worst case this rule has. Continue to
         STEP 1 (P1, R0)
  IF both averages are tiny — a handful of packets per interval
  THEN → the ratio is statistically meaningless, and formatted_number_string makes small counts
         easy to skim past. NO finding worth acting on (P4, R0)
  IF the two series have DIFFERENT point counts, or either shows gaps
  THEN → a decrease was dropped (:214), so the two averages may cover different intervals and the
         ratio is biased toward whichever series survived. Check `total_resets` and the run log
         before trusting the number (P3, R0)
  OTHERWISE
  THEN → the ratio rests on real, comparable packet counts. Continue to STEP 1 (P2, R0)

STEP 1 — WHERE does the gap sit in the series? The three upstream causes separate here.
  IF the gap is confined to a bounded window mid-run
  THEN → LIVE MIGRATION or live server update, named upstream as a cause of exactly this gap.
         Transient, infrastructure-driven, nothing to fix (P4, R1)
       → verify: `total_resets`, `interface_down` and `interface_up` for a coincident event, then
         a run recorded outside the window shows no gap
  IF the gap sits only at the start of the run
  THEN → flow establishment / ramp-up. Usually benign, but the rule averages the WHOLE run, so a
         short severe transient can still carry it past 0.3 (P3, R1)
       → verify: a steady-state re-recording with `--period 300` does not fire the rule at all
  IF the gap GROWS with offered load
  THEN → points at CARD RESOURCES: SRD state is consumed per concurrent connection, so pressure
         rises with the workload. Go to STEP 2 (P2, R0)
  IF the gap is a CONSTANT fraction regardless of load
  THEN → points at the MTU CAP: a fixed share of packets is simply too large for SRD, and that
         share does not care how busy the instance is. Go to STEP 3 (P2, R0)
  OTHERWISE
  THEN → sustained and structural but shape-neutral. Continue to STEP 2, then STEP 3 — both
         checks are cheap and only one of them will land (P2, R0)

STEP 2 — Is it CARD RESOURCE exhaustion, the cause aperf's message asserts?
  IF `High SRD Resource Utilization` also fired
  THEN → cause and effect BOTH confirmed and the diagnosis is settled: the card's concurrent-SRD
         pool is exhausted and eligible packets are already falling back. Go to STEP 4 (P2, R0)
  IF `ena_srd_resource_utilization` shows little movement but `netstat` shows a high concurrent
     connection count or heavy churn
  THEN → that gauge is deltified too, so it CANNOT report a steady saturation; connection
         pressure is the better evidence. Treat as resource exhaustion and go to STEP 4 (P2, R0)
  IF `ena_srd_resource_utilization` is charted as exactly TWO data points
  THEN → the all-zero compression fired (:410-:427): the gauge never moved and cannot tell you
         whether the level was 2% or 99%. Resources are neither confirmed nor ruled out — go to
         STEP 3 and let the MTU evidence decide (P2, R0)
  IF utilization is well below 95% WITH visible movement, and connection counts and churn are low
  THEN → RESOURCE EXHAUSTION IS RULED OUT despite aperf's message. This negative result is the
         most valuable one in this playbook: it stops a scale-out that would not have helped.
         Continue to STEP 3 (P2, R0)
  OTHERWISE
  THEN → resources unproven either way. Continue to STEP 3 (P2, R0)

STEP 3 — Is it the 8900-byte MTU CAP, and if not, is the limit OFF this instance?
  IF mean packet size (`tx_bytes`/`tx_cnt`) is near or above 8900 and the interface MTU is 9001
  THEN → the MTU CAP explains the gap: oversized packets cannot ride SRD and fall back silently.
         A configuration fix, not a capacity problem. Go to STEP 4 (P2, R0)
  IF the interface MTU is 1500, or the mean is well under 8900 with only a jumbo MINORITY
  THEN → the cap explains none of the gap, or at most the oversized share. Look off-instance:
         SRD is end-to-end and the receiving card has its OWN pool and its own MTU (P2, R1)
       → verify: the peer's `ena_stat` if a recording exists — its eligible-vs-actual gap tells
         the same story from the other side; if none exists, record the peer before spending
         anything on this instance
  IF `ena_srd_mode` indicates UDP support and the UDP traffic is high-connection-count
  THEN → mode 3 puts UDP on SRD too, so UDP is competing for the same pool. Note it as a lever
         and read `enabled-ena-express-without-udp.md`. see that playbook (P3, R0)
  OTHERWISE
  THEN → neither the cap nor a visible peer effect. Continue to STEP 4 and act only on what you
         confirmed (P3, R0)

STEP 4 — REMEDIATE by cause. The fixes are not interchangeable; the wrong one costs money.
  IF the cause is card resources and connections are not pooled or reused
  THEN → enable pooling and keep-alive and reuse connections instead of one per request. SRD
         state is per connection, not per byte, so this is the cheapest durable fix and it
         relieves connection tracking at the same time (P2, R2)
       → verify: the eligible-vs-actual gap narrows on a re-recording at comparable packet
         counts, and concurrent connections and `TIME_WAIT` both fall
  IF the cause is card resources and the connection count is irreducible
  THEN → SCALE OUT, AWS's own recommendation for the utilization metric, or SCALE UP since the
         pool is sized by instance type. Both are instance-level decisions (P2, R3)
       → verify: the gap narrows per instance, and tail latency improves at p99 and p99.9 while
         the MEAN barely moves — a flat mean is the usual reason a correct change is judged a
         failure
  IF the cause is the MTU cap and SRD's tail-latency benefit matters more than jumbo frames
  THEN → lower the interface MTU under 8900. State the trade-off rather than picking silently,
         and remember it applies to EVERY flow on the interface, not only the SRD ones (P2, R2)
       → verify: mean packet size drops below 8900 and the gap closes; confirm no path-MTU
         regression for peers that expected 9001
  IF the cause is the MTU cap and jumbo frames are load-bearing
  THEN → accept the fallback for the oversized share — a deliberate trade-off, not a defect.
         Document it so the finding is not re-investigated every run. NO finding to fix (P3, R0)
  IF the gap is large, the connection count is irreducible AND the traffic is not
     tail-latency-sensitive
  THEN → ENA Express may be the wrong tool here: standard ENA has neither the pool nor the 8900
         cap. Land on a coherent mode (0, 1 or 3) if you disable it (P3, R3)
       → verify: tail latency does not regress after disabling; read
         `disabled-ena-express-with-previously-enabled-udp.md` before leaving the UDP flag set
  OTHERWISE
  THEN → transient or peer-side, so there is nothing to change locally. Re-record and re-read
         rather than remediating. NO finding (P4, R1)
       → verify: the re-recorded steady-state window does not fire the rule

STEP 5 — What survives?
  VALID      : the gap and its direction — eligible packets exceeded transmitted SRD packets,
               measured from two counters that share identical processing, so the deltification
               CANCELS in the ratio and the structural first-sample zero cancels exactly; the
               score as a severity ranking, since it is unbounded and monotonic in the gap; and
               the finding as POSITIVE PROOF that ENA Express is enabled, since neither counter
               moves otherwise
  CAUTION    : the ratio when both averages rest on a handful of packets per interval; a ratio
               taken from the `average` series of >=3 interfaces, where one interface may be
               wholly responsible; and aperf's stated cause, which is one of three named upstream
               and the only one with a dedicated metric
  CONFOUNDED : any run containing an interface reset or a live migration, since a counter
               decrease drops the sample outright (:214) and can leave the two series covering
               DIFFERENT intervals; and any gap confined to ramp-up, where the run-wide average
               is not the steady state
  VOID       : reading the percentage as the fraction of packets that fell back — it is
               normalized by the ACTUAL SRD count, so "50% greater" is one THIRD falling back;
               treating the flat -53.33 of the baseline-0 case as merely a 2x gap when it means
               no SRD at all; and reading a flat `ena_srd_resource_utilization` as proof that
               resources are fine

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205);
         `lo`, `docker*`, `veth*`, `br-*` and `virbr*` are skipped, so a container with only
         virtual interfaces collects nothing (P4, R0)
  IF `ena_srd_*` metrics are absent while other `ena_stat` metrics are present
  THEN → the driver or instance type does not expose the SRD counters, so ENA Express is
         unsupported here and the rule COULD NOT FIRE (P4, R0)
  IF either series has fewer than 3 points
  THEN → the first point is a structural zero, so 2 snapshots cover 1 real interval and the
         average IS that interval. Re-record with `--period 300` (P4, R0)
  IF the interface MTU is unknown
  THEN → the 8900-cap hypothesis cannot be tested from the report alone. Read the MTU from the
         instance or the EC2 API before pursuing it (P3, R0)
```

## Runtime-specific consequences

The two structural causes have **opposite** runtime profiles, which is the fastest way to guess which one
you are looking at before checking either.

- **High-fan-out services and RPC meshes** are the most exposed to the *resource* cause: every hop is its
  own SRD connection, so a mesh multiplies pool use per request and sidecar proxies concentrate it on one
  ENI. Small payloads mean the MTU cap is irrelevant here.
- **Connection-per-request clients and thread-per-connection designs** are the same shape seen from the
  application side. Each request takes and returns a pool entry, so the gap tracks request rate rather than
  byte rate, and the thread count in `processes` is a direct proxy for concurrent connections.
- **Bulk-transfer and replication workloads** are the mirror image: few flows, large payloads, so the
  *resource* cause is unlikely and the **8900 MTU cap** leads. On a 9001-MTU interface moving mostly
  full-size frames the cap can account for nearly the whole gap, and no capacity change will touch it.
- **UDP workloads under mode 3.** UDP rides SRD too, so a high-connection UDP application competes for the
  same pool; dropping to mode 1 is a real lever at the cost of UDP acceleration.
- **Java.** Connection pools are usually explicit and configurable (HTTP client pools, JDBC pools, gRPC
  channels), which makes this one of the cheaper runtimes to fix — but check `java_profile` before blaming
  the network for a latency regression, since a 50 ms GC pause swamps any SRD tail effect.
- **Containers.** ENA Express, its pool and the interface MTU are all properties of the **ENI**, shared by
  every container on the host, so one container's churn or jumbo frames produce a gap the others pay for.

## Architecture-specific considerations

Architecture-independent in mechanism; instance- and interface-dependent in every number that matters.

- **Both counters are architecture-agnostic.** `ena_stat` reads them via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically — and the reason the ratio is
  trustworthy is the same on both.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`), so inside a
  container with only virtual interfaces **`ena_stat` collects nothing** and the rule cannot fire.
- **The 8900-byte SRD cap is not architectural.** It is a property of SRD, identical on every instance
  type and CPU family, and it is compared against an *interface* MTU that is pure configuration. So the
  MTU cause can appear and disappear with an image or launch-template change and no hardware change at all.
- **The SRD pool is a property of instance type and size, not of CPU architecture.** A Graviton migration
  at the same size neither grants nor removes SRD capacity, so if this finding appeared after one, look for
  a change in connection behaviour or MTU rather than in the card. Scaling up is a type change and the pool
  scales with it, which makes instance size the one lever guaranteed to work when the connection count is
  genuinely irreducible. And since **ENA Express needs supported types on both ends and the same subnet**, a
  topology change that moves a peer can produce this gap with nothing changed locally.
- **Multi-ENI instances** each carry their own SRD state, and with **≥3 series** the auto-generated
  `average` mixes them before the ratio is taken. At exactly two series the aggregate is dropped
  (`:312`–`:319`), so read per-interface series before attributing the gap.

## Verification

The falsifiable claim is *packets that qualified for SRD were transmitted over standard ENA instead, and
this instance's workload is measurably worse for it*. The first half is directly measured; the second is
what justifies spending anything.

1. **Recompute the fallback fraction from the description, not the percentage.** `ratio / (1 + ratio)` of
   eligible packets fell back, so "50% greater" is one third. If the baseline reads `0`, no SRD ran at all
   and the score understates it at a flat −53.33.
2. **Check that the two series are comparable before trusting the ratio.** Equal point counts, no gaps,
   `total_resets` at zero, and no skipped-decrease `warn!` in the run log. A reset that hit one counter and
   not the other makes the averages cover different intervals.
3. **Predict which cause and then test it, in this order.** Resources predict utilization movement above
   ~95% *and* high connection counts, with the gap growing under load; the MTU cap predicts a mean packet
   size near 8900 on a 9001 interface and a gap that is a constant fraction; migration predicts a bounded
   window and a coincident interface event. **Exactly one should match** — if none does, the cause is
   likely on the peer.
4. **Rule out the competing explanations for the latency.** All four allowance counters at zero means
   shaping is not the story; if one fired, that finding outranks this one and SRD fallback is a side effect.
   Idle CPU in `cpu_utilization` confirms network-bound rather than compute-bound.
5. **Predict the tail, then measure it.** Predict that p99 and p99.9 latency improve after remediation while
   the **mean barely moves** — SRD's benefit is a tail effect, and a flat mean is the usual reason a correct
   change gets judged a failure. Re-record and confirm the gap narrowed at comparable packet counts. Then
   state what this finding settles for the rest of the report: it is positive proof ENA Express is enabled,
   so `Disabled ENA Express` alongside it is an artifact, and unlike the rest of `ena_stat` the score here
   is a real severity ranking, so say so rather than letting it be discounted with the others.

## Do not

- **Do not read the percentage as the fraction of packets that fell back.** It is normalized by the
  *actual* SRD count: "50% greater" means one third of eligible packets fell back, not one half.
- **Do not repeat aperf's stated cause without checking it.** The message says "potentially caused by
  resource utilization issues"; that is one of three causes named upstream, and the MTU cap or a migration
  window is often the better explanation.
- **Do not read a flat `ena_srd_resource_utilization` as proof that resources are fine.** That gauge is
  deltified too, so a steadily saturated card produces near-zero values and the all-zero compression
  reduces it to two points. Use connection counts as the evidence instead.
- **Do not overlook the 8900 SRD MTU limit.** With a 9001 interface MTU, oversized packets fall back
  silently and no capacity change will help.
- **Do not treat the numbers as run totals.** Both are averages of per-interval deltas, first sample
  forced to 0 — which cancels in the ratio, but does not make them totals. And **do not act on a ratio
  built from tiny absolute counts**: read the values in the description.
- **Do not trust the ratio to two decimals when the two series have different point counts.** A dropped
  decrease (`:214`) leaves the averages covering different intervals.
- **Do not miss the baseline-`0` case.** A description showing `ena_srd_tx_pkts (0)` with "100% greater
  than" means **no SRD at all**, and the score understates it — a flat −53.33 however large the eligible
  count.
- **Do not believe `Disabled ENA Express` over this finding.** This rule reads counters that only move
  when SRD is active; the mode rules read a deltified enum and are unreliable.
- **Do not report `ENA Express Enabled with UDP` alone when this finding is present.** The configuration
  is ideal; the outcome is not.
- **Do not expect SRD fallback to explain a bandwidth, PPS, tracking, or link-local breach.** Separate
  mechanisms, and any allowance finding outranks this one.
- **Do not escalate a bounded-window gap**, since live migration and live server updates are named
  upstream as a cause and there is nothing to fix — and **do not assume this instance is the limit**: SRD
  is end-to-end, and the peer's card has its own resource pool and its own MTU.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:88` — baseline `ena_srd_tx_pkts`, comparison
  `ena_srd_eligible_tx_pkts`, `Stat::Average`, `GreaterEqual`, `abs: false`, `delta_ratio: 0.3`.
- Rule template: `src/analytics/rule_templates/time_series_stat_intra_run_comparison_rule.rs` — the
  baseline-zero substitution `cur_ratio = 1.0` at `:91`–`:94`, the general ratio at `:96`, the finding keyed
  on the *comparison* metric at `:119`, and **both description placeholders being metric names**.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; findings sort ascending by score,
  `src/report_frontend/src/utils/analytics.tsx:40`. Formatting: `delta_ratio_to_percentage_string` and
  `formatted_number_string`, `src/computations/mod.rs:162` and `:176`, both truncating to 2 decimals via
  `f64_to_fixed_2` at `:138`.
- Delta processing: `add_accumulative_data_point` and `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189`–`:224` (the `return None` on a decrease at `:214`,
  the `warn!` at `:297`–`:302`), applied to every metric at `src/data/ena_stat.rs:343`.
- Series handling: the all-zero compression at `time_series_data_processor.rs:410`–`:427`, the 2-series
  aggregate removal at `:312`–`:319`, and stats read from `stats_series_idx` via `time_series_metric_stats`,
  `src/data/common/processed_data_accessor.rs:119`–`:130`.
- Collection: `Ethtool::new` interface filter and `device` requirement, `src/data/ena_stat.rs:190`–`:205`;
  the `SIOCETHTOOL` ioctl at `:31`–`:33` and `:216`; queue-name flattening at `:327`–`:341`.
- Metric semantics: `ena_srd_eligible_tx_pkts` and `ena_srd_tx_pkts` in
  `src/report_frontend/src/definitions/data-descriptions.ts:3871` onward — the source of the three named
  causes (card resources, MTU limit, live migration). Related playbooks:
  `high-srd-resource-utilization.md`, `disabled-ena-express.md`, `ena-express-enabled-with-udp.md`,
  `enabled-ena-express-without-udp.md`.
- [ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express.html)
- [ENA Express performance and MTU](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express-configure.html)
- [Monitor network performance for your EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
