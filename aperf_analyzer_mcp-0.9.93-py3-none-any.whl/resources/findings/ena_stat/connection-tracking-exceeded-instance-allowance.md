---
rule_name: Connection Tracking Exceeded Instance Allowance
data_type: ena_stat
data_key: conntrack_allowance_exceeded
template: time_series_data_point_threshold
condition: "any(conntrack_allowance_exceeded) > 0.0"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "EFA is dropping packets because connection tracking exceeded the maximum for the instance and new connections could not be established."
source: src/analytics/rules/ena_stat.rs:40
---

# Connection Tracking Exceeded Instance Allowance

## What fired

**At least one** interval delta of `conntrack_allowance_exceeded` was **greater than 0.0** — the Nitro
card dropped at least one packet because the number of connections tracked by the security group
reached the instance's maximum, so **new connections could not be established**.

Base score `Critical` (**−256**). Single-run rule, `Comparator::Greater`, threshold `0.0` (`ena_stat.rs:38`–`:46`).

Like the other four allowance rules this is **not a heuristic** — it is a hardware enforcement counter.
But it differs from all of them in the thing that matters most: **the failure mode is refusal, not
degradation.** Bandwidth and PPS shaping make existing traffic slower. This drops the packets that would
*create* a tracking entry, so established connections keep flowing at full speed while new ones fail
outright. The finding is an **availability** event wearing a performance rule's clothes, and the
diagnostic question is the **RATE and DURATION** of the refusal.

> **The message names the wrong device.** aperf says *"EFA is dropping packets"*. All five
> `ena_stat` allowance rules (`ena_stat.rs:21`, `:29`, `:37`, `:45`, `:53`) say "EFA" when they mean
> **ENA**. The metric is read by an `ethtool -S` ioctl on the ENA interface (`ena_stat.rs:235`);
> Elastic Fabric Adapter is a different device with its own data type and rules. The
> `data-descriptions.ts` entry for the same metric (`:3831`) is correct.

## The processing defect — a gauge run through a delta, verified by simulation

`conntrack_allowance_available` is this finding's natural companion metric — remaining headroom, the only
allowance-family metric with `desired: "higher"` (`data-descriptions.ts:3852`) and **the only one with no
analytical rule**, since `ena_stat.rs` defines rules on the five `*_exceeded` metrics and on `ena_srd_*` but
never on this gauge. So it must be read manually. **Do not.**

`ena_stat.rs:343` calls `add_accumulative_data_point` for **every** metric name it parses, with no exemption
list, so a gauge goes through the accumulative path: `get_delta_and_set_previous_value` emits
`current − previous`, and a **decrease** returns `None` at `time_series_data_processor.rs:202`–`:214` — the
point is dropped while the baseline still advances. Headroom decreases exactly when connections are being
established, the event you are investigating. Simulating **15,625 headroom trajectories** (6 snapshots, levels
{0, 1, 2, 4, 8}) gives an exact result rather than a tendency: the plotted series sums to the headroom
**released** by closing connections in **15,625 of 15,625**, an interval of headroom **consumption** appears in
**0 of 15,625**, and in 205 trajectories headroom was consumed while the series showed nothing at all. The
metric plots recovery and is structurally **blind to consumption**.

```
snapshots [130000, 126000, 122000, 118000, ...]   monotonic drain to exhaustion
  -> 9 of 10 points DROPPED, series = [0.0], plots as a flat zero
snapshots [8,8,8,8,8,8]  full headroom throughout      -> [0,0,0,0,0,0]
snapshots [0,0,0,0,0,0]  ZERO headroom, saturated      -> [0,0,0,0,0,0]  identical
```

An all-zero metric is then **compressed to two data points** (`compress_all_zero_time_series_metric`,
`time_series_data_processor.rs:410`–`:427`), so a fully saturated instance draws a two-point flat line
at zero, indistinguishable from one that never tracked a connection. Read absolute headroom from raw
`ethtool -S` or CloudWatch; `conntrack_headroom_is_unreadable()` in
[`../tools/aperf_ena_allowance.py`](../tools/aperf_ena_allowance.py) carries the verdict.

Three further properties apply to `conntrack_allowance_exceeded` itself, shared across this family, and only
the third is subtle. The series is a **per-interval delta** (`ena_stat.rs:343`); its **first point is a forced
zero** covering no elapsed time, because `ignore_first_accumulative_value` defaults to `true`
(`time_series_data_processor.rs:73`, `None` arm at `:218`, only `perf_stat` opting out at `perf_stat.rs:1295`),
so an n-snapshot run covers **(n−1) × interval** seconds and any *average* is diluted by (n−1)/n; and the
auto-generated `average` series — a **mean** across interfaces (`ena_stat.rs:315`) — is scanned alongside the
real ones. Because the `threshold == 0.0` branch pins every sub-unit value at a flat −256.00 while exactly 1.0
scores −0.00, a one-packet peak is out-scored by its own mean: `eth0` at 1.0 scores 0.00, `eth1` at 0.0 does not
fire, and the `average` of **0.5** scores **256.00** and is the one reported.

Brute-forcing 1,596 combinations over 2/3/4/8 ENIs with peaks in {0, 1, 2, 3, 5, 10, 47, 1000} found this in
exactly 22 cases and **the peak per-interface delta was 1 in every one**, because a peak of 2 scores −256.00 and
wins outright. So **a fractional value means the true per-interface peak was exactly ONE dropped packet** — one
refused connection attempt. Two scope limits: the queue split at `ena_stat.rs:332` fires only for
`queue_<n>_...` names, which no allowance metric matches, so these are always one series per **interface**; and
a single-ENI run drops the aggregate (`:315`–`:319`), so the artifact needs **two or more ENIs**.

## Reasoning

`conntrack_allowance_exceeded` is the *"Number of packets dropped because the number of tracked
connection exceeded the maximum for the instance and new connections could not be established. …The
security group tracks each connection established to ensure that return packets are delivered as
expected. There is a maximum number of connections that can be tracked per instance."*
(`data-descriptions.ts:3831`, `desired: "lower"`)

Security groups are **stateful**: when a connection is allowed, the Nitro card records an entry so
return traffic is permitted without a matching reverse rule. That table has a per-instance capacity, and
when it is full, packets that would create a *new* entry are dropped. Three properties drive the whole
investigation, and each contradicts an instinct that works for the bandwidth rules.

**1. The symptom is connection failures, not slowness.** Established connections keep flowing — their entries
already exist — so the signature is connection timeouts, TLS handshake failures and **failing health checks**
while existing traffic looks healthy and every bandwidth dashboard is green. That last item is what makes this
dangerous: a failed health check pulls the instance from its load balancer, shifting load onto peers running
the same workload against the same ceiling. **This is the only allowance finding with a plausible
cascading-failure path.**

**2. It is driven by concurrent connection count, nearly independently of traffic volume.** The
steady-state occupancy is Little's Law — establishment rate × mean **tracked** lifetime — and the
tracked lifetime is the security group's idle timeout, not the connection's useful life. For a service
handling 1 KB requests with 1 KB responses:

| establishment rate | bytes moved | of a 10 Gbps allowance | tracked entries at a 60 s idle timeout |
|---|---|---|---|
| 100 conn/s | 0.002 Gbps | 0.02 % | 6 000 |
| 1 000 conn/s | 0.016 Gbps | 0.16 % | 60 000 |
| 10 000 conn/s | 0.164 Gbps | **1.6 %** | **600 000** |

1.6 % of the byte ceiling while holding 600 000 entries is the quantitative reason a resize chosen for
bandwidth reasons is the wrong instrument, and why the *idle timeout* is such a strong lever: a
connection doing one second of useful work holds its entry for 60 seconds, a **60×** amplification.

**3. Much of the tracking may be avoidable outright.** A security group tracks a connection **only if the
inbound and outbound rules are asymmetric**, or if it traverses certain external components
(`EC2_NETWORK_TRACKED_CONNECTIONS_ALLOWANCE_RECOMMENDATIONS`, `optimization-guides.ts:134`). Make the relevant
rules symmetric and the connections in scope become **untracked**, consuming no capacity at all — no other
allowance finding has a fix that removes the demand rather than raising the supply. It costs no money, which
is precisely why it gets under-scrutinised: symmetry usually means *widening* a ruleset, a security-posture
change rather than a tuning knob. See the risk ratings below.

Common causes: **no connection pooling or keep-alive** (a new TCP connection per request — the single most
common cause, and usually a client-config fix); **high connection churn** with entries persisting past close;
**long idle tracking timeouts** holding capacity for connections doing nothing; **asymmetric security-group
rules**, often unintentional, making tracking necessary at all; **fan-out to many backends**, multiplying
entries per unit of work; **genuinely high concurrency** inherent to proxies, gateways and connection-heavy
databases; a **scan, probe or retry storm**; and **long-lived connections losing tracked state** without
keep-alives under 5 minutes, forcing re-establishment.

## Reading the description

`time_series_data_point_threshold` emits, with the comparator `"greater than"`:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
At least one data point in aperf_record is 4 (greater than the threshold of 0).
```

The value is the **worst single interval delta across every series**, not a total and not an average.
Values at or above 1000 print with a K/M/G/T suffix (`formatted_number_string`,
`computations/mod.rs:176`–`:190`).

**Score math takes the `threshold == 0.0` branch** of `compute_finding_score` (`analytics/mod.rs:170`):

```
if value < 1.0  →  score = rule_score               (flat −256)
else            →  score = (value - 1.0) * rule_score
```

| worst delta | score | note |
|---|---|---|
| 0.50 | **−256.00** | fractional ⇒ multi-ENI mean; true peak was 1 refused packet |
| **1.00** | **−0.00** | **one refused connection in an interval scores zero** |
| 2.00 | **−256.00** | collides with the 0.50 score |
| 4.00 | **−768.00** | |
| 50.00 | **−12 544.00** | |

Recover the delta as `|score| / 256 + 1`, but **−256.00 is ambiguous** — produced both by the flat
branch (any sub-unit value) and by exactly 2.0 on the linear branch. Disambiguate from the value
text, never from the score. Two traps, both confirmed against the engine: **`1.00 → −0.00` renders
NEUTRAL** — `FindingIcon` returns the `face-neutral` icon for `score == 0` and `getFindingColor`
greys it (`AnalyticalFindings.tsx:35`, `:44`–`:52`), and findings sort ascending by score
(`analytics.tsx:40`), so this `Critical` availability finding lands **mid-list below every
`Concerning` finding**, off the first page at the default page size of 5. And **the score is
non-monotonic**: every delta in [1.0, 2.0) scores closer to zero than any sub-unit delta.

**A conversion trap specific to this rule: the packet count is not the failure count.** Each dropped
packet is a **connection attempt** that failed, and clients retry — so one refused connection can
become three or four dropped SYNs and one user-visible error, or one dropped SYN and no error at all if
the retry succeeds. The counter cannot tell you which; the user-visible impact lives in `netstat` and in
application error rates, not here.

## Interpretation

Enforcement is a fact, so the question is **how much of the run refused connections**:

| Pattern in the series | Reading |
|---|---|
| One interval, small delta | A brief spike exhausted the table. A few attempts failed; retries may have hidden it |
| Sustained non-zero | **Permanently at the ceiling.** New connections are failing continuously — an availability incident, not a performance nit |
| Zero, then non-zero and never recovering | **Entry accumulation.** Entries are created faster than they expire — the strongest signal for missing connection reuse, an unclosed-socket leak, or an idle timeout longer than the churn period |
| Periodic bursts | Aligned with a batch, a deploy, a health-check cycle, or a retry storm |
| Fractional value | Multi-ENI mean out-scored the real series. **True per-interface peak was one refused packet** |

Combinations that change the diagnosis:

| also fired / observed | Reading |
|---|---|
| Bandwidth and PPS allowances **all zero** | **The characteristic case.** Modest traffic, exhausted table. The instance is not undersized for throughput, so resizing for bandwidth is the wrong instrument |
| Bandwidth or PPS also non-zero | Genuinely overloaded overall. A resize helps those, but the tracking demand is a separate quantity and may survive it |
| `Link-Local Service Exceeded Instance Allowance` | Both are per-connection overheads. A per-request DNS lookup and a per-request connection usually share one root cause: no reuse |
| `netstat` `TIME_WAIT` counts high, resets elevated | **Where churn is visible.** Confirms short-lived connections and protocol-level failures |
| `Underutilized CPU` | Idle CPU with connection failures — the instance is not overloaded, it is **refusing work**. Do not "fix" the idle CPU |
| High `system` / `softirq` at modest throughput, or `number_threads` high in a thread-per-connection design | Connection setup and teardown is kernel work, and each connection costs a thread *and* a tracking entry — both corroborate churn |
| Application errors up, latency of *successful* requests normal | **The signature of this finding.** It fails new connections rather than slowing existing ones |
| `total_resets` non-zero | The series has silent gaps; every total is a lower bound |

**Known false positives — none of them make the enforcement unreal:**

- **A single interval with a tiny delta**, possibly absorbed entirely by a client retry — judge from the
  series and from whether the application observed errors; or **a fractional value**, not false about
  *whether* it happened but reporting a true per-interface peak of one refused attempt.
- **Connections not created by the workload under test.** Monitoring agents, service-mesh sidecars, health
  checkers and package updates all establish connections, and a sidecar is often the most connection-hungry
  process on the instance. Check `processes`.
- **The recording captured a startup or deploy phase**, when pools are filling and churn peaks — or **a
  scan or probe from outside** inflated attempts that were never wanted. Neither is steady state.
- **Counter reset, interface flap, or too short a run.** A decrease is *dropped* (`:202`–`:214`) rather than
  emitted as a spike, so a reset yields a gap — check `total_resets`, `interface_down`, `interface_up`; and with
  the first point a structural zero, 2–3 snapshots can miss refusal entirely.
- **The instance is legitimately a proxy or load balancer.** Very high concurrency is inherent to the role. A
  real finding, but the levers are rule symmetry, the idle timeout and horizontal scale — not application
  changes that do not exist to make.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `conntrack_allowance_exceeded` full series, **per interface** | `ena_stat` | **Do this first.** Sustained vs burst vs monotonic accumulation, and the real per-interface counts behind any fractional value |
| `conntrack_allowance_available` | `ena_stat` | **Do NOT read the plotted series** — a gauge through a delta, blind to consumption, all-zero for both full and zero headroom. Read absolute headroom from raw `ethtool -S`. **No rule fires on it** |
| `bw_in_allowance_exceeded`, `bw_out_allowance_exceeded`, `pps_allowance_exceeded` | `ena_stat` | **All zero is the characteristic pattern** — proves the constraint is connection count, not traffic volume |
| `linklocal_allowance_exceeded` | `ena_stat` | Per-request DNS or IMDS chatter alongside per-request connections: one root cause, two ceilings |
| `tx_cnt`, `rx_cnt`, `tx_bytes`, `rx_bytes` per queue | `ena_stat` | Confirms traffic volume is modest while the table is exhausted. Sum **per queue**; the aggregate is a mean |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the counter series is continuous |
| `TIME_WAIT` counts, connection resets, listen-queue drops, retransmits | `netstat` | **Where the churn and the failures are visible**, and the only place the failure *count* exists |
| `idle`, `aggregate`, then `system` and `softirq` | `cpu_utilization` | Idle CPU with connection failures = refusing work, not overloaded (see `Underutilized CPU`); high `system` at modest throughput is the kernel doing setup/teardown, which corroborates churn |
| `number_threads`, per-process state | `processes` | Thread-per-connection designs, and which process opens the connections. **No analytical rules — read manually** |
| `ctxt` | `vmstat` | Context-switch rate accompanying high churn |
| `Instance Type` | `systeminfo` | **The tracking maximum is a property of this value**, and unlike bandwidth it is not published per type — obtain it from CloudWatch or support |
| `nf_conntrack_*` if present | `sysctl` | The OS conntrack table is a **separate** table from the security group's. Tuning it does not affect this counter. **No analytical rules — read manually** |

## Guidance

Ordered. Step 3 is the fix unique to this finding — it removes the demand rather than raising the supply.

1. **Read the full series, per interface, and quantify rate and duration.**
   `python3 tools/aperf_ena_allowance.py --metric conntrack_allowance_exceeded --series <deltas>` gives the
   exceeding-interval count, peak rate, total, and the sustained/pervasive verdict. Sustained non-zero ⇒
   continuous refusal, an availability incident. Zero then permanently non-zero ⇒ entry accumulation. Isolated
   burst ⇒ correlate before escalating. Fractional ⇒ the true peak was one refused packet. **Never triage by
   score, and never read `conntrack_allowance_available` from the report**: one refused packet per interval
   scores −0.00 and renders neutral, and the headroom series plots recovery, so a saturated instance and a
   healthy one draw the same flat line.

2. **Confirm the characteristic pattern.** The other three allowance counters all zero means the instance is
   not undersized for traffic and the constraint is purely the number of tracked connections — which rules out
   the bandwidth reflex before it costs anything.

3. **Ask whether these connections need to be tracked at all — before scaling anything.** Per
   `EC2_NETWORK_TRACKED_CONNECTIONS_ALLOWANCE_RECOMMENDATIONS`, tracking applies only when inbound and
   outbound rules are asymmetric or the connection traverses certain external components; making the
   rules symmetric makes those connections **untracked**, removing their capacity cost entirely. Highest
   leverage available and zero cost in money — but review the security consequence, because symmetry is
   usually reached by widening a ruleset.

4. **Size the demand with Little's Law, then quantify the damage and find the source.** Occupancy ≈
   establishment rate × tracked lifetime, the tracked lifetime being the security-group idle timeout rather
   than the connection's useful life; get the establishment rate from `netstat` and `processes`. That turns "we
   ran out of entries" into "we need to cut occupancy by N×" and names which factor to attack. Each drop is a
   failed *attempt* and clients retry, so the packet count does not map 1:1 to failures: correlate `netstat`
   reset and connection-state counters with application error rates, and **check health-check outcomes
   explicitly**, since that is the escalation path. `TIME_WAIT` counts plus `processes` then name the churn
   source — usually a client opening a new connection per request, but sidecars, health checkers and monitoring
   agents are connection-heavy and are fixed by configuring them, not resizing.

5. **Remediate**, per `EC2_NETWORK_TRACKED_CONNECTIONS_ALLOWANCE_RECOMMENDATIONS` — but note the risk ratings,
   which do **not** follow the cost ordering:
   - **Enable connection pooling and keep-alive in clients.** Cheapest, lowest-risk, and usually the largest
     single reduction: it attacks the establishment *rate*, the other factor in step 4. **Send TCP keep-alives
     under 5 minutes** on long-lived connections so they retain tracked state instead of paying
     re-establishment cost, and **reduce fan-out** so one unit of work opens one connection.
   - **Make inbound and outbound rules symmetric** so the connections in scope become untracked — upstream's
     first recommendation, and a security-posture change (R3).
   - **Configure the shortest workable idle connection-tracking timeout** so unused entries are released
     quickly. Powerful because of the step-4 amplification, but it evicts genuinely idle long-lived connections
     (R3) — pair it with the keep-alive change above.
   - **Use stateless network ACLs** where access control allows: they consume no tracking capacity, but NACLs
     are subnet-wide and stateless, so ephemeral ranges must be opened both ways (R4).
   - **Scale out** to spread connections across more instances, if the concurrency is genuinely irreducible. A
     resize also raises the tracking maximum, but the limit is a step function of instance size rather than a
     published per-type figure — confirm the new ceiling before buying.

## Priority and execution risk

**Priority: P1 — Act now** whenever the exceedance is sustained (≥5 consecutive intervals) or pervasive (≥25 %
of intervals), because refusal is measured rather than inferred and the failures are user-visible errors rather
than added latency. It rises to **P0 — Emergency** on a narrower condition than the bandwidth rules use: **any
sustained streak that coincides with failing health checks**, pervasive or not. A failed health check removes
the instance from its load balancer and moves its load onto peers running the same workload against the same
ceiling, so this is the one allowance finding with a credible cascade. It drops to **P3 — Monitor** for a single
exceeding interval with no correlated application error — a retry very plausibly absorbed it — and to **P4 —
Informational** when the value is fractional (true peak one refused packet) or the connections are attributable
to a sidecar rather than the workload. Note the same score asymmetry as the rest of the family: the P4 case
reads **−256.00** and the P3 case can read **−0.00**.

**Execution risk: R0 — Read-only** to resolve: the series, the per-interface split, the rate-and-duration
arithmetic, the Little's-Law sizing and the `netstat` correlation are all reads. Acting is where this finding
parts company with the bandwidth ones, because **cheap does not mean safe here** — the zero-cost fixes are
changes to security controls. **R1** for client-side connection pooling, keep-alive intervals and reducing
fan-out: reversible application configuration, and the correct place to start. **R2** for scaling out to spread
connections, which changes distribution but not the application. **R3** for making security-group rules
symmetric, since symmetry is normally reached by *widening* a ruleset — a security-posture change requiring
review, not a tuning knob; **R3** likewise for shortening the idle tracking timeout, which evicts genuinely idle
long-lived connections and can introduce the very failures you are trying to remove. **R4** for replacing
security-group rules with stateless NACLs: the blast radius is the whole subnet, ephemeral port ranges must be
opened both ways, and an error either black-holes every instance in the subnet or exposes it. **Do not inherit
the R0 of the reading into the rule change**, and do not read upstream's ordering as a risk ordering — it ranks
leverage.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `conntrack_allowance_exceeded` interval delta, on any series including
the auto-generated `average`, was `> 0.0`.

```
STEP 0 — Is the reported VALUE trustworthy? Check before reading anything into it.
  IF the value is FRACTIONAL (e.g. 0.50, 0.33)
  THEN → the `average` out-scored every interface. Over 1,596 multi-ENI combinations the
         true peak is EXACTLY 1: ONE refused attempt, reported at -256.00 (P4, R0)
       → verify: read the per-interface series directly; the peak must be 1
  IF `total_resets` or `interface_down` is non-zero
  THEN → the ENA driver reset mid-run. A DECREASE is dropped entirely
         (time_series_data_processor.rs:202-:214) while the baseline advances, so refusals
         between those snapshots are LOST and every total below is a lower bound (P2, R0)
  IF the series has fewer than 4 points
  THEN → the first point is a structural zero, so 2-3 snapshots cover 1-2 real intervals and
         neither rate nor duration is establishable. Re-record with `--period 300` (P2, R0)
       → verify: series length minus 1 equals the intervals actually covered
  OTHERWISE
  THEN → the value is a genuine worst-interval delta. Continue (P2, R0)

STEP 1 — Rate and duration. This, not the firing, is the finding.
         `tools/aperf_ena_allowance.py --metric conntrack_allowance_exceeded --series <deltas>`
  IF exceeding in >=5 CONSECUTIVE intervals AND >=25% of intervals
  THEN → the ceiling is this workload's steady state: new connections fail continuously. An
         AVAILABILITY incident, not a performance nit. Go to STEP 3 (P1, R0)
  IF sustained (>=5 consecutive) but not pervasive
  THEN → one phase refused connections. Identify it: a deploy or pool-fill burst is a
         different problem from a serving-hours ceiling (P1, R0)
  IF exactly ONE exceeding interval
  THEN → one refused attempt, very possibly absorbed by a client retry. Correlate with
         application errors before spending anything (P3, R0)
       → verify: application error rate in that second. No excursion means no action
  IF intermittent (several intervals, longest streak < 5)
  THEN → bursty establishment. Attack the RATE first via pooling and keep-alive, the cheapest
         and most reversible lever available (P2, R1)
       → verify: the exceeding-interval count falls AND `netstat` TIME_WAIT counts fall.
         TIME_WAIT flat means the pooling did not take effect

STEP 2 — Is this the tracking table, or something else that refuses connections?
  IF `netstat` listen-queue drops or accept-queue overflows are non-zero
  THEN → the application is not accepting fast enough; its own backlog is refusing connections,
         a separate mechanism with a separate fix (backlog, accept loop, thread pool) (P1, R1)
       → verify: after the backlog fix, `conntrack_allowance_exceeded` should be UNCHANGED
         -- it is a distinct mechanism. If it moved, the attribution was wrong
  IF an OS-level `nf_conntrack` table limit is being hit in `sysctl` or dmesg
  THEN → that is the KERNEL's table, independent of the security group's, and tuning `sysctl`
         cannot change this counter. Fix separately (P2, R1)
       → verify: the ENA counter is unchanged by the sysctl change
  OTHERWISE
  THEN → the security group's tracking table is the mechanism. Continue (P1, R0)

STEP 3 — Do these connections need to be TRACKED at all? Ask before sizing anything.
  IF the relevant security-group inbound and outbound rules are ASYMMETRIC
  THEN → asymmetry is what makes tracking necessary (optimization-guides.ts:134); symmetric
         rules make those connections UNTRACKED at no capacity cost -- and no money, but
         symmetry usually means WIDENING a ruleset, a posture change needing review (P1, R3)
       → verify: exceeding intervals go to ZERO at the same offered load, and the widened rule
         admits nothing the old pair did not already effectively admit
  IF access control could be expressed with stateless network ACLs instead
  THEN → NACLs consume no tracking capacity, but they are SUBNET-wide and stateless: ephemeral
         ranges must be opened both ways and an error black-holes or exposes every instance in
         the subnet (P2, R4)
       → verify: in a non-production subnet first -- the workload still connects AND nothing
         new is reachable
  OTHERWISE
  THEN → the connections are genuinely tracked. Size the demand at STEP 4 (P1, R0)

STEP 4 — Size the demand, then reduce it. Attack the RATE before the LIFETIME.
  IF the establishment rate is obtainable from `netstat` and `processes`
  THEN → occupancy ~= rate x TRACKED lifetime, the tracked lifetime being the SG idle timeout
         rather than the connection's useful life. A 1s connection under a 60s timeout holds
         its entry 60x too long; that ratio names which factor to attack (P1, R0)
  IF measured bandwidth and PPS are a small fraction of their allowances
  THEN → the characteristic case: at 10,000 conn/s of 2 KB exchanges you are at ~1.6% of a
         10 Gbps ceiling while holding ~600,000 entries, so a resize bought for BANDWIDTH
         reasons is the wrong instrument (P1, R0)
  IF the concurrency is genuinely irreducible (proxy, gateway, connection-heavy database)
  THEN → scale OUT to spread connections. A resize raises the tracking maximum too, but by a
         step function of instance size that is not published per type -- confirm the new
         ceiling before buying (P1, R2)
       → verify: exceeding intervals are ZERO at the same offered load, not merely fewer

STEP 5 — Reduce the demand at the application. Cheapest and most reversible levers.
  IF clients open a new connection per request, or one request fans out to several backends
  THEN → enable pooling and keep-alive, and pool or reduce the fan-out. Usually the largest
         single reduction, reversible, and no security review (P1, R1)
       → verify: TIME_WAIT counts and the exceeding-interval count BOTH fall. Only one
         falling means connections are being reused but not for long enough
  IF the idle tracking timeout is long relative to the connection's useful life
  THEN → shorten it so capacity recycles, and send TCP keep-alives under 5 minutes so
         long-lived connections keep their entries instead of paying re-establishment.
         Strong because of the STEP 4 amplification, but shortening EVICTS genuinely idle
         long-lived connections -- which is why the two are paired (P1, R3)
       → verify: exceeding intervals fall AND no new mid-connection resets appear. Resets
         rising means the timeout is now shorter than a real idle period

STEP 6 — Whose connections are they? Neither a resize nor a rule change fixes someone else's.
  IF a sidecar, health checker, monitoring agent or updater is active in `processes`
  THEN → configure it to reuse connections or poll less often. Cheaper than any of the above
         and it does not touch the serving path (P2, R1)
       → verify: re-record with the agent reconfigured; exceeding intervals should vanish
  IF connection attempts arrive from outside the expected client set
  THEN → a scan, probe or retry storm. Filter at the edge; capacity spent on unwanted attempts
         cannot be recovered by sizing (P1, R2)
       → verify: attempt rate falls to the expected client population
  IF the recording covered a startup, deploy or pool-fill phase
  THEN → churn peaks there by construction and is not steady state. Re-record during serving
         hours (P3, R0)

STEP 7 — What survives?
  VALID      : that the Nitro card dropped packets which would have created tracking entries,
               so NEW connections failed -- hardware enforcement, not inference; the
               exceeding-interval COUNT, the peak per-second rate, the run TOTAL as a sum of
               the series, and the longest streak
  CAUTION    : any total on a run with `total_resets` non-zero (lower bound only); a
               sustained/pervasive verdict on <=10 intervals, where `--period 10` cannot
               separate continuous refusal from a run that ended mid-burst; and any
               Little's-Law occupancy figure, estimated from an establishment rate aperf
               does not measure directly
  CONFOUNDED : any AVERAGE over the raw series, diluted by (n-1)/n by the forced first zero;
               the reported value when FRACTIONAL, a multi-ENI mean hiding a one-packet peak;
               and the dropped-packet count read as a FAILURE count, since each drop is an
               ATTEMPT and clients retry
  VOID       : any reading of the plotted `conntrack_allowance_available` series -- a gauge
               run through add_accumulative_data_point, blind to consumption in 15,625 of
               15,625 simulated trajectories and identical for full and zero headroom; any
               RANKING by score, the formula being non-monotonic in [1.0, 2.0) with -256.00
               having two disjoint preimages; and any claim that the OS `nf_conntrack` table
               and the security group's table are the same thing

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:205).
         Absence proves nothing about the tracking table (P3, R0)
  IF the finding did NOT fire and the question was "am I near the tracking limit?"
  THEN → absence is WEAKER evidence than for the other allowances: the headroom metric is
         unreadable, so a run one connection short of the ceiling looks exactly like an idle
         one. Re-record with `--period 300`, read headroom from `ethtool -S` (P2, R0)
  IF the instance's tracking maximum is unknown
  THEN → unlike bandwidth it is not published per type, so refusal cannot be converted into a
         target occupancy. The STEP 1 shape verdict and STEP 4 RATIO still stand (P2, R0)
```

## Runtime-specific consequences

The table is enforced below the OS, so every runtime is refused identically — but what each does in
response differs, and that changes the symptom you will be shown.

- **Any TCP client without pooling.** The dropped packet is a SYN, so the client sees a connect timeout only
  after its SYN retransmission schedule expires — seconds, not milliseconds. The symptom is a *long* timeout
  on a *new* connection while in-flight requests on established connections complete normally.
- **Java.** HTTP clients differ sharply: a pooling client holds entries for the pool's idle lifetime, while a
  per-request client multiplies establishment rate by request rate. The symptom is usually a connect-timeout
  exception several layers from the network, with `java_profile` showing threads parked in connect, not read.
- **UDP workloads.** Security groups track UDP flows too, on an idle timeout rather than a connection
  lifecycle, and there is no handshake to fail visibly — the datagram is simply gone, and silent loss is
  harder to attribute than a connect timeout.
- **Containers and service meshes.** The tracking table belongs to the **instance**, and attaching another ENI
  does not add capacity: containers sharing one ENI compete for one table with no per-container accounting, so a
  connection-hungry sidecar can refuse the primary workload's connections and neither container's metrics show
  why. A mesh sidecar terminates and re-originates connections, *doubling* entries per logical request — or
  *reducing* them by pooling upstream. Check which.
- **Health-check endpoints.** A short-interval check opening a fresh connection each time both consumes entries
  and fails first when they run out — the mechanism that turns this into an instance removal.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in threshold — but less legibly so than the
bandwidth allowances.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and unlike the `perf_stat` family
  there is no per-architecture config to consult.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*` and
  `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container with only
  virtual interfaces **`ena_stat` collects nothing** and the rule cannot fire — silence is structural, not health.
- **The tracking maximum is a property of instance type and size, not of the CPU**, so a same-size Graviton and
  x86 instance in one family carry the same maximum and a Graviton migration does not change this ceiling. **ENA
  Express (SRD)** does not change it either — an `ena_srd_*` finding alongside this one is a separate matter.
- **The maximum is not published the way bandwidth is.** EC2 tabulates bandwidth per instance type; the
  connections-tracked allowance is not. That is why step 4 sizes a *ratio* to attack rather than an absolute
  target, and why a resize here is a weaker instrument than for bandwidth.
- **There is no burst-credit behaviour.** The table is a hard count, so "zero then permanently non-zero" means
  entry accumulation, never a falling ceiling — a genuinely different reading of the same shape than on the
  bandwidth pages.
- **The security group's table is per instance; NACLs are per subnet.** That asymmetry is why the NACL
  substitution has a subnet-wide blast radius while the symmetric-rule fix does not.

## Verification

The falsifiable claim is *the instance's connection-tracking table was full for this fraction of the run, and
new connections failed as a result*. Verify in that order.

1. **Confirm the value is not the multi-ENI artifact, and that the series is continuous.** A fractional reading
   means the true per-interface peak was one refused packet — read the per-interface series; and
   `total_resets`, `interface_down`, `interface_up` must be zero or every total is a lower bound.
2. **Quantify rate and duration.** `tools/aperf_ena_allowance.py --metric conntrack_allowance_exceeded --series
   <deltas>` — exceeding count, peak rate, total, sustained/pervasive verdict. Check the score against
   `|score| / 256 + 1` and expect the −256.00 ambiguity.
3. **Do not use the headroom series as corroboration.** Predict in advance that
   `conntrack_allowance_available` plots flat at zero regardless of the truth; if it does, that confirms the
   defect, not health. Absolute headroom must come from raw `ethtool -S` or CloudWatch.
4. **Confirm the constraint is connections, not volume.** The other three allowance counters at zero while
   bandwidth and PPS sit at a small fraction of their ceilings is the characteristic pattern.
5. **Find the failures.** `netstat` connection resets and `TIME_WAIT` counts, plus application error rates
   during the exceeding intervals, and **health-check outcomes explicitly**. If nothing moved, refusal happened
   but no caller observed it — report that plainly rather than escalating.
6. **Rule out the impostors.** Listen-queue drops (an application backlog problem) and OS `nf_conntrack` limits
   (a different table). If either is present, predict *before* the fix that repairing it leaves
   `conntrack_allowance_exceeded` unchanged; a change falsifies the attribution.
7. **Re-record with a longer period.** At the default `--period 10` roughly 9 real intervals are observed,
   which cannot separate continuous refusal from a run that ended mid-burst.
8. **After remediation, predict zero.** At the same offered load the exceeding-interval count must be **zero**,
   not merely lower. And for the two R3 changes, predict the *absence* of a new symptom: no new mid-connection
   resets after shortening the idle timeout, and nothing newly reachable after making rules symmetric.

## Do not

- **Do not dismiss this finding because the score is small or zero, and do not rank it by score.** One refused
  packet in an interval scores −0.00 and renders with a neutral face, greyed out, sorted mid-list, while the
  rule is `Critical` and the refusal is measured. The formula is non-monotonic in [1.0, 2.0), −256.00 is
  produced both by any sub-unit value and by exactly 2.0, and a 50-packet interval scores −12 544.00 — orders
  of magnitude past any other rule.
- **Do not read the plotted `conntrack_allowance_available` series.** It is a gauge run through
  `add_accumulative_data_point`, so it shows headroom *released* and never headroom *consumed*; full headroom
  and zero headroom plot the same flat line, compressed to two points.
- **Do not read the value as a run total, or average the raw series.** It is a per-interval delta; sum the
  series for the total, and the forced first zero dilutes any average by (n−1)/n. And **do not read a
  fractional value as a real packet count** — it is a multi-ENI mean that out-scored the real series, meaning
  the true per-interface peak was exactly one refused packet.
- **Do not read the packet count as the number of affected requests.** Each drop is a failed connection
  *attempt*; retries both multiply the count and sometimes hide the failure entirely.
- **Do not look for a performance problem.** This finding fails *new* connections while existing ones run
  normally — the symptom is errors and timeouts, not latency, and the escalation path is a health check.
- **Do not assume low traffic means this cannot happen.** At 10 000 connections per second of 2 KB exchanges
  you are at 1.6 % of a 10 Gbps ceiling and holding hundreds of thousands of entries.
- **Do not resize for bandwidth reasons, and do not attach another ENI expecting more capacity.** The maximum
  is per instance; check rule symmetry and the idle timeout first, since removing the tracking requirement
  costs no money and may remove the problem entirely.
- **Do not treat the zero-cost fixes as low-risk.** Making rules symmetric widens a ruleset, and shortening
  the idle timeout evicts idle long-lived connections. Both are R3; the stateless-NACL substitution is R4 with
  a subnet-wide blast radius.
- **Do not confuse the security group's tracking table with the OS `nf_conntrack` table.** They are
  independent; tuning `sysctl` conntrack limits cannot change this counter.
- **Do not chase EFA because the message says "EFA".** All five allowance messages name the wrong device;
  this is an ENA metric read by `ethtool -S`.
- **Do not treat absence of the finding as proof of headroom.** The first point is a structural zero, the
  default `--period 10` observes about 9 real intervals, and the headroom metric that would otherwise
  settle the question is unreadable.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:38`–`:46` (`Comparator::Greater`, threshold `0.0`,
  `Score::Critical`; the `"EFA"` at `:45` is an upstream defect), and its template
  `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs`, which iterates every series
  including the aggregate and keeps the largest `|score|` with `>=`. Score formula: `compute_finding_score`,
  `src/analytics/mod.rs:167`–`:176` — the `threshold == 0.0` branch, flat below 1.0 and linear above.
- Delta processing: `add_accumulative_data_point` (`src/data/ena_stat.rs:343`) is applied to every metric
  including the `conntrack_allowance_available` **gauge**; `get_delta_and_set_previous_value`
  (`src/data/common/time_series_data_processor.rs:189`–`:224`) supplies the forced first zero
  (`:218`/`:73`), the dropped decrease (`:202`–`:214`) and the all-zero compression (`:410`–`:427`).
  `average` aggregate / `sum/count` mode / single-ENI suppression: `ena_stat.rs:315`, `:249`–`:256`, `:315`–`:319`.
- Metric descriptions: `conntrack_allowance_exceeded` at
  `src/report_frontend/src/definitions/data-descriptions.ts:3831`; the unreadable
  `conntrack_allowance_available` gauge at `:3852`, with **no analytical rule** in `ena_stat.rs`.
- Upstream guide: `EC2_NETWORK_TRACKED_CONNECTIONS_ALLOWANCE_RECOMMENDATIONS`,
  `src/report_frontend/src/definitions/optimization-guides.ts:134` — source of the symmetric-rules,
  network-ACL, idle-timeout and keep-alive recommendations, in that order.
- Zero-score rendering: `AnalyticalFindings.tsx:35` (`getFindingColor`), `:44`–`:52` (`FindingIcon`),
  ascending score sort at `src/report_frontend/src/utils/analytics.tsx:40`.
- Collection: `Ethtool::new` filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL` ioctl, `:31`–`:33`.
  Quantifier: [`../tools/aperf_ena_allowance.py`](../tools/aperf_ena_allowance.py), with
  `conntrack_headroom_is_unreadable()` and `aggregate_masks_the_peak()`.
- [Security group connection tracking](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/security-group-connection-tracking.html),
  [automatically tracked connections](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/security-group-connection-tracking.html#automatic-tracking),
  [Network ACLs](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-network-acls.html),
  [Monitor network performance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
- Related: `link-local-service-exceeded-instance-allowance.md` (the other per-connection overhead),
  `inbound-bandwidth-exceeded-instance-allowance.md`, `pps-exceeded-instance-allowance.md`,
  `underutilized-cpu.md` (idle CPU while refusing work).
