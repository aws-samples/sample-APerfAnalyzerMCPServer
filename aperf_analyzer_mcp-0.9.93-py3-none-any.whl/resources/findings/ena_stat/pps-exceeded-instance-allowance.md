---
rule_name: PPS Exceeded Instance Allowance
data_type: ena_stat
data_key: pps_allowance_exceeded
template: time_series_data_point_threshold
condition: "any(pps_allowance_exceeded) > 0.0"
base_score: Critical
score_sign: negative
requires_comparison: false
aperf_message: "EFA is queuing or dropping packets due to exceeding the instance's bidirectional PPS maximum."
source: src/analytics/rules/ena_stat.rs:32
---

# PPS Exceeded Instance Allowance

## What fired

**At least one** interval delta of `pps_allowance_exceeded` was **greater than 0.0** — the Nitro card
queued or dropped packets because the instance's **bidirectional packets-per-second** maximum was
exceeded.

Base score `Critical` (**−256**). Single-run rule, `Comparator::Greater`, threshold `0.0`
(`ena_stat.rs:32`).

A hardware enforcement counter, not a heuristic: the card incremented it because it actually shaped or
dropped traffic. Two questions follow, and in this order — **whether the bandwidth counters are also
non-zero** (which decides the entire remediation path), then **RATE and DURATION**.

> **The message names the wrong device.** aperf says *"EFA is queuing or dropping packets"*. All five
> `ena_stat` allowance rules (`ena_stat.rs:21`, `:29`, `:37`, `:45`, `:53`) say "EFA" when they mean
> **ENA**. The metric is read by the `ethtool` ioctl on the ENA interface (`ena_stat.rs:235`); Elastic
> Fabric Adapter is a different device with its own data type and rules. The `data-descriptions.ts`
> entries for these same metrics (`:3817`–`:3851`) are correct.

## The processing caveat — verified by simulating the collection loop

Three properties of `ena_stat`'s processing change what the number means, and one makes the reported
value **fractional and misleading** in a narrow but reachable case.

**1. The series is already a per-interval delta.** `add_accumulative_data_point` (`ena_stat.rs:343`)
stores `current − previous` between `ethtool` snapshots. At the default `--interval 1`
(`record.rs:35`) each point is "packets shaped in about one second". Summing the series gives the run
total; the reported value is one interval.

**2. The first point is a forced zero covering no elapsed time.**
`get_delta_and_set_previous_value` finds no previous value, takes the `None` arm
(`time_series_data_processor.rs:218`), and returns `0.0` because `ignore_first_accumulative_value`
defaults to `true` (`:73`). Only `perf_stat` opts out (`perf_stat.rs:1295`). An n-snapshot run yields an
n-point series over **(n−1) × interval** seconds, so any *average* over the raw series is diluted by
(n−1)/n. Sums, peaks and streaks are unaffected.

**3. The auto-generated `average` series can WIN the rule's selection and print a fractional packet
count.** `ena_stat` aggregates with `time_series_data_processor_with_average_aggregate`
(`ena_stat.rs:315`), so a multi-ENI instance gains an `average` series that is the **mean** across
interfaces, and the rule iterates every series including it. Because the `threshold == 0.0` branch pins
every value below 1.0 at the flat **−256.00** while exactly 1.0 scores **−0.00**, a one-packet peak is
out-scored by its own sub-unit mean:

| series | value | \|score\| | selected? |
|---|---|---|---|
| `eth0` | 1.0 | **0.00** | no |
| `eth1` | 0.0 | — | does not fire |
| `average` | **0.5** | **256.00** | **yes — reported** |

Brute-forcing 1,596 combinations over 2/3/4/8 ENIs with peaks in {0, 1, 2, 3, 5, 10, 47, 1000} found
the artifact in exactly 22 cases, and **the peak per-interface delta was 1 in every one**. At a peak of
2 the real series scores −256.00 and wins outright, so the window is the single value 1.0:

> **A fractional value in the description means the true per-interface peak was exactly ONE packet.**
> The mildest possible reading of a `Critical` finding, reported with the most severe score a small
> delta can produce.

Two scope limits, both verified: the queue split at `ena_stat.rs:332` fires only for names of the form
`queue_<n>_...`, and none of the five allowance metrics match — so these are always **one series per
interface**, never per queue (`tx_cnt` and `rx_cnt`, by contrast, *are* per queue, which is why the
mean-packet-size arithmetic below sums those separately). And on a single-ENI instance the aggregate is
**dropped before rendering** (`time_series_data_processor.rs:315`–`:319`), so the artifact needs **two
or more ENIs** to exist at all.

`tools/aperf_ena_allowance.py` carries all of this; `aggregate_masks_the_peak()` returns the verdict, and
`tools/test_aperf_ena_allowance.py` re-derives the 1.0 bound over 2,044 combinations.

## Reasoning

`pps_allowance_exceeded` is the *"Number of packets queued or dropped because the bidirectional
Packet-per-second (PPS) exceeded the maximum for the instance. PPS allowance is enforced separately to
the overall bandwidth allowance and, while the instance may still be under overall bandwidth allowance,
the PPS allowance may exceed if the mean packet size is small."* (`data-descriptions.ts:3831`,
`desired: "lower"`)

Two properties make this rule different from the two bandwidth rules, and both matter for diagnosis:

1. **It is bidirectional.** Bandwidth has separate inbound and outbound ceilings; the PPS ceiling covers
   transmit and receive **together**, so `tx_cnt` and `rx_cnt` are the only way to learn which direction
   dominates the packet rate.
2. **It is a ceiling on *packet count*, not bytes, enforced independently of bandwidth.** The Nitro card
   spends a fixed amount of work per packet regardless of size. A 64-byte packet and a 9000-byte packet
   cost the same against the PPS budget while contributing 140× different amounts to the bandwidth
   budget.

That leads to the finding's central diagnostic, which upstream states explicitly in
`EC2_NETWORK_PPS_ALLOWANCE_RECOMMENDATIONS` (`optimization-guides.ts:125`):

> *"If the `pps_allowance_exceeded` metric is the only one breaching, while the
> `bw_*_allowance_exceeded` metrics stay zero, this indicates that the network traffics are dominated
> by small packets, possibly caused by packet fragments."*

**So the first check is not this metric — it is whether the bandwidth metrics are also non-zero:**

- **PPS only, bandwidth zero** ⇒ **a small-packet problem.** You are nowhere near the byte ceiling but
  are exhausting the per-packet budget. The fix is to send *fewer, larger* packets, usually with no
  infrastructure change at all — the one case where a resize is the *wrong* answer.
- **PPS and bandwidth both non-zero** ⇒ the instance is simply undersized for the traffic; scaling
  addresses both ceilings at once.

Common causes of a high packet rate at low byte volume: chatty request/response protocols (RPC-heavy
meshes, per-key cache lookups, uncoalesced health checks); no batching or pipelining, one item per packet
where a hundred would fit; `TCP_NODELAY` everywhere, so small writes leave as individual packets;
**packet fragmentation**, named explicitly upstream — an MTU mismatch along the path splits each logical
message into several packets, multiplying PPS at *identical* byte volume, which is why the traffic looks
unchanged while PPS doubles; a 1500-byte MTU where 9001 is available, ~6× more packets for bulk transfer;
disabled offloads (no TSO/GSO/GRO/LRO), so the stack handles wire-sized segments; DNS, metadata, and
monitoring chatter (whose *link-local* portion has its own separate allowance and finding); ACK-heavy or
retransmission-heavy traffic, since recovery traffic is mostly small packets so a drop problem amplifies
into a PPS problem; and genuinely packet-rate-bound workloads — DNS servers, load balancers, game
servers, telemetry ingestion — where the lever is instance choice or horizontal scale.

The consequence follows the bandwidth rules' non-linear pattern: queueing adds latency and jitter, drops
become TCP congestion signals, senders back off, throughput falls below the ceiling. And because recovery
traffic is itself small-packet-heavy, PPS exhaustion self-reinforces.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"greater than"`:

```
At least one data point in aperf_record is 1 (greater than the threshold of 0).
```

The value is the **worst single interval delta across every series**, not a total and not an average.
Values at or above 1000 print with a K/M/G/T suffix (`formatted_number_string`,
`computations/mod.rs:176`–`:190`).

**Score math takes the `threshold == 0.0` branch** of `compute_finding_score` (`analytics/mod.rs:170`):

```
if value < 1.0  →  score = rule_score               (flat −256)
else            →  score = (value - 1.0) * rule_score
```

| worst delta | score | note |
|---|---|---|
| 0.50 | **−256.00** | fractional ⇒ multi-ENI mean; true peak was 1 packet |
| **1.00** | **−0.00** | **one packet in an interval scores zero** |
| 2.00 | **−256.00** | collides with the 0.50 score |
| 5.00 | **−1024.00** | |
| 100.00 | **−25 344.00** | |

Recover the delta as `|score| / 256 + 1`, but **−256.00 is ambiguous**: it is produced both by the flat
branch (any value below 1.0) and by exactly 2.0 on the linear branch. Disambiguate from the
description's value text, never from the score.

**Two traps, both confirmed by running the engine** — the `is 1` case above produced literally
`"score": -0.0`:

- **`1.00 → −0.00` renders as NEUTRAL.** `FindingIcon` returns the `zero` icon (`face-neutral`) for
  `score == 0` and `getFindingColor` greys it out (`AnalyticalFindings.tsx:35`, `:44`–`:52`). Findings
  sort ascending by score (`analytics.tsx:40`), so this `Critical` finding lands **mid-list**, below
  every `Concerning` finding, with a neutral face beside it.
- **The score is non-monotonic.** Every delta in [1.0, 2.0) scores *closer to zero* than any delta below
  1.0. A larger value can score better.

**Never triage this rule by score, or compare its score with anything else in the report. Check whether
the finding exists at all.**

## Interpretation

**The decisive comparison is against the bandwidth findings, not the value itself:**

| PPS **and** bandwidth | Reading |
|---|---|
| PPS non-zero, `bw_in`/`bw_out` **both zero** | **Small-packet problem.** Well under the byte ceiling, exhausting the per-packet budget. Check fragmentation and batching first — the fix is often free, and a resize is the wrong answer |
| PPS non-zero, bandwidth also non-zero | The instance is undersized overall. Scaling addresses both |
| Bandwidth non-zero, PPS zero | Not this finding's case — large packets, byte-bound. See the bandwidth playbooks |

Then the series shape:

| Pattern | Reading |
|---|---|
| One interval, small delta | A brief burst. Real; correlate with a known event |
| Sustained non-zero across the run | **Packet-rate-limited.** A leading bottleneck |
| Zero, then non-zero from a point onward | Burst-credit exhaustion, or a phase change that raised the packet rate |
| Periodic bursts | Batch job, health-check storm, or retry storm |
| Growing across the run | Suspect retransmission amplification — recovery traffic is small-packet-heavy |
| Fractional value | Multi-ENI mean out-scored the real series. **True per-interface peak was one packet** |

Other combinations:

| also fired / observed | Reading |
|---|---|
| Mean packet size (`tx_bytes`/`tx_cnt`, `rx_bytes`/`rx_cnt`) small, or `rx_copybreak_pkt` elevated | **Confirms the small-packet diagnosis.** The single most useful derived number for this finding, plus an independent counter that agrees |
| `Link-Local Service Exceeded Instance Allowance` also fired | Part of the packet rate is DNS/IMDS/time-sync chatter, which has its *own* separate allowance. See that playbook |
| TCP retransmits elevated (`netstat`) | Recovery traffic is small-packet-heavy — possible amplification loop |
| `tx_queue_stop` / `tx_queue_wakeup` elevated | Driver-level transmit backpressure consistent with high packet rates |
| `softirq` high, or high `system` with low `user` (`cpu_utilization`) | **Expected here** — per-packet processing is a CPU cost. High PPS is often a CPU problem *and* an allowance problem |
| `Underutilized CPU` | The bandwidth/PPS-bound signature — idle CPU waiting on the network |
| `suspected_poll_starvation`, `missing_intr` | The receive path could not keep up with the packet rate; interrupt affinity or CPU contention |
| `total_resets` non-zero | The series has silent gaps — the total is a lower bound by an unknown amount |

**Known false positives — none of them make the enforcement unreal:**

- **A single interval with a tiny delta**, or a **fractional value** where the magnitude is a mean and
  the true per-interface peak was one packet. Enforcement happened; impact may be negligible.
- **Traffic not generated by the workload under test** — monitoring agents, health checks, service
  meshes, and sidecars are all high-PPS, low-byte producers. Check `processes`.
- **The recording captured a setup or teardown phase.** Connection-establishment storms are PPS-heavy.
- **Counter reset or interface flap.** A decrease is *dropped* (`:202`–`:214`) rather than emitted as a
  spike, so a reset yields a gap; `total_resets` or `interface_down` non-zero means discontinuity. And on
  a very short run the structural first zero can hide enforcement entirely.
- **The workload is legitimately packet-rate-bound.** DNS, load balancers, telemetry ingestion, and game
  servers run at high PPS by design. A real finding, but the lever is instance selection or horizontal
  scale, not code.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `bw_in_allowance_exceeded`, `bw_out_allowance_exceeded` | `ena_stat` | **Do this first.** Both zero ⇒ the small-packet case, which has the cheapest fixes |
| `tx_cnt` and `rx_cnt` per queue | `ena_stat` | **Which direction dominates the packet rate** — the allowance is bidirectional, so this is the only way to tell |
| `tx_bytes`/`tx_cnt` and `rx_bytes`/`rx_cnt` | `ena_stat` | **Derive the mean packet size.** The key number here: small means batching/MTU/fragmentation work will pay off |
| `pps_allowance_exceeded` full series, **per interface** | `ena_stat` | Sustained vs burst; true per-interface counts behind a fractional value |
| `linklocal_allowance_exceeded` | `ena_stat` | Whether DNS/IMDS/time-sync chatter contributes. See `Link-Local Service Exceeded Instance Allowance` |
| `tx_queue_stop`, `tx_queue_wakeup`, `rx_copybreak_pkt` | `ena_stat` | Transmit backpressure, and a direct count of small received packets that corroborates the diagnosis. **No rules fire on these** — read manually |
| `suspected_poll_starvation`, `missing_intr`, `num_of_active_io_queues` | `ena_stat` | Whether the receive path can keep up with the packet rate, and how much queue parallelism it has. Read manually |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the series is continuous |
| `Instance Type` | `systeminfo` | **The PPS allowance is a property of this value** |
| TCP retransmit, timeout and `IpExt` octet counters | `netstat` | Whether recovery traffic is amplifying PPS. **TCP only: aperf reads just `/proc/net/netstat` (`netstat.rs:33`), which has no UDP section, so a UDP-heavy packet rate is invisible here** |
| `softirq`, `system`, `idle` | `cpu_utilization` | Per-packet processing is a CPU cost; high `softirq` with high PPS means the receive path is also CPU-limited |
| `interrupts` distribution | `interrupts` | Whether network interrupts concentrate on a few CPUs — a common PPS bottleneck independent of the allowance. **No analytical rules — read manually** |
| Per-process activity | `processes` | Which process generates the packet rate. **No analytical rules — read manually** |

## Guidance

Ordered. **Step 2 is what makes this finding distinctive** — do it before anything expensive.

1. **Read the full series, per interface, and quantify rate and duration.**
   `python3 tools/aperf_ena_allowance.py --metric pps_allowance_exceeded --series <deltas>` gives
   exceeding-interval count, peak rate, total, and the sustained/pervasive verdict. Fractional values
   mean the multi-ENI mean won; read the per-interface series.

2. **Compare against the bandwidth findings — this determines the entire remediation path.**
   - **Bandwidth counters both zero** ⇒ **the small-packet case.** You are far from the byte ceiling. Go
     to step 3; the fixes are usually free and a resize is the wrong answer.
   - **Bandwidth also non-zero** ⇒ the instance is undersized overall; scaling addresses both. Skip to
     step 5.

3. **Derive the mean packet size** from `tx_bytes`/`tx_cnt` and `rx_bytes`/`rx_cnt`, summing the
   **per-queue** series, and identify which direction dominates the packet count — the allowance is
   bidirectional, so this is not available from the allowance counter itself. A small mean packet size
   confirms the diagnosis and says which side to fix.

4. **Rule out fragmentation before optimizing application behaviour.** Upstream names packet fragments
   explicitly. An MTU mismatch along the path multiplies the packet count at identical byte volume, so
   the traffic looks unchanged while PPS doubles or worse. Check the interface MTU and path MTU; a
   mismatch is a configuration fix, not a code change, and it is the cheapest possible resolution.

5. **Establish the actual ceiling, and never triage by score.** Read `Instance Type` from `systeminfo`
   and compare the measured packet rate (summed `tx_cnt` + `rx_cnt` per interval, since the allowance is
   bidirectional) against the documented PPS allowance for that type. One packet per interval scores
   −0.00 and renders with a neutral face, so presence of the finding is the signal, not its magnitude.

6. **Check whether the packet rate is CPU-limited too**, and whether the packets are even yours. High
   `softirq` with concentrated network `interrupts` means per-packet processing is also costing CPU, so
   raising the allowance will not help — check `suspected_poll_starvation`. Then check `processes` and
   `linklocal_allowance_exceeded`: service meshes, health checks, and monitoring agents are high-PPS,
   low-byte by nature.

7. **Remediate**, per `EC2_NETWORK_PPS_ALLOWANCE_RECOMMENDATIONS`, cheapest first:
   - **Fix MTU/fragmentation** if the step-4 check found a mismatch. Free, and often decisive.
   - **Verify offloads are enabled** (TSO/GSO/GRO/LRO) so the stack and card handle large segments
     rather than wire-sized ones.
   - **Batch and coalesce** — send many logical items per packet instead of one. Pipeline requests, use
     bulk/multi-get APIs, buffer small writes. The highest-leverage application change.
   - **Enable jumbo frames (MTU 9001)** where the whole path supports it — up to ~6× fewer packets for
     the same bytes.
   - **Reduce protocol chattiness** — fewer round trips, longer-lived connections, cached lookups, less
     aggressive health-checking and retry policies.
   - **Tune the receive path** per the upstream ENA tuning guide (queue count, interrupt affinity,
     RPS/RFS) if per-packet CPU cost is co-limiting.
   - **Scale vertically or horizontally** if the packet rate is irreducible — as upstream puts it,
     *"Otherwise, also consider vertical or horizontal scaling."*

## Priority and execution risk

**Priority: P1 — Act now** when the exceedance is sustained (≥5 consecutive intervals) or pervasive
(≥25% of intervals), because the enforcement is measured rather than inferred. It rises to
**P0 — Emergency** when shaping is pervasive *and* the application is missing its SLO *and* either
`Underutilized CPU` fired (packet-rate-bound with idle CPU) or retransmits confirm an amplification
loop. It drops to **P3 — Monitor** for a single exceeding interval with no correlated excursion, and to
**P4 — Informational** when the value is fractional (true peak one packet) or when the packet rate is
attributable to a sidecar or service mesh rather than the workload. Note the asymmetry with the score:
the P4 case is precisely where the score reads **−256.00**, and the P3 case is where it can read
**−0.00**.

A priority quirk specific to this finding: the **PPS-only** case (bandwidth counters zero) carries the
*same* P1 but a *much cheaper* fix, so it deserves attention ahead of an equally-scored bandwidth
finding — fragmentation and batching cost nothing, a resize costs money and a maintenance window.

**Execution risk: R0 — Read-only** to resolve: the series, the per-interface split, the bandwidth
comparison, the mean-packet-size arithmetic, and the interrupt/`softirq` correlation are all reads.
Acting spans the range and the cheap options come first here more than in any other allowance finding.
**R1** for batching, coalescing, connection reuse, enabling offloads, or relaxing health-check and retry
policy — reversible, and the highest value per unit of risk. **R2 — MTU change**, because jumbo frames
must be supported by *every* hop; a partial rollout causes silent black-holing or a fresh round of
fragmentation, which is worse than the original problem. **R2** also for scaling out or rebalancing
behind a load balancer. **R3 — Resize** for an instance change (stop/start or replacement,
instance-store data moves, CPU generation may change). **R3** as well for receive-path tuning such as
interrupt affinity and RPS/RFS, since a bad affinity map can degrade throughput broadly. **Do not
inherit the R0 of the reading into the MTU change or the resize.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `pps_allowance_exceeded` interval delta, on any series including the
auto-generated `average`, was `> 0.0`.

```
STEP 0 — Is the reported VALUE trustworthy? Check this before reading anything into it.
  IF the value is FRACTIONAL (e.g. 0.50, 0.33)
  THEN → the auto-generated `average` series out-scored every real interface. Brute force
         over 1,596 multi-ENI combinations puts this artifact at a true per-interface peak
         of EXACTLY 1 packet, so the event is a ONE-PACKET microburst reported with a
         -256.00 score -- the mildest reading this rule can produce (P4, R0)
       → verify: read the per-interface series directly; the peak must be 1
  IF `total_resets` or `interface_down` is non-zero
  THEN → the ENA driver reset mid-run. A counter DECREASE is dropped entirely
         (time_series_data_processor.rs:202-:214) while the baseline still advances, so
         events between those snapshots are LOST. Every total below is a lower bound
         (P2, R0)
  IF the series has fewer than 4 points
  THEN → the first point is a structural zero, so 2-3 snapshots cover 1-2 real intervals.
         Neither rate nor duration is establishable. Re-record with `--period 300` (P2, R0)
       → verify: series length minus 1 equals the number of intervals actually covered
  OTHERWISE
  THEN → the value is a genuine worst-interval delta. Continue (P2, R0)

STEP 1 — The routing question. Are the BANDWIDTH counters also non-zero?
         This decides whether the fix is free or expensive.
  IF `bw_in_allowance_exceeded` and `bw_out_allowance_exceeded` are BOTH zero
  THEN → the SMALL-PACKET case, exactly what upstream describes
         (optimization-guides.ts:125). You are far from the byte ceiling and exhausting the
         per-packet budget. A resize is the WRONG answer here. Go to STEP 2 (P1, R0)
  IF either bandwidth counter is also non-zero
  THEN → the instance is undersized overall, not small-packet-bound. Both ceilings fall to
         one resize. Skip to STEP 5 and use the bandwidth playbooks for sizing (P1, R0)

STEP 2 — Mean packet size, and which DIRECTION. The allowance is bidirectional, so the
         counter itself cannot tell you.
  IF mean packet size (`tx_bytes`/`tx_cnt`, `rx_bytes`/`rx_cnt`, summed PER QUEUE) is far
     below the interface MTU
  THEN → confirmed small-packet traffic, and the direction with the higher `*_cnt` is the
         one to fix. An elevated `rx_copybreak_pkt` corroborates it from a counter unrelated
         to the allowance. Go to STEP 3 (P1, R0)
  IF mean packet size is CLOSE to the MTU yet PPS is still exceeded with bandwidth zero
  THEN → the packet rate is irreducible at this payload size: neither batching nor jumbo
         frames will help. The lever is instance selection or horizontal scale. Skip to
         STEP 5 (P1, R0)
       → verify: measured packet rate against the documented PPS allowance for the instance
         type; the ratio should be near or above 1

STEP 3 — Fragmentation first. This is the free fix and upstream names it explicitly.
  IF the interface MTU and the path MTU disagree, or IP fragmentation is observable
  THEN → each logical message is being split into several packets, multiplying PPS at
         IDENTICAL byte volume -- which is why the traffic looks unchanged while PPS
         doubles. A configuration fix, not a code change (P1, R1)
       → verify: after the MTU alignment, `tx_cnt`/`rx_cnt` fall while `tx_bytes`/`rx_bytes`
         are UNCHANGED. Bytes moving too means you changed the workload, not the framing
  IF offloads (TSO/GSO/GRO/LRO) are disabled
  THEN → the stack is handling wire-sized segments individually, inflating both PPS and CPU.
         Re-enable them before anything structural (P1, R1)
       → verify: `tx_cnt` per byte sent falls, and `softirq` falls with it
  IF the whole path supports MTU 9001 and is currently at 1500
  THEN → jumbo frames give up to ~6x fewer packets for the same bytes. But EVERY hop must
         support it: a partial rollout black-holes traffic or re-introduces fragmentation,
         which is worse than the original problem (P1, R2)
       → verify: end-to-end reachability at full frame size BEFORE relying on it, then
         confirm `tx_cnt` fell without a rise in retransmits

STEP 4 — Application-level packet reduction, once framing is right.
  IF the protocol sends one logical item per packet
  THEN → batch and coalesce: pipeline requests, use bulk/multi-get APIs, buffer small
         writes. The highest-leverage application change available to this finding
         (P1, R1)
       → verify: `tx_cnt` falls proportionally to the batch factor while `tx_bytes` stays
         roughly flat; if bytes fell too, you dropped work rather than batching it
  IF health checks, retries, or short-lived connections dominate the packet count
  THEN → longer-lived connections, less aggressive health-check intervals, backoff on
         retries. Connection setup and teardown are pure PPS cost at near-zero bytes
         (P2, R1)
       → verify: `netstat` connection-establishment counters fall alongside `tx_cnt`
  IF `linklocal_allowance_exceeded` also fired
  THEN → part of the packet rate is DNS/IMDS/time-sync chatter against a SEPARATE
         allowance. Fix it there -- caching and IMDS token reuse -- and re-measure this
         counter (P2, R1)
       → verify: after the caching change, both counters fall; only one falling means the
         two rates were independent

STEP 5 — Is the ceiling the real limit, or is the receive path CPU-bound?
  IF `softirq` is high AND network `interrupts` concentrate on a few CPUs
  THEN → per-packet processing is co-limiting. Raising the allowance by resizing will NOT
         help if the receive path saturates first. Tune queue count, interrupt affinity,
         RPS/RFS -- but a bad affinity map degrades throughput broadly (P1, R3)
       → verify: after the tuning, `softirq` spreads across CPUs and `suspected_poll_
         starvation` falls. If PPS shaping persists unchanged, the allowance was the real
         limit after all -- two mechanisms, not one
  IF the packet rate is irreducible and the receive path is healthy
  THEN → scale UP (R3: stop/start or replacement, instance-store data moves, CPU generation
         may change) or scale OUT behind a load balancer (P1, R3)
       → verify: after the change, re-record and confirm ZERO exceeding intervals at the
         same offered load. Nonzero means the new size is still short

STEP 6 — Whose packets are they, and did anything actually suffer?
  IF a service mesh, sidecar, monitoring agent, or health-check daemon dominates `processes`
  THEN → high-PPS/low-byte by nature. Reduce its rate or move it; cheaper than resizing and
         it leaves the serving path untouched (P2, R1)
       → verify: re-record with the agent quiesced; the exceeding intervals should vanish
  IF `netstat` retransmits rise in step with the exceeding intervals
  THEN → amplification: recovery traffic is small-packet-heavy, so drops beget more packets.
         Reducing packet rate breaks the loop; more allowance alone may not (P1, R1)
       → verify: retransmits and exceeding intervals fall together after the packet-rate
         reduction
  IF exceeding intervals do NOT align with any latency or error excursion
  THEN → enforcement happened but nothing observable suffered. Record it and move on; a
         Critical score is not by itself a business case (P3, R0)

STEP 7 — What survives?
  VALID      : that the Nitro card queued or dropped packets against the BIDIRECTIONAL PPS
               ceiling -- hardware enforcement, not inference; the exceeding-interval COUNT,
               the peak per-second rate, the run TOTAL as a sum of the series, the longest
               streak; and the small-packet diagnosis when both bandwidth counters are zero
  CAUTION    : any total on a run with `total_resets` non-zero (lower bound only); a
               sustained/pervasive verdict on <=10 intervals; and a mean-packet-size figure
               derived from a single queue rather than the per-queue sum
  CONFOUNDED : any AVERAGE over the raw series, diluted by (n-1)/n by the forced first zero;
               the reported value when FRACTIONAL, which is a multi-ENI mean hiding a
               one-packet peak; and any attempt to split THIS counter by direction -- the
               allowance is bidirectional, so direction comes only from `tx_cnt` vs `rx_cnt`
  VOID       : any RANKING of this finding by score -- the formula is non-monotonic in
               [1.0, 2.0), -256.00 has two disjoint preimages, and a one-packet interval
               scores -0.00 and renders NEUTRAL mid-list; and any conclusion that the
               network is healthy because bandwidth is well under its ceiling, which is
               exactly the case this rule exists to catch

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:205).
         Absence proves nothing about the allowance (P3, R0)
  IF `tx_cnt`/`rx_cnt` or `tx_bytes`/`rx_bytes` are unavailable
  THEN → mean packet size cannot be derived, so the small-packet diagnosis cannot be
         confirmed and STEP 3-4 are guesses. The STEP 1 routing still stands (P2, R0)
  IF the finding did NOT fire and the question was "am I packet-rate-limited?"
  THEN → absence is weak evidence at the default `--period 10`: the first point is a
         structural zero, so ~9 real intervals were observed. Re-record with
         `--period 300` before concluding health (P3, R0)
```

## Runtime-specific consequences

The allowance is enforced below the OS, but per-packet cost is paid *in* the OS, so the runtime matters
more here than for the bandwidth findings.

- **Any TCP workload.** Congestion control reacts to the drop, not the application. Because ACKs and
  retransmissions are themselves small packets, TCP recovery consumes the very budget that is exhausted
  — the amplification is structural, not incidental.
- **UDP workloads.** No backoff and no retransmission, so shaping is silent loss. High-rate UDP
  (telemetry, DNS, game traffic) is the archetypal PPS-bound case and drops map directly to lost work.
- **Java.** Small-write patterns are easy to create accidentally: an unbuffered `OutputStream`, or
  per-object socket writes, emit one packet per write. `java_profile` showing many short socket writes is
  the signature, and buffering is a one-line fix with a large PPS effect.
- **gRPC / HTTP/2 meshes.** Multiplexing over one connection *helps* PPS; per-RPC connections and
  aggressive health checks *hurt* it. A sidecar proxy doubles the packet count for the same logical
  traffic, since every packet is received and re-sent on the same instance.
- **Containers and multi-ENI setups.** The allowance belongs to the **instance**, so containers sharing
  one ENI compete for one bidirectional packet budget with no per-container accounting, and adding an
  interface does **not** add PPS allowance.
- **DNS-heavy and IMDS-heavy code paths.** These consume the *link-local* allowance too; a client library
  that re-fetches credentials or re-resolves a name per request shows up in both.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in threshold.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container
  with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot fire.
- **The PPS allowance is a property of instance type and size, not of the CPU.** A Graviton migration
  does not change this ceiling — but it *can* change how much CPU the per-packet work costs.
- **Per-packet processing cost is where architecture does matter.** PPS work is dominated by cache
  behaviour and interrupt handling, so core count and per-core throughput determine whether the receive
  path saturates before the allowance does. `num_of_active_io_queues` typically scales with vCPU count,
  so a smaller instance has both a lower ceiling and less parallelism to reach it. `.metal` and the
  largest family sizes give the full non-shared allowance.
- **ENA Express (SRD)** changes single-flow throughput and tail latency but **not** the PPS allowance.
  SRD adds header overhead, so it slightly *reduces* payload per packet — it is not a PPS remedy.

## Verification

The falsifiable claim is *the instance's bidirectional packet-rate ceiling was reached for this fraction
of the run, and sending fewer, larger packets removes the shaping*. Verify in that order.

1. **Confirm the value is trustworthy.** A fractional reading means the true per-interface peak was one
   packet; and `total_resets`, `interface_down`, `interface_up` must all be zero for the series to be
   continuous.
2. **Run the routing check.** Are `bw_in_allowance_exceeded` and `bw_out_allowance_exceeded` both zero?
   This single comparison decides whether the remediation is free or costs a resize.
3. **Quantify rate and duration.** `tools/aperf_ena_allowance.py --metric pps_allowance_exceeded
   --series <deltas>` — exceeding count, peak rate, total, sustained/pervasive verdict. Check the score
   against `|score| / 256 + 1` and expect the −256.00 ambiguity.
4. **Derive mean packet size from the per-queue sums** and record which direction dominates. This is the
   number the whole small-packet argument rests on; a single-queue figure will mislead.
5. **Predict the framing fix quantitatively.** For an MTU alignment or a jumbo-frame rollout, state the
   expected packet-count reduction *before* changing anything, then check that `tx_cnt`/`rx_cnt` fell by
   about that factor while `tx_bytes`/`rx_bytes` stayed flat. Bytes moving too means the workload changed,
   not the framing.
6. **Separate the CPU limit from the allowance limit.** If `softirq` is high and interrupts concentrate,
   predict that affinity tuning moves `suspected_poll_starvation` but leaves `pps_allowance_exceeded`
   unchanged. If both move, they were one mechanism and the attribution was wrong.
7. **Re-record with `--period 300`**, since the default `--period 10` observes roughly 9 real intervals
   and cannot separate sustained shaping from a run that ended mid-burst. Then **after remediation,
   predict zero**: at the same offered load the exceeding-interval count must be **zero**, not lower.

## Do not

- **Do not dismiss this finding because the score is small or zero.** A one-packet interval scores −0.00
  and renders with a neutral face, greyed out, mid-list. The rule is `Critical` and the enforcement is
  measured.
- **Do not rank this finding by score, or compare its score against other findings.** The formula is
  non-monotonic in [1.0, 2.0), −256.00 is produced both by any sub-unit value and by exactly 2.0, and
  `Critical` times the delta multiplier produces values orders of magnitude larger than any other rule.
- **Do not read the value as a run total.** It is a per-interval delta; sum the series for the total.
- **Do not read a fractional value as a real packet count.** It is a multi-ENI mean that out-scored the
  real series, so the true per-interface peak was exactly one packet.
- **Do not average anything here.** The forced first zero dilutes an average over the raw series by
  (n−1)/n, and the `average` series is itself a mean across series (`ena_stat.rs:315`).
- **Do not look for an inbound/outbound split of this counter.** The allowance is **bidirectional**;
  direction comes only from `tx_cnt` versus `rx_cnt`.
- **Do not conclude the network is fine because bandwidth is well under the limit.** That is precisely
  the small-packet case this rule exists to catch — and the case with the cheapest fixes.
- **Do not scale up before checking MTU and fragmentation.** A path MTU mismatch inflates PPS at
  constant byte volume and costs nothing to fix.
- **Do not roll out jumbo frames partially.** Every hop must support MTU 9001; a partial rollout
  black-holes traffic or re-introduces the fragmentation you meant to remove.
- **Do not chase EFA because the message says "EFA".** All five allowance messages name the wrong
  device; this is an ENA metric read by the `ethtool` ioctl.
- **Do not assume scaling up fixes a PPS problem that is really CPU-bound.** Check `softirq`,
  `interrupts`, `suspected_poll_starvation` first.
- **Do not attach another ENI or enable ENA Express expecting more PPS allowance.** The ceiling is per
  instance, and SRD changes flow throughput and tail latency rather than the packet ceiling — its header
  overhead slightly *reduces* payload per packet.
- **Do not treat absence on a short run as proof of health.** The first point is a structural zero, so
  the default `--period 10` observes about 9 real intervals.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:32`–`:38` (`Comparator::Greater`, threshold `0.0`,
  `Score::Critical`). The `"EFA"` in the message at `:37` is an upstream defect. Template:
  `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates every series
  including the auto-generated aggregate, keeping the largest `|score|` with `>=`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`–`:176` — the `threshold == 0.0`
  branch, flat below 1.0 and linear above.
- Delta processing: `add_accumulative_data_point` (`src/data/ena_stat.rs:343`) and
  `get_delta_and_set_previous_value` (`src/data/common/time_series_data_processor.rs:189`–`:224`) — the
  forced first zero at `:218`/`:73`, and the dropped decrease at `:202`–`:214`.
- Average aggregate and its single-ENI suppression: `src/data/ena_stat.rs:315`;
  `src/data/common/time_series_data_processor.rs:249`–`:256` and `:315`–`:319`.
- Metric description: `data-descriptions.ts:3831` — the small-mean-packet-size explanation is upstream's.
- Frontend rendering of a zero score: `AnalyticalFindings.tsx:35` (`getFindingColor`), `:44`–`:52`
  (`FindingIcon`), and the ascending score sort at `src/report_frontend/src/utils/analytics.tsx:40`.
- Collection: `Ethtool::new` filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL`, `:31`–`:33`.
- Upstream guide: `EC2_NETWORK_PPS_ALLOWANCE_RECOMMENDATIONS`,
  `src/report_frontend/src/definitions/optimization-guides.ts:125`–`:132` — the source of the
  "PPS-only breach ⇒ small packets / fragments" diagnostic.
- Quantifier: [`../tools/aperf_ena_allowance.py`](../tools/aperf_ena_allowance.py)
  `--metric pps_allowance_exceeded`; `aggregate_masks_the_peak()` for the fractional-value artifact,
  re-derived over 2,044 combinations in `tools/test_aperf_ena_allowance.py`.
- [Maximize ENA network performance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-nitro-perf.html#ena-nitro-perf-maximize)
- [Monitor network performance for your EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/monitoring-network-performance-ena.html)
- Related playbooks: `inbound-bandwidth-exceeded-instance-allowance.md`,
  `outbound-bandwidth-exceeded-instance-allowance.md` (the STEP 1 routing partners),
  `link-local-service-exceeded-instance-allowance.md` (DNS/IMDS chatter on a separate allowance),
  `underutilized-cpu.md` (the packet-rate-bound signature).
