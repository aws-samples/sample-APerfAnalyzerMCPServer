---
rule_name: Disabled ENA Express with Previously Enabled UDP
data_type: ena_stat
data_key: ena_srd_mode
template: time_series_data_point_threshold
condition: "any(ena_srd_mode) == 2.0"
base_score: Bad
score_sign: negative
requires_comparison: false
aperf_message: "ENA Express is disabled, but it was previously enabled with UDP support. Verify if this is expected."
source: src/analytics/rules/ena_stat.rs:72
---

# Disabled ENA Express with Previously Enabled UDP

## What fired

**At least one** data point of `ena_srd_mode` was **equal to 2.0** — read literally, "ENA Express off,
UDP on", a state the metric description says "only happens after disabling the previously enabled ENA
Express with UDP". Base score `Bad` (**−2**), twice the two `Concerning` mode rules; single-run,
`Comparator::Equal` (`ena_stat.rs:72`), so with an `Equal` comparator the score is **always exactly
−2.00**.

**This rule is effectively unreachable on aperf 1.3.0, and when it does fire it means something other
than what it says.** Read the next section first.

## The processing defect — verified by running the engine

`ena_srd_mode` is a **mode enum** (0/1/2/3), but every `ena_stat` metric is passed through
`add_accumulative_data_point` at `src/data/ena_stat.rs:343`, which stores **per-interval differences**
and forces the first sample to 0 (`ignore_first_accumulative_value: true`,
`time_series_data_processor.rs:73`; the only opt-out in the tree, `use_first_accumulative_value()`, is
called once, from `perf_stat.rs:1295`). A mode does not accumulate, so a device sitting in mode 2 reports
raw `2, 2, 2, …` and aperf stores `[0.0, 0.0, 0.0, …]` — which fires **`Disabled ENA Express`** (== 0),
not this rule.

Verified: with a constant `ena_srd_mode = 3` the engine produced the series `[0.0, 0.0]` and emitted
**`Disabled ENA Express`** with score `−1.0` and the description `is 0 (equal to the threshold of 0)`.
The mode-specific rules never see raw values.

What *can* make this rule fire is a **delta that happens to equal 2** — the mode increasing by exactly
2 during the recording:

| transition during the run | delta | rule that fires | what it actually means |
|---|---|---|---|
| 0 → 2 | +2 | **this rule** | UDP-on/Express-off appeared from a fully-off state — unusual, worth investigating |
| 1 → 3 | +2 | **this rule** | **UDP support was enabled** while ENA Express stayed on — i.e. the configuration *improved* to the ideal state |
| any decrease (3 → 1, 2 → 0, 3 → 0) | **no data point at all** | **none** | **the actual disabling transitions are invisible** |

That last row is stronger than "skipped". `get_delta_and_set_previous_value`
(`time_series_data_processor.rs:189`–`:224`) sees `prev_value > data_value`, emits a `debug!`, increments
a per-key counter, and `return None` at `:214`; `add_data_point_impl` returns early at `:150`, so **no
series entry is created** — a gap, not a zero. **Every transition that would genuinely indicate "ENA
Express was disabled" is a decrease, and decreases never reach the series.** So the rule cannot detect the
event it is named for under either reading, and when it fires the likeliest event is 1 → 3 — the opposite
of what the message says.

There is exactly one in-report trace of a decrease: at the end of processing aperf emits a single
`warn!` (`:297`–`:302`):

```
<data_name>.<metric>.<series>: skipped N data points due to unexpected decrease of accumulative data.
```

**A skipped decrease on `ena_srd_mode` is the only evidence aperf can give you that ENA Express was
turned off during the run** — the very event this rule exists to report, findable only in the log.

Two further observable artifacts. **A constant mode renders as exactly two data points**, because
`compress_all_zero_time_series_metric` (`:410`–`:427`) compresses every series to its first and last point
when the metric's min and max are both 0.0 — so a two-point `ena_srd_mode` chart proves the mode never
changed and this rule could not have fired. And **the `average` series may not exist**: `ena_stat`
aggregates with `time_series_data_processor_with_average_aggregate` (`ena_stat.rs:315`), but `:312`–`:319`
removes the auto-generated aggregate at exactly two series, so the cross-interface mean needs **≥3**.

**Correct interpretation of this finding on 1.3.0: the ENA Express mode increased by 2 during the
recording.** Verify the real mode out of band before reporting anything. The rest of this playbook covers
the question the rule *intended* to ask, because mode 2 is a genuinely odd state worth understanding.

## Reasoning

`ena_srd_mode` "Indicates whether ENA Express is configured. 0 = ENA Express off, UDP off; 1 = ENA
Express on, UDP off; 2 = ENA Express off, UDP on (only happens after disabling the previously enabled
ENA Express with UDP); 3 = ENA Express on, UDP on." (`data-descriptions.ts:3859`, `desired: "fixed"`)

Mode 2 is the only mode the description explains historically rather than functionally, and that is the
whole point of the rule. The bit pattern reads naturally — bit 0 = ENA Express on/off, bit 1 = UDP support
on/off — so mode 2 is **"UDP support flag set, ENA Express itself off"**, a combination with no useful
effect, since UDP acceleration cannot happen if SRD is not in use at all. It is a residue: someone had
mode 3 and turned ENA Express off, leaving the UDP flag behind.

**Why that residue deserves a `Bad` (−2) rather than `Concerning` (−1):**

1. **It is a regression, not a default.** Mode 0 can be the untouched factory state; mode 2 cannot. It
   proves ENA Express *was* configured, with UDP support, and then deliberately switched off.
2. **It is a state nobody chooses** — the fingerprint of an incomplete change, a partial rollback,
   configuration-management drift, or an automated remediation that disabled the wrong thing.
3. **The workload was previously judged to need SRD *and* UDP acceleration.** Whoever enabled mode 3
   believed it was latency-sensitive and UDP-heavy, so an undocumented rollback is likely an unintended
   regression on exactly the traffic that most needed the acceleration.

Plausible causes when the device really is in mode 2:

- **An intentional rollback** — disabled deliberately (the 8900 MTU cap, SRD resource exhaustion,
  cross-AZ traffic, or reordering in a UDP application) with the UDP flag simply left set. Benign, and the
  rule's "Verify if this is expected" is the right question.
- **A partially applied configuration change** — automation that disabled ENA Express without completing
  the intended change, or applied to the wrong ENI.
- **An AMI or launch-template mismatch** — a template carrying the UDP setting applied where ENA Express
  itself was not enabled.
- **Instance or ENI replacement** — the interface was recreated and only part of the configuration
  reapplied.
- **A troubleshooting change never reverted.**

**And aperf offers no guidance on any of it.** `optimization-guides.ts` contains only the four EC2
network *allowance* guides (`:117`, `:125`, `:134`, `:146`) — there is **no ENA Express or SRD guide**, so
the remediation below comes from the metric descriptions and AWS documentation.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"equal to"`:

```
At least one data point in aperf_record is 2 (equal to the threshold of 2).
```

**The value carries no information** — with `Equal` it is always the threshold. And per the defect above,
that `2` is a **delta between consecutive mode samples**, not the mode itself. Score math —
`compute_finding_score(2.0, 2.0, −2)`, general branch: `delta = 2/2 = 1`, so `score = 1 × −2`:

| value | score | note |
|---|---|---|
| 2.0 (the only possible value) | **−2.00** | exactly twice the `Disabled ENA Express` score |

**Always −2.00.** Nothing to rank. Because findings sort ascending by score (`analytics.tsx:40`) it sorts
above the other mode findings — the only relative priority the mode family conveys.

## Interpretation

**First, resolve what the firing means**, since it reports a +2 transition rather than a state:

| Verified real mode at end of run | Reading |
|---|---|
| **3** — on, UDP on | The transition was 1 → 3: **UDP support was enabled**, moving to the ideal configuration. This negative finding is reporting an improvement — the exact inverse of its message |
| **2** — off, UDP on | The transition was 0 → 2. The message's conclusion is right about the state; investigate why the UDP flag is set with Express off |
| **1** or **0** | Inconsistent with a +2 delta; suspect an interface flap or counter discontinuity. Check `total_resets` / `interface_down` / `interface_up` |

Either way the recording **spans a configuration change**, so metrics before and after the step are not
comparable — flag that regardless of the mode question, since it affects every other finding in the report.

Once the real mode is known to be 2, the question is *why*, and whether ENA Express should be back on:

| Situation | Reading |
|---|---|
| Rollback is documented and deliberate | Benign. Clear the UDP flag for hygiene; record the decision |
| Nobody knows why ENA Express is off | **The case that matters.** Someone previously judged this workload to need SRD *with* UDP; that benefit is currently lost. Treat as a suspected regression |
| It was disabled because of the **8900 MTU cap** | Legitimate. Reconcile the MTU deliberately if re-enabling |
| It was disabled because of **SRD resource exhaustion** | Legitimate — see `High SRD Resource Utilization`. Fix capacity before re-enabling |
| It was disabled because a **UDP application saw reordering** | Legitimate for UDP; consider re-enabling ENA Express **without** UDP support (mode 1) to keep the TCP benefit |
| Traffic moved **cross-AZ** | ENA Express requires both endpoints in the same AZ; disabling was correct |
| Peer instances no longer have it enabled | Both ends are required; disabling matches reality |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Disabled ENA Express` **also fired** | **Expected on 1.3.0** — the flat-delta series contains zeros, so the == 0 rule fires alongside any transition rule. An artifact, not a contradiction |
| `ena_srd_tx_pkts` / `ena_srd_rx_pkts` **non-zero** | **SRD is transmitting, so ENA Express is on** — the device is not in mode 2. The quickest in-report refutation |
| `ena_srd_tx_pkts` / `ena_srd_rx_pkts` **zero** | Consistent with ENA Express being off. Corroborates a real mode 2 |
| `High SRD Resource Utilization` or `Low SRD Usage Rate` fired | Both require active SRD, so they contradict mode 2 — and if SRD was previously resource-starved, that may be *why* it was disabled |
| A skipped-decrease `warn!` on `ena_srd_mode` in the run log | **The disabling happened during this recording.** The only evidence aperf can produce for it |
| Tail-latency regression in application metrics since a known date | **The corroboration that turns this into an actionable regression.** Correlate with when ENA Express was disabled |
| Any allowance finding | Separate ceilings; SRD does not raise them. Fix those first |
| UDP traffic significant (measured **on the instance** — aperf collects no UDP counters) | Confirms the workload has the UDP traffic the previous configuration was accelerating — raises the cost of the rollback |

**Known false positives:**

- **The rule fires on a +2 delta, not on mode 2.** On aperf 1.3.0 this is the *only* way it can fire,
  and the most likely underlying event is **1 → 3**, i.e. an improvement.
- **The actual disabling transitions are invisible.** Decreases produce no data point at all, so this
  rule cannot detect ENA Express being turned off — the event it is named for.
- **Multi-interface averaging**, but only with **≥3 series**: the rule scans the auto-generated `average`
  series, so a mean across interfaces can land on exactly 2.0 with no single interface stepping by 2.
  With exactly two series the aggregate is removed (`:312`–`:319`).
- **Interface flap or counter reset** producing a spurious *increase*. Check `total_resets` /
  `interface_down` / `interface_up`.
- **A documented, intentional rollback.** Real state, expected. The rule's own wording — "Verify if this
  is expected" — anticipates this.
- **ENA Express is unsupported or inapplicable** (cross-AZ traffic, unsupported peers), making the
  residual UDP flag cosmetic.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `ena_srd_tx_pkts`, `ena_srd_rx_pkts` | `ena_stat` | **Do this first — the fastest refutation.** Non-zero means SRD is active, so the device is not in mode 2. Read manually; no rule fires on these |
| `ena_srd_resource_utilization` | `ena_stat` | Zero corroborates ENA Express being off; previously-high values may explain the rollback. See `High SRD Resource Utilization` |
| `ena_srd_eligible_tx_pkts` vs `ena_srd_tx_pkts` | `ena_stat` | Historical fallback rate — another plausible rollback motive. See `Low SRD Usage Rate` |
| `ena_srd_mode` series, and its **point count** | `ena_stat` | **Deltified** — locate the +2 step to time the configuration change; a two-point chart means no step happened |
| The aperf `warn!` log for skipped decreases | run log | **The only in-report evidence that the mode FELL** — i.e. that ENA Express was disabled during this recording, the event the rule is named for |
| `total_resets`, `interface_down`, `interface_up` | `ena_stat` | Whether the delta is a real transition or a counter discontinuity. "A reset reinitializes the driver and temporarily disrupts network connectivity" |
| UDP packet and error counters | **not collected** | How much UDP traffic the disabled configuration was accelerating — the cost of the rollback. **aperf reads only `/proc/net/netstat` (`netstat.rs:33`), which has `TcpExt:` and `IpExt:` and no UDP section**, and `/proc/net/snmp` is read by no collector. Measure on the instance (`ss -su`, `nstat -z \| grep -i udp`, `/proc/net/snmp`) |
| TCP retransmits, out-of-order counters | `netstat` | Path congestion that SRD's multipath routing was mitigating |
| The four allowance counters | `ena_stat` | Separate ceilings, unaffected by SRD |
| `tx_cnt`, `rx_cnt`, mean packet size | `ena_stat` | Traffic profile; feeds the MTU and resource considerations. Both are **per queue** (`ena_stat.rs:327`–`:341`), so sum the queue series |
| Instance type and size | `systeminfo` | ENA Express support and the same-AZ constraint context |
| MTU configuration | `systeminfo` / `sysctl` | The 8900 SRD cap is a common reason ENA Express gets disabled. **No analytical rules for `sysctl` — read manually** |
| `idle`, `aggregate` | `cpu_utilization` | Whether the workload is network-bound. See `Underutilized CPU` |
| Out of band: EC2 API / `ethtool` on the ENI, plus CloudTrail or config history | — | **The authoritative mode, and *when and by whom* it was changed.** aperf cannot answer either on 1.3.0 |

## Guidance

Ordered. **Step 1 is establishing what the firing actually means** — very likely the opposite of the
message.

1. **Treat this as "the ENA Express mode increased by 2 during the recording", not as a mode reading.** The
   most likely underlying transition is **1 → 3**, i.e. UDP support being *enabled* — an improvement.
   Locate the step in the `ena_srd_mode` series to time it.

2. **Refute or confirm from inside the report.** Read `ena_srd_tx_pkts` and `ena_srd_rx_pkts`. Non-zero
   means SRD is active, so the device is **not** in mode 2 and the message's conclusion is wrong. Zero
   is consistent with ENA Express being off.

3. **Verify the real mode out of band** (EC2 API or `ethtool` on the ENI). aperf cannot answer this on
   1.3.0. While you are in the run log, grep for the skipped-decrease `warn!` on `ena_srd_mode` — it is
   the only evidence aperf can give that the mode *fell* during the recording, which is exactly the
   event this rule is named for and structurally cannot report.

4. **Flag the configuration change itself.** A mode step mid-recording means metrics either side are not
   comparable, which affects every other finding in the report — worth stating even if the mode question
   turns out benign.

5. **Ignore the score.** Always exactly −2.00.

6. **If the device really is in mode 2, find out why ENA Express was disabled — this is the decisive
   step.** Mode 2 proves it was once enabled *with UDP support*, so someone judged this workload to need
   both. Check change history (CloudTrail, configuration management, launch templates, runbooks):
   - **Documented rollback** ⇒ benign; clear the residual UDP flag for hygiene and record the decision.
   - **No known reason** ⇒ treat as a suspected performance regression on latency-sensitive UDP traffic,
     and correlate with application tail-latency history.
   - **Partial automation run / wrong ENI / template mismatch** ⇒ a configuration-drift bug; fix the
     automation, not just the instance.

7. **Quantify what was lost.** Read the `netstat` TCP retransmit/out-of-order counters, and measure UDP
   **on the instance** — aperf collects no UDP counters (only `/proc/net/netstat`, which has no UDP
   section), so use `ss -su`, `nstat` or `/proc/net/snmp`. Substantial UDP traffic plus path congestion
   means the disabled configuration was doing real work.

8. **Decide the target state deliberately, and check the constraints before re-enabling:**
   - Instance-type support; **both endpoints in the same Availability Zone**; peers that also have it
     enabled. Any "no" and mode 2 is simply stale — clear the flag and move on.
   - **8900 MTU cap** — reconcile a 9001 MTU explicitly, since oversized packets fall back to standard
     ENA. A frequent reason ENA Express gets disabled in the first place.
   - **SRD resource headroom** — if `High SRD Resource Utilization` or `Low SRD Usage Rate` were part of
     the original problem, fix capacity before re-enabling. See those playbooks, and note that a *low*
     utilization reading is not headroom: the gauge is deltified, so a steadily saturated card reads
     near zero and never fires its rule.
   - **Reordering tolerance for UDP** — if a UDP application was the reason for the rollback, consider
     re-enabling ENA Express **without** UDP support (mode 1) to keep the TCP benefit without the
     reordering exposure.
   - Whatever you choose, **land on a coherent mode (0, 1, or 3)** rather than leaving 2 in place.

9. **Measure tail latency after any change**, not the mean — that is where SRD's benefit appears.

## Priority and execution risk

**Priority: P2 — Plan** whenever this finding is present, and for a reason unrelated to its message: on
1.3.0 presence means the mode stepped by **+2 during the recording**, so the run spans a configuration
change and every before/after comparison in the report crosses a data-path boundary. That invalidation is
the finding's real content, and it holds even in the likeliest case — a `1 → 3` step, an *improvement*
reported as a `Bad` finding. It rises to **P1 — Act now** in the one case that justifies the `Bad` score:
the mode is confirmed **2** out of band, **no one can explain why ENA Express was disabled**, and
application tail latency regressed around the same time — an undocumented regression on traffic someone
previously judged to need acceleration, with the ENI in a state nobody would choose. It stays **P2** when
the mode is confirmed 2 with a documented rollback (the residual flag is worth clearing for hygiene and to
stop this finding recurring), drops to **P3 — Monitor** when the rollback reason is still live (MTU cap,
SRD resource exhaustion, UDP reordering) because re-enabling would reintroduce the original problem, and
**P4 — Informational** when ENA Express is unsupported or inapplicable (cross-AZ, uncontrolled peers),
making the flag cosmetic.

**Execution risk: R0 — Read-only** for the whole diagnosis: the SRD-counter refutation, locating the step,
the point-count check, the out-of-band mode query, the run-log check for skipped decreases, and the change
history in CloudTrail or configuration management. Acting is where the risk is, and the range is wide.
**R1** for clearing the residual UDP flag on an ENI whose ENA Express is already off — no data-path change,
since UDP support does nothing without SRD — and for re-recording a run that does not straddle the step.
**R2 — re-enabling ENA Express**, on both endpoints, with the effective MTU capped at 8900 and SRD header
overhead reducing payload slightly; **R2** also for the accompanying MTU reconciliation, for re-enabling
UDP support (per-ENI, so it exposes multipath reordering to every UDP application on the instance), and for
fixing the automation or launch template that produced the drift, which changes the deployment path and so
is broader in blast radius than the instance in front of you. **R3** if the original rollback was caused by
SRD resource exhaustion and fixing it needs a resize or scale-out. **Do not inherit the R0 of the
investigation into the re-enablement.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `ena_srd_mode` interval delta, on any series, was `== 2.0` — which on
aperf 1.3.0 requires a mode *increase* of exactly 2 during the recording, not a steady state.

```
STEP 0 — Refute first. The counters settle this faster than anything else.
  IF `ena_srd_tx_pkts` or `ena_srd_rx_pkts` is NON-ZERO
  THEN → ENA Express is ON, so the device is NOT in mode 2 and the message's conclusion is
         wrong. The likeliest underlying event is a 1 -> 3 step: UDP support was ENABLED, an
         improvement reported as a Bad finding. Go to STEP 2 (P2, R0)
  IF `High SRD Resource Utilization` or `Low SRD Usage Rate` also fired
  THEN → both require ACTIVE SRD, so they contradict mode 2 outright. But note them: if SRD
         was resource-starved, that may be exactly WHY someone disabled it. Go to STEP 2
         (P2, R0)
  IF the `ena_srd_mode` chart shows exactly TWO data points
  THEN → contradiction: the all-zero compression fired
         (time_series_data_processor.rs:410-:427), which requires a CONSTANT mode, so no +2
         step occurred on a real series. The delta came from the aggregate. Go to STEP 1
         (P3, R0)
  OTHERWISE
  THEN → a mode increase of +2 plausibly occurred. Continue to STEP 1 (P2, R0)

STEP 1 — Is the +2 delta real, or an artifact of the pipeline?
  IF `total_resets`, `interface_down` or `interface_up` is non-zero
  THEN → the driver reset or the link flapped, so the counter baseline moved for reasons
         unrelated to configuration. "A reset reinitializes the driver and temporarily
         disrupts network connectivity" (P3, R0)
       → verify: confirm the current mode out of band; if it matches the pre-run mode, there
         was no configuration change at all
  IF the metric has THREE OR MORE series and only the `average` series shows the +2
  THEN → a cross-interface MEAN landed on 2.0 with no single interface stepping by 2. With
         exactly two series the aggregate is removed (:312-:319), so this needs >=3 (P3, R0)
       → verify: read each interface's series individually; at least one must step by +2
  OTHERWISE
  THEN → a genuine +2 step on a real interface. Continue to STEP 2 (P2, R0)

STEP 2 — WHICH transition was it? Two are possible and they are opposites.
  IF the mode is confirmed 3 at the end of the run
  THEN → the transition was 1 -> 3: UDP support was ENABLED and the configuration moved to the
         IDEAL state. This Bad finding is reporting an improvement. Read
         `ena-express-enabled-with-udp.md` for what mode 3 does and does not guarantee, then
         go to STEP 3 for the run-boundary problem (P2, R0)
  IF the mode is confirmed 2 at the end of the run
  THEN → the transition was 0 -> 2 and the message's conclusion about the STATE is right.
         Mode 2 is "UDP flag set, ENA Express off" — a residue nobody chooses. Continue to
         STEP 4 (P2, R0)
  IF the mode is confirmed 0 or 1
  THEN → inconsistent with a +2 increase. Go back to STEP 1; this is a discontinuity or an
         aggregate artifact (P3, R0)
  IF the run log carries "skipped N data points due to unexpected decrease of accumulative
     data" on `ena_srd_mode`
  THEN → the mode also FELL during this run — the disabling event this rule is NAMED for,
         which produces no data point at all (:214 returns None). This log line is the only
         evidence aperf can give you of it (P1, R0)
       → verify: the current mode out of band, and whether the disabling was intentional; an
         unplanned drop from mode 3 is a configuration regression

STEP 3 — The run spans a CONFIGURATION CHANGE. This is the finding's real content.
  IF the step lands in the middle of the run
  THEN → metrics before and after are NOT comparable, and that applies to every finding in the
         report, not just this one. The network data path changed underneath the measurement
         (P2, R1)
       → verify: re-record entirely after the change; then confirm `ena_srd_mode` is flat
         (two points after compression) in the new run
  IF the step lands in the first one or two intervals
  THEN → the change effectively preceded the workload, so the run is usable. Note the boundary
         and stop here unless the mode is 2 (P3, R0)

STEP 4 — Mode 2 confirmed. WHY was ENA Express disabled? This is the decisive question and
         aperf cannot answer any of it.
  IF the rollback is DOCUMENTED and deliberate
  THEN → benign. Clear the residual UDP flag so the ENI lands on a coherent mode 0 and this
         finding stops recurring; record the decision (P2, R1)
       → verify: `ena_srd_mode` reads 0 out of band afterwards, and no SRD counter moves
  IF NOBODY can explain why ENA Express is off
  THEN → the case that justifies the Bad score. Mode 2 PROVES it was once enabled with UDP
         support, so someone judged this workload to need both, and that benefit is currently
         lost. Treat as a suspected performance regression (P1, R0)
       → verify: correlate application tail-latency history against the change date in
         CloudTrail or config history; a regression at that date confirms the cost
  IF the cause was a partial automation run, the wrong ENI, or a template mismatch
  THEN → a configuration-DRIFT bug. Fixing the instance in front of you leaves the deployment
         path broken, so fix the automation too (P2, R2)
       → verify: re-run the automation against a test instance and confirm the resulting mode
         is the intended one, not 2
  OTHERWISE
  THEN → cause unknown but the rollback reason may still be live. Continue to STEP 5 (P3, R0)

STEP 5 — Is the original rollback reason STILL live? Re-enabling blindly reintroduces it.
  IF the interface MTU is 9001
  THEN → the 8900 SRD cap makes full-size frames fall back to standard ENA, and that is one of
         the commonest reasons ENA Express gets disabled in the first place. Reconcile the MTU
         before re-enabling, not after (P3, R2)
       → verify: after re-enabling, `ena_srd_tx_pkts` tracks `ena_srd_eligible_tx_pkts`
         closely; a persistent gap means the MTU is still wrong
  IF SRD resource exhaustion was the original problem
  THEN → the card's SRD pool is consumed by CONCURRENT CONNECTIONS, not bandwidth, so all four
         allowance counters can read zero while it saturates. Fix capacity first — and do not
         read a low `ena_srd_resource_utilization` as headroom, since the deltified gauge reads
         near zero when STEADILY saturated (P3, R3)
       → verify: after scaling, the eligible-vs-actual gap narrows; read
         `high-srd-resource-utilization.md` before trusting any low reading
  IF a UDP application saw REORDERING
  THEN → legitimate, and re-enabling with UDP support would repeat it. Re-enable ENA Express
         WITHOUT UDP support (mode 1) to keep the TCP benefit without exposing UDP to
         multipath spraying (P3, R2)
       → verify: application-level out-of-order metrics stay flat while TCP p99 improves
  IF the traffic is now CROSS-AZ, internet-facing, or the peers no longer have it enabled
  THEN → STOP. Disabling was correct and the UDP flag is merely stale. Clear it for hygiene
         and record that ENA Express is inapplicable. NO finding (P4, R1)

STEP 6 — Land on a coherent mode and measure the right thing.
  IF re-enabling ENA Express
  THEN → enable on BOTH endpoints in the same AZ, with the MTU reconciled, and decide UDP
         support separately. Never leave the ENI in mode 2 (P2, R2)
       → verify: tail latency p99 and p99.9 before and after — NOT the mean, which barely
         moves even when SRD is working, and is the usual reason the change gets judged a
         failure
  IF re-enabling UDP support as well
  THEN → the setting is per-ENI, so EVERY UDP application on the instance is exposed to
         multipath reordering, including ones not audited here (P2, R2)
       → verify: `processes` for UDP-owning processes first, then application-level ordering
         metrics after the change
  OTHERWISE
  THEN → target mode 0: clear the UDP flag and leave ENA Express off (P2, R1)
       → verify: `ena_srd_mode` reads 0 out of band, and this finding does not recur

STEP 7 — What survives?
  VALID      : that a +2 mode delta occurred, hence a configuration change during the run;
               that mode 2 is a state nobody chooses and PROVES ENA Express was once enabled
               with UDP support; the historical reading of the mode from the metric
               description; and the same-AZ, both-endpoints and 8900-MTU constraints
  CAUTION    : a +2 delta on the `average` series of >=3 interfaces, where no single interface
               stepped; a transition claimed on a run with `total_resets` non-zero; and any
               rollback motive inferred rather than found in change history
  CONFOUNDED : every metric in the run when the step lands mid-recording, since the data path
               changed underneath; any average over the `ena_srd_mode` series, diluted by the
               forced first zero; and a low `ena_srd_resource_utilization` read as headroom,
               since the deltified gauge reads near zero when steadily saturated
  VOID       : "the device is in mode 2" — the series is deltified, so the firing is a +2 step
               whose likeliest cause is 1 -> 3, an IMPROVEMENT; this rule as a detector of ENA
               Express being DISABLED, since every disabling transition is a decrease and
               decreases produce no data point at all; the score, a constant -2.00; and any
               UDP volume claim taken from `netstat`, which collects no UDP counters

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205);
         `lo`, `docker*`, `veth*`, `br-*` and `virbr*` are skipped, so a container with only
         virtual interfaces collects nothing (P4, R0)
  IF `ena_srd_*` metrics are absent while other `ena_stat` metrics are present
  THEN → the driver or instance type does not expose the SRD counters, so ENA Express is
         almost certainly unsupported here and mode 2 is impossible (P4, R0)
  IF the series has fewer than 3 points
  THEN → the first point is a structural zero, so 2 snapshots cover 1 real interval and the
         step cannot be located in time. Re-record with `--period 300` (P4, R0)
  IF no change history is available and the mode is 2
  THEN → the decisive question — why was it disabled — is unanswerable, so the finding cannot
         be closed either way. Record it as an open configuration question (P2, R0)
```

## Runtime-specific consequences

Mode 2 is a configuration residue, so no runtime behaves differently *because of the flag* — UDP support
does nothing while SRD is off. What differs is how much each runtime lost when ENA Express was disabled.

- **TCP workloads.** Lost the multipath benefit entirely: single-flow throughput back to one path, tail
  latency back to waiting on TCP recovery instead of routing around congestion. Nothing in the application
  changed, which is why the regression is easy to miss.
- **UDP workloads.** Lost the most, since mode 3 was accelerating them and mode 2 accelerates nothing.
  These justified enabling UDP support in the first place, so check their tail latency against the change
  date.
- **QUIC / HTTP-3 / gRPC-over-QUIC.** Entirely UDP-borne and reordering-tolerant by design — ideal mode-3
  candidates, and the strongest case for restoring it. Same for **real-time media and voice** where a
  jitter buffer already absorbs reordering; tail latency regressed while means look unchanged.
- **Java.** Nothing to reconfigure, but the regression is hard to see: a 50 ms GC pause swamps a network
  change of a few hundred microseconds, and JVM latency reports quote a mean beside the p99 that actually
  moved. Rule GC out with `java_profile` before attributing a regression to this rollback.
- **RPC meshes and sidecar proxies.** Every hop was its own SRD connection, so a mesh was both the biggest
  beneficiary of mode 3 and the fastest consumer of card SRD resources — making resource exhaustion a
  plausible original rollback motive worth checking before re-enabling.
- **Containers.** ENA Express is a property of the **ENI**, so the rollback removed it from every container
  at once and re-enabling returns it to all of them, including any UDP container with ordering assumptions.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in availability.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and the delta defect that
  makes this rule unreachable applies identically on both.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container
  with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot fire.
- **ENA Express support is a property of instance type and generation, not CPU architecture.** A Graviton
  migration neither grants nor removes it — but an **instance-type change is itself a plausible cause of
  mode 2**, if the new type or a recreated ENI received only part of the previous configuration. And mode 2
  is unreachable on a type that never supported ENA Express, so its presence is evidence the family does;
  confirm the current type still does before planning to re-enable.
- **Multi-ENI instances** can carry different modes per interface — a partial rollback touching one ENI is
  a common way to reach mode 2 — and with **≥3 series** the auto-generated `average` mixes them into a mean
  that can itself land on 2.0. At exactly two series the aggregate is dropped (`:312`–`:319`).
- **`.metal` and the largest family sizes** give the full non-shared network allowance, which changes the
  ceilings SRD does *not* affect — separate that from any SRD before/after comparison.

## Verification

The falsifiable claim is *ENA Express is off on this ENI having previously been on with UDP support, and
that rollback cost this workload measurable tail latency*. Both halves need establishing outside aperf.

1. **Refute from the report first.** `ena_srd_tx_pkts` and `ena_srd_rx_pkts` non-zero falsifies mode 2
   outright — SRD is running. So does either sibling SRD finding, both of which need active SRD.
2. **Check the point count and the step.** A two-point `ena_srd_mode` chart means the mode was constant and
   no +2 step occurred on a real series. Otherwise locate the step; if it lands mid-run, every before/after
   comparison in the report is invalid. And `total_resets`, `interface_down` and `interface_up` must be zero
   for the step to be a configuration change rather than a counter baseline moving.
3. **Establish the mode authoritatively**, via the EC2 API or `ethtool`. A confirmed **3** inverts the
   finding — the step was `1 → 3`, an improvement. Also grep the run log for
   `"skipped N data points due to unexpected decrease"` on `ena_srd_mode`: that line is the only proof
   aperf can offer that the mode *fell*, which is the event this rule is named for.
4. **Find the change in history, not by inference** — CloudTrail, configuration management, launch
   templates, runbooks. "Nobody knows why" is a finding in itself, and is what raises this to P1.
5. **Quantify the loss with the right numbers.** `netstat` TCP retransmit and out-of-order counters for
   path congestion, and UDP volume measured **on the instance** — aperf has no UDP counters anywhere. Then
   correlate application p99/p99.9 history against the change date; a regression there is the
   corroboration, and a flat mean proves nothing either way.
6. **Predict specifics before re-enabling, then check them.** Predict a gap between
   `ena_srd_eligible_tx_pkts` and `ena_srd_tx_pkts` if the MTU is 9001, that the tail falls by more than
   the mean, and that `ena_srd_resource_utilization` stays below 95 — while remembering a low reading is
   not headroom. Afterwards confirm the ENI reads a coherent 0, 1 or 3, never 2. Note that **`Disabled ENA
   Express` will still fire** whatever you choose; the delta defect is unchanged by any configuration.

## Do not

- **Do not read this as "the device is in mode 2".** On aperf 1.3.0 the mode series is deltified, so
  this rule fires only on a **+2 transition** — most plausibly 1 → 3, which is an *improvement*.
- **Do not rely on this rule to detect ENA Express being disabled.** The disabling transitions are
  *decreases*, and a decreasing sample produces no data point at all (`:214`) — only a `warn!` line in
  the log. The rule cannot see the event it is named for.
- **Do not read the score as severity.** It is a constant −2.00.
- **Do not treat mode 2 as merely cosmetic if the rollback is undocumented.** It proves ENA Express was
  deliberately enabled with UDP support and then switched off — a likely regression on exactly the
  traffic that needed acceleration.
- **Do not re-enable ENA Express without finding out why it was disabled.** MTU caps, SRD resource
  exhaustion, and UDP reordering are all legitimate reasons, and re-enabling blindly reintroduces the
  original problem.
- **Do not read a low `ena_srd_resource_utilization` as proof there is headroom now.** The gauge is
  deltified, so a steadily saturated card produces near-zero deltas and its rule never fires.
- **Do not fix only the instance when the cause was configuration drift.** A partial automation run or a
  template mismatch will recreate mode 2 on the next deployment.
- **Do not leave the configuration in mode 2 after investigating.** Land on 0, 1, or 3.
- **Do not measure UDP volume from `netstat`.** aperf reads only `/proc/net/netstat`, which has no UDP
  section; `/proc/net/snmp` is never read. Absence is a collection gap, not evidence of low UDP traffic.
- **Do not ignore that the run spans a configuration change.** Metrics either side of the step are not
  comparable, and that affects every other finding in the report.
- **Do not expect ENA Express to raise any allowance.** Bandwidth, PPS, tracking, and link-local
  ceilings are unaffected, and they outrank this finding.
- **Do not judge a re-enablement by mean latency.** The benefit concentrates in the tail; a flat mean is
  the expected result even when SRD is working.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:72`–`:78` (`Comparator::Equal`, threshold `2.0`,
  `Score::Bad` — twice the two `Concerning` mode rules). Siblings at `:56`, `:64`, `:80`; the two sound
  SRD rules at `:88`, `:99`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates
  every series including the auto-generated aggregate, keeping the largest `|score|`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167` — general branch, `delta = 2/2 = 1`.
  `Score::Bad = −2` at `:147`–`:157`; findings sort ascending by score
  (`src/report_frontend/src/utils/analytics.tsx:40`).
- **The defect:** `add_accumulative_data_point` applied to every `ena_stat` metric at
  `src/data/ena_stat.rs:343`; `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189`–`:224`.
- **Why the disabling transitions are invisible:** the `prev_value > data_value` arm returns `None` at
  `time_series_data_processor.rs:214`, `add_data_point_impl` returns early at `:150`, and the only trace
  is one `warn!` at `:297`–`:302`.
- Forced first zero: `ignore_first_accumulative_value: true` at
  `src/data/common/time_series_data_processor.rs:73`, taken at `:218`; the only opt-out,
  `use_first_accumulative_value()` (`:81`–`:83`), is called once, from `src/data/perf_stat.rs:1295`.
- All-zero compression to two points: `compress_all_zero_time_series_metric`,
  `time_series_data_processor.rs:410`–`:427`.
- Average aggregate and the two-series collapse: `src/data/ena_stat.rs:315`;
  `time_series_data_processor.rs:249`–`:256` and `:312`–`:319`. Queue-name flattening, `:327`–`:341`.
- Metric semantics: `ena_srd_mode` at `src/report_frontend/src/definitions/data-descriptions.ts:3859`
  (`desired: "fixed"`, and the only mode explained historically); `ena_srd_eligible_tx_pkts` at `:3871`
  names the three fallback causes; `ena_srd_resource_utilization` at `:3884`.
- No UDP collection: `NetstatRaw` reads only `/proc/net/netstat` (`src/data/netstat.rs:33`), which
  carries `TcpExt:` and `IpExt:`; `/proc/net/snmp` is read by no collector.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL` and the
  `ETHTOOL_GSSET_INFO`/`GSTRINGS`/`GSTATS` sequence, `:31`–`:33`, `:216`.
- **No upstream guidance exists:** `src/report_frontend/src/definitions/optimization-guides.ts` contains
  only the four EC2 network allowance guides (`:117`, `:125`, `:134`, `:146`) — nothing for SRD.
- Related playbooks: `disabled-ena-express.md` (the finding that fires instead),
  `enabled-ena-express-without-udp.md` (mode 1, the fallback target when UDP reordering caused the
  rollback), `ena-express-enabled-with-udp.md` (mode 3, the likeliest actual end state),
  `low-srd-usage-rate.md`, `high-srd-resource-utilization.md`.
- [ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express.html)
- [Configure ENA Express (including UDP support)](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express-configure.html)
