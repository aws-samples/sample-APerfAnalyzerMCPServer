---
rule_name: Disabled ENA Express
data_type: ena_stat
data_key: ena_srd_mode
template: time_series_data_point_threshold
condition: "any(ena_srd_mode) == 0.0"
base_score: Concerning
score_sign: negative
requires_comparison: false
aperf_message: "ENA Express is disabled. Verify if this is expected."
source: src/analytics/rules/ena_stat.rs:56
---

# Disabled ENA Express

## What fired

**At least one** data point of `ena_srd_mode` was **equal to 0.0** — read literally, "ENA Express off,
UDP off".

Base score `Concerning` (**−1**). Single-run rule, `Comparator::Equal`, threshold `0.0`
(`ena_stat.rs:56`). Because the comparator is `Equal`, the score is **always exactly −1.00** — there is
no magnitude to read.

**Read the next section before acting on this finding.** On aperf 1.3.0 this rule fires on essentially
every instance, including instances where ENA Express is fully enabled. It is the only one of the four
`ena_srd_mode` rules that fires in practice, and it fires for the wrong reason.

## The processing defect — verified by running the engine

`ena_srd_mode` is a **mode enum** (0/1/2/3), but `src/data/ena_stat.rs:343` passes **every** `ena_stat`
metric through `add_accumulative_data_point`, which:

- stores the **difference between consecutive samples**, not the raw value, and
- **forces the first sample to 0** (`ignore_first_accumulative_value: true` at
  `time_series_data_processor.rs:73`, never overridden — `use_first_accumulative_value()` has exactly
  **one caller in the entire source tree**, `src/data/perf_stat.rs:1295`).

A mode value is not a counter. It does not accumulate, so the delta of a constant mode is zero:

| device state | raw `ena_srd_mode` samples | series aperf stores | rule that fires |
|---|---|---|---|
| ENA Express **off** | 0, 0, 0, … | `[0.0, 0.0, 0.0, …]` | **Disabled ENA Express** ✔ correct by accident |
| ENA Express **on**, UDP off | 1, 1, 1, … | `[0.0, 0.0, 0.0, …]` | **Disabled ENA Express** ✘ wrong |
| off, UDP previously on | 2, 2, 2, … | `[0.0, 0.0, 0.0, …]` | **Disabled ENA Express** ✘ wrong |
| ENA Express **on**, UDP **on** | 3, 3, 3, … | `[0.0, 0.0, 0.0, …]` | **Disabled ENA Express** ✘ wrong |

This was confirmed by running the real rule engine against a device with a constant
`ena_srd_mode = 3`: the series came out as `[0.0, 0.0]` and the resulting finding was **"Disabled ENA
Express"** with score `−1.0` and the description `At least one data point in aperf_record is 0 (equal to
the threshold of 0)`. **The best possible configuration is reported as a negative finding, and the rule
written to praise it never fires.**

Three further processing facts, each independently observable in the report:

**1. A decreasing sample is DROPPED, not clamped.** `get_delta_and_set_previous_value`
(`time_series_data_processor.rs:189`–`:224`) compares against the stored previous value; if
`prev_value > data_value` it emits a `debug!`, increments a per-key counter, and `return None` at `:214`.
`add_data_point_impl` then returns early at `:150`, so **no series entry is created at all** — a gap, not
a zero. At the end of processing aperf emits exactly one `warn!` (`:297`–`:302`):

```
<data_name>.<metric>.<series>: skipped N data points due to unexpected decrease of accumulative data.
```

That log line is a directly citable artifact. It is also why **every mode *decrease* is invisible**: a
3→1, 2→0 or 3→0 transition — the disabling events this rule family is named for — produces no data point.

**2. A constant mode is rendered as exactly TWO data points.**
`compress_all_zero_time_series_metric` (`:410`–`:427`) checks the metric's stats and, when both min and
max are 0.0, compresses **every** series to only its first and last point. A constant `ena_srd_mode`
yields all-zero deltas, so in the report the `ena_srd_mode` chart shows two points regardless of run
length. **If you see two points, the mode never changed** — which is the normal case, and confirms the
finding is the artifact rather than a reading of the mode.

**3. The `average` series may not exist.** `ena_stat` aggregates with
`time_series_data_processor_with_average_aggregate` (`ena_stat.rs:315`), but `:312`–`:319` removes the
auto-generated aggregate when there are exactly **two** series and uses index 0 when there is one. So the
multi-interface-averaging caveat applies only with **≥2 real interfaces**; on a single-ENI instance there
is no `average` series at all.

Two consequences, and they are the whole of this playbook's practical value:

1. **This finding is not evidence that ENA Express is disabled.** Any constant mode produces it.
2. **The three sibling rules are effectively unreachable.** `Enabled ENA Express without UDP` (== 1),
   `Disabled ENA Express with Previously Enabled UDP` (== 2), and `ENA Express Enabled with UDP` (== 3)
   require raw mode values the pipeline never produces. They can only fire on a *transition* whose delta
   lands on 1, 2 or 3 — and only on an *increase*, since decreases are dropped. See their playbooks.

**So treat this finding as "aperf could not determine the ENA Express mode" and verify the mode out of
band.** The rest of this playbook is about what to check once you know the real mode — because when ENA
Express genuinely *is* off, the question the rule asks is a good one.

## Reasoning

`ena_srd_mode` "Indicates whether ENA Express is configured. 0 = ENA Express off, UDP off; 1 = ENA
Express on, UDP off; 2 = ENA Express off, UDP on (only happens after disabling the previously enabled
ENA Express with UDP); 3 = ENA Express on, UDP on." (`data-descriptions.ts:3859`, `desired: "fixed"`)

Note `desired: "fixed"` — the frontend knows this is a configuration enum where neither "higher" nor
"lower" is better. The rule engine's delta processing did not get the same memo.

**Why the underlying question matters.** ENA Express is powered by **SRD** (Scalable Reliable
Datagram), the same transport used by EFA. Compared with standard ENA it offers:

- **Multipath / dynamic routing** — traffic is sprayed across many network paths rather than pinned to
  one flow-hashed path, so a single congested or degraded path does not throttle a connection.
- **Much lower tail latency** — the largest and most reliable benefit. p99/p99.9 latency improves far
  more than the mean, because SRD routes around transient congestion instead of waiting for TCP
  recovery.
- **Higher single-flow throughput** — a single TCP flow on standard ENA is limited to one path;
  multipath lifts that ceiling substantially.

So the finding is worth asking about for latency-sensitive and single-flow-heavy workloads. But it is
`Concerning` (−1), the mildest negative score aperf defines, for good reason: **ENA Express is
frequently and correctly off.** It has real constraints:

- **Both endpoints must have it enabled**, and must be **in the same Availability Zone**. It does not
  work across AZs or over the internet.
- **Not all instance types support it.** Availability varies by family and generation.
- **MTU is capped at 8900** with ENA Express, below the 9001 standard jumbo MTU. Packets over the SRD
  MTU limit fall back to standard ENA.
- **It consumes network-card resources** for concurrent SRD connections — see
  `High SRD Resource Utilization` and `Low SRD Usage Rate`, which describe what happens when those
  resources run short.
- **It is not free of downside for every workload.** Workloads dominated by many short flows, or
  bandwidth-bound bulk transfer that already saturates the allowance, gain little.

**And there is no upstream guidance to lean on.** Unlike the five allowance findings, which each map to
an `optimization` array in `optimization-guides.ts`, **aperf ships no ENA Express or SRD optimization
guide at all** — grepping that file for `SRD` or `ena` returns only the four EC2 network *allowance*
guides. All remediation below comes from the metric descriptions and AWS documentation, not from aperf.

## Reading the description

`time_series_data_point_threshold` emits:

```
At least one data point in {run_name} is {value} ({comparator} the threshold of {threshold}).
```

with the comparator `"equal to"`:

```
At least one data point in aperf_record is 0 (equal to the threshold of 0).
```

**The value carries no information.** The comparator is `Equal`, so the reported value is always the
threshold — `0`. And because of the delta defect, that `0` is a *difference between samples*, not the
device's mode.

Score math — `compute_finding_score(0.0, 0.0, −1)` takes the `threshold == 0.0` branch with
`value < 1.0`:

| value | score | note |
|---|---|---|
| 0.0 (the only possible value) | **−1.00** | the comparator admits no other value |

**Always −1.00.** There is nothing to rank, and nothing to recover from the score. This is one of the
few aperf rules whose score is a constant, which is a useful tell: a `−1.00` on `ena_srd_mode` means the
rule fired, and nothing more.

## Interpretation

**Step one is always: find out the real mode, outside aperf.** Then:

| Real mode (verified out of band) | Reading |
|---|---|
| **0** — ENA Express off, UDP off | The finding is correct. Evaluate whether ENA Express would help this workload (below) |
| **1** — on, UDP off | **The finding is wrong.** ENA Express is active for TCP. See `Enabled ENA Express without UDP` for the question that rule was meant to ask |
| **2** — off, UDP previously on | **The finding is wrong**, and it is masking a `Bad` (−2) condition. See `Disabled ENA Express with Previously Enabled UDP` |
| **3** — on, UDP on | **The finding is wrong** and inverted: the ideal configuration is being reported as a negative finding. See `ENA Express Enabled with UDP` |

Once you know ENA Express really is off, the value of enabling it depends on the workload:

| Workload characteristic | Would ENA Express help? |
|---|---|
| Latency-sensitive, tail-latency-driven SLOs | **Yes — the strongest case.** Tail latency is where SRD's multipath routing pays off most |
| Single-flow or few-flow bulk transfer within an AZ | **Yes.** Multipath lifts the single-flow throughput ceiling |
| HPC / tightly-coupled distributed compute in one AZ | **Yes**, and consider whether EFA proper is the better fit |
| Traffic mostly **cross-AZ** or to the internet | **No.** ENA Express requires both endpoints in the same AZ |
| Peer instances not under your control | **No** — both ends must have it enabled |
| Already bandwidth-allowance-limited | **Marginal.** Fix the allowance first; SRD does not raise it |
| Jumbo frames at 9001 are load-bearing | **Careful.** The SRD MTU cap is 8900; oversized packets fall back to standard ENA |
| Very many short-lived flows | **Marginal**, and watch SRD resource utilization |

Combinations:

| also fired / observed | Reading |
|---|---|
| `Low SRD Usage Rate` or `High SRD Resource Utilization` also fired | **Proof that ENA Express is actually enabled** — those rules read SRD packet and utilization counters, which only move when SRD is in use. A direct contradiction of this finding; trust them, not this |
| `ena_srd_tx_pkts` / `ena_srd_rx_pkts` non-zero | **Same conclusion, more directly**: SRD packets are being transmitted, so ENA Express is on. **The quickest in-report refutation of this finding** |
| `ena_srd_resource_utilization` non-zero | Same — SRD resources are in use |
| `ena_srd_mode` chart shows exactly **two** points | The all-zero compression at `:410`–`:427` fired, so the mode was **constant** — the finding is the artifact |
| Any allowance finding fired | Bandwidth/PPS/tracking ceilings are separate from SRD and unaffected by it. Fix those first |
| TCP retransmits elevated (`netstat`) with tail-latency complaints | The scenario ENA Express addresses best |
| `Underutilized CPU` | Network-bound signature; if the bound is single-flow throughput, ENA Express may help |

**Known false positives:**

- **The processing defect above.** On aperf 1.3.0 this is the **default outcome for every constant
  mode**, including 3. It is by far the most likely reason you are reading this finding.
- **The metric is absent or the device does not report it.** Instance types without ENA Express support
  may still expose the counter at 0; "disabled" is then not actionable — it is unavailable.
- **ENA Express is deliberately off** — cross-AZ traffic, unsupported peers, or a considered decision.
  The rule says "Verify if this is expected", which is the correct framing.
- **Multi-interface averaging**, but only with **≥2 real interfaces**: the rule scans the auto-generated
  `average` series too, and on a two-series metric that aggregate is removed entirely (`:312`–`:319`).
- **A short recording.** The first sample is forced to 0, so a 1–2 sample run guarantees a 0 in the
  series regardless of anything else.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| `ena_srd_tx_pkts`, `ena_srd_rx_pkts` | `ena_stat` | **Do this first — the fastest refutation.** Non-zero means SRD is transmitting, so ENA Express is *on* and this finding is the delta defect. No rule fires on these directly; read manually |
| `ena_srd_resource_utilization` | `ena_stat` | Non-zero means SRD is in use. Also see `High SRD Resource Utilization` |
| `ena_srd_eligible_tx_pkts` vs `ena_srd_tx_pkts` | `ena_stat` | Whether SRD is being used for the traffic that qualifies. See `Low SRD Usage Rate` |
| `ena_srd_mode` series, and its **point count** | `ena_stat` | It is **deltified**; a flat zero series is expected for *any* constant mode, and a two-point chart proves the mode never changed |
| The four allowance counters | `ena_stat` | Separate ceilings; SRD does not raise them. Fix those first if breached |
| `tx_bytes`/`tx_cnt`, `rx_bytes`/`rx_cnt` | `ena_stat` | Flow volume and mean packet size — feeds the MTU-cap consideration |
| `total_resets`, `interface_down` | `ena_stat` | "Total number of ENA driver resets" — a reset reinitializes the driver, so counters may discontinue and mode readings may straddle a reconfiguration |
| Instance type and size | `systeminfo` | **Whether ENA Express is supported at all**, and the AZ constraint context |
| MTU configuration | `systeminfo` / `sysctl` | The SRD MTU cap is 8900; a 9001 MTU means some packets fall back. **No analytical rules for `sysctl` — read manually** |
| TCP retransmits, out-of-order counters | `netstat` | Path congestion — the condition SRD's multipath routing mitigates |
| `idle`, `aggregate` | `cpu_utilization` | Whether the workload is network-bound at all. See `Underutilized CPU` |
| The aperf `warn!` log for skipped decreases | run log | `"skipped N data points due to unexpected decrease"` on `ena_srd_mode` means the mode **fell** mid-run — the one way to learn a disabling transition happened |
| Out of band: `ethtool` / EC2 API on the ENI | — | **The authoritative mode.** aperf cannot be trusted for this on 1.3.0 |

## Guidance

Ordered. **Step 1 is refutation, not remediation** — this rule is unreliable by construction on
aperf 1.3.0.

1. **Refute or confirm from inside the report first.** Read `ena_srd_tx_pkts`, `ena_srd_rx_pkts`, and
   `ena_srd_resource_utilization`. If any is non-zero, **ENA Express is enabled and this finding is
   wrong** — it is the delta-processing artifact. Stop and note that; do not report "ENA Express is
   disabled".

2. **Check whether the sibling SRD rules fired.** `Low SRD Usage Rate` or `High SRD Resource
   Utilization` firing alongside this one is a direct contradiction: both read counters that only move
   when SRD is active. Trust them over this rule.

3. **Verify the real mode out of band.** Query the ENI's ENA Express configuration through the EC2 API
   or `ethtool` on the instance. aperf's `ena_srd_mode` series cannot answer this on 1.3.0. Check the run
   log for the skipped-decrease `warn!` while you are there: it is the only in-report signal that the
   mode changed *downward* during the recording.

4. **Ignore the score.** It is always exactly −1.00 and encodes nothing.

5. **If ENA Express really is off, establish whether it is even available and applicable** before
   recommending it:
   - Does the **instance type support** ENA Express? (`systeminfo`)
   - Is the traffic **within a single Availability Zone**? Cross-AZ traffic cannot use it.
   - Are the **peer instances** under your control, and can they enable it too? Both ends are required.
   - Is the workload **latency-sensitive or single-flow-heavy**? That is where the benefit is real.
   Any "no" makes the finding informational rather than actionable.

6. **Fix the allowance findings first if present.** Bandwidth, PPS, tracking, and link-local ceilings
   are independent of SRD; ENA Express does not raise any of them. Enabling it will not resolve a
   shaping problem.

7. **If enabling it, plan for the constraints and the follow-on findings:**
   - Enable on **both endpoints**, same AZ.
   - Account for the **8900 MTU cap** — if the interface uses 9001, oversized packets fall back to
     standard ENA. Reconcile the MTU deliberately rather than discovering it later.
   - Enable **UDP support too** if UDP traffic matters — see `Enabled ENA Express without UDP`.
   - After enabling, watch `ena_srd_resource_utilization` and the eligible-vs-actual packet gap; SRD
     resource exhaustion causes silent fallback to standard ENA. See `High SRD Resource Utilization`
     and `Low SRD Usage Rate`.
   - Measure **tail latency**, not the mean — that is where the improvement appears.

8. **If ENA Express is deliberately off, record that.** The rule literally says "Verify if this is
   expected"; a documented "yes, expected" is a complete resolution.

## Priority and execution risk

**Priority: P4 — Informational by default**, and that is unusual for a finding that fires: the rule is
unreliable by construction, so its *appearance* carries almost no information. It becomes
**P3 — Monitor** once the mode is confirmed as truly 0 and the workload is latency-sensitive or
single-flow-heavy within one AZ, because there is then a real, unrealized performance option on the
table. It rises to **P2 — Plan** when the mode is confirmed 0, ENA Express is supported, the peers are
under your control, and a tail-latency SLO is being missed with `netstat` retransmits corroborating path
congestion — the case where SRD's multipath routing is the direct remedy. It never reaches P1 or P0 on
its own: enabling ENA Express is an optimization, not a fix for an outage, and the four allowance
findings and any CPU-bound finding outrank it every time. And it drops back to **P4** the moment any
sibling SRD counter is non-zero, because the finding is then simply wrong.

**Execution risk: R0 — Read-only** for everything that resolves the finding: the counter refutation, the
two-point-chart check, the out-of-band mode query, the support and AZ checks, and reading the run log for
skipped decreases. Acting is where the risk sits, and it is higher than the mild score suggests.
**R2 — Enable ENA Express** on an existing ENI: it is a network-configuration change on both endpoints,
it silently caps effective MTU at 8900, and SRD adds header overhead so payload per packet falls
slightly. **R2** also for the MTU reconciliation that should accompany it, since an unaligned MTU
re-introduces fallback or fragmentation. **R3** if enabling requires a new ENI or an instance-type change
to reach a supporting family — a replacement, with all that implies. **R1** for the observability work
that should follow: adding tail-latency measurement and watching the SRD counters. **Do not inherit the
R0 of the diagnosis into the enablement.**

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: at least one `ena_srd_mode` interval delta, on any series, was `== 0.0` — which on
aperf 1.3.0 is true for every constant mode.

```
STEP 0 — Refute the finding before reading anything into it. This step resolves most cases.
  IF `ena_srd_tx_pkts`, `ena_srd_rx_pkts` or `ena_srd_resource_utilization` is NON-ZERO
  THEN → STOP. ENA Express is ENABLED and this finding is the delta-processing artifact.
         Those counters only move when SRD is carrying traffic. NO finding — do not report
         "ENA Express is disabled" (P4, R0)
  IF `Low SRD Usage Rate` or `High SRD Resource Utilization` also fired
  THEN → STOP. Both read SRD counters that only move when SRD is active, so they directly
         contradict this finding. Trust them. NO finding here; go read those playbooks
         (P4, R0)
  IF the `ena_srd_mode` chart shows exactly TWO data points
  THEN → the all-zero compression fired (time_series_data_processor.rs:410-:427), proving
         the mode was CONSTANT for the whole run. The finding says nothing about WHICH
         constant. Continue to STEP 1 (P4, R0)
  OTHERWISE
  THEN → the mode series has real variation, so a transition happened. Continue to STEP 1
         (P3, R0)

STEP 1 — Establish the REAL mode. aperf cannot answer this; nothing below is valid until
         you have.
  IF the mode is confirmed 1, 2 or 3 out of band (EC2 API or `ethtool` on the ENI)
  THEN → STOP. This finding is WRONG. For mode 3 it is also inverted: the best possible
         configuration reported as a negative. Read the matching sibling playbook for the
         question that rule meant to ask. VOID here (P4, R0)
  IF the aperf run log carries "skipped N data points due to unexpected decrease of
     accumulative data" on `ena_srd_mode`
  THEN → the mode FELL during the run — a disabling transition, which produces no data point
         at all (time_series_data_processor.rs:214 returns None). This is the only in-report
         evidence such a change occurred, and it means a reconfiguration happened mid-record
         (P2, R0)
       → verify: confirm the current mode out of band, then check whether the change was
         intentional; an unplanned drop from 1 or 3 is a configuration regression
  IF the mode is confirmed 0
  THEN → the finding is CORRECT, by accident. Continue to STEP 2 (P3, R0)

STEP 2 — Is ENA Express even AVAILABLE for this instance and this traffic? Any "no" ends
         the analysis.
  IF the instance type does not support ENA Express
  THEN → STOP. Nothing to enable. The finding is unavailability reported as configuration,
         and moving families to gain SRD is an instance-selection decision, not a fix.
         NO finding (P4, R0)
  IF the traffic is predominantly CROSS-AZ or internet-facing
  THEN → STOP. ENA Express requires both endpoints in the SAME Availability Zone, so SRD
         cannot carry this traffic at all. NO finding (P4, R0)
  IF the peer instances are not under your control
  THEN → STOP. Both ends must have it enabled; a one-sided enablement buys nothing.
         NO finding — record it as a dependency, not a defect (P4, R0)
  OTHERWISE
  THEN → ENA Express is available and applicable. Continue to STEP 3 (P3, R0)

STEP 3 — Fix the ALLOWANCE findings first. SRD does not raise any ceiling.
  IF any of the four allowance findings fired
  THEN → those are hardware ceilings on bytes, packets, connections or link-local traffic,
         and ENA Express raises NONE of them. Enabling SRD will not resolve shaping. Resolve
         them first, then return here. Go to their playbooks (P1, R0)
  IF `Underutilized CPU` fired with the network as the suspected bound
  THEN → establish whether the bound is SINGLE-FLOW throughput (which SRD lifts) or total
         allowance (which it does not). Read `tx_bytes` per interface against the documented
         allowance before crediting SRD with anything. Continue to STEP 4 (P2, R0)
  OTHERWISE
  THEN → no competing ceiling. Continue to STEP 4 (P3, R0)

STEP 4 — Would SRD actually help THIS workload? The benefit is narrow and specific.
  IF the workload has tail-latency SLOs AND `netstat` retransmits are elevated
  THEN → the strongest case for ENA Express. SRD's multipath routing sidesteps a congested
         path instead of waiting for TCP recovery, and p99/p99.9 improves far more than the
         mean (P2, R2)
       → verify: baseline p99 and p99.9 BEFORE enabling, then compare the same percentiles
         after. A mean-only comparison will look like no change and is the usual reason this
         enablement gets judged a failure
  IF the workload is single-flow or few-flow bulk transfer inside one AZ
  THEN → multipath lifts the per-flow path limit, so single-flow throughput is the expected
         gain. Confirm the flow count first: many-flow traffic already spreads across paths
         and gains little (P2, R2)
       → verify: single-flow throughput before and after at the same offered load; total
         instance throughput may not move at all
  IF the workload is many short-lived flows, or is already bandwidth-allowance-bound
  THEN → marginal at best. Short flows amortize no multipath benefit and SRD consumes card
         resources per concurrent connection; a saturated allowance is untouched by SRD.
         Record as informational and stop (P4, R0)
  IF the workload is tightly-coupled HPC or distributed training in one AZ
  THEN → evaluate EFA proper rather than ENA Express — same SRD transport, but exposed to
         the application with far larger gains for collective communication (P2, R3)
       → verify: EFA requires a supporting instance type, an EFA-enabled security group and
         a libfabric-aware stack; confirm all three before planning

STEP 5 — If enabling, plan the constraints. Two of them bite silently.
  IF the interface MTU is 9001
  THEN → the SRD MTU cap is 8900, so oversized packets fall back to standard ENA. Reconcile
         the MTU deliberately rather than discovering the fallback as unexplained variance
         (P2, R2)
       → verify: after the change, `ena_srd_tx_pkts` tracks `ena_srd_eligible_tx_pkts`
         closely; a persistent gap means packets still exceed the SRD limit
  IF UDP traffic matters to the workload
  THEN → enable UDP support at the same time, but weigh REORDERING first: SRD sprays across
         paths and UDP has no transport layer restoring order, so a reordering-sensitive UDP
         application can do WORSE with UDP enabled. See `enabled-ena-express-without-udp.md`
         (P2, R2)
       → verify: application-level out-of-order or late-arrival metrics, not throughput —
         throughput can rise while correctness-relevant ordering degrades
  OTHERWISE
  THEN → enable on both endpoints and move to the follow-on watch list (P2, R2)
       → verify: `ena_srd_tx_pkts` becomes non-zero, and `ena_srd_resource_utilization` stays
         well below 95 — see `high-srd-resource-utilization.md` for why its absence is not
         proof of headroom

STEP 6 — What survives?
  VALID      : that the mode question is worth asking on a latency-sensitive, single-flow,
               same-AZ workload; the instance-type support check; the same-AZ and
               both-endpoints constraints; the 8900 MTU cap; and the presence of the finding
               as a prompt to go verify the mode elsewhere
  CAUTION    : any workload-fit judgement made without measuring tail latency and flow count
               first; and a two-point `ena_srd_mode` chart read as "nothing happened" when it
               only proves the mode was CONSTANT
  CONFOUNDED : the reported value, which is a per-interval DELTA of an enum and always the
               threshold anyway; and any average over the series, diluted by the forced first
               zero and, with >=2 interfaces, by the cross-interface mean
  VOID       : the conclusion "ENA Express is disabled" — a constant mode of ANY value,
               including 3, produces this finding, engine-verified; the score, a constant
               −1.00 with no magnitude; and the absence of the three sibling findings as
               evidence about the mode, since they are unreachable for constant modes

INSUFFICIENT DATA
  IF `ena_stat` is absent from the run
  THEN → collection needs the ethtool ioctl on a PCI-backed interface (ena_stat.rs:190-:205);
         `lo`, `docker*`, `veth*`, `br-*` and `virbr*` are skipped. Absence proves nothing
         about the mode (P4, R0)
  IF `ena_srd_*` metrics are absent while other `ena_stat` metrics are present
  THEN → the driver or instance type does not expose the SRD counters, so ENA Express is
         almost certainly unsupported here. Confirm from the instance type (P4, R0)
  IF the series has fewer than 3 points
  THEN → the first point is a structural zero, so 2 snapshots cover 1 real interval. Even a
         transition could not be resolved. Re-record with `--period 300` (P4, R0)
  IF the question was "is ENA Express enabled?" and this finding did NOT fire
  THEN → impossible to reach on 1.3.0 for a constant mode, so its absence means the metric
         was not collected rather than that the mode is non-zero (P3, R0)
```

## Runtime-specific consequences

SRD is transparent to the application — it substitutes for the ENA data path beneath the socket — so no
runtime needs code changes. What differs is which runtimes *notice* the benefit.

- **Any TCP workload.** SRD replaces the single flow-hashed path with multipath spraying and reorders
  are resolved below the socket, so TCP sees fewer congestion events and less spurious recovery. No
  application change required; the gain appears as reduced tail latency.
- **UDP workloads.** UDP is only carried when mode is 1→3, and it is the one case where SRD can hurt:
  spraying reorders datagrams and UDP has no transport layer restoring order. A reordering-tolerant
  protocol gains; a reordering-sensitive one may regress. See `enabled-ena-express-without-udp.md`.
- **Java.** Nothing to configure, but the measurement trap is acute: JVM latency histograms are usually
  reported as means and p99 in the same breath, and only the p99/p99.9 move meaningfully. A GC pause of
  50 ms swamps a network improvement of a few hundred microseconds, so `java_profile` GC evidence must be
  ruled out before crediting or blaming SRD.
- **RPC meshes and sidecar proxies.** Every hop is a separate connection consuming its own SRD card
  resources, so a mesh multiplies concurrent SRD connections for the same logical traffic — the fastest
  route to `High SRD Resource Utilization`.
- **Containers.** ENA Express is a property of the **ENI**, so all containers on the instance share it
  and none can opt out. A container with only virtual interfaces collects no `ena_stat` at all.
- **HPC / MPI / distributed training.** These are the workloads SRD was designed for, but through **EFA**
  rather than ENA Express — the same transport exposed directly to the application, with far larger gains
  for collective communication. See the `efa_stat` playbooks.

## Architecture-specific considerations

Architecture-independent in mechanism, instance-dependent in availability.

- **The metric source is architecture-agnostic.** `ena_stat` reads it via the `SIOCETHTOOL` ioctl
  (`src/data/ena_stat.rs:31`–`:33`, `:216`), so Graviton and x86 collect identically, and the delta defect applies
  identically on both.
- **Collection requires a PCI-backed interface.** `Ethtool::new` skips `lo`, `docker*`, `veth*`, `br-*`
  and `virbr*`, then requires `/sys/class/net/<if>/device` (`ena_stat.rs:190`–`:205`). Inside a container
  with only virtual interfaces, **`ena_stat` collects nothing** and the rule cannot fire.
- **ENA Express support is a property of instance type and generation, not of the CPU architecture.**
  Graviton and Intel/AMD families both include supporting and non-supporting types; a Graviton migration
  neither grants nor removes it. Check the specific type, never the architecture.
- **The same-AZ requirement is a placement constraint, not a hardware one.** It is unaffected by
  instance size, and it is the most common reason ENA Express is correctly off.
- **Multi-ENI instances** may have SRD enabled on some interfaces and not others, and with **≥2 real
  interfaces** the auto-generated `average` series mixes their modes into a meaningless mean. With
  exactly two series the aggregate is dropped (`:312`–`:319`), so the mixing only starts at three.
- **`.metal` and the largest family sizes** give the full non-shared network allowance, which changes the
  allowance ceilings SRD does *not* affect — worth separating in any before/after comparison.

## Verification

The falsifiable claim is *ENA Express is off on this instance, and enabling it would reduce tail latency
for this workload*. aperf cannot establish the first half, so verification starts by discarding it.

1. **Refute from the report.** `ena_srd_tx_pkts`, `ena_srd_rx_pkts` and `ena_srd_resource_utilization`
   must **all** be zero for the finding to be even possibly correct. Any non-zero value falsifies it
   outright — no further work needed.
2. **Check the point count.** A two-point `ena_srd_mode` chart proves the all-zero compression fired
   (`:410`–`:427`), so the mode was constant — and therefore that the finding is uninformative about
   *which* constant.
3. **Establish the mode authoritatively**, via the EC2 API or `ethtool` on the ENI. Record the answer in
   the report notes; every subsequent step depends on it. Also grep the run log for
   `"skipped N data points due to unexpected decrease"` on `ena_srd_mode` — its presence means the mode
   fell mid-run and no data point was written for the change.
4. **Confirm applicability before recommending anything.** Instance-type support, same-AZ traffic, and
   peer control are all necessary; a recommendation that fails any of the three is unactionable and
   should be recorded as such rather than escalated.
5. **Baseline the right metric.** Capture p99 and p99.9 latency, single-flow throughput, and the flow
   count *before* enabling. A mean-latency baseline will show no change afterwards and is the usual
   reason this enablement is judged a failure.
6. **Predict the MTU consequence.** If the interface is at 9001, predict that some packets fall back to
   standard ENA, and check it afterwards as a gap between `ena_srd_eligible_tx_pkts` and
   `ena_srd_tx_pkts`. No gap means the traffic was already under 8900.
7. **After enabling, predict specifics, not improvement.** `ena_srd_tx_pkts` becomes non-zero;
   `ena_srd_resource_utilization` stays well below 95; p99 falls by more than the mean. If throughput
   rose but the tail did not move, the gain came from somewhere else and the attribution is wrong. Note
   that **this finding will still fire** afterwards — the delta defect is unchanged by enablement.

## Do not

- **Do not conclude ENA Express is disabled from this finding.** On aperf 1.3.0 a constant mode of
  **any** value — including 3, fully enabled — produces this exact finding. Verified by running the
  engine.
- **Do not read the reported value as the device's mode.** It is a per-interval *delta*, and with an
  `Equal` comparator it is always the threshold anyway.
- **Do not read the score as severity.** It is a constant −1.00.
- **Do not treat the absence of the three sibling findings as evidence about the mode.** They are
  unreachable for a constant mode, so their silence is structural, not informative.
- **Do not read a flat zero series, or a two-point chart, as "the mode was 0".** Both are exactly what a
  constant mode of 3 produces.
- **Do not expect a mode *decrease* to appear anywhere in the series.** A decreasing sample is dropped
  entirely (`:214`), leaving a gap and one `warn!` line — so the disabling transitions this rule family
  is named for are invisible in the data.
- **Do not recommend enabling ENA Express without checking support, the same-AZ requirement, and the
  peer endpoints.** Missing any of the three makes the recommendation unactionable.
- **Do not expect ENA Express to raise a bandwidth, PPS, or connection-tracking allowance.** Those are
  separate ceilings, and they outrank this finding.
- **Do not enable it while leaving a 9001 MTU unexamined.** The SRD cap is 8900; oversized packets fall
  back silently to standard ENA.
- **Do not assume the mean latency will improve much.** The benefit concentrates in the tail, so a
  mean-only baseline will show nothing and the change will be judged a failure.
- **Do not treat "not enabled" as automatically wrong.** ENA Express is correctly off for cross-AZ,
  internet-facing, and many-short-flow workloads.
- **Do not look for upstream aperf guidance here.** No ENA Express or SRD optimization guide exists in
  `optimization-guides.ts`; only the four network *allowance* guides do.

## References

- Rule definition: `src/analytics/rules/ena_stat.rs:56`–`:62` (`Comparator::Equal`, threshold `0.0`,
  `Score::Concerning`). Siblings at `:64`, `:72`, `:80`; the two sound SRD rules at `:88`, `:99`.
- Rule template: `src/analytics/rule_templates/time_series_data_point_threshold_rule.rs` — iterates
  every series including the auto-generated aggregate, keeping the largest `|score|`.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`–`:176` — the `threshold == 0.0`
  branch with `value < 1.0` returns `rule_score` unchanged, hence the constant −1.00.
- **The defect:** `add_accumulative_data_point` applied unconditionally to every `ena_stat` metric at
  `src/data/ena_stat.rs:343`; `get_delta_and_set_previous_value`,
  `src/data/common/time_series_data_processor.rs:189`–`:224`.
- Forced first zero: `ignore_first_accumulative_value: true` at
  `src/data/common/time_series_data_processor.rs:73`, taken at `:218`. The only opt-out in the tree is
  `use_first_accumulative_value()` (`:81`–`:83`), called once, from `src/data/perf_stat.rs:1295`.
- Dropped decrease and its warning: `time_series_data_processor.rs:214` (`return None`), early return at
  `:150`, and the single `warn!` at `:297`–`:302`.
- All-zero compression to two points: `compress_all_zero_time_series_metric`,
  `time_series_data_processor.rs:410`–`:427`.
- Average aggregate and the two-series collapse: `src/data/ena_stat.rs:315`;
  `time_series_data_processor.rs:249`–`:256` and `:312`–`:319`.
- Metric semantics: `ena_srd_mode` at `src/report_frontend/src/definitions/data-descriptions.ts:3859`
  (`desired: "fixed"` — the frontend knows it is a configuration enum); the other SRD metrics at
  `:3865`–`:3890`.
- Collection: `Ethtool::new` interface filter, `src/data/ena_stat.rs:190`–`:205`; `SIOCETHTOOL`
  and the `ETHTOOL_GSSET_INFO`/`GSTRINGS`/`GSTATS` sequence, `:31`–`:33`, `:216`.
- **No upstream guidance exists:** `src/report_frontend/src/definitions/optimization-guides.ts` contains
  only the four EC2 network allowance guides (`:117`, `:125`, `:134`, `:146`) — nothing for SRD.
- Related playbooks: `enabled-ena-express-without-udp.md`,
  `disabled-ena-express-with-previously-enabled-udp.md`, `ena-express-enabled-with-udp.md`,
  `low-srd-usage-rate.md`, `high-srd-resource-utilization.md`, and the allowance playbooks that outrank
  this finding.
- [ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express.html)
- [Improve network performance with ENA Express](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/ena-express-configure.html)
- [Scalable Reliable Datagram (SRD)](https://aws.amazon.com/blogs/hpc/in-the-search-for-performance-theres-more-than-one-way-to-build-a-network/)
