# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Parse and reproduce aperf's finding `description` strings.

Every playbook's `## Reading the description` section is a prose statement of what this
module does mechanically. The two must agree: `check_playbooks.py` lints the prose, and
`test_aperf_desc.py` differentially fuzzes the code against the Rust original.

Faithful ports, with sources:

  f64_to_fixed_2                  src/computations/mod.rs:138   truncation, NOT rounding
  delta_ratio_to_percentage_string  src/computations/mod.rs:162
  formatted_number_string         src/computations/mod.rs:176   T/G/M/K suffixes
  compute_finding_score           src/analytics/mod.rs:167

Verified against aperf 1.3.0 (commit adf0970) by differential fuzz over 40 000 values:
0 mismatches. See tools/README.md.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any

# --------------------------------------------------------------------------------------
# Formatters — ports of aperf's Rust functions
# --------------------------------------------------------------------------------------

#: Score enum, src/analytics/mod.rs:147. The emitted score is this value only for the
#: five non-amplifying templates; the four time-series templates scale it.
SCORE = {
    "Critical": -256,
    "Poor": -16,
    "Bad": -2,
    "Concerning": -1,
    "Neutral": 0,
    "Acceptable": 1,
    "Good": 2,
    "Great": 16,
    "Optimal": 256,
}

#: Templates that call compute_finding_score. The other six insert the raw Score, so
#: their emitted score carries no magnitude at all.
AMPLIFYING_TEMPLATES = {
    "time_series_stat_threshold",
    "time_series_data_point_threshold",
    "time_series_data_point_threshold_multi_metric",
    "time_series_stat_run_comparison",
    "time_series_stat_intra_run_comparison",
}


def f64_to_fixed_2(value: float) -> float:
    """src/computations/mod.rs:138 — truncate to 2 dp. `999.999` becomes `999.99`."""
    return math.trunc(value * 100.0) / 100.0


def _rust_display_f64(value: float) -> str:
    """Rust's `{}` on an f64: `2.0` prints as `2`, `2.5` as `2.5`."""
    if value == int(value):
        return str(int(value))
    return repr(value)


def formatted_number_string(value: float) -> str:
    """src/computations/mod.rs:176 — the exact string aperf puts in a description."""
    if isinstance(value, float) and math.isnan(value):
        return "NaN"
    if value >= 1e12:
        return _rust_display_f64(f64_to_fixed_2(value / 1e12)) + "T"
    if value >= 1e9:
        return _rust_display_f64(f64_to_fixed_2(value / 1e9)) + "G"
    if value >= 1e6:
        return _rust_display_f64(f64_to_fixed_2(value / 1e6)) + "M"
    if value >= 1e3:
        return _rust_display_f64(f64_to_fixed_2(value / 1e3)) + "K"
    return _rust_display_f64(f64_to_fixed_2(value))


def delta_ratio_to_percentage_string(delta_ratio: float) -> str:
    """src/computations/mod.rs:162.

    Note `0.0` yields the literal `"equal to"` with no percentage, so a description
    reading `is equal to` is a formatting branch, not a missing value.
    """
    if delta_ratio == 0.0:
        return "equal to"
    pct = f64_to_fixed_2(abs(delta_ratio) * 100.0)
    relation = "greater than" if delta_ratio > 0.0 else "less than"
    return f"{_rust_display_f64(pct)}% {relation}"


def compute_finding_score(value: float, threshold: float, rule_score: float) -> float:
    """src/analytics/mod.rs:167.

    Three branches, all of which surprise on first reading:
      * `threshold == 0.0` — the zero-threshold rules. A value of exactly 1.0 scores 0.0.
      * `value == 0.0` — hardcoded to twice the base score.
      * otherwise — ratio amplification, reciprocal when the ratio is below 1, so a value
        far *below* the threshold amplifies exactly as much as one far above it.
    """
    if threshold == 0.0:
        return rule_score if value < 1.0 else (value - 1.0) * rule_score
    if value == 0.0:
        return 2.0 * rule_score
    delta = value / threshold
    if delta < 1.0:
        delta = 1.0 / delta
    return delta * rule_score


# --------------------------------------------------------------------------------------
# Inverse: recover the observed value from a score
# --------------------------------------------------------------------------------------


def value_from_score(
    score: float, threshold: float, rule_score: float
) -> tuple[float, ...]:
    """Invert `compute_finding_score`, returning every candidate value.

    The score is full precision while the description is truncated to 2 dp, so this is
    the *more* accurate reading of a finding — but it is not always unique.

    Returns a tuple because the ratio branch is genuinely two-valued: `delta` and
    `1/delta` produce the same score, so a score of `-512` against threshold `50` at base
    `Critical` could mean an observed `100.0` or an observed `25.0`. The description's
    `greater than`/`less than` wording, or the metric's own bounds, disambiguates.
    An empty tuple means the score is unreachable for these parameters.
    """
    if rule_score == 0.0:
        return ()
    if threshold == 0.0:
        if score == rule_score:
            return ()  # any value < 1.0; not recoverable
        return (score / rule_score + 1.0,)
    ratio = score / rule_score
    if ratio < 1.0:
        return ()
    candidates = [threshold / ratio, ratio * threshold]
    if ratio == 2.0:
        # The `value == 0.0` branch short-circuits to exactly 2x the base score, so a
        # score at ratio 2 has THREE preimages: 0.0, threshold/2, and 2*threshold.
        candidates.insert(0, 0.0)
    return tuple(sorted(set(candidates)))


def parse_formatted_number(text: str) -> float:
    """Invert `formatted_number_string`.

    The suffix is mandatory context: `1.5G` is 1.5e9. Because the source value was
    truncated to 2 dp *after* division, the result carries up to 1e7 of absolute error on
    a `G`-suffixed value — never treat a parsed description number as exact.
    """
    text = text.strip()
    if text == "NaN":
        return math.nan
    multipliers = {"T": 1e12, "G": 1e9, "M": 1e6, "K": 1e3}
    if text and text[-1] in multipliers:
        return float(text[:-1]) * multipliers[text[-1]]
    return float(text)


# --------------------------------------------------------------------------------------
# Description parsers — one per template, keyed by the template name in frontmatter
# --------------------------------------------------------------------------------------


@dataclass
class ParsedDescription:
    """What a playbook's decision tree branches on.

    `fields` holds only what the template actually emitted. Absent keys are absent
    because aperf never wrote them, not because parsing failed — a decision tree must
    never branch on a key this object does not carry.
    """

    template: str
    form: str
    fields: dict[str, Any] = field(default_factory=dict)

    def __getitem__(self, key: str) -> Any:
        return self.fields[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.fields.get(key, default)


_NUM = r"(?:NaN|-?[\d.]+[TGMK]?)"

_PATTERNS: list[tuple[str, str, re.Pattern[str]]] = [
    # ---- time_series_stat_threshold
    # src/analytics/rule_templates/time_series_stat_threshold_rule.rs:74
    (
        "time_series_stat_threshold",
        "value",
        re.compile(rf"^The (?P<stat>\w+) in (?P<run>.+?) is (?P<value>{_NUM})\.$"),
    ),
    # ---- time_series_data_point_threshold(_multi_metric) — ..._rule.rs:125
    (
        "time_series_data_point_threshold",
        "value",
        re.compile(
            rf"^At least one data point in (?P<run>.+?) is (?P<value>{_NUM}) "
            r"\((?P<comparator>.+?) the threshold of (?P<threshold>[\d.-]+)\)\.$"
        ),
    ),
    # ---- time_series_stat_run_comparison — ..._rule.rs:121
    (
        "time_series_stat_run_comparison",
        "delta",
        re.compile(
            rf"^The (?P<stat>\w+) in (?P<run>.+?) \((?P<value>{_NUM})\) is "
            r"(?P<pct>[\d.]+)% (?P<relation>greater than|less than) "
            rf"(?P<base_run>.+?) \((?P<base_value>{_NUM})\)\.$"
        ),
    ),
    (
        "time_series_stat_run_comparison",
        "equal",
        re.compile(
            rf"^The (?P<stat>\w+) in (?P<run>.+?) \((?P<value>{_NUM})\) is equal to "
            rf"(?P<base_run>.+?) \((?P<base_value>{_NUM})\)\.$"
        ),
    ),
    # ---- time_series_stat_intra_run_comparison — ..._rule.rs:107
    # Same shape as run_comparison, but the two names are METRICS, not runs.
    (
        "time_series_stat_intra_run_comparison",
        "delta",
        re.compile(
            rf"^The (?P<stat>\w+) in (?P<metric>.+?) \((?P<value>{_NUM})\) is "
            r"(?P<pct>[\d.]+)% (?P<relation>greater than|less than) "
            rf"(?P<baseline_metric>.+?) \((?P<base_value>{_NUM})\)\.$"
        ),
    ),
    (
        "time_series_stat_intra_run_comparison",
        "equal",
        re.compile(
            rf"^The (?P<stat>\w+) in (?P<metric>.+?) \((?P<value>{_NUM})\) is equal to "
            rf"(?P<baseline_metric>.+?) \((?P<base_value>{_NUM})\)\.$"
        ),
    ),
    # ---- key_value_key_run_comparison — ..._rule.rs:78 and :95
    (
        "key_value_key_run_comparison",
        "differs",
        re.compile(
            r'^The value of (?P<key>.+?) in (?P<run>.+?) \("(?P<value>.*?)"\) is '
            r'different from (?P<base_run>.+?) \("(?P<base_value>.*?)"\)\.$'
        ),
    ),
    (
        "key_value_key_run_comparison",
        "key_missing",
        re.compile(
            r"^The key (?P<key>.+?) does not exist in (?P<run>.+?), while its value in "
            r'(?P<base_run>.+?) is "(?P<base_value>.*?)"\.$'
        ),
    ),
    # ---- key_value_key_expected — ..._rule.rs:60 and :76
    (
        "key_value_key_expected",
        "differs",
        re.compile(
            r'^The value of (?P<key>.+?) in (?P<run>.+?) is "(?P<value>.*?)", '
            r'instead of "(?P<expected>.*?)"\.$'
        ),
    ),
    (
        "key_value_key_expected",
        "key_missing",
        re.compile(
            r"^The key (?P<key>.+?) in (?P<run>.+?) is missing, instead of being set to "
            r"(?P<expected>.*)$"
        ),
    ),
    # ---- profile_stack_frame_threshold — ..._rule.rs:124  (NOTE: no trailing period)
    (
        "profile_stack_frame_threshold",
        "value",
        re.compile(
            r"^Stack pattern (?P<pattern>.+?) accounts for (?P<pct>[\d.]+)% of samples "
            r"in (?P<profile_type>.+?) \(threshold: (?P<threshold>[\d.]+)%\)$"
        ),
    ),
    # ---- profile_metadata_expected — ..._rule.rs:88 and :97
    (
        "profile_metadata_expected",
        "differs",
        re.compile(
            r"^Event type '(?P<group>.*?)' field '(?P<key>.*?)' in (?P<metadata_key>.+?) "
            r"should match pattern '(?P<expected>.*?)', found: (?P<value>.*)$"
        ),
    ),
    (
        "profile_metadata_expected",
        "not_found",
        re.compile(
            r"^Event type '(?P<group>.*?)' field '(?P<key>.*?)' not found in profile data$"
        ),
    ),
    # ---- multi_data_rule — rules/multi_data_rules.rs:60
    # Not a template at all: the one multi-data rule builds its finding inline, so its
    # description shape is unique to `PREEMPT_LAZY Detected` and cannot be reused.
    (
        "multi_data_rule",
        "preempt_lazy",
        re.compile(
            r"^Kernel (?P<kernel_version>.+?) in (?P<run>.+?) is running with "
            r"PREEMPT_LAZY preemption model\.$"
        ),
    ),
    # ---- profile_metadata_comparison — ..._rule.rs:101, :135, :151, :155
    (
        "profile_metadata_comparison",
        "base_absent",
        re.compile(
            r"^Event type '(?P<group>.*?)' field '(?P<key>.*?)' not found in run "
            r"(?P<base_run>.+?)\.$"
        ),
    ),
    (
        "profile_metadata_comparison",
        "differs_keyed",
        re.compile(
            r"^Event type '(?P<group>.*?)' field '(?P<key>.*?)' in (?P<run>.+?) for "
            r"'(?P<metadata_key>.*?)' \(\"(?P<value>.*?)\"\) differs from "
            r"(?P<base_run>.+?) for '(?P<base_metadata_key>.*?)' \(\"(?P<base_value>.*?)\"\)$"
        ),
    ),
    (
        "profile_metadata_comparison",
        "differs",
        re.compile(
            r"^Event type '(?P<group>.*?)' field '(?P<key>.*?)' in (?P<run>.+?) for "
            r"'(?P<metadata_key>.*?)' \(\"(?P<value>.*?)\"\) differs from "
            r"(?P<base_run>.+?) \(\"(?P<base_value>.*?)\"\)$"
        ),
    ),
    (
        "profile_metadata_comparison",
        "missing_in_run",
        re.compile(
            r"^Event type '(?P<group>.*?)' field '(?P<key>.*?)' not found in (?P<run>.+?) "
            r"for '(?P<metadata_key>.*?)', while its value in (?P<base_run>.+?) is "
            r'"(?P<base_value>.*?)"$'
        ),
    ),
]

#: `value`/`base_value` are only numbers when the template ran them through
#: `formatted_number_string` — i.e. for the four time-series templates. The key_value and
#: profile templates interpolate the raw string, so their `value` is `"n"`, `"6.1.0-1029"`,
#: `"jvm"`, and coercing it would either raise or silently invent a number.
_NUMERIC_FIELDS = {"value", "base_value"}
_FLOAT_FIELDS = {"pct", "threshold"}


def parse_description(description: str, template: str | None = None) -> ParsedDescription:
    """Parse a finding description into the fields a decision tree branches on.

    Pass `template` (from the playbook's frontmatter) whenever it is known.
    `time_series_stat_run_comparison` and `time_series_stat_intra_run_comparison` emit
    *byte-identical* shapes — the only difference is whether the two names are runs or
    metrics — so without the template the intra-run form is indistinguishable and this
    function will return the run-comparison reading.

    Raises `ValueError` on no match: an unparseable description means aperf changed a
    format string, which must fail loudly rather than silently yield an empty tree input.
    """
    text = description.strip()
    candidates = _PATTERNS
    if template:
        base = (
            "time_series_data_point_threshold"
            if template == "time_series_data_point_threshold_multi_metric"
            else template
        )
        candidates = [p for p in _PATTERNS if p[0] == base]
        if not candidates:
            raise ValueError(f"unknown template: {template!r}")
    for tmpl, form, pattern in candidates:
        match = pattern.match(text)
        if not match:
            continue
        numeric = tmpl in AMPLIFYING_TEMPLATES
        fields: dict[str, Any] = {}
        for key, raw in match.groupdict().items():
            if raw is None:
                continue
            if numeric and key in _NUMERIC_FIELDS:
                fields[key] = parse_formatted_number(raw)
                fields[key + "_text"] = raw
            elif key in _FLOAT_FIELDS:
                fields[key] = float(raw)
            else:
                fields[key] = raw
        if form == "equal":
            fields["pct"] = 0.0
            fields["relation"] = "equal to"
        if "pct" in fields and "relation" in fields:
            sign = -1.0 if fields["relation"] == "less than" else 1.0
            fields["delta_ratio"] = sign * fields["pct"] / 100.0
        return ParsedDescription(template=tmpl, form=form, fields=fields)
    raise ValueError(
        f"no template pattern matched: {text!r}"
        + (f" (template={template!r})" if template else "")
    )


def base_stat_was_zero(parsed: ParsedDescription) -> bool:
    """True when the `100.00% greater than` reading is the zero-baseline substitution.

    Both comparison templates hardcode a delta ratio of 1.0 when the base stat is 0
    rather than dividing by zero, so `100.00% greater than X (0)` does **not** mean
    "twice as much" — it means the baseline measured nothing. Every playbook whose
    template is a comparison must have a decision-tree branch for this.
    """
    if "base_value" not in parsed.fields:
        return False
    return parsed.fields["base_value"] == 0.0 and parsed.fields.get("pct") == 100.0
