---
rule_name: Inconsistent Outbound Network Traffic
data_type: netstat
data_key: IpExt:OutOctets
template: time_series_stat_run_comparison
condition: "abs(delta_avg(IpExt:OutOctets)) >= 0.1"
base_score: Bad
score_sign: negative
requires_comparison: true
aperf_message: "The average number of bytes transmitted by the network interface is different. Verify that the load generator is providing the expected traffic, if the system is under tests."
source: src/analytics/rules/netstat.rs:21
---

# Inconsistent Outbound Network Traffic

## What fired

The **average** per-interval delta of `IpExt:OutOctets` differs from the base run by **10% or more in either
direction** (`abs: true`). `IpExt:OutOctets` is "Total number of bytes transmitted by the network interface at
the IP layer" (`data-descriptions.ts:3527`, `unit: "Bytes"`, `desired: "depends"`).

Base score `Bad` (**−2**). Comparison-only: it cannot fire on a single-run report.

The message is identical in intent to the inbound rule — *"Verify that the load generator is providing the
expected traffic, if the system is under tests."* — but **the message's framing fits the outbound direction
less well**, and that matters. For a server, outbound bytes are **responses the system produced**, not load the
generator offered. **Outbound is closer to a work-*output* metric than an input**, which changes what a
difference means.

## Reasoning

**Why the outbound direction reads differently from inbound.** The same rule, threshold, and score are applied
to both octet counters, but the causal position of the two metrics is not symmetric:

- **Inbound** is primarily *offered load*: less in usually means less work was requested.
- **Outbound** is primarily *completed work*: for a request/response server, response bytes are produced only
  after the system has done the work. **Less out with the same in is a throughput regression**, not a harness
  problem — the system received the requests and failed to answer as much.

So the most valuable reading of this finding is **relative to the inbound finding**, not on its own. That
comparison — did in and out move together, or did they diverge — is the single most informative thing you can
do with it, and it is why these two playbooks should be read as a pair.

**The four in/out combinations, and what each means.** This is the core reasoning of the finding:

| Inbound | Outbound | Reading |
|---|---|---|
| down ~equally | down ~equally | **Load-volume difference.** Both directions scale with request count. Harness or deliberate load change |
| flat | **down** | **Throughput or response-size regression.** Requests arrived; fewer response bytes came back. **The most actionable case** |
| flat | **up** | Response size or protocol overhead grew — larger payloads, lost compression, more retransmission, chattier protocol |
| down | flat | Requests fell but output held — often a background/batch producer dominating the outbound count, or an asymmetric ingest workload |

**Retransmission is the outbound-specific trap, and it inflates bytes without producing work.** Every
retransmitted segment is counted again in `IpExt:OutOctets`. So a run on a lossier path, with worse congestion
control behaviour, or hitting a throttle can show **more** outbound bytes while delivering **less** useful
payload. `TcpExt:TCPSynRetrans`, `TcpExt:TCPLostRetransmit`, `TcpExt:TCPRetransFail`, and
`TcpExt:TCPTimeouts` are how you catch this. **This is the outbound analogue of the `retrans_bytes` check in
`Inconsistent Outbound EFA Traffics`**: the question "are the extra bytes work, or are they the same work sent
twice?" applies identically here, and `netstat` can answer it where the byte counter alone cannot.

**Outbound is where EC2 bandwidth allowances usually bite first.** Instance network allowances are typically
tighter on egress in practice for server workloads, and `bw_out_allowance_exceeded` is the counter that says so.
Above the ceiling, outbound bytes are **capped by the instance, not by the workload** — the series goes
flat-topped and this finding fires with a cause that has nothing to do with the code. The frontend's own
`NETWORK_USAGE_INVESTIGATION` guidance names `bw_out_allowance_exceeded` explicitly and ends with the operative
sentence: *"If hitting ENA throttles, provision a larger instance to get more bandwidth if possible. IO
bottlenecks tend to mask any CPU performance gains."* **A flat-topped outbound series makes every CPU finding in
the report suspect**, because CPU gains cannot show up as throughput when the pipe is the limit.

**Why `Bad` (−2) rather than something heavier.** As with inbound: outbound volume legitimately varies with
response sizes, keep-alive behaviour, compression, ACK volume, and background traffic. The rule fires often and
is frequently benign, so it is calibrated as "check this before trusting the report". The consequence is the
same **ranking hazard**: −2 sorts below almost everything, while the finding can invalidate the comparison
above it.

**Bytes are not responses.** `IpExt:OutOctets` is IP-layer, system-wide, and includes TCP/IP headers, pure ACKs
(which for a receive-heavy workload can be a large share of outbound bytes), retransmissions, and every
non-workload sender on the box — monitoring agents shipping metrics, log forwarders, package managers, DNS, SSH,
and co-tenants. **On an ingest-heavy workload, outbound traffic can be almost entirely ACKs**, in which case
this finding is tracking ACK behaviour (coalescing, delayed-ACK settings, `TcpExt:DelayedACKs`) rather than
anything about responses.

**Processing detail with real consequences.** Cumulative counters via `add_accumulative_data_point`: values are
**per-interval deltas** with the **first sample forced to 0**. On a default 10-sample run that zero dilutes the
average by ~10% in both runs — cancelling only if the runs have the same `--period`/`--interval`. **Mismatched
sampling geometry can fire this rule with no traffic change at all.** A decreasing counter yields a **gap**
rather than a negative value, so a counter reset silently drops an interval and biases the average.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({cur_value}) is {pct_delta} {base_run} ({base_value}).
```

For this rule:

```
The average in aperf_record_new (412.88M) is 34.10% greater than aperf_record_base (307.89M).
```

Five things to know:

1. **The value is bytes per interval**, per-second only at the default `--interval 1`.
2. **The suffix is decimal.** `412.88M` = 412.88 million bytes ≈ 393.7 MiB; ×8 ⇒ ~3.3 Gbps at `--interval 1`.
   **Convert to bits before comparing against an instance's advertised bandwidth** — that is the units
   allowances are quoted in.
3. **The percentage is signed; the score uses the absolute value.** With `abs: true`, **the description text is
   the only place the direction appears** — and for outbound, direction is most of the meaning.
4. **Values are truncated to two decimals**, not rounded.
5. The average includes the **forced-zero first sample**, understating true mean throughput by roughly `1/n`.

Score math — `compute_finding_score(abs_ratio, 0.1, −2)`, general branch, `delta = abs_ratio/0.1`:

| abs ratio | meaning | score |
|---|---|---|
| 0.10 | exactly 10% — **fires** (`GreaterEqual`) | **−2.00** |
| 0.11 | 11% | −2.20 |
| 0.125 | 12.5% | −2.50 |
| 0.15 | 15% | −3.00 |
| 0.20 | 20% | −4.00 |
| 0.25 | 25% | −5.00 |
| 0.34 | 34% (the example above) | −6.80 |
| 0.50 | 50% | −10.00 |
| 1.00 | 2× the traffic | −20.00 |
| 2.00 | 3× | −40.00 |
| 5.00 | 6× | −100.00 |
| 10.00 | 11× | −200.00 |

Notes:

- **The zero trap does not apply** (threshold 0.1); the `value == 0.0` branch is unreachable since equal
  averages give ratio 0.0, which fails `>= 0.1`.
- **A ratio of exactly 1.0 may mean the base run's average was 0** — the template's `base_stat == 0.0`
  substitution. For outbound that means the base run transmitted essentially nothing: an idle base run, a
  receive-only workload, or a failed collection. Verify before reading it as "twice the traffic".

**MISCALIBRATION — the threshold is relative with no absolute floor, so this gate fires on an idle host.**
`time_series_stat_run_comparison_rule.rs:97-110` compares `|(cur - base) / base|` to `delta_ratio: 0.1` and
never asks whether the traffic is large enough for 10% to mean anything. Idle-host chatter — SSH keepalives,
DNS, monitoring agents, and aperf's own output — is a few kB/s and varies by multiples between runs.

Measured on this host, two runs **16 seconds apart, both idle, identical `--period 10 --interval 1`**:
`avg(IpExt:OutOctets)` went **3164.90 → 4146.54 B/s**, ratio 0.3102, score **−6.20**. The inbound gate fired
on the same pair at −61.91. A **1 kB/s** difference voided the comparison.

Outbound is the *noisier* of the two on an idle box, because an idle host transmits more than it receives —
this host's outbound average was 4× its inbound. **Read the absolute averages before the percentage**; see
STEP 3's first branch.

## Interpretation

**First, rule out sampling geometry and base-run problems:**

| Evidence | Reading |
|---|---|
| **`--interval`/`--period` differ between runs** | **Artifact.** Forced-zero first sample plus different interval widths move the average with no traffic change |
| Base run's `netstat` series empty or near-zero | A ratio of exactly 1.0 is substituted. Not a real 100% delta |
| Parameters match, both runs populated | The delta is real. Proceed |

**Then pair it with the inbound finding — the highest-value step:**

| Evidence | Reading |
|---|---|
| **`Inconsistent Inbound Network Traffic` also fired, same direction, similar magnitude** | **Load-volume difference.** Both directions scale with requests. Harness or deliberate change |
| **Inbound did *not* fire, outbound down** | **Throughput or response-size regression** — requests arrived, fewer response bytes returned. **The case worth chasing** |
| Inbound did not fire, outbound **up** | Response payloads grew, compression was lost, the protocol got chattier, or **retransmission inflated the count** |
| Inbound fired, outbound flat | Asymmetric — background/batch producer dominating egress, or an ingest-only workload |

**Then test the retransmission hypothesis — outbound-specific:**

| Evidence | Reading |
|---|---|
| **`TcpExt:TCPLostRetransmit`, `TCPRetransFail`, `TCPSynRetrans` grown** | **The extra bytes are the same work sent twice.** More outbound bytes, no more delivered payload |
| `TcpExt:TCPTimeouts` grown | Retransmission timeouts — worst-case retransmission, with latency cost attached |
| `TcpExt:TCPDSACKRecv`, `TcpDuplicateDataRehash` grown | The peer is telling you it received duplicates — spurious retransmission |
| `TcpExt:TCPSpuriousRtxHostQueues` grown | Retransmission caused by host queueing, not the network |
| All retransmission counters flat | The extra bytes are real payload. A genuine output difference |

**Then check for a ceiling — the most common non-workload cause of an outbound difference:**

| Evidence | Reading |
|---|---|
| **`bw_out_allowance_exceeded` non-zero** (`ena_stat`) | **Egress bandwidth allowance hit.** Outbound is capped by the instance. See `Outbound Bandwidth Allowance Exceeded`. **Makes every CPU finding suspect** — "IO bottlenecks tend to mask any CPU performance gains" |
| `pps_allowance_exceeded` non-zero | Packet-rate ceiling — small responses hit this before the byte ceiling |
| Outbound series **flat-topped** | A ceiling was reached, whatever the counters say |
| `conntrack_allowance_exceeded` non-zero | New connections dropped — a connection-per-request client stalls, reducing both directions |

**Then account for the ACK/header share:**

| Evidence | Reading |
|---|---|
| Workload is ingest-heavy, outbound ≪ inbound | **Outbound is mostly ACKs.** This finding tracks ACK behaviour, not responses |
| `TcpExt:DelayedACKs`, `TCPPureAcks` moved | ACK generation changed — coalescing, delayed-ACK tuning, or offload differences |
| `IpExt:OutBcastOctets`/`OutMcastOctets` material | Broadcast/multicast noise inflating the count |
| `TcpExt:TCPAutoCorking` moved | Small-write batching changed, altering segment and header overhead |

**Then read the series shape:**

| Observation | Reading |
|---|---|
| Ramp then steady | **Ramp dilution** — on `--period 10`, two ramp seconds move the average ~20%. Compare plateaus |
| Flat-topped | A ceiling. Go to the allowance counters |
| Collapse partway through | Something broke mid-run; the average hides it and scores mildly |
| Steady in both, plateaus differ | **A genuine throughput difference** — the cleanest version of this finding |

**Combinations:**

| also fired | Reading |
|---|---|
| **`Inconsistent Inbound Network Traffic`** | **Read them as one finding.** Same direction and magnitude ⇒ load volume; divergence ⇒ a real throughput or payload change |
| **`Outbound Bandwidth Allowance Exceeded`** | The ceiling explains the difference directly, and masks CPU gains |
| `Inconsistent Outbound EFA Traffics` | The same validity question on the RDMA path — and that playbook's `retrans_bytes` check is the same idea as the TCP retransmission check here |
| `Inconsistent Physical Memory` / `Inconsistent Number of CPUs` | **Different hardware ⇒ different network allowances.** Fix the mismatch first |
| `Kernel Version Mismatch` | Different congestion control defaults, offload behaviour, and buffer sizing |
| `Underutilized CPU` | Consistent with a network ceiling: the CPU is idle because the pipe is full. **A common and important pairing** |
| Any `perf_stat` or `cpu_utilization` improvement | **Discount it** until output parity is established — throughput may simply have been capped |

**Known false positives — a large share of firings:**

- **Ramp-up or warm-up** included in one run, especially on a short `--period`.
- **Different `--interval`/`--period`**, so the forced-zero sample does not cancel.
- **Retransmission differences** inflating bytes without delivering payload.
- **An ENA egress ceiling** capping one run.
- **Response-size, compression, or content-encoding changes** at constant request count.
- **ACK-dominated egress** on ingest-heavy workloads, where the finding tracks ACK behaviour.
- **Background senders** — metric shippers, log forwarders, package updates, backups. `netstat` is system-wide,
  and outbound is where agents are most visible.
- **Keep-alive/connection-reuse differences**, changing header and handshake byte volume.
- **An idle or receive-only base run**, forcing the ratio to exactly 1.0.
- **A closed-loop generator**, where a faster server produces more outbound bytes: **the improved run fires the
  rule.**
- **A deliberate load or payload change** — the finding is correct and expected.

**Blind spots:**

- **No response-count metric.** Byte parity is a proxy; response parity must come from the application or
  generator.
- **No per-connection or per-process attribution** — one dominating connection looks identical in aggregate,
  which is why the frontend's guidance recommends `watch netstat -t`.
- **Useful payload versus retransmitted payload is not separated in the metric** — you have to bring the
  retransmission counters to it.
- **Counter resets create gaps, not negatives**, biasing the average silently.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`Inconsistent Inbound Network Traffic` / `IpExt:InOctets`** | `netstat` | **Do this first.** In-versus-out divergence is where the meaning is |
| **`--interval`, `--period`, sample count for both runs** | run metadata / `aperf_stats` | Mismatched geometry fires this rule alone. **No analytical rules — read manually** |
| **`IpExt:OutOctets` series shape** | `netstat` | Ramp, flat-topped ceiling, collapse, or steady plateaus |
| **`TcpExt:TCPLostRetransmit`, `TCPRetransFail`, `TCPSynRetrans`, `TCPTimeouts`** | `netstat` | **Whether extra bytes are retransmission rather than work** — the outbound-specific check |
| `TcpExt:TCPDSACKRecv`, `TcpDuplicateDataRehash`, `TCPSpuriousRtxHostQueues` | `netstat` | Spurious retransmission and host-queue-induced resends |
| `TcpExt:TCPOrigDataSent` | `netstat` | Original (non-retransmitted) data sent — the closest thing to "useful payload" |
| `TcpExt:DelayedACKs`, `TCPPureAcks`, `TCPAutoCorking` | `netstat` | ACK volume and small-write batching, which dominate egress on ingest-heavy workloads |
| `TcpExt:TCPToZeroWindowAdv`, `WantZeroWindowAdv` | `netstat` | The *peer* throttling you, limiting what you can send |
| `TcpExt:TCPMemoryPressures`, `TCPAbortOnMemory` | `netstat` | Socket memory limiting transmission |
| `IpExt:OutBcastOctets`, `OutMcastOctets`, `OutBcastPkts` | `netstat` | Non-unicast noise inflating the count |
| **`tx_bytes`, `tx_pkts`, `tx_drops`** | `ena_stat` | **Driver-level cross-check** against the IP-layer count |
| **`bw_out_allowance_exceeded`, `pps_allowance_exceeded`, `conntrack_allowance_exceeded`, `linklocal_allowance_exceeded`** | `ena_stat` | **Whether a ceiling capped egress.** Named explicitly in the frontend's guidance. See the allowance playbooks |
| `tx_bytes` per-queue spread | `ena_stat` | One hot queue ⇒ one dominating connection |
| `Inconsistent Outbound EFA Traffics`, `retrans_bytes`/`retrans_pkts` | `efa_stat` | The same work-versus-resend question on the RDMA path |
| Instance type, vCPU count, bandwidth class | `systeminfo` | **Required** to judge whether the observed Gbps is near an allowance |
| `Inconsistent Number of CPUs`, `Inconsistent Physical Memory` | `systeminfo`, `meminfo` | Hardware mismatch changes allowances and invalidates the comparison |
| `aggregate`, `system`, `softirq`, `idle` | `cpu_utilization` | Whether CPU tracked the output change — and whether idle CPU points at a network ceiling |
| Interrupt distribution | `interrupts` | Transmit processing concentrated on one core. **No analytical rules — read manually** |
| `net.ipv4.tcp_congestion_control`, `net.core.wmem_*`, offload settings | `sysctl` | Congestion control and buffer differences that change retransmission and byte accounting. **No analytical rules — read manually** |
| Application response sizes, compression/content-encoding, generator model | out of band | **Required.** aperf sees bytes, not responses |

## Guidance

Ordered. **Steps 1–4 close most firings.**

1. **Read the inbound finding first.** `Inconsistent Inbound Network Traffic` and this one are one diagnosis
   split in two. Moving together ⇒ load volume; **inbound flat while outbound fell ⇒ a genuine throughput or
   response-size regression**, which is the case worth chasing.

2. **Confirm `--interval` and `--period` match, and that the base run has data.** Per-interval deltas with a
   forced-zero first sample mean mismatched geometry fires this rule on its own; an empty base run manufactures
   a ratio of exactly 1.0.

3. **Check for an egress ceiling.** Read `bw_out_allowance_exceeded` and `pps_allowance_exceeded` in `ena_stat`,
   and look for a flat-topped series. **Above an allowance, outbound bytes are set by the instance, not the
   workload** — and per the frontend's own guidance, "IO bottlenecks tend to mask any CPU performance gains", so
   every CPU finding in the report becomes suspect.

4. **Test whether extra bytes are retransmission rather than work.** Read `TCPLostRetransmit`, `TCPRetransFail`,
   `TCPSynRetrans`, and `TCPTimeouts`, and compare `TCPOrigDataSent`. **More outbound bytes with more
   retransmission is not more work** — it is the same work sent twice, with latency cost attached.

5. **Establish the egress composition.** On an ingest-heavy workload outbound may be almost entirely ACKs, in
   which case this finding is about ACK behaviour (`DelayedACKs`, coalescing, offload) and not about responses at
   all.

6. **Look at the series shape before trusting the average.** Ramp-up, a mid-run collapse, and different steady
   plateaus all average to the same number. On short runs compare plateaus.

7. **Know the generator's concurrency model.** Under a **closed-loop** generator, a faster server transmits more
   — so **the improved run fires this rule.** aperf does not record this; you must supply it.

8. **Cross-check `ena_stat` `tx_bytes`.** Driver and IP-layer counts should move together; disagreement means
   tunnels, encapsulation, a second interface, or layer-specific accounting.

9. **Subtract background senders.** `netstat` is system-wide and egress is where agents show up most: metric
   shippers, log forwarders, backups, package updates.

10. **Do not let the score set your priority.** At `Bad` (−2) this sorts below nearly everything, yet it can
    invalidate the comparison — and combined with `Underutilized CPU` it often *is* the story: the CPU is idle
    because the network is the limit.

11. **If one connection dominates, investigate that specifically** — `watch netstat -t` per the frontend
    guidance, and per-queue `tx_bytes` spread in `ena_stat` as the in-report equivalent. A single connection can
    saturate one core and bottleneck the system.

12. **If a ceiling is confirmed and more bandwidth is needed, a larger instance is the documented remedy** —
    the frontend's guidance says so directly. Re-establish output parity before re-reading the rest of the
    report.

## Priority and execution risk

**Priority: P0 — Blocking** for throughput comparisons at large deltas; **P2 — Investigate** in the 10–25% band.

**Execution risk: R0 — Read-only.** Fix the load generation and re-run.

Scored **`Bad` (−2)** — mild relative to what it invalidates. **Do not let the score set your priority.**

**Outbound is the more diagnostic direction of the pair.** Inbound is largely controlled by the client;
outbound is what the system under test *produced*, so an outbound delta with matched inbound is usually a real
result rather than a load-generator artifact.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `|avg(IpExt:OutOctets) delta| >= 10%` versus the base run.

```
STEP 1 — Parse the observed values.
  Format: The avg in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).
  T/G/M/K suffixes at 2 dp. Score: 10% -> -2, 50% -> -10, 100% -> -20.
  Comparator is GreaterEqual: exactly 10.00% fires.

  IF the delta reads exactly `100.00% greater than`
  THEN → AMBIGUOUS: hardcoded delta ratio of 1.0 when the base is 0 (P2, R0)
       → verify the base value in the description

STEP 2 — Cross-reference INBOUND first. This is the primary discrimination.
  IF inbound matched (no inbound finding) AND outbound differs
  THEN → SAME REQUESTS, DIFFERENT RESPONSES. This is usually a REAL RESULT (P1, R0)
       → response payload size changed (serialization, compression, verbosity)
       → error responses replacing success responses (smaller or larger)
       → a caching layer engaging or disengaging
       → verify: this is the highest-signal case for the pair — investigate the
         application, do not dismiss it as a load artifact
  IF both inbound and outbound differ proportionally
  THEN → a load-LEVEL difference: a genuine confound (P0, R0)
  IF outbound fell while inbound held
  THEN → the system produced less per request: suspect errors, truncated
         responses, or a saturated egress path (P1, R0)
       → verify: check ENA outbound allowance findings and `cpu_utilization`

STEP 3 — Check the ABSOLUTE traffic level, then size the delta.
  The rule has no absolute floor, so the percentage is meaningless at idle.
  IF EITHER average is under ~100 KB per interval (~100 KB/s at --interval 1)
  THEN → NOISE, not a load-parity problem. FALSE POSITIVE (P3, R0)
       → verify: `p50` versus `avg`, and `max` versus `p90`. A single burst
         moves `avg` and leaves `p50` alone
       → observed on this host: two IDLE runs 16 s apart fired at -6.20 on
         3164.90 -> 4146.54 B/s, a 1 kB/s difference, while the inbound gate
         fired on the same pair at -61.91
       → do NOT void the report. Proceed to the other findings
  IF both averages are workload-scale, size the delta:
    IF |delta| is 10-25%   → variance, warm-up, or ramp skew; check the graph (P2, R0)
    IF |delta| is 25-100%  → materially different work; throughput void (P0, R0)
    IF |delta| > 100%      → configuration or topology difference (P0, R0)

STEP 4 — Check for an egress ceiling rather than a workload change.
  IF outbound is LOWER in the compared run
  AND ENA outbound bandwidth/PPS allowance findings are present
  THEN → the instance hit its egress ceiling; traffic was SHAPED, not offered
         differently (P1, R4)
       → this is a real, actionable finding — see the ENA allowance playbooks
       → the gate is reporting a consequence of saturation, not a confound
       → verify: after lifting the ceiling (larger instance, or ENA Express where
         the traffic pattern suits it), the `bw_out_allowance_exceeded` counter
         should stop incrementing AND outbound bytes should rise. If the counter
         clears but bytes do not rise, the ceiling was not the limit

STEP 5 — What survives?
  VALID  : configuration findings, ENA/EFA saturation flags
  VOID   : throughput comparisons, per-request efficiency, cpu_utilization deltas,
           the statistical table for rate metrics
  CAUTION: HOST-WIDE across all interfaces — includes monitoring agents, log
           shipping, and the aperf process itself. On a low-traffic host,
           background egress can dominate and produce a spurious delta

INSUFFICIENT DATA
  IF the base run lacks the `IpExt:OutOctets` metric
  THEN → rule returned early; NO finding produced (P1, R0)
```

## Runtime-specific consequences

Outbound byte volume is dominated by *serialization and compression choices*, which are runtime-level settings
that change without any application logic change:

| Runtime | What silently changes outbound volume | Risk to change deliberately |
|---|---|---|
| **Java** | Jackson/Gson configuration, gzip filter presence, HTTP/2 vs 1.1 framing, `Content-Encoding` negotiation | R2 — config and restart |
| **.NET** | `System.Text.Json` vs Newtonsoft defaults, response compression middleware, Kestrel HTTP/2 | R2 |
| **Python** | Framework middleware ordering (gzip), `json` vs `orjson`, WSGI vs ASGI chunking | R2 |
| **Perl** | Output buffering and `Compress::Zlib`/mod_deflate layering | R2 |

**A dependency or framework upgrade that changes default compression will fire this gate and no other finding.**
When inbound matched and outbound moved by a large factor, check the serialization and compression path before
suspecting anything about CPU or memory — this is the single most common real cause, and it is invisible to
every other aperf finding.

## Architecture-specific considerations

The ENA and netstat counters themselves are architecture-neutral — the same driver counters on the same
interface, read the same way on Intel, AMD, and arm64. Architecture matters here for a different reason:
**a traffic delta is very often the visible half of an architecture migration**, and this gate is one of the
few that will actually fire when the migration is not like-for-like.

Confirm architecture from `pmu_config.json` in each run before reading the delta
([ARCHITECTURE.md](../ARCHITECTURE.md) §1), because none of the hardware gates will tell you.

| Observed | Reading | Action |
|---|---|---|
| Traffic delta present, architectures identical | Read as a normal workload-parity question | Follow the tree above |
| Traffic delta present, architectures **differ** | The delta is a *symptom* of the platform change, not an independent variable. Serving less traffic on the new architecture usually means the application is slower there | Investigate the platform difference first, not the load generator (P1, R0) |
| Traffic matched, architectures differ | Genuinely comparable load — the most useful cross-architecture comparison you can get | Proceed, but `perf_stat` remains incomparable in meaning (P2, R0) |

**Instance-family bandwidth ceilings are not portable.** The same nominal size in different families has
different baseline and burst network allowances, and the ENA allowance findings compare against whatever the
running instance actually has. A traffic delta accompanied by allowance exceedances on only one side is usually
a ceiling difference, not an application difference (P0 for the throughput comparison, R4 to fix).

**Where architecture genuinely changes network cost:**

- **SMT.** Graviton has no SMT; x86 with SMT enabled reports 2× logical CPUs for the same physical core count.
  Per-connection and per-queue processing lands on physical cores, so a "same vCPU count" comparison gives the
  arm64 side twice the physical capacity for interrupt and softirq handling. Cross-check `cpu_utilization`'s
  `softirq` and `irq` series.
- **Number of ENA queues** typically follows vCPU count, so a size change alters queue count and per-queue load
  distribution. aperf does not collect queue counts directly.
- **TLS and compression paths** are where arm64 differs most: AES/GCM and CRC benefit from hardware
  instructions, but only if the runtime uses them. On the JVM this needs a recent JDK; for Python and .NET it
  depends on the linked OpenSSL build. An unmet request here reduces achievable throughput on arm64 and shows
  up as a traffic delta with elevated `user` CPU time.
- **Serialization/compression library builds** — the most common invisible cause of an outbound delta. A
  compression or protobuf library that fell back to a generic build on the new architecture changes payload
  sizes and CPU cost together ([ARCHITECTURE.md](../ARCHITECTURE.md) §5.3).

None of the above is collected by aperf. Capture the runtime's crypto and compression provider list manually
when the two runs differ in architecture.

## Verification

Match the load generation, re-run, and confirm the finding disappears. If inbound matches and outbound still
differs, the response path genuinely changed — pursue it as a result rather than a confound.

## Do not

- **Do not read this in isolation.** Its meaning comes from the comparison with the inbound finding.
- **Do not apply the message's "load generator" framing literally to outbound.** Outbound is work the system
  *produced*; less out with the same in is a regression, not a harness problem.
- **Do not equate more outbound bytes with more work done.** Retransmission is counted again — check
  `TCPLostRetransmit`, `TCPRetransFail`, and `TCPOrigDataSent`.
- **Do not ignore ENA egress allowances.** Above the ceiling the workload does not control outbound bytes, and
  CPU gains cannot appear as throughput.
- **Do not read the value as bytes per second** unless `--interval` is 1; convert to bits before comparing with
  an instance's advertised bandwidth.
- **Do not assume outbound bytes are responses** on an ingest-heavy workload — they may be almost all ACKs.
- **Do not expect the score to show direction.** `abs: true` — only the description text is signed.
- **Do not rank by score.** −2 base sorts it last while it can invalidate everything above it.
- **Do not compare runs with different `--interval`/`--period`.** The forced-zero first sample will not cancel.
- **Do not read a ratio of 1.0 as "twice the traffic"** without confirming the base run transmitted anything.
- **Do not blame the workload without excluding background senders and co-tenants.** `netstat` is system-wide.
- **Do not interpret the direction without knowing the generator's concurrency model.**

## References

- Rule definition: `src/analytics/rules/netstat.rs:21` — `metric: "IpExt:OutOctets"`, `stat: Stat::Average`,
  `comparator: Comparator::GreaterEqual`, `abs: true`, `delta_ratio: 0.1`, `score: Score::Bad`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — skips the base run,
  returns early if the base run lacks the metric, substitutes `original_delta_ratio = 1.0` when
  `base_stat == 0.0`, applies `abs()` to the comparison ratio only, and renders the **signed** ratio.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Bad = −2`,
  `src/analytics/mod.rs:147`.
- Formatting: `formatted_number_string`, `src/computations/mod.rs:176` (decimal K/M/G/T, **truncated** to 2
  decimals); `delta_ratio_to_percentage_string`, `src/computations/mod.rs:162`.
- Collection and parsing: `src/data/netstat.rs` — reads `/proc/net/netstat`; metric names are `prefix + name`
  (`IpExt:` + `OutOctets`).
- **Delta processing:** all metrics via `add_accumulative_data_point`
  (`src/data/common/time_series_data_processor.rs:130`) ⇒ **per-interval deltas**, first sample forced to 0
  (`ignore_first_accumulative_value: true`, `:73`); a **decreasing** counter returns `None`
  (`get_delta_and_set_previous_value`, `:189`) producing a **gap**, not a negative value.
- Aggregation: `time_series_data_processor_with_custom_aggregate!`, one `netstat` series per metric ⇒ **no
  auto-generated `average` series**.
- Metric semantics: `IpExt:OutOctets` at `data-descriptions.ts:3527` (`unit: "Bytes"`, `desired: "depends"`,
  `optimization: [NETWORK_USAGE_INVESTIGATION]`); `TcpExt:TCPOrigDataSent` :3102,
  `TcpExt:TCPLostRetransmit` :3108, `TcpExt:TCPRetransFail` :2815, `TcpExt:TCPSynRetrans` :2826,
  `TcpExt:TCPTimeouts` :3317, `TcpExt:DelayedACKs` :2946.
- Frontend guidance: `NETWORK_USAGE_INVESTIGATION`,
  `src/report_frontend/src/definitions/optimization-guides.ts:18` — `watch netstat -t`, then
  `bw_out_allowance_exceeded` and the other ENA allowance counters; "If hitting ENA throttles, provision a
  larger instance… IO bottlenecks tend to mask any CPU performance gains."
- Related playbooks: `inconsistent-inbound-network-traffic.md`,
  `../ena_stat/outbound-bandwidth-allowance-exceeded.md`, `../ena_stat/pps-allowance-exceeded.md`,
  `../ena_stat/conntrack-allowance-exceeded.md`, `../efa_stat/inconsistent-outbound-efa-traffics.md`,
  `../cpu_utilization/underutilized-cpu.md`, `../meminfo/inconsistent-physical-memory.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`.
- [Graviton perfrunbook — check network usage](https://aws.github.io/graviton/perfrunbook/debug_system_perf.html#check-network-usage)
- [proc_net_netstat / SNMP counters](https://www.kernel.org/doc/html/latest/networking/snmp_counter.html)
