---
rule_name: Inconsistent Inbound Network Traffic
data_type: netstat
data_key: IpExt:InOctets
template: time_series_stat_run_comparison
condition: "abs(delta_avg(IpExt:InOctets)) >= 0.1"
base_score: Bad
score_sign: negative
requires_comparison: true
aperf_message: "The average number of bytes received by the network interface is different. Verify that the load generator is providing the expected traffic, if the system is under tests."
source: src/analytics/rules/netstat.rs:11
---

# Inconsistent Inbound Network Traffic

## What fired

The **average** per-interval delta of `IpExt:InOctets` differs from the base run by **10% or more in either
direction** (`abs: true`). `IpExt:InOctets` is "Total number of bytes received by the network interface at the
IP layer" (`data-descriptions.ts:3169`, `unit: "Bytes"`, `desired: "depends"`).

Base score `Bad` (**−2**). Comparison-only: it cannot fire on a single-run report.

**This is a load-validity gate, not a performance finding** — and the rule's own message says so:
*"Verify that the load generator is providing the expected traffic, if the system is under tests."* It is
telling you the two runs may not have been given the same work. Resolve that before attributing any other
delta in the report to the code under test.

## Reasoning

**Why this rule exists at all, and why it is the most important cheap check in a comparison report.** Almost
every meaningful comparison in aperf assumes the two runs did the same amount of work. For a server workload,
inbound bytes are the closest thing aperf collects to a *request-volume* proxy: fewer bytes in means fewer
requests handled, which lowers CPU, lowers IPC pressure, lowers memory traffic, and improves per-request
latency — all of which will look like an *improvement* in the rest of the report. **A quiet 15% shortfall in
offered load can manufacture an apparent win across a dozen other findings.** That is the failure mode this
rule is built to catch, and it is why `abs: true`: more traffic invalidates the comparison exactly as
thoroughly as less.

**Why the score is only `Bad` (−2), the mildest of aperf's "something is wrong" tiers.** Traffic volume is
*expected* to vary. Load generators ramp, keep-alive and connection-reuse patterns shift byte counts without
shifting request counts, and a faster server pulls *more* traffic through in the same wall-clock window. So the
rule fires often and is frequently benign. `Bad` is calibrated for "look at this before you trust the report",
not "this is a defect". Compare with `meminfo`'s `Inconsistent Physical Memory` at `Critical` (−256): different
RAM is unambiguously wrong, whereas different traffic often is not.

**The causal ambiguity that makes this rule genuinely hard to read — and it runs both ways.** Inbound bytes
are *both* an input and an output of system performance:

- **As an input:** the load generator offered less traffic ⇒ the system did less work. The comparison is
  invalid; fix the harness.
- **As an output:** the system under test was slower, so it accepted connections more slowly, advertised
  smaller windows, or backed up its receive queues ⇒ *less traffic arrived*. Here the traffic drop is a
  **symptom of a real regression**, and dismissing it as a harness problem hides the actual bug.

Aperf cannot distinguish these from `netstat` alone, and the rule makes no attempt to. **The discriminator is
whether the system shows back-pressure**: `TcpExt:ListenOverflows`, `TcpExt:ListenDrops`,
`TcpExt:TCPBacklogDrop`, `TcpExt:TCPRcvQDrop`, `TcpExt:TCPToZeroWindowAdv`, and
`TcpExt:TCPFromZeroWindowAdv`. Back-pressure present with less traffic ⇒ the system pushed the load away, which
is a regression. Less traffic with no back-pressure at all ⇒ the load simply was not offered.

**A closed-loop generator inverts the whole reading — this is the trap most worth internalizing.** With a
fixed-concurrency, closed-loop generator (a fixed thread or connection count issuing requests back to back),
throughput is *determined by* server latency. A **faster** server therefore receives **more** inbound bytes,
and this finding fires on the run that improved. Under an open-loop generator (fixed request rate), inbound
bytes should be flat and a difference genuinely points at the harness. **You cannot interpret the direction of
this finding without knowing which kind of generator produced the load** — and aperf does not record that.

**Bytes are not requests, and for the inbound direction that gap is wide.** `IpExt:InOctets` counts IP-layer
bytes: payload plus TCP/IP headers, plus ACKs, retransmissions, and every non-workload packet on the box —
health checks, monitoring agents, SSH, package updates, DNS, and any co-tenant traffic. It is **system-wide and
protocol-level**. So a 10% byte difference can come from a change in average request size, a change in
MTU/segmentation behaviour, an ACK-ratio change (GRO/LRO coalescing, `TcpExt:TCPRcvCoalesce`), or a background
process — with the actual request count unchanged. **Request-count parity has to be established from the load
generator's own numbers, not from here.**

**Why the average is the right stat and where it misleads.** Averaging the per-interval deltas over the run
gives mean throughput, which is what you want for a load-parity check. But it hides shape completely: a run
that ramped for 3 seconds then held steady averages the same as one that was steady throughout, and a run whose
traffic collapsed halfway through averages out to something mild. **On the default `--period 10`, a two-second
ramp is 20% of the run** — enough to fire this rule on its own. Always look at the series before accepting the
average.

**One processing detail with real consequences.** These are cumulative kernel counters processed with
`add_accumulative_data_point`, so the reported values are **per-interval deltas** with the **first sample forced
to 0** (`ignore_first_accumulative_value: true`). On a 10-sample default run, that zero is one tenth of the
samples and **drags the average down by ~10% in both runs**. It largely cancels between runs of equal length —
but **if the two runs have different `--period` or `--interval`, it does not cancel**, and the rule can fire on
sampling geometry alone. Check the run parameters before anything else.

## Reading the description

`time_series_stat_run_comparison` emits:

```
The {stat} in {run} ({cur_value}) is {pct_delta} {base_run} ({base_value}).
```

For this rule:

```
The average in aperf_record_new (81.42M) is 23.45% less than aperf_record_base (106.36M).
```

Five things to know:

1. **The value is bytes per interval, not per second** — per-second only at the default `--interval 1`. At
   `--interval 5`, `81.42M` is ~16.3 MB/s, not 81 MB/s.
2. **The suffix is decimal** (`formatted_number_string` divides by 1e6 for `M`), so `81.42M` is 81.42 million
   bytes ≈ 77.6 MiB. Multiply by 8 for bits: ~651 Mbps at `--interval 1`.
3. **The percentage in the text is signed; the score uses the absolute value.** `abs: true` applies to the
   comparison and the score only, so **the text is the only place the direction appears.** Read it.
4. **Values are truncated to two decimals**, not rounded.
5. The average includes the **forced-zero first sample**, so it understates true mean throughput by roughly
   `1/n`.

Score math — `compute_finding_score(abs_ratio, 0.1, −2)`, general branch, `delta = abs_ratio/0.1`:

| abs ratio | meaning | score |
|---|---|---|
| 0.10 | exactly 10% — **fires** (`GreaterEqual`) | **−2.00** |
| 0.11 | 11% | −2.20 |
| 0.125 | 12.5% | −2.50 |
| 0.15 | 15% | −3.00 |
| 0.20 | 20% | −4.00 |
| 0.25 | 25% | −5.00 |
| 0.50 | 50% | −10.00 |
| 1.00 | 2× the traffic | −20.00 |
| 2.00 | 3× | −40.00 |
| 5.00 | 6× | −100.00 |
| 10.00 | 11× | −200.00 |
| 100.00 | 101× — e.g. near-idle base run | −2000.00 |

Two notes:

- **The zero trap does not apply** (threshold 0.1, not 0.0), and the `value == 0.0` branch is unreachable: equal
  averages give ratio 0.0, which fails `>= 0.1`.
- **The base score of −2 means this finding sorts near the bottom of a score-ordered list** unless the ratio is
  huge. That is a **ranking hazard**: a load-parity problem that invalidates the whole report scores −3 while a
  single `Poor` finding scores −16. **Read this finding first regardless of where it sorts.**

**A ratio of exactly 1.0 may mean the base run's average was 0.** The template substitutes
`original_delta_ratio = 1.0` when `base_stat == 0.0`. For this metric that means the base run received
essentially no traffic — an idle base run or a failed collection, not "twice the traffic". Check the base run's
`netstat` series before reading a 100% delta literally.

**MISCALIBRATION — the threshold is purely relative, so this gate fires on an idle host.**
`time_series_stat_run_comparison_rule.rs:97-110` computes `(cur - base) / base` and compares the magnitude to
`delta_ratio: 0.1`. There is **no absolute floor**: nothing in the rule requires the traffic to be large enough
for a 10% difference to mean anything. On a machine doing nothing, background SSH, DNS, and monitoring chatter
is a few hundred bytes per second and varies by multiples between runs, so the ratio test passes trivially.

Measured on this host — two runs recorded **16 seconds apart, both idle, identical `--period 10 --interval 1`**:

| | base (`quiet_a`) | current (`quiet_b`) | ratio | score |
|---|---|---|---|---|
| `avg(IpExt:InOctets)` | 791.36 B/s | 3241.09 B/s | 3.0956 | **−61.91** |
| `avg(IpExt:OutOctets)` | 3164.90 B/s | 4146.54 B/s | 0.3102 | **−6.20** |

Both gates fired. The inbound score of **−61.91** outranks every genuine finding in that report, and the entire
difference is **2.4 kB/s** — one burst of 23 kB in a single 1-second sample (`max` 23432 vs 1291) against an
otherwise identical baseline. `p50` actually went **down**, 818 → 572.

So the score is a measure of *relative* difference, and at near-zero traffic it is a measure of nothing. A
score of −61.91 does not mean this is 30× worse than a −2.00 firing; it means the base was small. **Before
believing any score from this rule, read the absolute averages.** Two runs on an idle host will essentially
always trip this gate, which means it cannot be used as a gate on a lightly loaded system at all — see
STEP 2's first branch.

## Interpretation

**First, rule out sampling geometry:**

| Evidence | Reading |
|---|---|
| **`--interval` or `--period` differ between runs** | **Artifact.** The forced-zero first sample and differing interval widths change the average without any traffic change. Re-run with matched parameters |
| Runs have different sample counts | Same problem, milder. The `1/n` zero-sample dilution differs between runs |
| Parameters match | The delta is real. Proceed |

**Then decide input versus output — the central question:**

| Evidence | Reading |
|---|---|
| **`TcpExt:ListenOverflows`, `ListenDrops`, `TCPBacklogDrop` non-zero or grown** | **The system pushed load away.** Traffic is an *output* here: this is a real regression, not a harness problem. The most important discriminator |
| **`TcpExt:TCPRcvQDrop`, `RcvPruned`, `PruneCalled` grown** | Receive buffers overflowing — the application is not draining sockets fast enough. Regression |
| **`TcpExt:TCPToZeroWindowAdv` grown** | The receiver advertised a zero window: **flow control throttled the sender.** Classic "slow consumer" signature |
| `TcpExt:TCPFromZeroWindowAdv` grown | Recovering from zero windows — the same story, intermittently |
| `TcpExt:TCPAbortOnMemory`, `TCPMemoryPressures` non-zero | Socket memory exhaustion. Cross-check `Reduced Memory Availability` |
| **No back-pressure counters moved at all** | **The load was simply not offered.** Harness problem — the most common case |
| `TcpExt:TCPTimeouts`, `TCPSynRetrans` grown | Connection setup or delivery struggled. Could be either side |

**Then account for the byte-count-versus-request-count gap:**

| Evidence | Reading |
|---|---|
| `IpExt:InOctets` down but `TcpExt:TCPOrigDataSent`/segment counts flat | **Request size changed, not request count.** Payload, compression, or header differences |
| `TcpExt:TCPRcvCoalesce` moved a lot | GRO/LRO coalescing differences change segment accounting, not bytes — check whether `netstat` and `ena_stat` agree |
| `IpExt:InOctets` and `ena_stat` `rx_bytes` **disagree in direction** | Something is being counted at only one layer — tunnels, encapsulation, or a second interface |
| `IpExt:InBcastOctets`/`InMcastOctets` material | Broadcast/multicast noise is inflating the count |
| `IpExt:InCsumErrors`, `InTruncatedPkts`, `InNoRoutes` non-zero | Corruption or misrouting — some received bytes never became work |

**Then check for a throttle ceiling, which caps traffic regardless of offered load:**

| Evidence | Reading |
|---|---|
| **`bw_in_allowance_exceeded` non-zero** (`ena_stat`) | **Inbound bandwidth allowance hit.** The instance could not accept more; offered load is irrelevant above the cap. See `Inbound Bandwidth Allowance Exceeded` |
| `pps_allowance_exceeded` non-zero | Packet-rate ceiling, not byte ceiling — small packets hit this first |
| `conntrack_allowance_exceeded` non-zero | Connection-tracking limit — new connections dropped, so a connection-per-request generator stalls |
| `linklocal_allowance_exceeded` non-zero | Link-local (DNS/IMDS/NTP) throttling — often breaks the generator, not the data path |
| Traffic **flat-topped** in the series | A ceiling was reached. Look for the allowance counters |

**Then read the series shape:**

| Observation | Reading |
|---|---|
| Ramp at the start, then steady | **Ramp dilution.** On `--period 10`, two ramp seconds move the average ~20%. Compare the steady-state plateaus instead |
| Collapse partway through | Something broke mid-run. The average hides it and scores mildly |
| Steady in both runs, plateaus differ | **A genuine throughput difference.** The cleanest version of this finding |
| Spiky/bursty in one run only | Generator scheduling or coordinated omission. Harness-side |

**Combinations:**

| also fired | Reading |
|---|---|
| **`Inconsistent Outbound Network Traffic`** | **Both directions moved.** Strongly suggests a load-volume difference rather than a subtle protocol change. Read them as one finding |
| Inbound fired, outbound did **not** | Asymmetric — request size or ingest-only behaviour changed while responses did not. Suspicious of a payload change |
| `Inconsistent Physical Memory` / `Inconsistent Number of CPUs` | **Different hardware.** Different instance sizes have different network allowances; fix the hardware mismatch first |
| `Kernel Version Mismatch` | Different stack tuning, GRO behaviour, and defaults. A second confound |
| `Underutilized CPU` | Consistent with less work offered — likely the same root cause, not two findings |
| `Inbound Bandwidth Allowance Exceeded` | A ceiling explains the traffic difference directly |
| Any `perf_stat` or `cpu_utilization` delta | **Discount it** until load parity is established |

**Known false positives — a large share of firings:**

- **Ramp-up or warm-up periods** included in one run, especially on a short `--period`.
- **A closed-loop load generator**, where traffic tracks server speed: **the faster run fires the rule.**
- **Different `--interval`/`--period`**, so the forced-zero sample and interval width do not cancel.
- **Background traffic** — monitoring, health checks, package updates, SSH, IMDS. `netstat` is system-wide.
- **Request-size or compression changes** at constant request count.
- **Keep-alive / connection-reuse differences**, which change header bytes and ACK volume substantially.
- **GRO/LRO or offload configuration differences** between hosts.
- **An idle or failed base run**, which forces the ratio to exactly 1.0.
- **A deliberate load-level change** — the finding is correct and expected.

**Blind spots:**

- **No request-count metric.** aperf has no notion of requests, so byte parity is a proxy. Request parity must
  come from the generator.
- **No per-connection or per-process attribution.** A single dominating connection saturating one core looks
  identical in aggregate — which is exactly why the frontend's own guidance says to run `watch netstat -t`.
- **A decreasing counter yields a gap, not a negative value.** Counter resets (interface reset, namespace
  change) drop that interval from the series entirely, biasing the average.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`--interval`, `--period`, sample count for both runs** | run metadata / `aperf_stats` | **Do this first.** Mismatched geometry fires this rule on its own. **No analytical rules — read manually** |
| **`IpExt:InOctets` series shape in both runs** | `netstat` | Ramp versus steady versus collapse. The average hides all of it |
| **`TcpExt:ListenOverflows`, `ListenDrops`, `TCPBacklogDrop`** | `netstat` | **The input-versus-output discriminator.** Non-zero ⇒ the system rejected load ⇒ regression |
| `TcpExt:TCPRcvQDrop`, `RcvPruned`, `PruneCalled`, `OfoPruned` | `netstat` | Receive buffers overflowing — application not draining sockets |
| **`TcpExt:TCPToZeroWindowAdv`, `TCPFromZeroWindowAdv`, `WantZeroWindowAdv`** | `netstat` | **Flow control throttling the sender** — the slow-consumer signature |
| `TcpExt:TCPAbortOnMemory`, `TCPMemoryPressures` | `netstat` | Socket memory exhaustion |
| `TcpExt:TCPTimeouts`, `TCPSynRetrans`, `TCPLostRetransmit`, `TCPRetransFail` | `netstat` | Delivery and setup trouble on the wire |
| `TcpExt:TCPOFOQueue`, `TCPOFODrop`, `TCPDSACKRecv` | `netstat` | Reordering and duplicate delivery |
| `IpExt:InCsumErrors`, `InTruncatedPkts`, `InNoRoutes` | `netstat` | Received bytes that never became work |
| `IpExt:InBcastOctets`, `InMcastOctets`, `InBcastPkts` | `netstat` | Non-unicast noise inflating the byte count |
| `TcpExt:TCPRcvCoalesce`, `BusyPollRxPackets` | `netstat` | Coalescing and polling differences that shift accounting |
| **`rx_bytes`, `rx_pkts`, `rx_drops`** | `ena_stat` | **Driver-level cross-check.** Disagreement with `netstat` means counting at different layers |
| **`bw_in_allowance_exceeded`, `pps_allowance_exceeded`, `conntrack_allowance_exceeded`, `linklocal_allowance_exceeded`** | `ena_stat` | **Whether a ceiling capped the traffic.** The frontend's own guidance points here. See the allowance playbooks |
| `rx_bytes` per-queue spread | `ena_stat` | One hot queue means one dominating connection |
| `Inconsistent Inbound EFA Traffics` | `efa_stat` | If EFA is in play, the same validity question for the RDMA path |
| Instance type, vCPU count, network allowance class | `systeminfo` | **Different sizes have different allowances.** Required context |
| `Inconsistent Number of CPUs`, `Inconsistent Physical Memory` | `systeminfo`, `meminfo` | Hardware mismatch invalidates everything, including allowances |
| `aggregate`, `system`, `softirq`, `idle` | `cpu_utilization` | Less traffic ⇒ less `softirq` and `system`. Confirms the work difference is real |
| Interrupt counts per CPU | `interrupts` | Whether receive processing is concentrated on one core. **No analytical rules — read manually** |
| `net.core.*`, `net.ipv4.tcp_*` tunables | `sysctl` | Buffer sizes, backlog, and congestion control differences. **No analytical rules — read manually** |
| Load-generator request counts, concurrency model, ramp settings | out of band | **Required.** aperf cannot see request counts or whether the generator is open- or closed-loop |

## Guidance

Ordered. **Steps 1–4 close most firings.**

1. **Confirm `--interval` and `--period` match between the runs.** Values are per-interval deltas with the
   first sample forced to 0, so mismatched geometry moves the average without any traffic change. Cheapest
   possible refutation.

2. **Confirm the base run is the one you meant, and that its `netstat` data is populated.** A ratio of exactly
   1.0 is what the template substitutes when the base average is 0 — an idle base run or a collection failure,
   not "twice the traffic".

3. **Decide whether traffic is an input or an output.** Read `TcpExt:ListenOverflows`, `ListenDrops`,
   `TCPBacklogDrop`, `TCPRcvQDrop`, and `TCPToZeroWindowAdv`. **Any of them moving means the system pushed load
   away — that is a regression, and the traffic drop is its symptom.** All quiet means the load was not
   offered: a harness problem.

4. **Establish which concurrency model the generator uses.** Under a **closed-loop** generator, inbound traffic
   is proportional to server speed, so **the faster run fires this rule** and the finding is inverted. Under an
   open-loop generator, a difference genuinely points at the harness. aperf does not record this — you must
   know it.

5. **Look at the series shape before trusting the average.** Ramp-up in one run, a mid-run collapse, or
   different steady-state plateaus all average to the same number and mean completely different things. Compare
   plateaus, not means, on short runs.

6. **Check for a ceiling.** Read `bw_in_allowance_exceeded`, `pps_allowance_exceeded`,
   `conntrack_allowance_exceeded`, and `linklocal_allowance_exceeded` in `ena_stat`. Above an allowance, offered
   load is irrelevant — this is exactly what the frontend's `NETWORK_USAGE_INVESTIGATION` guidance directs you
   to check.

7. **Cross-check against `ena_stat` `rx_bytes`.** Driver and IP-layer counts should move together; disagreement
   means tunnels, encapsulation, a second interface, or counting at different layers.

8. **Separate byte volume from request volume.** Get request counts from the load generator. A 10% byte
   difference at constant request count is a payload, header, or keep-alive change, not a load difference.

9. **Subtract the background.** `netstat` is system-wide: monitoring agents, health checks, package updates,
   SSH, DNS, and IMDS all count. On a lightly loaded box this alone can cross 10%.

10. **Do not let the score set your priority.** At `Bad` (−2) this finding sorts below almost everything else,
    yet **it can invalidate the entire comparison.** Read it before the findings that outrank it, and explicitly
    discount CPU, IPC, memory, and latency deltas until load parity is established.

11. **If a single connection dominates, investigate that.** The frontend's guidance is specific: `watch
    netstat -t` to find heavily used connections, because one connection can saturate a single core and
    bottleneck the whole system. Per-queue `rx_bytes` spread in `ena_stat` is the in-report version of the same
    check.

12. **Once load parity is established, re-generate the report and re-read the other findings.** Their meaning
    changes entirely once the two runs are known to have done the same work.

## Priority and execution risk

**Priority: P0 — Blocking** for any throughput or per-unit comparison when the delta is large: the two runs did
not process the same amount of work. **P2 — Investigate** in the 10–25% band, where load-generator variance is
at least as likely as a real change.

**Execution risk: R0 — Read-only.** The remediation is to fix the load generation and re-run; nothing on the
system under test needs to change. This is the *cheapest* gate to resolve and the most commonly ignored.

Note this gate is scored **`Bad` (−2)**, two orders of magnitude milder than the EFA equivalents (`Critical`,
−256) despite testing the same thing on the general-purpose interface. **Do not let the mild score set your
priority** — a load mismatch invalidates as much as a hardware mismatch does for throughput work.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `|avg(IpExt:InOctets) delta| >= 10%` versus the base run.

```
STEP 1 — Parse the observed values.
  Format: The avg in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).
  Values carry T/G/M/K suffixes at 2 dp. Score: 10% -> -2, 50% -> -10, 100% -> -20.
  NOTE the comparator is GreaterEqual, so exactly 10.00% DOES fire
  (the EFA equivalents use Greater and would not).

  IF the delta reads exactly `100.00% greater than`
  THEN → AMBIGUOUS: base_stat == 0.0 is hardcoded to a delta ratio of 1.0 (P2, R0)
       → verify: if the base value prints as 0, the base run received NO inbound
         traffic at all — a broken base run, not a doubling

STEP 2 — Check the ABSOLUTE traffic level before the percentage.
  The rule has no absolute floor, so a percentage on a near-idle host is noise.
  Read both averages in bytes per interval, not the percentage or the score.
  IF EITHER average is under ~100 KB per interval (~100 KB/s at --interval 1)
  THEN → NOISE. This is background chatter, not workload traffic, and the gate
         is a FALSE POSITIVE. Do NOT void the report on it (P3, R0)
       → verify: compare `p50` against `avg`. Background traffic is spiky, so a
         single burst in one sample drags `avg` while `p50` barely moves; if
         `p50` moved LESS than `avg`, or moved the OPPOSITE way, one sample
         did this
       → verify: check `max`. If `max` is several times `p90`, the delta is one
         packet burst — a package-manager poll, a DNS refresh, an SSH keepalive
       → observed on this host: two IDLE runs 16 s apart, identical
         --period 10 --interval 1, fired at score -61.91 on 791 B/s vs
         3241 B/s, where `max` was 23432 vs 1291 and `p50` went DOWN 818 -> 572.
         A 2.4 kB/s difference produced a score larger than every real finding
         in the report
       → consequence: on an idle or lightly loaded host BOTH netstat gates fire
         essentially always. They gate load PARITY, and there is no load to
         compare. Treat the report as ungated and proceed to the other findings
  IF both averages are substantial (workload-scale traffic)
  THEN → the ratio rests on real, comparable byte counts. Continue to STEP 2b (P2, R0)

STEP 2b — Size the delta.
  IF |delta| is 10-25%
  THEN → load-generator variance, warm-up skew, or ramp differences (P2, R0)
       → verify: check the metric GRAPH, not the average. A ramp that starts
         earlier in one run shifts the average without changing steady-state load
       → also check run geometry: a different --period changes what the average
         covers, and accumulative counters have their FIRST sample forced to 0,
         so short runs are diluted differently
  IF |delta| is 25-100%
  THEN → the runs did materially different work. Throughput comparison is VOID (P0, R0)
  IF |delta| > 100%
  THEN → a configuration or topology difference, not variance (P0, R0)
       → suspect: different client count, different payload size, keep-alive
         vs new connections, or compression enabled on one side

STEP 3 — Check symmetry against the OUTBOUND gate.
  IF BOTH inbound and outbound fired in the same direction and similar magnitude
  THEN → a genuine load-level difference. Simple to reason about (P0, R0)
  IF ONLY inbound fired
  THEN → asymmetric: more bytes received but not sent. Suspect (P2, R0)
       → retries/duplicate requests from the client
       → larger request payloads with unchanged responses
       → a broken response path (check netstat error counters and `cpu_utilization`)
  IF inbound and outbound moved in OPPOSITE directions
  THEN → the request/response ratio changed: a different workload MIX,
         not merely a different load level (P0, R0)

STEP 4 — Is the traffic change the CAUSE or the EFFECT?
  This is the key discrimination, and the direction of causality is not obvious.
  IF the system under test is SATURATED (check `Underutilized CPU` absent,
     ENA allowance findings present, or `Increased I/O Wait Time`)
  THEN → traffic may be LOWER because the system could not accept more:
         the traffic delta is an EFFECT of a regression, not a confound (P1, R0)
       → this is the one case where the gate is reporting your actual result
  IF the system has spare capacity in both runs
  THEN → the traffic delta is an INPUT difference: a genuine confound (P0, R0)

STEP 5 — What survives?
  VALID  : configuration findings (THP, ENA Express state, tiered compilation),
           ENA/EFA *saturation* flags (a hit ceiling is a hit ceiling)
  VOID   : throughput comparisons, all per-request efficiency claims,
           cpu_utilization deltas (utilization tracks offered load),
           the statistical findings table for every rate metric
  CAUTION: `IpExt:InOctets` is HOST-WIDE across all interfaces. Background traffic
           (monitoring agents, package updates, the aperf process itself) is included

INSUFFICIENT DATA
  IF the base run lacks the `IpExt:InOctets` metric
  THEN → the rule returned early; NO finding produced (P1, R0)
```

## Runtime-specific consequences

Traffic volume interacts with each runtime's concurrency model, which determines whether a load change shows up
as throughput, latency, or nothing at all:

| Runtime | Concurrency model | What a traffic delta reveals |
|---|---|---|
| **Java** | Thread-per-request or async (Netty/NIO); virtual threads in newer JDKs | More traffic often shows as GC pressure first (allocation per request), before CPU. Check GC before concluding a network limit |
| **.NET** | `async`/`await` over the thread pool; Kestrel | Thread-pool starvation shows as latency growth with *flat* CPU — easy to misread as idle capacity |
| **Python** | GIL-bound; scaled by *processes* (gunicorn/uwsgi workers) | Traffic increase saturates one core per worker. `Underutilized CPU` alongside high per-worker CPU means worker count, not machine size, is the limit |
| **Perl** | Preforking workers | Same as Python: the limit is worker count. Fork cost dominates if connections are short-lived |

**The common misread across all four:** offered load rose, the application could not keep up, and the *received*
byte count fell as a result — so the gate fires and looks like a broken load generator when it is actually
reporting the regression you were looking for. STEP 4 exists to catch exactly this.

## Architecture-specific considerations

The ENA and netstat counters themselves are architecture-neutral — the same driver counters on the same
interface, read the same way on Intel, AMD, and arm64. Architecture matters here for a different reason:
**a traffic delta is very often the visible half of an architecture migration**, and this gate is one of the
few that will actually fire when the migration is not like-for-like.

Confirm architecture from `pmu_config.json` in each run before reading the delta
([ARCHITECTURE.md](../ARCHITECTURE.md) §1), because none of the hardware gates will tell you.

| Observed | Reading | Action |
|---|---|---|
| Traffic delta present, architectures identical | Read as a normal workload-parity question | Follow the tree above |
| Traffic delta present, architectures **differ** | The delta is a *symptom* of the platform change, not an independent variable. Serving less traffic on the new architecture usually means the application is slower there | Investigate the platform difference first, not the load generator (P1, R0) |
| Traffic matched, architectures differ | Genuinely comparable load — the most useful cross-architecture comparison you can get | Proceed, but `perf_stat` remains incomparable in meaning (P2, R0) |

**Instance-family bandwidth ceilings are not portable.** The same nominal size in different families has
different baseline and burst network allowances, and the ENA allowance findings compare against whatever the
running instance actually has. A traffic delta accompanied by allowance exceedances on only one side is usually
a ceiling difference, not an application difference (P0 for the throughput comparison, R4 to fix).

**Where architecture genuinely changes network cost:**

- **SMT.** Graviton has no SMT; x86 with SMT enabled reports 2× logical CPUs for the same physical core count.
  Per-connection and per-queue processing lands on physical cores, so a "same vCPU count" comparison gives the
  arm64 side twice the physical capacity for interrupt and softirq handling. Cross-check `cpu_utilization`'s
  `softirq` and `irq` series.
- **Number of ENA queues** typically follows vCPU count, so a size change alters queue count and per-queue load
  distribution. aperf does not collect queue counts directly.
- **TLS and compression paths** are where arm64 differs most: AES/GCM and CRC benefit from hardware
  instructions, but only if the runtime uses them. On the JVM this needs a recent JDK; for Python and .NET it
  depends on the linked OpenSSL build. An unmet request here reduces achievable throughput on arm64 and shows
  up as a traffic delta with elevated `user` CPU time.
- **Serialization/compression library builds** — the most common invisible cause of an outbound delta. A
  compression or protobuf library that fell back to a generic build on the new architecture changes payload
  sizes and CPU cost together ([ARCHITECTURE.md](../ARCHITECTURE.md) §5.3).

None of the above is collected by aperf. Capture the runtime's crypto and compression provider list manually
when the two runs differ in architecture.

## Verification

Fix the load generation so both runs offer identical traffic, then re-run and confirm the finding disappears.
If it persists with a verified-identical generator, the system under test is shaping the traffic — which is a
result, not a confound.

## Do not

- **Do not read this as a performance finding.** It says load parity is in doubt.
- **Do not assume less traffic means the generator underdelivered.** Back-pressure counters distinguish "load
  not offered" from "load pushed away" — the latter is a real regression.
- **Do not interpret the direction without knowing the generator's concurrency model.** Under a closed-loop
  generator, the *faster* run receives more traffic and fires this rule.
- **Do not equate bytes with requests.** Payload size, headers, ACKs, retransmissions, keep-alive, and
  background traffic all move bytes at constant request count.
- **Do not read the value as bytes per second** unless `--interval` is 1.
- **Do not trust the average on a short run.** Ramp-up on `--period 10` can move it 20% by itself.
- **Do not expect the score to show direction.** `abs: true` — only the description text is signed.
- **Do not rank by score here.** −2 base means it sorts last while potentially invalidating everything above it.
- **Do not compare runs with different `--interval`/`--period`.** The forced-zero first sample and interval
  width will not cancel.
- **Do not read a ratio of 1.0 as "twice the traffic"** without confirming the base run has data.
- **Do not blame the workload without checking background traffic and co-tenants.** `netstat` is system-wide.
- **Do not ignore ENA allowances.** Above a throttle ceiling, offered load and received bytes decouple.

## References

- Rule definition: `src/analytics/rules/netstat.rs:11` — `metric: "IpExt:InOctets"`, `stat: Stat::Average`,
  `comparator: Comparator::GreaterEqual`, `abs: true`, `delta_ratio: 0.1`, `score: Score::Bad`.
- Rule template: `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs` — skips the base run,
  returns early if the base run lacks the metric, substitutes `original_delta_ratio = 1.0` when
  `base_stat == 0.0`, applies `abs()` to the comparison ratio only, and renders the **signed** ratio in the
  description.
- Score formula: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score::Bad = −2`,
  `src/analytics/mod.rs:147`.
- Formatting: `formatted_number_string`, `src/computations/mod.rs:176` (decimal K/M/G/T, **truncated** to 2
  decimals); `delta_ratio_to_percentage_string`, `src/computations/mod.rs:162`.
- Collection and parsing: `src/data/netstat.rs` — reads `/proc/net/netstat`; metric names are
  `prefix + name` (e.g. `IpExt:` + `InOctets`).
- **Delta processing:** all metrics via `add_accumulative_data_point`
  (`src/data/common/time_series_data_processor.rs:130`) ⇒ **per-interval deltas**, first sample forced to 0
  (`ignore_first_accumulative_value: true`, `:73`); a **decreasing** counter returns `None`
  (`get_delta_and_set_previous_value`, `:189`) producing a **gap**, not a negative value.
- Aggregation: `time_series_data_processor_with_custom_aggregate!` with one `netstat` series per metric, so
  **no auto-generated `average` series**.
- Metric semantics: `IpExt:InOctets` at `data-descriptions.ts:3169` (`unit: "Bytes"`, `desired: "depends"`,
  `optimization: [NETWORK_USAGE_INVESTIGATION]`); `netstat` summary notes "the metric values were computed
  using the delta between two snapshots, so the first value is always zero".
- Frontend guidance: `NETWORK_USAGE_INVESTIGATION`,
  `src/report_frontend/src/definitions/optimization-guides.ts:18` — `watch netstat -t` for dominating
  connections, then check `bw_in_allowance_exceeded`, `bw_out_allowance_exceeded`,
  `conntrack_allowance_exceeded`, `linklocal_allowance_exceeded`, `pps_allowance_exceeded`.
- Related playbooks: `inconsistent-outbound-network-traffic.md`,
  `../ena_stat/inbound-bandwidth-allowance-exceeded.md`, `../ena_stat/pps-allowance-exceeded.md`,
  `../ena_stat/conntrack-allowance-exceeded.md`, `../efa_stat/inconsistent-inbound-efa-traffics.md`,
  `../meminfo/inconsistent-physical-memory.md`, `../systeminfo/inconsistent-number-of-cpus.md`,
  `../cpu_utilization/underutilized-cpu.md`.
- [Graviton perfrunbook — check network usage](https://aws.github.io/graviton/perfrunbook/debug_system_perf.html#check-network-usage)
- [proc_net_netstat / SNMP counters](https://www.kernel.org/doc/html/latest/networking/snmp_counter.html)
