# Validity Gates — precedence policy

The 8 findings below all mean the same thing: **the two runs are not comparable**. They are the only findings
in the tree that are **P0 — Blocking**, because every other finding in a comparison report, plus the entire
statistical findings table, is measured against a base run that turns out to be a different system or a
different amount of work.

Read this before any domain playbook. Vocabulary (P-levels, R-levels, tree inputs) is defined in
[GUIDANCE_MODEL.md](GUIDANCE_MODEL.md).

## The 8 gates

| # | Finding | Gate class | Score | Template | Score is |
|---|---|---|---|---|---|
| 46 | Inconsistent Number of CPUs | **Hardware** | Critical | `key_value_key_run_comparison` | **flat** |
| 41 | Inconsistent Physical Memory | **Hardware** | Critical | `time_series_stat_run_comparison` | scaled |
| 45 | Kernel Version Mismatch | **Software stack** | Critical | `key_value_key_run_comparison` | **flat** |
| 51 | JVM Version Comparison | **Software stack** | Critical | `profile_metadata_comparison` | **flat** |
| 34 | Inconsistent Inbound EFA Traffics | **Workload** | Critical | `time_series_stat_run_comparison` | scaled |
| 35 | Inconsistent Outbound EFA Traffics | **Workload** | Critical | `time_series_stat_run_comparison` | scaled |
| 43 | Inconsistent Inbound Network Traffic | **Workload** | Bad | `time_series_stat_run_comparison` | scaled |
| 44 | Inconsistent Outbound Network Traffic | **Workload** | Bad | `time_series_stat_run_comparison` | scaled |

**Three classes, three different meanings — and they are not equally fatal:**

- **Hardware** (#46, #41) — the machines differ. Nothing is comparable, including absolute counter values.
- **Software stack** (#45, #51) — the machines match but the code beneath the workload changed. Per-unit
  efficiency metrics (IPC, cache miss rates) remain *meaningful* but their causes are confounded.
- **Workload** (#43, #44, #34, #35) — the machines and stack match, but the runs **did not do the same amount
  of work**. This invalidates every *throughput* and *per-unit* comparison while leaving *configuration*
  findings (THP, ENA Express state, tiered compilation) fully valid.

**The workload gates are the only ones that produce routine false positives.** All four are relative-ratio
tests with no absolute floor, so a host with no network workload trips them on background traffic. Two idle
runs recorded 16 seconds apart on the same host, with identical `--period 10 --interval 1`, fired **both**
netstat gates: inbound at **−61.91** (791 → 3241 B/s) and outbound at −6.20 (3165 → 4147 B/s). The inbound
score exceeded every genuine finding in that report, off a 2.4 kB/s difference caused by one 23 kB burst in a
single sample. **Check the absolute averages before treating a workload gate as blocking.** The hardware and
software-stack gates have no equivalent failure mode — they compare identities, not ratios.

## Precedence order

When several fire, resolve in this order. Each step's outcome determines whether the next matters.

```
1. Hardware gates      (#46 CPUs, #41 MemTotal)
   → differ?  STOP. Re-run on matched instances. Nothing below is interpretable.

2. Architecture parity  (MANUAL — aperf has no rule for this)
   → Compare `pmu_config.json` between runs; the Cycles event encoding names the vendor.
   → vendor/ISA differs?  STOP. perf_stat is incomparable in MEANING, and two
                          findings exist on only one side.
   → µarch extension differs?  perf_stat metric DEFINITIONS differ between runs.
   Full chain and branches: ARCHITECTURE.md §6.

3. Instance-type check (MANUAL — aperf has no rule for this; see below)
   → differ?  STOP, even if CPUs and MemTotal match.

4. Software-stack gates (#45 kernel, #51 JVM)
   → differ?  The report is a STACK comparison, not a code comparison.
              Configuration findings stay valid. Attribute nothing to the application.

5. Workload gates      (#43/#44 netstat, #34/#35 EFA)
   → FIRST check the ABSOLUTE averages, not the percentage. These four rules are
     purely relative (|delta| >= 10% for netstat) with NO absolute floor, so at
     near-zero traffic they fire on background chatter.
   → either average under ~100 KB per interval?  FALSE POSITIVE. Not a workload
                          difference. Do not void anything; proceed to the findings.
   → differ at workload scale?  Throughput and per-unit comparisons are void.
              Configuration and saturation findings stay valid.

6. Collection-parity check (MANUAL — --interval / --period, PMU availability,
   --save-profile-events, kernel_config presence)
   → differ?  Specific metric families are incomparable; see per-playbook notes.

7. Only now read the domain findings and the statistical table.
```

## The two gaps that outrank all 8: architecture and instance type

Both are missing rules, not weak rules. **Architecture parity is checked first** because a vendor change makes
the `perf_stat` *metrics* incomparable — different events, different normalisations, two findings that exist on
only one side — whereas a size change only makes *values* incomparable. See
[ARCHITECTURE.md](ARCHITECTURE.md) for the fingerprint, the per-architecture finding matrix, and the
parity-check branches. Instance type is the broader check and follows immediately.

### Instance type

**aperf collects `Instance Type` and no rule ever compares it.** Verified: no reference to `Instance Type`,
`AMI ID`, `OS Version`, or `Region` exists anywhere under `src/analytics/`.

This means the following comparison produces **zero** hardware gate findings:

| | Base run | Compared run | Gate fires? |
|---|---|---|---|
| Instance type | `m6i.4xlarge` | `m7g.4xlarge` | **No** |
| `CPUs` | 16 | 16 | No — identical |
| `MemTotal` | 64 GiB | 64 GiB | No — identical |
| Architecture | x86_64 | **aarch64** | **No rule exists** |

Same vCPU count, same memory, **different CPU architecture** — and aperf reports a clean comparison. Every
`perf_stat` counter is now incomparable in *meaning*, not merely in value, and `Old-Style Atomic Instructions`
becomes relevant on one side only.

**Therefore: compare `Instance Type` manually as step 3 of every comparison report, before trusting any
finding.** Together with the architecture check that precedes it, these are the two highest-value manual checks
in the entire tree.

Secondary manual checks in the same category, all collected and all uncompared: `OS Version` (distro upgrade),
`AMI ID` (usually the *reason* the kernel differs), `Region` (different hardware generations behind the same
instance type).

## Deriving architecture

No `arch` field exists in `systeminfo`, but the run directory does identify the CPU. Three sources, in order of
reliability:

1. **`pmu_config.json` in the run directory** — the microarchitecture-specific PMU config aperf selected at
   record time, written by `src/data/perf_stat.rs:801` and archived with the run. The `Cycles` event encoding
   names the vendor: `armv8_pmuv3_0/event=0x11/` (arm64), `cpu/event=0x3c` (Intel), `cpu/event=0x76` (AMD).
   **This is data, not inference** — but it exists only if `perf_stat` was collected.
2. **`Instance Type`** — families containing `g` before the size (`m7g`, `c7g`, `r8g`, `x2gd`) are Graviton
   (aarch64); Intel (`i`) and AMD (`a`) suffixes are x86_64. An inference, but it also gives you the
   bandwidth/PPS ceilings the ENA playbooks need.
3. **`Kernel Version` suffix** — Amazon Linux appends `.x86_64` / `.aarch64`. Distro-specific; absent on
   many others.

Sources 2 and 3 are inferences. State which one you used. Full reading guide, including microarchitecture
discrimination and the limits of aperf's own detection: [ARCHITECTURE.md](ARCHITECTURE.md) §1.

## What each class invalidates

| Finding family | Architecture differs | Hardware differs | Stack differs | Workload differs |
|---|---|---|---|---|
| `cpu_utilization` (all 5) | valid (ISA-independent) | **void** | confounded | **void** (utilization tracks load) |
| `perf_stat` per-unit (IPC, miss rates) | **void in meaning** | **void** | confounded but meaningful | mostly valid |
| `perf_stat` absolute counters | **void in meaning** | **void** | confounded | **void** |
| `vmstat` / `meminfo` pressure | mostly valid | **void** | confounded | **void** |
| ENA allowance exceedances | **void** (different ceilings) | **void** (different ceilings) | valid | **void** |
| ENA Express / SRD *configuration* | valid | valid | valid | **valid** |
| `kernel_config` (THP, PREEMPT_LAZY) | valid | valid | **this is the change** | valid |
| `java_profile` configuration | valid | valid | **this is the change** | valid |
| **Statistical findings table** | **void** for `perf_stat` metrics | **void** | confounded | **void** for rates |

The pattern: **configuration findings survive every gate; rate and throughput findings survive none of them.**

Architecture is the one class where "void" means something stronger than elsewhere: the metric is not merely
measured under different conditions, it is **a different quantity with the same name** — and two findings
(`High Code Sparsity`, `Old-Style Atomic Instructions`) can only ever fire on arm64
([ARCHITECTURE.md](ARCHITECTURE.md) §2, §3).

## Shared mechanics of the two templates

**`key_value_key_run_comparison`** (#45, #46) — exact string inequality, `value != base_value`. **Score is
inserted directly with no `compute_finding_score` call, so it is always exactly −256** regardless of how
different the values are. Returns early (`debug!`) if the *base* run lacks the key, so **absence of the finding
does not prove the values match**. Two description forms:

```
The value of {key} in {run} ("{v}") is different from {base} ("{bv}").
The key {key} does not exist in {run}, while its value in {base} is "{bv}".
```

**`time_series_stat_run_comparison`** (#41, #43, #44, #34, #35) — computes
`(cur − base) / base` on the chosen stat, optionally takes `|·|`, and compares against `delta_ratio`.

```
The {stat} in {run} ({v}) is {pct}% {greater than|less than} {base} ({bv}).
```

Three mechanical properties that change how the value is read:

1. **`base_stat == 0.0` forces the delta ratio to exactly `1.0`** (a hardcoded "treat as 100% larger"), *not*
   infinity. So a metric that was 0 in the base run always reports as `100.00% greater than` regardless of the
   actual current value — and always scores identically. **A `100.00%` delta is therefore ambiguous**: it may
   be a true doubling or a zero base.
2. **`cur_stat == base_stat` yields exactly `0.0`**, rendered as the literal word `equal to`, and cannot fire
   a `Greater`/`GreaterEqual` rule.
3. **Values are `formatted_number_string`** — T/G/M/K suffixes at 2 decimal places. `1.50G` must be parsed back
   to a number, and the 2-dp rounding means two visibly identical values can differ.

Score scaling for the 5 threshold gates, all at `delta_ratio = 0.1`:

| Observed \|delta\| | Score (Critical base) | Score (Bad base) |
|---|---|---|
| 10% (at threshold) | −256 | −2 |
| 15% | −384 | −3 |
| 20% | −512 | −4 |
| 50% | −1280 | −10 |
| 100% (**or zero base**) | −2560 | −20 |
| 400% | −10240 | −80 |

Note the comparator differs by family: **netstat and meminfo use `GreaterEqual`, EFA uses `Greater`** — so an
EFA delta of exactly 10.0% does *not* fire while a netstat delta of exactly 10.0% does.

## Decision tree — gate triage

Entry condition: at least one of the 8 gates fired.

```
STEP 1 — Was the difference intended?
  IF you are deliberately A/B-testing hardware, kernel, JVM, or load level
  THEN the gate is CONFIRMING your independent variable.
       → Re-read the report as a comparison OF THAT VARIABLE (P4, R0)
       → Every delta is attributable to it — the opposite of the usual reading
  ELSE continue.

STEP 2 — Hardware class (#46, #41)?
  IF CPUs differ at all
  THEN → STOP. No analysis recovers this. Re-run matched (P0, R4)
  IF |MemTotal delta| >= 10%
  THEN → STOP. Different machine or different NUMA/reserved config (P0, R4)
  IF MemTotal delta is 10-15% AND CPUs match
  THEN → Suspect same instance type with different reserved memory
         (hugepages, crashkernel, GPU carve-out) rather than a different size (P1, R0)
       → verify: compare `Instance Type` manually; if equal, the delta is configuration

STEP 3 — Architecture parity (MANUAL, no rule)
  Read the `Cycles` event from each run's `pmu_config.json`.
  IF the vendor differs (armv8_pmuv3_0/event=0x11 vs cpu/event=0x3c vs cpu/event=0x76)
  THEN → STOP. All 15 perf_stat findings are incomparable in MEANING (P0, R4)
       → High Code Sparsity and Old-Style Atomic Instructions exist on the arm64 side only
  IF the vendor matches but the µarch extension differs (Slots on one side only,
     *167 on one side only, stall-backend-pkc missing on one side only)
  THEN → stall and l3-mpki definitions differ between runs; those comparisons are
         void while cache and TLB comparisons survive (P0, R0)
  IF only one run has pmu_config.json
  THEN → PMU collection failed or was skipped on one side, possibly an unrecognised
         CPU (bail!). All perf_stat findings are one-sided (P1, R0)
  IF perf_stat is absent from both runs
  THEN → fall back to the Instance Type / kernel-suffix inference and say so (P2, R0)
  → full branches: ARCHITECTURE.md §6

STEP 4 — Instance type (MANUAL, no rule)
  IF `Instance Type` differs in ANY component (family, generation, size, suffix)
  THEN → STOP even if CPUs and MemTotal matched (P0, R4)
       → architecture may differ silently; perf_stat becomes incomparable in meaning
  IF only the generation differs (m6i -> m7i)
  THEN → Same ISA, different microarchitecture: per-unit metrics shift legitimately (P1, R0)
       → but if that crosses a detected µarch boundary (e.g. into Sapphire Rapids,
         or out of Milan/Genoa), the metric DEFINITIONS also changed — see STEP 3

STEP 5 — Software stack (#45, #51)
  Locate the FIRST differing component of the version string:
    architecture suffix  → STOP, nothing comparable (P0, R4)
    major version        → expect broad behavioural change; check PREEMPT_LAZY on >=7 (P1, R0)
    minor / patch        → targeted change; check kernel_config for config drift (P2, R0)
    distro build / tag   → config changes invisible to this rule; check kernel_config (P2, R0)
  THEN → the report is a STACK comparison. Configuration findings remain valid (P0, R0)

STEP 6 — Workload class (#43/#44, #34/#35)
  IF |delta| is 10-25%
  THEN → load generator variance or warm-up skew. Re-run before concluding (P2, R0)
  IF |delta| > 25%
  THEN → the runs did different work. Throughput comparison is void (P0, R0)
       → configuration and saturation findings remain valid
  IF delta reads exactly `100.00% greater than`
  THEN → AMBIGUOUS: may be a zero base, not a doubling (see mechanics above) (P2, R0)
       → verify: read the base value in the description; if it is 0, the interface
         or counter did not exist in the base run
  IF inbound fired but outbound did not (or vice versa)
  THEN → asymmetric load change: often a client-side or retry-path difference,
         not a server-side throughput change (P2, R0)

STEP 7 — Collection parity (MANUAL)
  IF --interval or --period differ between runs
  THEN → percentiles are positional and incomparable; accumulative averages are
         diluted differently (P0, R0)
  IF one run has perf_stat and the other does not
  THEN → all pipeline/memory-hierarchy findings are one-sided (P1, R0)
  IF java_profile is absent
  THEN → --save-profile-events was not set; #51 could not fire. Absence proves
         NOTHING about JVM parity (P1, R0)
  IF kernel_config is absent (KERNEL_CONFIG=NOT FOUND)
  THEN → #47 fires spuriously AND PREEMPT_LAZY is silently disabled (P2, R0)

INSUFFICIENT DATA
  IF the base run lacks the key or metric entirely
  THEN → the rule returned early; NO finding was produced. Silence is not parity (P1, R0)
```

## Runtime-specific notes for the gates

The four target runtimes react differently to a stack change, which matters when a gate is *intentional*:

| Runtime | What a kernel change most affects | What an instance-family change most affects | Architecture-specific request to verify |
|---|---|---|---|
| **Java** | Futex/scheduling behaviour under GC threads; THP interaction with heap | JIT codegen (AArch64 vs x86_64), GC ergonomics keyed off vCPU/RAM | JDK 17+ on arm64 for LSE atomics and intrinsics; 2 MB default thread stack on aarch64 |
| **.NET** | Same futex/scheduling exposure; `DOTNET_GCHeapHardLimit` reads cgroup limits | Server GC heap count follows vCPU; ReadyToRun images are architecture-specific | RID matches the host (`linux-x64` vs `linux-arm64`); R2R/NativeAOT actually published for it |
| **Python** | Syscall-heavy paths and allocator behaviour (`mmap` thresholds) | C-extension wheels are architecture-specific; may fall back to source builds | Wheel tag matches (`manylinux_*_x86_64` / `_aarch64`); native-library ISA dispatch (`ONEDNN_MAX_CPU_ISA`) |
| **Perl** | I/O and syscall paths; fork cost for preforking servers | Rebuild required for XS modules; `perl -V` build config differs per distro image | XS modules rebuilt for the target architecture, not a generic build |

None of the right-hand column is visible to aperf — it collects no build flags, runtime identifiers, or dispatch
variables ([ARCHITECTURE.md](ARCHITECTURE.md) §5). When a gate is intentional *and* crosses architectures, this
is the first thing to capture manually, because an unmet architecture-specific build request will show up as a
`Reduced Instructions per Cycle` finding that looks like an application regression.

**When a JVM or CLR version changes, the gate is doing its job** — GC defaults, JIT tiering, and library
internals all shift. `#51 JVM Version Comparison` is the only rule that catches this, and **it is inert unless
the hidden `--save-profile-events` flag was passed**, so for .NET, Python, and Perl there is *no runtime-version
gate at all*. Compare runtime versions manually for those three.

## Do not

- **Do not read any gate's score as magnitude.** The two `key_value` gates are flat −256; a patch bump and a
  five-major-version jump score identically.
- **Do not treat absence of a gate finding as proof of parity.** All comparison rules return early when the
  *base* run lacks the key or metric, and #51 is inert by default.
- **Do not assume matched `CPUs` and `MemTotal` mean matched hardware.** Neither instance type nor CPU
  architecture is ever compared; a vendor change can pass all 8 gates silently.
- **Do not compare `perf_stat` findings across architectures without checking `pmu_config.json`.** Some metrics
  share a name but not a definition, and two findings exist only on arm64
  ([ARCHITECTURE.md](ARCHITECTURE.md) §2, §3).
- **Do not read `100.00% greater than` as a doubling** without checking the base value — a zero base produces
  the same string and the same score.
- **Do not discard configuration findings when a gate fires.** THP, ENA Express state, and tiered compilation
  remain valid across every gate class.
- **Do not try to correct for a gate analytically.** Fix the comparison and re-run; there is no adjustment that
  recovers a clean measurement.
- **Do not stop at the first gate.** Several can fire together and they invalidate different things.

## References

- Precedence and invalidation derived from the templates:
  `src/analytics/rule_templates/key_value_key_run_comparison_rule.rs` and
  `src/analytics/rule_templates/time_series_stat_run_comparison_rule.rs`.
- Zero-base handling: `time_series_stat_run_comparison_rule.rs` — `else if base_stat == 0.0 { 1.0 }`.
- Flat score for the key-value gates: same file family; `data_findings.insert_finding(... self.score ...)`
  with no `compute_finding_score` call.
- Score scaling: `compute_finding_score`, `src/analytics/mod.rs:167`; `Score` enum `:147`.
- Description formatting: `delta_ratio_to_percentage_string` and `formatted_number_string`,
  `src/computations/mod.rs:162` and `:176`.
- Comparators: `src/computations/mod.rs:108` — note `Greater` (EFA) vs `GreaterEqual` (netstat, meminfo).
- Rule definitions: `src/analytics/rules/systeminfo.rs:12`, `:18`; `src/analytics/rules/meminfo.rs:11`;
  `src/analytics/rules/netstat.rs:11`, `:22`; `src/analytics/rules/efa_stat.rs:33`, `:43`;
  `src/analytics/rules/java_profile.rs`.
- Collected-but-uncompared keys: `src/data/systeminfo.rs:173`–`:200`; verified absent from `src/analytics/`.
- Architecture parity, per-architecture finding matrix, and the arch-specific configuration class:
  [ARCHITECTURE.md](ARCHITECTURE.md). PMU config selection `src/data/perf_stat.rs:764`–`:791`; archived config
  `:801`; `CpuInfo` predicates `src/data/common/utils.rs:57`–`:99`.
- Per-gate playbooks: [systeminfo/inconsistent-number-of-cpus.md](systeminfo/inconsistent-number-of-cpus.md),
  [meminfo/inconsistent-physical-memory.md](meminfo/inconsistent-physical-memory.md),
  [systeminfo/kernel-version-mismatch.md](systeminfo/kernel-version-mismatch.md),
  [java_profile/jvm-version-comparison.md](java_profile/jvm-version-comparison.md),
  [netstat/inconsistent-inbound-network-traffic.md](netstat/inconsistent-inbound-network-traffic.md),
  [netstat/inconsistent-outbound-network-traffic.md](netstat/inconsistent-outbound-network-traffic.md),
  [efa_stat/inconsistent-inbound-efa-traffics.md](efa_stat/inconsistent-inbound-efa-traffics.md),
  [efa_stat/inconsistent-outbound-efa-traffics.md](efa_stat/inconsistent-outbound-efa-traffics.md).
- [statistical/README.md](statistical/README.md) — why the whole table is void when a gate fires.
