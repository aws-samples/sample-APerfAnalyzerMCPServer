# APerf Findings Knowledge Base — Index

Authoritative inventory of **every finding APerf can emit**, extracted mechanically from
`aws/aperf` @ `1.3.0` (commit `adf0970`, main branch, newer than tag `v1.2.3`).

This index is ground truth. Every claim below was read out of the Rust source, not recalled.
Source of record:

| What | Where in aperf |
|---|---|
| Rule definitions (per data type) | `src/analytics/rules/*.rs` |
| Rule templates (how a finding's `description` string is built) | `src/analytics/rule_templates/*.rs` |
| Multi-data rules | `src/analytics/rules/multi_data_rules.rs` |
| Score enum + score math | `src/analytics/mod.rs` |
| Statistical findings (computed in frontend, not Rust) | `src/report_frontend/src/utils/analytics.tsx` |
| Metric semantics + desired direction | `src/report_frontend/src/definitions/data-descriptions.ts` |
| Upstream optimization guides | `src/report_frontend/src/definitions/optimization-guides.ts` |
| Per-architecture PMU event sets (which `perf_stat` findings can fire) | `src/pmu_configs/*.json`, selected at `src/data/perf_stat.rs:764` |

To re-run the upstream-agreement checks in `tools/test_aperf_statistical.py`, clone [aws/aperf](https://github.com/aws/aperf) at this exact version and set `APERF_UPSTREAM_DIR` to that clone.

## Counts

| Category | Count |
|---|---|
| Single-data analytical rules | 50 |
| Multi-data analytical rules | 1 |
| **Total analytical findings** | **51** |
| Statistical findings | generated dynamically (1 per metric × stat × run with non-zero delta) |
| Data types carrying rules | 11 (of 21 registered) |
| Rule templates | 9 |

## The two finding families

APerf's report surfaces two separate panels. They are produced by different engines and
need different prescriptive treatment.

### 1. Analytical Findings
Produced by the Rust analytics engine at report-generation time
(`AnalyticalEngine::run`, `src/analytics/mod.rs`). A fixed set of 51 hand-written rules
is matched against processed data. Each match emits:

```json
{
  "rule_name":   "Underutilized CPU",
  "score":       -445.05461168773354,
  "description": "The average in flask_run_02 is 86.92.",
  "message":     "CPU utilization might not be maximized."
}
```

Serialized into the report as `<data_type>_findings` in `data/js/<data_type>.js`, shaped:

```json
{"per_run_findings": {"<run_name>": {"findings": {"<data_key>": [ <finding>, ... ]}}}}
```

`<data_key>` is the metric name for time-series data, the key name for key-value data, or
the profiler name for profiling data.

**`rule_name` is the join key.** It is the stable identifier our prescriptive files key on.
`description` carries the observed values; `message` is aperf's own (generic) advice.

### 2. Statistical Findings
Computed in the browser by `computeAllTimeSeriesStatsDelta()`
(`src/report_frontend/src/utils/analytics.tsx`). Not rule-based and **not** serialized as
findings — they are derived by diffing every time-series metric's stats against the base run.

- Only exist when comparing ≥2 runs. The base run has none.
- One finding per (metric × stat) where `delta != 0`, for all 8 stats.
- `baseScore` is `+1` (good), `-1` (bad), or `0` (neutral), decided by the metric's
  `desired` field in `data-descriptions.ts` (`higher` / `lower` / `moderate` / `fixed` / `depends`).
- `std` is always scored `0`. Non-directional metrics (`depends`/`moderate`/`fixed`) score `0` too — 201 of the
  802 time-series metrics (25.1%), which with the `std` rule makes **2209 of the 6416 possible (metric × stat)
  pairs structurally unscoreable.**
- Delta math: `(cur - base) / base` when `base > 0`, else the raw difference `cur - base`.
- **No threshold and no noise filter**, so a comparison emits thousands of rows; the default view is `avg`-only
  and `negative`-only; and `compareDelta` pins zero-base rows to ±Infinity, so the sort is actively misleading.

See `statistical/README.md` for the prescriptive treatment — § "The triage procedure" is the executable part, and
`tools/aperf_statistical.py` implements it (recompute → gate → filter → rank → route).

## Score scale

`Score` enum (`src/analytics/mod.rs:147`). Negative = problem, positive = healthy.

| Score | Value | Meaning |
|---|---|---|
| `Critical` | -256 | Severe; investigate first |
| `Poor` | -16 | Significant impact |
| `Bad` | -2 | Moderate impact |
| `Concerning` | -1 | Worth a look |
| `Neutral` | 0 | Informational |
| `Acceptable` | 1 | Fine |
| `Good` | 2 | Healthy |
| `Great` | 16 | Very healthy |
| `Optimal` | 256 | Ideal |

The emitted `score` is **not** the enum value — it is amplified by how far the observation
sits from the threshold, via `compute_finding_score(value, threshold, rule_score)`:

- `threshold == 0` → `value < 1 ? rule_score : (value - 1) * rule_score`
- `value == 0` → `2 * rule_score`
- otherwise → `delta * rule_score` where `delta = value/threshold`, inverted (`1/delta`) if `< 1`

So "Underutilized CPU" (base `Critical` = -256) reported `-445.05` for `idle` avg `86.92`
against threshold `50.0`: `86.92/50 = 1.7384`, `1.7384 × -256 = -445.05`. **A larger
magnitude means a larger deviation from threshold, not a different rule.** Findings are
sorted ascending by score, so the most negative appears first.

**Amplification applies to exactly four of the ten description shapes** — the time-series
ones: `time_series_stat_threshold`, `time_series_data_point_threshold` (and its
`_multi_metric` variant, which shares the same code), `time_series_stat_run_comparison`,
and `time_series_stat_intra_run_comparison`.
`key_value_key_expected`, `key_value_key_run_comparison`, `profile_stack_frame_threshold`,
`profile_metadata_expected`, `profile_metadata_comparison`, and the inline `multi_data_rule`
emit the raw `Score` value unchanged (verified: they pass `self.score` straight into
`AnalyticalFinding::new`). So
`Kernel Version Mismatch` always scores exactly `-256`, `Huge Page Disabled` exactly `-16`,
`Excessive Exceptions` exactly `-256`, and `PREEMPT_LAZY Detected` exactly `0` — the score
of those findings carries **no** information about magnitude.

Two further amplification details that matter when reading a score:

- `time_series_data_point_threshold` computes the score for *every* qualifying data point
  and reports only the one with the largest absolute score, then re-applies the sign. So
  the value in the description is the **worst single sample**, not an average.
- For the `threshold == 0.0` rules (the four TLB rules, `pgmajfault`, and the five ENA
  allowance rules), the formula's zero-threshold branch applies: any observed value `< 1.0`
  scores exactly the base score, and values `>= 1.0` score `(value − 1) × base`. A
  consequence worth knowing: an observed value of exactly `1.0` scores `0.0`.

Observed distribution across the 50 single-data rules: `Concerning` ×17, `Poor` ×13,
`Critical` ×13, `Bad` ×5, `Good` ×2. Only 2 of 51 rules are positive findings —
the engine is tuned to surface problems.

## Rule templates — how `description` is generated

Knowing the template tells you exactly what numbers the description carries, which is what
prescriptive guidance must parse. All 9 rule templates plus the one inline shape, with
their exact format strings. The two `data_point_threshold` rows share one implementation,
so there are **10 template names and 9 distinct emitting sites**:

| Template | Fires when | `description` format |
|---|---|---|
| `time_series_stat_threshold` | one metric's stat vs a constant | `The {stat} in {run} is {value}.` |
| `time_series_data_point_threshold` | **any single data point** vs a constant | `At least one data point in {run} is {value} ({comparator} the threshold of {threshold}).` |
| `time_series_data_point_threshold_multi_metric` | same, metric name matched by regex | same as above |
| `time_series_stat_run_comparison` | metric stat vs same metric in base run | `The {stat} in {run} ({value}) is {±pct} {base_run} ({base_value}).` |
| `time_series_stat_intra_run_comparison` | two different metrics within one run | `The {stat} in {comparison_metric} ({value}) is {±pct} {baseline_metric} ({base_value}).` |
| `key_value_key_expected` | key-value key vs expected literal | `The value of {key} in {run} is "{value}", instead of "{expected}".` |
| `key_value_key_run_comparison` | key-value key vs base run | `The value of {key} in {run} ("{value}") is different from {base_run} ("{base_value}").` |
| `profile_stack_frame_threshold` | % of profile samples in a stack pattern | `Stack pattern {pattern} accounts for {pct}% of samples in {profile_type} (threshold: {t}%).` |
| `profile_metadata_expected` | profile metadata vs regex | `Event type '{group}' field '{key}' in {k} should match pattern '{re}', found: {value}` |
| `profile_metadata_comparison` | profile metadata vs base run | `Event type '{group}' field '{key}' in {run} for '{k}' ("{v}") differs from {base_run} ...` |
| `multi_data_rule` (inline, not a template) | two data types together | `Kernel {version} in {run} is running with PREEMPT_LAZY preemption model.` |

Every one of these format strings is parsed executably by
[tools/aperf_desc.py](tools/aperf_desc.py), whose `parse_description()` returns the fields
a decision tree branches on. Prefer calling it over re-deriving a regex: it is fuzz-verified
against the compiled Rust formatters, and its test suite fails loudly when aperf edits a
format string.

**Every one of these descriptions reports a value; none reports a recommendation.** Where a
finding's inputs support one, the arithmetic lives in a tested module rather than in prose —
today that is [tools/aperf_rightsize.py](tools/aperf_rightsize.py), which turns
`Underutilized CPU`'s "CPU utilization might not be maximized" into "32 of 64 vCPUs suffices,
a 50% reduction", with the forced-zero, percentile-collapse, `min(idle)` and SMT corrections
applied. See `PATTERN.md` §5.1 for when to reach for one.

Important behavioural notes that change how guidance must be worded:

- **`*_run_comparison` and `*_data_point_threshold` templates need ≥2 runs** (comparison) or
  fire on a *single* sample spike (data point). A `data_point_threshold` finding may
  represent one transient blip — guidance must say so rather than assume a sustained problem.
- `time_series_stat_threshold` on `Stat::Average` describes a sustained condition; on
  `Stat::P99` / `Stat::Max` it describes a tail.
- Both comparison templates treat a zero baseline as "100% larger" rather than dividing by zero.
- `key_value_key_expected` also fires when the key is **missing entirely**, with a different
  description (`The key {key} in {run} is missing, ...`). Guidance must handle both.

## Complete finding inventory

51 findings. `Template` abbreviations: `TS-ST` = time_series_stat_threshold,
`TS-DP` = time_series_data_point_threshold, `TS-DP-M` = ..._multi_metric,
`TS-RC` = time_series_stat_run_comparison, `TS-IRC` = time_series_stat_intra_run_comparison,
`KV-EXP` = key_value_key_expected, `KV-RC` = key_value_key_run_comparison,
`PROF-SF` = profile_stack_frame_threshold, `PROF-EXP` = profile_metadata_expected,
`PROF-CMP` = profile_metadata_comparison, `MULTI` = multi-data rule.

### cpu_utilization — 5 rules (`src/analytics/rules/cpu_utilization.rs`)

| # | Rule name | Metric | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 1 | Consistent CPU Utilization | `aggregate` | TS-RC | \|Δavg\| ≤ 1% | Good | [cpu_utilization/consistent-cpu-utilization.md](cpu_utilization/consistent-cpu-utilization.md) |
| 2 | Underutilized CPU | `idle` | TS-ST | avg > 50.0 | Critical | [cpu_utilization/underutilized-cpu.md](cpu_utilization/underutilized-cpu.md) |
| 3 | Increased User-Space CPU Utilization | `user` | TS-RC | Δavg ≥ +10% | Poor | [cpu_utilization/increased-user-space-cpu-utilization.md](cpu_utilization/increased-user-space-cpu-utilization.md) |
| 4 | Decreased User-Space CPU Utilization | `user` | TS-RC | Δavg ≤ −10% | Poor | [cpu_utilization/decreased-user-space-cpu-utilization.md](cpu_utilization/decreased-user-space-cpu-utilization.md) |
| 5 | Increased I/O Wait Time | `iowait` | TS-RC | Δavg ≥ +10% | Poor | [cpu_utilization/increased-io-wait-time.md](cpu_utilization/increased-io-wait-time.md) |

### perf_stat — 15 rules (`src/analytics/rules/perf_stat.rs`)

**These 15 rules are architecture-conditional.** aperf selects its PMU event set by CPU vendor and
microarchitecture, so some of these findings *cannot fire* on some architectures and some share a metric name
across architectures without sharing a definition. The `Arch` column below is the summary; the mechanics are in
[ARCHITECTURE.md](ARCHITECTURE.md) §2 and §3.

| # | Rule name | Metric | Template | Condition | Score | Arch | File |
|---|---|---|---|---|---|---|---|
| 6 | Reduced Instructions per Cycle | `ipc` | TS-RC | Δavg ≤ −10% | Poor | all | [perf_stat/reduced-instructions-per-cycle.md](perf_stat/reduced-instructions-per-cycle.md) |
| 7 | Frontend-Dominated CPU Stalls | `stall-frontend-pkc` vs `stall-backend-pkc` | TS-IRC | ≥ +10% | Concerning | **not generic AMD** | [perf_stat/frontend-dominated-cpu-stalls.md](perf_stat/frontend-dominated-cpu-stalls.md) |
| 8 | Backend-Dominated CPU Stalls | `stall-backend-pkc` vs `stall-frontend-pkc` | TS-IRC | ≥ +10% | Concerning | **not generic AMD** | [perf_stat/backend-dominated-cpu-stalls.md](perf_stat/backend-dominated-cpu-stalls.md) |
| 9 | High Branch Mispredictions | `branch-mpki` | TS-ST | avg ≥ 10.0 | Concerning | all | [perf_stat/high-branch-mispredictions.md](perf_stat/high-branch-mispredictions.md) |
| 10 | High L1 Instruction Cache Misses | `inst-l1-mpki` | TS-DP | any > 20.0 | Concerning | all | [perf_stat/high-l1-instruction-cache-misses.md](perf_stat/high-l1-instruction-cache-misses.md) |
| 11 | Instruction TLB Misses | `inst-tlb-mpki` | TS-DP | any > 0.0 | Concerning | all | [perf_stat/instruction-tlb-misses.md](perf_stat/instruction-tlb-misses.md) |
| 12 | Instruction TLB Table Walks | `inst-tlb-tw-pki` | TS-DP | any > 0.0 | Concerning | all | [perf_stat/instruction-tlb-table-walks.md](perf_stat/instruction-tlb-table-walks.md) |
| 13 | High Code Sparsity | `code-sparsity` | TS-DP | any > 0.5 | Bad | **arm64 only** | [perf_stat/high-code-sparsity.md](perf_stat/high-code-sparsity.md) |
| 14 | High L1 Data Cache Misses | `data-l1-mpki` | TS-DP | any > 20.0 | Concerning | all | [perf_stat/high-l1-data-cache-misses.md](perf_stat/high-l1-data-cache-misses.md) |
| 15 | High L2 Cache Misses | `l2-mpki` | TS-DP | any > 10.0 | Concerning | all | [perf_stat/high-l2-cache-misses.md](perf_stat/high-l2-cache-misses.md) |
| 16 | High L3 Cache Misses | `l3-mpki` | TS-DP | any > 10.0 | Bad | all (≠ defs) | [perf_stat/high-l3-cache-misses.md](perf_stat/high-l3-cache-misses.md) |
| 17 | Data TLB Misses | `data-tlb-mpki` | TS-DP | any > 0.0 | Concerning | all | [perf_stat/data-tlb-misses.md](perf_stat/data-tlb-misses.md) |
| 18 | Data TLB Table Walks | `data-tlb-tw-pki` | TS-DP | any > 0.0 | Concerning | all | [perf_stat/data-tlb-table-walks.md](perf_stat/data-tlb-table-walks.md) |
| 19 | Old-Style Atomic Instructions | `strex-spec-pki` | TS-DP | any ≥ 10.0 | Poor | **arm64 only** | [perf_stat/old-style-atomic-instructions.md](perf_stat/old-style-atomic-instructions.md) |
| 20 | PMU Counter Collection Multiplexing | `mux_counter_schedule_rate` | TS-DP | any < 100.0 | Concerning | all | [perf_stat/pmu-counter-collection-multiplexing.md](perf_stat/pmu-counter-collection-multiplexing.md) |

### ena_stat — 11 rules (`src/analytics/rules/ena_stat.rs`)

| # | Rule name | Metric | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 21 | Inbound Bandwidth Exceeded Instance Allowance | `bw_in_allowance_exceeded` | TS-DP | any > 0.0 | Critical | [ena_stat/inbound-bandwidth-exceeded-instance-allowance.md](ena_stat/inbound-bandwidth-exceeded-instance-allowance.md) |
| 22 | Outbound Bandwidth Exceeded Instance Allowance | `bw_out_allowance_exceeded` | TS-DP | any > 0.0 | Critical | [ena_stat/outbound-bandwidth-exceeded-instance-allowance.md](ena_stat/outbound-bandwidth-exceeded-instance-allowance.md) |
| 23 | PPS Exceeded Instance Allowance | `pps_allowance_exceeded` | TS-DP | any > 0.0 | Critical | [ena_stat/pps-exceeded-instance-allowance.md](ena_stat/pps-exceeded-instance-allowance.md) |
| 24 | Connection Tracking Exceeded Instance Allowance | `conntrack_allowance_exceeded` | TS-DP | any > 0.0 | Critical | [ena_stat/connection-tracking-exceeded-instance-allowance.md](ena_stat/connection-tracking-exceeded-instance-allowance.md) |
| 25 | Link-Local Service Exceeded Instance Allowance | `linklocal_allowance_exceeded` | TS-DP | any > 0.0 | Critical | [ena_stat/link-local-service-exceeded-instance-allowance.md](ena_stat/link-local-service-exceeded-instance-allowance.md) |
| 26 | Disabled ENA Express | `ena_srd_mode` | TS-DP | any == 0.0 | Concerning | [ena_stat/disabled-ena-express.md](ena_stat/disabled-ena-express.md) |
| 27 | Enabled ENA Express without UDP | `ena_srd_mode` | TS-DP | any == 1.0 | Concerning | [ena_stat/enabled-ena-express-without-udp.md](ena_stat/enabled-ena-express-without-udp.md) |
| 28 | Disabled ENA Express with Previously Enabled UDP | `ena_srd_mode` | TS-DP | any == 2.0 | Bad | [ena_stat/disabled-ena-express-with-previously-enabled-udp.md](ena_stat/disabled-ena-express-with-previously-enabled-udp.md) |
| 29 | ENA Express Enabled with UDP | `ena_srd_mode` | TS-DP | any == 3.0 | Good | [ena_stat/ena-express-enabled-with-udp.md](ena_stat/ena-express-enabled-with-udp.md) |
| 30 | Low SRD Usage Rate | `ena_srd_eligible_tx_pkts` vs `ena_srd_tx_pkts` | TS-IRC | ≥ +30% | Poor | [ena_stat/low-srd-usage-rate.md](ena_stat/low-srd-usage-rate.md) |
| 31 | High SRD Resource Utilization | `ena_srd_resource_utilization` | TS-ST | P99 > 95.0 | Poor | [ena_stat/high-srd-resource-utilization.md](ena_stat/high-srd-resource-utilization.md) |

### efa_stat — 5 rules (`src/analytics/rules/efa_stat.rs`)

| # | Rule name | Metric | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 32 | Unused RDMA Read | `rdma_read_wrs` | TS-ST | max == 0.0 | Concerning | [efa_stat/unused-rdma-read.md](efa_stat/unused-rdma-read.md) |
| 33 | Unused RDMA Write | `rdma_write_wrs` | TS-ST | max == 0.0 | Concerning | [efa_stat/unused-rdma-write.md](efa_stat/unused-rdma-write.md) |
| 34 | Inconsistent Inbound EFA Traffics | `rx_bytes` | TS-RC | \|Δavg\| > 10% | Critical | [efa_stat/inconsistent-inbound-efa-traffics.md](efa_stat/inconsistent-inbound-efa-traffics.md) |
| 35 | Inconsistent Outbound EFA Traffics | `tx_bytes` | TS-RC | \|Δavg\| > 10% | Critical | [efa_stat/inconsistent-outbound-efa-traffics.md](efa_stat/inconsistent-outbound-efa-traffics.md) |
| 36 | EFA Errors | regex `^*_err$` | TS-DP-M | any ≥ 1.0 | Poor | [efa_stat/efa-errors.md](efa_stat/efa-errors.md) |

### vmstat — 4 rules (`src/analytics/rules/vmstat.rs`)

| # | Rule name | Metric | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 37 | Major Page Faults Detected | `pgmajfault` | TS-DP | any > 0.0 | Poor | [vmstat/major-page-faults-detected.md](vmstat/major-page-faults-detected.md) |
| 38 | Increased Minor Page Faults | `pgminorfault` | TS-RC | Δavg ≥ +20% | Concerning | [vmstat/increased-minor-page-faults.md](vmstat/increased-minor-page-faults.md) |
| 39 | Increased Major Page Faults | `pgmajfault` | TS-RC | Δavg ≥ +20% | Poor | [vmstat/increased-major-page-faults.md](vmstat/increased-major-page-faults.md) |
| 40 | Excessive Page Fault Rate | `pgfault` | TS-ST | P99 > 100000.0 | Concerning | [vmstat/excessive-page-fault-rate.md](vmstat/excessive-page-fault-rate.md) |

Note: `pgminorfault` is **derived** by aperf as `pgfault − pgmajfault` (`src/data/vmstat.rs:96`).

### meminfo — 2 rules (`src/analytics/rules/meminfo.rs`)

| # | Rule name | Metric | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 41 | Inconsistent Physical Memory | `MemTotal` | TS-RC | \|Δavg\| ≥ 10% | Critical | [meminfo/inconsistent-physical-memory.md](meminfo/inconsistent-physical-memory.md) |
| 42 | Reduced Memory Availability | `MemAvailable` | TS-RC | Δavg ≤ −10% | Poor | [meminfo/reduced-memory-availability.md](meminfo/reduced-memory-availability.md) |

### netstat — 2 rules (`src/analytics/rules/netstat.rs`)

| # | Rule name | Metric | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 43 | Inconsistent Inbound Network Traffic | `IpExt:InOctets` | TS-RC | \|Δavg\| ≥ 10% | Bad | [netstat/inconsistent-inbound-network-traffic.md](netstat/inconsistent-inbound-network-traffic.md) |
| 44 | Inconsistent Outbound Network Traffic | `IpExt:OutOctets` | TS-RC | \|Δavg\| ≥ 10% | Bad | [netstat/inconsistent-outbound-network-traffic.md](netstat/inconsistent-outbound-network-traffic.md) |

### systeminfo — 2 rules (`src/analytics/rules/systeminfo.rs`)

| # | Rule name | Key | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 45 | Kernel Version Mismatch | `Kernel Version` | KV-RC | differs from base run | Critical | [systeminfo/kernel-version-mismatch.md](systeminfo/kernel-version-mismatch.md) |
| 46 | Inconsistent Number of CPUs | `CPUs` | KV-RC | differs from base run | Critical | [systeminfo/inconsistent-number-of-cpus.md](systeminfo/inconsistent-number-of-cpus.md) |

### kernel_config — 1 rule + 1 multi-data rule

| # | Rule name | Key | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 47 | Huge Page Disabled | `CONFIG_TRANSPARENT_HUGEPAGE` | KV-EXP | != `"y"` | Poor | [kernel_config/huge-page-disabled.md](kernel_config/huge-page-disabled.md) |
| 48 | PREEMPT_LAZY Detected | `CONFIG_PREEMPT_LAZY` | MULTI | kernel major ≥ 7 **and** `CONFIG_PREEMPT_LAZY=y` | Neutral | [kernel_config/preempt-lazy-detected.md](kernel_config/preempt-lazy-detected.md) |

Source: `src/analytics/rules/multi_data_rules.rs:16` (`PreemptLazyDetectedRule`).

### java_profile — 3 rules (`src/analytics/rules/java_profile.rs`)

| # | Rule name | Target | Template | Condition | Score | File |
|---|---|---|---|---|---|---|
| 49 | Excessive Exceptions | `cpu` profile stacks | PROF-SF | ≥ 5% of samples in exception-construction frames | Critical | [java_profile/excessive-exceptions.md](java_profile/excessive-exceptions.md) |
| 50 | Tiered Compilation Check | `jdk.JVMInformation` / `jvmArguments` | PROF-EXP | no `-XX:±TieredCompilation` flag | Poor | [java_profile/tiered-compilation-check.md](java_profile/tiered-compilation-check.md) |
| 51 | JVM Version Comparison | `jdk.JVMInformation` / `jvmVersion` | PROF-CMP | differs from base run | Critical | [java_profile/jvm-version-comparison.md](java_profile/jvm-version-comparison.md) |

## Data types with NO analytical rules

These 10 registered data types have `impl AnalyzeData for X {}` — no rules, so they never
produce analytical findings. They remain valuable as corroborating evidence when
investigating another finding.

Only the **time-series** ones fall back to statistical findings (and only when ≥2 runs are
compared). The other four have **no automated signal at all** and must be read manually:

| Data type | Format | Metrics | Statistical findings? |
|---|---|---|---|
| `processes` | time-series | 7 | yes |
| `diskstats` | time-series | 17 | yes |
| `interrupts` | time-series | 31 | yes |
| `numastat` | time-series | 6 | yes |
| `memalloc` | time-series | 94 | yes |
| `aperf_stats` | time-series | 21 | yes |
| `sysctl` | key-value | — | **no** |
| `hotline` | graph | — | **no** |
| `perf_profile` | graph | — | **no** |
| `aperf_runlog` | text | — | **no** |

This is a gap, not an all-clear: a disk-saturated or IRQ-storming host emits **zero**
analytical findings from `diskstats` / `interrupts`. Prescriptive guidance for
`Increased I/O Wait Time` and CPU findings must therefore reach into these data types
manually.

The gap is also wider than these 10 data types suggest, because a data type *having* rules does not mean a given
metric is covered: **752 of the 802 time-series metrics (93.8%) are named by no rule at all**, including 5 of 9
`cpu_utilization` metrics and 4 of 19 `perf_stat` metrics. For all of them the statistical table is the only
automated signal. `statistical/README.md` § "The triage procedure" STEP 5 has the routing and the per-data-type
guidance for the six rule-less types; `tools/aperf_statistical.py`'s `route()` answers it per metric.

## How the MCP consumes this

Every file in this tree is a **prescriptive playbook** keyed by `rule_name`. Resolution:

1. Parse `<data_type>_findings` from the report's `data/js/*.js`, or read findings from the
   aperf MCP/report JSON.
2. For each finding, look up `rule_name` → `<data_type>/<kebab-case-rule-name>.md`.
3. Load that playbook and execute it against the run's actual data.

**This is implemented, not aspirational.** In `aperf-mcp`:

| Step | Where |
|---|---|
| 1 — parse findings out of a report | `src/parsers/findings_parser.py` (`parse_findings`) |
| 2 — join `rule_name` → playbook | `src/parsers/playbook_library.py` (`PlaybookLibrary`) |
| 3 — assemble findings + guidance in gate order | `src/mcp_tools/analyze_findings.py` (`analyze_findings` tool) |

The tree is also served directly as MCP resources under `aperf://findings/`
(`aperf://findings/GATES`, `aperf://findings/cpu_utilization/underutilized-cpu`,
`aperf://findings/statistical/README`) — a scheme deliberately separate from `aperf://prompts/`,
which holds advisory prose rather than per-rule instructions. The resource list is enumerated
from `FINDINGS_REGISTRY.json`, so it can never advertise a playbook no rule joins to.

Two things the tool does that a caller reading the raw JS cannot: it applies the
[GATES.md](GATES.md) precedence order (including the workload-gate absolute-floor check, which is
mechanical because both averages are already in the description), and it orders findings by the
playbooks' own `P0`-`P4` priority rather than by `abs(score)` — see [Score scale](#score-scale)
for why those disagree.

The mapping is *mostly* mechanical: lowercase the `rule_name`, replace spaces and
underscores with `-`, strip remaining non-alphanumerics
(`Link-Local Service Exceeded Instance Allowance` →
`link-local-service-exceeded-instance-allowance.md`).

**Do not re-derive it.** `PREEMPT_LAZY Detected` is the case that breaks naive derivation —
the registry maps it to `preempt-lazy-detected.md` (underscore → `-`), whereas simply
stripping non-alphanumerics yields `preemptlazy-detected.md`.
`FINDINGS_REGISTRY.json` carries the explicit machine-readable mapping and is the only
authority; read the `playbook` field directly.

**For any `perf_stat` finding, also load `pmu_config.json` from the run directory.** It determines whether the
finding could have fired at all and what its metric actually measures on that CPU; two findings are arm64-only
and several metric definitions differ by microarchitecture. Without it the tool will explain findings that were
mechanically impossible and compare quantities that share only a name. See
[ARCHITECTURE.md](ARCHITECTURE.md).

The check does not require parsing markdown: every `perf_stat` entry in `FINDINGS_REGISTRY.json` carries an
**`architectures`** array naming the PMU-config profiles on which that finding can fire, and an
**`architecture_note`** string where the metric is present but not comparable. The profile names match the keys
of the top-level `architecture.profiles` block, which also holds the `cycles_event_discriminator` needed to map
a `pmu_config.json` back to a profile.

See `SCHEMA.md` for the tier-1 playbook file contract, **`PATTERN.md` for the tier-2 authoring pattern**,
`GUIDANCE_MODEL.md` for decision-tree inputs, priority and risk levels, `GATES.md` for comparison-validity
precedence, `ARCHITECTURE.md` for the Intel/AMD/arm64 dimension, and `statistical/README.md` for the
statistical-findings treatment.

## Authoring progress

Every one of the 51 findings has a playbook capturing **what** it means and **why** it fires, and **all 51 are
now at tier 2** — prescriptive depth was added in batches, and the last batch closed the tier-1 backlog:

| Tier | Sections | Has | Count |
|---|---|---|---|
| **1** | 8 | Mechanism, reasoning, interpretation, corroborating data, scaffolded guidance | 0 |
| **2** | 13 | Adds priority/risk, a value-keyed decision tree, runtime and architecture dimensions, and verification | 51 |

The batches, in the order they were written:

- **The 8 comparison-validity gates** — `Inconsistent Number of CPUs`, `Inconsistent Physical Memory`,
  `Kernel Version Mismatch`, `JVM Version Comparison`, the two `netstat` traffic gates, and the two
  `efa_stat` traffic gates. These came first because every other comparison finding is void without them.
- **All 5 `cpu_utilization` findings** — `Underutilized CPU` (which piloted the pattern),
  `Consistent CPU Utilization`, `Increased`/`Decreased User-Space CPU Utilization`, and
  `Increased I/O Wait Time`.
- **The 6 `perf_stat` pipeline and stall findings** — `Backend-`/`Frontend-Dominated CPU Stalls`,
  `Reduced Instructions Per Cycle`, `High Branch Mispredictions`, `Old-Style Atomic Instructions`, and
  `PMU Counter Collection Multiplexing`, which gates the other five by telling you whether the counters
  were even measured concurrently.
- **The 9 `perf_stat` memory-hierarchy findings** — the L1/L3 cache and instruction/data TLB findings plus
  `High Code Sparsity`, sharing one ratio quantifier (`tools/test_aperf_memory_hierarchy.py`) and the
  PMU-pairing table that says which of them can fire on which architecture.
- **All 5 ENA allowance exceedances** — `Inbound`/`Outbound Bandwidth`, `PPS`, `Connection Tracking`, and
  `Link-Local Service Exceeded Instance Allowance`. These route on the exceedance **rate and duration**
  rather than the cumulative total the score encodes, and share one quantifier
  (`tools/test_aperf_ena_allowance.py`) plus the multi-ENI `average`-series artifact.
- **The 6 ENA Express and SRD findings**, then **the 3 remaining `efa_stat` findings**, then **the 5 memory
  findings** across `vmstat` and `meminfo`, then **the 2 `kernel_config` findings**, and finally **the 2
  remaining `java_profile` findings** — `Excessive Exceptions`, the one Java rule that measures rather than
  inspects, and `Tiered Compilation Check`, the weakest finding aperf produces.

After the 51 playbooks, one batch covered the *other* half of aperf's findings:

- **The statistical-findings triage layer** — `statistical/README.md` § "The triage procedure" plus
  `tools/aperf_statistical.py` and `tools/test_aperf_statistical.py`. Statistical findings are a different
  mechanism, not a curated rule: **every non-zero delta of every (metric × stat) pair is a finding**, computed in
  the browser, not serialized, with no threshold. So the treatment is a procedure and a module rather than a
  playbook — a noise filter aperf lacks, a faithful port of the delta arithmetic (which must be recomputed since
  nothing can parse it out of a report), a correction for the ±Infinity sorting artifact and the `avg`-only /
  `negative`-only default filters, and routing for the **752 of 802 metrics (93.8%) that no analytical rule
  covers.** It is exempt from the playbook lint by the `README.md` skip at `tools/check_playbooks.py:565`, so its
  contract is the test suite instead.

Promotion is governed by `PATTERN.md` and enforced by `tools/check_playbooks.py`. Run it,
`tools/test_aperf_desc.py`, `tools/test_aperf_rules.py`, `tools/test_check_drift.py`,
`tools/test_aperf_rightsize.py`, `tools/test_aperf_ena_allowance.py`, `tools/test_aperf_perf_stat.py`,
`tools/test_aperf_memory_hierarchy.py`, and `tools/test_aperf_statistical.py` before committing any
playbook change; all nine must exit `OK` with an empty warning backlog.

## Version-drift maintenance

Everything in this tree is pinned to aperf **1.3.0 / `adf0970`**, and the pin is load-bearing in two
ways that rot silently when upstream moves:

- **Rule facts.** The thresholds, scores, conditions and messages in `FINDINGS_REGISTRY.json` and in
  every playbook's frontmatter. A threshold changed upstream leaves the registry, the frontmatter and
  the prose all still agreeing *with each other* and all wrong. `check_playbooks.py` cannot see this:
  it validates frontmatter **against the registry**, so a stale registry passes clean.
- **Source citations.** 339 `path:LINE` anchors plus 1104 bare follow-on `` `:N` `` refs. Any edit
  above a cited line silently repoints it at unrelated code.

`tools/check_drift.py` is the only check in the tree that reads aperf itself; everything else
validates internal consistency. Run it against a checkout of whatever aperf version you care about:

```
python3 tools/check_drift.py <aperf-checkout>              # exit 1 on drift
python3 tools/check_drift.py <checkout> --update-baseline  # re-pin CITATIONS.json
python3 tools/check_drift.py <checkout> --rules-only       # skip the citation layer
```

Three layers, and the third is the one that is easy to forget:

1. **Rules** — re-extracts all 51 rules from the Rust macros (`tools/aperf_rules.py`) and rebuilds
   each `condition` string mechanically (`tools/aperf_conditions.py`), then diffs `template`,
   `source`, `base_score`, `base_score_value`, `condition` and `aperf_message` against the registry.
   Reports new rules (no playbook — a report carrying one routes nowhere), removed rules (a playbook
   documenting a rule that can no longer fire), and any changed field. 2 of the 51 conditions are
   prose paraphrase and are declared unverifiable rather than approximated; the other 49 round-trip
   byte-for-byte, which `tools/test_aperf_rules.py` asserts.
2. **Citations** — `CITATIONS.json` stores the normalized text of every cited line **plus three lines
   of context on each side**. On a new checkout, text still at the line is `OK`; text found elsewhere
   is `MOVED` with the new line number printed; text gone is `LOST` and needs a human. The context
   window is what makes `MOVED` usable: citations often point at a blank line or one `} else {` of
   four, and matching on text alone degrades to "ambiguous among 15 lines".
3. **Watchlist** — six upstream defects the guidance is *written around*, most importantly the
   `Tiered Compilation Check` regex sign bug and the hidden `--save-profile-events` gate. Here a
   defect being **fixed** is the finding: guidance saying "the regex matches both signs, so
   `-XX:-TieredCompilation` produces no finding" becomes actively misleading the moment upstream
   tightens it, and nothing else in the tree would notice.

**The line-number policy is pinned lines, not symbol anchors.** Symbol names were rejected because
the citations are load-bearing at sub-function granularity —
`time_series_stat_run_comparison_rule.rs:97`–`:110` points at the specific branch that computes the
ratio with no absolute floor, and no symbol name identifies that. Pinned lines are made *survivable*
by the fingerprints instead. Cite by full path or by a basename that is unambiguous in aperf's
`src/`; do not elide a filename to `..._rule.rs:125` to make a table row fit, because a citation a
reader cannot resolve is a defect in the citation.

### The upgrade procedure

1. `python3 tools/check_drift.py <new-checkout>` and read every line of the output.
2. Fix `DRIFT` first. A changed threshold, score or message means the registry entry, the playbook
   frontmatter, and every score-math table and threshold sentence in the prose all change together —
   the number is usually restated several times per playbook.
3. Then `MOVED`: verify the new line really is the code the prose describes, then repoint.
   The move is mechanical; the confirmation is not.
4. `LOST` means the cited code is gone. Re-read the replacement and re-derive the claim; do not
   repoint to whatever now sits nearest.
5. Re-run `check_playbooks.py` plus all seven test suites, then
   `python3 tools/check_drift.py <checkout> --update-baseline` **last** — re-pinning before fixing
   the prose just records the drift as the new truth.
6. Update the version and commit in this file's header, in `FINDINGS_REGISTRY.json`, and in the
   `PINNED_COMMIT` constant in `tools/test_aperf_rules.py`.

Detection is proved in both directions, and by a test rather than by hand. `tools/test_check_drift.py`
copies the checkout to a temp directory, plants 11 mutations of the kinds upstream actually makes — a
changed threshold, a changed score, an added rule, a removed rule, a reworded message, a rescaled
`Score::Critical`, a renamed function, a bumped version, 3 lines inserted into a rule template, and
**both** watchlist defects named above being fixed — and asserts each produces its specific finding.
A checker that has only ever run
against the pinned commit is untested where it counts: a false negative reads exactly like a clean
tree. It also fixes the reference point for the `MOVED` mechanism — the 3-line insertion must repoint
`time_series_stat_run_comparison_rule.rs:100` to `:103`, unambiguously.
