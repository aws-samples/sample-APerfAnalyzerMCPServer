---
rule_name: PREEMPT_LAZY Detected
data_type: kernel_config
data_key: CONFIG_PREEMPT_LAZY
template: multi_data_rule
condition: "kernel major version >= 7 AND CONFIG_PREEMPT_LAZY == \"y\""
base_score: Neutral
score_sign: neutral
requires_comparison: false
aperf_message: "Linux 7.0 changed the default preemption model to PREEMPT_LAZY. If you observe unexpected performance differences, consider setting the preemption model to PREEMPT_NONE via kernel boot parameter (preempt=none) or kernel config (CONFIG_PREEMPT_NONE=y), or implementing rseq (restartable sequences) in the application's hot functions. See: https://lore.kernel.org/all/20260403191942.21410-1-dipiets@amazon.it/T/#t"
source: src/analytics/rules/multi_data_rules.rs:16
---

# PREEMPT_LAZY Detected

## What fired

Two facts held simultaneously for this run: the `Kernel Version` from `systeminfo` has a **major version ≥ 7**, and
`CONFIG_PREEMPT_LAZY` in `kernel_config` is exactly `"y"`.

Base score `Neutral` (**0**) — **the only zero-scored rule in aperf.** There is no score table: the rule inserts
`Score::Neutral.as_f64()` directly and never calls `compute_finding_score`. Single-run: it evaluates every run
independently, needing no comparison.

**This is a context flag, not a problem report.** aperf is not claiming anything went wrong. It is telling you that a
kernel-level scheduling default changed in Linux 7.0, and that if this report contains performance differences you
cannot otherwise explain, the preemption model is a candidate — the only aperf rule whose entire purpose is to
*pre-empt a misattribution* rather than to flag a defect.

## The processing defect — aperf records the context-switch counter and throws it away at processing time

The single most direct measurement of a preemption-model change is the system-wide context-switch rate, and the prior
version of this playbook said aperf does not collect it. **That is wrong in the way that matters: aperf records it in
every run and discards it while processing.** `collect_data` reads `/proc/stat` *whole* into a `String`
(`cpu_utilization.rs:43`) and `write_to_file` bincodes that raw string into `cpu_utilization.bin`
(`data_collection.rs:305`), which `create_run_data_archive` packs into `<run>.tar.gz` (`record.rs:306`–`:316`).
Verified on a real archive (16 vCPU, `--interval 1`, `--period 30`, 31 snapshots) —
`strings cpu_utilization.bin | grep '^ctxt '` returns **31 lines**, one cumulative counter per snapshot:
`262249377, 262291136, 262332217, 262373478, 262413686, …`.

The loss happens in `ProcKernelStat::from_raw_data`, which keeps only the `cpu*` lines:

| `/proc/stat` line | Fields | Survives processing? |
|---|---|---|
| `cpu`, `cpu0` … `cpuN` | 11 | **Yes.** `total` from the aggregate line, `per_cpu` from the rest (`:87`–`:89`) |
| `ctxt`, `btime`, `processes`, `procs_running`, `procs_blocked` | 2 | No — killed by `if split.len() < 9 { continue }` (`:73`) |
| `intr` | 554 on this host | No — passes the length test, then fails the `cpu`-prefix test (`:86`) |
| `softirq` | 12 | No — fails both |

**So the counter is one command away from any archive you still have**, and unrecoverable from an HTML report alone.
Difference consecutive values, divide by `--interval`, and you have the rate the report cannot show.

**The in-report proxy this playbook used to recommend is off by three orders of magnitude.** Measured on that same
run: **42,703 context switches/s** system-wide (**2,669/s per CPU**) against **29 rescheduling IPIs/s** summed
across all 16 CPUs — a ratio of `0.00067`, so **`RES` undercounts context switches by ~1,483×**. That is a category
difference, not noise: `RES` counts only *cross-CPU* resched requests, and lazy preemption's whole effect is on the
*local* path `RES` never sees. **The report understates even that proxy** — `interrupts` is processed through
`time_series_data_processor_with_average_aggregate!` (`interrupts.rs:146`), so the aggregate `RES` series reads
about **1.80/s per CPU** and reaching the system-wide 29/s takes a multiplication by hand. And
`src/analytics/rules/interrupts.rs` is four lines long — `impl AnalyzeData for InterruptData {}` — so
**`interrupts` has no analytical rules at all** and nothing will flag a shift for you.

## Reasoning

**Why aperf ships a rule for this at all.** Linux 7.0 changed the **default** preemption model to `PREEMPT_LAZY` — a
behaviour change that arrives with a kernel upgrade, applies to every workload on the host, and is invisible in every
other data type aperf collects. When someone upgrades an AMI and sees a throughput or latency shift they cannot trace
to their own code, the preemption model is a plausible cause that would otherwise take a long time to reach. **The
rule exists to shorten that search, which is why it is scored `Neutral` rather than negative — a hypothesis
generator, not a verdict.**

**What lazy preemption actually changes.** Under the classic models, a wakeup that should displace the running
task sets `TIF_NEED_RESCHED` and the kernel reschedules at the next opportunity — for `PREEMPT_FULL`, essentially
immediately, including inside kernel code. Lazy preemption adds a second, weaker flag: for **non-urgent**
preemption requests the scheduler marks the task lazily and lets it keep running until a natural boundary — the
next tick or the return to userspace — instead of forcing an immediate switch. Urgent cases (real-time tasks,
explicit resched) still preempt promptly. The design goal was `PREEMPT_NONE`-like throughput without the scattered
`cond_resched()` calls voluntary preemption relied on.

**Why that can move performance in either direction.** The mechanism trades latency against throughput, and which
way it lands depends on the workload. A CPU-bound task keeps its cache and TLB warm for longer and takes fewer
involuntary switches — the intended win. A task that *should* have been displaced runs on for up to a tick, which
for a latency-sensitive service shows up as tail-latency growth and **not** as any change in average CPU. And
delaying preemption changes the interleaving of threads that share data, moving lock hold times, queue depths, and
contention patterns in ways hard to predict from first principles.

**Why the message recommends rseq, the least obvious part of it.** "Restartable sequences in the application's hot
functions" is aimed at userspace code with **per-CPU data structures** — allocator caches (tcmalloc, jemalloc),
counters, freelists. Such code is correct only if it can detect that it was preempted and migrated mid-sequence, and
`rseq` gives it a kernel-assisted way to do that cheaply. **Changing the preemption model changes the rate at which
those sequences are interrupted**, so code that took a slow fallback path takes it at a different frequency:
applications already using `rseq` absorb the change, and those with a heavier fallback (an atomic, a lock, a restart
loop) feel it — which is why the recommendation sits alongside the two kernel-level ones, not as an alternative.

**The compile-time/runtime gap — the same trap as `Huge Page Disabled`, and the single most important caveat here.**
This rule reads `CONFIG_PREEMPT_LAZY=y`, which means only that **lazy preemption is compiled into the kernel**. With
`CONFIG_PREEMPT_DYNAMIC` — standard on distro kernels, and `=y` on Amazon Linux 2023 — the *active* model is selected
at boot via `preempt=none|voluntary|full|lazy` and can be switched at runtime through
`/sys/kernel/debug/sched/preempt`, and **aperf collects neither the kernel command line nor that debugfs file**. So a
host booted with `preempt=none` **fires this finding while not running lazy preemption at all**; and conversely the
rule's own recommended remedy (`preempt=none`) **does not clear the finding**, because the config flag is still `y`.
**This finding persisting after you apply its own advice is expected, not a failed fix.** And the debugfs check the
old guidance led with needs root — `/sys/kernel/debug` is mode `drwx------ root root`, so
`cat /sys/kernel/debug/sched/preempt` returns Permission denied for an ordinary user. **Two non-root substitutes
exist, and neither is in the report:** the build string in `/proc/version` and `uname -v` embeds the model — this host
reads `#1 SMP PREEMPT_DYNAMIC Tue Jul 14 14:13:08 UTC 2026` — and `/proc/cmdline` shows whether a `preempt=` override
was passed (it was not, here). Prefer those; they cost nothing and answer the same question.

**Why the version gate is `major >= 7`, where it is brittle, and which string it reads.** `systeminfo` sets
`Kernel Version` from `sys.kernel_version()` (`systeminfo.rs:122`, filed at `:175`); with `sysinfo = "0.26.2"`
resolving to 0.26.9 that is the `release` field of `libc::uname()` — **`uname -r`, not `/proc/version`** — so the
*build* string that would have named the preemption model outright is never collected. The major is then parsed as
`version.split('.').next().and_then(|m| m.parse::<u32>().ok()).unwrap_or(0)`. Simulating that over realistic strings:
`7.0.1-1.amzn2023.aarch64`, `7.0.0-rc1` and `10.0.0-…` all fire, `6.12.94-…` stays silent, and `v7.0.1`,
`linux-7.0.1` and **`7-amzn`** all yield `0`, which is `< 7`, so **the rule is silently skipped**. The hyphen-only
form is the trap worth remembering: a 7.x kernel to a human, a 0.x kernel to the parser. The gate is `>= 7`, so future
majors are covered; a 6.x kernel with `CONFIG_PREEMPT_LAZY=y` **does not fire**, deliberately — the rule is about the
*default change*, not the feature — so **its absence on a 6.x kernel says nothing about the preemption model.**

**Why it needs two data types, and what that costs.** This is aperf's only `MultiDataAnalyticalRule`: it reads
`Kernel Version` from `systeminfo` and `CONFIG_PREEMPT_LAZY` from `kernel_config`, and **returns immediately if either
is absent**. `kernel_config` is exactly the data type that fails to collect on containers and minimal AMIs —
`get_kernel_config_data` falls back to the literal `KERNEL_CONFIG=NOT FOUND`. **On such a host this rule is silently
disabled while `Huge Page Disabled` fires spuriously from the same missing file**, so that finding with a "key is
missing" description and no `PREEMPT_LAZY Detected` on a 7.x kernel is one shared collection failure, not two
independent facts.

**Where the finding is filed, and why the zero score buries it.** It is inserted under data type `kernel_config`, key
`CONFIG_PREEMPT_LAZY` — **not** under `systeminfo`, despite the kernel version being half the trigger — so it appears
only on the `kernel_config` page, whose `Section` column is wrong for about a third of its rows (see
`huge-page-disabled.md`): **search that page by key name, never by section.** On the Report Home page it lands in the
Analytical Findings list sorted ascending by score, so **a zero sits below every negative finding**; with 5-item
pagination a dozen negative findings push it onto page three or later, in gray with a neutral-face icon as finding
type "Neutral". It is **structurally the least discoverable finding aperf produces**, and the one most likely to
explain a mystery. Look for it deliberately.

## Reading the description

There is no rule template here: `multi_data_rule` is this tree's name for the one rule that builds its description
and finding inline (`src/analytics/rules/multi_data_rules.rs:60`) rather than through a shared template, so this
format string is used by no other finding. Shown with a concrete rendering:

```
Kernel {version} in {run} is running with PREEMPT_LAZY preemption model.
Kernel 7.0.1-1.amzn2023.aarch64 in aperf_record is running with PREEMPT_LAZY preemption model.
```

Four things to know:

1. **The full `Kernel Version` string is echoed verbatim**, so the description doubles as a record of exactly
   which kernel this was — useful when pairing with `Kernel Version Mismatch`. It is `uname -r`, so it carries no
   preemption information of its own.
2. **"is running with" overstates what was verified.** The rule checked a compile-time config flag. With
   `CONFIG_PREEMPT_DYNAMIC` the *running* model may be something else entirely. Read this as "is built with".
3. **There is no value, ratio, or threshold in the text**, and the score is a flat 0 — no `compute_finding_score`
   call, **no score table**, no magnitude, and no severity ordering relative to other findings.
4. **It fires once per run**, including the base run of a comparison. Both runs firing means both kernels are
   7.x-with-lazy — consistent, and therefore *not* an explanation for a delta between them.

## Interpretation

**First, establish whether lazy preemption was actually active:**

| Evidence | Reading |
|---|---|
| `/proc/version` or `uname -v` contains **`PREEMPT_LAZY`** | **The build default is lazy.** The strongest non-root confirmation available, and not collected by aperf |
| The build string contains **`PREEMPT_DYNAMIC`**, and `preempt=` is **absent** from the kernel command line on a 7.x kernel | The model is boot- and runtime-selectable, so the config flag alone proves nothing — but with no override, **lazy is the 7.0 default and was almost certainly active.** The finding is meaningful |
| **`preempt=none` / `voluntary` / `full` on the command line**, or a non-lazy model in `/sys/kernel/debug/sched/preempt` | **The finding is a config artifact.** Lazy is compiled in but not active. aperf sees neither, and the debugfs file needs root (`drwx------`) |
| Finding **persists after** applying `preempt=none` | **Expected.** The rule reads the config flag, which `preempt=` does not change. Not a failed fix |
| `CONFIG_PREEMPT_DYNAMIC` **not set** | The compiled-in model is the active one — **the finding is a much stronger statement** |

**Then decide whether it explains anything in this report:**

| Evidence | Reading |
|---|---|
| **Fires on one run only, `Kernel Version Mismatch` also fired** | **The high-value case.** A preemption-model change is a live candidate for any unexplained delta — but the two variables are not independent |
| Fires on **both** runs, or the report shows **no unexplained differences**, or is single-run | Consistent configuration, so it **cannot explain a difference between them**; purely informational, since the message itself is conditioned on "if you observe unexpected performance differences" and a single run has no baseline to show one against |
| **`ctxt` rate recovered from the archives differs between runs** | **The only direct measurement, and it is available from `cpu_utilization.bin` even though the report omits it** |
| Tail latency regressed with average CPU unchanged, or throughput improved while latency worsened | **The characteristic lazy-preemption signature**, and the intended trade landing as designed: delayed preemption costs latency without costing throughput, and aperf's period-average metrics are poorly suited to seeing it. Whether the trade is acceptable is a product decision, not a bug |
| Workload uses per-CPU caches (tcmalloc/jemalloc per-CPU mode, per-CPU counters) | **The `rseq` recommendation applies directly.** Preemption-rate changes alter fallback-path frequency |
| Rescheduling interrupts (`IPI0`/`RES`) shifted materially | Weakly consistent with a changed preemption pattern. **Measured at 1/1483 of the context-switch rate — a shift here is suggestive, an absence of one proves nothing** |
| `system` CPU shifted with no workload change | Scheduler and context-switch overhead moved |
| `CONFIG_HZ=100` with `CONFIG_NO_HZ_FULL=y` | **A 10 ms lazy window, the widest common setting**, and on `nohz_full` CPUs the tick that would close it may be omitted entirely |
| Real-time or `SCHED_FIFO` threads present | Urgent preemption is unaffected by laziness; expect little impact on those threads specifically |

**Known false positives — the rule is factually correct, so these are all "correct but not actionable":**

- **`preempt=` overriding the compiled default**, so the config flag is set and lazy preemption is not running.
  The most consequential case, and completely invisible to aperf.
- **Every 7.x host fires this.** Lazy is the 7.0 *default*, so on a fleet of 7.x instances the finding is
  near-universal and carries almost no differential information — least of all when **both runs of a comparison
  fire it**, where the configuration is identical and cannot explain any delta.
- **A workload genuinely insensitive to preemption timing** — batch, single-threaded, or long-running CPU-bound
  code with no per-CPU structures — or **the finding as a red herring** when a real cause exists elsewhere. It is
  scored `Neutral` precisely so it does not outrank actual findings; test it *after* the negative-scored ones.

**Blind spots, in order of importance:**

- **The active preemption model is invisible.** `CONFIG_PREEMPT_DYNAMIC` plus `preempt=` or debugfs means the config
  flag is a weak proxy, and neither the command line nor `/proc/version` is collected.
- **The context-switch rate is recorded but not reported.** `/proc/stat` is stored whole in `cpu_utilization.bin`,
  then `ProcKernelStat::from_raw_data` drops every non-`cpu*` line, so **`ctxt` never reaches the report even though
  it is in the archive.** Recover it with `strings`; if the archive is gone, the measurement is gone with it.
- **The rescheduling-IPI proxy undercounts by ~1,483×** and is reported as a per-CPU average, so it can move by a
  factor of two while the real context-switch rate barely shifts, and vice versa. `interrupts` also has **no
  analytical rules** — nothing flags a change. And there are **no per-task counters either**: `processes` reads only
  `/proc/<pid>/stat` (fields 11, 12, 17, 20, 21 → user time, kernel time, thread count, VSZ, RSS), never
  `/proc/<pid>/status`, which is where `voluntary_ctxt_switches` lives.
- **A 6.x kernel with `CONFIG_PREEMPT_LAZY=y` never fires**, so absence proves nothing below 7.0 — nor when the
  version string has a non-numeric leading component (`unwrap_or(0)`, then `0 < 7`) or when a run present in
  `systeminfo` is missing from `kernel_config`. Both skip the rule in silence.
- **`CONFIG_PREEMPT_NONE`/`_VOLUNTARY`/`_FULL`/`_DYNAMIC` are not checked** by any rule, though they sit in the
  same data and would sharpen the reading; read them by hand. And **latency effects are largely unobservable** —
  aperf reports period statistics, while delayed preemption shows up in tail latency.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **`/proc/version` or `uname -v` for `PREEMPT_LAZY`/`PREEMPT_DYNAMIC`** | out of band | **Do this first.** Non-root, instant, and decisive about the build default. **Not collected by aperf** |
| Kernel command line for **`preempt=`**; `/sys/kernel/debug/sched/preempt` | out of band | Whether the build default was overridden at boot, and the runtime model under `CONFIG_PREEMPT_DYNAMIC`. Neither is collected, and the debugfs file is **root only** (`drwx------`) |
| **`strings cpu_utilization.bin \| grep '^ctxt '`** | run archive | **The real context-switch counter, one cumulative value per snapshot.** Present in every `<run>.tar.gz`, absent from the report |
| **`CONFIG_PREEMPT_DYNAMIC`** | `kernel_config` | Whether the model is boot/runtime-selectable at all. If not set, the config flag *is* the active model |
| `CONFIG_PREEMPT_NONE`, `CONFIG_PREEMPT_VOLUNTARY`, `CONFIG_PREEMPT`, `CONFIG_PREEMPT_RT` | `kernel_config` | The full compiled preemption picture. **No rule checks these — read manually, by key name** |
| `CONFIG_HZ`, `CONFIG_NO_HZ_FULL`, `CONFIG_HZ_PERIODIC`; `CONFIG_RSEQ` | `kernel_config` | Tick granularity sets **how long a lazily-marked task can keep running** — a lower `HZ` amplifies the effect; `CONFIG_RSEQ` says whether the kernel supports the `rseq` remedy |
| **`Kernel Version`** and **`Kernel Version Mismatch`** | `systeminfo` | The other half of the trigger, echoed verbatim in the description — and `uname -r`, so silent about preemption. **The mismatch is the pairing that makes this finding actionable** |
| `Huge Page Disabled` with a "key is missing" description | `kernel_config` | Signature of a `kernel_config` collection failure — which would have **silently disabled this rule** |
| `RES` (x86_64) or `IPI0` (arm64) rescheduling interrupts; `LOC` local timers | `interrupts` | The in-report proxy, **undercounting context switches ~1483× and shown as a per-CPU average**; `LOC` gives actual tick delivery to cross-check against `CONFIG_HZ`. No analytical rules on either |
| **`system` CPU**, `user`, `idle`, per-CPU spread | `cpu_utilization` | Scheduler and migration overhead, and whether the CPU budget moved at all or only its distribution |
| `ipc`, `l3-cache-mpki`, `*-tlb-mpki`, `stall_*_pkc` | `perf_stat` | **Longer uninterrupted runs mean warmer caches** — the throughput side of the trade should show here |
| `num_threads`, per-process `utime`/`stime` | `processes` | Thread count and mix determine preemption sensitivity. **No per-task context-switch counters, and no rules** |
| `kernel.sched_*` entries | `sysctl` | Eight keys are present. **`kernel.sched_schedstats=0` is the one to read** — it explains an empty `/proc/schedstat` |
| Thread, lock, and scheduler frames | `java_profile`, `perf_profile`, `hotline` | Whether contention patterns shifted. **No analytical rules — read manually** |
| Application tail-latency metrics | out of band | **The effect most likely to matter and least likely to appear in aperf's period statistics** |

## Guidance

Ordered. **Step 1 decides whether the finding means anything; step 2 whether it is worth pursuing here.**

1. **Read `/proc/version` or `uname -v` before anything else.** `CONFIG_PREEMPT_LAZY=y` only means lazy preemption
   is *compiled in*; with `CONFIG_PREEMPT_DYNAMIC` the active model comes from `preempt=` at boot or from
   `/sys/kernel/debug/sched/preempt` at runtime. **aperf collects none of the three.** The build string is the one
   check that needs no root, so start there, then confirm with `/proc/cmdline`. If a non-lazy model is selected,
   this finding is a config artifact — stop here.

2. **Ask whether the report actually contains an unexplained difference.** The message is explicitly conditional:
   *"If you observe unexpected performance differences…"*. **No mystery ⇒ nothing to do**; record the preemption
   model as context and move on.

3. **Work the negative-scored findings first.** This one is `Neutral` by design: the hypothesis you reach for when
   the ranked findings have not explained the delta, not a competing candidate alongside them. Because the list
   sorts ascending by score it sits **below every negative finding**, often pages down; look for it deliberately.

4. **Establish whether it can explain a *difference* at all.** In a comparison, check which runs fired. **One run
   only, ideally alongside `Kernel Version Mismatch`, is the case worth investigating** — while remembering that the
   kernel changed too, so the two are confounded. Both runs firing means the configuration is consistent and cannot
   account for a delta.

5. **Recover the context-switch rate from the archives.** It is in every `<run>.tar.gz` even though it is not in
   the report: extract, then `strings cpu_utilization.bin | grep '^ctxt '`, difference consecutive values, and
   divide by `--interval`. **This is the measurement the preemption model most directly moves**, and comparing it
   across two runs is worth more than everything else in this playbook. Keep the tarballs.

6. **Treat the rescheduling-IPI series as a weak hint, not evidence.** On a measured run, `RES` summed over all
   CPUs ran at **29/s against 42,703 context switches/s** — 1/1483 of the rate — because it counts only cross-CPU
   resched requests, not the local preemption lazy preemption actually changes. It is also reported as a **per-CPU
   average**, so multiply by the CPU count before comparing anything.

7. **Look for the signature rather than the average, then read the tick configuration by key name.** Delayed
   preemption typically costs **tail latency** while leaving average CPU and throughput flat or improved, and
   aperf's period statistics are poorly suited to seeing it, so you will usually need application-side latency
   data. `CONFIG_HZ` and the `NO_HZ` settings then bound **how long a lazily-marked task can keep running** before
   the next tick forces the switch — 10 ms at `CONFIG_HZ=100`, the common Amazon Linux 2023 setting. With
   `CONFIG_NO_HZ_FULL=y` a CPU running a single task may skip the tick altogether, widening the window further;
   check `nohz_full=` on the command line and the per-CPU `LOC` rate.

8. **If you decide to test the kernel-side remedy, use the boot parameter first.** `preempt=none` is reversible
   with a reboot and requires no rebuild, whereas `CONFIG_PREEMPT_NONE=y` needs a custom kernel. **Expect this
   finding to keep firing afterwards** — it reads the config flag, which `preempt=` does not change — so verify
   through `/proc/cmdline` and the recovered `ctxt` rate, never through the finding's disappearance, and note that
   `GUIDANCE_MODEL.md` lists the preemption model as its own example of an **R5, behaviour-changing** action.

9. **Consider the application-side remedy where it applies, and read the upstream thread on magnitude.** If the
   workload maintains per-CPU data structures — allocator caches, counters, freelists — the message's `rseq`
   recommendation is the durable fix: it makes preemption cheap to detect and recover from instead of requiring a
   heavyweight fallback, and it holds regardless of which model the kernel ends up using. The rule links a
   specific lore.kernel.org discussion, whose workload-specific effects are the intended reference for what kind
   of regression to expect. And **if `Huge Page Disabled` also fired with a "key is missing" description,
   re-examine step 1 entirely** — that pattern means `kernel_config` was not collected, which would have silently
   disabled this rule, so a genuinely lazy 7.x host might show no finding at all.

## Priority and execution risk

**Priority: P4 — Informational** by default, and that is not a hedge — it is what a flat zero score encodes. The rule
fires on essentially every 7.x host, carries no measurement, and its own message is conditional on you already having
an unexplained difference. It rises to **P2 — Investigate** when the finding fired on exactly one run of a comparison,
`Kernel Version Mismatch` also fired, and the report shows a delta the negative-scored findings do not explain; that
is the one configuration in which this playbook is worth working end to end. It reaches **P3** only after a recovered
`ctxt`-rate difference or a tail-latency regression has made the preemption model the leading candidate. It drops back
to P4 the moment `/proc/cmdline` shows a `preempt=` override, and to **P4 permanently** when `kernel_config` failed to
collect, because then the finding is not about preemption at all.

**Execution risk: R5 — Behaviour-changing** for the remedy the message proposes.
[../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md) names "preemption model" as its own R5 example, and correctly so:
changing it alters scheduling latency for **every task on the host**, not just the workload under test, and a service
validated against one model has not been validated against another. The subordinate levels are worth separating,
because most of this playbook is free: **R0** for the entire diagnosis — reading `/proc/version`, `/proc/cmdline`,
`kernel_config` keys, and recovering `ctxt` from an archive touch nothing. **R1** for a root write to
`/sys/kernel/debug/sched/preempt`, which takes effect instantly and reverts as fast. **R4** for `preempt=none` as a
boot parameter, since it needs a reboot, and for `CONFIG_PREEMPT_NONE=y`, which needs a different kernel or AMI.
**R3** for the `rseq` route, an application change shipped as an artifact — the highest-effort option and the only one
that changes behaviour for nothing but your own code.

**The score cannot inform any of this.** It is a flat 0 with no ratio, magnitude, or severity ordering:
`Score::Neutral.as_f64()` is inserted directly and `compute_finding_score` is never called. Priority comes entirely
from the corroborating measurements, and the most important one has to be extracted from the archive by hand.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `PREEMPT_LAZY Detected` fired on at least one run — or you are on a 7.x kernel and it did not.

```
STEP 0 — Could the rule even have fired? Check before reading anything into it.
  The rule needs BOTH systeminfo and kernel_config and returns immediately if either
  is absent (multi_data_rules.rs :25, :29).
  IF the kernel_config page has NO Section column (every group name empty, one key
     KERNEL_CONFIG) AND Huge Page Disabled fired with an "is missing" description
  THEN → COLLECTION FAILURE. /boot/config-* was unreadable, CONFIG_PREEMPT_LAZY was
         never looked up, this rule was silently disabled, and its absence here says
         nothing about preemption. See that playbook: huge-page-disabled.md reads the
         same signature from the other side (P4, R0)

  IF Kernel Version does not begin with a parseable integer, or its major is 6 or
     lower
  THEN → the rule could not fire whatever CONFIG_PREEMPT_LAZY says: 0 and 6 are both
         < 7. `7-amzn`, `v7.0.1` and `linux-7.0.1` all parse to 0, and lazy
         preemption existed before 7.0, so read the key by hand (P4, R0)

  IF the finding fired
  THEN → CONFIG_PREEMPT_LAZY is exactly "y", the major version is >= 7 (P4, R0)
       → continue to STEP 1

STEP 1 — Was lazy preemption ACTUALLY active? Non-root checks first.
  /sys/kernel/debug is drwx------ root root, so the debugfs check needs root; two
  non-root substitutes exist and neither is in the report.
  IF /proc/version or `uname -v` contains PREEMPT_LAZY
  THEN → lazy is the build default and was almost certainly active (P2, R0)
       → continue to STEP 2

  IF the build string contains PREEMPT_DYNAMIC
  THEN → the model is selectable at boot and at runtime, so the config flag proves
         nothing on its own; Amazon Linux 2023 ships this way. Read /proc/cmdline
         next: no preempt= on a 7.x kernel means the 7.0 default, while preempt=none,
         voluntary or full means CONFIG ARTIFACT — lazy is compiled in but not active,
         so STOP, no conclusion about this report follows (P4, R0)

  IF CONFIG_PREEMPT_DYNAMIC is not set in kernel_config
  THEN → the compiled model IS the active model and the finding is a strong
         statement rather than a hint (P2, R0)
       → continue to STEP 2

STEP 2 — Recover the counter aperf recorded and discarded.
  The report has no ctxt series; the archive does. Extract <run>.tar.gz, then
  `strings cpu_utilization.bin | grep '^ctxt '` for one cumulative value per
  snapshot. Difference consecutive values and divide by --interval.
  IF the recovered ctxt rate differs materially between the two runs
  THEN → the most direct evidence available anywhere that scheduling behaviour
         changed. Pair it with `system` CPU from cpu_utilization (P2, R0)
       → a lower rate with equal or better throughput is the intended lazy trade;
         a lower rate with worse tail latency is the cost side of the same trade

  IF the ctxt rates match within noise
  THEN → the preemption model did not change the switch rate for this workload, so
         it is a poor candidate for any delta in the report. And if the archives are
         gone and only the HTML reports remain, the measurement is unrecoverable: fall
         back to the IPI proxy in STEP 3, which undercounts by ~1483x (P4, R0)

STEP 3 — Does the finding explain a difference in THIS report?
  IF the finding fired on both runs, or the report shows no unexplained difference
     at all
  THEN → identical configuration cannot explain a delta, and there is no mystery to
         explain. VOID as an explanation; record it and STOP (P4, R0)

  IF it fired on one run only and Kernel Version Mismatch also fired
  THEN → the high-value case, and a confounded one: the preemption model travels
         with the kernel build, so the two are not independent (P2, R0)
       → run the gate in ../GATES.md for the version mismatch before attributing

  IF tail latency regressed while average CPU and throughput stayed flat
  THEN → the characteristic lazy-preemption signature (P2, R0)
       → aperf's period statistics cannot resolve it; the evidence must come from
         application-side latency data

  IF the rescheduling-IPI series (RES on x86_64, IPI0 on arm64) shifted materially
  THEN → weakly suggestive only. Multiply by the CPU count first, because the series
         is a per-CPU average, and remember it is 1/1483 of the real rate (P4, R0)

STEP 4 — How wide is the lazy window? Read the tick by key name.
  CONFIG_HZ bounds how long a lazily-marked task keeps running: 10 ms at HZ=100 (the
  Amazon Linux 2023 default and widest common setting), 4 ms at 250, 1 ms at 1000.
  IF CONFIG_HZ is 100
  THEN → the effect is at its largest here; at 250 or 1000 it is the same mechanism
         with proportionally less room to move. And with CONFIG_NO_HZ_FULL=y a
         nohz_full CPU running one runnable task can omit the tick entirely, making
         the window wider than CONFIG_HZ implies (P2, R0)
       → cross-check the per-CPU LOC rate in interrupts against CONFIG_HZ, and read
         nohz_full= on the command line

STEP 5 — If you act, in ascending order of blast radius.
  Every kernel-side branch changes scheduling for every task on the host, which is
  why GUIDANCE_MODEL.md lists the preemption model as its own R5 example.
  IF the workload keeps per-CPU data structures with a heavyweight preemption
     fallback and CONFIG_RSEQ=y
  THEN → the rseq route is the durable fix and touches nothing but your own code
         (P3, R3)
       → verify: re-record and confirm the fallback-path rate in perf_profile or
         hotline falls while throughput holds; the ctxt rate should barely move

  IF you want to test the kernel-side remedy
  THEN → with root and no reboot, write the model to /sys/kernel/debug/sched/preempt:
         immediate effect, reverts as fast (P3, R1). For a durable test, preempt=none
         as a boot parameter is reversible with a reboot and needs no rebuild — but if
         CONFIG_PREEMPT_DYNAMIC is not set, no boot or runtime lever exists at all and
         this becomes a different kernel or AMI (P3, R4)
       → expect this finding to KEEP FIRING; the config flag is unchanged by design
       → verify: read the debugfs file back, or confirm preempt=none in /proc/cmdline
         after the reboot (or CONFIG_PREEMPT_NONE on the new image), then re-record and
         compare the recovered ctxt rate against the baseline

  IF the service is latency-sensitive and was validated against the current model
  THEN → treat the change as behaviour-changing rather than a tuning knob, and stage
         it like a release (P2, R5)
       → verify: compare application tail latency, not throughput, across a full
         traffic profile before and after; a flat p50 with a moved p99 is the
         expected shape of the risk

STEP 6 — What survives?
  VALID      : the config fact itself — CONFIG_PREEMPT_LAZY really is "y" and the
               kernel major really is >= 7
  CAUTION    : every claim about the ACTIVE model, which the rule never observed;
               and any reading of the RES/IPI0 series as a context-switch proxy
  CONFOUNDED : this finding on one run of a comparison where Kernel Version Mismatch
               also fired, since the preemption model travels with the kernel build
  VOID       : the description's "is running with" under CONFIG_PREEMPT_DYNAMIC; the
               score as a magnitude; the finding as an explanation when it fired on
               both runs; and the old claim that aperf does not collect ctxt at all

INSUFFICIENT DATA
  IF the archives are gone AND the report is single-run AND the build string is
     unavailable
  THEN → nothing in or out of the report can test the hypothesis (P4, R1)
       → re-record with the tar.gz retained, capture /proc/version and /proc/cmdline
         alongside it, and set kernel.sched_schedstats=1 if you want schedstat data
       → verify: on the new run, `strings cpu_utilization.bin | grep '^ctxt '`
         returns one line per snapshot and STEP 2 becomes answerable
```

## Runtime-specific consequences

Preemption timing reaches each runtime through its threading model and its stop-the-world mechanism, and the sign of
the effect is not the same for all four:

| Runtime | How lazy preemption reaches it | What to check |
|---|---|---|
| **Java** | The most exposed runtime, for a reason specific to the JVM: **every GC and deoptimisation pause needs all threads to reach a safepoint**, and a lazily-marked thread keeps running to the next tick instead of yielding, so *time-to-safepoint* stretches. That cost lands in pause duration, not in CPU. Thread-dense servers also feel the interleaving change in lock hold times, and glibc/tcmalloc per-CPU arenas make the `rseq` remedy directly relevant | JFR safepoint and pause statistics rather than aperf's averages; `num_threads` in `processes`; whether `jvmArguments` in `java_profile` selects a concurrent collector (less exposed) or a stop-the-world one (more) (P2, R2) |
| **.NET** | Server GC suspends threads by hijacking return addresses and polling — the same class of rendezvous as a JVM safepoint, with the same sensitivity to a delayed switch. Per-core Server GC heaps mean the per-CPU-locality argument applies to the allocator too | GC pause counters and `%` time in GC against the recovered `ctxt` rate; whether `DOTNET_gcServer` is set, since workstation GC is far less rendezvous-heavy (R2) |
| **Python** | **The least exposed of the four for CPU-bound code**, because the GIL already serialises bytecode execution: only one thread runs at a time and `sys.setswitchinterval` (5 ms by default) is a *voluntary* handoff below the 10 ms tick, so laziness rarely changes the pattern. `multiprocessing` workers are single-threaded CPU-bound processes — the throughput-favouring case | Whether the workload is GIL-bound (little to see) or `multiprocessing`-parallel (expect the intended throughput win); per-process `stime` in `processes` (R1) |
| **Perl** | Single-threaded, usually preforking, and therefore **the clean throughput case**: each worker is a long-running CPU-bound process with no per-CPU structures and no rendezvous, so longer uninterrupted runs are pure upside. If anything regresses here, look for a cause other than preemption | Per-process `utime` in `processes` and `ipc` in `perf_stat`; a regression that does not move the recovered `ctxt` rate is not a preemption effect (R1) |

**The cross-cutting rule: rendezvous frequency decides the sign.** A runtime that periodically requires *all* threads
to stop — a JVM safepoint, a .NET GC suspension — pays for delayed preemption in pause length, because the pause
cannot start until the last lazily-marked thread yields. A runtime with no such rendezvous, running long-lived
CPU-bound work, collects the throughput benefit with none of the cost. Thread count amplifies the first case and is
irrelevant to the second.

## Architecture-specific considerations

**The one architecture fact that will silently break a comparison is the name of the proxy row.** aperf's frontend
carries two descriptions for the same concept — `RES (Rescheduling interrupts)` on x86_64 and `IPI0 (Rescheduling
interrupts)` on arm64, both with `readableName: "Rescheduling Interrupts"`, `desired: "depends"`. A cross-architecture
comparison therefore has **no shared row to compare**, and a filter or script looking for one name finds nothing on
the other platform rather than reporting a difference.

| Platform | Rescheduling-IPI row | What else differs |
|---|---|---|
| **x86_64** | `RES` in `/proc/interrupts`, plus a 554-field `intr` line that aperf drops entirely | `softirq` and `intr` are both discarded at processing time, so IPI accounting comes only from the per-name rows |
| **arm64 / Graviton** | `IPI0`, with `IPI1` carrying function-call interrupts | The IPI rows are named positionally, so a kernel change can renumber them; verify against the row descriptions, not the index |

**What is *not* architecture-dependent, despite looking like it:**

- **`CONFIG_HZ` and `CONFIG_PREEMPT_LAZY` are build options, not properties of the platform.** Two Graviton AMIs
  can differ, and so can two x86_64 ones; a mixed-architecture fleet on one distro version usually agrees, but that
  is a packaging convention, not a guarantee. Read the keys; do not infer them from the instance type.
- **The `ctxt` recovery works identically on both.** `/proc/stat`'s `ctxt` line is architecture-independent, and
  the `split.len() < 9` filter that drops it is too — so the archive workaround in STEP 2 is portable.
- **`rseq` is available on both** (`CONFIG_RSEQ=y` on Amazon Linux 2023 for x86_64 and arm64), though the
  per-CPU-cache allocators that benefit from it are tuned differently per platform. See
  [ARCHITECTURE.md](../ARCHITECTURE.md) for the PMU-side differences that affect the `perf_stat` corroboration.

## Verification

**Verify through the recovered `ctxt` rate, never through this finding.** It reads a compile-time flag, so it keeps
firing after `preempt=none` and after a debugfs write; its disappearance is not a success signal and its persistence
is not a failure. The sequence that works: confirm the change took effect (`/proc/cmdline` after a reboot, or reading
`/sys/kernel/debug/sched/preempt` back as root); re-record with the same `--interval` and `--period`; extract both
archives and compare `strings cpu_utilization.bin | grep '^ctxt '` rates alongside `system` CPU from
`cpu_utilization`; then check that the thing you were trying to fix moved — application tail latency for a latency
regression, `ipc` and throughput for a throughput one. **Keep the `.tar.gz` files**: the HTML report alone cannot
answer the central question, and once the archive is gone the measurement is unrecoverable. If you took the `rseq`
route instead, the `ctxt` rate should stay roughly flat while the fallback-path cost in `perf_profile` or `hotline`
falls — that difference is what distinguishes fixing the sensitivity from changing the scheduler.

## Do not

- **Do not read this as a problem.** It is scored `Neutral` (0) on purpose: a context flag, not a defect.
- **Do not read "is running with" literally.** The rule verified a compile-time config flag, not the active
  model. With `CONFIG_PREEMPT_DYNAMIC`, `preempt=` on the command line wins — and aperf cannot see it.
- **Do not say aperf does not collect context switches.** It records all of `/proc/stat` into
  `cpu_utilization.bin` and drops the non-`cpu*` lines at processing time. `ctxt` is in every archive; recover it
  with `strings` before concluding the measurement is unavailable.
- **Do not use the rescheduling-IPI series as a context-switch proxy.** Measured at **29/s against 42,703/s** on a
  real run — 1/1483 — because it counts only cross-CPU resched requests. And it is a **per-CPU average**, so
  multiply by the CPU count before comparing anything at all.
- **Do not lead with `/sys/kernel/debug/sched/preempt`.** `/sys/kernel/debug` is `drwx------ root root`; as an
  ordinary user you get Permission denied. `/proc/version` and `uname -v` answer the same question for free.
- **Do not treat the finding persisting after `preempt=none` as a failed fix.** The config flag is unchanged by
  design; verify through `/proc/cmdline` and the recovered `ctxt` rate instead. And **do not use it to explain a
  difference when it fired on both runs** — identical configuration explains nothing.
- **Do not read absence as evidence.** The rule gates on `major >= 7` and stays silent on 6.x regardless of the
  config; a missing `kernel_config` data type, a run absent from it, or a version string with a non-numeric leading
  component — `7-amzn` parses to 0 — all skip it just as silently.
- **Do not navigate `kernel_config` by `Section`.** A third of its keys are filed under a group that had already
  closed; search by key name. See `huge-page-disabled.md`.
- **Do not expect average-based metrics to reveal the effect.** The characteristic cost is tail latency and
  safepoint-pause length, which period statistics hide.
- **Do not rebuild a kernel to test this**, and **do not treat the change as a tuning knob**. `preempt=none` at
  boot gets the same answer reversibly, and `GUIDANCE_MODEL.md` classifies the preemption model as R5 for a
  reason: it changes scheduling for every task on the host.
- **Do not chase it before the negative-scored findings, and do not overlook it because it sorts low.** Its zero
  score encodes exactly that ordering and gives you no ratio, **no score table**, and no severity to weigh; it also
  sorts below every negative finding, pages down — yet it is often what explains an inexplicable regression.

## References

- Rule definition: `src/analytics/rules/multi_data_rules.rs:16` — `PreemptLazyDetectedRule`; requires **both**
  `systeminfo` and `kernel_config` (`:25`, `:29` — early `return` if either is absent); major version via
  `version.split('.').next().and_then(|m| m.parse::<u32>().ok()).unwrap_or(0)` (`:44`) with
  `if major < 7 { continue }` (`:49`); `is_lazy` via exact `== "y"` with `.unwrap_or(false)` (`:53`); description built
  inline at `:61` as `"Kernel {} in {} is running with PREEMPT_LAZY preemption model."`; inserted under data type
  `kernel_config`, key `CONFIG_PREEMPT_LAZY` (`:66`); message `PREEMPT_LAZY_MESSAGE` at `:12`. Score is
  `Score::Neutral.as_f64() = 0.0` (`src/analytics/mod.rs:147`), **inserted directly — no `compute_finding_score` call,
  so the score is flat.**
- Registration, lookup, and unit tests: `multi_data_analytical_rules!(PreemptLazyDetectedRule)`,
  `src/analytics/mod.rs:269`, and `get_multi_data_rules()`, `multi_data_rules.rs:82` — **the only multi-data rule in
  aperf**; key resolution through `key_value_value_by_key` → `lookup_key_value`,
  `src/data/common/processed_data_accessor.rs:157` and `:571`, scanning all key-value groups with first match
  winning. Tests at `multi_data_rules.rs:118`–`:145`: `triggers_k7_preempt_lazy` (7.0.1 + `y` ⇒ fires), `skips_k6`
  (6.12.0 + `y` ⇒ **no finding**), `skips_no_preempt_lazy` (7.0.1, key absent ⇒ no finding).
- Collection dependency: `src/data/kernel_config.rs` — reads `/boot/config-$(uname -r)`, falls back to
  `/boot/config`, and **on failure substitutes the literal `KERNEL_CONFIG=NOT FOUND`** (`:94`), which removes
  `CONFIG_PREEMPT_LAZY` and **silently disables this rule** while making `Huge Page Disabled` fire.
- **The discarded context-switch counter, and where the raw string survives:** `src/data/cpu_utilization.rs:43` —
  `self.data = std::fs::read_to_string("/proc/stat")?` stores the file whole; `ProcKernelStat::from_raw_data` (`:64`,
  called from `:147`) then drops every line with fewer than 9 fields (`if split.len() < 9 { continue }`, `:73`) and
  every line without a `cpu` prefix (`:79`, `:86`–`:89`), so `ctxt`, `btime`, `processes`, `procs_running`,
  `procs_blocked`, `intr` and `softirq` never reach the report. The raw string is nonetheless persisted by
  `src/data_collection.rs:305` — `bincode::serialize_into(&mut self.data_file, &self.data)?` into the append-mode file
  opened at `:247`–`:252`, path from `data_file_path` (`src/lib.rs:159`, `APERF_FILE_FORMAT` at `:34`) — and archived
  by `create_run_data_archive`, `src/record.rs:306`–`:316`. Hence
  `strings cpu_utilization.bin | grep '^ctxt '`, verified to return one line per snapshot on a real run.
- **The IPI proxy, its aggregate, and its row names:** `src/data/interrupts.rs:33` reads `/proc/interrupts`; `:146`
  applies `time_series_data_processor_with_average_aggregate!` ⇒ `TimeSeriesDataAggregateMode::Average`
  (`src/data/common/time_series_data_processor.rs:431`; contrast `Sum` at `:443`, `MaxSeries` at `:457`) — so the
  series is a **per-CPU average**, not a system total. The rows are `RES (Rescheduling interrupts)` and
  `IPI0 (Rescheduling interrupts)`, `src/report_frontend/src/definitions/data-descriptions.ts:2463` and `:2343`, both
  `readableName: "Rescheduling Interrupts"`, `desired: "depends"`, and **architecture-specific**. And
  `src/analytics/rules/interrupts.rs` is four lines — `impl AnalyzeData for InterruptData {}` — so **no finding
  will ever flag a rescheduling-IPI shift.**
- **`Kernel Version` provenance, and the absence of per-task counters:** `src/data/systeminfo.rs:122` calls
  `sys.kernel_version()` and `:175` files it under `"Kernel Version"`; `sysinfo = "0.26.2"` resolves to 0.26.9,
  whose `kernel_version()` (`sysinfo-0.26.9/src/linux/system.rs:525` — a path in the *crate*, not in aperf)
  returns the `release` field of `libc::uname()` — **`uname -r`,
  not `/proc/version`** — so the build string naming the preemption model is never collected. And
  `src/data/processes.rs` reads only `/proc/<pid>/stat` (`UserSpaceTime`→field 11, `KernelSpaceTime`→12,
  `NumberThreads`→17, `VirtualMemorySize`→20, `ResidentSetSize`→21); `/proc/<pid>/status`, carrying
  `voluntary_ctxt_switches`, is never opened.
- Zero-score UI behaviour: `getFindingColor`,
  `src/report_frontend/src/components/analytics/AnalyticalFindings.tsx:34` — `score == 0` ⇒ gray
  `rgba(125,125,125,0.3)`; `FindingIcon` (`:44`) ⇒ `face-neutral`; `isFindingTypeExpected`,
  `src/report_frontend/src/components/analytics/common.tsx:52` ⇒ finding type `"zero"`, displayed as
  **"Neutral"** (`getFindingTypeReadableName`, `src/report_frontend/src/utils/utils.ts:107`), all three types
  selected by default (`ReportStateProvider.tsx:87`); sorted by `.sort((a, b) => a.finding.score -
  b.finding.score)`, `src/report_frontend/src/utils/analytics.tsx:40` — **ascending, so zero sits below every
  negative finding** — with 5-item home-page pagination (`AnalyticalFindings.tsx:257`).
- Related playbooks: `huge-page-disabled.md`, `../systeminfo/kernel-version-mismatch.md`,
  `../systeminfo/inconsistent-number-of-cpus.md`,
  `../cpu_utilization/excessive-system-cpu-utilization.md`, `../cpu_utilization/underutilized-cpu.md`.
- [Upstream discussion referenced by the rule](https://lore.kernel.org/all/20260403191942.21410-1-dipiets@amazon.it/T/#t)
- [Lazy preemption (LWN)](https://lwn.net/Articles/1000135/) and [rseq(2)](https://man7.org/linux/man-pages/man2/rseq.2.html)
