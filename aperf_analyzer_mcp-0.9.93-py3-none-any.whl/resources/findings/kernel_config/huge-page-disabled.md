---
rule_name: Huge Page Disabled
data_type: kernel_config
data_key: CONFIG_TRANSPARENT_HUGEPAGE
template: key_value_key_expected
condition: "CONFIG_TRANSPARENT_HUGEPAGE != \"y\" (or key missing)"
base_score: Poor
score_sign: negative
requires_comparison: false
aperf_message: "Using huge-pages should reduce TLB pressure and generally improve performance on all EC2 instance types, but using exclusively huge-pages may sometime lead to performance degradation. Fully test your application after enabling and/or allocating huge-pages."
source: src/analytics/rules/kernel_config.rs:9
---

# Huge Page Disabled

## What fired

`CONFIG_TRANSPARENT_HUGEPAGE` is **not** `"y"` in the collected kernel config — or the key is **absent
entirely**, which produces a differently worded finding at the same score. Per aperf's own legend: `"y"` means
compiled into the kernel, `"not set"`/`"n"` means not compiled in, `"m"` means a loadable module.

Base score `Poor` (**−16**), flat — this template inserts the score directly and never calls
`compute_finding_score`, so **there is no score table for this rule.** Single-run: it evaluates every run
independently, including the base run, and needs no comparison.

**This is a configuration observation, not a measurement.** The rule read a compile-time flag from
`/boot/config-*`; it did **not** observe TLB misses, page faults, or anything about how the workload behaved.
Whether it matters is decided in `perf_stat` and `vmstat`, not here.

## The processing defect — a third of the keys are filed under the wrong section, including this one

Running aperf's own parser over three real Amazon Linux 2023 kernel configs (`6.12.94-123.180`, `-123.190`,
`-123.192`, all x86_64) produces an identical census: **229 key-value groups, 5,014 keys — and 1,737 of those
keys (34.6%) are attributed to a config section that had already closed.**

The cause is in `collect_data` (`src/data/kernel_config.rs:115`–`:186`). A new group opens only on a three-line
`#\n# Name\n#` comment header (`:126`–`:130`). The closing marker `# end of Name` **does not pop the group**: when
the name matches the current group it reaches `continue` (`:165`–`:167`) and returns, leaving that group as
`last_mut()`. So every entry between an `end of X` line and the *next* three-line header is filed under `X`.
**This rule's own key is one of them** — `# end of Slab allocator options` sits at line 1101 and
`CONFIG_TRANSPARENT_HUGEPAGE` at line 1146, 45 lines later with no intervening header:

| Key | Line in `/boot/config-*` | Section aperf reports | Section it belongs to |
|---|---|---|---|
| `CONFIG_TRANSPARENT_HUGEPAGE`, `_ALWAYS`, `_MADVISE` | 1146–1148 | `Memory Management options:Slab allocator options` | `Memory Management options` |
| `CONFIG_COMPACTION` | 1128 | `Memory Management options:Slab allocator options` | `Memory Management options` |
| `CONFIG_HUGETLB_PAGE` | 5132 | `File systems:Pseudo filesystems` | `File systems` |

**What this does and does not break.** It does **not** affect the rule: `lookup_key_value` scans *all* groups and
returns the first match (`processed_data_accessor.rs:571`), so the value found is correct regardless of which
group holds it. What it breaks is **navigation** — the `Section` column on the report's `kernel_config` page is
wrong for a third of its rows, so **filtering or scanning by section will not find this key**, and the label it
does show is actively misleading. Search by key name, never by section. Two adjacent facts from the same census
are reassuring, though: **zero keys appear in more than one group** across all 5,014, so `lookup_key_value`'s
first-match-wins scan over a `HashMap` of groups — order-dependent in principle — **has nothing to disambiguate
and is deterministic in practice**; and exactly one group-name collision occurs (`Device Drivers:Media drivers`,
an empty group overwritten in `parse_kernel_config`'s final `insert`), losing **no keys**.

**The collection-failure case has a distinct visual tell, and it is worth learning.** When `/boot/config-*` is
unreadable, `get_kernel_config_data` substitutes the literal `KERNEL_CONFIG=NOT FOUND` (`:94`) with only a
`debug!`, yielding **one group, named `""`, holding one key**. In the frontend, `buildKeyValueTable` leaves
`isDummySection` true when every group name is empty (`KeyValueTable.tsx:20`) and therefore **omits the `Section`
column entirely** (`:36`). So a `kernel_config` page with **no Section column at all** is a collection failure,
full stop — you do not need to count keys.

## Reasoning

**What THP buys, and why the frontend attaches its TLB guidance to this exact key.** A 2 MiB transparent huge
page replaces 512 base-page TLB entries with one, and is faulted in with **one** fault instead of 512. The
frontend's description says it directly: THP improves performance "by speeding up page faults during memory
allocation, by reducing the number of tlb misses and by speeding up the pagetable walking" — three distinct wins
landing in three different data types (`vmstat` fault counts, `perf_stat` TLB counters, `perf_stat` stall
metrics). **This is the only `kernel_config` rule that carries the frontend's `TLB_MISS_OPTIMIZATION`
guidance**, and its key is the only one in the whole data type with a `fieldDescription` at all, which is why it
is the natural landing point for any TLB-miss investigation.

**The 512× multiplier is not a constant — read it from the host.**
`/sys/kernel/mm/transparent_hugepage/hpage_pmd_size` gives the exact PMD-mapped huge page size in bytes; on the
AL2023 x86_64 host used above it is `2097152`, i.e. 2 MiB over a 4 KiB base page, hence **512×** — the figure the
four `vmstat` fault playbooks quote. A different base page granule changes the ratio.

**Why the rule tests the compile-time config rather than the runtime setting — and why that is its central
weakness.** THP has two independent gates: **compile-time**, `CONFIG_TRANSPARENT_HUGEPAGE` (is the code in the
kernel at all?), and **runtime**, `/sys/kernel/mm/transparent_hugepage/enabled` (`always`, `madvise`, or
`never`). This rule only reads the first. **A kernel with `CONFIG_TRANSPARENT_HUGEPAGE=y` and
`transparent_hugepage=never` at runtime has THP fully disabled and this rule stays completely silent.** That is
the more common configuration in practice — most distro kernels compile THP in, and operators disable it at
runtime (often for database workloads, or via a boot parameter). **So the absence of this finding is weak evidence
that THP is active, while its presence is strong evidence that it is not.** aperf collects neither the runtime
setting nor the command line, so check it out of band — or infer it from `vmstat`'s `thp_*` counters.

**The compiled-in default *is* recoverable from the data, contrary to what you might assume.** Three sibling keys
are collected alongside the gate and encode the built-in default outright:
`CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS`, `_MADVISE`, and `_NEVER` — exactly one is `"y"`. On the AL2023 config above,
`_MADVISE=y` and the other two are `"not set"`, which correctly predicts the observed runtime state
(`always [madvise] never`). **No rule checks these, so read them by hand**: one search converts "THP is compiled
in" into "THP is compiled in and defaults to `madvise`" — a materially different fact for an application that
never calls `madvise`.

**Why `Poor` (−16) and not worse — and why the message hedges.** The message is unusually two-sided for an
aperf rule: THP "should reduce TLB pressure and generally improve performance on all EC2 instance types, **but
using exclusively huge-pages may sometime lead to performance degradation. Fully test your application after
enabling and/or allocating huge-pages.**" That hedge is earned. THP's real costs are `khugepaged` CPU scanning
and collapsing in the background; allocation stalls when a 2 MiB contiguous region is not immediately available,
since direct compaction can block an allocating thread for milliseconds (`compact_stall` and
`thp_fault_fallback` show it); memory bloat from internal fragmentation, where touching one 4 KiB page in a
sparse mapping commits 2 MiB; copy-on-write amplification, where one post-`fork()` write to a shared huge page
copies **2 MiB** rather than 4 KiB (why preforking servers can *regress* — see Runtime-specific consequences);
and latency variance, which is why latency-sensitive and database workloads frequently disable it deliberately.
So the finding is a legitimate "you are probably leaving performance on the table" signal, not a defect report.
`Poor` positions it as worth investigating but not as a validity gate.

**The three-valued config space matters for the reading.** **`"not set"`** is aperf's own rendering of a
`# CONFIG_TRANSPARENT_HUGEPAGE is not set` line (`:147`, `:151`) and means THP is genuinely **not compiled in** —
the strongest form of the finding, and the one that needs a different kernel to fix; **`"n"`** is the same fact
spelled differently. **`"m"`** is anomalous: THP is not tristate in mainline, so it suggests a vendor kernel
rather than a real modular THP. **A missing key** is usually a collection problem — check for the absent
`Section` column described above.

**Folios changed the calculus on modern kernels — and the frontend's own guidance is now incomplete.** Per the
`TLB_MISS_OPTIMIZATION` text: on kernels ≥ 6.9, THP is extended with folios providing **16 KiB and 64 KiB** pages
in addition to 2 MiB, each independently controllable under
`/sys/kernel/mm/transparent_hugepage/hugepages-*kB/enabled`. On the 6.12 host measured here, **nine** such
directories exist (8, 16, 32, 64, 128, 256, 512, 1024, 2048 kB), not the three the guide names — and their
observed defaults are **not** uniform:

| sysfs node | Observed state on 6.12 AL2023 | Consequence |
|---|---|---|
| `transparent_hugepage/enabled` | `always [madvise] never` | Top-level: `madvise` only |
| `hugepages-2048kB/enabled` | `always [inherit] madvise never` | Follows the top level |
| `hugepages-16kB`, `-64kB`, and the other six | `always inherit madvise [never]` | **Pinned off — they ignore the top level** |

**So `echo always > .../enabled`, exactly as the frontend instructs, enables 2 MiB THP and leaves every folio
size disabled**, because only the 2048 kB node is set to `inherit`; the folio benefit needs a second, explicit
write per size. That is a real gap between aperf's advice and its effect on a current kernel, so **read
`Kernel Version` and then the per-size nodes rather than assuming one write did the job.**

## Reading the description

`key_value_key_expected` emits one of two descriptions.

**Value present but not `"y"` — template, then the same text on a real run:**

```
The value of {key} in {run} is "{value}", instead of "{expected}".
The value of CONFIG_TRANSPARENT_HUGEPAGE in aperf_record is "not set", instead of "y".
```

**Key missing — template, then a real run:**

```
The key {key} in {run} is missing, instead of being set to {expected}
The key CONFIG_TRANSPARENT_HUGEPAGE in aperf_record is missing, instead of being set to y
```

Four things to know:

1. **Read which of the two forms you got.** "is `"not set"`" is a genuine config fact. **"is missing" is usually a
   collection failure** — most often a container or minimal AMI with no `/boot/config-*`.
2. **The value is quoted verbatim.** `"not set"` is aperf's own rendering of a `# CONFIG_… is not set` line, not a
   string from the file.
3. **The score is flat −16.** No ratio, no magnitude, no `compute_finding_score` call. **No score table applies.**
4. **This rule fires per run independently**, including the base run of a comparison. Seeing it on both runs means
   both kernels lack THP — at least *consistent*, and therefore not a comparison-validity problem. The
   missing-key form has no trailing period and does not quote the expected value — cosmetic, but a quick way to
   recognize which branch produced the text.

## Interpretation

**First, decide whether this is a config fact or a collection artifact:**

| Evidence | Reading |
|---|---|
| **Description says "is missing"** and the `kernel_config` page has **no `Section` column** | **Collection failure.** `/boot/config-*` was unreadable — typical in containers and minimal AMIs. **The finding says nothing about THP.** `PREEMPT_LAZY Detected` is also disabled |
| Description says "is missing" but the page shows sections and thousands of keys | Genuinely absent key — unusual. Likely a very old or heavily customized kernel |
| Value is **`"not set"`** or **`"n"`** | **THP is not compiled in.** No runtime setting can enable it; fixing this needs a different kernel or AMI |
| Value is **`"m"`** | Unusual — THP is not tristate in mainline. Suspect a vendor or non-standard kernel |
| **Finding absent** | **Weak evidence only.** THP is compiled in, but `transparent_hugepage=never` at runtime would still disable it and this rule cannot see that |

**Then decide whether it matters — the measurements, not the config:**

| Evidence | Reading |
|---|---|
| **High TLB miss rates** (`data-tlb-mpki`, `inst-tlb-mpki`, `*-tlb-tw-pki` in `perf_stat`) | **THP would likely help.** This is the primary payoff and exactly what the frontend's `TLB_MISS_OPTIMIZATION` guidance addresses |
| TLB miss rates low | **THP is unlikely to help much.** The finding is informational; do not spend effort on it |
| `Excessive Page Fault Rate` or high `pgfault`; `Increased Minor Page Faults` | Losing THP multiplies minor faults by `hpage_pmd_size / base_page_size` — **512× on x86_64** — for anonymous first-touch. A plausible sole cause; the second is the same mechanism in comparison form |
| High backend stalls / low IPC in `perf_stat` | Page-table walks contribute to backend stalls; THP shortens them |
| Large anonymous footprint (`AnonPages` in `meminfo`) | The more anonymous memory, the more THP has to work with |
| Workload is mostly file-backed or small-allocation | Classic 2 MiB THP helps less — **but folios on ≥ 6.9 kernels change this** |
| Workload is a **preforking** server (Perl, `fork`-mode Python) | THP can *hurt*: post-`fork()` copy-on-write copies a full huge page per write |

**Then check the runtime state, which this rule cannot see:**

| Evidence | Reading |
|---|---|
| **`thp_fault_fallback` non-zero in `vmstat`** | THP allocation is being attempted and **failing to fragmentation** — so THP *is* active at runtime. Contradicts a "disabled" reading |
| **`thp_fault_alloc` or `thp_collapse_alloc` non-zero** | Huge pages are being allocated on fault, or `khugepaged` is collapsing — THP is working. Conversely, **all `thp_*` counters flat at zero** is consistent with THP genuinely inactive, by config or by runtime setting — **the best in-report proxy for the runtime state** |
| `thp_fault_alloc` non-zero but `AnonHugePages` ≈ 0 | THP is *available and barely used* — the classic `madvise`-default signature with an application that does not opt in |
| `AnonHugePages` in `meminfo` non-zero | **THP is in use right now.** Directly contradicts a "disabled" conclusion — check for a collection artifact |
| `compact_stall` high | Compaction pressure — the cost side of THP. Relevant to whether enabling it is safe |
| `HugePages_Total`/`Hugetlb` non-zero | **Explicit** huge pages are reserved (a different mechanism from THP). The workload may already use pinned huge pages via `mmap` |

**Combinations:**

| also fired / observed | Reading |
|---|---|
| **`PREEMPT_LAZY Detected` absent while `Kernel Version` is 7.x** | Suspicious — that rule also needs `kernel_config`. **Consistent with the same collection failure** |
| `Kernel Version` ≥ 6.9 | **Folios apply**: per-size huge pages make THP cheaper and more broadly useful. The upside is larger — but the per-size nodes default to `never`, so enabling the top level is not enough |
| `Kernel Version Mismatch` in a comparison | THP config commonly differs with the kernel build — **this can explain fault-rate and TLB deltas outright** |
| This finding on **one run only** / on **both runs** | One run only is **a real configuration asymmetry** and a strong candidate explanation for memory-related deltas; both runs is consistent configuration — not a comparison problem, just an optimization opportunity on both |
| `Major Page Faults Detected` | Unrelated mechanism (storage-backed faults). THP addresses minor faults and TLB pressure |

**Known false positives — the most important one is systematic:**

- **Container or minimal-AMI collection**, where `/boot/config-*` does not exist, `get_kernel_config_data` falls
  back to `KERNEL_CONFIG=NOT FOUND`, and the missing-key branch fires. **The host's THP may be fully enabled.**
- **Deliberately disabled THP** — common and often correct for latency-sensitive and database workloads, exactly
  as the rule's own message warns.
- **A workload that would not benefit**: small heaps, file-backed access patterns, low TLB miss rates. The config
  is suboptimal in the abstract and irrelevant in practice.
- **Explicit huge pages already in use** (`vm.nr_hugepages`, `hugepagesz=`), so the workload gets huge pages
  without THP — `HugePages_Total` shows this; and **`"m"` on a non-standard kernel**, where the value does not
  mean what the legend implies.

**Blind spots, in order of importance:**

- **The runtime setting is invisible.** `transparent_hugepage=never` with `CONFIG_TRANSPARENT_HUGEPAGE=y` yields
  **no finding** and **no THP**. This is the rule's biggest gap, and `vmstat`'s `thp_*` counters plus
  `AnonHugePages` are the only in-report substitutes.
- **Per-size folio settings are invisible**, and on a 6.12 kernel **eight of the nine default to `never`**
  independently of the top-level toggle.
- **`madvise` mode is indistinguishable from `always`** here — although `CONFIG_TRANSPARENT_HUGEPAGE_MADVISE`
  *is* in the data and resolves it if you read it manually. An application that never calls `madvise` gets no
  THP even in a "THP enabled" configuration.
- **The kernel command line is not collected**, so `transparent_hugepage=never` as a boot parameter cannot be seen,
  and **the `Section` column lies for a third of the keys**, making section-based navigation unusable here.

## Corroborating data

| Check | Data type | What it tells you |
|---|---|---|
| **Which description form fired, and whether the page has a `Section` column** | `kernel_config` | **Do this first.** "is missing" plus no Section column means `/boot/config-*` was unreadable — a collection artifact, not a THP fact |
| **`CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS`, `_MADVISE`, `_NEVER`** | `kernel_config` | **The compiled-in default, recoverable from the report.** Exactly one is `"y"`. **No rule checks them — read manually** |
| `CONFIG_COMPACTION`, `CONFIG_MIGRATION`, `CONFIG_THP_SWAP`; `CONFIG_PREEMPT_LAZY` presence and `PREEMPT_LAZY Detected` | `kernel_config` | Whether the machinery THP depends on is present at all; and a cross-check on whether `kernel_config` was collected at all |
| **`thp_fault_alloc`, `thp_fault_fallback`, `thp_collapse_alloc`, `thp_file_mapped`, `thp_split_pmd`** | `vmstat` | **The best available proxy for the runtime THP state.** Non-zero ⇒ THP is active despite the config finding. **No analytical rules — read manually** |
| `compact_stall`, `compact_fail` | `vmstat` | Fragmentation and compaction pressure — the cost side of enabling THP |
| **`pgfault`, `pgminorfault`** | `vmstat` | The fault multiplier. See `Excessive Page Fault Rate`, `Increased Minor Page Faults` |
| **`AnonHugePages`** | `meminfo` | **Non-zero means THP is in use right now** — directly contradicts a "disabled" reading |
| `HugePages_Total`, `HugePages_Free`, `Hugetlb`, `Hugepagesize`, plus `htlb_buddy_alloc_success` in `vmstat` | `meminfo` | Explicit (pinned) huge pages — a different mechanism the workload may already use |
| `AnonPages`; `ShmemHugePages`, `FileHugePages`, `FilePmdMapped` | `meminfo` | How much anonymous memory THP has to work with; huge pages in shmem and file mappings |
| **`data-tlb-mpki`, `inst-tlb-mpki`, `data-tlb-tw-pki`, `inst-tlb-tw-pki`** | `perf_stat` | **The primary payoff measurement.** High TLB miss rates are the case for enabling THP |
| `ipc`, `stall_backend_pkc`, `stall_frontend_pkc` | `perf_stat` | Page-table-walk cost surfaces as backend stalls |
| **`Kernel Version`**, `Kernel Version Mismatch` | `systeminfo` | **≥ 6.9 means folios apply** — per-size huge pages make THP cheaper and more useful. THP config often differs with the kernel build, explaining memory deltas |
| **`hpage_pmd_size`, and `hugepages-*kB/enabled` for every size** | out of band | **The exact fault multiplier, and which sizes are actually on.** Eight of nine default to `never` on 6.12 |
| `/sys/kernel/mm/transparent_hugepage/enabled`, `defrag`, `shmem_enabled`; the kernel command line (`transparent_hugepage=never`) | out of band | **The runtime setting this rule cannot see** — the decisive check. The command line is **not collected by aperf** at all |
| `vm.nr_hugepages` | `sysctl` | Explicit huge-page reservations. **No analytical rules — read manually** |
| JVM flags (`-XX:+UseTransparentHugePages`, `-XX:+UseLargePages`) | `java_profile` / out of band | Whether a Java workload is set up to use huge pages at all |

## Guidance

Ordered. **Steps 1–3 decide whether this finding is real and whether it matters.**

1. **Check which description form fired.** If it says **"is missing"**, look at whether the `kernel_config` page
   has a `Section` column at all. No Section column means every group name was empty — i.e. `/boot/config-*` was
   unreadable and the data set holds the single key `KERNEL_CONFIG` — typical for **containers and minimal AMIs**.
   **The finding then says nothing about THP.** Dismiss it and note that `PREEMPT_LAZY Detected` is disabled too.

2. **Establish the runtime state, which this rule cannot see.** `CONFIG_TRANSPARENT_HUGEPAGE=y` with
   `transparent_hugepage=never` gives no finding and no THP; the converse also matters. In-report: **non-zero
   `thp_fault_alloc`/`thp_fault_fallback`/`thp_collapse_alloc` in `vmstat` or non-zero `AnonHugePages` in
   `meminfo` means THP is active** despite what the config says. Out of band, read
   `/sys/kernel/mm/transparent_hugepage/enabled`.

3. **Decide whether THP would help *this* workload** by measuring, not by config. Read the TLB metrics in
   `perf_stat` (`data-tlb-mpki`, `inst-tlb-mpki`, `*-tlb-tw-pki`). **Low TLB miss rates ⇒ this finding is
   informational and not worth pursuing.** High rates ⇒ it is the top lever, and the frontend's own
   `TLB_MISS_OPTIMIZATION` guidance applies directly.

4. **Recover the compiled-in default from the report.** Search `kernel_config` for
   `CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS`, `_MADVISE`, and `_NEVER` — exactly one is `"y"`, and that is the kernel's
   built-in default. **Search by key name, not by section**: the `Section` column is wrong for these keys, which
   are reported under `Memory Management options:Slab allocator options`.

5. **Check the fault-rate angle, then read `Kernel Version`.** Without THP, anonymous first-touch costs
   `hpage_pmd_size / base_page_size` times more faults — **512× on x86_64 with 4 KiB pages** — so if
   `Excessive Page Fault Rate` or `Increased Minor Page Faults` also fired, this config can be the whole
   explanation. On **≥ 6.9**, folios add smaller huge pages that are far easier to allocate than 2 MiB ones: the
   upside is larger and the compaction-stall risk smaller than the classic tradeoff implies.

6. **If the value is `"not set"` or `"n"`, understand that no runtime change can fix it.** THP is not in the
   kernel; the remedy is a different kernel or AMI, a much bigger change than flipping a sysfs file. Weigh that
   against the measured TLB and fault evidence before recommending it.

7. **Respect the rule's own hedge before enabling THP.** The message says explicitly that "using exclusively
   huge-pages may sometime lead to performance degradation" and to "fully test your application". The costs are
   real: `khugepaged` CPU, compaction stalls (`compact_stall`), memory bloat from internal fragmentation,
   copy-on-write amplification after `fork()`, and latency variance. Latency-sensitive and database workloads
   often disable THP deliberately and correctly.

8. **If enabling is warranted, follow the frontend's ladder — and then verify each size individually.**
   `always` or `madvise` via `/sys/kernel/mm/transparent_hugepage/enabled`; **then read every
   `hugepages-*kB/enabled` node**, because on a 6.12 kernel only `hugepages-2048kB` is set to `inherit` and the
   rest are pinned to `never`, so the top-level write alone does not enable folios. For applications that `mmap`
   directly, explicit reservations (`sysctl -w vm.nr_hugepages=X`, or `hugepagesz=2M hugepages=512` at boot); and
   for Java, `-XX:+UseTransparentHugePages` (if THP is at least `madvise`) or `-XX:+UseLargePages` (if pages are
   reserved).

9. **Check whether huge pages are already in use by another mechanism, and note which runs fired.** Non-zero
   `HugePages_Total`/`Hugetlb` in `meminfo` means the workload may already have pinned huge pages, making the THP
   config largely moot. In a comparison, **one run only** is a real configuration asymmetry and a strong candidate
   explanation for memory and TLB deltas — check `Kernel Version Mismatch`, since THP config usually travels with
   the kernel build. Both runs firing is merely a shared optimization opportunity.

## Priority and execution risk

**Priority: P3 — Opportunistic** by default. This is a compile-time observation with no measured impact attached,
and the rule's own message tells you to test before acting. It rises to **P2** when TLB miss rates are high or a
fault-rate finding also fired, and to **P1** only when THP absence is the leading candidate for a measured
regression. It drops to **P4** whenever the "is missing" form fired on a container, because the finding then
carries no information about THP at all.

**Execution risk: R1 — Reversible, no restart** for the runtime remedy: writing `always` or `madvise` to
`/sys/kernel/mm/transparent_hugepage/enabled` takes effect immediately and reverts as fast, and per-size folio
toggles are the same. **R4** when the value is `"not set"`, because THP is not compiled in and the remedy is a
different kernel or AMI. **R5** for `always` on a latency-sensitive service, where compaction stalls and memory
bloat can move the tail latency profile without moving throughput — the exact degradation the message warns about.

**The score is flat −16** with no ratio and no magnitude: `"not set"`, `"n"`, `"m"`, and a missing key score
identically. Priority comes entirely from the corroborating measurements, never from the score.

Vocabulary: [../GUIDANCE_MODEL.md](../GUIDANCE_MODEL.md). Precedence: [../GATES.md](../GATES.md).

## Decision tree

Entry condition: `Huge Page Disabled` fired on at least one run.

```
STEP 0 — Which description form fired? This gates everything.
  IF the description says "is missing" AND the kernel_config page has NO Section
     column (every group name empty ⇒ the single key KERNEL_CONFIG)
  THEN → COLLECTION FAILURE, not a THP fact. /boot/config-* was unreadable, which is
         normal in containers and minimal AMIs (P4, R0)
       → the same failure silently disables PREEMPT_LAZY Detected; do not read its
         absence as a preemption fact either
       → no finding about THP can be drawn from this run

  IF the description says "is missing" but sections and thousands of keys are present
  THEN → the key is genuinely absent: a very old or heavily customized kernel (P3, R0)
       → treat as "not compiled in" and continue to STEP 2

  IF the value is "not set" or "n"
  THEN → THP is NOT COMPILED IN. No sysfs write can enable it (P3, R0)
       → continue to STEP 2, but note the remedy will be R4, not R1

  IF the value is "m"
  THEN → anomalous: THP is not tristate in mainline. Suspect a vendor kernel (P4, R1)
       → verify: read CONFIG_TRANSPARENT_HUGEPAGE from the host's own /boot/config-*
         directly; if it reads "y" there, the report's copy is not from this kernel

STEP 1 — Recover the compiled-in DEFAULT, which the gate does not report.
  Search kernel_config BY KEY NAME for the three siblings; exactly one reads "y".
  CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS  = default `always`
  CONFIG_TRANSPARENT_HUGEPAGE_MADVISE = default `madvise` (AL2023 6.12)
  CONFIG_TRANSPARENT_HUGEPAGE_NEVER   = default `never`
  Do NOT browse by Section: these keys are filed under "Memory Management
  options:Slab allocator options", a group that closed 45 lines earlier.
  IF the default is `madvise` and the application never calls madvise(MADV_HUGEPAGE)
  THEN → THP is effectively off despite being compiled in (P2, R0)
  IF the default is `never`
  THEN → the kernel ships THP disabled; a sysfs write is required (P3, R0)

STEP 2 — Is THP active at runtime RIGHT NOW? The config cannot tell you.
  Read the thp_* series in vmstat and AnonHugePages in meminfo.
  IF any of thp_fault_alloc / thp_fault_fallback / thp_collapse_alloc is non-zero,
     or AnonHugePages > 0
  THEN → THP IS ACTIVE. The finding contradicts the measurements — re-check STEP 0
         for a collection artifact before acting on it (P4, R0)

  IF thp_fault_alloc is non-zero but AnonHugePages is ~0
  THEN → THP is available and almost unused: the `madvise`-default signature with an
         application that does not opt in (P2, R1)
       → the cheap test is the top-level sysfs write, not an application change
       → verify: after `echo always > .../enabled`, re-record; AnonHugePages should
         become non-zero and thp_fault_alloc should rise

  IF every thp_* counter is flat zero
  THEN → consistent with THP genuinely inactive. This is the case the finding
         describes, and STEP 3 decides whether it matters (P3, R0)

STEP 3 — Would THP help THIS workload? Measure; do not reason from the config.
  Read data-tlb-mpki, inst-tlb-mpki, data-tlb-tw-pki, inst-tlb-tw-pki in perf_stat.
  IF perf_stat is absent (no PMU access — common in VMs and containers)
  THEN → the payoff cannot be measured in this report. Fall back to the fault-rate
         evidence in STEP 4 alone (P4, R0)

  IF the TLB miss rates are low and no fault-rate finding fired
  THEN → INFORMATIONAL ONLY. The config is suboptimal in the abstract and irrelevant
         in practice. Do not spend effort here (P4, R0)

  IF TLB miss rates are high, or Data TLB Table Walks / Instruction TLB Table Walks
     also fired
  THEN → THP is the top lever for this report, and TLB_MISS_OPTIMIZATION applies
         directly (P1, R1)
       → verify: enable THP, re-record, and confirm *-tlb-mpki and *-tlb-tw-pki fall
         while ipc rises. If the miss rates do not move, the pressure was not
         translation-related and THP is the wrong lever

STEP 4 — The fault-rate angle: the multiplier is per-host, not a constant.
  Read hpage_pmd_size out of band; divide by the base page size. On x86_64 with 4 KiB
  pages that is 2097152 / 4096 = 512.
  IF Excessive Page Fault Rate or Increased Minor Page Faults also fired
  THEN → losing THP can be the WHOLE explanation: anonymous first-touch costs one
         fault per base page instead of one per huge page (P1, R1)
       → verify: enable THP, re-record, and confirm pgfault falls by roughly the
         multiplier on the anonymous-allocation phase. A flat pgfault means the
         faults were file-backed and THP was never going to help
  ELSE → the fault path is not under pressure; judge this finding on the TLB
         evidence from STEP 3 alone (P3, R0)

STEP 5 — If enabling: which sizes, and the inherit trap.
  Read Kernel Version first.
  IF Kernel Version < 6.9
  THEN → only 2 MiB THP exists. One write to .../enabled is the whole change (P3, R1)
       → verify: AnonHugePages becomes non-zero and thp_fault_alloc rises

  IF Kernel Version >= 6.9
  THEN → folios exist, but the per-size nodes have INDEPENDENT defaults. On 6.12,
         nine sizes are exposed and only hugepages-2048kB is set to `inherit` —
         the other eight are pinned to `never` (P3, R1)
       → a top-level `echo always` therefore enables 2 MiB ONLY; aperf's own
         TLB_MISS_OPTIMIZATION text does not mention this
       → verify: after the top-level write, read every hugepages-*kB/enabled node
         and confirm the sizes you intended are `always` or `inherit`, not `never`

  IF the workload is latency-sensitive, or compact_stall is already non-zero
  THEN → prefer `madvise` over `always` and let the application opt in (P2, R5)
       → `always` can add compaction stalls and memory bloat that move the tail
         without moving throughput
       → verify: re-record and compare compact_stall, compact_fail, and application
         tail latency — not just throughput — before and after

  IF the value was "not set" or "n"
  THEN → no sysfs remedy exists; this is a kernel or AMI change (P3, R4)
       → verify: on the new image, confirm CONFIG_TRANSPARENT_HUGEPAGE reads "y" and
         that this finding stops firing

  IF HugePages_Total or Hugetlb is non-zero
  THEN → explicit huge pages are already reserved: a different mechanism that may
         already deliver the benefit (P4, R0)
       → ../meminfo/reduced-memory-availability.md, see that playbook for how pinned
         pages remove memory from MemAvailable

STEP 6 — What survives?
  VALID      : the config fact itself, when the value form (not the missing form)
               fired — CONFIG_TRANSPARENT_HUGEPAGE really is not "y"
  CAUTION    : any claim about the RUNTIME state; the gate never observed it, and
               `madvise` with a non-opting application looks identical to `always`
  CONFOUNDED : this finding on one run of a comparison where Kernel Version Mismatch
               also fired — THP config travels with the kernel build, so the two are
               not independent variables
  VOID       : the "is missing" form on a container; the score as a magnitude; and
               any THP conclusion contradicted by non-zero thp_* counters

INSUFFICIENT DATA
  IF perf_stat is absent AND no vmstat fault finding fired
  THEN → neither payoff can be measured: the finding is unactionable here (P4, R1)
       → re-record on a host with PMU access, or with a longer --period so the
         fault-rate rules have enough intervals to fire
       → verify: on the new run, either the TLB metrics appear and STEP 3 resolves,
         or they are still absent and this finding stays informational permanently
```

## Runtime-specific consequences

THP reaches each runtime through its allocator and its process model, and the sign of the effect is not the same
for all four:

| Runtime | How THP reaches it | What to check |
|---|---|---|
| **Java** | The heap is one large anonymous reservation — the ideal 2 MiB THP case. `-XX:+UseTransparentHugePages` makes the JVM `madvise(MADV_HUGEPAGE)` the heap, so it works only when the sysfs mode is at least `madvise`; with `never` the flag is silently inert. `-XX:+AlwaysPreTouch` combines well: pretouching faults in whole huge pages, cutting startup fault counts by the multiplier | `AnonHugePages` versus the configured heap size, and whether the flag is present in `jvmArguments`. If the flag is set and `AnonHugePages` is ~0, the sysfs mode is `never` (P2, R2) |
| **.NET** | Server GC heaps are large anonymous regions and benefit the same way, but **`DOTNET_GCLargePages` requires *reserved* hugetlb pages, not THP** — it is not the equivalent flag. THP applies to .NET with no flag at all once the sysfs mode is `always` | `HugePages_Total` if `GCLargePages` is set (it needs reservations), otherwise `AnonHugePages` for the plain THP path (R1) |
| **Python** | pymalloc arenas are 1 MiB via `mmap` — **below `hpage_pmd_size`, so arena allocation itself gets no PMD-mapped huge page**. The benefit arrives through large `numpy`/`pyarrow` buffers, and through folios on ≥ 6.9 where 16–64 KiB pages do fit an arena | Whether the footprint is dominated by the interpreter (little benefit) or by large array buffers (real benefit). Folio sizes matter more here than 2 MiB (R1) |
| **Perl** | **The runtime where THP can make things worse.** Preforking servers share a large read-mostly interpreter heap by copy-on-write; under THP a single write to a shared huge page copies the whole 2 MiB instead of 4 KiB, inflating RSS across every worker | `AnonPages` and total RSS growth across workers after `fork()`. If RSS climbs far above what the write volume justifies, THP-COW amplification is the mechanism (P2, R1) |

**The cross-cutting rule: the process model decides the sign.** A single long-lived process with a large heap
(Java, .NET, a monolithic native service) is the case THP was designed for. A preforking server relying on
copy-on-write sharing is the case where `always` should be avoided in favour of `madvise`, so huge pages land only
where the application asked; `fork()`-heavy Python (`multiprocessing` with the `fork` start method) sits in the
same hazard class as Perl.

## Architecture-specific considerations

**The fault multiplier and the folio sizes are both architecture-dependent, and neither is in the report.** Read
`hpage_pmd_size` on the host — the PMD-mapped huge page size in bytes — and divide by the base page size for the
exact factor the `vmstat` fault playbooks quote as 512×.

| Platform | Base page | `hpage_pmd_size` | Fault multiplier |
|---|---|---|---|
| x86_64, all EC2 | 4 KiB | 2 MiB (`2097152`, measured) | **512×** |
| arm64 / Graviton, 4 KiB granule | 4 KiB | 2 MiB | **512×** |
| arm64 / Graviton, 64 KiB granule | 64 KiB | 512 MiB | **8192×** — though base-page TLB pressure is already far lower |

**Graviton specifics worth knowing:**

- **The 64 KiB folio maps onto the arm64 contiguous-PTE hint**, which lets the hardware coalesce 16 adjacent
  4 KiB entries into one TLB entry. That makes 64 KiB mTHP unusually cheap on Graviton: it needs 64 KiB of
  contiguity rather than 2 MiB, so it rarely triggers compaction. **On a ≥ 6.9 Graviton kernel, enabling
  `hugepages-64kB` is often a better first move than the top-level toggle** — and it is one of the eight sizes
  that default to `never`.
- **Page size is a kernel build option, not a version**, and aperf collects neither it nor the config key that
  encodes it — two runs with identical `Kernel Version` strings can differ here.
- **The TLB counters that justify enabling THP are themselves architecture-dependent.** `data-tlb-tw-pki` and
  `inst-tlb-tw-pki` come from different PMU events on Graviton than on x86_64; cross-check `pmu_config.json`
  ([ARCHITECTURE.md](../ARCHITECTURE.md) §1) before comparing miss rates across a mixed pair of runs. The
  frontend's Graviton perfrunbook link below is the architecture-specific companion to this finding.

## Verification

Enable THP at the level the evidence justifies — `madvise` if the workload opts in or is latency-sensitive,
`always` otherwise — re-record with the same `--interval` and `--period`, and check three things in order:
`AnonHugePages` becomes non-zero and `thp_fault_alloc` rises (the change took effect); `*-tlb-mpki` and
`*-tlb-tw-pki` fall while `ipc` rises (the payoff is real); and `compact_stall`, `compact_fail`, and application
tail latency have not worsened (the cost is acceptable). **This finding itself will keep firing if the value was
`"not set"`** — a sysfs write does not change the compile-time flag, so use the sysfs nodes and the `vmstat`
counters as the verification signal, never the finding's disappearance. On ≥ 6.9, re-read every
`hugepages-*kB/enabled` node afterwards: a top-level write leaves the eight non-`inherit` sizes at `never`.

## Do not

- **Do not treat this as a measurement.** It is a compile-time flag; the payoff is measured in `perf_stat` TLB
  metrics and `vmstat` fault counts.
- **Do not navigate this data type by `Section`.** 1,737 of 5,014 keys (34.6%) are filed under a closed group,
  including `CONFIG_TRANSPARENT_HUGEPAGE` itself. Search by key name.
- **Do not trust the "is missing" form without checking for the `Section` column.** Its absence means every group
  name was empty — the `KERNEL_CONFIG=NOT FOUND` fallback — which is a collection failure, not a THP fact.
- **Do not read the absence of this finding as "THP is enabled".** `transparent_hugepage=never` at runtime is
  invisible to this rule, and non-zero `thp_*` counters or `AnonHugePages` mean THP is running regardless.
- **Do not assume the compiled-in default is unknowable.** `CONFIG_TRANSPARENT_HUGEPAGE_ALWAYS`/`_MADVISE`/`_NEVER`
  are all in the data; exactly one is `"y"`. No rule reads them, but you can.
- **Do not read the score as magnitude**, and **do not treat this as a comparison-validity gate** when it fires
  on both runs. Flat −16 with no ratio; `"not set"` and `"m"` score identically, and both runs firing means the
  configuration is at least consistent.
- **Do not enable THP reflexively.** The rule's own message warns about degradation and instructs you to fully
  test. Compaction stalls, `khugepaged` CPU, memory bloat, COW amplification, and latency variance are real costs.
- **Do not assume one sysfs write enabled folios.** On 6.12, eight of the nine `hugepages-*kB` nodes default to
  `never` and ignore the top-level setting; only `hugepages-2048kB` is `inherit`.
- **Do not quote 512× as a constant.** It is `hpage_pmd_size / base_page_size`; 64 KiB-granule arm64 gives 8192×.
- **Do not expect a runtime fix when the value is `"not set"`** — THP is not compiled in; that needs a new kernel.
- **Do not enable `always` on a preforking server without measuring RSS.** Post-`fork()` copy-on-write copies a
  full huge page per write, which inflates memory across every worker.
- **Do not overlook explicit huge pages.** `HugePages_Total` non-zero may already deliver the benefit.

## References

- Rule definition: `src/analytics/rules/kernel_config.rs:9` — `key: "CONFIG_TRANSPARENT_HUGEPAGE"`,
  `expected_value: "y"`, `score: Score::Poor`. **The only rule this data type has.**
- Rule template: `src/analytics/rule_templates/key_value_key_expected_rule.rs:47` — evaluates **every** run
  (including the base run) with no comparison; emits
  `"The value of {} in {} is \"{}\", instead of \"{}\"."` when the value differs (`:59`), and
  `"The key {} in {} is missing, instead of being set to {}"` when absent (`:75`); **inserts `self.score`
  directly — no `compute_finding_score` call, so the score is flat**. `Score::Poor = −16`,
  `src/analytics/mod.rs:147`.
- Key lookup: `key_value_value_by_key` → `lookup_key_value`,
  `src/data/common/processed_data_accessor.rs:157` and `:571` — scans **all** key-value groups, first match wins.
  Measured on three AL2023 configs: **229 groups, 5,014 keys, zero keys present in more than one group**, so the
  scan order has nothing to disambiguate.
- **Group-attribution defect:** `collect_data`, `src/data/kernel_config.rs:115`–`:186`. A group opens only on a
  three-line `#\n# Name\n#` header (`:126`–`:130`); `# end of Name` does **not** pop it, reaching `continue` at
  `:165`–`:167`. Measured on `/boot/config-6.12.94-123.{180,190,192}.amzn2023.x86_64`: **1,737 of 5,014 keys
  (34.6%) are filed under an already-closed group**, including `CONFIG_TRANSPARENT_HUGEPAGE` (line 1146, reported
  under `Memory Management options:Slab allocator options`, closed at line 1101). The nesting prefix comes from
  the `end of` fold at `:162`–`:185`; the final `HashMap::insert` is in `parse_kernel_config`, `:199`–`:230`.
- Collection fallback: `get_kernel_config_data`, `src/data/kernel_config.rs:78` — reads
  `/boot/config-$(uname -r)`, falling back to `/boot/config`; **on failure substitutes the literal
  `KERNEL_CONFIG=NOT FOUND` with only a `debug!` log** (`:94`), producing one group named `""` with one key.
  `# CONFIG_X is not set` lines parse to the value **`"not set"`** (`:147`, `:151`). `is_static() == true`.
  **Frontend tell for that fallback:** `buildKeyValueTable`,
  `src/report_frontend/src/components/data/KeyValueTable.tsx:20` — `isDummySection` stays true when every group
  name is empty, so the `Section` column is **not rendered at all** (`:36`).
- Value legend: `data-descriptions.ts:4663` — `"y"` compiled in, `"not set"`/`"n"` not compiled in, `"m"`
  loadable module; source is `/boot/config*`.
- Metric semantics: `CONFIG_TRANSPARENT_HUGEPAGE` at `data-descriptions.ts:4666` — THP "allows the kernel to use
  huge pages and huge tlb transparently … by speeding up page faults during memory allocation, by reducing the
  number of tlb misses and by speeding up the pagetable walking", with `optimization: [TLB_MISS_OPTIMIZATION]`.
  **The only `fieldDescription` in the entire `kernel_config` block.**
- Frontend guidance: `TLB_MISS_OPTIMIZATION`,
  `src/report_frontend/src/definitions/optimization-guides.ts:58` — sysfs `enabled` modes, **folios on kernels
  ≥ 6.9** (it names 16 KiB/64 KiB/2 MiB toggles; a 6.12 host exposes **nine** sizes and pins eight of them to
  `never`), explicit reservation via `sysctl -w vm.nr_hugepages=X` or `hugepagesz=2M hugepages=512`, and the JVM
  flags `-XX:+UseTransparentHugePages` / `-XX:+UseLargePages`.
- Runtime state measured on AL2023 6.12 x86_64: `enabled` = `always [madvise] never`, `defrag` = `[madvise]`,
  `shmem_enabled` = `[never]`, `hpage_pmd_size` = `2097152`, `hugepages-2048kB` = `[inherit]`, and the other eight
  sizes = `[never]`. `CONFIG_TRANSPARENT_HUGEPAGE_MADVISE=y` correctly predicts the top-level default.
- Related playbooks: `preempt-lazy-detected.md`, `../vmstat/excessive-page-fault-rate.md`,
  `../vmstat/increased-minor-page-faults.md`, `../vmstat/major-page-faults-detected.md`,
  `../vmstat/increased-major-page-faults.md`, `../meminfo/reduced-memory-availability.md`,
  `../systeminfo/kernel-version-mismatch.md`, `../perf_stat/data-tlb-table-walks.md`.
- [Transparent Hugepage Support](https://www.kernel.org/doc/html/latest/admin-guide/mm/transhuge.html)
- [Graviton perfrunbook — optimizing for high TLB miss rates](https://aws.github.io/graviton/perfrunbook/optimization_recommendation.html#optimizing-for-high-tlb-miss-rates)
- [Folios (LWN)](https://lwn.net/Articles/937239/)
