# Generic System Performance Advisory

You are analyzing system-level performance data from an aperf recording.
The application language/runtime could not be automatically detected.

## System-Level Analysis Framework

### CPU Analysis Priority
1. **Overall utilization** — Is the system busy or idle?
2. **User vs System time** — Application work vs kernel overhead?
3. **I/O wait** — Storage-bound?
4. **IRQ/SoftIRQ** — Network or device overhead?
5. **Per-CPU distribution** — Even or imbalanced?

### PMU Analysis Priority (if available)
1. **IPC** — Overall efficiency metric
   - > 2.0: Excellent (compute-bound, well-optimized)
   - 1.0-2.0: Good
   - 0.5-1.0: Room for improvement
   - < 0.5: Severely bottlenecked
2. **Branch prediction** — Code quality indicator
3. **Cache hierarchy** — Data locality indicator
4. **TLB** — Memory mapping efficiency
5. **Frontend vs Backend stalls** — Where is the bottleneck?

### Common System-Level Issues
| aperf Metric | Issue | Resolution |
|---|---|---|
| High iowait (>10%) | Storage bottleneck | Upgrade EBS, add caching, async I/O |
| High system time (>20%) | Kernel overhead | Reduce syscalls, use io_uring |
| IPI storm (>100K/sec) | Scheduler/lock overhead | Kernel upgrade, affinity tuning |
| CPU imbalance (>30%) | Poor work distribution | Thread pinning, NUMA-aware allocation |
| Interrupt hotspot | NIC affinity | irqbalance or manual affinity |

### EC2-Specific Optimizations
- **ENA driver**: Ensure latest version for network performance
- **EBS**: Check if provisioned IOPS matches workload need
- **Placement groups**: For inter-instance communication
- **Instance store**: For temporary high-IOPS storage
- **Graviton**: often better price-performance; measure it for your workload rather than quoting a range

### Kernel Tuning — anchor before you change anything

**No aperf rule reads any sysctl value** (`src/analytics/rules/sysctl.rs` is an empty
impl). A sysctl is therefore never evidence of a problem; it is only ever a *remedy* for
something aperf measured. The blanket checklist that used to live here has been removed
because several of its values were already the kernel default (a no-op) and two
contradicted the per-language guidance in this same directory.

Sysctls with a real anchor, and the finding that gates each:

| Setting | Only when this fires | Note |
|---|---|---|
| THP `enabled=madvise` | Data/Instruction TLB Misses **in the actionable band** | `madvise` is the AL2023 default and the correct target; `always` is high-risk |
| `vm.swappiness` | Major Page Faults Detected **and `pswpin > 0`** | With `pswpin == 0` the faults are page-cache thrash and lowering swappiness makes it **worse** |
| `net.ipv4.tcp_keepalive_time` | Connection Tracking Exceeded Instance Allowance | Target **under 300s** per aperf's own guide; only affects `SO_KEEPALIVE` sockets |
| IRQ affinity / RPS / RFS | PPS Exceeded Instance Allowance | R3 risk; `irqbalance` silently reverts manual `smp_affinity` writes |
| `numactl` / cpuset pinning | Cache-miss + Backend-Dominated Stalls | Multi-node instances only |
| `ulimit -l` (memlock) | EFA Errors, for the `*_mr_err` counters only | EFA instances only |

`somaxconn`, `tcp_max_syn_backlog`, `netdev_max_backlog`, `tcp_fin_timeout`,
`vm.max_map_count`, `vm.dirty_*` and the CPU governor have **no aperf signal at all** —
treat them as hygiene to verify against your own load test, never as findings.

```bash
# Performance (unanchored — verify against your own measurements)

# Performance
# The governor is a no-op on non-metal instance types, and aperf collects no
# frequency data, so no finding can support changing it.
echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor
echo defer+madvise > /sys/kernel/mm/transparent_hugepage/defrag

# File descriptors
ulimit -n 1000000
```

## Analysis Workflow
1. Start with CPU utilization overview — is the system loaded?
2. If loaded: check PMU for efficiency bottlenecks
3. If not loaded: check iowait, network, and identify what's blocking
4. Compare against baseline or reference system
5. Focus on the highest-impact finding first
6. Iterate: fix → measure → repeat
