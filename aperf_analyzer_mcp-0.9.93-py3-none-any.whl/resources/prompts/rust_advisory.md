# Rust Performance Advisory

You are analyzing performance data from a Rust application.

## Rust Performance Model

Rust's zero-cost abstractions mean aperf data maps closely to code behavior:
- No GC pauses — steady CPU utilization expected
- No runtime overhead — PMU data directly reflects application code
- Ownership model eliminates many cache coherency issues
- But: excessive allocation (clone, Box, Vec growth) still shows up in PMU data

## Key Performance Levers

### Compilation Optimization
```toml
# Cargo.toml — release profile
[profile.release]
# opt-level = 3 and strip = true are already the release defaults (strip since Rust
# 1.77) — listing them changes nothing. Only the non-default settings are shown.
lto = "fat"           # Cross-crate LTO
codegen-units = 1     # Better optimization (slower compile)
panic = "abort"       # Smaller binary, no unwind overhead
```

```bash
# Name the deploy target explicitly. Do NOT use -C target-cpu=native on EC2: the build
# host is frequently not the deploy host, and a binary built for the wrong part dies
# with SIGILL at runtime.
RUSTFLAGS="-C target-cpu=neoverse-v2"   # Graviton4; -n1 = Graviton2, -v1 = Graviton3
```

### PGO for Rust
```bash
# Step 1: Instrumented build
RUSTFLAGS="-Cprofile-generate=/tmp/pgo-data" cargo build --release
# Step 2: Run representative workload
./target/release/app [args]
# Step 3: Merge profile data
llvm-profdata merge -o merged.profdata /tmp/pgo-data
# Step 4: Optimized build
RUSTFLAGS="-Cprofile-use=merged.profdata" cargo build --release
```

### BOLT for Rust Binaries
Works the same as C/C++ — post-link binary optimization.
Particularly effective for Rust due to monomorphization bloat.

### Common Performance Patterns
| aperf Symptom | Rust Cause | Fix |
|---|---|---|
| High branch misses | Dynamic dispatch (dyn Trait) | Monomorphize hot paths (generics) |
| High ITLB misses | Monomorphization code bloat | `#[inline(never)]` on cold paths, thin LTO |
| Backend stalls | Allocation in hot loop | Reuse buffers, use `Vec::with_capacity` |
| High L1D misses | Non-sequential access | Use `Vec` over `HashMap` for small N |
| High system time | Frequent allocation/deallocation | Arena allocators (bumpalo, typed-arena) |
| CPU not saturated | Async runtime overhead or lock contention | Profile with `tokio-console`, check `Mutex` usage |

### Allocation Optimization
- **`Vec::with_capacity(n)`** — avoid reallocations
- **`String::with_capacity(n)`** — same for strings
- **Reuse allocations** — `clear()` + reuse instead of `drop` + `new`
- **Arena allocators** — `bumpalo` for batch allocations
- **`SmallVec`** — stack-allocate small vectors
- **Avoid `.clone()` in hot paths** — use references or `Cow`

### Async Runtime (Tokio/async-std)
- **Worker threads**: Set to physical core count
- **Blocking operations**: Use `spawn_blocking` — never block the runtime
- **Task spawning**: Cheap but not free — batch small tasks
- **Monitor with `tokio-console`** for task scheduling issues

## Graviton/ARM64 Specific
- Rust toolchain has excellent aarch64 support
- Use `target-cpu=neoverse-n1` (Graviton2) or `neoverse-v1` (Graviton3)
- LSE atomics: automatically used with appropriate target CPU
- NEON auto-vectorization works well — check with `cargo asm`
- Cross-compile: `rustup target add aarch64-unknown-linux-gnu`

## Profiling Tools
1. **`perf`** — standard Linux profiler, works great with Rust
2. **`flamegraph`** crate — `cargo flamegraph` for easy flamegraphs
3. **`cargo-instruments`** (macOS) or **`samply`** — GUI profilers
4. **`dhat`** — heap allocation profiler
5. **`criterion`** — microbenchmark framework
6. **`tracing` + `tracing-flame`** — instrumented profiling

## Analysis Workflow
1. Check if IPC is reasonable (>1.0 expected for well-optimized Rust)
2. High branch misses → check for `dyn Trait` in hot paths
3. High ITLB misses → binary too large from monomorphization → consider thin LTO
4. Backend stalls → memory-bound → check allocation patterns
5. Use `perf stat` to confirm aperf findings
6. Profile with `cargo flamegraph` to identify hot functions
7. Use `cargo asm` to inspect generated assembly for hot functions
