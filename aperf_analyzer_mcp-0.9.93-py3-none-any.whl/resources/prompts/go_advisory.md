# Go Performance Advisory

You are analyzing performance data from a Go application.

## Go Performance Model

Go's runtime introduces specific patterns visible in aperf:
- **GC pauses**: Brief but frequent STW events → small CPU dips
- **Goroutine scheduling**: M:N threading → CPU should be well-utilized
- **System time**: High syscall rate from goroutine scheduling

## Key Performance Levers

### GC Tuning
| Setting | Effect | When |
|---|---|---|
| `GOGC=200` | Double heap before GC | Memory-rich, latency-sensitive |
| `GOGC=50` | Aggressive GC | Memory-constrained |
| `GOMEMLIMIT=4GiB` | Hard memory limit (Go 1.19+) | Container environments |
| `debug.SetGCPercent(-1)` | Disable GC | Short-lived processes |

### Concurrency Patterns
| aperf Symptom | Go Cause | Fix |
|---|---|---|
| Low CPU utilization | Channel blocking or mutex contention | Profile with `pprof`, reduce lock scope |
| High system time | Excessive goroutine creation | Use worker pools |
| CPU imbalance | GOMAXPROCS too low | Set to physical core count |
| High IPI | Lock contention → OS futex calls | Use `sync.RWMutex` or lock-free patterns |

### Memory & Allocation
- **`sync.Pool`** — reuse allocations for frequently created/destroyed objects
- **Pre-allocate slices**: `make([]T, 0, expectedSize)`
- **Avoid escape to heap**: Small objects on stack are free
- **String interning**: Avoid repeated string allocations
- **`bytes.Buffer` pool** — reuse for serialization

### Compiler Flags
```bash
# Build with optimizations (default, but verify)
go build -gcflags="-l=4" # More aggressive inlining
go build -ldflags="-s -w" # Strip debug info (smaller binary)

# PGO (Go 1.21+)
go test -cpuprofile=cpu.prof ./...
go build -pgo=cpu.prof  # Profile-guided optimization
```

## Graviton/ARM64 Specific
- Go has excellent ARM64 support since Go 1.16
- Cross-compile: `GOOS=linux GOARCH=arm64 go build`
- Go 1.21+ PGO works on arm64
- Verify with: `go version` should show `linux/arm64`

## Profiling
1. **`runtime/pprof`** — CPU, memory, goroutine profiles
2. **`net/http/pprof`** — HTTP endpoint for live profiling
3. **`go tool trace`** — goroutine scheduling visualization
4. **`fgprof`** — wall-clock profiler (includes off-CPU time)
