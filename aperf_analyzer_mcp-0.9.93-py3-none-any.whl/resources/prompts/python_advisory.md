# Python Performance Advisory

Use this guide when analyzing Python application performance data from aperf.

---

## Python Performance Model

Python's GIL (Global Interpreter Lock) means only one thread executes Python bytecode at a time.
On aperf data this shows as:

- CPU utilization capped at ~1 core even on a 64-core machine → GIL contention
- Multiple workers (gunicorn, uwsgi) with only 1-3 showing active CPU → connection affinity issue
- iowait near zero but high latency → threads blocked on network, not disk

---

## Key Performance Levers

### Parallelism

| Approach | When to Use | aperf Signal |
|---|---|---|
| multiprocessing | CPU-bound work | CPU balanced across workers |
| asyncio | I/O-bound, high concurrency | Low CPU, many threads idle |
| threading (gthread) | Mixed I/O-bound | CPU concentrated on few workers |
| C extensions | Tight loops, math | _PyEval low, extension high |

### Runtime Upgrades

| Version | Key Benefit | aperf Impact |
|---|---|---|
| 3.11 | Specializing adaptive interpreter, ~25% faster | Reduced `_PyEval_EvalFrameDefault` |
| 3.12 | perf trampolines for sampling profilers | Better flamegraph symbol resolution |
| 3.13 | Free-threading (no GIL) experimental | True multi-core Python |
| PyPy | JIT compilation | Drastically lower interpreter overhead |

---

## Interpreting aperf Data for Python

### GIL Diagnosis

| aperf observation | Likely cause | Fix |
|---|---|---|
| 1-2 CPUs busy on N-CPU machine | GIL contention (threads) | Switch to multiprocessing or async |
| `_PyEval_EvalFrameDefault` > 50% | CPU-bound Python code | Profile with py-spy, optimize hot path |
| iowait 0%, CPU 20-30%, high latency | Network I/O wait (not disk) | Async I/O or connection pool tuning |
| Worker A: 35% CPU, Worker B: 1% CPU | Connection affinity (LB/Envoy) | Istio DestinationRule fix (see below) |

### Common Bottlenecks (from real EKS investigations)

| aperf symptom | Python cause | Fix |
|---|---|---|
| `SSL_CTX_load_verify_locations` in flamegraph (>2%) | SSLContext rebuilt per-request | Cache `ssl.create_default_context()` at module level |
| `elasticapm capture_span` + `iter_stack_frames` (>3%) | APM stack capture on every span | `ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION=50ms` |
| `Expression.__init__` in hot path | DSL rule tree rebuilt per-request | Compile expression once, cache at construction |
| `botocore._make_api_call` in hot path (>3%) | AWS SDK called per-request | Add in-process TTL cache (60s) |
| `Document.from_mongo` + `__setattr__` (>3%) | ODM full document deserialization | Add MongoDB projection parameters |
| `pymongo._csot csot_wrapper` (1-2%) | PyMongo 4.x operation timeout overhead | Expected upgrade cost, not removable |
| Workers 1-3 at 30%+, Workers 4-7 near zero | Gunicorn + ALB/Envoy connection affinity | Istio DestinationRule (see below) |

---

## Gunicorn + Kubernetes/Istio Worker Imbalance

**Root cause:** ALB and Envoy maintain persistent keepalive connection pools to each pod.
With `gthread` workers, each connection is accepted by one worker and all requests on that
connection go to the same worker. Result: 3-4 workers carry all load, the rest are idle.

**Fix (Istio DestinationRule):**
```yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: your-app
spec:
  host: your-app
  trafficPolicy:
    connectionPool:
      http:
        maxRequestsPerConnection: 1
    loadBalancer:
      simple: LEAST_REQUEST
```

`maxRequestsPerConnection: 1` forces Envoy to open a new connection per request,
breaking the connection affinity. Combined with `LEAST_REQUEST`, work distributes evenly.

**Alternative:** Lean pod model (2 workers per pod, more replicas) reduces imbalance impact.
With 2 workers instead of 7, the worst case is one worker handles 100% of pod load
rather than one worker handling 50% of cluster load.

---

## SSLContext Rebuild Pattern

**Symptom:** `SSL_CTX_load_verify_locations` → `X509_load_cert_crl_file_ex` → `PEM_X509_INFO_read_bio_ex`
in the flamegraph at >2% CPU.

**Cause:** Application creates a new `SSLContext` (or `requests.Session`) on every outbound request.

**Fix:**
```python
# Module level — created once at import time
import ssl
import requests

_ssl_context = ssl.create_default_context()

_session = requests.Session()
_session.mount('https://', requests.adapters.HTTPAdapter(
    pool_connections=10,
    pool_maxsize=20,
))
```

For in-mesh service calls behind Istio, switch to plain HTTP — Envoy handles mTLS transparently:
```python
# Eliminates SSL overhead entirely for internal calls
response = _session.get("http://other-service/endpoint")  # http, not https
```

---

## ElasticAPM Tuning

**Symptom:** `capture_span.__enter__` + `iter_stack_frames` at >3% CPU.

**Fix (environment variables only, no code changes):**
```bash
ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION=50ms  # Skip stack for fast ops
ELASTIC_APM_TRANSACTION_SAMPLE_RATE=0.1          # 10% sampling
ELASTIC_APM_STACK_TRACE_LIMIT=50                 # Cap stack depth
```

These three settings typically recover the full instrumentation overhead.

---

## AWS SDK Caching Pattern

**Symptom:** `botocore.BaseClient._make_api_call` + `SigV4Auth.add_auth` at >3% CPU.

**Cause:** AppConfig, Secrets Manager, or SSM Parameter Store called per-request.

**Fix:**
```python
import time

_config_cache: dict = {}

def get_config() -> dict:
    now = time.time()
    if "value" not in _config_cache or now - _config_cache["ts"] > 60:
        _config_cache["value"] = boto3_client.get_secret_value(SecretId="my-secret")
        _config_cache["ts"] = now
    return _config_cache["value"]
```

For AppConfig specifically, use the `aws-appconfig-agent` sidecar which caches locally
and exposes a local HTTP endpoint.

---

## Dirty Page Writeback Bursts (Kubernetes / EKS)

**Symptom:** iowait spikes to 15-20% for 1-2 seconds periodically (every 30 seconds).
Zero disk activity between spikes. No process shows elevated kernel time during the spike.

**Hypothesis (NOT measured by aperf).** No aperf rule reads `pgpgout` or `nr_dirty` — the
four `vmstat` rules cover only `pgmajfault`, `pgminorfault` and `pgfault` — so nothing here
establishes that this workload has the problem. Confirm first: `nr_dirty` far below
`nr_dirty_background_threshold`, `pgpgout` arriving in bursts, and iowait spiking with them.

**Mechanism:** `vm.dirty_expire_centisecs=3000` (30 seconds default). The kernel
forces a flush of all dirty pages older than 30 seconds. If `dirty_background_ratio`
is too high (default 10%), the background flusher never triggers — dirty pages only
accumulate to a few hundred MB but the ratio threshold requires GB. The expiry timer
becomes the only flush mechanism and dumps everything at once.

**Common sources of dirty pages in Python EKS workloads:**
- Fluent-bit with `storage.type=filesystem` (disk buffering of log forward queue)
- Container runtime logs to `/var/log/pods/`
- Application logging via Python's `logging` module with FileHandler
- Any `open(path, 'w')` in the application writing to the pod filesystem

**Candidate fix, once the evidence above confirms it applies** (one DaemonSet, works on all
instance types including Spot/Karpenter). These trade latency for more frequent, smaller
writes and raise IOPS — do not apply them blind:
```bash
sysctl -w vm.dirty_background_ratio=1    # flush at 1% of RAM instead of the 10% default
sysctl -w vm.dirty_expire_centisecs=500   # expire pages in 5s instead of 30s
sysctl -w vm.dirty_writeback_centisecs=200 # writeback thread wakes every 2s
sysctl -w vm.dirty_ratio=10               # hard cap
```

**Effect:** 20% iowait burst → continuous 0.1-0.3% iowait. Total disk writes identical.

**Check fluent-bit:**
```bash
kubectl exec -n kube-system <fluent-bit-pod> -- grep -i storage /fluent-bit/etc/fluent-bit.conf
# If storage.type=filesystem, change to storage.type=memory
```

**Field case:** EKS Python 3.12/Gunicorn workload on storage-optimized NVMe. Fluent-bit disk buffering
generated 574MB of dirty pages continuously. 20% iowait spike lasted 1-2 seconds every
30 seconds exactly. Standard aperf missed the event by 3 minutes timing. Off-CPU run
captured it at t+30s with pgpgout=442,020/s (85x baseline).

---

## Spot Instances and Karpenter

All tuning recommendations in this guide apply identically to Spot instances managed
by Karpenter. Key points:

- **sysctl changes** apply via DaemonSet initContainer which runs on every node
  regardless of instance type, lifecycle, or procurement method
- **dirty page writeback** is a kernel behavior — instance family (storage-optimized
  i7i vs compute-optimized c7i) affects available IOPS but not the burst pattern
- **Worker imbalance** (ALB/Envoy connection affinity) is application-level and
  unchanged by instance type or Spot
- **Graviton arm64** requires verifying Python package wheels before adding Graviton
  instances to the Karpenter node pool — missing wheels cause pod startup failures

**For Graviton Spot:** Test in a separate node group with a label selector:
```yaml
nodeSelector:
  kubernetes.io/arch: arm64
```
Verify all pods start correctly before enabling Graviton in the main Spot pool.

---

## Off-CPU Profiling: When the Flamegraph Shows Nothing

Standard `aperf --profile` captures on-CPU time. If latency is high but the flamegraph
shows no obvious hotspots, the bottleneck is **off-CPU** — threads blocked waiting.

**Collect off-CPU data alongside aperf:**
```bash
# Run simultaneously with aperf record
sudo bpftrace -e '
tracepoint:sched:sched_switch { @start[args->prev_pid] = nsecs; }
tracepoint:sched:sched_switch / @start[args->next_pid] != 0 / {
  $d = (nsecs - @start[args->next_pid]) / 1000;
  if ($d > 500) { @offcpu_us[args->next_comm] += $d; }
  delete(@start[args->next_pid]);
}
interval:s:30 { print(@offcpu_us); exit(); }
' 2>/dev/null > /tmp/offcpu.txt
```

**Interpret results:** Any Python process with >50ms total blocking time during the
recording window is a caching candidate. The 100ms `update()` fix pattern shows as
`python: 100ms per request cycle` — clearly above background noise.

**What off-CPU finds that flamegraph misses:**
- Uncached DB/API calls (thread blocks on network wait)
- Lock contention (`futex_wait`, `mutex_lock`)
- Dirty page writeback (iowait spike, no process responsible)
- `update()` / `refresh()` methods without TTL caching

**What only ElasticAPM/tracing finds:**
- Per-request blocking time broken down by span
- Which specific function is blocking and for how long
- The 100ms `update()` pattern is clearest in the transaction waterfall view

---

## Graviton / ARM64 Specific Guidance

Before migrating a Python application to Graviton (c7g, m7g, r7g instance families):

1. **Python 3.11+** — ARM64 wheels are reliably published. Python 3.9 has inconsistent arm64 support.
2. **C extensions** — verify each has a `manylinux_aarch64` wheel on PyPI:
   - `ujson < 5.0` — no arm64 wheel, upgrade to 5.x or remove
   - `orjson < 3.8` — inconsistent arm64 wheel publication, upgrade to 3.10+
   - `netifaces` — abandoned, no arm64 wheel, replace with `psutil`
   - `pymongo < 4.0` — no arm64 `_cbson` wheel, upgrade required
   - `maxminddb < 2.0` — no arm64 wheel, upgrade to 2.x
3. **confluent-kafka** — arm64 wheels available in 2.x; needs `librdkafka` on host
4. **valkey-glide** — Rust extension, verify specific version has `manylinux_aarch64` wheel
5. **Test command:** `pip install --only-binary :all: -r requirements.txt` — fails fast on missing wheels

---

## Profiling Recommendations

| Tool | Use case | Command |
|---|---|---|
| `py-spy` | Live CPU profiling, zero restart | `py-spy record -o profile.svg --pid <pid>` |
| `py-spy top` | Real-time function hotspot monitor | `py-spy top --pid <pid>` |
| `scalene` | CPU + memory + GPU profiling | `scalene your_script.py` |
| `cProfile` | Deterministic profiling, startup cost | `python -m cProfile -s cumulative app.py` |
| `line_profiler` | Line-by-line timing for specific function | `@profile` decorator + `kernprof` |

For Kubernetes pods:
```bash
# py-spy on a running pod without restart
kubectl exec -it <pod> -- py-spy record -o /tmp/profile.svg --pid 1 --duration 30
kubectl cp <pod>:/tmp/profile.svg ./profile.svg
```
