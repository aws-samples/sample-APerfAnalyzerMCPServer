# Node.js Performance Advisory

You are analyzing performance data from a Node.js application.

## Node.js Performance Model

Node.js (V8 engine) is single-threaded for JS execution:
- **Event loop**: Single thread for JS — multi-core requires `cluster` or `worker_threads`
- **libuv thread pool**: Background threads for I/O (default: 4 threads)
- **V8 GC**: Generational, concurrent, but can cause pauses

## Key Performance Levers

### Concurrency
| aperf Symptom | Node.js Cause | Fix |
|---|---|---|
| Single core at 100%, others idle | Single-threaded nature | `cluster` module or `worker_threads` |
| Low CPU overall | I/O-bound (good) or event loop blocked (bad) | Profile event loop lag |
| High system time | Excessive I/O or child processes | Batch I/O, use streams |
| CPU spikes | V8 JIT compilation or GC | Warm up before load, tune GC |

### V8 Tuning
```bash
# Heap ceiling. NOT an unconditional recommendation: raising it on a container whose
# cgroup limit is lower converts graceful V8 GC pressure into an OOM kill. Set it only
# against a measured heap requirement, and keep it under the container limit.
node --max-old-space-size=<under-the-cgroup-limit> app.js

# Expose GC for monitoring
node --expose-gc app.js

# Optimize for throughput
node --max-semi-space-size=128 app.js  # Larger young gen

# UV thread pool (for I/O-heavy apps)
UV_THREADPOOL_SIZE=64 node app.js
```

### Memory Optimization
- **Streams** — avoid buffering large payloads in memory
- **Object pooling** — reuse objects in hot paths
- **Buffer.allocUnsafe()** — skip zero-fill for temporary buffers
- **WeakRef/FinalizationRegistry** — for caches that shouldn't prevent GC

### Clustering
```javascript
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;

if (cluster.isPrimary) {
    for (let i = 0; i < numCPUs; i++) cluster.fork();
} else {
    // Worker process
    startServer();
}
```

## Graviton/ARM64 Specific
- Node.js 16+ has full ARM64 support
- V8 JIT produces good ARM64 code
- Native addons may need recompilation: `npm rebuild`
- Use Node.js 18+ LTS for best ARM64 performance

## Profiling
1. **`clinic.js`** — Doctor, Flame, Bubbleprof
2. **`0x`** — flamegraph generation
3. **`node --prof`** — V8 CPU profiler
4. **`node --inspect`** — Chrome DevTools profiling
5. **`autocannon`** — HTTP benchmarking
