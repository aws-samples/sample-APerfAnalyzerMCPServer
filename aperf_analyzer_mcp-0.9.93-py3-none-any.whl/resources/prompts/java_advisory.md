# Java/JVM Performance Advisory

You are analyzing performance data from an application running on the JVM (Java, Scala, Kotlin, Clojure).

## Key JVM Performance Levers

### Garbage Collection

**aperf has no GC signal.** `java_profile` carries exactly three rules — Excessive
Exceptions, Tiered Compilation Check, JVM Version Comparison — and none observes collector
behaviour, pause times or heap sizing. Do not recommend a collector change from aperf data;
nothing here can tell you a collector is the problem.

To investigate GC at all you need a different source: `-Xlog:gc*` output, or
`jstat -gcutil`, correlated against your own latency measurements.

**What CPU dips do and do not tell you:** periodic dips are *consistent with* stop-the-world
pauses, but an I/O block, a throttled container and a bursty workload produce the same
shape. Confirm with GC logs before attributing them.

### JIT Compilation & Code Quality
| Symptom (from PMU) | Likely Cause | Fix |
|---|---|---|
| High branch misses (aperf fires at branch-mpki ≥ 10) | Predictor retrained by recompilation churn | `-XX:ReservedCodeCacheSize=64M -XX:InitialCodeCacheSize=64M`; eliminate exception-based control flow |
| High ITLB misses | JIT code footprint too large | `-XX:+UseTransparentHugePages` (**Linux only** — a non-Linux JVM refuses to start with this flag) |
| High code sparsity | Methods scattered in memory | `-XX:ReservedCodeCacheSize=512m` + BOLT post-processing |
| Frontend stalls dominant | I-cache misses from code size | Reduce method count, avoid deep inlining |

**Do not recommend `-XX:-TieredCompilation`.** aperf's own rule message says to *try setting*
the flag, and `+TieredCompilation` has been the default since JDK 8 — so the finding means
"nobody has tuned JIT compilation here", not "it is misconfigured". The rule's regex matches
both signs, so a JVM that already disabled tiering produces no finding at all — meaning the
rule cannot even detect the state this advice would create.

### Memory & TLB
- `-XX:+UseTransparentHugePages` when measured TLB pressure justifies it — **Linux only**,
  and gate it on the aperf TLB findings rather than applying it unconditionally
- `-XX:+AlwaysPreTouch` to pay first-touch cost at startup instead of under load
- `-XX:+UseLargePages` is a *different* mechanism: the explicit hugetlb pool, requiring
  `vm.nr_hugepages` reserved in advance. Prefer THP unless you can reserve pages.
- `-XX:+UseNUMA` is not recommended here: `numastat` carries no aperf rules, and EC2
  instances below the metal tier are effectively single-socket.

### Thread Configuration
- **ForkJoinPool**: Set parallelism to physical core count (not vCPU)
- **GC threads**: `-XX:ParallelGCThreads=N` (default = CPU count, may be too high)
- **Compiler threads**: `-XX:CICompilerCount=N` (reduce for small instances)

### Graviton/ARM64 Specific
- Use Corretto (Amazon's JDK) — optimized for Graviton
- Async-profiler works well on aarch64 for detailed JVM profiling
- LSE atomics: JDK 17+ (or Corretto 11+) emits them. If aperf's Old-Style Atomic
  Instructions finding fires, the exclusives usually belong to the JVM's own compiled
  code, not your bytecode — a runtime upgrade is the fix, not an application change.
- Compressed OOPs are already the default for heaps under the compressed-oop limit;
  setting `-XX:+UseCompressedOops` explicitly changes nothing.

## Analysis Workflow
1. Start from the findings aperf emitted — every recommendation must trace to one
2. Check CPU dips, but confirm with GC logs before calling them GC (see above)
3. Check PMU branch misses → size the code cache; do NOT disable tiered compilation
4. Check ITLB/DTLB misses → enable THP if the rate is in the actionable band, not merely nonzero
5. Check IPC → if low after the above, profile hot methods
6. Use async-profiler flamegraph to find allocation-heavy methods
7. Check thread distribution across CPUs for affinity issues

## Common Anti-Patterns
- Running with default JVM flags in production
- Heap size too small (causes excessive GC) or too large (causes long pauses)
- Using `-XX:+PrintCompilation` in production (overhead)
- Not pinning GC threads away from application threads on large instances
- Using -Xms != -Xmx (causes GC to resize heap repeatedly)
