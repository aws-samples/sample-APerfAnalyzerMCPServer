# C/C++ Performance Advisory

You are analyzing performance data from a native C/C++ application.

## C/C++ Performance Model

Native code gives direct access to hardware — aperf PMU data is directly actionable:
- **IPC** reflects true efficiency of compiled code
- **Branch prediction** reveals code layout quality
- **Cache misses** directly show data structure issues
- No runtime/GC overhead to confuse the picture

## Key Performance Levers

### Compiler Optimization
| Flag | Effect | When to Use |
|---|---|---|
| `-O3` | Aggressive optimization | Always for production |
| `-mcpu=<deploy-target>` | Target the DEPLOY CPU explicitly | Always. `-march=native` targets the BUILD host — on EC2 that is frequently a different part, and the binary dies with SIGILL |
| `-flto` | Link-Time Optimization | Always — enables cross-TU inlining |
| `-fprofile-generate`/`-fprofile-use` | PGO | Best single optimization technique |
| `-fomit-frame-pointer` | Free register on x86 | Unless you need stack traces |
| `-funroll-loops` | Loop unrolling | If backend-stall-bound |

### Profile-Guided Optimization (PGO)
PGO is the #1 optimization for reducing branch mispredictions:
```bash
# Step 1: Instrument
g++ -O3 -fprofile-generate -o app_instrumented app.cpp
# Step 2: Run representative workload
./app_instrumented [representative_args]
# Step 3: Rebuild with profile data
g++ -O3 -fprofile-use -o app_optimized app.cpp
```
Expected improvements: 10-30% throughput, 2-5x reduction in branch misses.

### BOLT (Binary Optimization and Layout Tool)
Post-link optimizer that reorders functions and basic blocks:
```bash
perf record -e cycles:u -j any,u -- ./app
perf2bolt -p perf.data -o perf.fdata ./app
llvm-bolt ./app -o ./app.bolt -data=perf.fdata -reorder-blocks=ext-tsp -reorder-functions=hfsort
```
Reduces frontend stalls and ITLB misses by 10-20%.

### Memory Access Patterns
| aperf Symptom | Cause | Fix |
|---|---|---|
| High L1D misses | Poor data locality | AoS → SoA, cache-line padding |
| High L3 misses | Working set > L3 | Prefetching, data compression |
| High DTLB misses | Scattered allocations | Huge pages, arena allocators |
| High ITLB misses | Large code footprint | LTO + BOLT, reduce template instantiation |
| Backend stalls >40% | Memory-bound | Prefetch, restructure access patterns |

### Data Structure Optimization
- **Hot/cold splitting**: Separate frequently-accessed fields from rare ones
- **Cache-line alignment**: `alignas(64)` for shared data
- **False sharing**: Pad shared-but-independent data to cache line boundaries
- **Arena allocation**: Reduce `malloc` pressure and improve locality
- **SoA layout**: For traversal-heavy workloads (better vectorization + prefetch)

### Threading & Synchronization
- **High IPI count in aperf** → excessive lock contention or atomic operations
- **CPU imbalance** → work distribution issue
- Use `taskset` / `numactl` for NUMA-aware placement
- Consider lock-free data structures for high-contention paths
- `perf c2c` can identify false sharing

## Graviton/ARM64 Specific
- **LSE atomics**: Use `-march=armv8.1-a` or higher (or `-moutline-atomics` for compatibility)
- **SVE/SVE2**: Available on Graviton3+ — auto-vectorization with `-march=armv8.4-a+sve2`
- **Memory model**: ARM has weaker memory ordering — `std::atomic` is correct but fences are more expensive
- **Branch prediction**: Graviton3 has excellent branch predictor — PGO still helps for indirect calls
- **NEON SIMD**: 128-bit — use intrinsics or auto-vectorization
- **Large System Extensions**: Critical for lock-heavy workloads on many cores

## Analysis Workflow
1. Check IPC — if <1.0, identify if frontend-bound or backend-bound
2. Frontend-bound: ITLB + I-cache misses → PGO + BOLT + LTO
3. Backend-bound: D-cache + DTLB misses → data layout + prefetch + huge pages
4. High branch misses: PGO + devirtualization + branchless algorithms
5. Profile with `perf record` to identify hot functions
6. Use `perf annotate` for instruction-level analysis
