# .NET Performance Advisory

You are analyzing performance data from a .NET application (C#, F#, VB.NET).

## .NET Performance Model

.NET CLR has JIT compilation and GC similar to JVM, but with distinct characteristics:
- **Tiered compilation**: Methods start interpreted, then JIT'd at higher tiers
- **GC generations**: Gen0 (fast), Gen1, Gen2 (full GC — expensive)
- **ReadyToRun (R2R)**: Pre-compiled code for startup performance

## Key Performance Levers

### GC Configuration
| Mode | Best For | Config |
|---|---|---|
| Workstation GC | Interactive/low-latency | Default for desktop apps |
| Server GC | Throughput on multi-core | `<GCServer>true</GCServer>` |
| Background GC | Reduce pause times | `<GCConcurrent>true</GCConcurrent>` |

### JIT & Compilation
| aperf Symptom | .NET Cause | Fix |
|---|---|---|
| High branch misses | Tiered compilation (Tier0 code) | Wait for Tier1 JIT, or use R2R |
| Cold start overhead | JIT compilation | NativeAOT or ReadyToRun |
| High ITLB misses | Large IL assemblies | NativeAOT + trimming |
| Frontend stalls | Generic instantiation bloat | Reduce generic type variance |

### NativeAOT (for ahead-of-time compilation)
```xml
<PropertyGroup>
    <PublishAot>true</PublishAot>
</PropertyGroup>
```
- Eliminates JIT overhead
- Smaller binary → better I-cache behavior
- Better branch prediction (no dynamic code generation)
- Trade-off: no dynamic loading, some reflection limitations

### Memory Patterns
- **`Span<T>` and `Memory<T>`** — avoid heap allocation for buffer slicing
- **`ArrayPool<T>.Shared`** — rent/return arrays instead of allocating
- **`stackalloc`** — stack allocation for small temporary buffers
- **Object pooling** — `ObjectPool<T>` for expensive-to-create objects
- **Struct vs Class** — value types on stack avoid GC pressure

## Graviton/ARM64 Specific
- .NET 6+ has full ARM64 support
- Ensure using `linux-arm64` runtime identifier
- NativeAOT produces optimized ARM64 code
- Check: `dotnet --info` should show ARM64 architecture

## Profiling Tools
1. **`dotnet-trace`** — cross-platform tracing
2. **`dotnet-counters`** — real-time metrics
3. **`dotnet-dump`** — memory analysis
4. **PerfView** — detailed ETW analysis (Windows)
5. **`BenchmarkDotNet`** — microbenchmarks
