# PHP Performance Advisory

You are analyzing performance data from a PHP application.

## PHP Performance Model

PHP has multiple execution models that produce very different aperf signatures:
- **PHP-FPM**: Process-per-request (fork model) — each worker is a separate OS process
- **Swoole/OpenSwoole**: Event-driven, coroutine-based — single process, high concurrency
- **RoadRunner**: Go-based app server with PHP workers — persistent processes
- **FrankenPHP**: Embedded in Caddy — modern worker mode

### Critical: Worker Pool Diagnosis from aperf

In PHP-FPM, the number of **worker processes** directly maps to what aperf sees:
- `pm.max_children` = max OS processes visible in aperf process list
- Each worker handles ONE request at a time (blocking model)
- If workers < concurrent requests → queuing → latency spikes

| aperf Symptom | PHP Cause | Fix |
|---|---|---|
| Few processes using CPU, many idle cores | FPM workers < CPU count | Increase `pm.max_children` |
| All workers at 100% but low total throughput | Workers blocked on I/O | Add more workers, or switch to async |
| Periodic CPU spikes then idle | `pm = ondemand` spawning overhead | Use `pm = static` for steady load |
| High system time | Process forking (dynamic PM) | `pm = static` + `pm.max_children = CPU * 2` |
| Memory growing over time | Worker memory leaks | Set `pm.max_requests = 500` to recycle |
| CPU imbalance (some workers starved) | Connection routing issue | Check load balancer, IPv4/IPv6 session affinity |

### ⚠️ Common Misconfig: Worker Starvation from Session Affinity

**Real-world case**: Customer had 7 PHP-FPM workers but only 3 received moderate workload.

**Root cause**: Load balancer using IPv4 source-based session persistence (sticky sessions). 
Clients behind NAT/proxy all share the same source IP → all requests route to same subset of workers.

**Diagnosis in aperf**:
- `processes` data shows 7 PHP-FPM workers
- Only 3 workers show consistent CPU utilization
- 4 workers remain near-idle
- Overall CPU utilization is low despite load

**Fix**:
1. Switch session persistence from `source_ip` to `cookie-based` or `header-based`
2. Or disable session affinity entirely if stateless
3. If sessions required: use shared session backend (Redis/Memcached) + round-robin
4. Check: `upstream` block in nginx, or ALB sticky session config

## Key Performance Levers

### OPcache (Critical)
```ini
; php.ini — MUST be enabled in production
opcache.enable=1
opcache.memory_consumption=256
opcache.max_accelerated_files=20000
opcache.validate_timestamps=0          ; Disable in prod (restart to pick up changes)
opcache.jit=1255                       ; PHP 8.0+ JIT compilation
opcache.jit_buffer_size=128M
```

Without OPcache: PHP re-parses/compiles every file on every request → massive overhead.
With JIT (PHP 8.0+): Near-native performance for compute-heavy paths.

### JIT Impact on aperf Metrics
| OPcache Mode | Branch Misses | IPC | Frontend Stalls |
|---|---|---|---|
| Disabled | Very high | Very low | Very high |
| OPcache (no JIT) | High | Low-medium | High |
| OPcache + JIT (tracing) | Medium | Medium-high | Low |

### PHP-FPM Configuration
```ini
; Static pool for predictable performance
pm = static
pm.max_children = <CPU_cores * 2>     ; Adjust based on memory/workload
pm.max_requests = 1000                 ; Prevent memory leaks

; For memory-constrained environments
pm = dynamic
pm.max_children = 50
pm.start_servers = 10
pm.min_spare_servers = 5
pm.max_spare_servers = 20
```

### Database Connection Patterns
| Pattern | Impact | Fix |
|---|---|---|
| New connection per request | High system time, TCP overhead | Use persistent connections or connection pool |
| No prepared statements | High CPU in MySQL/PG | Use PDO prepared statements |
| N+1 queries | Many small I/O waits | Eager loading, batch queries |
| Large result sets in memory | Memory pressure | Use cursors/generators |

### Composer & Autoloading
```bash
# Production: generate optimized classmap
composer dump-autoload --optimize --classmap-authoritative
```
Without this: PSR-4 autoloading does filesystem lookups → high syscall overhead visible as system time in aperf.

## Version-Specific Behavior

| PHP Version | aperf Process Visibility | Notes |
|---|---|---|
| < 7.4 | Basic process listing | No JIT, higher overhead |
| 7.4 | Process listing + FFI | Preloading available |
| 8.0+ | Full process detail + JIT | OPcache JIT changes PMU profile significantly |
| 8.1+ | Fibers (cooperative multitasking) | May show different scheduling patterns |
| 8.3+ | Better process info | Improved readonly properties |

## Graviton/ARM64 Specific
- PHP 8.0+ has full ARM64 JIT support
- Ensure native compilation (not qemu emulation)
- Extensions may need recompilation: `pecl install <ext>`
- Use `php -i | grep Architecture` to verify

## Profiling Tools
1. **Xdebug** — Full profiler (heavy overhead, dev only)
2. **Blackfire.io** — Production profiling
3. **Tideways** — Low-overhead production profiler
4. **SPX** — Simple profiling extension
5. **Xhprof** — Hierarchical profiler (Facebook)
6. **php-fpm status page** — Real-time worker stats (`pm.status_path`)
