# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Application context loader for the report handler.

When the user runs `generate_html_report` they may pass an `app_context` dict
explicitly, or rely on the auto-loader to compute the run's fingerprint and
look up the persisted context at ~/.aperf-contexts/<hash>.json.

This module provides:
- compute_fingerprint(run_path): same algorithm as hooks/aperf_context_hook.py
- load_context_for_run(run_path): returns the persisted context dict + hash, or None
- merge_context(explicit, loaded): explicit args take precedence over loaded values
- bump_runs_analyzed(fp_hash): increment counter and persist (called after a
  successful report generation)

The hook handles first-time-run questionnaires. The report handler only needs
to read what's already there and increment the counter when a report runs.
"""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

CONTEXT_STORE = Path.home() / ".aperf-contexts"
_HOOK_PATH = Path(__file__).parent.parent / "hooks" / "aperf_context_hook.py"


def _load_hook_module():
    """
    Import the hook module by file path. The hooks/ directory isn't a Python
    package; this is the cleanest way to share the fingerprint algorithm
    without copy-pasting it.
    """
    if "_aperf_hook" in sys.modules:
        return sys.modules["_aperf_hook"]
    if not _HOOK_PATH.exists():
        return None
    try:
        spec = importlib.util.spec_from_file_location("_aperf_hook", _HOOK_PATH)
        if not spec or not spec.loader:
            return None
        mod = importlib.util.module_from_spec(spec)
        sys.modules["_aperf_hook"] = mod
        spec.loader.exec_module(mod)
        return mod
    except Exception:
        return None


def compute_fingerprint(run_path: Path) -> tuple[dict | None, str | None]:
    """
    Compute (fingerprint_dict, fingerprint_hash) for an aperf run.
    Returns (None, None) if the hook module can't be loaded or the run is unparseable.
    """
    hook = _load_hook_module()
    if hook is None:
        return (None, None)
    try:
        fp = hook.extract_fingerprint(run_path)
        # primary_process / memory_tier may need to be set by the hook's helpers
        if hasattr(hook, "memory_tier") and fp.get("memory_total_kb"):
            fp["memory_tier"] = hook.memory_tier(fp["memory_total_kb"])
        fp_hash = hook.fingerprint_hash(fp)
        return (fp, fp_hash)
    except Exception:
        return (None, None)


def load_context_for_run(run_path: Path) -> tuple[dict | None, str | None]:
    """
    Auto-load any persisted application context for this run's fingerprint.
    Returns (context_dict, fingerprint_hash), or (None, None) if not found.
    """
    _fp, fp_hash = compute_fingerprint(run_path)
    if not fp_hash:
        return (None, None)
    ctx_path = CONTEXT_STORE / f"{fp_hash}.json"
    if not ctx_path.exists():
        return (None, fp_hash)
    try:
        return (json.loads(ctx_path.read_text()), fp_hash)
    except Exception:
        return (None, fp_hash)


def merge_context(explicit: dict, loaded: dict | None) -> dict:
    """
    Merge an explicitly-passed app_context with what was loaded from disk.

    Explicit values take precedence. This lets the agent override or augment
    the persisted context for one-off runs (e.g. testing a different priority
    or providing a dep_file path that wasn't there before).
    """
    if not loaded:
        return dict(explicit)
    out = dict(loaded)
    for k, v in (explicit or {}).items():
        # Don't let an empty explicit value clobber a real loaded value
        if v is None or v == "" or v == {} or v == []:
            continue
        out[k] = v
    return out


def bump_runs_analyzed(fp_hash: str) -> int:
    """
    Increment runs_analyzed for the persisted context. Returns the new count.
    No-op when the context file doesn't exist yet (the hook seeds it on
    first run; this only updates an already-seeded context).
    """
    if not fp_hash:
        return 0
    ctx_path = CONTEXT_STORE / f"{fp_hash}.json"
    if not ctx_path.exists():
        return 0
    try:
        data = json.loads(ctx_path.read_text())
        data["runs_analyzed"] = int(data.get("runs_analyzed", 0)) + 1
        ctx_path.write_text(json.dumps(data, indent=2))
        return data["runs_analyzed"]
    except Exception:
        return 0
