# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Diagnostic Playbook Engine

Deterministic, symptom-gated rule evaluator. Loads rules from
resources/anchored_playbooks.json and evaluates them against a flat
context dict built from live run data.

No I/O at evaluation time — JSON is loaded once at import.
No LLM calls — all logic is explicit comparators and boolean trees.

Anchoring
---------
Every rule declares `anchor.aperf_rules`: the names of findings aperf itself emitted.
A rule can only fire if one of them is present in the run, which is what stops the
engine inventing advice for a symptom nothing measured.

Anchors are matched on the exact `rule_name` string aperf writes into
`data/js/<data_type>_findings`, read via parsers.findings_parser. They are NOT
matched against values this module re-derives from raw collected data, and they are
NOT matched against context fields no parser populates — both were defects in the
schema 1.0 rule set. `system.transparent_hugepages` in particular has readers but no
writer, so it always read "unknown"; the THP rule's trigger therefore always passed
and its non-JVM twin never did. See `dead_context_fields` in the JSON.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Rule DB loading
# ---------------------------------------------------------------------------

_DB_PATH = Path(__file__).parent.parent / "resources" / "anchored_playbooks.json"


def _load_db() -> dict:
    if not _DB_PATH.exists():
        return {"rules": []}
    try:
        return json.loads(_DB_PATH.read_text())
    except Exception:
        return {"rules": []}


_DB = _load_db()

_SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2}
_KILL_SWITCH_ENV = "PLAYBOOK_DISABLE"  # comma-separated rule IDs to suppress

#: Reserved context key holding the set of aperf `rule_name`s that fired. Not a dotted
#: path because rule names contain spaces and are matched verbatim.
_ANCHOR_KEY = "__aperf_fired__"


def _normalize_findings(aperf_findings: Any) -> frozenset[str]:
    """Reduce any accepted findings input to the set of aperf rule names that fired."""
    if aperf_findings is None:
        return frozenset()
    # A FindingsReport carries `.findings`; an iterable may hold Finding or plain strings.
    items = getattr(aperf_findings, "findings", aperf_findings)
    names = set()
    for item in items:
        name = getattr(item, "rule_name", item)
        if isinstance(name, str) and name:
            names.add(name)
    return frozenset(names)


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class MatchedRule:
    id: str
    severity: str
    confidence: str
    category: str
    title: str  # with {{}} substituted
    why: str
    core: list[str]
    extensions: dict  # keyed by language
    target: str | None = None
    current: str | None = None  # resolved from current_field
    verify: str | None = None
    provenance: dict = field(default_factory=dict)
    #: Which aperf findings gated this rule, and how much of the gate is aperf's own.
    anchor: dict[str, Any] = field(default_factory=dict)
    #: The subset of `anchor.aperf_rules` actually present in this run.
    anchored_by: list[str] = field(default_factory=list)
    priority_default: str = ""
    #: Read-only diagnostics — what to collect next. Never recommendations.
    next_steps: list[str] = field(default_factory=list)
    #: OS/sysctl-level fix. A sysctl can never gate a rule (no aperf rule reads sysctl
    #: values) but is a legitimate remediation for a symptom aperf measured.
    os_remediation: dict[str, Any] = field(default_factory=dict)
    caveats: list[str] = field(default_factory=list)

    def advice_for(self, language: str) -> dict[str, Any] | None:
        """
        Per-language block, or None when the rule is suppressed for that runtime.

        Suppression is stronger than "no knob": it means the rule's own threshold is
        invalid for that runtime, so reporting it at all would be noise. Excessive
        Exceptions on CPython is the case — exceptions are idiomatic there, so >5% of
        samples in exception machinery is normal rather than pathological.
        """
        ext = self.extensions.get(language)
        if ext is None or ext.get("suppress_rule_for_language"):
            return None
        return ext


# ---------------------------------------------------------------------------
# Context builder
# ---------------------------------------------------------------------------


def build_context(
    meta=None,
    cpu_summary=None,
    pmu_summary=None,
    mem_summary=None,
    sys_health: dict | None = None,
    app_context: dict | None = None,
    recommendations=None,
    aperf_findings=None,
) -> dict:
    """
    Flatten all run summaries into the dotted-namespace context dict that
    the rule trigger evaluator expects.

    Namespaces:
        system.*    — OS, kernel, sysctl values
        cpu.*       — utilization
        pmu.*       — IPC, stall %, TLB misses
        memory.*    — usage pct, signals (flat_line, over_provisioned, ...)
        runtime.*   — detected language, runtime version
        migration.* — target arch, target gen, whether Graviton is recommended
        aperf.*     — which findings aperf itself emitted; the anchor source

    `aperf_findings` accepts a FindingsReport, an iterable of Finding, or an iterable of
    plain rule-name strings. Without it no rule can fire, because every rule is anchored.
    """
    ctx: dict[str, Any] = {}

    # --- aperf findings (anchor source) ---
    # Stored under a reserved key rather than one entry per finding: rule names contain
    # spaces and are matched exactly, so they are not usable as dotted context paths.
    ctx[_ANCHOR_KEY] = _normalize_findings(aperf_findings)

    # --- system ---
    if meta:
        kver = getattr(meta, "kernel_version", None) or ""
        ctx["system.kernel_version"] = kver
        ctx["system.kernel_major"] = _parse_kernel_major(kver)
        ctx["system.architecture"] = getattr(meta, "architecture", "unknown")
        ctx["system.os_release"] = getattr(meta, "os_release", "unknown")
        ctx["system.instance_type"] = getattr(meta, "instance_type", "unknown")

    if sys_health:
        sysinfo = sys_health.get("system_info", {})
        # THP
        thp = sysinfo.get("transparent_hugepages", "unknown")
        ctx["system.transparent_hugepages"] = thp
        # sysctl — aperf captures some in system_info
        vm_max = sysinfo.get("vm_max_map_count") or sysinfo.get("vm.max_map_count")
        if vm_max is not None:
            try:
                ctx["system.vm_max_map_count"] = int(vm_max)
            except (ValueError, TypeError):
                pass
        swappiness = sysinfo.get("vm_swappiness") or sysinfo.get("vm.swappiness")
        if swappiness is not None:
            try:
                ctx["system.vm_swappiness"] = int(swappiness)
            except (ValueError, TypeError):
                pass
        numa = sysinfo.get("numa_balancing")
        if numa is not None:
            ctx["system.numa_balancing"] = numa

    # --- cpu ---
    if cpu_summary:
        ctx["cpu.avg_total_utilization_pct"] = getattr(
            cpu_summary, "avg_total_utilization_pct", 0.0
        )
        ctx["cpu.avg_idle_pct"] = 100.0 - ctx["cpu.avg_total_utilization_pct"]

    # --- pmu ---
    if pmu_summary:
        ctx["pmu.ipc"] = getattr(pmu_summary, "ipc", 0.0)
        ctx["pmu.backend_stall_pct"] = getattr(pmu_summary, "backend_stall_pct", 0.0)
        ctx["pmu.frontend_stall_pct"] = getattr(pmu_summary, "frontend_stall_pct", 0.0)
        ctx["pmu.dtlb_misses_per_1k_instructions"] = getattr(
            pmu_summary, "dtlb_misses_per_1k_instructions", 0.0
        )
        ctx["pmu.itlb_misses_per_1k_instructions"] = getattr(
            pmu_summary, "itlb_misses_per_1k_instructions", 0.0
        )
        ctx["pmu.branch_misses_per_1k_instructions"] = getattr(
            pmu_summary, "branch_misses_per_1k_instructions", 0.0
        )

    # --- memory ---
    if mem_summary:
        ctx["memory.avg_used_pct"] = getattr(mem_summary, "avg_used_pct", 0.0)
        ctx["memory.peak_used_pct"] = getattr(mem_summary, "peak_used_pct", 0.0)
        ctx["memory.total_mb"] = getattr(mem_summary, "total_mb", 0.0)
        ctx["memory.committed_unused_mb"] = getattr(mem_summary, "committed_unused_mb", 0.0)
        ctx["memory.committed_unused_pct"] = getattr(mem_summary, "committed_unused_pct", 0.0)
        ctx["memory.is_flat_line"] = getattr(mem_summary, "is_flat_line", False)
        ctx["memory.over_provisioned"] = getattr(mem_summary, "over_provisioned", False)
        ctx["memory.used_pct_variance"] = getattr(mem_summary, "used_pct_variance", 0.0)
        ctx["memory.used_pct_range"] = getattr(mem_summary, "used_pct_range", 0.0)
        ctx["memory.swap_used_mb"] = getattr(mem_summary, "swap_used_mb", 0.0)

    # --- runtime (from app_context) ---
    if app_context:
        lang = _detect_language(app_context)
        ctx["runtime.language"] = lang
        ctx["runtime.framework"] = app_context.get("framework", "")
        ctx["runtime.jvm_version"] = app_context.get("jvm_version", "")
        # Pass through useful sub-fields so rules can match on them
        rv = (app_context.get("runtime_version") or "").strip()
        if rv:
            ctx["runtime.runtime_version"] = rv
        rf = (app_context.get("runtime_flags") or "").strip()
        if rf:
            ctx["runtime.runtime_flags"] = rf

    # --- migration ---
    if recommendations:
        ctx["migration.graviton_recommended"] = getattr(
            recommendations, "graviton_recommended", False
        )
        ctx["migration.workload_class"] = getattr(recommendations, "workload_class", "balanced")
        # Derive target arch / gen from the instance options
        for opt in getattr(recommendations, "instance_options", []):
            itype = getattr(opt, "instance_type", "")
            arch = getattr(opt, "architecture", "")
            if arch == "aarch64":
                ctx["migration.target_arch"] = "aarch64"
                ctx["migration.target_gen"] = _parse_graviton_gen(itype)
                break

    return ctx


# ---------------------------------------------------------------------------
# Trigger evaluator
# ---------------------------------------------------------------------------


def _get(ctx: dict, field_path: str) -> Any:
    """Retrieve a value from the flat dotted context. Returns _MISSING sentinel if absent."""
    return ctx.get(field_path, _MISSING)


_MISSING = object()


def _eval_condition(cond: dict, ctx: dict) -> bool:
    """Evaluate a single leaf condition {field, op, value}."""
    # 'aperf_fired' operator: true when the named aperf finding is in this run's fired
    # set, independent of any measured magnitude. Exists for triggers that need to test
    # for a SPECIFIC finding among several anchors — the ordinary anchor gate only tests
    # "at least one of the rule's anchors fired," which cannot distinguish which one.
    if "aperf_fired" in cond:
        fired = ctx.get(_ANCHOR_KEY, frozenset())
        return cond["aperf_fired"] in fired

    field_path = cond.get("field", "")
    value = _get(ctx, field_path)

    # 'missing' operator: true when field not in context
    if "missing" in cond:
        return (value is _MISSING) == bool(cond["missing"])

    # 'present' operator
    if "present" in cond:
        return (value is not _MISSING) == bool(cond["present"])

    # All other operators require the field to be present
    if value is _MISSING:
        return False

    if "eq" in cond:
        return value == cond["eq"]
    if "ne" in cond:
        return value != cond["ne"]
    if "lt" in cond:
        try:
            return float(value) < float(cond["lt"])
        except (TypeError, ValueError):
            return False
    if "lte" in cond:
        try:
            return float(value) <= float(cond["lte"])
        except (TypeError, ValueError):
            return False
    if "gt" in cond:
        try:
            return float(value) > float(cond["gt"])
        except (TypeError, ValueError):
            return False
    if "gte" in cond:
        try:
            return float(value) >= float(cond["gte"])
        except (TypeError, ValueError):
            return False
    if "in" in cond:
        return value in cond["in"]
    if "not_in" in cond:
        return value not in cond["not_in"]
    if "contains" in cond:
        return str(cond["contains"]) in str(value)

    return False


def _eval_node(node: dict, ctx: dict) -> bool:
    """Recursively evaluate a trigger node (all/any/not or leaf condition)."""
    if "all" in node:
        return all(_eval_node(c, ctx) for c in node["all"])
    if "any" in node:
        return any(_eval_node(c, ctx) for c in node["any"])
    if "not" in node:
        return not _eval_node(node["not"], ctx)
    # Leaf condition
    return _eval_condition(node, ctx)


# ---------------------------------------------------------------------------
# Template substitution
# ---------------------------------------------------------------------------

_TMPL_RE = re.compile(r"\{\{([^}]+)\}\}")


def _substitute(template: str, ctx: dict) -> str:
    """Replace {{field.path}} and {{field.path_or_unknown}} in a template string."""

    def replacer(m: re.Match) -> str:
        key = m.group(1)
        if key.endswith("_or_unknown"):
            real_key = key[: -len("_or_unknown")]
            val = ctx.get(real_key, _MISSING)
            return str(val) if val is not _MISSING else "unknown"
        val = ctx.get(key, _MISSING)
        if val is _MISSING:
            return f"<{key}>"
        # Format floats sensibly
        if isinstance(val, float):
            return f"{val:.1f}"
        return str(val)

    return _TMPL_RE.sub(replacer, template)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def evaluate(ctx: dict, language_hint: str | None = None) -> list[MatchedRule]:
    """
    Evaluate all rules against the given context dict.

    Returns a list of MatchedRule sorted by severity (high first) then confidence.
    Rules in the PLAYBOOK_DISABLE env var are suppressed.
    """
    disabled_ids = {r.strip() for r in os.environ.get(_KILL_SWITCH_ENV, "").split(",") if r.strip()}

    # NOTE: `language_hint` is not consulted below. Rules select on language through
    # `ctx["runtime.language"]` inside their own triggers, so a hint that disagrees with the
    # context has no effect. `evaluate_for_report` passes the context's own value, so the two
    # always agree today; a caller that expected the hint to override would be surprised.
    results: list[MatchedRule] = []

    fired = ctx.get(_ANCHOR_KEY, frozenset())

    for rule in _DB.get("rules", []):
        rule_id = rule.get("id", "")
        if rule_id in disabled_ids:
            continue

        # Anchor gate. A rule with no aperf finding behind it cannot fire, which is the
        # whole point: it makes "we measured this" a precondition for giving advice
        # rather than a claim in a comment.
        anchor = rule.get("anchor", {})
        anchored_by = [name for name in anchor.get("aperf_rules", []) if name in fired]
        if not anchored_by:
            continue

        # Refinement gate. aperf's four TLB rules fire at `> 0.0`, i.e. on any nonzero
        # sample, so the finding alone does not mean the value is worth acting on. Rules
        # marked `refined` carry a `trigger` supplying the magnitude floor.
        trigger = rule.get("trigger", {})
        if trigger and not _eval_node(trigger, ctx):
            continue

        # Resolve current value from current_field if specified
        current_val = None
        cf = rule.get("current_field")
        if cf:
            v = ctx.get(cf, _MISSING)
            current_val = str(v) if v is not _MISSING else "unknown"

        results.append(
            MatchedRule(
                id=rule_id,
                severity=rule.get("severity", "medium"),
                confidence=rule.get("confidence", "medium"),
                category=rule.get("category", ""),
                title=_substitute(rule.get("title", rule_id), ctx),
                why=rule.get("why", ""),
                core=rule.get("core", []),
                extensions=rule.get("extensions", {}),
                target=rule.get("target"),
                current=current_val,
                verify=rule.get("verify"),
                provenance=rule.get("provenance", {}),
                anchor=anchor,
                anchored_by=anchored_by,
                priority_default=rule.get("priority_default", ""),
                next_steps=rule.get("next_steps", []),
                os_remediation=rule.get("os_remediation", {}),
                caveats=rule.get("caveats", []),
            )
        )

    results.sort(
        key=lambda r: (
            _SEVERITY_ORDER.get(r.severity, 9),
            0 if r.confidence == "high" else 1 if r.confidence == "medium" else 2,
        )
    )

    return results


def evaluate_for_report(
    meta=None,
    cpu_summary=None,
    pmu_summary=None,
    mem_summary=None,
    sys_health: dict | None = None,
    app_context: dict | None = None,
    recommendations=None,
    aperf_findings=None,
) -> list[MatchedRule]:
    """
    Convenience wrapper: build context then evaluate.

    Without `aperf_findings` this returns an empty list — every rule is anchored on a
    finding aperf emitted, so a caller that passes no findings gets no advice. That is
    the intended behaviour, not a failure.
    """
    ctx = build_context(
        meta=meta,
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        mem_summary=mem_summary,
        sys_health=sys_health,
        app_context=app_context,
        recommendations=recommendations,
        aperf_findings=aperf_findings,
    )
    lang = ctx.get("runtime.language", "")
    return evaluate(ctx, language_hint=lang)


def reload() -> None:
    """Reload the rule database from disk (for tests or hot-reload)."""
    global _DB
    _DB = _load_db()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_kernel_major(kver: str) -> int:
    """Extract major version number from a kernel version string like '5.15.61-generic'."""
    if not kver:
        return 0
    m = re.match(r"(\d+)\.", kver)
    return int(m.group(1)) if m else 0


def _parse_graviton_gen(instance_type: str) -> int:
    """
    Infer Graviton generation from instance type suffix letter.
    c7g -> gen 3, c8g -> gen 4, r6g -> gen 2, etc.
    Returns 0 if not determinable.
    """
    m = re.search(r"[a-z](\d+)g\.", instance_type)
    if not m:
        return 0
    gen_num = int(m.group(1))
    # Graviton mapping: 6g=gen2, 7g=gen3, 8g=gen4
    if gen_num <= 6:
        return 2
    if gen_num == 7:
        return 3
    return 4


def _detect_language(app_context: dict) -> str:
    """
    Resolve runtime.language from multiple signals:
      1. Explicit language / primary_language / runtime field
      2. runtime_version string ("Java 11", "Python 3.12", "Node 20.4", ...)
      3. runtime_flags string (-Xmx, --max-old-space-size, GOMEMLIMIT, ...)
      4. fingerprint.primary_process / fingerprint.all_processes (java, python, node, dotnet, ...)
      5. dep_file extension/path (pom.xml, requirements.txt, package.json, Cargo.toml, ...)

    Returns the normalised key used by playbook rules: java, python, go, nodejs,
    dotnet, rust, cpp, php, ruby. Empty string if undetectable.
    """
    if not app_context:
        return ""

    # 1. Explicit fields
    explicit = (
        app_context.get("language")
        or app_context.get("primary_language")
        or app_context.get("runtime")
        or ""
    )
    if explicit:
        return _normalize_language(explicit.lower().strip())

    # 2. runtime_version string
    rv = (app_context.get("runtime_version") or "").lower()
    if rv:
        for needle, key in [
            ("java", "java"),
            ("openjdk", "java"),
            ("corretto", "java"),
            ("kotlin", "java"),
            ("scala", "java"),
            ("python", "python"),
            ("cpython", "python"),
            ("pypy", "python"),
            ("node", "nodejs"),
            ("nodejs", "nodejs"),
            ("typescript", "nodejs"),
            ("go ", "go"),
            ("golang", "go"),
            (".net", "dotnet"),
            ("dotnet", "dotnet"),
            ("csharp", "dotnet"),
            ("rust", "rust"),
            ("php", "php"),
            ("ruby", "ruby"),
        ]:
            if needle in rv:
                return key

    # 3. runtime_flags string — JVM-isms are most diagnostic
    rf = (app_context.get("runtime_flags") or "").lower()
    if rf:
        if "-xmx" in rf or "-xx:" in rf or "-xms" in rf or "usegc" in rf:
            return "java"
        if "gunicorn" in rf or "uwsgi" in rf or "tracemalloc" in rf:
            return "python"
        if "--max-old-space-size" in rf or "--inspect" in rf or "node " in rf:
            return "nodejs"
        if "gomemlimit" in rf or "gogc" in rf:
            return "go"
        if "dotnet_" in rf:
            return "dotnet"

    # 4. Fingerprint process names — same needle table `language_detector.py`'s
    # process-based engine uses, imported rather than duplicated so the two can never
    # drift into disagreeing about what a process name means.
    from .language_detector import PROCESS_NAME_LANGUAGE_NEEDLES

    fp = app_context.get("fingerprint") or {}
    procs = [fp.get("primary_process") or ""]
    procs.extend(fp.get("all_processes") or [])
    proc_blob = " ".join(p.lower() for p in procs if p)
    if proc_blob:
        for needle, key in PROCESS_NAME_LANGUAGE_NEEDLES:
            if needle in proc_blob:
                return key
        # Detect Go binaries by absence of language suffix and presence of compiled artefact
        # (this is a soft signal; only use if nothing else matched)

    # 5. Dep file path / format
    dep = (app_context.get("dep_file_resolved") or app_context.get("dep_file") or "").lower()
    if dep and dep not in ("auto", "none"):
        if "pom.xml" in dep or ".gradle" in dep or "ivy.xml" in dep:
            return "java"
        if "requirements" in dep or "pipfile" in dep or "pyproject" in dep:
            return "python"
        if "package.json" in dep:
            return "nodejs"
        if "go.mod" in dep:
            return "go"
        if "cargo.toml" in dep:
            return "rust"
        if ".csproj" in dep or "packages.config" in dep:
            return "dotnet"
        if "composer.json" in dep:
            return "php"
        if "gemfile" in dep:
            return "ruby"

    return ""


def _normalize_language(lang: str) -> str:
    """Normalize language string to the keys used in rule extensions."""
    lang = lang.lower().strip()
    mapping = {
        "java": "java",
        "kotlin": "java",  # runs on JVM
        "scala": "java",  # runs on JVM
        "groovy": "java",  # runs on JVM
        "python": "python",
        "python3": "python",
        "go": "go",
        "golang": "go",
        "node": "nodejs",
        "nodejs": "nodejs",
        "javascript": "nodejs",
        "typescript": "nodejs",
        "dotnet": "dotnet",
        ".net": "dotnet",
        "csharp": "dotnet",
        "c#": "dotnet",
        "rust": "rust",
        "c": "cpp",
        "c++": "cpp",
        "cpp": "cpp",
        "php": "php",
        "ruby": "ruby",
    }
    return mapping.get(lang, lang)
