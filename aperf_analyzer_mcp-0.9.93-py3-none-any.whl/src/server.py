# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
APerf Analyzer MCP Server

Exposes tools for:
- Listing and summarizing aperf runs
- Comparing multiple runs (delta analysis)
- Identifying hotspots and bottlenecks
- Language/runtime-specific performance advisory
- Flamegraph/profile summarization

Resources:
- Prompt templates (`aperf://prompts/...`) — language-specific advisory guides and
  system-level tuning playbooks
- Findings playbooks (`aperf://findings/...`) — one prescriptive playbook per analytical
  finding aperf can emit, plus the documents defining their vocabulary and gate precedence
"""

import asyncio
import logging
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    TextContent,
    Tool,
)
from pydantic import AnyUrl, BaseModel

from .mcp_tools.analyze_findings import ANALYZE_FINDINGS_TOOL, analyze_findings_handler
from .mcp_tools.compare_runs import COMPARE_RUNS_TOOL, compare_runs_handler
from .mcp_tools.config_diagnosis import CONFIG_DIAGNOSIS_TOOL, config_diagnosis_handler
from .mcp_tools.continuous_improve import CONTINUOUS_IMPROVE_TOOL, continuous_improve_handler
from .mcp_tools.dependency_analyzer import DEPENDENCY_ANALYZER_TOOL, dependency_analyzer_handler
from .mcp_tools.graviton_readiness import GRAVITON_READINESS_TOOL, graviton_readiness_handler
from .mcp_tools.hotspots import HOTSPOTS_TOOL, hotspots_handler
from .mcp_tools.html_report import GENERATE_HTML_REPORT_TOOL, generate_html_report_handler
from .mcp_tools.language_advisor import LANGUAGE_ADVISOR_TOOL, language_advisor_handler
from .mcp_tools.list_runs import LIST_RUNS_TOOL, list_runs_handler
from .mcp_tools.pricing_status import PRICING_STATUS_TOOL, pricing_status_handler
from .mcp_tools.profile_summary import PROFILE_SUMMARY_TOOL, profile_summary_handler
from .mcp_tools.regression_detect import REGRESSION_DETECT_TOOL, regression_detect_handler
from .mcp_tools.right_sizing import RIGHT_SIZING_TOOL, right_sizing_handler
from .mcp_tools.run_summary import RUN_SUMMARY_TOOL, run_summary_handler
from .mcp_tools.sysctl_ai_fallback import SYSCTL_AI_FALLBACK_TOOL, sysctl_ai_fallback_handler
from .mcp_tools.system_health import SYSTEM_HEALTH_TOOL, system_health_handler
from .parsers.playbook_library import URI_PREFIX as FINDINGS_URI_PREFIX
from .parsers.playbook_library import PlaybookNotFound, get_library

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Server Configuration
# ---------------------------------------------------------------------------


class ServerConfig(BaseModel):
    """Configuration for the aperf MCP server."""

    aperf_data_dir: str = "./aperf_data"  # Base directory for aperf runs
    max_comparison_runs: int = 10
    default_top_n: int = 10


# ---------------------------------------------------------------------------
# MCP Server Setup
# ---------------------------------------------------------------------------

app = Server("aperf-analyzer")

# All registered tools
TOOLS = [
    LIST_RUNS_TOOL,
    RUN_SUMMARY_TOOL,
    COMPARE_RUNS_TOOL,
    HOTSPOTS_TOOL,
    PROFILE_SUMMARY_TOOL,
    LANGUAGE_ADVISOR_TOOL,
    REGRESSION_DETECT_TOOL,
    SYSTEM_HEALTH_TOOL,
    RIGHT_SIZING_TOOL,
    CONFIG_DIAGNOSIS_TOOL,
    DEPENDENCY_ANALYZER_TOOL,
    GENERATE_HTML_REPORT_TOOL,
    CONTINUOUS_IMPROVE_TOOL,
    ANALYZE_FINDINGS_TOOL,
    PRICING_STATUS_TOOL,
    SYSCTL_AI_FALLBACK_TOOL,
    GRAVITON_READINESS_TOOL,
]

# Tool name → handler mapping
HANDLERS = {
    "list_runs": list_runs_handler,
    "get_run_summary": run_summary_handler,
    "compare_runs": compare_runs_handler,
    "get_hotspots": hotspots_handler,
    "get_profile_summary": profile_summary_handler,
    "get_language_advisory": language_advisor_handler,
    "detect_regressions": regression_detect_handler,
    "get_system_health": system_health_handler,
    "diagnose_config_errors": config_diagnosis_handler,
    "analyze_app_context": dependency_analyzer_handler,
    "generate_html_report": generate_html_report_handler,
    "improve_app": continuous_improve_handler,
    "analyze_findings": analyze_findings_handler,
    "pricing_status": pricing_status_handler,
    "get_right_sizing": right_sizing_handler,
    "sysctl_ai_fallback": sysctl_ai_fallback_handler,
    "graviton_readiness": graviton_readiness_handler,
}


# ---------------------------------------------------------------------------
# Resource Discovery
# ---------------------------------------------------------------------------

RESOURCES_DIR = Path(__file__).parent.parent / "resources" / "prompts"


def _discover_resources() -> list[Resource]:
    """Discover prompt templates and findings playbooks.

    Two families under two schemes. `aperf://prompts/` is advisory prose for a language or
    subsystem; `aperf://findings/` is a playbook bound to one analytical rule aperf can emit,
    naming the condition that fired it and what to do about it. They are kept apart so a client
    can tell "background reading" from "instructions for this specific finding".

    The findings side is enumerated from the registry rather than the filesystem, so the listing
    cannot advertise a playbook no rule joins to.
    """
    resources = []
    if RESOURCES_DIR.exists():
        for f in sorted(RESOURCES_DIR.glob("*.md")):
            resources.append(
                Resource(
                    uri=AnyUrl(f"aperf://prompts/{f.stem}"),
                    name=f.stem.replace("_", " ").title(),
                    description=f"Performance advisory prompt for {f.stem.replace('_advisory', '').replace('_', ' ')}",
                    mimeType="text/markdown",
                )
            )

    try:
        for doc in get_library().documents():
            resources.append(
                Resource(
                    uri=AnyUrl(doc.uri),
                    name=doc.title,
                    description=doc.description,
                    mimeType="text/markdown",
                )
            )
    except Exception:
        # A malformed registry must not take the prompt resources down with it.
        logger.exception("could not enumerate the findings playbooks")

    return resources


# ---------------------------------------------------------------------------
# MCP Protocol Handlers
# ---------------------------------------------------------------------------


@app.list_tools()  # type: ignore[no-untyped-call,untyped-decorator]
async def handle_list_tools() -> list[Tool]:
    """Return all available tools."""
    return TOOLS


#: Upper bound on one tool call. Above every timeout a tool sets itself (improve_app's test
#: run is 300 s, the pricing refresh 120 s), so it only fires on work that is genuinely stuck,
#: e.g. a parser looping on a crafted capture file.
_TOOL_CALL_TIMEOUT_SECS = 600

#: Tool calls run one at a time, as they always have: the handlers' bodies are synchronous and
#: were never written to run concurrently. The lock is released when a call times out, so a
#: stuck call cannot block every later one.
_tool_call_lock = asyncio.Lock()


@app.call_tool()  # type: ignore[untyped-decorator]
async def handle_call_tool(name: str, arguments: dict[str, Any] | None) -> list[TextContent]:
    """Dispatch tool calls to their handlers."""
    handler = HANDLERS.get(name)
    if not handler:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    try:
        # The handlers are `async def` but parse synchronously, so awaiting one directly would
        # block the event loop -- and a timeout on the loop could never fire. Each call runs on
        # a worker thread with its own loop instead. A Python thread cannot be killed, so a call
        # that times out keeps its thread until it finishes, but the server answers the client
        # and stays responsive.
        async with _tool_call_lock:
            result = await asyncio.wait_for(
                asyncio.to_thread(asyncio.run, handler(arguments or {})),
                timeout=_TOOL_CALL_TIMEOUT_SECS,
            )
        return [TextContent(type="text", text=result)]
    # asyncio.TimeoutError, not TimeoutError: they are only the same class from Python 3.11.
    except asyncio.TimeoutError:
        logger.error(f"Tool {name} timed out after {_TOOL_CALL_TIMEOUT_SECS}s")
        return [
            TextContent(
                type="text",
                text=f"Error executing {name}: timed out after {_TOOL_CALL_TIMEOUT_SECS} s",
            )
        ]
    except Exception as e:
        logger.exception(f"Error in tool {name}")
        return [TextContent(type="text", text=f"Error executing {name}: {e!s}")]


@app.list_resources()  # type: ignore[no-untyped-call,untyped-decorator]
async def handle_list_resources() -> list[Resource]:
    """Return every available resource: prompt templates and findings playbooks."""
    return _discover_resources()


@app.read_resource()  # type: ignore[no-untyped-call,untyped-decorator]
async def handle_read_resource(uri: Any) -> str:
    """Read a prompt template or a findings playbook.

    `uri` arrives as a pydantic `AnyUrl`, not a `str` — the lowlevel server hands the request
    field through unconverted — so it is stringified before any prefix test.
    """
    uri = str(uri)

    # aperf://prompts/{name}
    if uri.startswith("aperf://prompts/"):
        name = uri[len("aperf://prompts/") :]
        path = RESOURCES_DIR / f"{name}.md"
        # Resolve before comparing: a name of `../../etc/passwd` must not escape the directory.
        if path.resolve().parent == RESOURCES_DIR.resolve() and path.is_file():
            return path.read_text(encoding="utf-8")
        raise ValueError(f"Resource not found: {uri}")

    # aperf://findings/{data_type}/{slug} and aperf://findings/{TOP_DOC}
    if uri.startswith(FINDINGS_URI_PREFIX):
        try:
            return get_library().get(uri).read()
        except PlaybookNotFound:
            raise ValueError(
                f"Resource not found: {uri}. Findings playbooks are addressed as "
                f"{FINDINGS_URI_PREFIX}<data_type>/<slug>; list resources for the exact set."
            ) from None

    raise ValueError(f"Resource not found: {uri}")


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------


async def _run() -> None:
    """Run the MCP server over stdio."""
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


def main() -> None:
    """CLI entry point."""
    logging.basicConfig(level=logging.INFO)
    asyncio.run(_run())


if __name__ == "__main__":
    main()
