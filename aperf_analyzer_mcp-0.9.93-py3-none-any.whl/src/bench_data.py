# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Benchmark data loader — independent c-ray and STREAM measurements.

Reads `resources/bench_scores.json`, produced by `scripts/refresh_bench_scores.py`.

Two things this module exists to get right, because both are easy to get wrong and
neither fails loudly:

**c-ray is measured in SECONDS and lower is better.** Throughput is `1 / seconds`. The
inversion happens in exactly one function, `cpu_throughput()`, so no caller can invert
it twice or forget to. A caller that reads `.value` directly and treats a bigger number
as faster gets the answer exactly backwards.

**STREAM is MB/s and higher is better, but it is not a trustworthy scalar everywhere.**
Verified in the current data:

  - `c6a.8xlarge` reports 65,473 MB/s at 2 NUMA nodes; `c6a.12xlarge` — a LARGER
    instance — reports 49,401 MB/s at 1 node. Growing the instance measured 25% *less*
    bandwidth. The same inversion appears in `m6a`.
  - four rows rest on 1–4 steady samples (`i8g.16xlarge` on a single sample).

So `memory_bandwidth()` returns a value *and* a confidence, and the sizer is expected to
degrade to "must not regress" rather than rank on a number it cannot trust.

Everything else follows the report's own caveats: a null result means NOT MEASURED never
zero; per-core figures divide by `physical_cores` never vCPU; single sample per test with
about +/-10% run-to-run spread, so a difference under that is not resolved by this data.

Customer-facing sizing text describes relative capability in words rather than quoting these
figures: a raw c-ray time or STREAM number means little to a reader without the methodology
behind it, and a +/-10% noise band makes small percentage differences misleading. The raw
values are still available for audit through `include_internal`.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from .instance_types import InstanceType, parse

_DB_PATH = Path(__file__).parent.parent / "resources" / "bench_scores.json"

#: Documented run-to-run spread. A candidate must beat a demand by more than this to
#: count as sufficient, otherwise the decision rests on measurement noise.
NOISE_BAND_PCT = 10.0

#: Below this many steady samples a STREAM figure is a glance, not a measurement.
_MIN_STEADY_SAMPLES = 5

#: c-ray on a very fast instance takes only a few seconds, so the relative cost of a
#: fixed overhead grows as the score shrinks. Not currently used to reject rows, but
#: recorded so a future gate has somewhere to live.
_CPU_TEST = "c-ray"
_MEM_TEST = "stream"


class Confidence(str, Enum):
    """How much weight a benchmark figure can carry."""

    OK = "ok"
    LOW_SAMPLES = "low_samples"  # measured, but on too few steady samples
    NON_MONOTONIC = "non_monotonic"  # a larger size in the family measured lower
    MISSING = "missing"  # not measured; never means zero


@dataclass(frozen=True)
class Score:
    """A benchmark figure with its provenance. `value` is None when not measured."""

    value: float | None
    confidence: Confidence
    measured: bool  # False => inherited from the family's main variant
    detail: str = ""

    @property
    def usable(self) -> bool:
        """Whether this figure may be ranked on numerically."""
        return self.value is not None and self.confidence in (
            Confidence.OK,
            Confidence.LOW_SAMPLES,
        )

    @property
    def trustworthy(self) -> bool:
        """Whether this figure may be treated as a precise scalar."""
        return self.value is not None and self.confidence is Confidence.OK


def _load() -> dict[str, Any]:
    if not _DB_PATH.exists():
        return {"_metadata": {}, "instances": []}
    try:
        loaded: dict[str, Any] = json.loads(_DB_PATH.read_text())
    except (OSError, ValueError):
        return {"_metadata": {}, "instances": []}
    return loaded


_DB: dict[str, Any] = _load()
_BY_TYPE: dict[str, dict[str, Any]] = {r["instance_type"]: r for r in _DB.get("instances", [])}


def get(instance_type: str) -> dict[str, Any] | None:
    return _BY_TYPE.get((instance_type or "").strip().lower())


def all_instance_types() -> list[str]:
    return sorted(_BY_TYPE)


def vcpu(instance_type: str) -> int | None:
    rec = get(instance_type)
    return rec.get("vcpu_count") if rec else None


def cores(instance_type: str) -> int | None:
    """Physical cores. Use this, not vCPU, for any per-core figure."""
    rec = get(instance_type)
    return rec.get("physical_cores") if rec else None


def memory_gb(instance_type: str) -> float | None:
    """Usable RAM in GB as the instance reported it, not the marketing figure."""
    rec = get(instance_type)
    if not rec or not rec.get("memory_total_mb"):
        return None
    return float(rec["memory_total_mb"]) / 1024.0


def numa_nodes(instance_type: str) -> int | None:
    rec = get(instance_type)
    return rec.get("numa_node_count") if rec else None


def is_measured(instance_type: str) -> bool:
    """False for an inherited row — a d/n/dn variant copied from the main family."""
    rec = get(instance_type)
    return bool(rec and rec.get("measured"))


def cpu_throughput(instance_type: str) -> Score:
    """
    CPU throughput as `1 / c-ray seconds`. Higher is faster.

    THE INVERSION LIVES HERE AND NOWHERE ELSE. c-ray reports seconds-to-complete a fixed
    workload, so a bigger raw value is a SLOWER machine. Every comparison in the sizer
    runs on this function's output so the direction is decided once.
    """
    rec = get(instance_type)
    if not rec:
        return Score(None, Confidence.MISSING, False, "instance not in benchmark data")

    raw = (rec.get("results") or {}).get(_CPU_TEST) or {}
    seconds = raw.get("value")
    measured = bool(rec.get("measured"))

    if not seconds or seconds <= 0:
        return Score(
            None,
            Confidence.MISSING,
            measured,
            raw.get("error") or "c-ray not measured on this instance",
        )

    # A missing key means this source does not carry sample-count confidence at all — some
    # sources curate it separately — which is not the same claim as "measured on 0 steady
    # samples". `raw.get(...) or 0` collapsed both to 0 and marked every row from such a
    # source LOW_SAMPLES, which is a confidence claim the source never made.
    steady = raw.get("cpu_steady_samples")
    if steady is None:
        confidence, detail = Confidence.OK, ""
    else:
        confidence = Confidence.OK if steady >= _MIN_STEADY_SAMPLES else Confidence.LOW_SAMPLES
        detail = "" if confidence is Confidence.OK else f"only {steady} steady samples"
    return Score(1.0 / seconds, confidence, measured, detail)


#: family -> {size_rank: bandwidth}, used to detect the NUMA inversion.
_family_bandwidth_cache: dict[str, list[tuple[int, float]]] = {}


def _family_bandwidth_curve(family: str) -> list[tuple[int, float]]:
    """(vcpu, bandwidth) pairs for a family, ascending, measured rows only."""
    if family not in _family_bandwidth_cache:
        curve = []
        for rec in _DB.get("instances", []):
            if rec.get("family") != family:
                continue
            val = ((rec.get("results") or {}).get(_MEM_TEST) or {}).get("value")
            if val and rec.get("vcpu_count"):
                curve.append((rec["vcpu_count"], float(val)))
        _family_bandwidth_cache[family] = sorted(curve)
    return _family_bandwidth_cache[family]


def memory_bandwidth(instance_type: str) -> Score:
    """
    Sustained memory bandwidth in MB/s. Higher is better.

    Carries a confidence, because a raw STREAM number is not always a usable scalar:

    - `LOW_SAMPLES` when the figure rests on fewer than 5 steady samples.
    - `NON_MONOTONIC` when a SMALLER size in the same family measured materially higher
      bandwidth. That really happens — `c6a.8xlarge` (2 NUMA nodes) beats
      `c6a.12xlarge` (1 node) by 25%. The number is not wrong, but it does not mean
      "this instance has less memory bandwidth available per thread" in the way a
      ranking would imply, so the sizer must not rank on it.
    """
    rec = get(instance_type)
    if not rec:
        return Score(None, Confidence.MISSING, False, "instance not in benchmark data")

    raw = (rec.get("results") or {}).get(_MEM_TEST) or {}
    value = raw.get("value")
    measured = bool(rec.get("measured"))

    if not value or value <= 0:
        # STREAM needs 2.24 GiB of arrays, so small instances legitimately cannot run it.
        return Score(
            None,
            Confidence.MISSING,
            measured,
            raw.get("error") or "STREAM not measured on this instance",
        )

    value = float(value)
    # See the matching comment in `cpu_throughput`: an absent key is "not carried by this
    # source", not "measured on zero samples".
    steady = raw.get("cpu_steady_samples")
    if steady is not None and steady < _MIN_STEADY_SAMPLES:
        return Score(value, Confidence.LOW_SAMPLES, measured, f"only {steady} steady samples")

    my_vcpu = rec.get("vcpu_count") or 0
    for other_vcpu, other_val in _family_bandwidth_curve(rec.get("family", "")):
        if other_vcpu < my_vcpu and other_val > value * (1 + NOISE_BAND_PCT / 100.0):
            return Score(
                value,
                Confidence.NON_MONOTONIC,
                measured,
                f"a smaller size in {rec.get('family')} measured higher bandwidth "
                f"({other_vcpu} vCPU); NUMA topology differs across sizes",
            )

    return Score(value, Confidence.OK, measured)


def size_rank(instance_type: str) -> int | None:
    """
    Position on the size ladder, derived from `vcpu_count`.

    Deliberately not a hardcoded name list. The previous implementation carried
    `SIZE_ORDER` with 15 names and silently skipped every candidate whose size was not
    in it — verified to drop `nano`, `micro`, `small`, `metal`, `metal-24xl` and
    `metal-48xl`. vCPU count orders every size, including metal variants, and needs no
    maintenance when a new size appears.
    """
    return vcpu(instance_type)


def parsed(instance_type: str) -> InstanceType | None:
    return parse(instance_type)


def iter_candidates() -> Iterator[dict[str, Any]]:
    """Every benchmark record. No private-state reach-in required by callers."""
    yield from _DB.get("instances", [])
