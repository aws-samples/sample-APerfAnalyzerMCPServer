# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Primary-language detector — infers the application's main runtime from the process
data aperf itself already recorded (`processes.bin`/`processes.js`), with no explicit
questionnaire answer and no separate hook script required.

`playbook_engine.py::_detect_language(app_context)` already does language detection,
but only from EXPLICIT signals a caller supplied in `app_context` (a stated language, a
runtime-version string, JVM/GC flags, or a fingerprint the separate
`hooks/aperf_context_hook.py` script must have already built). This module is the
earlier stage that CAN populate one of those signals directly from
`AperfRunParser.get_report_data()`'s own `report_data["processes"]` — the same dict
every report already carries — so a report generated with no app_context at all still
gets a real language guess instead of "unknown".

Kernel-thread/systemd/init/bash exclusion and CPU-time ranking are copied byte-for-byte
from `hooks/aperf_context_hook.py::extract_fingerprint`'s own process-selection logic
(the one place in this codebase that already solved "which process is the real
workload, not noise") — this module does not re-derive that heuristic independently.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

#: Process-name substring -> normalised language key. Shared with
#: `playbook_engine.py::_detect_language`'s tier-4 (fingerprint process-name) branch,
#: which imports this exact tuple rather than carrying its own copy — one source of
#: truth, so the two can never drift into disagreeing about what a process name means.
PROCESS_NAME_LANGUAGE_NEEDLES: tuple[tuple[str, str], ...] = (
    ("java", "java"),
    (".jar", "java"),
    ("python", "python"),
    ("uwsgi", "python"),
    ("gunicorn", "python"),
    ("node", "nodejs"),
    ("dotnet", "dotnet"),
    ("rustc", "rust"),
    ("ruby", "ruby"),
    ("php-fpm", "php"),
    ("php ", "php"),
)

#: Byte-identical to `hooks/aperf_context_hook.py`'s own noise exclusion (flat-binary
#: branch) — kernel threads and process-supervision/shell noise, never the real workload.
_NOISE_PREFIXES = ("k",)
_NOISE_EXACT = ("systemd", "init", "sh", "bash")


@dataclass
class LanguageGuess:
    language: str = ""  # normalised key, "" if undetectable
    confidence: str = "low"  # "high" | "medium" | "low"
    evidence: list[str] = field(default_factory=list)


def _is_noise(name: str) -> bool:
    return name.startswith(_NOISE_PREFIXES) or name in _NOISE_EXACT


def _match_language(name: str) -> str:
    lowered = name.lower()
    for needle, key in PROCESS_NAME_LANGUAGE_NEEDLES:
        if needle in lowered:
            return key
    return ""


def _ranked_processes(report_data: dict[str, Any]) -> list[tuple[str, float]]:
    """
    `[(process_name, total_cpu_time), ...]` sorted by CPU time descending, real
    workload processes only (noise excluded). Handles BOTH shapes
    `AperfRunParser.get_report_data` can produce for `report_data["processes"]`:

    - Flat-binary layout: `{"<pid>_<name>": {"name", "utime", "stime", ...}}` — one
      entry per process, CPU time already summed.
    - Report-JS layout: `{"user_space_time": {"series": [{"series_name": "<pid>_<name>",
      "values": [...]}]}, "kernel_space_time": {...}, ...}` — one series per process
      PER METRIC, values are a time series that must be summed.
    """
    processes = report_data.get("processes")
    if not processes or not isinstance(processes, dict):
        return []

    # Flat-binary layout: every value is a process entry dict with "name"/"utime"/"stime".
    first_value = next(iter(processes.values()), None)
    if isinstance(first_value, dict) and "name" in first_value and "utime" in first_value:
        totals: dict[str, float] = {}
        for entry in processes.values():
            name = entry.get("name", "")
            if not name or _is_noise(name):
                continue
            cpu_time = float(entry.get("utime", 0)) + float(entry.get("stime", 0))
            totals[name] = totals.get(name, 0.0) + cpu_time
        return sorted(totals.items(), key=lambda kv: kv[1], reverse=True)

    # Report-JS layout: metric name -> {"series": [{"series_name": "<pid>_<name>", "values": [...]}]}.
    totals = {}
    for metric_name in ("user_space_time", "kernel_space_time"):
        metric = processes.get(metric_name) or {}
        for s in metric.get("series", []):
            series_name = s.get("series_name", "")
            # "<pid>_<name>" — name is everything after the first underscore, since a
            # process name can itself contain underscores (e.g. "aws-k8s-agent" does
            # not, but this must not assume no process name ever will).
            _pid, _, name = series_name.partition("_")
            if not name or _is_noise(name):
                continue
            values = s.get("values") or []
            cpu_time = sum(float(v) for v in values if isinstance(v, (int, float)))
            totals[name] = totals.get(name, 0.0) + cpu_time
    return sorted(totals.items(), key=lambda kv: kv[1], reverse=True)


def detect_primary_language(report_data: dict[str, Any]) -> LanguageGuess:
    """
    Infer the primary application language from `report_data["processes"]`.

    Never raises: absent, malformed, or noise-only process data all resolve to an
    explicit low-confidence "undetectable" guess rather than an exception, since a
    report must still render when process data is missing or unrecognisable.
    """
    ranked = _ranked_processes(report_data)
    if not ranked:
        return LanguageGuess(
            language="",
            confidence="low",
            evidence=["no process data available in this capture"],
        )

    top_name, top_cpu = ranked[0]
    runner_up_cpu = ranked[1][1] if len(ranked) > 1 else 0.0

    language = _match_language(top_name)
    if not language:
        # The top CPU consumer didn't name-match anything — check the next few
        # ranked processes in case the real application sits behind a supervisor
        # process (e.g. "supervisord" outranking the "gunicorn" worker it spawned).
        for name, _cpu in ranked[1:5]:
            language = _match_language(name)
            if language:
                return LanguageGuess(
                    language=language,
                    confidence="medium",
                    evidence=[
                        f"top CPU consumer '{top_name}' did not match a known "
                        f"language; '{name}' (ranked lower) matched '{language}'",
                    ],
                )
        return LanguageGuess(
            language="",
            confidence="low",
            evidence=[
                f"top CPU-consuming process '{top_name}' did not match a known language signature",
            ],
        )

    dominant = runner_up_cpu == 0.0 or top_cpu > runner_up_cpu * 2
    confidence = "high" if dominant else "medium"
    evidence = [
        f"process '{top_name}' consuming the most CPU time "
        f"({top_cpu:.0f} vs runner-up {runner_up_cpu:.0f})",
    ]
    return LanguageGuess(language=language, confidence=confidence, evidence=evidence)
