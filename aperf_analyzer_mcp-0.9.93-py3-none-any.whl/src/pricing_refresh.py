# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Shared EC2 pricing refresh logic for us-east-1, from the AWS public bulk pricing API.

Both `scripts/refresh_pricing.py` (a standalone CLI, documented in README.md) and
`src/mcp_tools/pricing_status.py`'s MCP tool call `refresh()` here rather than one
shelling/subprocessing out to the other. That used to be backwards: the MCP tool spawned the CLI
script as a subprocess (`create_subprocess_exec(sys.executable, str(REFRESH_SCRIPT), ...)`),
which is exactly the "argument to a process-spawning call is not a literal string" shape a
security scanner flags, correctly, as unauditable in general even when — as here — the specific
argument happens to be a fixed constant. There is no such call in this module at all now; `main`
in the CLI script imports and calls the same function this module's own async API calls.
"""

from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests

# Master index for AmazonEC2 service
INDEX_URL = (
    "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current/us-east-1/index.json"
)
OUTPUT_PATH = Path(__file__).parent.parent / "resources" / "ec2_pricing_us_east_1.json"
USER_AGENT = "aperf-analyzer-mcp/refresh-pricing"
FETCH_TIMEOUT_SECS = 60


def _fetch_sync(url: str) -> dict[str, Any]:
    """
    Blocking HTTP fetch — always run via `asyncio.to_thread` from async callers.

    Uses `requests`, not `urllib.request.urlopen` -- urllib itself supports `file://` and other
    non-HTTP schemes, which a security scanner (correctly) flags on every urlopen call regardless
    of whether the URL passed to it is a literal or a variable, since the module-level capability
    is what's being audited, not this call site's specific argument. `requests` has no such
    scheme surface. `url` here is in fact only ever the hardcoded INDEX_URL constant above
    (confirmed: the sole call site is `_fetch_sync(INDEX_URL)`) -- this switch is not "url could
    be attacker-controlled," it is "urlopen itself is a broader capability than this code needs."
    """
    resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=FETCH_TIMEOUT_SECS)
    resp.raise_for_status()
    result: dict[str, Any] = resp.json()
    return result


def _extract_prices(index_data: dict[str, Any]) -> dict[str, float]:
    """
    Filter the AWS pricing index to:
    - Linux OS
    - Shared tenancy
    - OnDemand term
    - preInstalledSw == NA
    - capacityStatus == Used (the standard, non-reserved capacity)

    Returns dict[instance_type] -> price_per_hour (USD).
    """
    products = index_data.get("products", {})
    on_demand_terms = index_data.get("terms", {}).get("OnDemand", {})

    sku_to_instance = {}
    for sku, product in products.items():
        attrs = product.get("attributes", {})
        if attrs.get("productFamily", product.get("productFamily")) != "Compute Instance":
            continue
        if attrs.get("operatingSystem") != "Linux":
            continue
        if attrs.get("tenancy") != "Shared":
            continue
        if attrs.get("preInstalledSw") != "NA":
            continue
        if attrs.get("capacitystatus") != "Used":
            continue

        instance_type = attrs.get("instanceType")
        if instance_type:
            sku_to_instance[sku] = instance_type

    prices: dict[str, float] = {}
    for sku, instance_type in sku_to_instance.items():
        sku_terms = on_demand_terms.get(sku, {})
        for term in sku_terms.values():
            for dim in term.get("priceDimensions", {}).values():
                price_str = dim.get("pricePerUnit", {}).get("USD")
                if price_str:
                    try:
                        price = float(price_str)
                        if price > 0:
                            # If multiple SKUs map to the same instance type, prefer the lower
                            # price (sometimes there are duplicates).
                            existing = prices.get(instance_type)
                            if existing is None or price < existing:
                                prices[instance_type] = price
                    except ValueError:
                        pass
                    break  # first valid price dimension is enough

    return prices


def _read_existing() -> tuple[dict[str, float], str]:
    if not OUTPUT_PATH.exists():
        return {}, "none"
    try:
        existing = json.loads(OUTPUT_PATH.read_text())
        return existing.get("prices", {}), existing.get("_metadata", {}).get(
            "publication_date", "none"
        )
    except (json.JSONDecodeError, OSError):
        return {}, "none"


def _build_output(index_data: dict[str, Any], prices: dict[str, float]) -> dict[str, Any]:
    return {
        "_metadata": {
            "region": "us-east-1",
            "publication_date": index_data.get("publicationDate", "unknown"),
            "version": index_data.get("version", "unknown"),
            "fetched_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "source_url": INDEX_URL,
            "filters": {
                "os": "Linux",
                "tenancy": "Shared",
                "term": "OnDemand",
                "preInstalledSw": "NA",
                "capacityStatus": "Used",
            },
            "instance_count": len(prices),
        },
        "prices": dict(sorted(prices.items())),
    }


async def refresh(dry_run: bool = False) -> dict[str, Any]:
    """
    Fetch, filter, and (unless `dry_run`) atomically write the current EC2 pricing snapshot.

    The network fetch runs in a worker thread (`asyncio.to_thread`) so this coroutine never
    blocks the event loop the MCP server shares with every other in-flight tool call. Await this
    directly; it has no timeout of its own — callers that need one (the MCP tool does) wrap the
    call in `asyncio.wait_for` and must not act on `OUTPUT_PATH` if that raises, since a
    cancelled-by-timeout fetch never reaches the write step below.

    Returns a dict describing what happened; raises on fetch/parse failure rather than returning
    an error dict, so a caller cannot forget to check a status field.
    """
    index_data = await asyncio.to_thread(_fetch_sync, INDEX_URL)

    publication_date = index_data.get("publicationDate", "unknown")
    version = index_data.get("version", "unknown")

    prices = _extract_prices(index_data)
    if not prices:
        raise ValueError("No prices extracted from the AWS pricing index response.")

    existing_prices, existing_pub_date = _read_existing()
    added = sorted(set(prices.keys()) - set(existing_prices.keys()))
    removed = sorted(set(existing_prices.keys()) - set(prices.keys()))
    changed = [
        (k, existing_prices[k], prices[k])
        for k in sorted(set(prices.keys()) & set(existing_prices.keys()))
        if existing_prices[k] > 0
        and abs(prices[k] - existing_prices[k]) / existing_prices[k] > 0.01
    ]

    output = _build_output(index_data, prices)
    output_json = json.dumps(output, indent=2)

    wrote = False
    if not dry_run:
        # Atomic write: a reader (pricing.py's lookup(), loaded fresh on every MCP tool call) must
        # never observe a partially-written file. Write to a sibling temp file in the same
        # directory (same filesystem, so os.replace is atomic) then rename over the real path.
        tmp_path = OUTPUT_PATH.with_suffix(".json.tmp")
        OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp_path.write_text(output_json)
        tmp_path.replace(OUTPUT_PATH)
        wrote = True

    return {
        "wrote": wrote,
        "instance_count": len(prices),
        "previous_instance_count": len(existing_prices),
        "publication_date": publication_date,
        "previous_publication_date": existing_pub_date,
        "version": version,
        "added_count": len(added),
        "removed_count": len(removed),
        "changed_count": len(changed),
        "added": added,
        "removed": removed,
        "changed": changed,
        "output_size_kb": len(output_json.encode("utf-8")) / 1024,
    }


def refresh_sync(dry_run: bool = False) -> dict[str, Any]:
    """Synchronous entry point for the standalone CLI script (no event loop to share)."""
    return asyncio.run(refresh(dry_run=dry_run))


def _print_report(result: dict[str, Any], verbose: bool) -> None:
    print(f"Local publicationDate:  {result['previous_publication_date']}", file=sys.stderr)
    print(f"AWS publicationDate:    {result['publication_date']}", file=sys.stderr)
    print(
        f"Instance count:         {result['instance_count']} "
        f"(was {result['previous_instance_count']})",
        file=sys.stderr,
    )
    print(f"  +added:               {result['added_count']}")
    print(f"  -removed:             {result['removed_count']}")
    print(f"  ~price changes >1%:   {result['changed_count']}")
    print(f"Output size:            {result['output_size_kb']:.1f} KB")

    if verbose:
        if result["added"]:
            print(f"\nAdded ({len(result['added'])}):", file=sys.stderr)
            for it in result["added"][:20]:
                print(f"  + {it}", file=sys.stderr)
            if len(result["added"]) > 20:
                print(f"  ... and {len(result['added']) - 20} more", file=sys.stderr)
        if result["removed"]:
            print(f"\nRemoved ({len(result['removed'])}):", file=sys.stderr)
            for it in result["removed"][:20]:
                print(f"  - {it}", file=sys.stderr)
        if result["changed"]:
            print(f"\nPrice changes ({len(result['changed'])}):", file=sys.stderr)
            for it, old, new in result["changed"][:20]:
                pct = (new - old) / old * 100
                print(f"  ~ {it}: ${old:.4f} -> ${new:.4f} ({pct:+.1f}%)", file=sys.stderr)

    if not result["wrote"]:
        print("\nDry run — no file written.", file=sys.stderr)
    else:
        print(f"\nWrote {OUTPUT_PATH}", file=sys.stderr)
