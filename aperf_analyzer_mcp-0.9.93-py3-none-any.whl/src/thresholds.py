# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Single source of truth for metric thresholds.

Every threshold here is either aperf's own value or a documented refinement of one. The
point is that there is exactly one place to change them.

Why this module exists
----------------------
The same metric previously carried different gates in six files, with no stated reason
for any of them. ITLB alone had four values:

    aperf perf_stat.rs           > 0.0
    diagnostic_playbooks.json    >= 3 (java) / >= 5 (non-java)
    language_advisor.py          > 5
    pmu_parser.py                > 5
    html_report.py               > 5

DTLB had four as well (0.0 / 3 / 5 / 8) and branch-miss had five (10 / 8 / 5 / 12).
Fixing one did not propagate, so the report and the advisory could disagree about the
same run.

Two kinds of value
------------------
`APERF_*` are aperf's own thresholds, reproduced so callers can say "aperf fires here".
Do not change them to express a preference — they describe someone else's code.

`FLOOR_*` are our refinements, and they exist only because four of aperf's TLB rules
fire at `> 0.0`, i.e. on any nonzero sample. The findings library rates those
Informational by default for exactly that reason: a rule that fires on essentially every
run ranks nothing. The floors come from that library's published magnitude bands, and the
band is recorded next to each so the number is not mistaken for taste.
"""

from __future__ import annotations

import os

# ---------------------------------------------------------------------------
# aperf's own thresholds — src/analytics/rules/perf_stat.rs, vmstat.rs,
# cpu_utilization.rs, java_profile.rs. Descriptive, not ours to tune.
# ---------------------------------------------------------------------------

#: branch-mpki, Comparator::GreaterEqual. Per 1000 INSTRUCTIONS, not per 1000 branches.
APERF_BRANCH_MPKI = 10.0

#: inst-l1-mpki and data-l1-mpki, Comparator::Greater.
APERF_L1_MPKI = 20.0

#: l2-mpki and l3-mpki, Comparator::Greater.
APERF_L2_MPKI = 10.0
APERF_L3_MPKI = 10.0

#: code-sparsity, Comparator::Greater. Graviton PMU configs only.
APERF_CODE_SPARSITY = 0.5

#: strex-spec-pki, Comparator::GreaterEqual. arm64 only.
APERF_STREX_SPEC_PKI = 10.0

#: All four TLB rules: data/inst-tlb-mpki and data/inst-tlb-tw-pki, Comparator::Greater.
#: Firing on any nonzero sample is why FLOOR_* below exists.
APERF_TLB_ANY = 0.0

#: cpu_utilization "idle", Stat::Average, Comparator::Greater. Score::Critical — but the
#: findings library notes that top position "is an artifact of the formula, not a ranking".
APERF_IDLE_PCT = 50.0

#: vmstat pgfault, Stat::P99, Comparator::Greater. Two caveats that make this weak: the
#: threshold is compared against a PER-INTERVAL delta while the message claims "/s", and
#: Stat::P99 equals the maximum on any run under 101 samples.
APERF_PGFAULT_P99 = 100_000.0

#: java_profile stack-frame share, in percent of total samples.
APERF_EXCEPTION_SAMPLE_PCT = 5.0

#: Intra-run stall comparison margin: backend vs frontend, ±10%. NOTE this is a RATIO
#: between two metrics, not an absolute stall percentage. Gates written as
#: `backend_stall_pct > 30` measure something aperf does not compute.
APERF_STALL_RATIO_MARGIN = 0.1


# ---------------------------------------------------------------------------
# Our refinements. Each cites the band it came from.
# ---------------------------------------------------------------------------

#: data-tlb-mpki. Band: the "real" band starts ~2 pki (below that is measurement floor
#: and mild). aperf fires at > 0.0.
FLOOR_DTLB_MPKI = 2.0

#: inst-tlb-mpki. Bands: <0.5 universal-ignore / 0.5-2 mild / 2-10 real / >10 severe.
FLOOR_ITLB_MPKI = 2.0

#: Table walks start one band higher than misses, because every counted event is a
#: completed page-table walk rather than an L2-TLB hit. Bands: <0.1 measurement floor /
#: 0.1-1 mild / 1-5 real / >5 severe.
FLOOR_TLB_TABLE_WALK_PKI = 1.0

#: Walks / misses. Below 0.2 the L2 TLB is absorbing misses and huge pages win little;
#: at or above 0.5 the hierarchy is saturated and huge pages are very likely to help.
#: This is the decision variable for THP advice, not the raw miss rate.
ESCALATION_FRACTION_LOW = 0.2
ESCALATION_FRACTION_SATURATED = 0.5


def tlb_pressure_is_actionable(dtlb_mpki: float, itlb_mpki: float) -> bool:
    """
    True when measured TLB pressure justifies acting, as opposed to merely being nonzero.

    aperf's TLB rules fire on any nonzero sample, so "the finding exists" is not the same
    as "this is worth fixing". Either side satisfying its floor is enough: instruction and
    data translation pressure have different causes and either alone can dominate.
    """
    return dtlb_mpki >= FLOOR_DTLB_MPKI or itlb_mpki >= FLOOR_ITLB_MPKI


def escalation_fraction(misses_mpki: float, table_walks_pki: float) -> float | None:
    """
    Table walks per miss, or None when there are no misses to divide by.

    Caveat worth knowing before trusting this: the ratio is a true fraction only on the
    Graviton PMU profiles. On 5 of 8 profiles the miss and walk counters are DISJOINT, so
    total pressure is `misses + walks` and a ratio above 1.0 is legitimate there rather
    than a collection bug.
    """
    if misses_mpki <= 0:
        return None
    return table_walks_pki / misses_mpki


# ---------------------------------------------------------------------------
# Right-sizing: pressure classification and sizing safety.
#
# These gate a recommendation to CHANGE A CUSTOMER'S INSTANCE, so each one is
# stated with the reason it sits where it does.
# ---------------------------------------------------------------------------

#: CPU peak utilisation bands. `peak`, not average: an average is diluted by process
#: start-up and by any idle stretch inside the capture window, and a workload that hits
#: 85% for ten minutes an hour is not a 20%-utilised workload.
CPU_PRESSURE_HIGH_PCT = 75.0
CPU_PRESSURE_MODERATE_PCT = 40.0

#: Memory CAPACITY bands, on peak used percent. Distinct from bandwidth: a box can be
#: 95% full and completely un-stressed on bandwidth, or half empty and bandwidth-bound.
MEMORY_CAPACITY_HIGH_PCT = 85.0
MEMORY_CAPACITY_MODERATE_PCT = 65.0

#: Memory BANDWIDTH pressure, as the backend/frontend stall ratio.
#:
#: A ratio, deliberately not the absolute `backend_stall_pct`. aperf normalises the
#: backend term differently per vendor (see `PmuSummary.stall_denominator`: issue slots
#: on Intel ICL/SPR, slot-scaled on AMD Genoa), so a bare `backend_stall_pct > 40`
#: compares different quantities across exactly the architectures a right-sizing
#: decision has to weigh against each other. The ratio is vendor-stable, and it is what
#: aperf's own Backend-Dominated CPU Stalls rule computes.
BACKEND_DOMINANCE_HIGH = 2.0  # backend stalls at least 2x frontend
BACKEND_DOMINANCE_MODERATE = 1.1  # aperf's own intra-run margin

#: Last-level cache misses per 1k instructions. Sustained L3 misses go to DRAM, so this
#: is the most direct available proxy for real memory-bandwidth demand.
L3_MPKI_HIGH = 20.0
L3_MPKI_MODERATE = 10.0  # aperf's own High L3 Cache Misses threshold

#: Headroom added on top of observed demand before a candidate is considered sufficient.
#: An aperf capture is a window, not a year — it can easily miss the busy hour.
SIZING_SAFETY_BUFFER_PCT = 50.0

#: A candidate is only proposed if the workload's peak, projected onto it, stays under
#: this ceiling. "Projected" means: what would the current peak utilisation become if
#: this exact workload ran on the candidate instead, scaled by the two instances'
#: relative CPU throughput. A ceiling gives a MEANING to the peak that
#: `SIZING_SAFETY_BUFFER_PCT` does not: a candidate that would only reach 55% under the
#: SAME peak is a safer bet than one that would already sit at 71%, and the buffer-based
#: gate cannot distinguish those two cases from each other as directly as this can.
#:
#: The module-level default below. Operators who want a stricter (or looser) ceiling set
#: `APERF_MAX_PROJECTED_UTILIZATION_PCT`; read it via `max_projected_utilization_pct()`,
#: not this constant directly, so a change to the env var takes effect without a restart
#: of anything that calls the function fresh per request — the same reasoning as
#: `APERF_DATA_DIR`/`APERF_APPROVED_PROJECT_DIRS`, both operator-level config read from
#: the environment rather than a per-call tool argument.
SIZING_MAX_PROJECTED_UTILIZATION_PCT = 50.0

_MAX_PROJECTED_UTILIZATION_ENV = "APERF_MAX_PROJECTED_UTILIZATION_PCT"


def max_projected_utilization_pct() -> float:
    """
    The effective ceiling: `APERF_MAX_PROJECTED_UTILIZATION_PCT` if set to a valid
    number, else `SIZING_MAX_PROJECTED_UTILIZATION_PCT`.

    A malformed value (unset, empty, not a float) falls back to the default rather than
    raising, consistent with every other env-configured value in this server — a typo in
    an operator's environment should degrade to a safe default, not take down sizing.
    """
    raw = os.environ.get(_MAX_PROJECTED_UTILIZATION_ENV)
    if raw is None or not raw.strip():
        return SIZING_MAX_PROJECTED_UTILIZATION_PCT
    try:
        return float(raw)
    except ValueError:
        return SIZING_MAX_PROJECTED_UTILIZATION_PCT


#: A capture this short cannot characterise a workload; say so rather than size on it.
MIN_SAMPLES_FOR_SIZING = 5
