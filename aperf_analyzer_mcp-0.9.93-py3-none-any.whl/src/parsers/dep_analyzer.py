# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Dependency analyzer for aperf reports.

Parses dep files in multiple formats and classifies each entry against
the curated ARM64 blockers DB.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DepEntry:
    name: str
    version: str | None
    severity: str  # BLOCKER | VERIFY | DEGRADED | CLEAR
    reason: str
    action: str
    verification: str = ""


@dataclass
class DepAnalysis:
    language: str
    dep_file_path: str
    dep_file_format: str
    total_count: int = 0
    blockers: list[DepEntry] = field(default_factory=list)
    verifies: list[DepEntry] = field(default_factory=list)
    degradeds: list[DepEntry] = field(default_factory=list)
    clears: list[DepEntry] = field(default_factory=list)
    parse_errors: list[str] = field(default_factory=list)


def _load_blockers() -> dict:
    db_path = Path(__file__).parent.parent.parent / "resources" / "arm64_blockers.json"
    if not db_path.exists():
        return {}
    try:
        return json.loads(db_path.read_text())
    except Exception:
        return {}


_BLOCKERS_DB = _load_blockers()


def _version_lte(version: str, target: str) -> bool:
    if not version or not target:
        return False

    def _norm(v: str) -> tuple:
        v = re.sub(r"[-+].*$", "", v.strip())
        nums = []
        for p in v.split("."):
            try:
                nums.append(int(p))
            except ValueError:
                break
        return tuple(nums)

    try:
        return _norm(version) <= _norm(target)
    except Exception:
        return False


def classify_dep(name: str, version: str | None, language: str) -> DepEntry:
    """Classify a dep against the blockers DB.

    Walks all matching entries and returns the most relevant classification:
    - If any entry matches with version <= max_version_blocked, return that entry
    - Order: BLOCKER first (most severe), then DEGRADED, then VERIFY
    - If no version match but at least one entry matches the name pattern,
      return CLEAR (the dep is known and current version is above all thresholds)
    - If no entry matches at all, return CLEAR (likely pure-language)
    """
    matched_entries = []
    for entry in _BLOCKERS_DB.get(language, []):
        if not isinstance(entry, dict) or "_note" in entry:
            continue
        pattern = entry.get("match", "")
        if not pattern or not re.search(pattern, name, re.IGNORECASE):
            continue
        matched_entries.append(entry)

    if not matched_entries:
        # No entry in the DB matches this dep — assume CLEAR (pure-language)
        return DepEntry(
            name=name,
            version=version,
            severity="CLEAR",
            reason="No known ARM64 issues. Likely pure-language dependency.",
            action="None.",
        )

    # Among matching entries, find ones where the version triggers the threshold
    triggered = []
    for entry in matched_entries:
        max_ver = entry.get("max_version_blocked", "0.0.0")
        if version and _version_lte(version, max_ver):
            triggered.append(entry)

    if triggered:
        # Pick the most severe triggered entry
        severity_order = {"BLOCKER": 0, "DEGRADED": 1, "VERIFY": 2, "CLEAR": 3}
        triggered.sort(key=lambda e: severity_order.get(e.get("severity", "CLEAR"), 99))
        entry = triggered[0]
        return DepEntry(
            name=name,
            version=version,
            severity=entry.get("severity", "VERIFY"),
            reason=entry.get("reason", ""),
            action=entry.get("action", ""),
            verification=entry.get("verification", ""),
        )

    # No threshold triggered — version is above all known thresholds for this dep
    # Return CLEAR with a note that this is a known-good version of a tracked dep
    return DepEntry(
        name=name,
        version=version,
        severity="CLEAR",
        reason=f"Version is above all known ARM64-related thresholds for {name}.",
        action="None.",
    )


# ---------------------------------------------------------------------------
# Format-specific parsers
# ---------------------------------------------------------------------------


def _parse_maven_dep_tree(content: str) -> list[tuple[str, str | None]]:
    """Parse 'mvn dependency:tree' text format."""
    deps = []
    seen = set()
    pattern = re.compile(
        r"([a-zA-Z0-9_.\-]+):([a-zA-Z0-9_.\-]+):"
        r"(?:jar|war|pom|aar):"
        r"(?:[a-zA-Z0-9_.\-]+:)?"
        r"([0-9][\w.\-+]*?):"
        r"(?:compile|runtime|provided|test|system|import)"
    )
    for m in pattern.finditer(content):
        key = f"{m.group(1)}:{m.group(2)}"
        if key not in seen:
            seen.add(key)
            deps.append((key, m.group(3)))
    return deps


def _parse_pom_xml(content: str) -> list[tuple[str, str | None]]:
    deps = []
    seen = set()
    for block in re.findall(r"<dependency>(.*?)</dependency>", content, re.DOTALL):
        gid = re.search(r"<groupId>([^<]+)</groupId>", block)
        aid = re.search(r"<artifactId>([^<]+)</artifactId>", block)
        ver = re.search(r"<version>([^<]+)</version>", block)
        if gid and aid:
            key = f"{gid.group(1).strip()}:{aid.group(1).strip()}"
            version = ver.group(1).strip() if ver else None
            if version and version.startswith("${"):
                version = None
            if key not in seen:
                seen.add(key)
                deps.append((key, version))
    return deps


def _parse_requirements_txt(content: str) -> list[tuple[str, str | None]]:
    deps = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "-")):
            continue
        line = line.split("#")[0].strip()
        m = re.match(r"^([a-zA-Z0-9_\-\[\]\.]+)\s*([=~<>!]=?\s*[\d.][\w.\-]*)?", line)
        if m:
            name = m.group(1).split("[")[0]
            version = None
            if m.group(2):
                vm = re.search(r"[\d.][\w.\-]*", m.group(2))
                if vm:
                    version = vm.group(0)
            deps.append((name, version))
    return deps


def _parse_package_json(content: str) -> list[tuple[str, str | None]]:
    deps = []
    try:
        pkg = json.loads(content)
        for section in ("dependencies", "devDependencies", "peerDependencies"):
            for name, ver in (pkg.get(section) or {}).items():
                vm = re.search(r"[\d]+(?:\.[\d]+)*(?:[\w.\-]*)?", str(ver))
                deps.append((name, vm.group(0) if vm else None))
    except Exception:
        pass
    return deps


def _parse_cargo_toml(content: str) -> list[tuple[str, str | None]]:
    deps = []
    in_deps = False
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            in_deps = line in ("[dependencies]", "[dev-dependencies]", "[build-dependencies]")
            continue
        if not in_deps or not line or line.startswith("#"):
            continue
        m1 = re.match(r'^([a-zA-Z0-9_\-]+)\s*=\s*"([^"]+)"', line)
        m2 = re.match(r'^([a-zA-Z0-9_\-]+)\s*=\s*\{[^}]*version\s*=\s*"([^"]+)"', line)
        if m1:
            deps.append((m1.group(1), m1.group(2)))
        elif m2:
            deps.append((m2.group(1), m2.group(2)))
    return deps


def _parse_gradle(content: str) -> list[tuple[str, str | None]]:
    deps = []
    seen = set()
    pattern = re.compile(
        r"(?:implementation|api|compileOnly|runtimeOnly|testImplementation|annotationProcessor)"
        r"\s*\(?\s*['\"]([^:'\"]+):([^:'\"]+):([^'\"]+)['\"]"
    )
    for m in pattern.finditer(content):
        key = f"{m.group(1)}:{m.group(2)}"
        if key not in seen:
            seen.add(key)
            deps.append((key, m.group(3)))
    return deps


def _parse_go_mod(content: str) -> list[tuple[str, str | None]]:
    deps = []
    in_require = False
    for line in content.splitlines():
        line = line.strip()
        if line.startswith("require ("):
            in_require = True
            continue
        if line == ")":
            in_require = False
            continue
        m = re.match(r"^(\S+)\s+v(\S+)", line)
        if m and (in_require or line.startswith("require ")):
            deps.append((m.group(1), m.group(2)))
    return deps


def _parse_composer_json(content: str) -> list[tuple[str, str | None]]:
    deps = []
    try:
        cj = json.loads(content)
        for section in ("require", "require-dev"):
            for name, ver in (cj.get(section) or {}).items():
                vm = re.search(r"[\d]+(?:\.[\d]+)*(?:[\w.\-]*)?", str(ver))
                deps.append((name, vm.group(0) if vm else None))
    except Exception:
        pass
    return deps


# ---------------------------------------------------------------------------
# Format detection and dispatch
# ---------------------------------------------------------------------------


def detect_dep_format(file_path: Path) -> tuple[str, str] | None:
    """Detect dep file format. Returns (language, format_name) or None."""
    if not file_path.exists():
        return None

    name = file_path.name.lower()
    if name == "pom.xml":
        return ("java", "pom.xml")
    if name in ("dep tree", "deptree.txt", "dependency-tree.txt", "mvn-tree.txt"):
        return ("java", "maven_dep_tree")
    if name.startswith("requirements") and name.endswith(".txt"):
        return ("python", "requirements.txt")
    if name == "pipfile":
        return ("python", "Pipfile")
    if name == "package.json":
        return ("node", "package.json")
    if name == "cargo.toml":
        return ("rust", "Cargo.toml")
    if name in ("build.gradle", "build.gradle.kts"):
        return ("java", "build.gradle")
    if name == "go.mod":
        return ("go", "go.mod")
    if name == "composer.json":
        return ("php", "composer.json")

    # Content-based fallback
    try:
        content = file_path.read_text(errors="ignore")[:2000]
        if re.search(r":\w+:(?:jar|war|pom):[\d]", content):
            return ("java", "maven_dep_tree")
        if re.search(r"^\s*<\?xml", content) and "<dependencies>" in content:
            return ("java", "pom.xml")
        if re.search(r"^[a-zA-Z][\w\-\.]+\s*[=~<>!]=?\s*[\d]", content, re.MULTILINE):
            return ("python", "requirements.txt")
    except Exception:
        pass

    return None


def auto_detect_dep_file(run_dir: Path) -> Path | None:
    """Look for common dep file names in the aperf run directory or parent."""
    if not run_dir.exists():
        return None

    candidates = [
        "dep tree",
        "deptree.txt",
        "dependency-tree.txt",
        "mvn-tree.txt",
        "pom.xml",
        "requirements.txt",
        "Pipfile",
        "package.json",
        "Cargo.toml",
        "build.gradle",
        "build.gradle.kts",
        "go.mod",
        "composer.json",
    ]

    for parent in [run_dir, run_dir.parent]:
        for name in candidates:
            p = parent / name
            if p.exists() and p.is_file():
                return p
    return None


def analyze_dep_file(file_path: Path) -> DepAnalysis:
    """Parse a dep file and classify each entry."""
    detected = detect_dep_format(file_path)
    if not detected:
        return DepAnalysis(
            language="unknown",
            dep_file_path=str(file_path),
            dep_file_format="unknown",
            parse_errors=[f"Could not detect format of {file_path.name}"],
        )

    language, fmt = detected

    try:
        content = file_path.read_text(errors="ignore")
    except Exception as e:
        return DepAnalysis(
            language=language,
            dep_file_path=str(file_path),
            dep_file_format=fmt,
            parse_errors=[f"Failed to read file: {e}"],
        )

    parsers = {
        "maven_dep_tree": _parse_maven_dep_tree,
        "pom.xml": _parse_pom_xml,
        "requirements.txt": _parse_requirements_txt,
        "Pipfile": _parse_requirements_txt,
        "package.json": _parse_package_json,
        "Cargo.toml": _parse_cargo_toml,
        "build.gradle": _parse_gradle,
        "go.mod": _parse_go_mod,
        "composer.json": _parse_composer_json,
    }

    parser = parsers.get(fmt)
    if not parser:
        return DepAnalysis(
            language=language,
            dep_file_path=str(file_path),
            dep_file_format=fmt,
            parse_errors=[f"No parser for format: {fmt}"],
        )

    raw_deps = parser(content)

    analysis = DepAnalysis(
        language=language,
        dep_file_path=str(file_path),
        dep_file_format=fmt,
        total_count=len(raw_deps),
    )

    for name, version in raw_deps:
        entry = classify_dep(name, version, language)
        if entry.severity == "BLOCKER":
            analysis.blockers.append(entry)
        elif entry.severity == "VERIFY":
            analysis.verifies.append(entry)
        elif entry.severity == "DEGRADED":
            analysis.degradeds.append(entry)
        else:
            analysis.clears.append(entry)

    return analysis


def language_dep_instructions(language: str) -> str:
    """Language-specific instructions for obtaining a dep file."""
    instructions = {
        "java": "Run `mvn dependency:tree > deptree.txt` (Maven) or `gradle dependencies > deptree.txt` (Gradle).",
        "python": "Provide your `requirements.txt`, `Pipfile`, or `pyproject.toml`. Or capture installed: `pip freeze > requirements.txt`.",
        "node": "Provide your `package.json`. For full lockfile: `npm ls --all --json > deps.json`.",
        "rust": "Provide your `Cargo.toml`. For full graph: `cargo tree > deptree.txt`.",
        "go": "Provide your `go.mod`. For full graph: `go mod graph > deps.txt`.",
        "php": "Provide your `composer.json` or `composer.lock`.",
    }
    return instructions.get(language, "Provide your application's dependency manifest file.")
