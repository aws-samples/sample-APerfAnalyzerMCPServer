# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Parser for PMU (Performance Monitoring Unit) counter data.

This is the crown jewel for performance analysis — PMU counters reveal
CPU-level bottlenecks that are invisible to high-level metrics.

Key metrics aperf collects:
- Instructions Per Clock (IPC)
- Branch prediction miss rate
- Cache miss rates (L1, L2, L3, TLB)
- Frontend/Backend stalls
- Code sparsity (instruction locality)

**aperf does not publish raw PMU counters.** It reads raw events, divides them per its
architecture's `pmu_config.json`, and writes only the *derived* metrics — `ipc`, `branch-mpki`,
`stall-backend-pkc` and friends — as per-interval time series in `perf_stat.js`. There is no
`instructions` or `cycles` total anywhere in a report, in any aperf version. See
`src/pmu_configs/*.json` upstream for the definitions.
"""

from dataclasses import dataclass, field
from typing import Any

from ..thresholds import APERF_BRANCH_MPKI, FLOOR_DTLB_MPKI, FLOOR_ITLB_MPKI

#: The derived metric names aperf writes, mapped to the `PmuSummary` field that holds them.
#: Units are aperf's own: `mpki` is events per 1000 instructions, `pkc` is events per 1000 cycles
#: (per 1000 *issue slots* on Intel Ice Lake / Sapphire Rapids and AMD Genoa, whose configs divide
#: by `Slots` or scale by the slot width). Nothing here is a percentage.
_APERF_METRIC_FIELDS: dict[str, str] = {
    "ipc": "ipc",
    "branch-mpki": "branch_misses_per_1k_instructions",
    "inst-tlb-mpki": "itlb_misses_per_1k_instructions",
    "data-tlb-mpki": "dtlb_misses_per_1k_instructions",
    "inst-l1-mpki": "inst_l1_mpki",
    "data-l1-mpki": "data_l1_mpki",
    "l2-mpki": "l2_mpki",
    "l3-mpki": "l3_mpki",
    "inst-tlb-tw-pki": "inst_tlb_tw_pki",
    "data-tlb-tw-pki": "data_tlb_tw_pki",
    "stall-frontend-pkc": "stall_frontend_pkc",
    "stall-backend-pkc": "stall_backend_pkc",
    "code-sparsity": "code_sparsity",
    "mux_counter_schedule_rate": "counter_schedule_rate_pct",
}


@dataclass
class PmuSummary:
    """Summary of PMU counter data."""

    # Core efficiency
    ipc: float = 0.0  # Instructions Per Clock cycle
    cycles_per_instruction: float = 0.0

    # Branch prediction
    branch_misses_per_1k_instructions: float = 0.0
    branch_miss_rate_pct: float = 0.0

    # Cache hierarchy
    l1d_miss_rate_pct: float = 0.0
    l1i_miss_rate_pct: float = 0.0
    l2_miss_rate_pct: float = 0.0
    l3_miss_rate_pct: float = 0.0

    # TLB
    itlb_misses_per_1k_instructions: float = 0.0
    dtlb_misses_per_1k_instructions: float = 0.0

    # Pipeline
    frontend_stall_pct: float = 0.0
    backend_stall_pct: float = 0.0

    # Code locality
    code_sparsity: float = 0.0

    # Raw counters for comparison
    total_instructions: int = 0
    total_cycles: int = 0
    total_branches: int = 0
    total_branch_misses: int = 0

    # --- aperf's derived metrics, in aperf's units -------------------------------------------
    # The cache fields above are miss *rates* (misses / accesses), which aperf never publishes:
    # it publishes MPKI, misses per 1000 instructions, against a different denominator. These
    # hold the numbers aperf actually reports, so nothing has to be converted into a rate it
    # cannot be derived into.
    inst_l1_mpki: float = 0.0
    data_l1_mpki: float = 0.0
    l2_mpki: float = 0.0
    l3_mpki: float = 0.0
    inst_tlb_tw_pki: float = 0.0
    data_tlb_tw_pki: float = 0.0
    #: Stalls per 1000 cycles, aperf's native unit. `frontend_stall_pct`/`backend_stall_pct` are
    #: these divided by 10 — see `stall_denominator` for what the percentage is a percentage of.
    stall_frontend_pkc: float = 0.0
    stall_backend_pkc: float = 0.0
    #: What `stall_backend_pct` is a fraction of. Every shipped config divides the frontend term
    #: by `Cycles`, but the backend term is `Slots` on Intel Ice Lake and Sapphire Rapids and is
    #: slot-scaled on AMD Genoa, so a backend percentage is not always a percentage of cycles.
    stall_denominator: str = "cycles or issue slots (platform-dependent)"
    #: PMU counter multiplexing. Above ~0 the kernel is time-slicing the counter groups and every
    #: value here is extrapolated from a fraction of the interval, so small deltas are not real.
    counter_schedule_rate_pct: float = 0.0
    #: Which of aperf's metric names were present. Absent metrics read 0.0 on the fields above,
    #: and 0.0 is a legitimate measured value, so this is the only way to tell the two apart.
    metrics_available: list[str] = field(default_factory=list)


class PmuParser:
    """Parse and analyze PMU counter data."""

    def parse_from_report_data(self, data: dict[str, Any]) -> PmuSummary | None:
        """Parse PMU data from aperf report JSON structure.

        Supports three shapes, tried in this order:
        1. Report format: `data["perf_stat"][metric] = {"series": [...]}` — aperf's derived
           metrics as per-interval time series. What every real report contains.
        2. Flat-binary format: `data["perf_stat"][metric] = {"numerator": N, "denominator": D,
           "scale": S}` — one pre-reduced ratio per metric, from `get_flat_bin_report_data`.
        3. Raw counters: `data["perf_stat"]["counters"] = {metric: value}` — hand-built dicts
           and tests. aperf publishes no raw `instructions`/`cycles` in any version.
        """
        try:
            return self._parse_from_report_data(data)
        except (TypeError, AttributeError, ValueError, ZeroDivisionError, KeyError):
            # `data` is capture-derived, not something this process produced -- a malformed or
            # adversarial report must not raise into the calling tool handler, none of which wrap
            # this call in a try/except.
            return None

    def _parse_from_report_data(self, data: dict[str, Any]) -> PmuSummary | None:
        perf_stat = data.get("perf_stat", {})
        if not perf_stat:
            return None

        summary = PmuSummary()

        # Shape 1 — aperf's own layout: derived metrics as per-interval time series. Try this
        # first, since it is what every real report contains — the raw-counter branch below reads
        # names (`instructions`, `cycles`) that aperf publishes in no version, so before this every
        # PMU number came back 0.0 and `detect_bottlenecks` reported a critical `IPC = 0.00`
        # finding derived from data it had never read.
        if self._parse_derived_metrics(perf_stat, summary):
            return summary

        # Shape 2 — flat-binary: the same derived metrics, but already reduced to one
        # numerator/denominator pair per metric instead of a series, so `_parse_derived_metrics`
        # finds no `series` key and falls through to here.
        first_val = next(iter(perf_stat.values()), None)
        if isinstance(first_val, dict) and "numerator" in first_val:

            def _metric_val(name: str) -> float:
                entry = perf_stat.get(name)
                if not isinstance(entry, dict):
                    return 0.0
                numer = entry.get("numerator", 0)
                denom = entry.get("denominator", 0)
                scale = entry.get("scale", 1)
                return (numer / denom * scale) if denom > 0 else 0.0

            for metric_name, field_name in _APERF_METRIC_FIELDS.items():
                entry = perf_stat.get(metric_name)
                if not isinstance(entry, dict) or "numerator" not in entry:
                    continue
                summary.metrics_available.append(metric_name)
                setattr(summary, field_name, _metric_val(metric_name))

            if summary.ipc > 0:
                summary.cycles_per_instruction = 1.0 / summary.ipc
            # `pkc` is per 1000 cycles, so /10 is a percentage. Same conversion as the series path.
            summary.frontend_stall_pct = summary.stall_frontend_pkc / 10
            summary.backend_stall_pct = summary.stall_backend_pkc / 10
            # The cache/branch `*_rate_pct` fields are deliberately left at 0.0. A miss *rate* needs
            # accesses as the denominator and aperf publishes MPKI, which is per-instruction — the
            # `mpki / 10` this used to do produced a percentage of the wrong quantity. The real
            # values are on the `*_mpki` fields, set by the loop above.

            # `ipc` is instructions/cycles, so its own terms are the only raw totals available.
            ipc_entry = perf_stat.get("ipc")
            if isinstance(ipc_entry, dict):
                summary.total_instructions = ipc_entry.get("numerator", 0)
                summary.total_cycles = ipc_entry.get("denominator", 0)
            # `branch-mpki`'s denominator is instructions, not branches, so only the miss count is
            # recoverable here; `total_branches` stays 0 rather than being set to an instruction
            # count under a branch-count name.
            branch_entry = perf_stat.get("branch-mpki")
            if isinstance(branch_entry, dict):
                summary.total_branch_misses = branch_entry.get("numerator", 0)

            return summary

        # Shape 3 — raw counters

        counters = perf_stat.get("counters", {})

        instructions = counters.get("instructions", 0)
        cycles = counters.get("cycles", 0)
        branches = counters.get("branches", 0)
        branch_misses = counters.get("branch_misses", 0)

        summary.total_instructions = instructions
        summary.total_cycles = cycles
        summary.total_branches = branches
        summary.total_branch_misses = branch_misses

        # Derived metrics
        if cycles > 0:
            summary.ipc = instructions / cycles
            summary.cycles_per_instruction = cycles / instructions if instructions > 0 else 0

        if instructions > 0:
            summary.branch_misses_per_1k_instructions = (branch_misses / instructions) * 1000

        if branches > 0:
            summary.branch_miss_rate_pct = (branch_misses / branches) * 100

        # Cache metrics (if available)
        l1d_loads = counters.get("l1d_cache_loads", 0)
        l1d_misses = counters.get("l1d_cache_load_misses", 0)
        if l1d_loads > 0:
            summary.l1d_miss_rate_pct = (l1d_misses / l1d_loads) * 100

        # TLB metrics
        itlb_misses = counters.get("itlb_load_misses", 0)
        dtlb_misses = counters.get("dtlb_load_misses", 0)
        if instructions > 0:
            summary.itlb_misses_per_1k_instructions = (itlb_misses / instructions) * 1000
            summary.dtlb_misses_per_1k_instructions = (dtlb_misses / instructions) * 1000

        # Stall cycles
        frontend_stalls = counters.get("stalled_cycles_frontend", 0)
        backend_stalls = counters.get("stalled_cycles_backend", 0)
        if cycles > 0:
            summary.frontend_stall_pct = (frontend_stalls / cycles) * 100
            summary.backend_stall_pct = (backend_stalls / cycles) * 100

        return summary

    @staticmethod
    def _parse_derived_metrics(perf_stat: dict[str, Any], summary: PmuSummary) -> bool:
        """Fill `summary` from aperf's derived `perf_stat` metrics. False if there are none.

        `get_report_data` hands over aperf's own `metrics` mapping: metric name -> `{"series":
        [{"series_name": "Aggregate", "is_aggregate": true, "values": [...]}, {"series_name":
        "CPU0", ...}, ...]}`. The aggregate series is the per-interval whole-machine value, which
        is what a summary wants; the mean over intervals is the run-level number.

        Returning False rather than an empty summary matters: the caller then falls through to
        the raw-counter branch, so a hand-built `{"counters": {...}}` dict still parses.
        """
        found = False
        for metric_name, field_name in _APERF_METRIC_FIELDS.items():
            metric = perf_stat.get(metric_name)
            if not isinstance(metric, dict):
                continue
            values = PmuParser._aggregate_values(metric.get("series", []))
            if not values:
                continue
            summary.metrics_available.append(metric_name)
            setattr(summary, field_name, sum(values) / len(values))
            found = True

        if not found:
            return False

        if summary.ipc > 0:
            summary.cycles_per_instruction = 1 / summary.ipc
        # `pkc` is per 1000 cycles, so /10 converts to a percentage. Kept because callers and the
        # `detect_bottlenecks` thresholds are written in percent; `stall_*_pkc` holds the original.
        summary.frontend_stall_pct = summary.stall_frontend_pkc / 10
        summary.backend_stall_pct = summary.stall_backend_pkc / 10
        # `branch-mpki` is misses per 1000 instructions; a miss *rate* needs a branch count as the
        # denominator and aperf publishes none, so `branch_miss_rate_pct` stays 0.0 rather than
        # being filled with a number against the wrong denominator. Same for the cache rates: the
        # MPKI values live on the `*_mpki` fields instead.
        return True

    @staticmethod
    def _aggregate_values(series_list: list[Any]) -> list[Any]:
        """Values of the whole-machine series, falling back to the mean across per-CPU series.

        Every released aperf marks one series `is_aggregate`, but a config that collects only
        specific CPUs does not, and averaging the per-CPU series is the right reduction for every
        metric here (all of them are ratios, so a mean of per-CPU ratios is the machine ratio to
        within the per-CPU instruction-count weighting).
        """
        for s in series_list:
            if s.get("is_aggregate") and s.get("values"):
                aggregate: list[Any] = s["values"]
                return aggregate
        for s in series_list:
            if s.get("series_name") == "Aggregate" and s.get("values"):
                named: list[Any] = s["values"]
                return named
        per_cpu = [s["values"] for s in series_list if s.get("values")]
        if not per_cpu:
            return []
        width = min(len(v) for v in per_cpu)
        return [sum(v[i] for v in per_cpu) / len(per_cpu) for i in range(width)]

    def detect_bottlenecks(self, summary: PmuSummary) -> list[dict[str, Any]]:
        """
        Detect CPU-level performance bottlenecks from PMU data.

        Returns a list of findings with severity, category, and recommendations.
        """
        findings = []

        # An unset field reads 0.0, which every threshold below is satisfied by from the low side:
        # a summary with no IPC at all reported `critical: IPC = 0.00`, a bottleneck invented from
        # a missing measurement. `metrics_available` distinguishes "measured 0" from "not
        # measured", and it is only populated by the derived-metric path, so a raw-counter summary
        # (tests, and any pre-1.2 layout) is gated on the counters instead.
        measured = set(summary.metrics_available)
        has_derived = bool(measured)
        raw_cycles = summary.total_cycles > 0

        def measured_metric(aperf_name: str) -> bool:
            """Whether this metric came from data, rather than defaulting to 0.0."""
            if has_derived:
                return aperf_name in measured
            return raw_cycles

        # Multiplexing makes every value an extrapolation from part of the interval. aperf has its
        # own finding for this; the point here is not to raise thresholds against thin evidence.
        if summary.counter_schedule_rate_pct > 0:
            findings.append(
                {
                    "severity": "info",
                    "category": "measurement_quality",
                    "anchor_rules": ["PMU Counter Collection Multiplexing"],
                    "metric": f"Counter multiplexing = {summary.counter_schedule_rate_pct:.1f}%",
                    "description": (
                        "PMU counter groups were time-sliced, so every metric below is extrapolated "
                        "from a fraction of each interval. Small deltas are not necessarily real."
                    ),
                    "recommendations": [
                        "Collect fewer events per run to fit the available counters",
                        "Treat differences under roughly the multiplexing rate as noise",
                    ],
                }
            )

        # IPC analysis. This is the only check below that fires from the *low* side, so it is the
        # only one an unmeasured 0.0 can trigger; the rest all require a value above a threshold.
        #
        # `anchor_rules` is EMPTY for both IPC findings, deliberately: aperf has no IPC rule
        # (verified against FINDINGS_REGISTRY.json, 51 rules). An empty list means the
        # consumer's anchor gate drops it, so low IPC is never reported as a finding. It is
        # also redundant — low IPC is a *symptom* of the stall and cache findings that are
        # anchored, so the reader still learns about the underlying cause.
        ipc_measured = measured_metric("ipc")
        if ipc_measured and summary.ipc < 0.5:
            findings.append(
                {
                    "severity": "critical",
                    "category": "cpu_efficiency",
                    "anchor_rules": [],
                    "metric": f"IPC = {summary.ipc:.2f}",
                    "description": "Very low IPC indicates severe pipeline inefficiency",
                    "recommendations": [
                        "Check for memory-bound workload (high cache miss rates)",
                        "Look for branch misprediction penalties",
                        "Consider if workload is latency-bound on DRAM access",
                    ],
                }
            )
        elif ipc_measured and summary.ipc < 1.0:
            findings.append(
                {
                    "severity": "warning",
                    "category": "cpu_efficiency",
                    "anchor_rules": [],
                    "metric": f"IPC = {summary.ipc:.2f}",
                    "description": "Below-optimal IPC — room for improvement",
                    "recommendations": [
                        "Profile hot functions for optimization opportunities",
                        "Check compiler optimization flags",
                    ],
                }
            )

        # Branch prediction
        if summary.branch_misses_per_1k_instructions >= APERF_BRANCH_MPKI:
            findings.append(
                {
                    "severity": "critical",
                    "category": "branch_prediction",
                    "anchor_rules": ["High Branch Mispredictions"],
                    "metric": f"Branch misses = {summary.branch_misses_per_1k_instructions:.1f}/1K insns",
                    "description": "High branch misprediction causing pipeline flushes",
                    "recommendations": [
                        "For JVM: size the code cache (-XX:ReservedCodeCacheSize) — an "
                        "undersized cache retrains the predictor on every recompile",
                        "For JVM: -XX:+UseTransparentHugePages for code locality (LINUX ONLY — "
                        "a non-Linux JVM refuses to start with this flag)",
                        "For native: use PGO (Profile-Guided Optimization)",
                        "Consider separating hot/cold code paths",
                        "Check for polymorphic dispatch (virtual calls)",
                    ],
                }
            )
        elif summary.branch_misses_per_1k_instructions > APERF_BRANCH_MPKI / 2:
            findings.append(
                {
                    "severity": "warning",
                    "category": "branch_prediction",
                    "anchor_rules": ["High Branch Mispredictions"],
                    "metric": f"Branch misses = {summary.branch_misses_per_1k_instructions:.1f}/1K insns",
                    "description": "Moderate branch misprediction overhead",
                    "recommendations": [
                        "Profile branch-heavy code paths",
                        "Consider branch-free algorithms where possible",
                    ],
                }
            )

        # TLB analysis
        if summary.itlb_misses_per_1k_instructions >= FLOOR_ITLB_MPKI:
            findings.append(
                {
                    "severity": "critical",
                    "category": "memory_translation",
                    "anchor_rules": ["Instruction TLB Misses", "Instruction TLB Table Walks"],
                    "metric": f"ITLB misses = {summary.itlb_misses_per_1k_instructions:.1f}/1K insns",
                    "description": "High instruction TLB misses — code footprint exceeds TLB coverage",
                    "recommendations": [
                        "Enable Transparent Huge Pages (-XX:+UseTransparentHugePages for JVM)",
                        "For native: link with -Wl,-z,max-page-size=2097152",
                        "Reduce code size with LTO (Link-Time Optimization)",
                    ],
                }
            )

        if summary.dtlb_misses_per_1k_instructions >= FLOOR_DTLB_MPKI:
            findings.append(
                {
                    "severity": "warning",
                    "category": "memory_translation",
                    "anchor_rules": ["Data TLB Misses", "Data TLB Table Walks"],
                    "metric": f"DTLB misses = {summary.dtlb_misses_per_1k_instructions:.1f}/1K insns",
                    "description": "High data TLB misses — data footprint exceeds TLB coverage",
                    "recommendations": [
                        "Use huge pages for large data allocations",
                        "Improve data locality (struct packing, cache-aware allocation)",
                    ],
                }
            )

        # Frontend stalls
        if summary.frontend_stall_pct > 30:
            findings.append(
                {
                    "severity": "critical",
                    "category": "pipeline_frontend",
                    "anchor_rules": [
                        "Frontend-Dominated CPU Stalls",
                        "High L1 Instruction Cache Misses",
                        "High Code Sparsity",
                    ],
                    "metric": f"Frontend stalls = {summary.frontend_stall_pct:.1f}%",
                    "description": "CPU frontend starved — instruction fetch bottleneck",
                    "recommendations": [
                        "Likely caused by I-cache misses or ITLB misses",
                        "Improve code locality and reduce code footprint",
                        "For JVM: aggressive inlining may hurt; reduce method count",
                    ],
                }
            )

        # Backend stalls
        if summary.backend_stall_pct > 40:
            findings.append(
                {
                    "severity": "critical",
                    "category": "pipeline_backend",
                    "anchor_rules": [
                        "Backend-Dominated CPU Stalls",
                        "High L1 Data Cache Misses",
                        "High L2 Cache Misses",
                        "High L3 Cache Misses",
                    ],
                    "metric": f"Backend stalls = {summary.backend_stall_pct:.1f}% of "
                    f"{summary.stall_denominator}",
                    "description": "CPU backend stalled — execution units waiting for data",
                    "recommendations": [
                        "Likely memory-bound: check cache miss rates",
                        "Improve data locality and access patterns",
                        "Consider prefetching for predictable access patterns",
                        "For JVM: check for false sharing with @Contended",
                    ],
                }
            )

        return findings

    def compare(self, baseline: PmuSummary, candidate: PmuSummary) -> dict[str, Any]:
        """Compare two PMU summaries and produce a delta report.

        A metric absent from either run is reported `"available": False` rather than as a
        0.0-to-0.0 comparison. Callers turn `improved`/`change_pct` into verdicts, and unmeasured
        metrics used to read as `improved: false, change_pct: null` — indistinguishable from a
        measured no-change, which is how `compare_runs` came to report `NO_SIGNIFICANT_CHANGE` for
        two runs whose PMU data it had not read at all.
        """

        def pct_change(old: float, new: float) -> float | None:
            if old == 0:
                return None
            return ((new - old) / old) * 100

        # `metrics_available` is only populated by the derived-metric path. Without it — a
        # raw-counter or hand-built summary — availability is unknown, so fall back to the value
        # itself: 0.0 in both runs is either unmeasured or measured-zero, and both mean there is
        # nothing to compare.
        def available(aperf_name: str, old: float, new: float) -> bool:
            if not baseline.metrics_available and not candidate.metrics_available:
                return old != 0 or new != 0
            return (
                aperf_name in baseline.metrics_available
                and aperf_name in candidate.metrics_available
            )

        def delta(aperf_name: str, field_name: str, lower_is_better: bool) -> dict[str, Any]:
            old = getattr(baseline, field_name)
            new = getattr(candidate, field_name)
            if not available(aperf_name, old, new):
                return {
                    "available": False,
                    "reason": f"`{aperf_name}` is missing from at least one run — the PMU event "
                    "it derives from is not in this platform's pmu_config, or counter "
                    "multiplexing dropped it.",
                }
            return {
                "available": True,
                "baseline": old,
                "candidate": new,
                "change_pct": pct_change(old, new),
                "improved": (new < old) if lower_is_better else (new > old),
            }

        result = {
            "ipc": delta("ipc", "ipc", lower_is_better=False),
            "branch_misses_per_1k": delta(
                "branch-mpki", "branch_misses_per_1k_instructions", lower_is_better=True
            ),
            "itlb_misses_per_1k": delta(
                "inst-tlb-mpki", "itlb_misses_per_1k_instructions", lower_is_better=True
            ),
            "dtlb_misses_per_1k": delta(
                "data-tlb-mpki", "dtlb_misses_per_1k_instructions", lower_is_better=True
            ),
            "inst_l1_mpki": delta("inst-l1-mpki", "inst_l1_mpki", lower_is_better=True),
            "data_l1_mpki": delta("data-l1-mpki", "data_l1_mpki", lower_is_better=True),
            "l2_mpki": delta("l2-mpki", "l2_mpki", lower_is_better=True),
            "l3_mpki": delta("l3-mpki", "l3_mpki", lower_is_better=True),
            "frontend_stalls_pct": delta(
                "stall-frontend-pkc", "frontend_stall_pct", lower_is_better=True
            ),
            "backend_stalls_pct": delta(
                "stall-backend-pkc", "backend_stall_pct", lower_is_better=True
            ),
        }
        # Multiplexing is measurement quality, not a metric to call improved or regressed.
        if "mux_counter_schedule_rate" in baseline.metrics_available:
            result["counter_multiplexing_pct"] = {
                "available": True,
                "baseline": baseline.counter_schedule_rate_pct,
                "candidate": candidate.counter_schedule_rate_pct,
                "note": "Measurement quality, not performance. Above 0 the counters were "
                "time-sliced and every delta above is extrapolated.",
            }
        return result
