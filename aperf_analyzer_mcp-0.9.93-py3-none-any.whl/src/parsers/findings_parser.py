# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Parse aperf's own analytical findings out of a generated report.

aperf runs 51 curated rules over the collected data at `aperf report` time and serializes the
results into the report's JS bundle. Those findings are *aperf's* verdicts, produced by the
same Rust code that collected the data — they are not something this MCP server infers. This
module reads them back out verbatim and joins each one to the prescriptive playbook that
`resources/findings/` holds for it.

Where the findings live
-----------------------
Every `<report>/data/js/<data_type>.js` file carries two top-level assignments::

    processed_<data_type>_data = { ... }
    <data_type>_findings       = { ... }

and the findings object is always shaped (`src/analytics/mod.rs:100`-`:131`)::

    {"per_run_findings": {"<run>": {"findings": {"<data_key>": [
        {"rule_name", "score", "description", "message"}]}}}}

The inner key is the **data key** — a metric name, a key-value key, or a profiler key — *not*
the rule name. `rule_name`, one level down, is the join key into
`resources/findings/FINDINGS_REGISTRY.json`.

All 21 data files define a `<data_type>_findings` variable even when nothing fired, so an empty
`per_run_findings` is a real "no findings for this data type", not a missing file.

What this module deliberately does not do
-----------------------------------------
* **It does not compute findings.** Anything not in aperf's serialized output is not a finding
  as far as this parser is concerned.
* **It does not rank by severity.** `score` is unbounded for the five amplifying templates and
  flat for the other six, so `abs(score)` is not a severity order — see GUIDANCE_MODEL.md §2.
  Priority comes from the playbooks.
* **It does not see statistical findings.** aperf's other findings engine runs in the browser
  (`src/report_frontend/src/utils/analytics.tsx`) and serializes nothing, so 752 of 802 metrics
  have no analytical rule and no serialized verdict. `FindingsReport.statistical` says so
  explicitly, because a report with zero analytical findings is not a clean report.

Unknown rules fail loudly
-------------------------
A `rule_name` absent from the registry means the checkout that produced the report is newer
than the pinned one (aperf 1.3.0 / adf0970). The finding is kept with its registry fields
unset, recorded in `FindingsReport.unknown_rules`, and logged at WARNING. Same for a
`description` no template pattern matches. Either one means
`resources/findings/tools/check_drift.py` needs to run against the newer checkout.
"""

from __future__ import annotations

import importlib.util
import json
import logging
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .run_parser import _MAX_JSON_FILE_BYTES, AperfRunParser, _read_text_capped

logger = logging.getLogger(__name__)

#: The prescriptive findings tree: registry, playbooks, and the description parser.
FINDINGS_DIR = Path(__file__).resolve().parent.parent.parent / "resources" / "findings"

REGISTRY_PATH = FINDINGS_DIR / "FINDINGS_REGISTRY.json"

#: `aperf_desc.py` is loaded from the tree rather than vendored here. It is a faithful port of
#: aperf's Rust formatters, differentially fuzz-tested against the original by
#: `tools/test_aperf_desc.py`, and every playbook's `## Reading the description` section is
#: prose for what it does mechanically. A second copy would drift from all three.
_DESC_PATH = FINDINGS_DIR / "tools" / "aperf_desc.py"


def _load_aperf_desc() -> Any:
    """Import `resources/findings/tools/aperf_desc.py` without putting `tools/` on the path.

    The tools directory is a flat pile of stdlib-only scripts, not a package; `sys.path`
    inserting it would expose a dozen `test_*.py` and `check_*.py` names as importable
    top-level modules.
    """
    name = "aperf_findings_desc"
    existing = sys.modules.get(name)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(name, _DESC_PATH)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load the description parser from {_DESC_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


@dataclass
class Registry:
    """`FINDINGS_REGISTRY.json`, indexed by the join key.

    `by_rule_name` is keyed on the exact `rule_name` string. SCHEMA.md rule 1 makes that a
    byte-for-byte match on purpose: normalizing case or whitespace here would let a genuine
    upstream rename resolve to the wrong playbook instead of showing up as unknown.
    """

    aperf_version: str
    aperf_commit: str
    total_findings: int
    by_rule_name: dict[str, dict[str, Any]]
    statistical: dict[str, Any]
    data_types_without_rules: list[str]

    @classmethod
    def load(cls, path: Path | None = None) -> Registry:
        raw = json.loads((path or REGISTRY_PATH).read_text())
        return cls(
            aperf_version=raw["aperf_version"],
            aperf_commit=raw["aperf_commit"],
            total_findings=raw["total_findings"],
            by_rule_name={entry["rule_name"]: entry for entry in raw["findings"]},
            statistical=raw["statistical_findings"],
            data_types_without_rules=raw["data_types_without_rules"],
        )


_REGISTRY: Registry | None = None


def get_registry() -> Registry:
    """Process-wide registry, loaded once. 51 entries, ~50 KB."""
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = Registry.load()
    return _REGISTRY


# ---------------------------------------------------------------------------
# Findings
# ---------------------------------------------------------------------------


@dataclass
class Finding:
    """One serialized analytical finding, joined to its playbook.

    The first six fields are verbatim aperf output. Everything after `run_name` is recovered
    from the registry or derived, and is `None`/empty when the rule is unknown.
    """

    # --- verbatim from aperf ---
    rule_name: str
    score: float
    description: str
    message: str
    #: Which `<data_type>_findings` variable carried it, e.g. `perf_stat`.
    data_type: str
    #: The `per_run_findings.<run>.findings` key: a metric, key-value key, or profiler key.
    data_key: str
    run_name: str

    # --- joined from FINDINGS_REGISTRY.json ---
    slug: str | None = None
    playbook: str | None = None
    template: str | None = None
    condition: str | None = None
    base_score: str | None = None
    base_score_value: int | None = None
    score_sign: str | None = None
    requires_comparison: bool | None = None
    aperf_message: str | None = None
    source: str | None = None
    #: `architectures` / `architecture_note` where the registry records them (15 and 7 rules).
    architectures: list[str] = field(default_factory=list)
    architecture_note: str | None = None

    # --- derived ---
    #: `aperf_desc.ParsedDescription`, or None when parsing failed.
    parsed: Any = None
    #: Why parsing failed, when it did. A format string changed upstream.
    parse_error: str | None = None
    #: True when no registry entry matched `rule_name`.
    unknown_rule: bool = False
    #: True when `requires_comparison` is set yet the report holds a single run. Not an error:
    #: `JVM Version Comparison` does exactly this, and its `message` then falsely claims a
    #: cross-run difference. SCHEMA.md rule 5; `java_profile/jvm-version-comparison.md` STEP 0.
    fired_without_comparison: bool = False

    @property
    def observed(self) -> dict[str, Any]:
        """The parsed description fields, or `{}` when the description did not parse.

        A decision tree must branch only on keys this dict actually carries — an absent key is
        absent because the template never emitted it.
        """
        return dict(self.parsed.fields) if self.parsed is not None else {}

    @property
    def score_is_flat(self) -> bool:
        """True when the template inserts the raw `Score`, so the magnitude means nothing.

        Six of the eleven templates do not call `compute_finding_score`
        (`src/analytics/mod.rs:167`), so their score is always exactly the base score. Unknown
        rules report False, because the template is unknown too.
        """
        if self.template is None:
            return False
        desc = _load_aperf_desc()
        return self.template not in desc.AMPLIFYING_TEMPLATES

    def playbook_path(self) -> Path | None:
        """Absolute path to this finding's playbook, when it has one that exists."""
        if self.playbook is None:
            return None
        path = FINDINGS_DIR / self.playbook
        return path if path.is_file() else None

    def to_dict(self) -> dict[str, Any]:
        """JSON-serializable form. `parsed` is flattened to `observed`."""
        out = {
            "rule_name": self.rule_name,
            "score": self.score,
            "description": self.description,
            "message": self.message,
            "data_type": self.data_type,
            "data_key": self.data_key,
            "run_name": self.run_name,
            "slug": self.slug,
            "playbook": self.playbook,
            "template": self.template,
            "condition": self.condition,
            "base_score": self.base_score,
            "base_score_value": self.base_score_value,
            "score_sign": self.score_sign,
            "requires_comparison": self.requires_comparison,
            "source": self.source,
            "score_is_flat": self.score_is_flat,
            "observed": self.observed,
            "description_form": self.parsed.form if self.parsed is not None else None,
        }
        if self.architectures:
            out["architectures"] = self.architectures
        if self.architecture_note:
            out["architecture_note"] = self.architecture_note
        if self.parse_error:
            out["parse_error"] = self.parse_error
        if self.unknown_rule:
            out["unknown_rule"] = True
        if self.fired_without_comparison:
            out["fired_without_comparison"] = True
        return out


@dataclass
class StatisticalNote:
    """Why a report can hold zero analytical findings and still not be clean.

    aperf's second findings engine compares every metric's 8 stats against the base run *in
    the browser* and serializes nothing, so this parser cannot see those findings at all. The
    fields here come from the registry rather than being restated, so they cannot drift from
    what `statistical/README.md` documents.
    """

    #: False, always: nothing about statistical findings is in the report data.
    serialized: bool
    #: True only with >= 2 runs; the engine is a comparison against the base run.
    available_for_this_report: bool
    engine_source: str
    playbook: str
    note: str
    #: Time-series data types that have no analytical rule at all, so statistical findings are
    #: the *only* signal available for them.
    rule_less_data_types: list[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "serialized": self.serialized,
            "available_for_this_report": self.available_for_this_report,
            "engine_source": self.engine_source,
            "playbook": self.playbook,
            "note": self.note,
            "rule_less_data_types": self.rule_less_data_types,
        }


@dataclass
class FindingsReport:
    """Everything the analytical findings of one report directory say.

    `findings` is in a stable order — data type, then data key, then rule name — so two reads
    of the same report produce the same list. It is deliberately *not* score-ordered: see the
    module docstring.
    """

    report_path: Path
    #: Run names in report order. The first is aperf's base run, which every comparison
    #: template measures against (`src/report.rs:454`).
    runs: list[str]
    findings: list[Finding]
    statistical: StatisticalNote
    #: `version.js` — the aperf that generated the report, which need not be the pinned one.
    aperf_version: str | None = None
    aperf_git_sha: str | None = None
    registry_version: str = ""
    registry_commit: str = ""
    #: `<data_type>_findings` variables read, including the ones that held nothing.
    data_types_scanned: list[str] = field(default_factory=list)
    #: Rule names with no registry entry. Non-empty means a newer aperf; run check_drift.py.
    unknown_rules: list[str] = field(default_factory=list)
    #: `(rule_name, description)` pairs no template pattern matched. Same conclusion.
    parse_failures: list[tuple[Any, ...]] = field(default_factory=list)
    #: Flat-template findings whose score is not the base score. Also a drift signal.
    score_anomalies: list[str] = field(default_factory=list)

    @property
    def base_run(self) -> str | None:
        return self.runs[0] if self.runs else None

    @property
    def is_comparison(self) -> bool:
        return len(self.runs) > 1

    @property
    def registry_matches_report(self) -> bool:
        """Whether the playbooks were written against the aperf that made this report.

        False is common and usually harmless — the tree pins one commit while reports come from
        whatever aperf the user has. It only matters when combined with an unknown rule or a
        parse failure, which is when the mismatch stops being cosmetic.
        """
        return self.aperf_version == self.registry_version

    @property
    def has_drift_signals(self) -> bool:
        """Whether anything in this report suggests the tree no longer describes aperf."""
        return bool(self.unknown_rules or self.parse_failures or self.score_anomalies)

    def for_run(self, run_name: str) -> list[Finding]:
        return [f for f in self.findings if f.run_name == run_name]

    def for_data_type(self, data_type: str) -> list[Finding]:
        return [f for f in self.findings if f.data_type == data_type]

    def by_rule_name(self, rule_name: str) -> list[Finding]:
        """Every occurrence of one rule. A rule can fire once per run and per data key."""
        return [f for f in self.findings if f.rule_name == rule_name]

    def by_absolute_score(self) -> list[Finding]:
        """Findings ordered by `abs(score)`, descending.

        **This is not a severity order.** The five amplifying templates scale the base score by
        threshold exceedance, so `Underutilized CPU` at 89% idle scores −455 while the flat
        `Kernel Version Mismatch` — a P0 blocking gate — scores exactly −256 forever. Use it to
        surface the loudest *deviations*, never to decide what to act on first.
        """
        return sorted(self.findings, key=lambda f: abs(f.score), reverse=True)

    def to_dict(self) -> dict[str, Any]:
        return {
            "report_path": str(self.report_path),
            "runs": self.runs,
            "base_run": self.base_run,
            "is_comparison": self.is_comparison,
            "aperf_version": self.aperf_version,
            "aperf_git_sha": self.aperf_git_sha,
            "registry_version": self.registry_version,
            "registry_commit": self.registry_commit,
            "registry_matches_report": self.registry_matches_report,
            "data_types_scanned": self.data_types_scanned,
            "total_findings": len(self.findings),
            "findings": [f.to_dict() for f in self.findings],
            "statistical": self.statistical.to_dict(),
            "unknown_rules": self.unknown_rules,
            "parse_failures": [{"rule_name": r, "description": d} for r, d in self.parse_failures],
            "score_anomalies": self.score_anomalies,
            "has_drift_signals": self.has_drift_signals,
        }


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

#: Trailing `_findings` marks a findings variable; the stem is the data type.
_FINDINGS_SUFFIX = "_findings"

#: `runs.js` assigns an ARRAY, so the `name = {` scan in `run_parser` never sees it.
_RUNS_ARRAY = re.compile(r"runs_raw\s*=\s*(\[)")


class FindingsParseError(RuntimeError):
    """The path is not a readable aperf report. Distinct from "the report has no findings"."""


class AperfFindingsParser:
    """Read the analytical findings of a report directory and join them to the playbooks.

    Stateless apart from the registry, so one instance can read many reports.
    """

    def __init__(self, registry: Registry | None = None) -> None:
        self.registry = registry or get_registry()

    # -- location ----------------------------------------------------------

    @staticmethod
    def resolve_js_dir(path: Path) -> Path:
        """Find the `data/js` directory for `path`, accepting the usual ways of naming it.

        A caller may hold the report directory, the `data` directory, or `data/js` itself
        (which is what shows up when someone unpacks only the part they need).
        """
        path = Path(path)
        for candidate in (path / "data" / "js", path / "js", path):
            if candidate.is_dir() and any(candidate.glob("*.js")):
                return candidate
        raise FindingsParseError(
            f"no aperf report JS data under {path} — expected {path}/data/js/*.js. "
            "Findings are only written by `aperf report`; a raw record directory has none."
        )

    @staticmethod
    def is_report_dir(path: Path) -> bool:
        try:
            AperfFindingsParser.resolve_js_dir(Path(path))
        except FindingsParseError:
            return False
        return True

    # -- parsing -----------------------------------------------------------

    def parse_report(self, report_path: Path) -> FindingsReport:
        """Parse every `<data_type>_findings` variable under `report_path`.

        Raises `FindingsParseError` only when the path is not a report at all. A report whose
        rules all stayed quiet returns a `FindingsReport` with an empty `findings` list, which
        is a different thing and must be reported differently — read `statistical` before
        calling such a report clean.
        """
        report_path = Path(report_path)
        js_dir = self.resolve_js_dir(report_path)

        runs = self._read_runs(js_dir)
        version, git_sha = self._read_version(js_dir)

        findings: list[Finding] = []
        scanned: list[str] = []
        unknown: list[str] = []
        parse_failures: list[tuple[Any, ...]] = []
        anomalies: list[str] = []

        for js_file in sorted(js_dir.glob("*.js")):
            # Capture data is untrusted: same per-file cap run_parser applies, so one oversized
            # .js file cannot exhaust memory. Skipped files are reported, not silently dropped.
            text = _read_text_capped(js_file)
            if text is None:
                anomalies.append(
                    f"{js_file.name}: skipped, larger than the "
                    f"{_MAX_JSON_FILE_BYTES // (1024 * 1024)} MB per-file limit"
                )
                continue
            variables = AperfRunParser._parse_all_js_vars(text)
            for name, payload in variables.items():
                if not name.endswith(_FINDINGS_SUFFIX):
                    continue
                data_type = name[: -len(_FINDINGS_SUFFIX)]
                scanned.append(data_type)
                findings.extend(
                    self._findings_from_payload(
                        data_type, payload, runs, unknown, parse_failures, anomalies
                    )
                )

        if not scanned:
            raise FindingsParseError(
                f"{js_dir} holds no *_findings variables. Every aperf report writes one per "
                "data type, so this is a truncated or non-aperf report rather than a quiet one."
            )

        findings.sort(key=lambda f: (f.data_type, f.data_key, f.rule_name, f.run_name))

        for rule_name in sorted(set(unknown)):
            logger.warning(
                "aperf reported rule %r, which is not in FINDINGS_REGISTRY.json (aperf %s / %s). "
                "The report was generated by aperf %s. Run resources/findings/tools/check_drift.py "
                "against that checkout.",
                rule_name,
                self.registry.aperf_version,
                self.registry.aperf_commit,
                version or "unknown",
            )
        for rule_name, description in parse_failures:
            logger.warning(
                "rule %r emitted a description no template pattern matches: %r. aperf changed a "
                "format string; resources/findings/tools/aperf_desc.py needs updating.",
                rule_name,
                description,
            )
        for anomaly in anomalies:
            logger.warning("score anomaly: %s", anomaly)

        return FindingsReport(
            report_path=report_path,
            runs=runs,
            findings=findings,
            statistical=self._statistical_note(len(runs)),
            aperf_version=version,
            aperf_git_sha=git_sha,
            registry_version=self.registry.aperf_version,
            registry_commit=self.registry.aperf_commit,
            data_types_scanned=sorted(set(scanned)),
            unknown_rules=sorted(set(unknown)),
            parse_failures=parse_failures,
            score_anomalies=anomalies,
        )

    def _findings_from_payload(
        self,
        data_type: str,
        payload: dict[str, Any],
        runs: list[str],
        unknown: list[str],
        parse_failures: list[tuple[Any, ...]],
        anomalies: list[str],
    ) -> list[Finding]:
        """Walk one `<data_type>_findings` object into `Finding` objects."""
        out: list[Finding] = []
        per_run = payload.get("per_run_findings")
        if not isinstance(per_run, dict):
            return out
        for run_name, run_block in per_run.items():
            by_key = (run_block or {}).get("findings")
            if not isinstance(by_key, dict):
                continue
            for data_key, entries in by_key.items():
                for entry in entries or []:
                    finding = self._build(data_type, data_key, run_name, entry, len(runs))
                    if finding.unknown_rule:
                        unknown.append(finding.rule_name)
                    if finding.parse_error:
                        parse_failures.append((finding.rule_name, finding.description))
                    anomaly = self._score_anomaly(finding)
                    if anomaly:
                        anomalies.append(anomaly)
                    out.append(finding)
        return out

    def _build(
        self, data_type: str, data_key: str, run_name: str, entry: dict[str, Any], run_count: int
    ) -> Finding:
        rule_name = entry.get("rule_name", "")
        finding = Finding(
            rule_name=rule_name,
            score=float(entry.get("score", 0.0)),
            description=entry.get("description", ""),
            message=entry.get("message", ""),
            data_type=data_type,
            data_key=data_key,
            run_name=run_name,
        )

        registry_entry = self.registry.by_rule_name.get(rule_name)
        if registry_entry is None:
            finding.unknown_rule = True
        else:
            finding.slug = registry_entry["slug"]
            finding.playbook = registry_entry["playbook"]
            finding.template = registry_entry["template"]
            finding.condition = registry_entry["condition"]
            finding.base_score = registry_entry["base_score"]
            finding.base_score_value = registry_entry["base_score_value"]
            finding.score_sign = registry_entry["score_sign"]
            finding.requires_comparison = registry_entry["requires_comparison"]
            finding.aperf_message = registry_entry["aperf_message"]
            finding.source = registry_entry["source"]
            finding.architectures = list(registry_entry.get("architectures") or [])
            finding.architecture_note = registry_entry.get("architecture_note")
            finding.fired_without_comparison = bool(
                registry_entry["requires_comparison"] and run_count < 2
            )

        # The template is what disambiguates run_comparison from intra_run_comparison: the two
        # emit byte-identical descriptions and differ only in whether the two names are runs or
        # metrics. Without it, every intra-run finding would read as a cross-run one.
        desc = _load_aperf_desc()
        try:
            finding.parsed = desc.parse_description(finding.description, finding.template)
        except ValueError as exc:
            finding.parse_error = str(exc)

        return finding

    @staticmethod
    def _score_anomaly(finding: Finding) -> str | None:
        """Flat-template scores must equal the base score exactly.

        The six non-amplifying templates insert `Score::X as f64` and never scale it, so a
        mismatch is not a louder finding — it means the template started amplifying, or the
        `Score` enum was rescaled, and the registry's `base_score_value` is stale.
        """
        if finding.unknown_rule or finding.base_score_value is None:
            return None
        if not finding.score_is_flat:
            return None
        if finding.score == float(finding.base_score_value):
            return None
        return (
            f"{finding.rule_name}: template {finding.template} does not scale its score, so it "
            f"should be exactly {finding.base_score_value} ({finding.base_score}), but aperf "
            f"emitted {finding.score}"
        )

    def _statistical_note(self, run_count: int) -> StatisticalNote:
        stat = self.registry.statistical
        return StatisticalNote(
            serialized=bool(stat.get("serialized", False)),
            available_for_this_report=run_count >= 2,
            engine_source=stat["source"],
            playbook=stat["playbook"],
            note=(
                "aperf's statistical findings are computed in the report frontend and are NOT "
                "serialized, so this parser cannot see them. "
                + str(stat["note"])
                + " They exist only for a comparison report (>= 2 runs). Absence of analytical "
                "findings therefore does not mean the report is clean."
            ),
            rule_less_data_types=list(stat.get("rule_less_time_series_data_types") or []),
        )

    # -- small readers -----------------------------------------------------

    @staticmethod
    def _read_runs(js_dir: Path) -> list[str]:
        """Run names in report order, from `runs.js`.

        Order matters: `src/report.rs:454` makes the first run the base run, and every
        comparison template measures against it. `runs_raw` is a JSON *array*, which the
        `name = {`-anchored scan in `run_parser` cannot see, hence the separate read.
        """
        runs_js = js_dir / "runs.js"
        if not runs_js.is_file():
            return []
        content = _read_text_capped(runs_js)
        if content is None:
            return []
        match = _RUNS_ARRAY.search(content)
        if match is None:
            return []
        try:
            payload, _ = json.JSONDecoder().raw_decode(content, match.start(1))
        except json.JSONDecodeError:
            return []
        return [r["name"] for r in payload if isinstance(r, dict) and "name" in r]

    @staticmethod
    def _read_version(js_dir: Path) -> tuple[Any, ...]:
        """`(version, git_sha)` of the aperf that generated the report, from `version.js`."""
        version_js = js_dir / "version.js"
        if not version_js.is_file():
            return None, None
        text = _read_text_capped(version_js)
        if text is None:
            return None, None
        parsed = AperfRunParser._parse_all_js_vars(text).get("version_info")
        if not isinstance(parsed, dict):
            return None, None
        return parsed.get("version"), parsed.get("git_sha")


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------


def parse_findings(report_path: Path) -> FindingsReport:
    """Parse one report's analytical findings with the shared registry."""
    return AperfFindingsParser().parse_report(Path(report_path))


def find_report_dirs(base_dir: Path) -> list[Path]:
    """Report directories at or directly under `base_dir`, in name order.

    `aperf report` writes `<name>_report/` beside the run directory by default, but the name is
    the user's to choose, so this tests for the JS bundle rather than the suffix.

    When `base_dir` is itself a report, that is the whole answer: its only report-shaped child
    is its own `data/`, which `resolve_js_dir` accepts as an entry point and which would
    otherwise be returned as a second report holding the same findings.
    """
    base = Path(base_dir)
    if not base.is_dir():
        return []
    if AperfFindingsParser.is_report_dir(base):
        return [base]
    return [
        p for p in sorted(base.iterdir()) if p.is_dir() and AperfFindingsParser.is_report_dir(p)
    ]
