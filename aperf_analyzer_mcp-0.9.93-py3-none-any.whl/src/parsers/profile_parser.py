# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Profile parser - re-exported from disk_parser for compatibility."""

from .disk_parser import ProfileParser, ProfileSummary

__all__ = ["ProfileParser", "ProfileSummary"]
