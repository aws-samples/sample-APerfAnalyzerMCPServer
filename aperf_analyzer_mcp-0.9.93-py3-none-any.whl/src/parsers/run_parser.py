# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Core parser for aperf run directories.

APerf run directory structure (after `aperf record`):
    <run_name>/
    ├── aperf_run_stats.json          # Execution timing metadata
    ├── aperf_run_log.txt             # Run log messages
    ├── system_info.json              # System metadata, EC2 info
    ├── kernel_config.txt             # /boot/config dump
    ├── sysctl.json                   # Sysctl settings
    ├── cpu_utilization/              # Per-interval CPU data
    │   ├── 0001.bin                  # Binary serialized interval data
    │   ├── 0002.bin
    │   └── ...
    ├── vmstat/                       # Virtual memory stats
    ├── diskstats/                    # Per-disk I/O stats
    ├── interrupts/                   # Interrupt counts per CPU
    ├── perf_stat/                    # PMU counter data
    ├── processes/                    # Per-process CPU usage
    ├── netstat/                      # TCP/IP stats
    ├── meminfo/                      # Memory usage snapshots
    ├── perf_profile/                 # Profiling data (if --profile)
    ├── java_profile/                 # JVM profiling (if --profile-java)
    ├── hotline/                      # Hotline data (if built with feature)
    └── memalloc/                     # Memory allocation data

Each subdirectory contains numbered binary files (one per collection interval).
APerf uses a custom binary serialization format (Rust serde + bincode).
The `aperf report` command converts these to structured data for visualization.

For this MCP server, we can:
1. Parse the JSON metadata files directly
2. Invoke `aperf report --json` for structured data export (if available)
3. Parse the generated report HTML/JSON if a report was already generated
"""

import json
import tarfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..instance_types import is_graviton

# Capture archives are attacker-reachable input (a customer-supplied .tar.gz, or a crafted
# data/*.json file), not something this process produced. These ceilings bound the worst case —
# a single oversized or member-flooded archive hanging or OOM-ing the server — without touching
# any real aperf output, which is numbered per-interval binary/JSON files well under these sizes.
_MAX_JSON_FILE_BYTES = 64 * 1024 * 1024  # 64 MB: generous for one report JSON/JS file
_MAX_ARCHIVE_MEMBERS = 100_000
_MAX_ARCHIVE_MEMBER_BYTES = 512 * 1024 * 1024  # 512 MB: generous for one extracted file


def _read_text_capped(path: Path, max_bytes: int = _MAX_JSON_FILE_BYTES) -> str | None:
    """Read a text file, refusing anything past `max_bytes` rather than loading it fully first."""
    try:
        if path.stat().st_size > max_bytes:
            return None
    except OSError:
        return None
    return path.read_text()


@dataclass
class RunMetadata:
    """Metadata about an aperf run."""

    run_name: str
    run_path: str
    #: aperf's OWN name for this capture (from `runs.js`), when it differs from
    #: `run_name` (the report/record DIRECTORY's name — see `_parse_metadata`). None when
    #: the report holds more than one run or carries no `runs.js` at all.
    aperf_run_name: str | None = None
    timestamp: str | None = None
    duration_seconds: float | None = None
    interval_seconds: float | None = None
    num_intervals: int = 0
    system_info: dict[str, Any] = field(default_factory=dict)
    instance_type: str | None = None
    architecture: str | None = None
    cpu_count: int | None = None
    kernel_version: str | None = None
    collectors_available: list[str] = field(default_factory=list)
    has_profile: bool = False
    has_java_profile: bool = False
    has_hotline: bool = False
    #: Which aperf built the run. Read from `metadata.json` (1.3.0+) and worth surfacing: the
    #: guidance tree is pinned to one aperf commit, and a mismatch changes what the data means.
    collector_version: str | None = None
    collector_commit_sha: str | None = None


@dataclass
class RunData:
    """Parsed data from an aperf run."""

    metadata: RunMetadata
    cpu_utilization: dict[str, Any] | None = None
    memory: dict[str, Any] | None = None
    pmu_counters: dict[str, Any] | None = None
    interrupts: dict[str, Any] | None = None
    disk_stats: dict[str, Any] | None = None
    processes: dict[str, Any] | None = None
    network: dict[str, Any] | None = None
    profile_summary: dict[str, Any] | None = None
    java_profile_summary: dict[str, Any] | None = None


class AperfRunParser:
    """
    Main parser for aperf run data.

    Supports:
    - Raw run directories (from `aperf record`)
    - Compressed archives (.tar.gz)
    - Generated report directories (from `aperf report`)
    """

    def __init__(self, base_dir: str = "./aperf_data"):
        self.base_dir = Path(base_dir)

    def discover_runs(self) -> list[RunMetadata]:
        """Discover all aperf runs in the base directory."""
        runs: list[RunMetadata] = []

        if not self.base_dir.exists():
            return runs

        seen = set()
        for entry in sorted(self.base_dir.iterdir()):
            if entry.is_dir() and self._is_aperf_run(entry):
                metadata = self._parse_metadata(entry)
                if metadata:
                    seen.add(metadata.run_name)
                    runs.append(metadata)
            elif entry.suffix == ".gz" and entry.stem.endswith(".tar"):
                # Compressed archive. `aperf record` writes `<run>/` and `<run>.tar.gz` side by
                # side, and `aperf report` does the same, so listing both showed every run twice —
                # once with metadata and once with every field null, since the archive branch
                # reads only `system_info.json`, a file no released layout contains. The directory
                # is preferred because it is the one the other tools can actually read.
                name = entry.name[: -len(".tar.gz")]
                if name in seen:
                    continue
                metadata = self._parse_archive_metadata(entry)
                if metadata:
                    seen.add(metadata.run_name)
                    runs.append(metadata)

        return runs

    def _is_aperf_run(self, path: Path) -> bool:
        """Check if a directory looks like an aperf run."""
        indicators = [
            "aperf_run_stats.json",
            "system_info.json",
            "cpu_utilization",
            # A raw `aperf record` directory. 1.3.0 writes `metadata.json`; 1.2.x wrote
            # `meta_data.bin`, the same struct in bincode. None of the three names above appear
            # in either layout, so before this a record directory was not recognised as a run at
            # all — only reports were, and `list_runs` returned every record dir with null
            # metadata because `_parse_metadata` had nothing it could read.
            "metadata.json",
            "meta_data.bin",
        ]
        if any((path / ind).exists() for ind in indicators):
            return True
        # Also accept aperf report directories. The test is the JS data bundle, not `index.html`:
        # the data files are what every tool here reads, and the HTML shell is only the viewer.
        # `findings_parser.is_report_dir` draws the line in the same place.
        if (path / "data" / "js").is_dir() and any((path / "data" / "js").glob("*.js")):
            return True
        # Accept the flat-binary record layout: all collectors as timestamped `.bin` files in one
        # directory, with no per-collector subdirectory. `aperf_runlog`/`aperf_stats.bin` are the
        # markers that distinguish it from an arbitrary directory that happens to hold a `.bin`.
        if (path / "aperf_runlog").exists() and any(path.glob("*.bin")):
            return True
        return (path / "aperf_stats.bin").is_file()

    def _parse_metadata(self, run_path: Path) -> RunMetadata | None:
        """Parse metadata from a run directory."""
        metadata = RunMetadata(
            run_name=run_path.name,
            run_path=str(run_path),
        )

        # aperf's OWN run name, distinct from `run_name` above.
        #
        # `run_name` has to stay the report DIRECTORY's name: `discover_runs`/`list_runs`
        # use it as the lookup key callers pass back into `parse_run(run_name)`, dedupe on
        # it against the sibling `.tar.gz` archive, and two different directories can
        # legitimately share the same underlying aperf run name (e.g. a report re-run
        # under a new directory name) — collapsing them onto one `run_name` broke that
        # dedup and the lookup contract (`test_each_run_is_listed_once`).
        #
        # But the directory name is frequently NOT the name aperf itself used for the
        # capture: `aperf report` writes to whatever directory name `--name`/the default
        # timestamp gives it (`vaultwarden_report`, `aperf_report_2026-08-07_22_36_20`),
        # which is a different, arbitrary label from the `-r/--run-name` the capture was
        # recorded under (`vaultwarden`) — the name aperf's own report UI displays, read
        # from `runs.js`'s `runs_raw[].name`. `aperf_run_name` carries that real name
        # separately so a display-only consumer (the HTML report's customer-label
        # fallback) can prefer it without disturbing the lookup/dedup contract above.
        # Reports commonly hold exactly one run, so the first name is unambiguous; a
        # report legitimately holding several leaves this unset, since there is no single
        # "the" run to prefer.
        runs_js = run_path / "data" / "js" / "runs.js"
        if runs_js.is_file():
            runs_raw = self._parse_js_list(_read_text_capped(runs_js) or "")
            if isinstance(runs_raw, list):
                names = [r["name"] for r in runs_raw if isinstance(r, dict) and r.get("name")]
                if len(names) == 1:
                    metadata.aperf_run_name = names[0]

                # `runs.js` also carries this run's own wall-clock window
                # (`collection_start_ms`/`collection_end_ms`), which is the ONLY source
                # of timestamp/duration for a report-JS directory: `aperf_run_stats.json`
                # belongs to the flat-binary record layout and does not exist here, so
                # both fields silently stayed None for every report-directory run,
                # rendering as "Duration 0s" / "Recorded ?" in the HTML header. A report
                # holding several runs (a comparison) leaves this unset for the same
                # reason `aperf_run_name` does above — there is no single "the" window.
                if len(names) == 1:
                    entry = next(
                        (r for r in runs_raw if isinstance(r, dict) and r.get("name") == names[0]),
                        None,
                    )
                    if entry:
                        start_ms = entry.get("collection_start_ms")
                        end_ms = entry.get("collection_end_ms")
                        if isinstance(start_ms, (int, float)):
                            metadata.timestamp = datetime.fromtimestamp(
                                start_ms / 1000, tz=timezone.utc
                            ).strftime("%Y-%m-%dT%H:%M:%SZ")
                        if isinstance(start_ms, (int, float)) and isinstance(end_ms, (int, float)):
                            metadata.duration_seconds = (end_ms - start_ms) / 1000

        # Parse run stats
        stats_file = run_path / "aperf_run_stats.json"
        if stats_file.exists():
            try:
                text = _read_text_capped(stats_file)
                stats = json.loads(text) if text is not None else {}
                metadata.duration_seconds = stats.get("total_duration_secs")
                metadata.interval_seconds = stats.get("interval_secs")
                metadata.num_intervals = stats.get("num_intervals", 0)
                metadata.timestamp = stats.get("start_time")
            except (json.JSONDecodeError, KeyError):
                pass
        else:
            self._read_record_metadata(run_path, metadata)

        # A report directory states its producer in `version.js` — same shape in 1.2.x and 1.3.0.
        if not metadata.collector_version:
            version_js = run_path / "data" / "js" / "version.js"
            if version_js.is_file():
                info = self._parse_js_var(_read_text_capped(version_js) or "") or {}
                metadata.collector_version = info.get("version")
                metadata.collector_commit_sha = info.get("git_sha")

        # Parse system info from standard JSON or from report JS file
        sysinfo_file = run_path / "system_info.json"
        if sysinfo_file.exists():
            try:
                text = _read_text_capped(sysinfo_file)
                sysinfo = json.loads(text) if text is not None else {}
                metadata.system_info = sysinfo
                metadata.instance_type = sysinfo.get("ec2", {}).get("instance_type")
                metadata.architecture = sysinfo.get("architecture")
                metadata.cpu_count = sysinfo.get("cpu_count")
                metadata.kernel_version = sysinfo.get("kernel_version")
            except (json.JSONDecodeError, KeyError):
                pass
        else:
            # Try to read from report JS file
            js_sysinfo = run_path / "data" / "js" / "systeminfo.js"
            if js_sysinfo.exists():
                try:
                    parsed = self._parse_js_var(_read_text_capped(js_sysinfo) or "")
                    if parsed:
                        kvs = (
                            parsed.get("runs", {})
                            .get(next(iter(parsed.get("runs", {})), ""), {})
                            .get("key_value_groups", {})
                            .get("", {})
                            .get("key_values", {})
                        )
                        metadata.instance_type = kvs.get("Instance Type")
                        # No default. An aperf report's systeminfo carries no "Architecture"
                        # key at all, so defaulting to x86_64 here labelled every Graviton run
                        # x86_64 — and because this branch assigned a value, the instance-type
                        # derivation further down never ran. Observed on real i8g/r6g captures,
                        # which then drew a "migrate to Graviton" recommendation for a machine
                        # already on Graviton. Leaving it None lets that derivation decide.
                        metadata.architecture = kvs.get("Architecture")
                        metadata.cpu_count = int(kvs.get("CPUs", 0)) if kvs.get("CPUs") else None
                        metadata.kernel_version = kvs.get("Kernel Version")
                        metadata.system_info = kvs
                except (json.JSONDecodeError, KeyError, AttributeError, OSError, ValueError):
                    # Mirrors the JSON branch above: metadata is best-effort, and a report that
                    # nests `systeminfo.js` differently leaves the fields None rather than failing
                    # the whole parse. ValueError covers `int(kvs.get("CPUs"))` on a non-numeric
                    # value; AttributeError covers a `runs` entry that is not a dict.
                    pass
            else:
                # Fallback: newer flat binary layout — extract from systeminfo_*.bin via strings
                sysinfo_bins = AperfRunParser._bins_for(run_path, "systeminfo")
                if sysinfo_bins:
                    try:
                        raw = self._strings_from_bin(sysinfo_bins[0])
                        # The binary contains these fields as separate ASCII strings:
                        # [0] timestamp, [1] os_name, [2] kernel_version, [3] os_version,
                        # [4] hostname, [5] instance_id, [6] private_dns, [7] ami_id,
                        # [8] region, (form-feed \x0c is stripped), [9] instance_type
                        lines = [l.strip() for l in raw.splitlines() if l.strip()]
                        # instance_type is the last meaningful string (after region)
                        if lines:
                            # The last line is the instance type (e.g. "m6i.32xlarge")
                            metadata.instance_type = lines[-1]
                        # kernel version is line index 2
                        if len(lines) >= 3:
                            metadata.kernel_version = lines[2]
                        # CPU count from /proc/stat — count "cpuN" lines in cpu_utilization bin
                        cpu_bins = AperfRunParser._bins_for(run_path, "cpu_utilization")
                        if cpu_bins:
                            cpu_raw = self._strings_from_bin(cpu_bins[0])
                            import re

                            cpu_ids = set(re.findall(r"^cpu(\d+)", cpu_raw, re.MULTILINE))
                            if cpu_ids:
                                metadata.cpu_count = len(cpu_ids)
                        metadata.system_info = {"raw_lines": lines}

                        # Sysctl extraction from flat binary sysctl.bin.
                        # Length-prefixed strings; alternates key/value with
                        # write-only keys having no following value (see
                        # get_flat_bin_report_data for full rationale).
                        sysctl_bins = AperfRunParser._bins_for(run_path, "sysctl")
                        if sysctl_bins:
                            try:
                                import struct as _struct

                                sraw_bytes = sysctl_bins[0].read_bytes()
                                stoks = []
                                _i = 0
                                while _i + 8 <= len(sraw_bytes):
                                    _n = _struct.unpack_from("<Q", sraw_bytes, _i)[0]
                                    if 0 < _n < 4096 and _i + 8 + _n <= len(sraw_bytes):
                                        _s = sraw_bytes[_i + 8 : _i + 8 + _n]
                                        if all(0x09 <= b < 0x80 or b in (0x0A, 0x0D) for b in _s):
                                            try:
                                                stoks.append(_s.decode("ascii", errors="replace"))
                                                _i += 8 + _n
                                                continue
                                            except Exception:
                                                pass
                                    _i += 1
                                _key_re = re.compile(r"^[A-Za-z0-9._-]+$")

                                def _is_key(s: str) -> bool:
                                    return (
                                        "." in s
                                        and any(c.isalpha() for c in s)
                                        and bool(_key_re.match(s))
                                    )

                                wanted = {
                                    "vm.max_map_count": "vm_max_map_count",
                                    "vm.swappiness": "vm_swappiness",
                                    "kernel.numa_balancing": "numa_balancing",
                                }
                                _j = 1
                                while _j < len(stoks):
                                    _cur = stoks[_j]
                                    if not _is_key(_cur):
                                        _j += 1
                                        continue
                                    _nxt = stoks[_j + 1] if _j + 1 < len(stoks) else None
                                    if _nxt is not None and not _is_key(_nxt):
                                        if _cur in wanted and _nxt.lstrip("-").isdigit():
                                            metadata.system_info[wanted[_cur]] = int(_nxt)
                                        _j += 2
                                    else:
                                        _j += 1
                            except Exception:
                                pass

                    except Exception:
                        pass

        # Derive architecture from the instance type whenever no source above reported one.
        #
        # Hoisted out of the flat-binary branch, where it used to live: a report-directory
        # run took the `systeminfo.js` branch instead and so never reached it. Combined with
        # that branch defaulting the missing "Architecture" key to x86_64, every Graviton
        # report run was labelled x86_64.
        if metadata.architecture is None and metadata.instance_type:
            metadata.architecture = "aarch64" if is_graviton(metadata.instance_type) else "x86_64"

        # Parse timing from flat binary aperf_runlog if JSON stats not available
        if metadata.duration_seconds is None and metadata.timestamp is None:
            runlog = run_path / "aperf_runlog"
            if runlog.exists():
                try:
                    log_text = _read_text_capped(runlog) or ""
                    import re

                    # First timestamp in log = start time
                    ts_matches = re.findall(r"\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)", log_text)
                    if ts_matches:
                        metadata.timestamp = ts_matches[0]
                    # Duration from "Time elapsed: X.Xs" lines
                    elapsed = re.findall(r"Time elapsed: ([\d.]+)s", log_text)
                    if elapsed:
                        metadata.duration_seconds = float(elapsed[-1])
                        if len(elapsed) > 1:
                            metadata.num_intervals = len(elapsed)
                            metadata.interval_seconds = float(elapsed[-1]) / len(elapsed)
                except Exception:
                    pass

        # Discover available collectors (raw dirs or JS files)
        collectors = []
        collector_names = [
            "cpu_utilization",
            "vmstat",
            "diskstats",
            "interrupts",
            "perf_stat",
            "processes",
            "netstat",
            "meminfo",
            "perf_profile",
            "java_profile",
            "hotline",
            "memalloc",
            "ena_stat",
            "efa_stat",
        ]
        for collector in collector_names:
            # A record directory holds `<collector>.bin` (both 1.2.x and 1.3.0 — the per-interval
            # subdirectories this used to look for are from a pre-1.2 layout); a report holds
            # `data/js/<collector>.js`.
            if (
                (run_path / collector).exists()
                or (run_path / f"{collector}.bin").is_file()
                or (run_path / "data" / "js" / f"{collector}.js").exists()
            ):
                collectors.append(collector)
            elif AperfRunParser._bins_for(run_path, collector):
                # Newer flat layout: e.g. cpu_utilization_2026-06-03_16_24_05.bin
                collectors.append(collector)

        metadata.collectors_available = collectors
        # `perf_profile.bin` is written whether or not `--profile` was passed, and a report always
        # ships `perf_profile.js` even when its `runs` object is empty. Presence of the file is
        # therefore not evidence of profiling data, so the flamegraph is what gets tested.
        metadata.has_profile = "perf_profile" in collectors and bool(
            list(run_path.glob("*-flamegraph.svg"))
            or list(run_path.glob("data/js/*-flamegraph.svg"))
            or (run_path / "flamegraph.svg").is_file()
            or (run_path / "perf_profile").is_dir()
        )
        metadata.has_java_profile = "java_profile" in collectors
        metadata.has_hotline = "hotline" in collectors

        return metadata

    @staticmethod
    def _read_record_metadata(run_path: Path, metadata: RunMetadata) -> None:
        """Fill timing fields from a raw record directory's `metadata.json` (aperf 1.3.0+).

        1.3.0 replaced the bincode `meta_data.bin` with plain JSON, so a record directory now
        states its own run name, collector version, interval and period. `aperf_run_stats.json`
        does not exist in any released layout, so without this every field on a record directory
        came back null.

        1.2.x is left alone deliberately: `meta_data.bin` is bincode, and decoding it would mean
        reimplementing a Rust struct layout that carries no self-description. A 1.2.x record
        directory is still recognised as a run — it just reports timing as unknown.
        """
        source = run_path / "metadata.json"
        if not source.is_file():
            return
        try:
            text = _read_text_capped(source)
            if text is None:
                return
            meta = json.loads(text)
        except (OSError, json.JSONDecodeError):
            return

        metadata.run_name = meta.get("run_name") or metadata.run_name
        metadata.interval_seconds = meta.get("interval")
        metadata.duration_seconds = meta.get("period")
        # `collection_start` is `{"DateTime": "..."}`; take the value whatever the key is.
        start = meta.get("collection_start")
        if isinstance(start, dict) and start:
            metadata.timestamp = next(iter(start.values()))
        elif isinstance(start, str):
            metadata.timestamp = start
        if metadata.interval_seconds and metadata.duration_seconds:
            # The count aperf actually writes, not a claim: interval files are what exist.
            metadata.num_intervals = int(metadata.duration_seconds / metadata.interval_seconds)
        metadata.collector_version = meta.get("collector_version")
        metadata.collector_commit_sha = meta.get("collector_commit_sha")

    def _parse_archive_metadata(self, archive_path: Path) -> RunMetadata | None:
        """Parse metadata from a compressed archive without full extraction.

        Returns None for any tarball that is not an aperf run. This used to return metadata for
        every `.tar.gz` in the directory whatever it held — the downloaded aperf release tarball
        sitting beside the runs was listed as a run with every field null.

        The metadata read here is deliberately the same `metadata.json` a record directory holds
        (aperf 1.3.0+), not `system_info.json`, which no released layout contains.
        """
        try:
            with tarfile.open(archive_path, "r:gz") as tar:
                members = tar.getnames()
                metadata_member = next((m for m in members if m.endswith("metadata.json")), None)
                # An aperf archive holds either a record directory's `metadata.json` /
                # `meta_data.bin`, or a report's `data/js/`.
                is_aperf = metadata_member or any(
                    m.endswith("meta_data.bin") or "/data/js/" in m for m in members
                )
                if not is_aperf:
                    return None

                metadata = RunMetadata(
                    run_name=archive_path.name[: -len(".tar.gz")],
                    run_path=str(archive_path),
                )

                if metadata_member:
                    f = tar.extractfile(metadata_member)
                    if f:
                        meta = json.loads(f.read())
                        metadata.run_name = meta.get("run_name") or metadata.run_name
                        metadata.interval_seconds = meta.get("interval")
                        metadata.duration_seconds = meta.get("period")
                        metadata.collector_version = meta.get("collector_version")
                        metadata.collector_commit_sha = meta.get("collector_commit_sha")
                        start = meta.get("collection_start")
                        if isinstance(start, dict) and start:
                            metadata.timestamp = next(iter(start.values()))

                return metadata
        except (tarfile.TarError, json.JSONDecodeError, OSError):
            return None

    def parse_run(self, run_name: str) -> RunData | None:
        """Parse full data from a specific run."""
        # `run_name` reaches here straight from an MCP tool-call argument. Resolving and checking
        # containment against `base_dir` before any filesystem access rejects a `run_name` like
        # `../../etc` or an absolute path, which `Path.__truediv__` would otherwise happily honor
        # (an absolute right-hand operand REPLACES the left side entirely, per pathlib's own
        # semantics — `self.base_dir / "/etc/passwd"` is `/etc/passwd`, not an error).
        base_dir = self.base_dir.resolve()
        run_path = (base_dir / run_name).resolve()
        if not run_path.is_relative_to(base_dir):
            return None

        if not run_path.exists():
            # Try archive
            archive_path = (base_dir / f"{run_name}.tar.gz").resolve()
            if not archive_path.is_relative_to(base_dir):
                return None
            if archive_path.exists():
                # Extract to temp and parse
                try:
                    run_path = self._extract_archive(archive_path)
                except (tarfile.TarError, ValueError, OSError):
                    # Oversized/member-flooded/corrupt archive -- reported as "no such run" rather
                    # than propagating, since a hostile capture archive is exactly the kind of
                    # input this boundary exists to absorb.
                    return None
            else:
                return None

        metadata = self._parse_metadata(run_path)
        if not metadata:
            return None

        return RunData(metadata=metadata)

    def _extract_archive(self, archive_path: Path) -> Path:
        """Extract archive to a temporary location."""
        import tempfile

        extract_dir = Path(tempfile.mkdtemp())
        with tarfile.open(archive_path, "r:gz") as tar:
            # Bounded before extraction: a crafted archive with an enormous member count or an
            # individually huge member (a decompression-bomb shape, or just a lot of small files)
            # would otherwise exhaust disk/inodes/memory during extractall itself, before any
            # per-file size check downstream ever runs. This is a customer-supplied .tar.gz, not
            # something this process produced.
            members = tar.getmembers()
            if len(members) > _MAX_ARCHIVE_MEMBERS:
                raise ValueError(
                    f"archive has {len(members)} members, exceeding the {_MAX_ARCHIVE_MEMBERS} limit"
                )
            for member in members:
                if member.size > _MAX_ARCHIVE_MEMBER_BYTES:
                    raise ValueError(
                        f"archive member '{member.name}' is {member.size} bytes, exceeding the "
                        f"{_MAX_ARCHIVE_MEMBER_BYTES} limit"
                    )
            # `filter="data"` refuses absolute paths, `..` traversal, symlinks pointing outside the
            # destination, and device nodes. Without it a member named `../../.ssh/authorized_keys`
            # is written wherever it says — and an aperf archive is a file the caller hands us, not
            # something this process produced. Available since 3.10, so the >=3.10 floor holds; it
            # becomes the default in 3.14, and naming it makes the behaviour the same on all four.
            tar.extractall(extract_dir, filter="data")
        # Return the first directory inside
        for item in extract_dir.iterdir():
            if item.is_dir():
                return item
        return extract_dir

    @staticmethod
    def _parse_js_var(content: str, var_name: "str | None" = None) -> "dict[str, Any] | None":
        """Extract and parse the first JSON object from an aperf JS data file.

        Aperf JS files contain one or more assignments like:
            processed_cpu_utilization_data = {...}\n\ncpu_utilization_findings = {...}

        Uses json.JSONDecoder.raw_decode() anchored at each opening brace to find
        the exact end of each JSON object. This is robust against multiple
        consecutive assignments, which the previous regex-split approach failed on.

        Args:
            content: Raw JS file content.
            var_name: If provided, return only the object assigned to this name.
        """
        import re

        decoder = json.JSONDecoder()
        for m in re.finditer(r"(\w+)\s*=\s*(\{)", content):
            name = m.group(1)
            start = m.start(2)
            if var_name and name != var_name:
                continue
            try:
                obj: dict[str, Any] = decoder.raw_decode(content, start)[0]
                return obj
            except json.JSONDecodeError:
                continue
        return None

    @staticmethod
    def _parse_js_list(content: str) -> "list[Any] | None":
        """Extract the first JSON *array* assignment from an aperf JS file.

        `_parse_js_var` anchors its search on `{`, so it cannot see `runs_raw = [...]` and returns
        None for `runs.js` — which silently cost `_report_run_names` its authoritative ordering
        and left it falling back to arbitrary metric-file key order. `runs.js` is the only
        array-valued file aperf writes (verified across 1.2.2 and 1.3.0 reports), so this is a
        separate reader rather than a widening of the dict helper eight other call sites rely on
        returning a dict.
        """
        import re

        decoder = json.JSONDecoder()
        for m in re.finditer(r"(\w+)\s*=\s*(\[)", content):
            try:
                obj: list[Any] = decoder.raw_decode(content, m.start(2))[0]
                return obj
            except json.JSONDecodeError:
                continue
        return None

    @staticmethod
    def _parse_all_js_vars(content: str) -> dict[str, Any]:
        """Parse all variable assignments from an aperf JS data file.

        Returns a dict mapping variable_name -> parsed_object for every
        top-level assignment found in the file. Used to extract both the
        main data object and the findings object in a single pass.
        """
        import re

        decoder = json.JSONDecoder()
        results: dict[str, Any] = {}
        for m in re.finditer(r"(\w+)\s*=\s*(\{)", content):
            name = m.group(1)
            start = m.start(2)
            if name in results:
                continue
            try:
                obj, _ = decoder.raw_decode(content, start)
                results[name] = obj
            except json.JSONDecodeError:
                continue
        return results

    @staticmethod
    def _strings_from_bin(bin_path: Path) -> str:
        """Extract printable strings from a binary file (equivalent to Unix `strings`)."""
        import re

        data = bin_path.read_bytes()
        # Extract sequences of printable ASCII chars of length >= 4
        matches = re.findall(rb"[\x09\x0a\x0d\x20-\x7e]{4,}", data)
        return "\n".join(m.decode("ascii", errors="replace") for m in matches)

    @staticmethod
    def _bins_for(run_path: Path, collector: str) -> list[Path]:
        """
        Return all .bin files for a collector, matching BOTH the older
        timestamped form 'collector_<timestamp>.bin' AND the simpler
        'collector.bin' form used by the latest aperf format. Sorted for
        determinism.
        """
        files = list(run_path.glob(f"{collector}_*.bin"))
        single = run_path / f"{collector}.bin"
        if single.exists():
            files.append(single)
        return sorted(files)

    def get_flat_bin_report_data(self, run_path: Path) -> dict[str, Any] | None:
        """
        Parse aperf flat binary layout (newer aperf versions) into normalized report data.

        Newer aperf versions store all data as timestamped flat binary files in one directory:
            cpu_utilization_<timestamp>.bin
            meminfo_<timestamp>.bin
            perf_stat_<timestamp>.bin
            processes_<timestamp>.bin
            etc.

        This method extracts usable data by parsing the embedded text strings from each binary.
        """
        import re

        report_data: dict[str, Any] = {}

        # --- CPU utilization from /proc/stat embedded in cpu_utilization_*.bin ---
        cpu_bins = AperfRunParser._bins_for(run_path, "cpu_utilization")
        if cpu_bins:
            try:
                raw = self._strings_from_bin(cpu_bins[0])
                # Parse all "cpu  user nice system idle iowait irq softirq steal" lines
                cpu_stat_lines = re.findall(
                    r"^(cpu\d*)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)",
                    raw,
                    re.MULTILINE,
                )
                if cpu_stat_lines:
                    agg_line = next((l for l in cpu_stat_lines if l[0] == "cpu"), None)
                    per_cpu_lines = [l for l in cpu_stat_lines if l[0] != "cpu"]

                    def _pct(val: int, total: int) -> float:
                        return (int(val) / total * 100) if total > 0 else 0.0

                    if agg_line:
                        user, nice, system, idle, iowait, irq, softirq, steal = (
                            int(agg_line[i]) for i in range(1, 9)
                        )
                        total = user + nice + system + idle + iowait + irq + softirq + steal
                        agg = {
                            "user": [_pct(user, total)],
                            "system": [_pct(system, total)],
                            "iowait": [_pct(iowait, total)],
                            "idle": [_pct(idle, total)],
                            "irq": [_pct(irq, total)],
                            "softirq": [_pct(softirq, total)],
                            "steal": [_pct(steal, total)],
                        }
                        per_cpu: dict[str, dict[str, list[float]]] = {}
                        for cpu_line in per_cpu_lines:
                            cpu_id = cpu_line[0]
                            u, n, s, id_, io, ir, si, st = (int(cpu_line[i]) for i in range(1, 9))
                            t = u + n + s + id_ + io + ir + si + st
                            per_cpu[cpu_id] = {
                                "user": [_pct(u, t)],
                                "idle": [_pct(id_, t)],
                            }
                        report_data["cpu_utilization"] = {"aggregate": agg, "per_cpu": per_cpu}
            except Exception:
                pass

        # --- Memory info from meminfo_*.bin ---
        mem_bins = AperfRunParser._bins_for(run_path, "meminfo")
        if mem_bins:
            try:
                raw = self._strings_from_bin(mem_bins[0])
                mem_kv: dict[str, int] = {}
                for m in re.finditer(
                    r"(Mem\w+|Swap\w+|AnonPages|Cached|Mapped|HugePages\w*):\s+(\d+)", raw
                ):
                    mem_kv[m.group(1)] = int(m.group(2))
                if mem_kv:
                    avail_kb = mem_kv.get("MemAvailable", 0)
                    report_data["meminfo"] = {
                        "mem_total_kb": mem_kv.get("MemTotal", 0),
                        "mem_available_kb": [avail_kb],
                        "swap_total_kb": mem_kv.get("SwapTotal", 0),
                        "swap_free_kb": mem_kv.get("SwapFree", 0),
                        "anon_pages_kb": mem_kv.get("AnonPages", 0),
                    }
            except Exception:
                pass

        # --- PMU counters from perf_stat_*.bin ---
        pmu_bins = AperfRunParser._bins_for(run_path, "perf_stat")
        if pmu_bins:
            try:
                raw = self._strings_from_bin(pmu_bins[0])
                # Format per NUMA domain: "domain metric_name; numerator; denominator;scale"
                # e.g.  "0 ipc; 61176309; 98161860;1"
                pmu_entries: dict[str, dict[str, int]] = {}
                for m in re.finditer(r"^(\d+)\s+(\S+);\s*(\d+);\s*(\d+);(\d+)", raw, re.MULTILINE):
                    # The NUMA domain is deliberately dropped: entries are summed across
                    # domains into one per-metric total below.
                    _domain, metric, numer, denom, scale = (
                        int(m.group(1)),
                        m.group(2),
                        int(m.group(3)),
                        int(m.group(4)),
                        int(m.group(5)),
                    )
                    if metric not in pmu_entries:
                        pmu_entries[metric] = {"numerator": 0, "denominator": 0, "scale": scale}
                    pmu_entries[metric]["numerator"] += numer
                    pmu_entries[metric]["denominator"] += denom
                if pmu_entries:
                    report_data["perf_stat"] = pmu_entries
            except Exception:
                pass

        # --- Process list from processes_*.bin ---
        proc_bins = AperfRunParser._bins_for(run_path, "processes")
        if proc_bins:
            try:
                raw = self._strings_from_bin(proc_bins[0])
                # /proc/<pid>/stat format: pid (name) state ppid ...
                # Fields: pid, (name), state, ppid, pgrp, session, ..., utime(14), stime(15), ..., num_threads(20)
                proc_entries: dict[str, dict[str, Any]] = {}
                for m in re.finditer(
                    r"^(\d+)\s+\(([^)]+)\)\s+\S+\s+\d+\s+\d+\s+\d+\s+\d+\s+[-\d]+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)\s+(\d+)\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)",
                    raw,
                    re.MULTILINE,
                ):
                    pid = m.group(1)
                    name = m.group(2)
                    utime = int(m.group(3))
                    stime = int(m.group(4))
                    nthreads = int(m.group(5))
                    key = f"{pid}_{name}"
                    if key not in proc_entries:
                        proc_entries[key] = {
                            "pid": pid,
                            "name": name,
                            "utime": utime,
                            "stime": stime,
                            "num_threads": nthreads,
                        }
                if proc_entries:
                    report_data["processes"] = proc_entries
            except Exception:
                pass

        # --- Full sysctl extraction from sysctl.bin (or sysctl_<ts>.bin) ---
        # The flat-binary format is length-prefixed strings: <u64 LE length><bytes>.
        # Items appear as: <timestamp> <key> <value> <key> <value> ...
        # BUT some keys are write-only or blank — they appear with no following
        # value. The robust walk: a token is a "key" if it matches the sysctl
        # name pattern (alpha + dot + [A-Za-z0-9._-] only). When the current
        # token is a key, peek at the next: if it's ALSO a key, the current key
        # has no captured value (skip). Otherwise consume next as the value.
        sysctl_bins = AperfRunParser._bins_for(run_path, "sysctl")
        if sysctl_bins:
            try:
                import struct as _struct

                # Named apart from the `raw` the collectors above share: those hold the
                # `_strings_from_bin` text, this holds undecoded bytes, and reusing the name
                # made the whole function's inferred type wrong.
                sysctl_raw = sysctl_bins[0].read_bytes()
                items: list[str] = []
                i = 0
                while i + 8 <= len(sysctl_raw):
                    n = _struct.unpack_from("<Q", sysctl_raw, i)[0]
                    if 0 < n < 4096 and i + 8 + n <= len(sysctl_raw):
                        chunk = sysctl_raw[i + 8 : i + 8 + n]
                        if all(0x09 <= b < 0x80 or b in (0x0A, 0x0D) for b in chunk):
                            try:
                                items.append(chunk.decode("ascii", errors="replace"))
                                i += 8 + n
                                continue
                            except Exception:
                                pass
                    i += 1
                # Walk pairs with key-detection guard
                _key_re = re.compile(r"^[A-Za-z0-9._-]+$")

                def _is_key(s: str) -> bool:
                    return "." in s and any(c.isalpha() for c in s) and bool(_key_re.match(s))

                sysctl_kv: dict[str, str] = {}
                j = 1  # skip leading timestamp
                while j < len(items):
                    cur = items[j]
                    if not _is_key(cur):
                        j += 1
                        continue
                    nxt = items[j + 1] if j + 1 < len(items) else None
                    if nxt is not None and not _is_key(nxt):
                        sysctl_kv[cur] = nxt
                        j += 2
                    else:
                        j += 1
                if sysctl_kv:
                    report_data["sysctl"] = sysctl_kv
            except Exception:
                pass

        return report_data if report_data else None

    def _extract_series_avg(
        self, series_list: list[Any], series_name: str = "Aggregate"
    ) -> list[Any]:
        """Extract values from a named series, falling back to aggregate or first."""
        for s in series_list:
            if s.get("is_aggregate"):
                values: list[Any] = s.get("values", [])
                return values
        for s in series_list:
            if s.get("series_name") == series_name:
                named: list[Any] = s.get("values", [])
                return named
        first: list[Any] = series_list[0].get("values", []) if series_list else []
        return first

    def get_report_data(
        self, run_path: Path, run_key: "str | None" = None
    ) -> "dict[str, Any] | None":
        """
        Parse aperf report data into a normalized dict for the sub-parsers.
        Supports data/js/*.js (aperf report JS-wrapped JSON), data/*.json, and the flat-binary
        record layout (aperf_stats.bin + *_<timestamp>.bin).

        `run_key` selects which run inside the report to read. One `aperf report` can hold several
        runs — that is how aperf does comparisons — and every metric file is keyed by run name.

        The run is resolved **once for the whole report**, from `runs.js`, not per file. Files do
        not agree on run order: in a real two-run 1.3.0 report `cpu_utilization.js` lists
        `v130_loaded` first while `perf_stat.js` lists `v130_idle` first. Taking each file's first
        key independently — which is what this did — returned a dict whose CPU block described one
        run and whose PMU block described the other, and nothing said so.

        The chosen name comes back as `_run_key` and every run in the report as `_runs_in_report`,
        so a caller cannot mistake one run of a comparison for the whole report.
        """
        run_path = Path(run_path)  # ensure Path type even if str was passed
        # Layout 1: plain JSON files
        data_dir = run_path / "data"
        if data_dir.exists() and list(data_dir.glob("*.json")):
            report_data: dict[str, Any] = {}
            for json_file in data_dir.glob("*.json"):
                try:
                    text = _read_text_capped(json_file)
                    if text is None:
                        continue
                    report_data[json_file.stem] = json.loads(text)
                except json.JSONDecodeError:
                    continue
            if report_data:
                return report_data

        # Layout 2: data/js/*.js  (aperf report output)
        js_dir = run_path / "data" / "js"
        if not js_dir.exists():
            report_dirs = list(self.base_dir.glob("aperf_report_*"))
            for rd in report_dirs:
                if (rd / "data" / "js").exists():
                    js_dir = rd / "data" / "js"
                    break

        report_data = {}
        runs_seen: list[Any] = self._report_run_names(js_dir)
        # One run for every file. Falls back to each file's own first key only when `runs.js` is
        # absent or lists nothing, which no released report does.
        selected = (
            run_key if (run_key and run_key in runs_seen) else (runs_seen[0] if runs_seen else None)
        )

        def _run_metrics(js_file: Path) -> dict[str, Any]:
            if not js_file.exists():
                return {}
            raw = self._parse_js_var(_read_text_capped(js_file) or "")
            if not raw:
                return {}
            runs = raw.get("runs", {})
            key = selected if (selected and selected in runs) else next(iter(runs), None)
            return runs.get(key, {}).get("metrics", {}) if key else {}

        # --- cpu_utilization ---
        metrics = _run_metrics(js_dir / "cpu_utilization.js")
        if metrics:
            cpu_block: dict[str, Any] = {"aggregate": {}, "per_cpu": {}}
            for component in ["user", "system", "iowait", "idle", "irq", "softirq", "steal"]:
                vals = self._extract_series_avg(metrics.get(component, {}).get("series", []))
                cpu_block["aggregate"][component] = vals
            for s in metrics.get("user", {}).get("series", []):
                if s["series_name"].startswith("CPU"):
                    cpu_block["per_cpu"][s["series_name"]] = {
                        "user": s.get("values", []),
                        "idle": [],
                    }
            report_data["cpu_utilization"] = cpu_block

        # --- meminfo ---
        metrics = _run_metrics(js_dir / "meminfo.js")
        if metrics:
            # `meminfo.js` carries BYTES, not kB, despite `/proc/meminfo` itself always
            # reporting in kB — verified directly against six real report captures this
            # session (Meli, Gunicorn/i7i.2xlarge, EMR/r8a.16xlarge, and three fresh EKS
            # t3.medium runs): `MemTotal`'s raw value is consistently ~1024x the box's
            # real installed RAM in kB (e.g. 66329341952 for a 61.77 GB i7i.2xlarge —
            # bytes, not "66 TB" of kB). A prior version of this comment claimed the
            # value was "already in kB" and skipped the conversion; that was never true
            # for the report-JS path — the flat-binary path this comment also cites
            # reads /proc/meminfo TEXT directly (genuinely kB there), a different code
            # path entirely, so the assumption never applied to this branch. It went
            # undetected all session because every real capture until now was either
            # missing a real instance type (sizing short-circuited before reaching the
            # capacity math) or under HIGH memory-capacity pressure, where the floor
            # equals current capacity regardless of what "current capacity" gets
            # miscomputed as. A LOW-pressure workload with a real instance type (a
            # t3.medium EKS capture, 16.6% peak memory) is what finally exposed a 953
            # GB memory-capacity demand on a 4 GB box, driving right_sizing to recommend
            # an r6a.32xlarge (987 GB) — converting bytes to kB here fixes the root
            # cause, not just this one report.
            def _avg_kb(name: str) -> float:
                vals = (
                    metrics.get(name, {}).get("series", [{}])[0].get("values", [])
                    if metrics.get(name)
                    else []
                )
                return (sum(vals) / len(vals) / 1024) if vals else 0.0

            def _series(name: str) -> list[Any]:
                return (
                    metrics.get(name, {}).get("series", [{}])[0].get("values", [])
                    if metrics.get(name)
                    else []
                )

            # Same bytes-not-kB correction as `_avg_kb` above, applied to the raw series
            # (`MemAvailable` feeds `memory_parser`'s per-sample used% directly, so it
            # cannot go through an averaging helper) and to the anon-pages scalar.
            avail_vals = [v / 1024 for v in _series("MemAvailable")]
            anon_vals = _series("AnonPages")
            report_data["meminfo"] = {
                "mem_total_kb": _avg_kb("MemTotal"),
                "mem_available_kb": list(avail_vals),
                "swap_total_kb": _avg_kb("SwapTotal"),
                "swap_free_kb": _avg_kb("SwapFree"),
                "anon_pages_kb": (sum(anon_vals) / len(anon_vals) / 1024) if anon_vals else 0,
            }

        # --- interrupts ---
        metrics = _run_metrics(js_dir / "interrupts.js")
        if metrics:
            irq_block = {}
            for irq_name, irq_data in metrics.items():
                vals = self._extract_series_avg(irq_data.get("series", []))
                if any(v > 0 for v in vals):
                    irq_block[irq_name] = vals
            report_data["interrupts"] = irq_block

        # --- perf_stat (PMU) ---
        metrics = _run_metrics(js_dir / "perf_stat.js")
        if metrics:
            report_data["perf_stat"] = metrics

        # --- processes ---
        metrics = _run_metrics(js_dir / "processes.js")
        if metrics:
            report_data["processes"] = metrics

        # --- diskstats ---
        metrics = _run_metrics(js_dir / "diskstats.js")
        if metrics:
            report_data["diskstats"] = metrics

        # --- sysctl ---
        sysctl_js = js_dir / "sysctl.js"
        if sysctl_js.exists():
            raw = self._parse_js_var(_read_text_capped(sysctl_js) or "")
            if raw:
                runs = raw.get("runs", {})
                # Distinct name: assigning to `run_key` here rebound the parameter, so the
                # caller's chosen run was silently dropped for anything read after this block.
                sysctl_key = selected if (selected and selected in runs) else next(iter(runs), None)
                kvs = (
                    (
                        runs.get(sysctl_key, {})
                        .get("key_value_groups", {})
                        .get("", {})
                        .get("key_values", {})
                    )
                    if sysctl_key
                    else {}
                )
                report_data["sysctl"] = kvs

        # Layout 3: the flat-binary record layout, which has no `data/js` at all. Only reached when
        # neither JSON nor JS produced anything, so a real report never falls through to it. The
        # run-key bookkeeping below is skipped deliberately: a record directory holds exactly one
        # run, so there is no sibling run to be confused with.
        if not report_data:
            flat_data = self.get_flat_bin_report_data(run_path)
            if flat_data:
                return flat_data

        if not report_data:
            return None

        # Which run this data is, and what else the report holds. A caller handed the first run of
        # a two-run comparison had no way to tell that from a single-run report.
        report_data["_runs_in_report"] = runs_seen
        report_data["_run_key"] = selected
        if run_key and run_key != selected:
            # Asked for a run this report does not contain. Returning another run's numbers under
            # the requested name would answer a question nobody asked, so say so instead.
            report_data["_run_key_requested"] = run_key
            report_data["_run_key_warning"] = (
                f"Run '{run_key}' is not in this report; the data below is '{selected}'. "
                f"Runs present: {', '.join(runs_seen) or 'none'}."
            )
        return report_data

    def _report_run_names(self, js_dir: Path) -> list[Any]:
        """Run names in a report, in aperf's own order, from `runs.js`.

        `runs.js` is `runs_raw = [{"name": ..., "collection_start_ms": ...}, ...]` in both 1.2.x
        and 1.3.0, and it is the report's authoritative run list. Metric files are dicts keyed by
        run name and their key order does not match each other or this, so nothing else can serve
        as the ordering.
        """
        runs_js = js_dir / "runs.js"
        if runs_js.is_file():
            raw = self._parse_js_list(_read_text_capped(runs_js) or "")
            if isinstance(raw, list):
                names = [r["name"] for r in raw if isinstance(r, dict) and r.get("name")]
                if names:
                    return names

        # No `runs.js`: union the metric files, so `_runs_in_report` is still complete even though
        # the order is arbitrary.
        names = []
        for js_file in sorted(js_dir.glob("*.js")):
            var = self._parse_js_var(_read_text_capped(js_file) or "")
            if not isinstance(var, dict):
                continue
            for name in var.get("runs", {}):
                if name not in names:
                    names.append(name)
        return names
