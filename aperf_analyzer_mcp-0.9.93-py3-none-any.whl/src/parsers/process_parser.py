# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Process parser - re-exported from disk_parser for compatibility."""

from .disk_parser import ProcessParser, ProcessSummary

__all__ = ["ProcessParser", "ProcessSummary"]
