# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Access to the prescriptive findings tree under `resources/findings/`.

The tree is 51 playbooks — one per analytical rule aperf can emit — plus six top-level
documents that hold the vocabulary the playbooks are written against. This module is the only
thing that knows the tree's file layout, so both the MCP resource layer and the
`analyze_findings` tool address documents by URI rather than by path.

URI scheme
----------
Playbooks and top docs live under their own scheme, deliberately not folded into
`aperf://prompts/`. The prompt templates are advisory prose for a language; these are
executable instructions bound to a specific aperf rule, and a client listing resources should
be able to tell them apart::

    aperf://findings/GATES                                  top-level document
    aperf://findings/cpu_utilization/underutilized-cpu      playbook for one rule
    aperf://findings/statistical/README                     the statistical-findings treatment

The playbook set is enumerated from `FINDINGS_REGISTRY.json`, not from a glob, so a resource
listing can never advertise a playbook that no rule joins to, nor omit one that a rule needs.

Sections
--------
Every playbook has the same 13 `## ` sections (`tools/check_playbooks.py` enforces this), so a
consumer can ask for `Decision tree` or `Priority and execution risk` by name and get the part
it needs instead of 600 lines. Section names are matched exactly for the same reason rule names
are: a near-miss must read as "no such section", not as the wrong section.

37 of the 51 also carry one **evidence section** immediately after `What fired`, whose title is
free-form but starts with a known stem. It is where a playbook records that the finding's
behaviour was established by running aperf rather than by reading it — a processing defect, a
collection gap, a caveat that changes what the reported number means. `evidence_section()`
finds it by stem, since its title cannot be enumerated.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from .findings_parser import FINDINGS_DIR, Registry, get_registry

#: URI prefix for everything in the tree.
URI_PREFIX = "aperf://findings/"

#: Top-level documents, in reading order rather than alphabetical: an agent that reads them in
#: this order learns the inventory, then the contract, then the precedence policy.
TOP_DOCUMENTS = [
    ("INDEX", "Inventory of all 51 analytical findings, extracted from the aperf source"),
    ("GATES", "Validity-gate precedence policy — read before any domain playbook"),
    (
        "GUIDANCE_MODEL",
        (
            "Vocabulary for the playbooks: decision-tree inputs, the P0-P4 priority model, "
            "the R0-R5 execution-risk model, and the inputs aperf does not collect"
        ),
    ),
    (
        "ARCHITECTURE",
        (
            "Which findings can fire on which CPU architecture, and how to establish the "
            "architecture of a run — aperf has no rule that compares it"
        ),
    ),
    ("SCHEMA", "Contract every playbook satisfies, and the five rules for reading a finding"),
    ("PATTERN", "The tier-2 prescriptive-depth contract"),
]

#: Sections every playbook carries, in file order. Asserted against the tree by the tests.
PLAYBOOK_SECTIONS = [
    "What fired",
    "Reasoning",
    "Reading the description",
    "Interpretation",
    "Corroborating data",
    "Guidance",
    "Priority and execution risk",
    "Decision tree",
    "Runtime-specific consequences",
    "Architecture-specific considerations",
    "Verification",
    "Do not",
    "References",
]

#: Stems of the optional evidence section, from `tools/check_playbooks.py`'s
#: `EVIDENCE_SECTION_STEMS`. 37 of the 51 playbooks carry one; its full title is free-form
#: (`The processing defect — the reported value is not the worst sample`) so it can only be
#: found by stem, and it sits immediately after `What fired`.
EVIDENCE_SECTION_STEMS = (
    "The processing defect",
    "The processing caveat",
    "The pattern actually works",
    "The collection gap",
)

#: The two sections that answer "what do I do about this finding, and what does it cost" —
#: what `analyze_findings` returns when asked for playbook text without being told which parts.
DEFAULT_SECTIONS = ["Priority and execution risk", "Decision tree"]

_SECTION_RE = re.compile(r"^## (.+)$", re.MULTILINE)
_TITLE_RE = re.compile(r"^# (.+)$", re.MULTILINE)
_FRONTMATTER_RE = re.compile(r"\A---\n.*?\n---\n", re.DOTALL)

#: The opening claims of every `Priority and execution risk` section, whose shape
#: `tools/check_playbooks.py` enforces across all 51 playbooks.
_PRIORITY_RE = re.compile(r"\*\*Priority: (P[0-4]) — ([^*]+)\*\*")
_RISK_RE = re.compile(r"\*\*Execution risk: (R[0-5]) — ([^*]+)\*\*")


class PlaybookNotFound(KeyError):
    """No document in the tree answers to that URI, rule name, or slug."""


@dataclass(frozen=True)
class Document:
    """One addressable document in the tree."""

    uri: str
    path: Path
    #: `playbook` | `top` | `statistical`
    kind: str
    title: str
    description: str
    #: Set for playbooks only — the rule this document prescribes for.
    rule_name: str | None = None
    data_type: str | None = None
    slug: str | None = None

    def read(self) -> str:
        return self.path.read_text(encoding="utf-8")


class PlaybookLibrary:
    """The findings tree, addressed by URI.

    Holds no document text: playbooks are 300-600 lines each and are read on demand, so the
    server does not carry 30 000 lines of markdown in memory to answer a listing request.
    """

    def __init__(self, registry: Registry | None = None, root: Path | None = None) -> None:
        self.registry = registry or get_registry()
        self.root = root or FINDINGS_DIR
        self._by_uri: dict[str, Document] | None = None
        self._by_rule: dict[str, Document] | None = None

    # -- enumeration -------------------------------------------------------

    def documents(self) -> list[Document]:
        """Every document, top docs first, then playbooks by data type and slug."""
        return list(self._index().values())

    def playbooks(self) -> list[Document]:
        return [d for d in self.documents() if d.kind == "playbook"]

    def _index(self) -> dict[str, Document]:
        if self._by_uri is not None:
            return self._by_uri

        index: dict[str, Document] = {}
        for stem, description in TOP_DOCUMENTS:
            path = self.root / f"{stem}.md"
            if not path.is_file():
                continue
            index[f"{URI_PREFIX}{stem}"] = Document(
                uri=f"{URI_PREFIX}{stem}",
                path=path,
                kind="top",
                title=_title(path),
                description=description,
            )

        statistical = self.root / "statistical" / "README.md"
        if statistical.is_file():
            uri = f"{URI_PREFIX}statistical/README"
            index[uri] = Document(
                uri=uri,
                path=statistical,
                kind="statistical",
                title=_title(statistical),
                description=(
                    "Treatment for aperf's other findings engine, which compares every metric's "
                    "8 stats in the browser and serializes nothing. Covers the 752 of 802 "
                    "metrics that have no analytical rule"
                ),
                data_type="statistical",
                slug="README",
            )

        entries = sorted(
            self.registry.by_rule_name.values(), key=lambda e: (e["data_type"], e["slug"])
        )
        for entry in entries:
            path = self.root / entry["playbook"]
            if not path.is_file():
                continue
            uri = f"{URI_PREFIX}{entry['data_type']}/{entry['slug']}"
            index[uri] = Document(
                uri=uri,
                path=path,
                kind="playbook",
                title=entry["rule_name"],
                description=(
                    f"Prescriptive playbook for the {entry['data_type']} finding "
                    f"'{entry['rule_name']}' ({entry['base_score']}, fires when "
                    f"{entry['condition']})"
                ),
                rule_name=entry["rule_name"],
                data_type=entry["data_type"],
                slug=entry["slug"],
            )

        self._by_uri = index
        self._by_rule = {d.rule_name: d for d in index.values() if d.rule_name}
        return index

    # -- lookup ------------------------------------------------------------

    def get(self, uri: str) -> Document:
        """Resolve a `aperf://findings/...` URI.

        Only URIs this library itself advertises resolve. Nothing is derived from the URI text
        beyond a dictionary lookup, so no `..` or absolute path in a URI can reach a file
        outside the tree.
        """
        document = self._index().get(str(uri))
        if document is None:
            raise PlaybookNotFound(str(uri))
        return document

    def for_rule(self, rule_name: str) -> Document:
        """The playbook for an exact `rule_name`. The join key is byte-exact (SCHEMA.md rule 1)."""
        self._index()
        assert self._by_rule is not None
        document = self._by_rule.get(rule_name)
        if document is None:
            raise PlaybookNotFound(rule_name)
        return document

    def uri_for_rule(self, rule_name: str) -> str | None:
        """The playbook URI for a rule, or None when the rule is unknown to the registry."""
        try:
            return self.for_rule(rule_name).uri
        except PlaybookNotFound:
            return None

    # -- section access ----------------------------------------------------

    def sections(self, document: Document) -> dict[str, str]:
        """`{section title: body}` for one document, frontmatter stripped.

        Bodies keep their own markdown — nested `### ` headings, tables, and the fenced decision
        tree are all part of the instruction and must survive intact.
        """
        return split_sections(document.read())

    def evidence_section(self, document: Document) -> tuple[str, str] | None:
        """`(title, body)` of the playbook's evidence section, or None when it has none.

        Worth surfacing alongside any section a consumer asks for: this is where a playbook
        records that the number in the description does not mean what it appears to — a p99 that
        is really the maximum, a gauge run through a delta, a metric blind to stores on Intel.
        """
        for title, body in self.sections(document).items():
            if title.startswith(EVIDENCE_SECTION_STEMS):
                return title, body
        return None

    def priority(self, rule_name: str) -> str:
        """The playbook's own priority claim for a rule, e.g. `P2 — Investigate`, or `""`.

        The playbook is the authority on what to act on first — aperf's `score` is a deviation
        magnitude, not a severity — so anything that ranks findings reads it from here rather
        than mapping a score onto a severity word of its own.
        """
        try:
            body = self.sections(self.for_rule(rule_name)).get("Priority and execution risk", "")
        except PlaybookNotFound:
            return ""
        match = _PRIORITY_RE.search(body)
        return f"{match.group(1)} — {match.group(2).strip()}" if match else ""

    def execution_risk(self, rule_name: str) -> str:
        """The playbook's execution-risk claim for a rule, e.g. `R0 — Read-only`, or `""`."""
        try:
            body = self.sections(self.for_rule(rule_name)).get("Priority and execution risk", "")
        except PlaybookNotFound:
            return ""
        match = _RISK_RE.search(body)
        return f"{match.group(1)} — {match.group(2).strip()}" if match else ""

    def section(self, rule_name: str, section: str) -> str:
        """One named section of one rule's playbook.

        Raises `PlaybookNotFound` naming the sections that do exist, because a silently empty
        section reads exactly like a section with nothing to say.
        """
        document = self.for_rule(rule_name)
        found = self.sections(document)
        if section not in found:
            raise PlaybookNotFound(
                f"{document.uri} has no section {section!r}; it has {sorted(found)}"
            )
        return found[section]


def split_sections(text: str) -> dict[str, str]:
    """Split playbook markdown on its `## ` headings, in file order."""
    body = _FRONTMATTER_RE.sub("", text)
    matches = list(_SECTION_RE.finditer(body))
    sections: dict[str, str] = {}
    for n, match in enumerate(matches):
        end = matches[n + 1].start() if n + 1 < len(matches) else len(body)
        sections[match.group(1).strip()] = body[match.end() : end].strip()
    return sections


def _title(path: Path) -> str:
    match = _TITLE_RE.search(_FRONTMATTER_RE.sub("", path.read_text(encoding="utf-8")))
    return match.group(1).strip() if match else path.stem


_LIBRARY: PlaybookLibrary | None = None


def get_library() -> PlaybookLibrary:
    """Process-wide library, built once."""
    global _LIBRARY
    if _LIBRARY is None:
        _LIBRARY = PlaybookLibrary()
    return _LIBRARY
