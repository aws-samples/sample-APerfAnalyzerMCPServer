# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Parser for CPU utilization data from aperf.

CPU data structure (from aperf report output):
- Aggregate CPU utilization (user, system, iowait, idle, etc.)
- Per-CPU utilization breakdown
- Time series at collection interval granularity
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class CpuSummary:
    """Summary statistics for CPU utilization."""

    avg_user_pct: float = 0.0
    avg_system_pct: float = 0.0
    avg_iowait_pct: float = 0.0
    avg_idle_pct: float = 0.0
    avg_irq_pct: float = 0.0
    avg_softirq_pct: float = 0.0
    peak_utilization_pct: float = 0.0
    avg_total_utilization_pct: float = 0.0
    cpu_count: int = 0
    # Variance indicators
    utilization_stddev: float = 0.0
    # Per-CPU imbalance (max - min across CPUs)
    cpu_imbalance_pct: float = 0.0


class CpuUtilizationParser:
    """Parse and summarize CPU utilization data from aperf runs."""

    def parse_from_report_data(self, data: dict[str, Any]) -> CpuSummary | None:
        """Parse CPU data from aperf report JSON structure."""
        if not data:
            return None

        try:
            return self._parse_from_report_data(data)
        except (TypeError, AttributeError, ValueError, ZeroDivisionError, KeyError):
            # `data` is capture-derived, not something this process produced -- a malformed or
            # adversarial report (e.g. "aggregate" holding a string instead of a dict) must not
            # raise into the calling tool handler, none of which wrap this call in a try/except.
            return None

    def _parse_from_report_data(self, data: dict[str, Any]) -> CpuSummary | None:
        summary = CpuSummary()

        # Aperf report exports CPU data as time-series arrays
        cpu_data = data.get("cpu_utilization", {})
        if not cpu_data:
            return None

        # Aggregate metrics
        if "aggregate" in cpu_data:
            agg = cpu_data["aggregate"]
            samples = len(agg.get("user", []))
            if samples > 0:
                summary.avg_user_pct = sum(agg.get("user", [])) / samples
                summary.avg_system_pct = sum(agg.get("system", [])) / samples
                summary.avg_iowait_pct = sum(agg.get("iowait", [])) / samples
                summary.avg_idle_pct = sum(agg.get("idle", [])) / samples
                summary.avg_irq_pct = sum(agg.get("irq", [])) / samples
                summary.avg_softirq_pct = sum(agg.get("softirq", [])) / samples

                total_util = [100 - idle for idle in agg.get("idle", [])]
                summary.avg_total_utilization_pct = sum(total_util) / samples

                # The FIRST sample is a collector start-up artifact and is excluded from
                # the peak.
                #
                # aperf's first CPU sample is computed against a zero baseline rather than
                # a previous reading, so it reports 100% busy regardless of what the
                # machine was doing. Verified across five real runs in ~/Downloads: every
                # one reports exactly 100.0% on sample 0, while the true peak of the
                # remainder ranges from 9.1% to 71.8%.
                #
                # This is not cosmetic. Right-sizing keys on the peak, so a spurious 100%
                # made an idle box (3.6% average) look saturated and blocked every
                # proposal to shrink it — the exact opposite of the correct answer. The
                # report's own caveats note that a whole-window mean is diluted by
                # start-up; this is the same artifact seen from the other side.
                #
                # Only dropped when there is something left to measure: a single-sample
                # run has no alternative, and reporting nothing would be worse.
                peak_samples = total_util[1:] if len(total_util) > 1 else total_util
                summary.peak_utilization_pct = max(peak_samples) if peak_samples else 0

        # Per-CPU data for imbalance detection
        if "per_cpu" in cpu_data:
            per_cpu = cpu_data["per_cpu"]
            summary.cpu_count = len(per_cpu)

            # Calculate per-CPU average utilization
            cpu_avgs = []
            for cpu_series in per_cpu.values():
                idle_series = cpu_series.get("idle", [])
                if idle_series:
                    avg_util = 100 - (sum(idle_series) / len(idle_series))
                    cpu_avgs.append(avg_util)

            if cpu_avgs:
                summary.cpu_imbalance_pct = max(cpu_avgs) - min(cpu_avgs)

        return summary

    def detect_anomalies(self, summary: CpuSummary) -> list[str]:
        """Detect CPU-related performance anomalies."""
        anomalies = []

        if summary.avg_iowait_pct > 10:
            anomalies.append(
                f"HIGH_IOWAIT: Average I/O wait at {summary.avg_iowait_pct:.1f}% "
                f"— indicates storage bottleneck"
            )

        if summary.avg_irq_pct + summary.avg_softirq_pct > 5:
            anomalies.append(
                f"HIGH_IRQ_LOAD: IRQ+SoftIRQ at "
                f"{summary.avg_irq_pct + summary.avg_softirq_pct:.1f}% "
                f"— check interrupt affinity and NIC configuration"
            )

        if summary.cpu_imbalance_pct > 30:
            anomalies.append(
                f"CPU_IMBALANCE: {summary.cpu_imbalance_pct:.1f}% spread across CPUs "
                f"— workload not evenly distributed, check thread affinity"
            )

        if summary.avg_total_utilization_pct < 50 and summary.peak_utilization_pct > 90:
            anomalies.append(
                f"BURSTY_WORKLOAD: Average {summary.avg_total_utilization_pct:.0f}% "
                f"but peaks at {summary.peak_utilization_pct:.0f}% "
                f"— consider if measurement includes idle periods"
            )

        if summary.avg_system_pct > 20:
            anomalies.append(
                f"HIGH_KERNEL_TIME: System time at {summary.avg_system_pct:.1f}% "
                f"— excessive syscalls or kernel overhead"
            )

        return anomalies
