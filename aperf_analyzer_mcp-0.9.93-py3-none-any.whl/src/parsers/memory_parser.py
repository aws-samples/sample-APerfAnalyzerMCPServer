# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Parser for memory subsystem data with symptom-detection signals."""

from dataclasses import dataclass
from typing import Any


@dataclass
class MemorySummary:
    avg_used_pct: float = 0.0
    peak_used_pct: float = 0.0
    min_used_pct: float = 0.0
    avg_available_mb: float = 0.0
    total_mb: float = 0.0
    swap_used_mb: float = 0.0
    page_faults_per_sec: float = 0.0
    numa_imbalance: bool = False

    # Symptom signals for the diagnostic playbook engine
    used_pct_variance: float = 0.0  # variance of used% over the recording
    used_pct_range: float = 0.0  # peak - min (spread)
    is_flat_line: bool = False  # near-zero variation -> static allocation
    committed_unused_mb: float = 0.0  # allocated/reserved but not actively used
    committed_unused_pct: float = 0.0  # committed_unused as % of total
    over_provisioned: bool = False  # large unused headroom + flat usage
    anon_pages_mb: float = 0.0  # anonymous (process-owned, non-file-backed) memory
    samples: int = 0


def _variance(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    return sum((v - mean) ** 2 for v in values) / len(values)


class MemoryParser:
    # Thresholds for symptom detection
    FLAT_LINE_RANGE_PCT = 3.0  # peak-min spread below this = flat
    FLAT_LINE_VARIANCE = 1.0  # variance below this = flat
    OVER_PROVISION_UNUSED_PCT = 40.0  # >40% of RAM sits unused + flat = over-provisioned

    def parse_from_report_data(self, data: dict[str, Any]) -> MemorySummary | None:
        try:
            return self._parse_from_report_data(data)
        except (TypeError, AttributeError, ValueError, ZeroDivisionError, KeyError):
            # `data` is capture-derived, not something this process produced -- a malformed or
            # adversarial report (e.g. "meminfo" holding the wrong shape) must not raise into the
            # calling tool handler, none of which wrap this call in a try/except.
            return None

    def _parse_from_report_data(self, data: dict[str, Any]) -> MemorySummary | None:
        meminfo = data.get("meminfo", {})
        if not meminfo:
            return None
        summary = MemorySummary()

        total = meminfo.get("mem_total_kb", 0)
        available_series = meminfo.get("mem_available_kb", [])
        anon_pages_kb = meminfo.get("anon_pages_kb", 0)
        if anon_pages_kb:
            summary.anon_pages_mb = anon_pages_kb / 1024

        if total and available_series:
            used_pcts = [(1 - (a / total)) * 100 for a in available_series if total > 0]
            if used_pcts:
                summary.samples = len(used_pcts)
                summary.avg_used_pct = sum(used_pcts) / len(used_pcts)
                summary.peak_used_pct = max(used_pcts)
                summary.min_used_pct = min(used_pcts)
                summary.avg_available_mb = (sum(available_series) / len(available_series)) / 1024
                summary.total_mb = total / 1024

                # Variability signals
                summary.used_pct_variance = _variance(used_pcts)
                summary.used_pct_range = summary.peak_used_pct - summary.min_used_pct

                # Flat-line: usage barely moves across the whole recording.
                # Needs at least a few samples to be meaningful.
                if summary.samples >= 5:
                    summary.is_flat_line = (
                        summary.used_pct_range < self.FLAT_LINE_RANGE_PCT
                        and summary.used_pct_variance < self.FLAT_LINE_VARIANCE
                    )

                # Committed-but-unused: RAM that is provisioned but the workload
                # never touches. Approximated as available memory that stays
                # available throughout (min available across the window).
                min_avail_kb = min(available_series)
                summary.committed_unused_mb = min_avail_kb / 1024
                if total > 0:
                    summary.committed_unused_pct = (min_avail_kb / total) * 100

                # Over-provisioned: large unused headroom AND flat usage means
                # the instance has far more memory than the workload needs.
                summary.over_provisioned = (
                    summary.committed_unused_pct >= self.OVER_PROVISION_UNUSED_PCT
                    and (summary.is_flat_line or summary.used_pct_range < 10.0)
                )

        # Swap
        swap_total = meminfo.get("swap_total_kb", 0)
        swap_free = meminfo.get("swap_free_kb", 0)
        if swap_total:
            summary.swap_used_mb = (swap_total - swap_free) / 1024

        return summary

    def detect_anomalies(self, summary: MemorySummary) -> list[str]:
        anomalies = []
        if summary.peak_used_pct > 90:
            anomalies.append(f"MEMORY_PRESSURE: Peak usage at {summary.peak_used_pct:.1f}%")
        if summary.swap_used_mb > 100:
            anomalies.append(
                f"SWAP_ACTIVE: {summary.swap_used_mb:.0f}MB in swap — severe performance impact"
            )
        if summary.over_provisioned:
            anomalies.append(
                f"MEMORY_OVER_PROVISIONED: {summary.committed_unused_pct:.0f}% of RAM "
                f"({summary.committed_unused_mb:.0f}MB) unused with flat usage profile"
            )
        elif summary.is_flat_line and summary.committed_unused_pct >= 25:
            anomalies.append(
                f"MEMORY_FLAT_LINE: Usage static at ~{summary.avg_used_pct:.0f}% "
                f"with {summary.committed_unused_pct:.0f}% headroom unused"
            )
        return anomalies
