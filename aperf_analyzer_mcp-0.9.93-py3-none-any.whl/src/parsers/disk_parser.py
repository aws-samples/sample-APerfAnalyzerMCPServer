# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Parser for per-disk I/O statistics from aperf's `diskstats` collector, plus process/
profile summary stubs (see their own classes below).

`report_data["diskstats"]` (report-JS layout only — the flat-binary layout has no
diskstats parsing anywhere in this codebase today, confirmed by grep against
`run_parser.py`; `parse_from_report_data` correctly returns `None` for that layout,
since there is genuinely nothing to read) is metric-name-keyed, NOT pre-aggregated the
way `cpu_utilization`/`meminfo` are: `{"<metric>": {"series": [{"series_name":
"<device>", "values": [...]}]}}`, one series per block device per metric. This module
does its own per-device grouping across metrics, matching the SAME `series_name`-keyed
iteration style `config_diagnosis.py::_detect_worker_imbalance` already uses for
`processes`, rather than the pre-flattened `data["aggregate"]` style `cpu_parser.py`
uses (nothing upstream reshapes diskstats the way it reshapes CPU/memory).

Real Linux `/proc/diskstats` field semantics (aperf's field names in parentheses),
verified directly against a real saturated capture (`nvme1n1` on a `c6a.xlarge` under
real EBS pressure — `time_in_progress` averaged ~983ms per ~1000ms interval,
`weighted_time_in_progress` averaged ~51,111ms, i.e. ~51 average queue depth):

- `reads`/`writes` (fields 1/5) — I/O operations completed. aperf's own values are
  ALREADY per-interval deltas (verified: they hover around a stable count per sample,
  not monotonically increasing), so no diffing against a previous sample is needed.
- `sectors_read`/`sectors_written` (fields 3/7) — sectors transferred; 1 sector = 512
  bytes, the fixed Linux convention regardless of the device's actual block size.
- `time_reading`/`time_writing` (fields 4/8) — milliseconds spent on reads/writes.
- `in_progress` (field 9) — I/Os in flight at sample time (instantaneous, not a rate).
- `time_in_progress` (field 10) — ms spent with at least one I/O in flight this
  interval. `%util = time_in_progress / interval_ms * 100` — the standard `iostat`
  formula.
- `weighted_time_in_progress` (field 11) — ms weighted by queue length.
  `avg_queue_depth = weighted_time_in_progress / interval_ms` — the standard `iostat`
  `avgqu-sz` formula.
"""

from dataclasses import dataclass, field
from typing import Any

#: aperf's default collection interval (`aperf record -i 1`). `parse_from_report_data`
#: has no metadata parameter (matches `CpuUtilizationParser`'s existing signature), so
#: this is an explicit, documented assumption rather than a silent one — pass a real
#: `interval_seconds` when the caller has it (`run_data.metadata.interval_seconds`).
_DEFAULT_INTERVAL_SECONDS = 1.0

#: Pseudo/virtual devices that are never the real, EBS-backed volume a customer cares
#: about — excluded so a container's loopback-mounted overlay or a dm-crypt mapper
#: layer doesn't dilute the real device's saturation numbers. Same `_is_noise`-style
#: exclusion-by-prefix pattern `language_detector.py` already establishes for process
#: names, applied here to device names.
_PSEUDO_DEVICE_PREFIXES = ("loop", "dm-", "ram")


def _is_primary_device(name: str) -> bool:
    if name.startswith(_PSEUDO_DEVICE_PREFIXES):
        return False
    # Whole-disk NVMe devices look like "nvme0n1"; partitions add "p<N>" — e.g.
    # "nvme0n1p1". Only the whole-disk device is kept for the primary summary: Linux
    # attributes a partition's I/O to both the partition and the whole-disk device, so
    # counting both would double-count the same physical I/O.
    return not (name.startswith("nvme") and "n" in name[4:] and "p" in name.split("n", 2)[-1])


@dataclass
class DiskSummary:
    avg_read_mbps: float = 0.0
    avg_write_mbps: float = 0.0
    avg_iops: float = 0.0
    avg_queue_depth: float = 0.0
    avg_await_ms: float = 0.0
    avg_utilization_pct: float = 0.0
    peak_utilization_pct: float = 0.0
    device_count: int = 0
    #: The single busiest real device — the one to point a reader at when several
    #: devices exist (e.g. root volume idle, data volume saturated).
    busiest_device: str = ""


class DiskParser:
    """Parse and summarize per-disk I/O statistics from aperf runs."""

    def parse_from_report_data(
        self, data: dict[str, Any], interval_seconds: float = _DEFAULT_INTERVAL_SECONDS
    ) -> DiskSummary | None:
        diskstats = data.get("diskstats") if data else None
        if not diskstats:
            return None

        def _series_by_device(metric: str) -> dict[str, list[float]]:
            block = diskstats.get(metric) or {}
            return {
                s["series_name"]: [v for v in s.get("values", []) if isinstance(v, (int, float))]
                for s in block.get("series", [])
                if s.get("series_name")
            }

        time_in_progress = _series_by_device("time_in_progress")
        weighted_tip = _series_by_device("weighted_time_in_progress")
        time_reading = _series_by_device("time_reading")
        time_writing = _series_by_device("time_writing")
        reads = _series_by_device("reads")
        writes = _series_by_device("writes")
        sectors_read = _series_by_device("sectors_read")
        sectors_written = _series_by_device("sectors_written")

        devices = [d for d in time_in_progress if _is_primary_device(d)]
        if not devices:
            return None

        interval_ms = interval_seconds * 1000.0
        util_by_device: dict[str, float] = {}
        peak_util_by_device: dict[str, float] = {}
        queue_depth_by_device: dict[str, float] = {}
        await_by_device: dict[str, float] = {}
        iops_by_device: dict[str, float] = {}
        read_mbps_by_device: dict[str, float] = {}
        write_mbps_by_device: dict[str, float] = {}

        for dev in devices:
            tip_vals = time_in_progress.get(dev, [])
            if tip_vals:
                util_by_device[dev] = (sum(tip_vals) / len(tip_vals)) / interval_ms * 100
                peak_util_by_device[dev] = max(tip_vals) / interval_ms * 100

            wtip_vals = weighted_tip.get(dev, [])
            if wtip_vals:
                queue_depth_by_device[dev] = (sum(wtip_vals) / len(wtip_vals)) / interval_ms

            r_vals = reads.get(dev, [])
            w_vals = writes.get(dev, [])
            tr_vals = time_reading.get(dev, [])
            tw_vals = time_writing.get(dev, [])
            if r_vals and w_vals and tr_vals and tw_vals:
                n = min(len(r_vals), len(w_vals), len(tr_vals), len(tw_vals))
                total_io = sum(r_vals[:n]) + sum(w_vals[:n])
                total_time_ms = sum(tr_vals[:n]) + sum(tw_vals[:n])
                if total_io > 0:
                    await_by_device[dev] = total_time_ms / total_io
                if n > 0:
                    iops_by_device[dev] = total_io / (n * interval_seconds)

            sr_vals = sectors_read.get(dev, [])
            if sr_vals:
                total_sectors = sum(sr_vals)
                window_seconds = len(sr_vals) * interval_seconds
                if window_seconds > 0:
                    # 1 sector = 512 bytes (fixed Linux convention); MB = 1e6 bytes.
                    read_mbps_by_device[dev] = total_sectors * 512 / window_seconds / 1e6

            sw_vals = sectors_written.get(dev, [])
            if sw_vals:
                total_sectors = sum(sw_vals)
                window_seconds = len(sw_vals) * interval_seconds
                if window_seconds > 0:
                    write_mbps_by_device[dev] = total_sectors * 512 / window_seconds / 1e6

        if not util_by_device:
            return None

        busiest = max(util_by_device, key=lambda d: util_by_device[d])

        return DiskSummary(
            avg_read_mbps=sum(read_mbps_by_device.values()),
            avg_write_mbps=sum(write_mbps_by_device.values()),
            avg_iops=sum(iops_by_device.values()),
            avg_queue_depth=queue_depth_by_device.get(busiest, 0.0),
            avg_await_ms=await_by_device.get(busiest, 0.0),
            avg_utilization_pct=util_by_device[busiest],
            peak_utilization_pct=peak_util_by_device.get(busiest, 0.0),
            device_count=len(devices),
            busiest_device=busiest,
        )

    def detect_anomalies(self, summary: DiskSummary) -> list[str]:
        """
        Thresholds anchored to the standard `iostat` interpretation of these exact
        fields (util%/avgqu-sz/await), not generic guidance: `%util` near 100 means the
        device had at least one I/O in flight essentially the whole interval (queue
        never empties), and `avgqu-sz` above ~4 on typical cloud block storage
        indicates sustained queuing rather than momentary bursts. Verified against the
        real `ebs-baseline` capture: `nvme1n1` measured ~98% util and ~51 avg queue
        depth — both thresholds below fire correctly on that real saturated device.
        """
        anomalies = []
        if summary.avg_utilization_pct > 90:
            anomalies.append(
                f"DISK_SATURATION: {summary.busiest_device} at "
                f"{summary.avg_utilization_pct:.0f}% utilization — the device had an "
                f"I/O in flight nearly the entire capture window"
            )
        if summary.avg_queue_depth > 4:
            anomalies.append(
                f"DISK_QUEUE_DEPTH_HIGH: {summary.busiest_device} averaging "
                f"{summary.avg_queue_depth:.1f} queued I/Os — requests are queuing, "
                f"not completing as fast as they arrive"
            )
        if summary.avg_await_ms > 10:
            anomalies.append(
                f"HIGH_IO_LATENCY: {summary.busiest_device} averaging "
                f"{summary.avg_await_ms:.1f}ms per I/O"
            )
        return anomalies


@dataclass
class ProcessSummary:
    # See `InterruptSummary.top_interrupt_lines` for why these are `default_factory` and not
    # `= None`. Nothing in the tree populates them yet — these three parsers are the stubs this
    # module's docstring names — so the element type is the loosest thing that is still honest.
    top_processes: list[dict[str, Any]] = field(default_factory=list)
    total_processes: int = 0


class ProcessParser:
    def parse_from_report_data(self, data: dict[str, Any]) -> ProcessSummary | None:
        processes = data.get("processes", {})
        if not processes:
            return None
        return ProcessSummary()


@dataclass
class ProfileSummary:
    top_functions: list[dict[str, Any]] = field(default_factory=list)
    hot_modules: list[dict[str, Any]] = field(default_factory=list)
    total_samples: int = 0


class ProfileParser:
    def parse_from_report_data(self, data: dict[str, Any]) -> ProfileSummary | None:
        profile = data.get("perf_profile", data.get("java_profile", {}))
        if not profile:
            return None
        return ProfileSummary()
