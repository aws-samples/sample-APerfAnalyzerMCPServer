# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Parser for interrupt data — critical for detecting IPI storms and IRQ imbalances."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class InterruptSummary:
    total_interrupts_per_sec: float = 0.0
    ipi_per_sec: float = 0.0
    # `field(default_factory=list)` rather than `= None` plus a `__post_init__` guard: the field is
    # never anything but a list, and the old form annotated it `list` while defaulting to `None`,
    # which is the one value the annotation excluded. Matches `FlamegraphSummary`.
    top_interrupt_lines: list[dict[str, Any]] = field(default_factory=list)
    irq_imbalance_detected: bool = False


class InterruptParser:
    def parse_from_report_data(self, data: dict[str, Any]) -> InterruptSummary | None:
        interrupts = data.get("interrupts", {})
        if not interrupts:
            return None
        summary = InterruptSummary()
        # Parse interrupt time series
        ipi_data = interrupts.get("IPI0", interrupts.get("RES", {}))
        if isinstance(ipi_data, list) and len(ipi_data) > 1:
            # Rate = delta between samples
            rates = [ipi_data[i] - ipi_data[i - 1] for i in range(1, len(ipi_data))]
            summary.ipi_per_sec = sum(rates) / len(rates) if rates else 0
        return summary

    def detect_anomalies(self, summary: InterruptSummary) -> list[str]:
        anomalies = []
        if summary.ipi_per_sec > 100000:
            anomalies.append(
                f"IPI_STORM: {summary.ipi_per_sec:.0f} IPIs/sec — "
                "excessive cross-CPU communication. Check scheduler patches, "
                "NUMA topology, and kernel version."
            )
        return anomalies
