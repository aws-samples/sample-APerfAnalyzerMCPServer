# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Version Compatibility Matrix

Different language/runtime versions expose different levels of detail
to system-level profilers like aperf. This module tracks known limitations
so the advisory system can warn users when their runtime version limits
what aperf can see.

Key insight: If aperf can't see process-level details, it's often a
runtime version issue, not a data collection failure.
"""

from dataclasses import dataclass
from typing import Any


@dataclass
class VersionConstraint:
    """Describes a version-specific limitation or feature."""

    language: str
    min_version: str  # Minimum version for feature
    feature: str
    description: str
    impact_on_aperf: str
    workaround: str | None = None


# Known version constraints affecting aperf data quality
VERSION_CONSTRAINTS: list[VersionConstraint] = [
    # Python
    VersionConstraint(
        language="python",
        min_version="3.9",
        feature="detailed_process_info",
        description="Python < 3.9 does not expose per-thread names to /proc, "
        "making process-level attribution in aperf unreliable",
        impact_on_aperf="Process data shows generic 'python3' entries without "
        "thread differentiation. Cannot distinguish worker threads.",
        workaround="Upgrade to Python 3.9+ or use multiprocessing (separate PIDs visible)",
    ),
    VersionConstraint(
        language="python",
        min_version="3.12",
        feature="perf_trampoline",
        description="Python 3.12+ supports perf trampolines for native profiling integration",
        impact_on_aperf="With 3.12+ and PYTHONPERFSUPPORT=1, perf/aperf can see "
        "Python function names in profiles (not just C frames)",
        workaround="Set PYTHONPERFSUPPORT=1 env var (Python 3.12+) or use py-spy separately",
    ),
    VersionConstraint(
        language="python",
        min_version="3.13",
        feature="free_threading",
        description="Python 3.13+ experimental free-threading mode (no GIL)",
        impact_on_aperf="With free-threading, expect to see true multi-core utilization "
        "in aperf instead of single-core saturation pattern",
        workaround=None,
    ),
    # Java
    VersionConstraint(
        language="java",
        min_version="11",
        feature="flight_recorder",
        description="JDK 11+ includes JFR (Java Flight Recorder) as open-source",
        impact_on_aperf="JFR data can complement aperf with JVM-internal metrics",
        workaround="Use async-profiler for JDK < 11",
    ),
    VersionConstraint(
        language="java",
        min_version="17",
        feature="enhanced_pmu_correlation",
        description="JDK 17+ with -XX:+UnlockDiagnosticVMOptions -XX:+DumpPerfMapAtExit "
        "writes /tmp/perf-<pid>.map for symbol resolution",
        impact_on_aperf="Without perf map, aperf profile shows JIT'd code as '[unknown]'. "
        "With it, function-level attribution is possible.",
        workaround="Use async-profiler which handles symbol resolution internally",
    ),
    VersionConstraint(
        language="java",
        min_version="21",
        feature="virtual_threads",
        description="JDK 21+ Virtual Threads (Project Loom) change thread scheduling model",
        impact_on_aperf="Virtual threads don't map 1:1 to OS threads. aperf process data "
        "shows fewer OS threads but higher per-thread utilization.",
        workaround=None,
    ),
    # PHP
    VersionConstraint(
        language="php",
        min_version="7.4",
        feature="preloading",
        description="PHP 7.4+ supports opcache.preload for loading code at startup",
        impact_on_aperf="Preloaded code has lower syscall overhead at request time. "
        "Without preloading, aperf shows high system time from file access.",
        workaround="Use opcache without preloading (still good, just more file I/O)",
    ),
    VersionConstraint(
        language="php",
        min_version="8.0",
        feature="jit_compilation",
        description="PHP 8.0+ OPcache JIT fundamentally changes the PMU profile",
        impact_on_aperf="With JIT: lower branch misses, higher IPC, reduced frontend stalls. "
        "Without JIT: PHP's interpreter loop dominates branch miss metrics.",
        workaround="Enable JIT: opcache.jit=1255 and opcache.jit_buffer_size=128M",
    ),
    VersionConstraint(
        language="php",
        min_version="8.1",
        feature="fibers",
        description="PHP 8.1+ Fibers enable cooperative multitasking within workers",
        impact_on_aperf="Fiber-based frameworks (Amp, ReactPHP) show different process "
        "patterns than traditional FPM — fewer workers, higher utilization each.",
        workaround=None,
    ),
    # Go
    VersionConstraint(
        language="go",
        min_version="1.21",
        feature="pgo_support",
        description="Go 1.21+ has production-ready PGO support",
        impact_on_aperf="PGO-built Go binaries show improved branch prediction and IPC in aperf",
        workaround="Standard optimization without PGO for Go < 1.21",
    ),
    VersionConstraint(
        language="go",
        min_version="1.19",
        feature="gomemlimit",
        description="Go 1.19+ supports GOMEMLIMIT for soft memory limit",
        impact_on_aperf="Without GOMEMLIMIT in containers, Go may OOM or trigger aggressive GC "
        "visible as CPU spikes in aperf",
        workaround="Set GOGC to higher value and monitor memory manually",
    ),
    # Node.js
    VersionConstraint(
        language="nodejs",
        min_version="16",
        feature="perf_hooks_histogram",
        description="Node.js 16+ has detailed perf_hooks with histograms",
        impact_on_aperf="Node.js < 16 has limited process-level metrics. "
        "Upgrade for better correlation with aperf system data.",
        workaround="Use clinic.js for Node.js < 16 profiling",
    ),
    VersionConstraint(
        language="nodejs",
        min_version="18",
        feature="fetch_api_native",
        description="Node.js 18+ has native fetch (undici-based) which has different "
        "I/O patterns than http/https module",
        impact_on_aperf="Native fetch uses fewer syscalls, different epoll patterns "
        "visible in aperf system time.",
        workaround=None,
    ),
    # .NET
    VersionConstraint(
        language="dotnet",
        min_version="7",
        feature="native_aot",
        description=".NET 7+ has production-ready NativeAOT",
        impact_on_aperf="NativeAOT binaries look like native C code to aperf — "
        "direct function attribution without JIT symbol resolution issues.",
        workaround="Use crossgen2 for ReadyToRun on .NET 6",
    ),
    VersionConstraint(
        language="dotnet",
        min_version="8",
        feature="dynamic_pgo",
        description=".NET 8+ has enhanced Dynamic PGO enabled by default",
        impact_on_aperf="Dynamic PGO improves branch prediction over time during execution. "
        "aperf PMU data improves during warmup period.",
        workaround="Enable tiered compilation + Dynamic PGO manually on .NET 7",
    ),
    # Rust
    VersionConstraint(
        language="rust",
        min_version="1.71",
        feature="split_debuginfo",
        description="Rust 1.71+ supports split debuginfo for better perf symbol resolution",
        impact_on_aperf="Better function names in perf/aperf profile data",
        workaround="Build with debug=1 in release profile for symbol info",
    ),
    # C/C++
    VersionConstraint(
        language="cpp",
        min_version="gcc-12",
        feature="auto_pgo",
        description="GCC 12+ has improved AutoFDO support for hardware-sampled PGO",
        impact_on_aperf="Can use aperf's perf data directly for PGO feedback loop",
        workaround="Use standard instrumentation-based PGO with older GCC",
    ),
    VersionConstraint(
        language="cpp",
        min_version="clang-15",
        feature="bolt_integration",
        description="LLVM/Clang 15+ has improved BOLT integration for binary optimization",
        impact_on_aperf="BOLT post-processing of binaries reduces ITLB misses and "
        "frontend stalls visible in aperf PMU data",
        workaround="Use older BOLT from LLVM project separately",
    ),
]


def get_constraints_for_language(language: str) -> list[VersionConstraint]:
    """Get all version constraints for a language."""
    return [c for c in VERSION_CONSTRAINTS if c.language == language]


def check_version_limitations(language: str, version: str | None) -> list[dict[str, Any]]:
    """
    Check what limitations apply given a detected language and version.
    Returns list of warnings/notes about data quality.
    """
    constraints = get_constraints_for_language(language)
    # Annotated because the two shapes appended below differ: the no-version note carries a
    # nested `all_constraints` list, and the per-constraint entries carry an optional
    # `workaround`. Inferring from the first append alone rejects the second.
    warnings: list[dict[str, Any]] = []

    if not version:
        warnings.append(
            {
                "type": "info",
                "message": f"Runtime version not detected for {language}. "
                "Some aperf data may be limited depending on version.",
                "all_constraints": [
                    {
                        "min_version": c.min_version,
                        "feature": c.feature,
                        "description": c.description,
                    }
                    for c in constraints
                ],
            }
        )
        return warnings

    for constraint in constraints:
        if not _version_meets_minimum(version, constraint.min_version):
            warnings.append(
                {
                    "type": "limitation",
                    "feature": constraint.feature,
                    "required_version": constraint.min_version,
                    "detected_version": version,
                    "impact": constraint.impact_on_aperf,
                    "workaround": constraint.workaround,
                }
            )

    return warnings


def _version_meets_minimum(detected: str, minimum: str) -> bool:
    """Simple version comparison (handles semver-like strings)."""
    try:
        # Extract numeric parts
        def parse_ver(v: str) -> list[int]:
            import re

            parts = re.findall(r"\d+", v)
            return [int(p) for p in parts[:3]]  # Major.minor.patch

        detected_parts = parse_ver(detected)
        minimum_parts = parse_ver(minimum)

        # Pad to same length
        while len(detected_parts) < len(minimum_parts):
            detected_parts.append(0)
        while len(minimum_parts) < len(detected_parts):
            minimum_parts.append(0)

        return detected_parts >= minimum_parts
    except (ValueError, IndexError):
        return True  # Assume compatible if we can't parse
