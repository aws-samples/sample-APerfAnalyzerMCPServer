# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Flamegraph SVG parser for aperf reports.

Parses the Inferno-format flamegraph SVGs produced by aperf record.
Extracts:
- Top on-CPU functions by sample count (aggregated across all stack depths)
- Category breakdowns (SSL, JSON, APM overhead, AWS SDK, etc.)
- Python-specific signals (interpreter overhead, library hotspots)
- Per-library CPU percentages
- Anomaly detection with actionable messages
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class FlamegraphEntry:
    """A single function entry from the flamegraph."""

    function_name: str
    samples: int
    pct: float
    is_kernel: bool = False


@dataclass
class FlamegraphSummary:
    """Aggregated flamegraph analysis."""

    total_samples: int = 0
    top_functions: list[FlamegraphEntry] = field(default_factory=list)
    category_breakdown: dict[str, dict[str, Any]] = field(default_factory=dict)
    # Convenience percentage fields
    ssl_tls_pct: float = 0.0
    bson_pct: float = 0.0
    apm_overhead_pct: float = 0.0
    json_pct: float = 0.0
    network_syscall_pct: float = 0.0
    aws_sdk_pct: float = 0.0
    filters_dsl_pct: float = 0.0
    pymongo_pct: float = 0.0
    interpreter_pct: float = 0.0
    library_breakdown: dict[str, float] = field(default_factory=dict)
    anomalies: list[dict[str, Any]] = field(default_factory=list)
    has_python: bool = False
    python_version: str | None = None


# ---------------------------------------------------------------------------
# Category classification rules
# ---------------------------------------------------------------------------

_CATEGORIES: dict[str, list[str]] = {
    "ssl_tls": [
        "ssl",
        "x509",
        "ossl",
        "pem",
        "asn1",
        "libcrypto",
        "_ssl",
        "ssl_ctx",
        "tls",
        "x509_load",
        "x509_store",
    ],
    "bson_mongodb": [
        "cbson",
        "element_to_dict",
        "get_value",
        "_cbson_decode",
        "bson",
        "lmongo",
        "document.from_mongo",
        "document.__setattr__",
        "document.__init__",
    ],
    "apm_instrumentation": [
        "elasticapm",
        "elastic_apm",
        "capture_span",
        "iter_stack_frames",
        "begin_span",
        "transaction",
        "pymongoinstru",
        "pymongocursor",
    ],
    "json_serialization": [
        "_json.cpython",
        "orjson",
        "ujson",
        "simplejson",
        "decode_object",
        "decode_array",
        "jsontooobj",
        "json_decodeobject",
    ],
    "network_syscalls": [
        "epoll",
        "recv",
        "send",
        "socket",
        "net_rx",
        "napi",
        "tcp",
        "ena_io",
        "__napi_poll",
        "net_rx_action",
    ],
    "valkey_redis": [
        "valkey",
        "glide",
        "libglide",
        "redis",
        "hiredis",
    ],
    "aws_sdk": [
        "botocore",
        "boto3",
        "sigv4",
        "_make_api_call",
        "endpoint.make_request",
        "requestsigner",
        "baseimds",
    ],
    "filters_dsl": [
        "filters_dsl",
        "dynamicfilter",
        "expression.__init__",
        "expression.eval",
        "inoperator",
        "reverseinoperator",
        "handle_conditionals",
        "handle_lists",
    ],
    "pymongo_driver": [
        "pymongo",
        "mongo_client",
        "_csot",
        "csot_wrapper",
        "cursor._refresh",
        "cursor._send",
    ],
}

# Anomaly thresholds: category -> (threshold_pct, severity, message, fix)
_ANOMALY_RULES: list[dict[str, Any]] = [
    {
        "category": "ssl_tls",
        "threshold": 2.0,
        "severity": "critical",
        "message": "SSL/TLS context is being rebuilt on every request",
        "fix": (
            "Create the SSLContext once at module level and reuse it. "
            "For in-mesh service calls behind Istio/Envoy, switch to plain HTTP "
            "and let Envoy handle mTLS transparently."
        ),
    },
    {
        "category": "apm_instrumentation",
        "threshold": 3.0,
        "severity": "high",
        "message": "APM instrumentation overhead exceeds 3% of total CPU",
        "fix": (
            "Set ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION=50ms, "
            "ELASTIC_APM_TRANSACTION_SAMPLE_RATE=0.1, "
            "ELASTIC_APM_STACK_TRACE_LIMIT=50. "
            "These three env vars recover the full overhead with no code changes."
        ),
    },
    {
        "category": "filters_dsl",
        "threshold": 10.0,
        "severity": "critical",
        "message": "DSL filter evaluation is the top CPU hotspot",
        "fix": (
            "Expression.__init__ appearing in the flamegraph hot path means "
            "the expression tree is being rebuilt on every request. "
            "Cache the compiled Expression object at construction time and reuse it. "
            "Also check whether transaction_count or is_new_device are being "
            "called inline during evaluation — these should be pre-fetched."
        ),
    },
    {
        "category": "aws_sdk",
        "threshold": 3.0,
        "severity": "critical",
        "message": "AWS SDK calls appear on the hot request path",
        "fix": (
            "Identify which AWS service is called per request (AppConfig, "
            "Secrets Manager, SSM are most common). "
            "Add in-process TTL caching with a 60-second refresh interval. "
            "SigV4 signing is computed on every call — caching eliminates this entirely."
        ),
    },
    {
        "category": "bson_mongodb",
        "threshold": 2.0,
        "severity": "high",
        "message": "BSON deserialization is significant — full documents being deserialized",
        "fix": (
            "Add MongoDB projection parameters to return only required fields. "
            "If the lmongo ODM is in use, Document.from_mongo cost scales "
            "linearly with field count. Reducing fields returned reduces "
            "deserialization work proportionally."
        ),
    },
    {
        "category": "ssl_tls",
        "threshold": 0.5,
        "severity": "warning",
        "message": "Low but non-zero SSL/TLS context activity detected",
        "fix": "Verify SSLContext is cached at module level, not created per-request.",
    },
]


class FlamegraphParser:
    """Parses aperf flamegraph SVG files produced by aperf report."""

    def parse_file(self, svg_path: Path) -> FlamegraphSummary:
        """Parse a flamegraph SVG file and return a summary."""
        if not svg_path.exists():
            return FlamegraphSummary()
        content = svg_path.read_text(encoding="utf-8", errors="replace")
        return self._parse_svg(content)

    def parse_content(self, svg_content: str) -> FlamegraphSummary:
        """Parse flamegraph SVG content string directly."""
        return self._parse_svg(svg_content)

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _parse_svg(self, content: str) -> FlamegraphSummary:
        summary = FlamegraphSummary()

        # Total samples from SVG attribute
        ts_match = re.search(r'total_samples="(\d+)"', content)
        if ts_match:
            summary.total_samples = int(ts_match.group(1))

        if not summary.total_samples:
            return summary

        # Extract all <title> elements — each contains "funcname (N samples, X.XX%)"
        titles = re.findall(r"<title>([^<]+)</title>", content)

        # Aggregate by function name (same function appears at multiple stack depths)
        agg: dict[str, int] = defaultdict(int)
        for title in titles:
            # Sample counts are thousands-separated once they get large — aperf 1.3.0 weights
            # perf samples by period, so every title reads `(20,202,020 samples, 0.01%)` and a
            # `(\d+)` pattern matched none of the 431 titles in a real 1.3.0 flamegraph. It also
            # silently dropped the 31 largest frames of a 1.2.2 one, which is where the hot path
            # is, so this is a fix for both versions and not only for the new one.
            m = re.search(r"\(([\d,]+) samples,\s*([0-9.]+)%\)", title)
            if not m:
                continue
            samples = int(m.group(1).replace(",", ""))
            func_name = title[: title.rfind(" (")].strip()
            agg[func_name] += samples

        total = summary.total_samples

        # Build top functions list (top 100, sorted by sample count)
        entries = sorted(agg.items(), key=lambda x: -x[1])
        summary.top_functions = [
            FlamegraphEntry(
                function_name=name,
                samples=s,
                pct=round(s / total * 100, 2),
                is_kernel=self._is_kernel_function(name),
            )
            for name, s in entries[:100]
        ]

        # Detect Python runtime presence and version
        python_marker = next(
            (n for n in agg if "libpython" in n.lower() or "python3" in n.lower()), None
        )
        # Also detect Python via its well-known C symbols
        python_c_symbols = {
            "_PyFunction_Vectorcall",
            "_PyEval_EvalFrameDefault",
            "PyObject_Vectorcall",
            "_PyObject_Call_Prepend",
            "_PyObject_MakeTpCall",
            "PyObject_Call",
        }
        if python_marker or any(sym in agg for sym in python_c_symbols):
            summary.has_python = True
            if python_marker:
                vm = re.search(r"python(\d+\.\d+)", python_marker.lower())
                if vm:
                    summary.python_version = vm.group(1)

        # Category breakdown — sum samples matching any keyword
        for cat, keywords in _CATEGORIES.items():
            cat_samples = sum(
                s for name, s in agg.items() if any(kw in name.lower() for kw in keywords)
            )
            cat_pct = round(cat_samples / total * 100, 2)
            summary.category_breakdown[cat] = {
                "samples": cat_samples,
                "pct": cat_pct,
                "top_functions": [
                    {"function": name, "pct": round(s / total * 100, 2)}
                    for name, s in sorted(agg.items(), key=lambda x: -x[1])
                    if any(kw in name.lower() for kw in keywords)
                ][:5],
            }

        # Populate convenience pct fields
        summary.ssl_tls_pct = summary.category_breakdown.get("ssl_tls", {}).get("pct", 0.0)
        summary.bson_pct = summary.category_breakdown.get("bson_mongodb", {}).get("pct", 0.0)
        summary.apm_overhead_pct = summary.category_breakdown.get("apm_instrumentation", {}).get(
            "pct", 0.0
        )
        summary.json_pct = summary.category_breakdown.get("json_serialization", {}).get("pct", 0.0)
        summary.network_syscall_pct = summary.category_breakdown.get("network_syscalls", {}).get(
            "pct", 0.0
        )
        summary.aws_sdk_pct = summary.category_breakdown.get("aws_sdk", {}).get("pct", 0.0)
        summary.filters_dsl_pct = summary.category_breakdown.get("filters_dsl", {}).get("pct", 0.0)
        summary.pymongo_pct = summary.category_breakdown.get("pymongo_driver", {}).get("pct", 0.0)

        # Python interpreter overhead
        py_samples = sum(
            s
            for name, s in agg.items()
            if "_pyeval" in name.lower() or "python3" in name.lower() or "libpython" in name.lower()
        )
        summary.interpreter_pct = round(py_samples / total * 100, 2)

        # Library breakdown — group by .so or top-level package
        lib_agg: dict[str, int] = defaultdict(int)
        for name, s in agg.items():
            lib = self._extract_library(name)
            if lib:
                lib_agg[lib] += s
        summary.library_breakdown = {
            lib: round(s / total * 100, 2)
            for lib, s in sorted(lib_agg.items(), key=lambda x: -x[1])[:20]
        }

        # Anomaly detection — deduplicate by category (one finding per category)
        seen_cats: set[str] = set()
        for rule in _ANOMALY_RULES:
            cat = rule["category"]
            if cat in seen_cats:
                continue
            pct = summary.category_breakdown.get(cat, {}).get("pct", 0.0)
            if pct >= rule["threshold"]:
                seen_cats.add(cat)
                summary.anomalies.append(
                    {
                        "category": cat,
                        "pct": pct,
                        "severity": rule["severity"],
                        "message": rule["message"],
                        "fix": rule.get("fix", ""),
                    }
                )

        return summary

    @staticmethod
    def _is_kernel_function(name: str) -> bool:
        """Heuristic: kernel functions typically start with __ or are in brackets."""
        return name.startswith(("__", "[k]")) or (
            not name.startswith(("[", "py::")) and "::" not in name
        )

    @staticmethod
    def _extract_library(func_name: str) -> str | None:
        """Extract a short library/package name from a function symbol."""
        # [libname.so.x] style bracket notation
        m = re.match(r"\[([^\]]+\.so[^\]]*)\]", func_name)
        if m:
            lib = m.group(1).split("/")[-1]
            return re.sub(r"\.so.*", "", lib)
        # py:: prefix = Python userspace — extract top-level package from path
        if func_name.startswith("py::"):
            path_m = re.search(r"site-packages/([^/]+)", func_name)
            if path_m:
                return path_m.group(1)
            return "python_app"
        return None
