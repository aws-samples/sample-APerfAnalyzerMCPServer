# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
MCP sampling — lets THIS server ask the connected MCP CLIENT (Claude Code, Claude
Desktop, or any other host) to run a real LLM completion on the server's behalf, using
the client's own model access. Real part of the MCP spec (`sampling/createMessage`),
not a new dependency: no API key, no `anthropic`/`openai` SDK. This codebase has never
called a model directly before — every prior AI-adjacent tool
(`src/mcp_tools/sysctl_ai_fallback.py`) instead hands a prompt to the CALLING agent to
answer itself. Sampling is the mechanism that lets a tool get a real answer back
in-process, at execution time, before its output (e.g. an HTML report) is written.

Sampling is opt-in per CLIENT: the client declares a `sampling` capability during the
MCP handshake, and this server has no way to make a client support it. Every function
here therefore returns a plain (text, reason) tuple rather than raising — a client that
never declared sampling support is an ordinary, expected outcome, not an error
condition a caller must wrap in `try/except`.

`request_ctx` is `mcp`'s own module-level ContextVar (`mcp.server.lowlevel.server`), not
something `src/server.py`'s `app = Server(...)` instance owns — importing it here
creates no circular import with `server.py`, which is the only reason a tool module
(rather than `server.py` itself) can call this directly.
"""

from __future__ import annotations

from mcp.server.lowlevel.server import request_ctx
from mcp.types import SamplingMessage, TextContent

#: Exact wording the user asked this fallback to state when sampling is unavailable.
SAMPLING_NOT_ENABLED = "LLM sampling was not enabled by the connected MCP client."


def _current_session():
    """
    The live `ServerSession`, or `None` outside a request context (e.g. this function
    called from a standalone script rather than a running MCP server) — the SDK's own
    `request_ctx.get()` raises `LookupError` in that case, which is the ordinary case
    for local testing/report regeneration in this codebase, not a bug to propagate.
    """
    try:
        return request_ctx.get().session
    except LookupError:
        return None


def client_supports_sampling() -> bool:
    """True if the connected MCP client declared the `sampling` capability."""
    session = _current_session()
    if session is None:
        return False
    client_params = getattr(session, "_client_params", None)
    if client_params is None:
        return False
    capabilities = getattr(client_params, "capabilities", None)
    return bool(capabilities is not None and getattr(capabilities, "sampling", None) is not None)


async def sample_text(
    prompt: str,
    system_prompt: str | None = None,
    max_tokens: int = 512,
) -> tuple[str | None, str | None]:
    """
    Attempt a real `sampling/createMessage` call to the connected client.

    Returns `(generated_text, None)` on success, or `(None, reason)` when the client
    doesn't support sampling or the call itself fails — `reason` is
    `SAMPLING_NOT_ENABLED`, optionally with the underlying error appended, meant for
    direct display rather than a raised exception the caller must catch.
    """
    session = _current_session()
    if session is None or not client_supports_sampling():
        return None, SAMPLING_NOT_ENABLED

    try:
        result = await session.create_message(
            messages=[SamplingMessage(role="user", content=TextContent(type="text", text=prompt))],
            max_tokens=max_tokens,
            system_prompt=system_prompt,
        )
    except Exception as e:
        return None, f"{SAMPLING_NOT_ENABLED} ({e})"

    content = getattr(result, "content", None)
    text = getattr(content, "text", None)
    if not text:
        return None, f"{SAMPLING_NOT_ENABLED} (client returned no text content)"
    return text, None
