# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Canonical EC2 instance-type parser.

One parser, one place. Before this module the codebase carried four different
regexes in four files and three of them were subtly wrong:

    recommendation_engine.py  ^([a-z]+)(\\d+[a-z]*)$   then took group(1)[0]
    instance_sizer.py         ^([a-z])(\\d+[a-z]*)$    single letter only
    html_report.py            ^([a-z])(\\d+[a-z]*)\\.(\\S+)$
    run_parser.py             ^([a-z]+\\d+g[a-z]*)\\.  architecture only

The single-letter forms silently cannot see `im4gn`, `is4gen` or `hpc7g`, and the
`group(1)[0]` truncation turns `hpc7g` into `h`. Anything scanning a candidate pool
with those patterns skips whole families without saying so.

Nothing here compares a generation against a hardcoded list. The benchmark dataset is
still being filled in — it grew from 232 to 414 records in a single afternoon — so
"which generations exist" is a property of the data at runtime, never of this code.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

#: `<letters><generation><variant>` — non-greedy letters so the digits are reached.
#: Examples: c5 -> (c, 5, ''), c5a -> (c, 5, a), im4gn -> (im, 4, gn),
#: is4gen -> (is, 4, gen), i7ie -> (i, 7, ie), hpc7g -> (hpc, 7, g).
_FAMILY_RE = re.compile(r"^([a-z]+?)(\d+)([a-z]*)$")

#: Graviton test, kept byte-identical in spirit to run_parser.py's architecture
#: detection: a `g` immediately after the generation digits. `tests/test_playbook_engine.py`
#: pins the expected matches and non-matches, so this must not drift.
_GRAVITON_RE = re.compile(r"^[a-z]+\d+g[a-z]*$")


@dataclass(frozen=True)
class InstanceType:
    """A parsed instance type. `raw` always round-trips."""

    raw: str
    family: str  # "im4gn"
    letters: str  # "im"
    generation: int  # 4
    variant: str  # "gn" ("" for a base family such as c5)
    size: str  # "4xlarge", "metal-24xl", "large"
    is_graviton: bool
    is_metal: bool

    @property
    def base_family(self) -> str:
        """The family with its variant suffix removed: `c5n` -> `c5`, `im4gn` -> `im4`."""
        return f"{self.letters}{self.generation}"

    @property
    def vendor(self) -> str:
        """
        The leading vendor/architecture letter of `variant` — `a` (AMD), `i` (Intel), `g`
        (Graviton), or `""` when the family carries no vendor letter at all (e.g. `c5`).

        Kept separate from `capability_suffix` on purpose: ranking has to treat "same
        vendor, added capability" (`m6i` -> `m6in`) and "different vendor, same
        capability" (`m6i` -> `m8a`) as different KINDS of change, not the same distance.
        Collapsing both into one property would rank a same-architecture upgrade level
        with a cross-architecture migration, which is not the same decision for the
        customer — one needs no code changes, the other needs a dependency audit.
        """
        return self.variant[0] if self.variant and self.variant[0] in "aig" else ""

    @property
    def capability_suffix(self) -> str:
        """
        The variant with its leading vendor/architecture letter (`a`, `i`, or `g`) removed:
        `m6i` -> `""`, `m6a` -> `""`, `r8g` -> `""`, `r8gn` -> `"n"`, `c5n` -> `"n"`.

        `variant` conflates two unrelated things: a leading `a`/`i`/`g` names the CPU
        vendor or architecture (AMD / Intel / Graviton) and carries no capability signal on
        its own, while anything after it — `n`=network, `d`=local NVMe, `b`=?, `z`=high
        clock — names an added hardware capability neither benchmark measures. Comparing
        raw `variant` treated `r8g` (plain Graviton, nothing added) as equally "different"
        from `m6i` as `r8gn` (Graviton PLUS network-optimised) — so a plain vendor sibling
        and a specialised one tied at the same affinity rank, and price/bandwidth then
        picked the pricier specialised one for no reason tied to the workload. Comparing
        `capability_suffix` instead correctly reads `r8g` as having NO added capability
        (`""`, same as `m6i`'s vendor-only suffix) while `r8gn` still reads as having one.
        """
        for prefix in ("a", "i", "g"):
            if self.variant.startswith(prefix):
                return self.variant[len(prefix) :]
        return self.variant

    def __str__(self) -> str:
        return self.raw


def parse(instance_type: str | None) -> InstanceType | None:
    """
    Parse `<family>.<size>`, or return None when the string is not an instance type.

    Returns None rather than guessing. A caller that cannot identify the current
    instance must say so — the user's instruction is that no guidance is better than
    guidance built on a guess.
    """
    if not instance_type or "." not in instance_type:
        return None

    family, _, size = instance_type.strip().lower().partition(".")
    if not family or not size:
        return None

    m = _FAMILY_RE.match(family)
    if not m:
        return None

    letters, generation, variant = m.group(1), int(m.group(2)), m.group(3)
    return InstanceType(
        raw=instance_type.strip().lower(),
        family=family,
        letters=letters,
        generation=generation,
        variant=variant,
        size=size,
        is_graviton=bool(_GRAVITON_RE.match(family)),
        is_metal=size.startswith("metal"),
    )


def is_graviton(instance_type: str | None) -> bool:
    """True when the type is Graviton (aarch64). False for anything unparseable."""
    parsed = parse(instance_type)
    return bool(parsed and parsed.is_graviton)


def same_variant(a: InstanceType, b: InstanceType) -> bool:
    """
    Whether two types carry the same variant suffix.

    Variant affinity matters because the suffix encodes hardware the benchmark does not
    measure: `n`/`gn` are network-optimised, `d`/`ad`/`gd` have local NVMe, `e`/`en`/`ie`
    carry extra capacity. Proposing a `c5` to replace a `c5n` silently removes network
    capability the workload may depend on, and c-ray/STREAM cannot see that.
    """
    return a.variant == b.variant
