# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""APerf Analyzer MCP Server - AI-powered performance analysis for aperf data."""

__version__ = "0.9.93"
