# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""Tool: analyze_findings

Read aperf's own analytical findings out of a report and return them with the prescriptive
playbook for each, ordered by GATES.md precedence.

This tool reports what aperf concluded; it does not conclude anything itself. The 51 rules, their
thresholds, and their verdicts all come from the Rust analytics engine, and the guidance comes
from `resources/findings/`, which was written against a pinned aperf commit and is version-drift
checked. Nothing here invents a threshold or a severity.

Two things it does that a caller reading the raw JS could not
------------------------------------------------------------
1. **Applies gate precedence.** GATES.md defines 8 findings that all mean "the two runs are not
   comparable", and every other finding in a comparison report is measured against a base run
   those 8 may have just invalidated. They are returned first, in their documented resolution
   order, with the manual checks aperf has no rule for interleaved at the right points.
2. **Refuses to rank by score.** `score` is unbounded for the five amplifying templates and flat
   for the other six, so sorting by it puts a single-run observation above a blocking validity
   gate — which is exactly what the fixture reports do. Ordering is gate class first, then
   playbook priority, and the score is reported as what it is: a deviation magnitude.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from mcp.types import Tool

if TYPE_CHECKING:
    from collections.abc import Callable

    # Type-checking only, to keep the runtime imports of the four parser names below where they
    # are: the handler imports them inside the function body because `get_library()` and the
    # registry read ~50 playbook files off disk, and paying that at module import time would cost
    # every `list_tools` call. `from __future__ import annotations` above makes the annotations
    # lazy strings, so nothing in this block is evaluated at runtime.
    from ..parsers.findings_parser import Finding, FindingsReport
    from ..parsers.playbook_library import Document, PlaybookLibrary

ANALYZE_FINDINGS_TOOL = Tool(
    name="analyze_findings",
    description=(
        "Read APerf's own analytical findings from a generated report and return each one with "
        "its prescriptive playbook. Findings, thresholds and scores come from APerf's Rust "
        "analytics engine verbatim; guidance comes from the versioned playbook tree. "
        "Validity gates (the 8 findings meaning 'these runs are not comparable') are returned "
        "first in GATES.md precedence order, together with the parity checks APerf has no rule "
        "for (architecture, instance type, collection settings). "
        "Requires a report directory produced by `aperf report` — a raw `aperf record` "
        "directory contains no findings. "
        "Use this instead of interpreting APerf findings unaided: every finding comes back with "
        "the firing condition, the observed values parsed out of APerf's description, the "
        "playbook's priority and execution risk, and a `playbook_uri`. The playbook text itself "
        "is not inlined by default — read the URI as a resource for the findings you act on, or "
        "pass include_playbooks=true / sections=[...] to inline it."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "report_path": {
                "type": "string",
                "description": (
                    "Path to an aperf report directory (the one containing data/js/*.js). "
                    "Takes precedence over run_name."
                ),
            },
            "run_name": {
                "type": "string",
                "description": (
                    "Name of a report directory under data_dir, as returned by list_runs — the "
                    "same argument the other tools take. Use this or report_path: if neither is "
                    "given, the first report under data_dir in name order is used, and "
                    "`report_selected_by` in the response says so."
                ),
            },
            "data_dir": {
                "type": "string",
                "description": (
                    "Directory to search for report directories when neither report_path nor "
                    "run_name is given, and the directory run_name is resolved against. "
                    "Defaults to $APERF_DATA_DIR or ./aperf_data."
                ),
            },
            "rule_name": {
                "type": "string",
                "description": (
                    "Restrict to one finding by its exact APerf rule name, e.g. "
                    "'Underutilized CPU'. Case- and space-sensitive: it is the join key."
                ),
            },
            "data_type": {
                "type": "string",
                "description": (
                    "Restrict to one aperf data type, e.g. 'perf_stat' or 'cpu_utilization'."
                ),
            },
            "sections": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Playbook sections to inline. Pass ['all'] for whole playbooks. "
                    "Default: none — every finding carries a `playbook_uri` you read as a "
                    "resource when you get to that finding, which is cheaper than inlining "
                    "12 playbooks you may not act on. Inlining is worth it once you have "
                    "narrowed to one rule (combine with rule_name). Any playbook's evidence "
                    "section — where a finding's number is documented as not meaning what it "
                    "appears to — comes along whenever anything is inlined."
                ),
            },
            "include_playbooks": {
                "type": "boolean",
                "description": (
                    "Set true to inline the default sections ('Priority and execution risk' "
                    "and 'Decision tree') without naming them. Default false: priority, risk, "
                    "the firing condition and the observed values are always returned, and the "
                    "playbook itself is one resource read away."
                ),
            },
            "max_findings": {
                "type": "integer",
                "description": (
                    "Cap the number of findings returned, after gate-precedence ordering. "
                    "What was dropped is reported in 'truncated'. Default: no cap."
                ),
            },
        },
        "required": [],
    },
)


# ---------------------------------------------------------------------------
# Gate precedence — GATES.md
# ---------------------------------------------------------------------------

#: The 8 validity gates, in GATES.md's own resolution order, with the class each belongs to and
#: what a fired gate voids. `rank` is the step number in GATES.md's precedence block, so a gate
#: that fires sorts by the same number the document uses.
#:
#: Hardware first because the machines differ and nothing survives; then software stack, where
#: configuration findings stay valid; then workload, which is the only class with routine false
#: positives — all four are relative-ratio tests with no absolute floor, so an idle host trips
#: them on background traffic.
GATES = {
    "Inconsistent Number of CPUs": {
        "rank": 1,
        "gate_class": "hardware",
        "voids": "everything — no analysis recovers a vCPU-count difference",
    },
    "Inconsistent Physical Memory": {
        "rank": 1,
        "gate_class": "hardware",
        "voids": "everything — different machine, or different reserved-memory configuration",
    },
    "Kernel Version Mismatch": {
        "rank": 4,
        "gate_class": "software_stack",
        "voids": (
            "attribution to the application — this is a stack comparison. Configuration "
            "findings (THP, ENA Express state, tiered compilation) remain valid"
        ),
    },
    "JVM Version Comparison": {
        "rank": 4,
        "gate_class": "software_stack",
        "voids": (
            "attribution to application code — the runtime beneath it changed. Configuration "
            "findings remain valid"
        ),
    },
    "Inconsistent Inbound EFA Traffics": {
        "rank": 5,
        "gate_class": "workload",
        "voids": "throughput and per-unit comparisons, if the difference is at workload scale",
    },
    "Inconsistent Outbound EFA Traffics": {
        "rank": 5,
        "gate_class": "workload",
        "voids": "throughput and per-unit comparisons, if the difference is at workload scale",
    },
    "Inconsistent Inbound Network Traffic": {
        "rank": 5,
        "gate_class": "workload",
        "voids": "throughput and per-unit comparisons, if the difference is at workload scale",
    },
    "Inconsistent Outbound Network Traffic": {
        "rank": 5,
        "gate_class": "workload",
        "voids": "throughput and per-unit comparisons, if the difference is at workload scale",
    },
}

#: Sort rank for everything that is not a gate: after every gate, before nothing.
_DOMAIN_RANK = 7

#: Absolute floor, in bytes per interval, below which a fired workload gate is a false positive
#: (GATES.md precedence step 5). All four workload gates test `|delta| >= 10%` with no absolute
#: term, so two idle runs on one host fired both netstat gates off a 2.4 kB/s difference — the
#: inbound one scoring louder than every genuine finding in that report.
WORKLOAD_GATE_FLOOR_BYTES = 100_000

#: The parity checks aperf performs no rule for, at their GATES.md precedence positions. These
#: are the two highest-value checks in the tree precisely because nothing fires when they fail:
#: two runs on `m6i.4xlarge` and `m7g.4xlarge` produce a clean comparison with every `perf_stat`
#: counter incomparable in meaning.
MANUAL_CHECKS = [
    {
        "rank": 2,
        "check": "architecture_parity",
        "why": (
            "No analytical rule compares CPU architecture. A vendor change makes all 15 "
            "perf_stat findings incomparable in MEANING, not merely in value, and two findings "
            "(High Code Sparsity, Old-Style Atomic Instructions) can only fire on arm64."
        ),
        "how": (
            "Read the Cycles event encoding from each run's pmu_config.json: "
            "armv8_pmuv3_0/event=0x11 is arm64, cpu/event=0x3c is Intel, cpu/event=0x76 is AMD. "
            "This is data, not inference, but exists only where perf_stat was collected."
        ),
        "reference": "aperf://findings/ARCHITECTURE",
    },
    {
        "rank": 3,
        "check": "instance_type_parity",
        "why": (
            "aperf collects Instance Type and no rule compares it. This is the single largest "
            "gate gap: same vCPU count and same memory with a different CPU architecture "
            "produces zero hardware gate findings."
        ),
        "how": (
            "Compare `Instance Type` from each run's systeminfo. Any difference in family, "
            "generation, size or suffix stops the comparison even when CPUs and MemTotal match. "
            "Also compare OS Version, AMI ID and Region — all collected, none compared."
        ),
        "reference": "aperf://findings/GATES",
    },
    {
        "rank": 6,
        "check": "collection_parity",
        "why": (
            "Differing --interval/--period makes percentiles positionally incomparable, and a "
            "data type collected on only one side makes its whole finding family one-sided. "
            "Absence of a finding is never evidence of parity: several rules return early when "
            "the base run lacks the key."
        ),
        "how": (
            "Compare --interval and --period, whether perf_stat produced data on both sides, "
            "whether java_profile exists at all (it needs the hidden --save-profile-events "
            "flag), and whether kernel_config was found."
        ),
        "reference": "aperf://findings/GATES",
    },
]


def _priority_rank(priority: str) -> int:
    """`P0 — Blocking` → 0, `P4 — ...` → 4, anything unrecognised → 5.

    Reads the leading `Pn` out of the playbook's own claim, which carries its label with it.
    Unrecognised sorts last rather than first: a finding whose priority could not be read must
    not displace one whose priority is known.
    """
    token = priority.split(None, 1)[0] if priority else ""
    if len(token) == 2 and token[0] == "P" and token[1].isdigit():
        return int(token[1])
    return 5


def _workload_gate_check(finding: Finding) -> dict[str, Any]:
    """GATES.md step 5: is this fired workload gate a false positive?

    The absolute averages are already in the description — `time_series_stat_run_comparison`
    reports both sides in bytes — so the check the document tells a human to perform by hand is
    mechanical here. It stays a report, never a filter: a below-floor gate is annotated and left
    in place, because a genuinely idle-versus-idle network is itself worth knowing.
    """
    observed = finding.observed
    value, base = observed.get("value"), observed.get("base_value")
    if not isinstance(value, (int, float)) or not isinstance(base, (int, float)):
        return {
            "absolute_floor_check": "indeterminate",
            "note": (
                "Could not read both absolute averages out of the description, so the "
                f"false-positive check could not run. Compare them by hand against "
                f"~{WORKLOAD_GATE_FLOOR_BYTES:,} bytes per interval before treating this as "
                "blocking."
            ),
        }
    below = min(value, base) < WORKLOAD_GATE_FLOOR_BYTES
    return {
        "absolute_floor_check": "below_floor" if below else "at_workload_scale",
        "averages": {"run": value, "base_run": base},
        "floor_bytes_per_interval": WORKLOAD_GATE_FLOOR_BYTES,
        "note": (
            f"FALSE POSITIVE. The lower average is {min(value, base):,.0f} bytes per interval, "
            f"under the ~{WORKLOAD_GATE_FLOOR_BYTES:,} floor. This rule is a pure relative test "
            "with no absolute term, so it fires on background chatter. Void nothing; proceed to "
            "the domain findings."
            if below
            else (
                "Both averages are at workload scale, so this is a real difference in work done. "
                "Throughput and per-unit comparisons are void; configuration and saturation "
                "findings stay valid."
            )
        ),
    }


def _resolve_report(
    arguments: dict[str, Any],
    data_dir: str,
    find_report_dirs: Callable[[Path], list[Path]],
) -> dict[str, Any]:
    """Decide which report to analyze, and record how that was decided.

    Returns either `{"status": ...}` — a terminal payload for the caller — or
    `{"report_path", "available", "selected_by"}`.

    Two separate problems this addresses, both of which produce a confident answer about a report
    the caller did not name:

    * **`run_name` is what a caller has.** This is the only one of the 14 tools that did not accept
      it — eleven take `run_name`, two take `report_dir` — and it is the tool most likely to be
      called straight after `list_runs`, which returns `run_name` values. A `run_name` was silently
      ignored as an unknown argument (MCP does not reject those), so the call fell through to the
      no-argument path and analyzed whichever report sorted first.
    * **The fallback said nothing.** Picking `candidates[0]` is a reasonable convenience when a
      `data_dir` holds one report, and a silent misattribution when it holds two of the same shape.
      `selected_by` states which of the three ways the report was chosen, so a caller reading the
      response can tell "the one I asked for" from "the first one found".
    """
    report_path = arguments.get("report_path")
    run_name = arguments.get("run_name")

    if report_path:
        return {
            "report_path": str(report_path),
            "available": None,
            "selected_by": "report_path",
        }

    if run_name:
        # `run_name` is a directory name under `data_dir`, the same as in every other tool.
        candidate = Path(data_dir) / str(run_name)
        if candidate.is_dir():
            # The report/record distinction is the useful error here: `aperf record` writes no
            # findings at all, so pointing at a record directory is a different mistake from
            # pointing at nothing, and `parse_findings` already says so precisely.
            return {
                "report_path": str(candidate),
                "available": None,
                "selected_by": f"run_name ({run_name})",
            }
        return {
            "status": "no_such_run",
            "message": (
                f"No directory named {run_name!r} under {data_dir}. Pass a run_name as listed by "
                "list_runs, or a report_path pointing at the directory holding data/js/*.js."
            ),
            "searched": str(data_dir),
            "reports_available": [str(c) for c in find_report_dirs(Path(data_dir))],
        }

    candidates = find_report_dirs(Path(data_dir))
    if not candidates:
        return {
            "status": "no_report_found",
            "message": (
                f"No aperf report directory under {data_dir}. Analytical findings are "
                "written by `aperf report`, not by `aperf record` — generate a report "
                "first, or pass report_path."
            ),
            "searched": str(data_dir),
        }

    available = [str(c) for c in candidates]
    if len(candidates) > 1:
        selected_by = (
            f"fallback — no report_path or run_name given, and {data_dir} holds "
            f"{len(candidates)} reports; used the first in name order. Pass report_path or "
            "run_name to choose."
        )
    else:
        selected_by = "the only report under data_dir"
    return {"report_path": str(candidates[0]), "available": available, "selected_by": selected_by}


async def analyze_findings_handler(arguments: dict[str, Any]) -> str:
    """Build the findings-plus-guidance payload for one report."""
    from ..parsers.findings_parser import (
        FindingsParseError,
        find_report_dirs,
        parse_findings,
    )
    from ..parsers.playbook_library import DEFAULT_SECTIONS, get_library

    data_dir = arguments.get("data_dir") or os.environ.get("APERF_DATA_DIR", "./aperf_data")

    resolved = _resolve_report(arguments, data_dir, find_report_dirs)
    if resolved.get("status"):
        return json.dumps(resolved, indent=2)
    report_path = resolved["report_path"]
    available = resolved["available"]
    selected_by = resolved["selected_by"]

    try:
        report = parse_findings(Path(report_path))
    except FindingsParseError as exc:
        return json.dumps({"status": "error", "message": str(exc)}, indent=2)

    library = get_library()

    findings = report.findings
    if arguments.get("rule_name"):
        wanted = arguments["rule_name"]
        findings = [f for f in findings if f.rule_name == wanted]
        if not findings:
            known = sorted(library.registry.by_rule_name)
            return json.dumps(
                {
                    "status": "no_such_finding_in_report",
                    "message": (
                        f"No finding named {wanted!r} in this report. The name is an exact join "
                        "key, so check spacing and capitalisation. "
                        + (
                            f"{wanted!r} is a known aperf rule that did not fire here."
                            if wanted in library.registry.by_rule_name
                            else f"{wanted!r} is not a known aperf rule."
                        )
                    ),
                    "report_path": str(report.report_path),
                    "rules_that_fired": sorted({f.rule_name for f in report.findings}),
                    "all_known_rules": known,
                },
                indent=2,
            )
    if arguments.get("data_type"):
        findings = [f for f in findings if f.data_type == arguments["data_type"]]

    # Playbook text is opt-in. Measured on a real 2-run report: 17 findings across 12 distinct
    # playbooks inlined at the default two sections came to ~57 000 tokens even after
    # deduplication, which would crowd out the analysis it is supposed to inform. Priority,
    # risk, the firing condition and the observed values are always present, so a caller can
    # triage from the response and read only the playbooks it reaches — and `rule_name` +
    # `sections` inlines one playbook in full for a few hundred tokens.
    sections_requested = arguments.get("sections")
    include_playbooks = arguments.get("include_playbooks", sections_requested is not None)
    if not sections_requested:
        sections_requested = DEFAULT_SECTIONS if arguments.get("include_playbooks") else []
    if not sections_requested:
        include_playbooks = False

    entries = []
    #: Playbook text, one copy per playbook URI. Findings point at it by `guidance_uri`.
    guidance: dict[str, Any] = {}
    for finding in findings:
        gate = GATES.get(finding.rule_name)
        entry = finding.to_dict()
        entry["is_validity_gate"] = gate is not None
        if gate:
            entry["gate_class"] = gate["gate_class"]
            entry["gate_voids"] = gate["voids"]
            entry["gate_precedence_step"] = gate["rank"]
            if gate["gate_class"] == "workload":
                entry["gate_false_positive_check"] = _workload_gate_check(finding)

        entry["score_note"] = (
            "Flat: this template inserts the base score directly, so the value never moves and "
            "carries no magnitude."
            if finding.score_is_flat
            else "Scaled by threshold exceedance and unbounded. Not a severity — see "
            "aperf://findings/GUIDANCE_MODEL section 2."
        )

        uri = library.uri_for_rule(finding.rule_name)
        entry["playbook_uri"] = uri
        if uri is None:
            # Reported on the finding itself, not in the shared `guidance` block: that block is
            # keyed by playbook URI, and the whole point here is that there is no URI to key by.
            entry["no_playbook"] = (
                "This rule is not in the pinned registry, so no playbook exists for it. The "
                "report was generated by a newer aperf than the guidance tree describes; run "
                "resources/findings/tools/check_drift.py against that checkout."
            )
            entries.append(entry)
            continue

        document = library.get(uri)
        entry["priority"] = library.priority(finding.rule_name)
        entry["execution_risk"] = library.execution_risk(finding.rule_name)

        if include_playbooks:
            # Keyed by URI, not appended per finding: several rules fire once per run, and a
            # 16 kB playbook repeated per copy is the largest single term in the payload.
            if uri not in guidance:
                guidance[uri] = _guidance(library, document, sections_requested)
            entry["guidance_uri"] = uri

        entries.append(entry)

    entries.sort(
        key=lambda e: (
            e.get("gate_precedence_step", _DOMAIN_RANK),
            _priority_rank(e.get("priority") or ""),
            -abs(e["score"]),
            e["rule_name"],
        )
    )

    truncated = None
    max_findings = arguments.get("max_findings")
    if max_findings and len(entries) > max_findings:
        dropped = entries[max_findings:]
        truncated = {
            "returned": max_findings,
            "dropped": len(dropped),
            "dropped_rules": sorted({e["rule_name"] for e in dropped}),
            "note": (
                "Dropped by max_findings AFTER gate-precedence ordering, so the highest-"
                "precedence findings were kept. Raise max_findings to see the rest."
            ),
        }
        entries = entries[:max_findings]
        # Drop the playbooks only the dropped findings referenced, or a max_findings=1 call
        # still carries every playbook in the report.
        kept_uris = {e.get("guidance_uri") for e in entries}
        guidance = {uri: text for uri, text in guidance.items() if uri in kept_uris}

    gates_fired = [e for e in entries if e.get("is_validity_gate")]

    payload = {
        "status": "success",
        "report_path": str(report.report_path),
        # How `report_path` was arrived at. Every number below describes this report, so a caller
        # that did not name it needs to be told which one it got.
        "report_selected_by": selected_by,
        "runs": report.runs,
        "base_run": report.base_run,
        "is_comparison": report.is_comparison,
        "aperf_version": report.aperf_version,
        "aperf_git_sha": report.aperf_git_sha,
        "guidance_pinned_to": {
            "aperf_version": report.registry_version,
            "aperf_commit": report.registry_commit,
            "matches_report": report.registry_matches_report,
        },
        "total_findings_in_report": len(report.findings),
        "findings_returned": len(entries),
        "how_to_read_this": _how_to_read(report, gates_fired, include_playbooks),
        "validity_gates": _gate_triage(report, gates_fired),
        "findings": entries,
        "statistical_findings": report.statistical.to_dict(),
        "playbook_index_uri": "aperf://findings/INDEX",
    }
    if include_playbooks:
        payload["guidance"] = guidance
        payload["guidance_note"] = (
            "Playbook text is here, keyed by URI, and each finding names its own via "
            "`guidance_uri`. Several rules fire once per run — on a 2-run report five of them "
            "did — so inlining the text per finding duplicated it. Read each finding's "
            "`guidance_uri`, then this block."
        )
    if truncated:
        payload["truncated"] = truncated
    if available and len(available) > 1:
        # Only set on the fallback path, and `report_selected_by` above says the choice was not
        # the caller's. On its own this key read as "here is more you could look at".
        payload["other_reports_available"] = available[1:]
    if report.has_drift_signals:
        payload["drift"] = {
            "unknown_rules": report.unknown_rules,
            "parse_failures": [
                {"rule_name": r, "description": d} for r, d in report.parse_failures
            ],
            "score_anomalies": report.score_anomalies,
            "action": (
                "This report contains rules or description formats the guidance tree does not "
                "know. Run resources/findings/tools/check_drift.py against the aperf checkout "
                "that generated it before trusting the guidance below."
            ),
        }

    return json.dumps(payload, indent=2)


# ---------------------------------------------------------------------------
# Assembly helpers
# ---------------------------------------------------------------------------


def _guidance(
    library: PlaybookLibrary, document: Document, sections_requested: list[str]
) -> dict[str, Any]:
    """The playbook text for one finding, at the requested granularity."""
    available = library.sections(document)
    evidence = library.evidence_section(document)

    if sections_requested and any(str(s).lower() == "all" for s in sections_requested):
        return {
            "uri": document.uri,
            "sections": available,
            "note": "Complete playbook.",
        }

    wanted: dict[str, Any] = {}
    missing = []
    for name in sections_requested:
        if name in available:
            wanted[name] = available[name]
        else:
            missing.append(name)

    # The evidence section rides along unrequested: it is where a playbook says the number does
    # not mean what it appears to, which changes how every other section is read.
    if evidence and evidence[0] not in wanted:
        wanted[evidence[0]] = evidence[1]

    result = {
        "uri": document.uri,
        "sections": wanted,
        "sections_available": list(available),
        "note": (
            "Partial playbook. Request sections=['all'], or read the URI as a resource, for the "
            "rest — including Interpretation (false positives) and Verification."
        ),
    }
    if missing:
        result["sections_not_found"] = missing
    return result


def _gate_triage(report: FindingsReport, gates_fired: list[dict[str, Any]]) -> dict[str, Any]:
    """Gate state for this report, plus the manual checks aperf has no rule for."""
    if not report.is_comparison:
        return {
            "applicable": False,
            "reason": (
                "Single-run report: the 8 validity gates all compare two runs, so none of them "
                "can fire. Nothing here is invalidated by a gate — but nothing is confirmed "
                "comparable either, because there is nothing to compare."
            ),
            "gates_fired": [g["rule_name"] for g in gates_fired],
            "note": (
                "A requires_comparison rule firing on a single run is the documented "
                "JVM Version Comparison exception: its absence path emits before it reaches the "
                "other-runs loop, and its message then falsely claims a cross-run difference. "
                "See aperf://findings/java_profile/jvm-version-comparison STEP 0."
            )
            if any(g.get("fired_without_comparison") for g in gates_fired)
            else None,
            "manual_checks": [],
            "reference": "aperf://findings/GATES",
        }

    triage = {
        "applicable": True,
        "gates_fired": [
            {
                "rule_name": g["rule_name"],
                "gate_class": g["gate_class"],
                "precedence_step": g["gate_precedence_step"],
                "score": g["score"],
                "voids": g["gate_voids"],
                "playbook_uri": g.get("playbook_uri"),
                **(
                    {"false_positive_check": g["gate_false_positive_check"]}
                    if "gate_false_positive_check" in g
                    else {}
                ),
            }
            for g in gates_fired
        ],
        "manual_checks": MANUAL_CHECKS,
        "reference": "aperf://findings/GATES",
    }

    classes = {g["gate_class"] for g in gates_fired}
    if "hardware" in classes:
        triage["verdict"] = (
            "BLOCKING — a hardware gate fired. The machines differ; no other finding in this "
            "report is interpretable. Re-run on matched instances."
        )
    elif "software_stack" in classes:
        triage["verdict"] = (
            "This is a STACK comparison, not a code comparison. Configuration findings stay "
            "valid; attribute nothing to the application."
        )
    elif "workload" in classes:
        checks = [
            g["gate_false_positive_check"].get("absolute_floor_check")
            for g in gates_fired
            if g["gate_class"] == "workload"
        ]
        if checks and all(c == "below_floor" for c in checks):
            triage["verdict"] = (
                "Workload gates fired but ALL are below the absolute floor — false positives. "
                "These four rules are pure relative tests with no absolute term, so at near-zero "
                "traffic they fire on background chatter. Void nothing; read the domain findings."
            )
        elif "at_workload_scale" in checks:
            triage["verdict"] = (
                "A workload gate fired at workload scale: the runs did not do the same amount of "
                "work. Throughput and per-unit comparisons are void. Configuration and "
                "saturation findings stay valid."
            )
        else:
            triage["verdict"] = (
                "A workload gate fired and the absolute averages could not be read from the "
                "description — check them by hand before treating it as blocking. All four "
                "workload gates are relative-ratio tests with no absolute floor: two idle runs "
                "on the same host fired both netstat gates off a 2.4 kB/s difference, one "
                "scoring louder than every genuine finding in the report."
            )
    else:
        triage["verdict"] = (
            "No validity gate fired. That does NOT establish comparability: architecture and "
            "instance type have no rule at all, and several gates return early when the base "
            "run lacks the key. Run the manual checks below."
        )
    return triage


def _how_to_read(
    report: FindingsReport, gates_fired: list[dict[str, Any]], playbooks_inlined: bool
) -> list[str]:
    """Ordered reading instructions for this specific payload.

    `playbooks_inlined` changes step 3, and only step 3: with text in the payload the caller
    reads the `guidance` block, without it the caller reads `playbook_uri` as a resource. Saying
    "read the Decision tree" when no decision tree is present is the one instruction that would
    send a caller looking for something that is not there.
    """
    steps = []
    if report.is_comparison:
        steps.append(
            "1. Read `validity_gates` first. Findings are already ordered so that gates come "
            "before domain findings, in GATES.md precedence order."
        )
        steps.append(
            "2. Run the `manual_checks`: architecture and instance-type parity have no aperf "
            "rule, so a clean gate result does not mean the runs are comparable."
        )
    else:
        steps.append(
            "1. Single-run report: no validity gate can fire, and no statistical findings exist. "
            "Findings here are absolute observations, not regressions."
        )
    if playbooks_inlined:
        steps.append(
            f"{len(steps) + 1}. For each finding, read `condition` (what fired), `observed` "
            "(values parsed from aperf's description), then the playbook text under `guidance` "
            "keyed by that finding's `guidance_uri` — its Decision tree branches on `observed`."
        )
    else:
        steps.append(
            f"{len(steps) + 1}. For each finding, read `condition` (what fired), `observed` "
            "(values parsed from aperf's description), `priority` and `execution_risk`. Playbook "
            "text is not inlined: triage from those fields, then read the `playbook_uri` of the "
            "findings you act on as an MCP resource — that is where the Decision tree is, and it "
            "branches on `observed`. Or call again with include_playbooks=true."
        )
    steps.append(
        f"{len(steps) + 1}. Do not rank by `score`. It is unbounded for scaled templates and "
        "fixed for flat ones, so it orders deviation, not importance. Use `priority`."
    )
    steps.append(
        f"{len(steps) + 1}. Absence of a finding proves nothing: 752 of 802 metrics have no "
        "analytical rule, and the statistical engine that covers them serializes nothing. See "
        "`statistical_findings`."
    )
    if gates_fired and not report.is_comparison:
        steps.append(
            f"{len(steps) + 1}. A requires_comparison rule fired on a single run. Read that "
            "finding's `fired_without_comparison` flag and its playbook STEP 0 before believing "
            "its message, which claims a cross-run difference that no comparison produced."
        )
    return steps
