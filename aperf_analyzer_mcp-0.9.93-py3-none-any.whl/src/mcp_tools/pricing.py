# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Pricing lookup helper.

Reads from resources/ec2_pricing_us_east_1.json and provides:
- lookup(instance_type) -> price per hour (or None)
- annual_cost(instance_type) -> $/year
- savings_pct(from_type, to_type) -> percent savings
- pricing_freshness() -> "fresh" | "aging" | "stale" | "missing"
- fill_placeholders(html, current_instance, options) -> html with {{PRICE_*}}, {{ANNUAL_*}}, {{SAVINGS_*}} replaced
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

PRICING_FILE = Path(__file__).parent.parent.parent / "resources" / "ec2_pricing_us_east_1.json"
HOURS_PER_YEAR = 8760


def _load() -> dict:
    if not PRICING_FILE.exists():
        return {"_metadata": {}, "prices": {}}
    try:
        return json.loads(PRICING_FILE.read_text())
    except Exception:
        return {"_metadata": {}, "prices": {}}


_DATA = _load()


def reload() -> None:
    """Force reload of the pricing file (for tests)."""
    global _DATA
    _DATA = _load()


def lookup(instance_type: str) -> float | None:
    """Return $/hr for an instance type, or None if not in the file."""
    if not instance_type:
        return None
    return _DATA.get("prices", {}).get(instance_type)


def annual_cost(instance_type: str) -> float | None:
    """Return $/year (8760 hours) for an instance type."""
    price = lookup(instance_type)
    return price * HOURS_PER_YEAR if price is not None else None


def savings_pct(from_type: str, to_type: str) -> float | None:
    """Return percent savings of `to_type` vs `from_type`. Negative = more expensive."""
    from_price = lookup(from_type)
    to_price = lookup(to_type)
    if from_price is None or to_price is None or from_price == 0:
        return None
    return (from_price - to_price) / from_price * 100


def pricing_freshness() -> tuple[str, int]:
    """
    Returns (status, days_old).
    status: 'fresh' (<30d), 'aging' (30-90d), 'stale' (>90d), 'missing'
    """
    pub = _DATA.get("_metadata", {}).get("publication_date")
    if not pub or pub == "unknown":
        return ("missing", -1)

    try:
        # Parse ISO-8601 with Z suffix
        if pub.endswith("Z"):
            pub_dt = datetime.fromisoformat(pub.replace("Z", "+00:00"))
        else:
            pub_dt = datetime.fromisoformat(pub)
        now = datetime.now(timezone.utc)
        days_old = (now - pub_dt).days
        if days_old < 30:
            return ("fresh", days_old)
        elif days_old < 90:
            return ("aging", days_old)
        else:
            return ("stale", days_old)
    except Exception:
        return ("missing", -1)


def metadata() -> dict:
    """Return the metadata block from the pricing file."""
    return _DATA.get("_metadata", {})


def freshness_banner_html() -> str:
    """Build a small HTML banner showing pricing data freshness."""
    status, days = pricing_freshness()
    pub = _DATA.get("_metadata", {}).get("publication_date", "unknown")

    if status == "missing":
        return (
            '<div class="warn-box" style="margin-bottom:12px;">'
            "⚠️ No pricing data file found. Pricing fields in this report will show as placeholders. "
            "Run <code>scripts/refresh_pricing.py</code> to fetch latest prices from AWS."
            "</div>"
        )

    color = {"fresh": "#16a34a", "aging": "#d97706", "stale": "#dc2626"}[status]
    bg = {"fresh": "#f0fdf4", "aging": "#fffbeb", "stale": "#fef2f2"}[status]
    label = {
        "fresh": "Pricing data is current.",
        "aging": "Pricing data is aging — consider refreshing.",
        "stale": "⚠️ Pricing data is STALE.",
    }[status]

    return (
        f'<div style="background:{bg};border:1px solid {color};border-radius:6px;'
        f'padding:8px 14px;font-size:11px;color:{color};margin-bottom:16px;">'
        f"<strong>{label}</strong> &nbsp;Source: us-east-1 published {pub} ({days} days ago)"
        f"</div>"
    )


def fill_placeholders(html: str, current_instance: str, instance_options: list) -> str:
    """
    Replace pricing placeholders in the HTML report with real values from the pricing file.

    Placeholders filled:
    - {{PRICE_FROM}}       : $/hr for current_instance
    - {{ANNUAL_FROM}}      : $/yr for current_instance
    - {{PRICE_TO_STEP_N}}  : $/hr for instance_options[N-1]
    - {{SAVINGS_STEP_N}}   : percent savings vs current_instance

    Unfilled placeholders remain as-is (e.g. instance not in our pricing file).
    """
    # Current instance
    cur_price = lookup(current_instance)
    cur_annual = annual_cost(current_instance)

    if cur_price is not None:
        html = html.replace("{{PRICE_FROM}}", f"${cur_price:.4f}/hr")
    else:
        html = html.replace("{{PRICE_FROM}}", "<span style='color:#999;'>price unavailable</span>")
    if cur_annual is not None:
        html = html.replace("{{ANNUAL_FROM}}", f"${cur_annual:,.0f}")
    else:
        html = html.replace("{{ANNUAL_FROM}}", "<span style='color:#999;'>—</span>")

    # Step options
    for i, opt in enumerate(instance_options, start=1):
        instance_type = getattr(opt, "instance_type", "") or ""
        # Skip if still has a generation placeholder
        if "{{" in instance_type:
            continue

        price = lookup(instance_type)
        sav = savings_pct(current_instance, instance_type) if cur_price else None

        # New scheme: index-based placeholders match what html_report.py emits
        placeholder_price = f"{{{{PRICE_TO_OPT_{i}}}}}"
        placeholder_savings = f"{{{{SAVINGS_OPT_{i}}}}}"

        if price is not None:
            html = html.replace(placeholder_price, f"${price:.4f}/hr")
        else:
            html = html.replace(placeholder_price, "<span style='color:#999;'>—</span>")
        if sav is not None:
            color = "#16a34a" if sav > 0 else "#dc2626"
            html = html.replace(
                placeholder_savings, f"<span style='color:{color};'>{sav:+.1f}%</span>"
            )
        else:
            html = html.replace(placeholder_savings, "—")

    return html


def newest_generation(family_letter: str, suffix: str) -> int | None:
    """
    Find the newest generation number available for a family + suffix.

    e.g. newest_generation('m', 'a') -> 8 (because m8a.X exists in pricing file)
         newest_generation('r', 'g') -> 8 (because r8g.X exists)
         newest_generation('c', 'i') -> 8 (because c8i.X exists)

    Returns None if no match found.
    """
    import re

    prices = _DATA.get("prices", {})
    pattern = re.compile(rf"^{family_letter}(\d+){suffix}\.")
    max_gen = 0
    for instance_type in prices:
        m = pattern.match(instance_type)
        if m:
            gen = int(m.group(1))
            max_gen = max(max_gen, gen)
    return max_gen if max_gen > 0 else None


def resolve_instance_type(template: str) -> str:
    """
    Replace {{NEWEST_X86_AMD_GEN}}, {{NEWEST_X86_INTEL_GEN}}, {{NEWEST_GRAVITON_GEN}}
    placeholders in an instance type template like 'r{{NEWEST_GRAVITON_GEN}}g.16xlarge'.

    Walks the pricing file to find the newest generation that actually exists for
    each family + size combination. Falls back to the placeholder if nothing matches.
    """
    import re

    # Detect family letter and suffix from the template
    # e.g. 'r{{NEWEST_GRAVITON_GEN}}g.16xlarge' -> family='r', suffix='g', size='16xlarge'
    m = re.match(r"^([a-z])\{\{NEWEST_(\w+)_GEN\}\}([a-z]+)\.([\w]+)$", template)
    if not m:
        return template

    family, gen_kind, suffix, size = m.group(1), m.group(2), m.group(3), m.group(4)

    # Map placeholder kind to suffix we expect
    expected_suffix = {
        "X86_AMD": "a",
        "X86_INTEL": "i",
        "GRAVITON": "g",
    }.get(gen_kind)
    if expected_suffix and expected_suffix != suffix:
        return template

    gen = newest_generation(family, suffix)
    if gen is None:
        return template

    # Verify the resolved instance type exists at the requested size; otherwise
    # try to find the largest available size for that family+gen+suffix
    resolved = f"{family}{gen}{suffix}.{size}"
    if resolved in _DATA.get("prices", {}):
        return resolved

    # Try smaller sizes if exact size not available (some new gens don't ship all sizes yet)
    fallback_sizes = [
        "48xlarge",
        "32xlarge",
        "24xlarge",
        "16xlarge",
        "12xlarge",
        "8xlarge",
        "4xlarge",
        "2xlarge",
        "xlarge",
    ]
    if size in fallback_sizes:
        idx = fallback_sizes.index(size)
        for fallback in fallback_sizes[idx:]:
            candidate = f"{family}{gen}{suffix}.{fallback}"
            if candidate in _DATA.get("prices", {}):
                return candidate

    return resolved  # Return even if not in pricing, so user sees the gen
