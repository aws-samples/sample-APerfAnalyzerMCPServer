# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: get_language_advisory

The AI-powered advisory engine. Detects the runtime/language from aperf data
and returns tailored performance recommendations based on the actual metrics.

This is where the MCP + LLM combo really shines — the tool pre-processes the
data and provides structured context that helps the LLM give actionable advice.
"""

import json
import os
from pathlib import Path
from typing import Any

from mcp.types import Tool

LANGUAGE_ADVISOR_TOOL = Tool(
    name="get_language_advisory",
    description=(
        "Get language/runtime-specific performance advisory based on aperf data. "
        "Auto-detects the runtime (Java/JVM, Python, C/C++, Rust, .NET, Go, Node.js) "
        "from process data and profiling information. "
        "Returns tailored recommendations combining the aperf metrics with "
        "language-specific optimization knowledge. "
        "Use after get_run_summary to get actionable tuning advice."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "language": {
                "type": "string",
                "enum": ["auto", "java", "python", "cpp", "rust", "dotnet", "go", "nodejs", "php"],
                "description": "Override detected language (default: auto-detect)",
                "default": "auto",
            },
            "focus": {
                "type": "string",
                "enum": ["general", "latency", "throughput", "memory", "startup"],
                "description": "Optimization focus area",
                "default": "general",
            },
            "data_dir": {"type": "string"},
        },
        "required": ["run_name"],
    },
)


# Language detection heuristics
LANGUAGE_INDICATORS = {
    "java": {
        "processes": ["java", "jvm", "jar"],
        "profile_markers": ["jdk.", "java.", "scala.", "kotlin.", "clojure."],
        "modules": ["libjvm.so", "libjava.so"],
    },
    "python": {
        "processes": ["python", "python3", "gunicorn", "uvicorn", "celery"],
        "profile_markers": ["cpython", "PyEval", "_PyObject"],
        "modules": ["libpython"],
    },
    "cpp": {
        "processes": [],  # Too generic
        "profile_markers": ["std::", "__cxa_", "_ZN"],  # C++ name mangling
        "modules": ["libstdc++", "libc++"],
    },
    "rust": {
        "processes": [],
        "profile_markers": ["core::ptr", "alloc::vec", "std::io"],
        "modules": [],
    },
    "dotnet": {
        "processes": ["dotnet", "mono"],
        "profile_markers": ["System.", "Microsoft.", "coreclr"],
        "modules": ["libcoreclr", "libclrjit"],
    },
    "go": {
        "processes": [],
        "profile_markers": ["runtime.", "syscall.", "net/http"],
        "modules": [],
    },
    "nodejs": {
        "processes": ["node", "npm", "deno", "bun"],
        "profile_markers": ["v8::", "Builtins_", "node::"],
        "modules": ["libnode", "libv8"],
    },
    "php": {
        "processes": ["php", "php-fpm", "php-cgi", "artisan", "composer"],
        "profile_markers": ["zend_", "php_", "ZEND_"],
        "modules": ["libphp", "opcache.so"],
    },
}


def _detect_language(report_data: dict[str, Any], metadata: dict[str, Any]) -> str:
    """Auto-detect language/runtime from aperf data."""
    # Check processes
    processes = report_data.get("processes", {}).get("names", [])
    for lang, indicators in LANGUAGE_INDICATORS.items():
        for proc_name in indicators["processes"]:
            if any(proc_name in p.lower() for p in processes):
                return lang

    # Check profile data for language-specific markers
    profile = report_data.get("perf_profile", {})
    functions = profile.get("top_functions", [])
    for lang, indicators in LANGUAGE_INDICATORS.items():
        for marker in indicators["profile_markers"]:
            if any(marker in str(f) for f in functions):
                return lang

    # Check for java_profile specifically
    if report_data.get("java_profile"):
        return "java"

    return "generic"


def _load_advisory_prompt(language: str) -> str:
    """
    Load the advisory prompt template for a language.

    These files are injected verbatim into an LLM's context, so every line in them is
    emitted as guidance. They are therefore kept clean at the source: the retracted
    claims — flags that are already the default, advice contradicted by aperf's own rule
    message, and settings unsafe when applied blindly — were edited out of the six files
    that carried them.

    An earlier version filtered those lines here at read time instead. That was the wrong
    depth: substring matching on prose left a GC table with a header and no rows, orphaned
    a mid-sentence continuation, emptied a code fence, stripped a *legitimate*
    recommendation that shared a table row with a retracted one, and still missed variant
    phrasings that named no flag. `tests/test_anchoring.py` asserts the files stay clean.
    """
    prompts_dir = Path(__file__).parent.parent.parent / "resources" / "prompts"
    prompt_file = prompts_dir / f"{language}_advisory.md"
    if not prompt_file.exists():
        prompt_file = prompts_dir / "generic_system_advisory.md"
    if not prompt_file.exists():
        return ""
    return prompt_file.read_text(encoding="utf-8")


async def language_advisor_handler(arguments: dict[str, Any]) -> str:
    """Generate language-specific performance advisory."""
    run_name = arguments["run_name"]
    language = arguments.get("language", "auto")
    focus = arguments.get("focus", "general")
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))

    from ..parsers.cpu_parser import CpuUtilizationParser
    from ..parsers.pmu_parser import PmuParser
    from ..parsers.run_parser import AperfRunParser
    from ..parsers.version_compat import check_version_limitations

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)

    if not run_data:
        return json.dumps({"status": "error", "message": f"Run '{run_name}' not found"})

    # Resolved path, not a reconstruction: an archive run was extracted to a tempdir.
    report_data = parser.get_report_data(Path(run_data.metadata.run_path)) or {}

    # Detect language
    if language == "auto":
        language = _detect_language(report_data, run_data.metadata.system_info)

    # Load advisory prompt
    advisory_prompt = _load_advisory_prompt(language)

    # Gather key metrics for context
    pmu_parser = PmuParser()
    pmu_summary = pmu_parser.parse_from_report_data(report_data)

    cpu_parser = CpuUtilizationParser()
    cpu_summary = cpu_parser.parse_from_report_data(report_data)

    # Build context-rich advisory response
    # `dict[str, Any]`: `pmu` and `cpu` are metric dicts while `bottlenecks` is a list of
    # findings, so the inferred `dict[str, object]` rejects the list.
    metrics_context: dict[str, Any] = {}
    if pmu_summary:
        metrics_context["pmu"] = {
            "ipc": pmu_summary.ipc,
            "branch_misses_per_1k": pmu_summary.branch_misses_per_1k_instructions,
            "itlb_misses_per_1k": pmu_summary.itlb_misses_per_1k_instructions,
            "frontend_stalls_pct": pmu_summary.frontend_stall_pct,
            "backend_stalls_pct": pmu_summary.backend_stall_pct,
            # The advisory rules below all fire above a threshold, so a metric this platform does
            # not collect reads 0.0 and stays quiet rather than misfiring. It does mean the absence
            # of an advisory is not evidence of a healthy metric, which is what this records.
            "metrics_collected": pmu_summary.metrics_available,
            "counter_multiplexing_pct": pmu_summary.counter_schedule_rate_pct,
        }
        # Generate bottleneck findings
        metrics_context["bottlenecks"] = pmu_parser.detect_bottlenecks(pmu_summary)

    if cpu_summary:
        metrics_context["cpu"] = {
            "avg_utilization": cpu_summary.avg_total_utilization_pct,
            "system_time_pct": cpu_summary.avg_system_pct,
            "iowait_pct": cpu_summary.avg_iowait_pct,
            "imbalance_pct": cpu_summary.cpu_imbalance_pct,
        }

    result = {
        "status": "success",
        "detected_language": language,
        "optimization_focus": focus,
        "metrics_context": metrics_context,
        "advisory_prompt": advisory_prompt,
        "instance_type": run_data.metadata.instance_type,
        "architecture": run_data.metadata.architecture,
        "cpu_count": run_data.metadata.cpu_count,
    }

    # Version-aware limitations check
    detected_version = report_data.get("runtime_version") or report_data.get("processes", {}).get(
        "runtime_version"
    )
    version_warnings = check_version_limitations(language, detected_version)
    if version_warnings:
        result["version_warnings"] = version_warnings
        result["detected_version"] = detected_version

    # Anchored advice. Every rule is gated on a finding aperf emitted, so a raw `aperf
    # record` directory — which carries no `<data_type>_findings` variables — yields
    # nothing to anchor on and therefore no recommendations. That is correct behaviour:
    # advice requires a measurement.
    from ..parsers.findings_parser import FindingsParseError, parse_findings
    from ..playbook_engine import evaluate_for_report

    aperf_findings = None
    findings_error: str | None = None
    try:
        # Use the path the parser RESOLVED, not a reconstruction. For a `<run>.tar.gz`
        # archive, parse_run extracts to a tempdir and records that in `run_path`, so
        # `data_dir / run_name` does not exist and every anchor would be silently lost.
        aperf_findings = parse_findings(Path(run_data.metadata.run_path))
    except (FindingsParseError, OSError, ValueError, TypeError, AttributeError) as exc:
        # FindingsParseError: not a readable aperf report — the common case, since a raw
        # `aperf record` directory has no findings variables. OSError/ValueError: unreadable
        # or malformed files. TypeError/AttributeError: a findings payload whose shape
        # drifted from what the parser expects (a null `score` raises TypeError from
        # float(); a bare string where a dict belongs raises AttributeError). All of these
        # mean "no anchors", which the caller is told about — none should fail the tool.
        findings_error = f"{type(exc).__name__}: {exc}"

    matched_rules = evaluate_for_report(
        meta=run_data.metadata,
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        app_context={"language": language},
        aperf_findings=aperf_findings,
    )

    recommendations = _generate_quick_recommendations(
        language, metrics_context, focus, matched_rules
    )
    result["quick_recommendations"] = recommendations
    result["anchored_on"] = sorted({n for r in matched_rules for n in r.anchored_by})

    # An empty recommendation list has two very different causes, and saying which one
    # matters: "nothing was measured" is a data problem, "we have no playbook for your
    # runtime" is a scope problem. Previously only the first was reported, and only when NO
    # rule fired — so an out-of-scope language saw findings listed in `anchored_on` and then
    # zero advice with no explanation, indistinguishable from a clean run.
    if not matched_rules:
        result["no_advice_reason"] = (
            "No aperf analytical findings were available to anchor advice on. "
            + (
                f"Findings could not be read: {findings_error}. "
                if findings_error
                else "aperf emitted no findings this tool has a playbook for. "
            )
            + "Every recommendation requires a finding aperf measured; a raw `aperf record` "
            "directory carries no findings, only a generated `aperf report` does."
        )
    elif not recommendations:
        covered = sorted({lang for rule in matched_rules for lang in rule.extensions})
        result["no_advice_reason"] = (
            f"{len(matched_rules)} aperf finding(s) anchored rules for this run, but none "
            f"carries guidance for '{language}'. Runtimes currently covered: "
            f"{', '.join(covered)}. This is a scope limit, NOT a clean run — see "
            "`anchored_on` for what aperf measured, and the language-agnostic `core` steps "
            "of each rule still apply."
        )
        result["language_out_of_scope"] = language not in covered

    return json.dumps(result, indent=2, default=str)


#: Severity -> the `priority` vocabulary this tool's response has always used.
_SEVERITY_TO_PRIORITY = {"high": "high", "medium": "medium", "low": "low"}


def _generate_quick_recommendations(
    language: str,
    metrics: dict[str, Any],
    focus: str,
    matched_rules: list[Any] | None = None,
) -> list[dict[str, Any]]:
    """
    Recommendations for `language`, derived from the anchored playbook engine.

    Previously ~240 lines of per-language string literals with thresholds invented here.
    Those thresholds disagreed with aperf and with each other — ITLB alone carried four
    different values across six files — and much of the advice had no measured signal at
    all. Two items actively contradicted reality: `-XX:-TieredCompilation`, which aperf's
    own rule message argues *against*, and an unconditional `--max-old-space-size=4096`,
    which converts graceful GC pressure into an OOM kill under a lower cgroup limit.

    Now every item traces to a finding aperf emitted. `matched_rules` comes from
    playbook_engine.evaluate_for_report, so an empty list means aperf measured nothing
    that warrants advice — which is a real answer, not a failure.
    """
    if not matched_rules:
        return []

    recs: list[dict[str, Any]] = []
    for rule in matched_rules:
        advice = rule.advice_for(language)
        # None => the rule's own threshold is invalid for this runtime, so reporting it
        # would be noise. Exceptions on CPython are the case.
        if advice is None:
            continue

        priority = _SEVERITY_TO_PRIORITY.get(rule.severity, "medium")
        anchor = f"aperf finding: {', '.join(rule.anchored_by)}"

        if advice.get("no_config_needed"):
            recs.append(
                {
                    "priority": "info",
                    "action": f"No {language}-specific configuration needed for: {rule.title}",
                    "rationale": advice.get("reason", ""),
                    "anchored_by": rule.anchored_by,
                    "rule_id": rule.id,
                }
            )
        else:
            for action in advice.get("actions", []):
                recs.append(
                    {
                        "priority": priority,
                        "action": action,
                        "rationale": f"{rule.why} ({anchor})",
                        "anchored_by": rule.anchored_by,
                        "rule_id": rule.id,
                    }
                )
            for warning in advice.get("explicitly_not_recommended", []):
                recs.append(
                    {
                        "priority": "avoid",
                        "action": f"DO NOT: {warning}",
                        "rationale": "Recorded so a previously-recommended change is not reapplied.",
                        "anchored_by": rule.anchored_by,
                        "rule_id": rule.id,
                    }
                )

        # OS-level fixes are legitimate remediations for a measured symptom even though
        # no aperf rule reads sysctl values. Marked distinctly so they are never mistaken
        # for a language setting.
        osr = rule.os_remediation
        # A blocking pre-check may be expressed as `mandatory_discriminator` (this fix is
        # wrong unless you check X first) or as `preconditions` (this fix only applies on
        # certain hardware). Reading only the first silently dropped the multi-node gate on
        # NUMA pinning, whose own risk text says pinning wrong halves available bandwidth.
        check_first = " ".join(
            osr[key]
            for key in ("mandatory_discriminator", "preconditions", "cannot_be_gated_on")
            if osr.get(key)
        )
        for action in osr.get("actions", []):
            recs.append(
                {
                    "priority": priority,
                    "scope": "os",
                    "action": action,
                    "rationale": f"OS-level fix ({osr.get('strength', 'see playbook')}). {anchor}",
                    "risk": osr.get("risk", ""),
                    "check_first": check_first,
                    "correct_target": osr.get("anchored_target") or osr.get("correct_target", ""),
                    "anchored_by": rule.anchored_by,
                    "rule_id": rule.id,
                }
            )

    return recs
