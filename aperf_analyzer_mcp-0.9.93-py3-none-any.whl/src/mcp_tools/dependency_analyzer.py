# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: analyze_app_context

Analyzes application dependencies (requirements.txt, pom.xml, package.json, Cargo.toml,
go.mod, Gemfile, composer.json) and container configuration (Dockerfile, docker-compose.yml,
ECS task def, K8s manifests) to provide actionable optimization recommendations.

This tool bridges the gap between "what aperf sees" and "what to change" by understanding:
1. What libraries/frameworks are in use (→ framework-specific tuning)
2. How the app is containerized (→ resource allocation advice)
3. What versions are in use (→ version-specific optimizations)
"""

import json
import os
from pathlib import Path
from typing import Any

from mcp.types import Tool

DEPENDENCY_ANALYZER_TOOL = Tool(
    name="analyze_app_context",
    description=(
        "Analyze application dependencies and container configuration to provide "
        "optimization recommendations. Pass the content of dependency files "
        "(requirements.txt, pom.xml, package.json, Cargo.toml, go.mod, composer.json) "
        "and/or container configs (Dockerfile, docker-compose.yml, ECS task definition, "
        "K8s deployment YAML). Returns framework-specific tuning advice, resource "
        "allocation recommendations, and version upgrade suggestions — all correlated "
        "with aperf findings."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": "Name of the aperf run to correlate findings with (optional)",
            },
            "dependency_file_content": {
                "type": "string",
                "description": (
                    "Content of the dependency/package file "
                    "(requirements.txt, pom.xml, package.json, Cargo.toml, go.mod, composer.json, Gemfile)"
                ),
            },
            "dependency_file_type": {
                "type": "string",
                "enum": [
                    "requirements.txt",
                    "Pipfile",
                    "pyproject.toml",
                    "pom.xml",
                    "build.gradle",
                    "package.json",
                    "Cargo.toml",
                    "go.mod",
                    "composer.json",
                    "Gemfile",
                    "csproj",
                ],
                "description": "Type of the dependency file",
            },
            "container_config_content": {
                "type": "string",
                "description": (
                    "Content of container/deployment configuration "
                    "(Dockerfile, docker-compose.yml, ECS task def, K8s YAML)"
                ),
            },
            "container_config_type": {
                "type": "string",
                "enum": [
                    "dockerfile",
                    "docker-compose",
                    "ecs-task-definition",
                    "k8s-deployment",
                    "k8s-pod",
                    "helm-values",
                ],
                "description": "Type of the container configuration",
            },
            "data_dir": {"type": "string"},
        },
        "required": [],
    },
)


# Framework-specific optimization knowledge
# Annotated for the same reason `_analyze_dependencies`'s `analysis` is: the values mix a `str`
# `category` with a list of option dicts, and without this mypy joins them to
# `Collection[str]` — a supertype that is neither indexable nor iterable as dicts.
FRAMEWORK_OPTIMIZATIONS: dict[str, dict[str, Any]] = {
    # Python frameworks
    "gunicorn": {
        "category": "python_wsgi",
        "optimizations": [
            {
                "setting": "workers",
                "rule": "(2 * CPU_COUNT) + 1 for CPU-bound, (4 * CPU_COUNT) for I/O-bound",
                "common_mistake": "Using default (1 worker) or too many workers causing memory pressure",
            },
            {
                "setting": "worker_class",
                "rule": "Use 'uvicorn.workers.UvicornWorker' for async, 'gthread' for thread-based",
                "common_mistake": "Using sync workers for I/O-heavy apps",
            },
            {
                "setting": "worker_connections",
                "rule": "1000+ for async workers handling many concurrent connections",
                "common_mistake": "Default too low for high-concurrency scenarios",
            },
        ],
    },
    "uvicorn": {
        "category": "python_asgi",
        "optimizations": [
            {
                "setting": "workers",
                "rule": "CPU_COUNT for async frameworks (FastAPI, Starlette)",
                "common_mistake": "Running single worker in production",
            },
            {
                "setting": "loop",
                "rule": "Use 'uvloop' for 2-4x better event loop performance",
                "common_mistake": "Using default asyncio loop",
            },
        ],
    },
    "django": {
        "category": "python_framework",
        "optimizations": [
            {
                "setting": "CONN_MAX_AGE",
                "rule": "Set to 600+ (seconds) for persistent DB connections",
                "common_mistake": "Default 0 creates new connection per request",
            },
            {
                "setting": "DEBUG",
                "rule": "MUST be False in production",
                "common_mistake": "Debug mode in production causes memory leaks and overhead",
            },
        ],
    },
    "fastapi": {
        "category": "python_framework",
        "optimizations": [
            {
                "setting": "async endpoints",
                "rule": "Use async def for I/O-bound endpoints, def for CPU-bound",
                "common_mistake": "Mixing sync DB calls in async endpoints blocks the event loop",
            },
        ],
    },
    # Java frameworks
    "spring-boot": {
        "category": "java_framework",
        "optimizations": [
            {
                "setting": "server.tomcat.threads.max",
                "rule": "200 for typical web apps, reduce for CPU-bound",
                "common_mistake": "Default 200 may be too high for small instances",
            },
            {
                "setting": "spring.datasource.hikari.maximum-pool-size",
                "rule": "(CPU_COUNT * 2) + 1 (formula from HikariCP wiki)",
                "common_mistake": "Pool size = worker count creates contention",
            },
            {
                "setting": "JVM flags",
                "rule": "-Xms == -Xmx, choose GC based on latency requirement",
                "common_mistake": "Running with defaults, no GC tuning",
            },
        ],
    },
    "quarkus": {
        "category": "java_framework",
        "optimizations": [
            {
                "setting": "native compilation",
                "rule": "Use native image for startup-sensitive (Lambda, K8s scale-to-zero)",
                "common_mistake": "Running JVM mode in scenarios where startup matters",
            },
        ],
    },
    # Node.js frameworks
    "express": {
        "category": "nodejs_framework",
        "optimizations": [
            {
                "setting": "cluster mode",
                "rule": "Use PM2 cluster or native cluster module for multi-core",
                "common_mistake": "Single-process Express on multi-core instance",
            },
            {
                "setting": "compression middleware",
                "rule": "Offload to reverse proxy (nginx) for CPU efficiency",
                "common_mistake": "In-process compression steals cycles from request handling",
            },
        ],
    },
    "nestjs": {
        "category": "nodejs_framework",
        "optimizations": [
            {
                "setting": "fastify adapter",
                "rule": "Switch from Express to Fastify for 2x throughput",
                "common_mistake": "Using default Express adapter in high-throughput scenarios",
            },
        ],
    },
    # PHP frameworks
    "laravel": {
        "category": "php_framework",
        "optimizations": [
            {
                "setting": "config:cache",
                "rule": "Run `php artisan config:cache` in production",
                "common_mistake": "Parsing config files on every request",
            },
            {
                "setting": "route:cache",
                "rule": "Run `php artisan route:cache` in production",
                "common_mistake": "Route registration overhead on every request",
            },
            {
                "setting": "queue driver",
                "rule": "Use Redis or SQS, not 'sync' or 'database'",
                "common_mistake": "Sync queue driver blocks request threads",
            },
            {
                "setting": "octane",
                "rule": "Use Laravel Octane (Swoole/RoadRunner) for persistent workers",
                "common_mistake": "Traditional FPM reloads framework on every request",
            },
        ],
    },
    "symfony": {
        "category": "php_framework",
        "optimizations": [
            {
                "setting": "APP_ENV",
                "rule": "Must be 'prod' (not 'dev') in production",
                "common_mistake": "Dev mode enables profiler, debug toolbar, full stack traces",
            },
            {
                "setting": "composer dump-autoload",
                "rule": "--optimize --classmap-authoritative",
                "common_mistake": "PSR-4 autoloading does file_exists() on every class load",
            },
        ],
    },
}


# Container resource patterns
CONTAINER_PATTERNS = {
    "cpu_limits": {
        "check": "CPU limits set",
        "optimal": "Request = Limit for predictable performance (Guaranteed QoS in K8s)",
        "common_mistake": "CPU limit too low → throttling; no limit → noisy neighbor",
        "aperf_correlation": "If aperf shows CPU at ~100% constantly, you're being throttled",
    },
    "memory_limits": {
        "check": "Memory limits appropriate for workload",
        "optimal": "Set to working set + 20% headroom",
        "common_mistake": "Too tight → OOM kills; too loose → GC laziness",
        "aperf_correlation": "OOM kills show as sudden process disappearance in aperf",
    },
    "base_image": {
        "check": "Using slim/distroless base image",
        "optimal": "debian-slim or distroless for production (smaller attack surface + faster pull)",
        "common_mistake": "Using full ubuntu/debian image (900MB+ vs 80MB)",
    },
    "multi_stage_build": {
        "check": "Multi-stage Dockerfile",
        "optimal": "Separate build and runtime stages",
        "common_mistake": "Build tools in production image waste memory",
    },
    "healthcheck": {
        "check": "Health check configured",
        "optimal": "Liveness + readiness probes with appropriate thresholds",
        "common_mistake": "No health check → container runs but doesn't serve",
    },
}


async def dependency_analyzer_handler(arguments: dict[str, Any]) -> str:
    """Analyze application dependencies and container config."""
    run_name = arguments.get("run_name")
    dep_content = arguments.get("dependency_file_content", "")
    dep_type = arguments.get("dependency_file_type", "")
    container_content = arguments.get("container_config_content", "")
    container_type = arguments.get("container_config_type", "")
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))

    # Heterogeneous: two nested analysis dicts (or None) alongside two accumulating lists.
    result: dict[str, Any] = {
        "status": "success",
        "dependency_analysis": None,
        "container_analysis": None,
        "optimization_plan": [],
        "version_warnings": [],
    }

    # Analyze dependencies
    if dep_content:
        dep_analysis = _analyze_dependencies(dep_content, dep_type)
        result["dependency_analysis"] = dep_analysis
        result["optimization_plan"].extend(dep_analysis.get("recommendations", []))
        result["version_warnings"].extend(dep_analysis.get("version_warnings", []))

    # Analyze container config
    if container_content:
        container_analysis = _analyze_container(container_content, container_type)
        result["container_analysis"] = container_analysis
        result["optimization_plan"].extend(container_analysis.get("recommendations", []))

    # Correlate with aperf data if run specified
    if run_name:
        from ..parsers.run_parser import AperfRunParser

        parser = AperfRunParser(base_dir=data_dir)
        report_data = parser.get_report_data(Path(data_dir) / run_name) if run_name else None

        if report_data:
            correlations = _correlate_with_aperf(result, report_data)
            result["aperf_correlations"] = correlations

    # Generate prioritized action plan
    result["action_plan"] = _generate_action_plan(result)

    return json.dumps(result, indent=2, default=str)


def _analyze_dependencies(content: str, file_type: str) -> dict[str, Any]:
    """Analyze dependency file for known frameworks and optimization opportunities."""
    # Annotated because the values are heterogeneous — two lists of strings, a string, and a list of
    # dicts. Without it mypy joins them to `Sequence[str]`, and every one of the ~40 `.append` calls
    # below becomes an error against an immutable supertype the code never intended.
    analysis: dict[str, Any] = {
        "detected_frameworks": [],
        "detected_language": "",
        "recommendations": [],
        "version_warnings": [],
    }

    content_lower = content.lower()

    if file_type in ("requirements.txt", "Pipfile", "pyproject.toml"):
        analysis["detected_language"] = "python"

        # Detect frameworks
        if "gunicorn" in content_lower:
            analysis["detected_frameworks"].append("gunicorn")
        if "uvicorn" in content_lower:
            analysis["detected_frameworks"].append("uvicorn")
        if "django" in content_lower:
            analysis["detected_frameworks"].append("django")
        if "fastapi" in content_lower:
            analysis["detected_frameworks"].append("fastapi")
        if "flask" in content_lower:
            analysis["detected_frameworks"].append("flask")
        if "celery" in content_lower:
            analysis["detected_frameworks"].append("celery")

        # Check for uvloop (performance recommendation)
        if "uvloop" not in content_lower and any(
            f in analysis["detected_frameworks"] for f in ["uvicorn", "fastapi"]
        ):
            analysis["recommendations"].append(
                {
                    "priority": "medium",
                    "action": "Add 'uvloop' to dependencies for 2-4x event loop performance",
                    "rationale": "uvloop uses libuv (C) instead of Python's asyncio loop",
                }
            )

        # Check for orjson
        if "orjson" not in content_lower and "fastapi" in analysis["detected_frameworks"]:
            analysis["recommendations"].append(
                {
                    "priority": "low",
                    "action": "Add 'orjson' for faster JSON serialization",
                    "rationale": "orjson is 3-10x faster than standard json module",
                }
            )

    elif file_type in ("pom.xml", "build.gradle"):
        analysis["detected_language"] = "java"

        if "spring-boot" in content_lower or "springframework" in content_lower:
            analysis["detected_frameworks"].append("spring-boot")
        if "quarkus" in content_lower:
            analysis["detected_frameworks"].append("quarkus")
        if "micronaut" in content_lower:
            analysis["detected_frameworks"].append("micronaut")
        if "hikari" in content_lower:
            analysis["detected_frameworks"].append("hikaricp")
        if "netty" in content_lower:
            analysis["detected_frameworks"].append("netty")
        if "virtual-threads" in content_lower or "loom" in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "high",
                    "action": "Verify JDK 21+ for virtual threads support",
                    "rationale": "Virtual threads require JDK 21+ in production",
                }
            )

    elif file_type == "package.json":
        analysis["detected_language"] = "nodejs"

        if "express" in content_lower:
            analysis["detected_frameworks"].append("express")
        if "fastify" in content_lower:
            analysis["detected_frameworks"].append("fastify")
        if "nestjs" in content_lower or "@nestjs" in content_lower:
            analysis["detected_frameworks"].append("nestjs")
        if "pm2" not in content_lower and "cluster" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "high",
                    "action": "Add PM2 or cluster module for multi-core utilization",
                    "rationale": "Node.js is single-threaded — needs clustering for multi-core",
                }
            )

    elif file_type == "composer.json":
        analysis["detected_language"] = "php"

        if "laravel" in content_lower:
            analysis["detected_frameworks"].append("laravel")
        if "symfony" in content_lower:
            analysis["detected_frameworks"].append("symfony")
        if "swoole" in content_lower or "openswoole" in content_lower:
            analysis["detected_frameworks"].append("swoole")
        if "roadrunner" in content_lower:
            analysis["detected_frameworks"].append("roadrunner")

    elif file_type == "Cargo.toml":
        analysis["detected_language"] = "rust"

        if "tokio" in content_lower:
            analysis["detected_frameworks"].append("tokio")
        if "actix" in content_lower:
            analysis["detected_frameworks"].append("actix")
        if "axum" in content_lower:
            analysis["detected_frameworks"].append("axum")

        # Check for LTO in profile
        if "lto" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "high",
                    "action": 'Add [profile.release] lto = "fat" to Cargo.toml',
                    "rationale": "LTO can improve performance 5-20% for release builds",
                }
            )

    elif file_type == "go.mod":
        analysis["detected_language"] = "go"

        if "gin-gonic" in content_lower:
            analysis["detected_frameworks"].append("gin")
        if "fiber" in content_lower:
            analysis["detected_frameworks"].append("fiber")
        if "echo" in content_lower:
            analysis["detected_frameworks"].append("echo")

    # Add framework-specific recommendations
    for framework in analysis["detected_frameworks"]:
        if framework in FRAMEWORK_OPTIMIZATIONS:
            opts = FRAMEWORK_OPTIMIZATIONS[framework]
            for opt in opts["optimizations"]:
                analysis["recommendations"].append(
                    {
                        "priority": "medium",
                        "framework": framework,
                        "setting": opt["setting"],
                        "rule": opt["rule"],
                        "common_mistake": opt["common_mistake"],
                    }
                )

    return analysis


def _analyze_container(content: str, config_type: str) -> dict[str, Any]:
    """Analyze container configuration for resource optimization."""
    analysis: dict[str, Any] = {  # heterogeneous, as in `_analyze_dependencies` above
        "config_type": config_type,
        "findings": [],
        "recommendations": [],
    }

    content_lower = content.lower()

    if config_type == "dockerfile":
        # Check base image
        if (
            "from ubuntu" in content_lower or "from debian:" in content_lower
        ) and "slim" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "medium",
                    "action": "Use slim base image (e.g., python:3.12-slim, node:20-slim)",
                    "rationale": "Reduces image size by 60-80%, faster pulls, smaller attack surface",
                }
            )

        # Check for multi-stage
        from_count = content_lower.count("from ")
        if from_count <= 1:
            analysis["recommendations"].append(
                {
                    "priority": "medium",
                    "action": "Use multi-stage Dockerfile to separate build and runtime",
                    "rationale": "Build dependencies in production image waste memory",
                }
            )

        # Check for HEALTHCHECK
        if "healthcheck" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "high",
                    "action": "Add HEALTHCHECK instruction",
                    "rationale": "Without it, orchestrator can't detect unhealthy containers",
                }
            )

    elif config_type in ("k8s-deployment", "k8s-pod"):
        # Check resource requests/limits
        if "resources" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "critical",
                    "action": "Add resource requests AND limits",
                    "rationale": "Without limits: noisy neighbor. Without requests: eviction risk.",
                }
            )

        # Check for requests != limits (burstable vs guaranteed)
        if "limits" in content_lower and "requests" in content_lower:
            analysis["findings"].append(
                "Resource requests and limits detected — verify they match for Guaranteed QoS"
            )

        # Check for liveness/readiness probes
        if "livenessprobe" not in content_lower.replace(" ", "").replace("_", ""):
            analysis["recommendations"].append(
                {
                    "priority": "high",
                    "action": "Add livenessProbe and readinessProbe",
                    "rationale": "Enables K8s to restart unhealthy pods and route traffic only to ready pods",
                }
            )

        # HPA check
        if "hpa" not in content_lower and "horizontalpodautoscaler" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "medium",
                    "action": "Consider HPA for auto-scaling based on CPU/custom metrics",
                    "rationale": "Fixed replica count may under/over-provision during load variation",
                }
            )

    elif config_type == "ecs-task-definition":
        # Check for Fargate vs EC2 launch type
        if "fargate" in content_lower:
            analysis["findings"].append(
                "Fargate launch type — CPU/memory limits are hard constraints"
            )

        # Check for proper CPU/memory ratio
        # Fargate valid combos: 256/512/1024/2048/4096 CPU, various memory per CPU
        analysis["recommendations"].append(
            {
                "priority": "medium",
                "action": "Verify CPU/memory ratio matches workload type",
                "rationale": "CPU-bound: maximize CPU. Memory-bound: maximize memory per vCPU.",
            }
        )

    elif config_type == "docker-compose":
        # Check for resource limits in compose
        if "deploy" not in content_lower or "resources" not in content_lower:
            analysis["recommendations"].append(
                {
                    "priority": "medium",
                    "action": "Add deploy.resources.limits for CPU and memory",
                    "rationale": "Without limits, containers compete unfairly for host resources",
                }
            )

    return analysis


def _correlate_with_aperf(
    analysis_result: dict[str, Any], report_data: dict[str, Any]
) -> list[dict[str, Any]]:
    """Correlate dependency/container analysis with aperf findings."""
    correlations = []

    dep = analysis_result.get("dependency_analysis", {})
    frameworks = dep.get("detected_frameworks", []) if dep else []

    cpu_data = report_data.get("cpu_utilization", {})
    if cpu_data and "aggregate" in cpu_data:
        idle_series = cpu_data["aggregate"].get("idle", [])
        if idle_series:
            avg_util = 100 - (sum(idle_series) / len(idle_series))

            # Single-threaded runtime but low CPU
            if (
                dep
                and dep.get("detected_language") == "nodejs"
                and avg_util < 30
                and "express" in frameworks
                and "pm2" not in str(analysis_result)
            ):
                correlations.append(
                    {
                        "finding": "Node.js Express detected with low CPU utilization",
                        "aperf_evidence": f"Average CPU utilization: {avg_util:.0f}%",
                        "recommendation": "Deploy with cluster mode (PM2 or native cluster) to utilize all CPUs",
                        "expected_improvement": f"Up to {100 / avg_util:.0f}x throughput improvement",
                    }
                )

    return correlations


def _generate_action_plan(result: dict[str, Any]) -> list[dict[str, Any]]:
    """Generate a prioritized action plan from all findings."""
    actions = []

    # Gather all recommendations
    all_recs = result.get("optimization_plan", [])

    # Sort by priority
    priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    sorted_recs = sorted(all_recs, key=lambda r: priority_order.get(r.get("priority", "low"), 4))

    for i, rec in enumerate(sorted_recs[:10], 1):  # Top 10 actions
        actions.append(
            {
                "step": i,
                "priority": rec.get("priority", "medium"),
                "action": rec.get("action", rec.get("rule", "")),
                "rationale": rec.get("rationale", rec.get("common_mistake", "")),
                "framework": rec.get("framework", ""),
            }
        )

    return actions
