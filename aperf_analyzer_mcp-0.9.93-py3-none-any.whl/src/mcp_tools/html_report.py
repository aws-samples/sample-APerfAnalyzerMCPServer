# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: generate_html_report

Generates a customer-grade HTML performance analysis report with:
- System metadata header with instance/architecture/CPU/memory/OS
- Health summary (prose, not a composite score)
- System metrics grid
- CPU sample distribution (when flamegraph available)
- Findings cards with severity badges and code-fix blocks
- Dependency analysis table (when dep file available)
- Migration roadmap with instance comparison cards
- Pricing placeholders ({{PRICE_FROM}}, {{PRICE_TO_X}}, {{NEWEST_X86_AMD_GEN}}, etc.)
  for the agent to fill via AWS Pricing MCP
- Prioritized action plan
- Caveat banners when data is incomplete
"""

from __future__ import annotations

import json
import os
from html import escape as html_escape
from pathlib import Path
from typing import Any

from markdown_it import MarkdownIt
from mcp.types import Tool

from ..thresholds import APERF_BRANCH_MPKI, FLOOR_DTLB_MPKI, FLOOR_ITLB_MPKI


def _fmt_samples(n: int) -> str:
    """
    Compact K/M/B/T rendering of a flamegraph sample count.

    aperf 1.3.0 weights perf samples by period rather than counting them 1:1, so
    `total_samples` on a busy multi-core capture can run into the trillions (observed:
    19,195,244,648,421 on a real EMR run) — the raw comma-grouped digit string overflows
    the metric card's fixed-width field. This is display-only: nothing downstream (the
    per-function percentages) uses the abbreviated form, only the literal integer.
    """
    if n < 1_000_000:
        return f"{n:,}"
    for divisor, suffix in ((1_000_000_000_000, "T"), (1_000_000_000, "B"), (1_000_000, "M")):
        if n >= divisor:
            return f"{n / divisor:.2f}{suffix}"
    return f"{n:,}"


def _esc(value: object) -> str:
    """
    Escape playbook text for HTML interpolation.

    Advice strings use angle brackets for placeholders — `<node>`, `<bytes>`, `Span<T>`,
    `/proc/irq/<n>/smp_affinity`. Interpolated raw, a browser parses those as unknown tags
    and drops them, so `numactl --cpubind=<node> --membind=<node>` reaches the operator as
    `numactl --cpubind= --membind=`. No rule in the DB contains intentional markup, so
    escaping is unconditional.
    """
    return html_escape("" if value is None else str(value))


#: Renders real playbook Markdown (bold, inline code, numbered/bulleted lists, tables)
#: into HTML. `html: False` disables raw-HTML passthrough, so an angle-bracket
#: placeholder like `<node>` in the SAME playbook text `_esc` guards against gets
#: escaped to `&lt;node&gt;` rather than parsed as an unknown tag and dropped — the
#: exact safety property `_esc` exists for, preserved here for markdown-shaped text.
#: A single module-level instance: `MarkdownIt()` parses its ruleset once at
#: construction, and this text is rendered once per gap finding per report, not once
#: per line.
_MD = MarkdownIt("commonmark", {"html": False})


def _render_md(value: object) -> str:
    """`_esc`'s markdown-aware counterpart — for playbook prose, not plain advice strings."""
    return _MD.render("" if value is None else str(value))


GENERATE_HTML_REPORT_TOOL = Tool(
    name="generate_html_report",
    description=(
        "Generate a customer-grade HTML performance analysis report from an aperf run. "
        "Includes system metrics, findings with severity badges, dependency analysis, "
        "instance migration roadmap with phased recommendations, and prioritized action plan. "
        "Pricing fields are returned as placeholders (e.g. {{PRICE_FROM}}, {{NEWEST_X86_AMD_GEN}}) "
        "for the agent to fill via AWS Pricing MCP. "
        "Reads application context from the saved fingerprint store; if no context exists, "
        "the pre-tool hook will prompt the user for one before this tool runs."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Primary aperf run to analyze"},
            "baseline_run": {
                "type": "string",
                "description": "Optional baseline run for comparison",
            },
            "output_path": {"type": "string", "description": "Output HTML file path"},
            "data_dir": {"type": "string"},
            "customer_name": {"type": "string", "description": "Customer/project name for header"},
            "app_context": {
                "type": "object",
                "description": "Application context (auto-injected by pre-tool hook)",
            },
        },
        "required": ["run_name"],
    },
)


async def generate_html_report_handler(arguments: dict[str, Any]) -> str:
    """Generate a complete HTML performance analysis report."""
    run_name = arguments["run_name"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    customer_name = arguments.get("customer_name", "")
    output_path = arguments.get("output_path")
    app_context = arguments.get("app_context", {}) or {}

    from ..mcp_tools.recommendation_engine import build_recommendations
    from ..mcp_tools.system_health import system_health_handler
    from ..parsers.cpu_parser import CpuUtilizationParser
    from ..parsers.dep_analyzer import analyze_dep_file
    from ..parsers.flamegraph_parser import FlamegraphParser
    from ..parsers.memory_parser import MemoryParser
    from ..parsers.pmu_parser import PmuParser
    from ..parsers.run_parser import AperfRunParser

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)
    if not run_data:
        return json.dumps(
            {"status": "error", "message": f"Run '{run_name}' not found in {data_dir}"}
        )

    # Auto-load persisted application context for this run's fingerprint.
    # Explicit values from the tool call take precedence over the loaded context.
    from ..context_loader import load_context_for_run, merge_context

    loaded_ctx, fp_hash = load_context_for_run(Path(run_data.metadata.run_path))
    app_context = merge_context(app_context, loaded_ctx)
    if fp_hash and "fingerprint_hash" not in app_context:
        app_context["fingerprint_hash"] = fp_hash

    # Context completeness check. Required-for-quality fields are
    # app_name, customer_priority, capture_type, dep_file. When ALL of
    # these are missing we mark the report as 'context-missing' so the
    # rendered HTML can show a prominent banner and the JSON response
    # tells the caller to provide context for higher-fidelity output.
    _required_keys = ("app_name", "customer_priority", "capture_type", "dep_file")
    _present = [k for k in _required_keys if app_context.get(k)]
    _missing = [k for k in _required_keys if not app_context.get(k)]
    if not _present:
        app_context["_context_status"] = "missing"
    elif _missing:
        app_context["_context_status"] = "partial"
        app_context["_context_missing_keys"] = _missing
    else:
        app_context["_context_status"] = "complete"

    # `RunMetadata` carries `run_path` as a str, and has no `path` attribute — `get_report_data`
    # coerces, but the glob below needs a real `Path`.
    run_path = Path(run_data.metadata.run_path)
    report_data = parser.get_report_data(run_path) or {}

    # Language is shown/used only when the user supplied it explicitly (questionnaire
    # answer or `app_context`) — the process-name-based guess (`detect_primary_language`)
    # is deliberately not run here: its needle table only covers a handful of common
    # runtimes (Java/Python/Node/Go/.NET/Rust/PHP), so most real workload process names
    # resolve to "unknown" regardless, and per user request this report no longer shows
    # that guess at all. `graviton_readiness` still uses the same detector directly
    # (unaffected by this change) since it labels its output as a guess with a
    # confidence level rather than rendering it as a report header field.
    _language_was_explicit = bool(
        app_context.get("language")
        or app_context.get("primary_language")
        or app_context.get("runtime")
    )

    # Flamegraph, when the run was recorded with `--profile`.
    #
    # aperf names the SVG after the run, not `aperf_record`: a report holds
    # `data/js/<run>-flamegraph.svg` and a 1.3.0 record directory holds a bare `flamegraph.svg`
    # (1.2.2 used `<run>-flamegraph.svg` there). Globs are sorted so the choice is deterministic,
    # and `reverse-` is excluded because an inverted flamegraph aggregates to the same totals with
    # the callers as leaves.
    fg_summary = None
    if report_data:
        candidates = [
            *sorted(run_path.glob("data/js/*-flamegraph.svg")),
            *sorted(run_path.glob("*-flamegraph.svg")),
            run_path / "flamegraph.svg",
        ]
        for svg_candidate in candidates:
            if svg_candidate.name.startswith("reverse-") or "-reverse-" in svg_candidate.name:
                continue
            if svg_candidate.exists():
                fg_summary = FlamegraphParser().parse_file(svg_candidate)
                break

    # CPU summary
    cpu_summary = None
    if "cpu_utilization" in report_data:
        cpu_summary = CpuUtilizationParser().parse_from_report_data(report_data)

    # PMU summary
    pmu_summary = None
    if "perf_stat" in report_data:
        pmu_summary = PmuParser().parse_from_report_data(report_data)

    # Memory summary
    mem_summary = None
    if "meminfo" in report_data:
        mem_summary = MemoryParser().parse_from_report_data(report_data)

    # Disk summary — real per-device I/O saturation (utilization%, queue depth, await),
    # computed directly from aperf's own diskstats collector. Grounds exactly the kind
    # of "is storage the bottleneck" question a customer/agent would otherwise have to
    # guess at (e.g. inventing an EBS volume type this data cannot see).
    from ..parsers.disk_parser import DiskParser

    disk_summary = DiskParser().parse_from_report_data(report_data)

    # Measured anomalies — real numbers computed directly from this run's own CPU/
    # memory/disk summaries and process data, but NOT anchored to a curated aperf
    # finding (no playbook rule fires on them). Kept separate from `playbook_matches`
    # so the action plan can label them explicitly as measured-not-curated, the same
    # distinction `sysctl_ai_fallback.py` already draws between playbook-derived and
    # AI-generated guidance, applied here to measured-vs-curated instead.
    measured_anomalies: list[str] = []
    if cpu_summary:
        measured_anomalies.extend(CpuUtilizationParser().detect_anomalies(cpu_summary))
    if mem_summary:
        measured_anomalies.extend(MemoryParser().detect_anomalies(mem_summary))
    if disk_summary:
        measured_anomalies.extend(DiskParser().detect_anomalies(disk_summary))

    from .config_diagnosis import _detect_worker_imbalance

    worker_imbalance = _detect_worker_imbalance(report_data.get("processes", {}) or {})

    # System health
    sys_health_raw = await system_health_handler({"run_name": run_name, "data_dir": data_dir})
    try:
        sys_health = json.loads(sys_health_raw)
    except Exception:
        sys_health = {}

    # Resolve dep file from app_context
    dep_analysis = None
    dep_file_status = app_context.get("dep_file_status", "skipped")
    dep_file_resolved = app_context.get("dep_file_resolved")
    if dep_file_resolved:
        try:
            dep_analysis = analyze_dep_file(Path(dep_file_resolved))
            # `analyze_dep_file` never raises for a bad path or malformed content — it
            # reports both inline via `parse_errors` and still returns a `DepAnalysis`
            # (e.g. unreadable path -> language="unknown", parse_errors=["Could not
            # detect format of ..."]). The `except` below is therefore dead code for
            # this function; the real success/failure signal is `parse_errors`. This
            # used to report "skipped" for a fully successful parse too (72 real
            # dependencies rendered in the report's Dependencies tab) because nothing
            # on the success path ever moved the status off its "skipped" default.
            dep_file_status = (
                f"parse-error:{'; '.join(dep_analysis.parse_errors)}"
                if dep_analysis.parse_errors
                else "analyzed"
            )
        except Exception as e:
            dep_analysis = None
            dep_file_status = f"parse-error:{e}"

    # Build dep_analysis dict for recommendation engine
    dep_dict = None
    if dep_analysis:
        dep_dict = {
            "language": dep_analysis.language,
            "blockers": [
                {"name": b.name, "version": b.version, "action": b.action, "reason": b.reason}
                for b in dep_analysis.blockers
            ],
            "degradeds": [
                {"name": d.name, "version": d.version, "action": d.action, "reason": d.reason}
                for d in dep_analysis.degradeds
            ],
            "verifies": [{"name": v.name, "version": v.version} for v in dep_analysis.verifies],
            "total": dep_analysis.total_count,
        }

    # Build PMU/CPU/memory dicts for recommendation engine
    pmu_dict = (
        {
            "ipc": pmu_summary.ipc if pmu_summary else 0,
            "backend_stall_pct": pmu_summary.backend_stall_pct if pmu_summary else 0,
            "frontend_stall_pct": pmu_summary.frontend_stall_pct if pmu_summary else 0,
            "dtlb_misses_per_1k_insns": pmu_summary.dtlb_misses_per_1k_instructions
            if pmu_summary
            else 0,
        }
        if pmu_summary
        else {}
    )

    cpu_dict = (
        {
            "avg_utilization_pct": cpu_summary.avg_total_utilization_pct if cpu_summary else 0,
            "peak_utilization_pct": cpu_summary.peak_utilization_pct if cpu_summary else 0,
        }
        if cpu_summary
        else {}
    )

    mem_dict = (
        {
            "avg_used_pct": mem_summary.avg_used_pct if mem_summary else 0,
        }
        if mem_summary
        else {}
    )

    metadata_dict = {
        "instance_type": run_data.metadata.instance_type,
        "architecture": run_data.metadata.architecture,
        "cpu_count": run_data.metadata.cpu_count,
    }

    # Generate recommendations
    recs = build_recommendations(pmu_dict, cpu_dict, mem_dict, metadata_dict, app_context, dep_dict)

    # Resolve {{NEWEST_*_GEN}} placeholders in instance_type templates using pricing data
    from . import pricing as _pricing_mod

    for opt in recs.instance_options:
        opt.instance_type = _pricing_mod.resolve_instance_type(opt.instance_type)

    # Findings aperf itself emitted. Parsed BEFORE sizing because the workload
    # classifier uses them to corroborate its metric bands, and the playbook engine
    # below is gated on them entirely.
    #
    # Best-effort: a raw `aperf record` directory carries no `<data_type>_findings`
    # variables, only a generated report does, and a drifted payload can raise from
    # the parser. Either way the answer is 'no anchors', not a failed report.
    aperf_findings = None
    try:
        from ..parsers.findings_parser import FindingsParseError, parse_findings

        # `run_path` is the RESOLVED location — for a `<run>.tar.gz` archive the parser
        # extracted to a tempdir, so reconstructing `data_dir / run_name` would miss it and
        # silently drop every anchor.
        aperf_findings = parse_findings(run_path)
    except (FindingsParseError, OSError, ValueError, TypeError, AttributeError):
        # Not a readable aperf report (a raw `aperf record` dir has no findings variables),
        # or a payload whose shape drifted (null `score` -> TypeError from float(); a bare
        # string where a dict belongs -> AttributeError). Either way there is nothing to
        # anchor on, and the tuning sections stay empty rather than being filled with
        # unmeasured advice. None of these should fail report generation outright.
        aperf_findings = None

    # Right-sizing, from the benchmark-backed engine.
    #
    # Replaces the CoreMark/Vantage sizing pass. The new engine differs in ways the report
    # has to respect:
    #
    #   - it returns a VERDICT, so "keep your current instance" is a real answer rather
    #     than an empty list the report used to render as a gap;
    #   - it never crosses a purpose-built family class (i/x/u/accelerator) or leaves
    #     Graviton, so its candidates need no second-guessing here;
    #   - its benchmark figures are INTERNAL. Nothing from `candidate.internal` may reach
    #     the HTML, and no ratio derived from it either — a headroom percentage inverts to
    #     the score once one absolute value is known.
    from .rightsizer import is_cost_priority as _is_cost_priority
    from .rightsizer import recommend as _recommend
    from .rightsizer import recommend_graviton_equivalent as _recommend_graviton
    from .workload_classifier import classify as _classify

    workload_profile = _classify(
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        mem_summary=mem_summary,
        aperf_findings=aperf_findings,
    )

    # Capacity demand needs the same unit guard the tool applies: the flat-binary path
    # reports BYTES in a field named `mem_total_kb`, so `total_mb` can arrive 1024x too
    # large. Unguarded that produced a 15,177 GB demand on a real 256 GB instance.
    #
    # The demand is the current instance's OWN installed RAM, not a peak-scaled fraction
    # of it. There is no way to run this workload on less memory than it already has
    # allocated — the customer cannot "use" more RAM than was provisioned, so a peak of
    # 83.8% does not mean 83.8% of capacity is the requirement; 100% of the current
    # capacity is, because that is what is provisioned and available to it today. A 1.5x
    # buffer on top of that (623 GB demanded from a 496 GB box) invented headroom nothing
    # asked for and ruled out every reasonably-sized candidate, forcing jumps to `.48xlarge`
    # instances that cost MORE than the current box on a workload whose actual problem is
    # underused CPU, not insufficient memory. `_eligible`'s existing 10% noise band is
    # the only tolerance this comparison needs.
    _MAX_PLAUSIBLE_MB = 32 * 1024 * 1024
    capacity_gb: float | None = None
    if mem_summary is not None and getattr(mem_summary, "total_mb", 0.0):
        _total_mb = float(mem_summary.total_mb)
        while _total_mb > _MAX_PLAUSIBLE_MB:
            _total_mb /= 1024.0
        capacity_gb = _total_mb / 1024.0

    # Cost leads the ranking unless the customer has explicitly stated a different
    # priority. "Not defined" is treated the same as "cost" — see `recommend`'s docstring.
    _cost_priority = _is_cost_priority(app_context.get("customer_priority"))

    sizing = _recommend(
        current_instance=run_data.metadata.instance_type,
        profile=workload_profile,
        memory_capacity_gb=capacity_gb,
        cost_priority=_cost_priority,
        arm64_blocker_count=len(dep_analysis.blockers) if dep_analysis else 0,
    )

    # Computed once here and threaded through to BOTH the ARM Modernization tab and the
    # Right-sizing tab's comparison card, so the two tabs can never show a different
    # Graviton pick for the same run.
    graviton_candidate = _recommend_graviton(
        current_instance=run_data.metadata.instance_type,
        profile=workload_profile,
        memory_capacity_gb=capacity_gb,
        cost_priority=_cost_priority,
        arm64_blocker_count=len(dep_analysis.blockers) if dep_analysis else 0,
    )

    # Run the diagnostic playbook engine — anchored on aperf's own findings.
    #
    # `aperf_findings` is what makes the engine produce anything: every rule is gated on a
    # finding aperf emitted, so omitting it yields no advice. Parsing is best-effort
    # because a raw `aperf record` directory carries no `<data_type>_findings` variables —
    # only a generated report does. In that case there are legitimately no findings to
    # anchor on, and the tuning sections stay empty rather than being filled with advice
    # nothing measured.
    from ..playbook_engine import evaluate_for_report

    playbook_matches = evaluate_for_report(
        meta=run_data.metadata,
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        mem_summary=mem_summary,
        sys_health=sys_health,
        app_context=app_context,
        recommendations=recs,
        aperf_findings=aperf_findings,
    )

    # Real MCP sampling for gap findings (fired, but no curated os_remediation entry)
    # — computed here, in the async handler, since `_build_html` itself stays
    # synchronous for its dozens of existing direct test call sites. `_fired`/
    # `curated_anchors`/`_sysctl_gap_list` are re-derived the same way
    # `_build_system_sysctl` derives them internally, so this pre-fetch can never name
    # a different gap list than what actually renders.
    _fired_for_gaps: set[str] = set()
    for _item in getattr(aperf_findings, "findings", aperf_findings) or ():
        _name = getattr(_item, "rule_name", _item)
        if isinstance(_name, str):
            _fired_for_gaps.add(_name)
    _curated_anchors: set[str] = set()
    for _m in playbook_matches or []:
        if getattr(_m, "os_remediation", None):
            _curated_anchors.update(getattr(_m, "anchored_by", None) or ())
    _gap_findings = _sysctl_gap_list(_fired_for_gaps, _curated_anchors)
    gap_finding_guidance = await gather_gap_finding_guidance(
        _gap_findings, aperf_findings, app_context
    )

    # Build the HTML
    html = _build_html(
        run_name=run_name,
        run_data=run_data,
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        mem_summary=mem_summary,
        sys_health=sys_health,
        dep_analysis=dep_analysis,
        dep_file_status=dep_file_status,
        recommendations=recs,
        app_context=app_context,
        customer_name=customer_name,
        fg_summary=fg_summary,
        playbook_matches=playbook_matches,
        sizing=sizing,
        graviton_candidate=graviton_candidate,
        language_was_explicit=_language_was_explicit,
        gap_finding_guidance=gap_finding_guidance,
        measured_anomalies=measured_anomalies,
        worker_imbalance=worker_imbalance,
        workload_profile=workload_profile,
        aperf_findings=aperf_findings,
    )

    if not output_path:
        output_path = str(Path(data_dir) / f"{run_name}_aperf_report.html")

    # Fill pricing placeholders from the bundled us-east-1 pricing file
    from . import pricing as _pricing

    current_instance = run_data.metadata.instance_type or ""
    html = _pricing.fill_placeholders(html, current_instance, recs.instance_options)

    Path(output_path).write_text(html, encoding="utf-8")

    pricing_status, pricing_days = _pricing.pricing_freshness()

    response = {
        "status": "success",
        "output_path": output_path,
        "run_name": run_name,
        "app_context_used": bool(app_context),
        "context_status": app_context.get("_context_status", "complete"),
        "flamegraph_analyzed": fg_summary is not None,
        "total_samples": fg_summary.total_samples if fg_summary else 0,
        "anomalies_found": len(fg_summary.anomalies) if fg_summary else 0,
        "dep_file_status": dep_file_status,
        # Single-sourced from `rightsizer.recommend_graviton_equivalent()` — the SAME
        # candidate the HTML body's ARM Modernization tab and Right-sizing comparison
        # card render. This used to read `recs.graviton_recommended`/
        # `len(recs.instance_options)` from the older template-based
        # `recommendation_engine.py`, which is excluded from the HTML body precisely
        # because it is a second, disagreeing sizing voice (see the "Instance-change
        # rows are deliberately NOT emitted here" comment on `_build_action_plan`) — a
        # caller reading only this JSON, never opening the HTML, got that stale
        # engine's answer instead of what the report actually shows.
        "graviton_recommended": graviton_candidate is not None,
        "graviton_candidate": (
            {
                "instance_type": graviton_candidate.instance_type,
                "vcpu": graviton_candidate.vcpu,
                "memory_gb": graviton_candidate.memory_gb,
                "risk": graviton_candidate.risk,
                "price_per_hour": graviton_candidate.price_per_hour,
            }
            if graviton_candidate is not None
            else None
        ),
        "blockers_found": len(dep_analysis.blockers) if dep_analysis else 0,
        "degradeds_found": len(dep_analysis.degradeds) if dep_analysis else 0,
        "pricing_data_status": pricing_status,
        "pricing_data_age_days": pricing_days,
        "message": f"Report written to {output_path}.",
    }

    # Surface missing-context guidance so the calling agent knows to ask
    # the user for app_name / customer_priority / capture_type / dep_file
    # before re-running for higher fidelity.
    _ctx_status = app_context.get("_context_status", "complete")
    if _ctx_status in ("missing", "partial"):
        _ctx_missing = app_context.get("_context_missing_keys") or [
            k
            for k in ("app_name", "customer_priority", "capture_type", "dep_file")
            if not app_context.get(k)
        ]
        response["context_missing_keys"] = _ctx_missing
        response["context_action_required"] = (
            "Application context is "
            + ("MISSING" if _ctx_status == "missing" else "PARTIAL")
            + ". Recommendations and Graviton analysis will be limited until "
            + "context is provided. Ask the user for: "
            + ", ".join(_ctx_missing)
            + ". Pass them via app_context on the next call, or set up the "
            + "fingerprint hook (hooks/aperf_context_hook.py) to capture "
            + "them automatically."
        )

    # Surface a refresh hint when pricing data is not fresh, so the agent
    # can prompt the user to approve a refresh before the next analysis.
    if pricing_status in ("aging", "stale", "missing"):
        response["pricing_refresh_hint"] = (
            f"Pricing data is {pricing_status} ({pricing_days} days old). "
            f"Cost recommendations in this report use that data. "
            f"To refresh before the next analysis, ask the user to approve, then call "
            f"the 'pricing_status' tool with confirm=true."
        )

    return json.dumps(response, indent=2)


_CSS = """
:root {
  --bg: #f8f9fa; --surface: #fff; --border: rgba(0,0,0,.08);
  --text: #111827; --text-secondary: #4b5563; --text-muted: #9ca3af;
  --accent: #2563eb; --red: #dc2626; --orange: #d97706; --green: #16a34a;
  --purple: #7c3aed; --amber: #b45309;
  --red-bg: #fef2f2; --orange-bg: #fffbeb; --green-bg: #f0fdf4;
  --blue-bg: #eff6ff; --purple-bg: #f5f3ff; --amber-bg: #fffbeb;
  --font-mono: 'SF Mono','Fira Code','Cascadia Code',monospace;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; background: var(--bg); color: var(--text); font-size: 14px; line-height: 1.6; }
.page-header { background: #0f172a; color: #f1f5f9; padding: 32px 48px; }
.page-header .label { font-size: 11px; text-transform: uppercase; letter-spacing: .1em; color: #64748b; font-weight: 500; margin-bottom: 6px; }
.page-header h1 { font-size: 22px; font-weight: 600; letter-spacing: -.02em; }
.page-header .meta { display: flex; gap: 24px; margin-top: 16px; flex-wrap: wrap; }
.meta-item { display: flex; flex-direction: column; gap: 2px; }
.meta-item .key { font-size: 10px; text-transform: uppercase; letter-spacing: .08em; color: #475569; font-weight: 500; }
.meta-item .val { font-size: 13px; color: #cbd5e1; font-family: var(--font-mono); }
.health-banner { background: #1e293b; padding: 10px 48px; display: flex; align-items: center; border-bottom: 1px solid rgba(255,255,255,.05); }
.health-summary p { font-size: 12px; color: #94a3b8; max-width: 900px; margin: 0; }
.main { max-width: 1200px; margin: 0 auto; padding: 32px 48px 64px; }
.section { margin-bottom: 40px; }
.section-title { font-size: 12px; font-weight: 600; text-transform: uppercase; letter-spacing: .08em; color: var(--text-muted); margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid var(--border); }
.metrics-grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(160px,1fr)); gap: 12px; }
.metric-card { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 16px; }
.metric-label { font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: .06em; font-weight: 500; margin-bottom: 6px; }
.metric-value { font-size: 22px; font-weight: 700; font-family: var(--font-mono); color: var(--text); line-height: 1; }
.metric-sub { font-size: 11px; color: var(--text-muted); margin-top: 4px; }
.metric-card.warn .metric-value { color: var(--orange); }
.metric-card.crit .metric-value { color: var(--red); }
.metric-card.ok .metric-value { color: var(--green); }
.metric-card.info .metric-value { color: var(--accent); }
.badge { display: inline-flex; align-items: center; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; flex-shrink: 0; }
.badge.high, .badge.critical, .badge.blocker { background: var(--red-bg); color: var(--red); }
.badge.medium, .badge.warning { background: var(--orange-bg); color: var(--orange); }
.badge.low, .badge.info { background: var(--blue-bg); color: var(--accent); }
/* Distinct from severity badges above on purpose: MEASURED means "real number, computed
   directly from this run's own data" — not a curated aperf finding, not a schema-vetted
   playbook entry. A reader must be able to tell the two apart at a glance. */
.badge.measured { background: var(--purple-bg); color: var(--purple); }
.badge.ok, .badge.clear { background: var(--green-bg); color: var(--green); }
.badge.verify { background: var(--amber-bg); color: var(--amber); }
.badge.degraded { background: var(--orange-bg); color: var(--orange); border: 1px solid #fed7aa; }
.finding { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; padding: 20px 24px; margin-bottom: 12px; border-left: 3px solid transparent; }
.finding.high, .finding.critical { border-left-color: var(--red); }
.finding.medium, .finding.warning { border-left-color: var(--orange); }
.finding.low { border-left-color: var(--accent); }
.finding.info { border-left-color: #94a3b8; }
.finding-header { display: flex; align-items: flex-start; gap: 12px; margin-bottom: 10px; }
.finding-title { font-size: 14px; font-weight: 600; color: var(--text); }
.finding-meta { font-size: 11px; color: var(--text-muted); font-family: var(--font-mono); margin-top: 2px; }
.finding-body { font-size: 13px; color: var(--text-secondary); line-height: 1.6; }
.fix-block { background: #0f172a; border-radius: 6px; padding: 14px 16px; margin-top: 12px; }
.fix-block .fix-label { font-size: 10px; text-transform: uppercase; letter-spacing: .08em; color: #475569; font-weight: 600; margin-bottom: 8px; }
.fix-block pre { font-family: var(--font-mono); font-size: 12px; color: #e2e8f0; white-space: pre-wrap; line-height: 1.7; }
.fix-block .comment { color: #475569; }
.fix-block .key { color: #fbbf24; }
.fix-block .val { color: #86efac; }
.fix-block .cmd { color: #7dd3fc; }
.table-wrap { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; overflow: hidden; overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
thead th { background: #f8f9fa; padding: 10px 16px; text-align: left; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: .06em; color: var(--text-muted); border-bottom: 1px solid var(--border); }
tbody td { padding: 10px 16px; border-bottom: 1px solid var(--border); color: var(--text-secondary); font-size: 12px; }
tbody td.name { font-weight: 600; color: var(--text); font-family: var(--font-mono); font-size: 11px; }
tbody tr:last-child td { border-bottom: none; }
tbody tr:hover td { background: #f8f9fa; }
.instance-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }
.instance-card { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; overflow: hidden; }
.instance-card.current .instance-header { background: #1e293b; }
.instance-card.modernize .instance-header { background: #451a03; }
.instance-card.graviton .instance-header { background: #064e3b; }
.instance-header { padding: 14px 20px; }
.instance-header .ilabel { font-size: 10px; text-transform: uppercase; letter-spacing: .08em; font-weight: 600; margin-bottom: 4px; }
.instance-card.current .instance-header .ilabel { color: #64748b; }
.instance-card.modernize .instance-header .ilabel { color: #fed7aa; }
.instance-card.graviton .instance-header .ilabel { color: #6ee7b7; }
.instance-header .iname { font-size: 16px; font-weight: 700; font-family: var(--font-mono); color: #f1f5f9; }
.instance-card.modernize .instance-header .iname { color: #fdba74; }
.instance-card.graviton .instance-header .iname { color: #6ee7b7; }
.instance-header .idesc { font-size: 11px; margin-top: 2px; color: #94a3b8; }
.instance-body { padding: 14px 20px; }
.irow { display: flex; justify-content: space-between; align-items: center; padding: 5px 0; border-bottom: 1px solid var(--border); font-size: 12px; }
.irow:last-child { border-bottom: none; }
.ikey { color: var(--text-muted); }
.ival { font-family: var(--font-mono); font-weight: 600; color: var(--text); font-size: 11px; }
.ival.better { color: var(--green); }
.ival.same { color: var(--text-muted); }
.note-box { background: var(--blue-bg); border: 1px solid #bfdbfe; border-radius: 8px; padding: 14px 18px; font-size: 13px; color: #1e40af; margin-top: 16px; }
.warn-box { background: var(--orange-bg); border: 1px solid #fed7aa; border-radius: 8px; padding: 14px 18px; font-size: 13px; color: #92400e; margin-top: 12px; }
.error-box { background: var(--red-bg); border: 1px solid #fca5a5; border-radius: 8px; padding: 14px 18px; font-size: 13px; color: #991b1b; margin-top: 12px; }
.placeholder { background: #fef3c7; color: #92400e; padding: 1px 6px; border-radius: 3px; font-family: var(--font-mono); font-size: 11px; font-weight: 600; }
.page-footer { text-align: center; padding: 32px; font-size: 11px; color: var(--text-muted); border-top: 1px solid var(--border); margin-top: 40px; }
"""

# Tab chrome, kept separate from _CSS so the report body and its navigation can be reasoned
# about independently.
#
# No JavaScript by design: this file is emailed and opened from disk, where scripts are
# routinely blocked but CSS is not. The radios are visually hidden rather than `hidden`, so
# they keep native radio-group keyboard behaviour — Tab reaches the group, arrow keys move
# between tabs — which is the interaction the ARIA tab pattern prescribes and which a
# `hidden` input plus `tabindex` on the label cannot deliver (a label is not activatable
# from the keyboard).
_TAB_CSS = """
.tabs { position: relative; }
.tab-radio { position: absolute; width: 1px; height: 1px; opacity: 0; }
.tab-bar { display: flex; gap: 4px; flex-wrap: wrap; border-bottom: 1px solid var(--border); margin-bottom: 28px; }
.tab-label { padding: 9px 18px; font-size: 13px; font-weight: 600; color: var(--text-secondary); cursor: pointer; border-bottom: 2px solid transparent; margin-bottom: -1px; white-space: nowrap; user-select: none; }
.tab-label:hover { color: var(--text); background: rgba(0,0,0,.02); }
.tab-panel { display: none; }
.tab-panel > .section:last-child { margin-bottom: 0; }
.print-only { display: none; }
#tab-summary:checked ~ .tab-bar [for="tab-summary"],
#tab-sizing:checked ~ .tab-bar [for="tab-sizing"],
#tab-findings:checked ~ .tab-bar [for="tab-findings"],
#tab-system:checked ~ .tab-bar [for="tab-system"],
#tab-arm:checked ~ .tab-bar [for="tab-arm"] { color: var(--accent); border-bottom-color: var(--accent); }
#tab-summary:focus-visible ~ .tab-bar [for="tab-summary"],
#tab-sizing:focus-visible ~ .tab-bar [for="tab-sizing"],
#tab-findings:focus-visible ~ .tab-bar [for="tab-findings"],
#tab-system:focus-visible ~ .tab-bar [for="tab-system"],
#tab-arm:focus-visible ~ .tab-bar [for="tab-arm"] { outline: 2px solid var(--accent); outline-offset: 2px; border-radius: 4px 4px 0 0; }
#tab-summary:checked ~ #panel-summary,
#tab-sizing:checked ~ #panel-sizing,
#tab-findings:checked ~ #panel-findings,
#tab-system:checked ~ #panel-system,
#tab-arm:checked ~ #panel-arm { display: block; }
@media print {
  /* A printed or saved-as-PDF copy must be the whole report, not whichever tab happened
     to be open. Every panel expands and the tab bar itself is dropped, since a control
     nobody can click is noise on paper. */
  .tab-bar { display: none; }
  .tab-panel { display: block !important; page-break-before: always; }
  .tab-panel:first-of-type { page-break-before: avoid; }
  .print-only { display: block; }
  .tab-print-title { font-size: 18px; font-weight: 700; margin-bottom: 20px; padding-bottom: 8px; border-bottom: 2px solid var(--text); }
  .page-header, .health-banner { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .section, .finding, .metric-card { page-break-inside: avoid; }
}
"""

# Shared so the Summary tab and the Right-sizing tab cannot drift into styling the same
# verdict differently. "Keep what you have" is a decision, so it is coloured as one rather
# than as a failure to recommend.
_VERDICT_TONE = {
    "change_recommended": ("#1d4ed8", "#eff6ff"),
    "already_optimal": ("#047857", "#ecfdf5"),
    "no_better_option": ("#047857", "#ecfdf5"),
    "insufficient_data": ("#92400e", "#fffbeb"),
}
_VERDICT_DEFAULT_TONE = ("#475569", "#f8f9fa")

# Pressure level -> metric-card class. `unknown` deliberately maps to no class: an
# unmeasured dimension must not be tinted green as though it had been measured and found
# quiet, which is the exact confusion the classifier's `gaps` list exists to prevent.
_PRESSURE_CLASS = {"high": "warn", "moderate": "info", "none": "ok"}

#: Hours in a year at the fixed 720h/month convention this report uses everywhere it
#: annualises an hourly rate — 720 * 12, not 24 * 365. Named so the two call sites (the
#: Summary picks table and the Right-sizing candidate cards) cannot drift apart on which
#: convention they annualise with.
_HOURS_PER_YEAR = 720 * 12


def _cost_diff_html(current_price: float | None, candidate_price: float | None) -> str:
    """
    Cost delta vs. the current instance: %/hr and $/year at `_HOURS_PER_YEAR` hours.

    Green for a reduction, red for an increase — including the case this is explicitly
    NOT a savings pitch: a workload under real pressure whose only eligible candidate is
    WIDER and pricier than current. That candidate must still show its true cost in red,
    not be hidden, because the trade-off being offered (more capacity, more spend) is
    exactly what a reader needs to weigh before accepting a "high risk" upsize.

    Returns "" when either price is unknown — pricing is a snapshot the bundled dataset
    may not carry for every type (`.metal` sizes, mainly), and a fabricated diff against
    a missing price is worse than no diff at all.
    """
    if current_price is None or candidate_price is None:
        return ""
    if candidate_price == current_price:
        return (
            '<div style="margin-top:4px;font-size:12px;color:var(--text-muted);">'
            "same $/hr as current</div>"
        )
    pct = abs(candidate_price - current_price) / current_price * 100.0
    annual_delta = abs(candidate_price - current_price) * _HOURS_PER_YEAR
    is_reduction = candidate_price < current_price
    color = "#047857" if is_reduction else "#b91c1c"
    sign = "-" if is_reduction else "+"
    label = "savings" if is_reduction else "increase"
    return (
        f'<div style="margin-top:4px;font-size:12px;color:{color};font-weight:600;">'
        f"{sign}{pct:.1f}%/hr &middot; {sign}${annual_delta:,.0f}/yr {label} vs. current"
        f"</div>"
    )


def _build_html(
    run_name,
    run_data,
    cpu_summary,
    pmu_summary,
    mem_summary,
    sys_health,
    dep_analysis,
    dep_file_status,
    recommendations,
    app_context,
    customer_name,
    fg_summary=None,
    playbook_matches=None,
    sizing=None,
    graviton_candidate=None,
    language_was_explicit=False,
    gap_finding_guidance=None,
    measured_anomalies=None,
    worker_imbalance=None,
    workload_profile=None,
    aperf_findings=None,
):
    """Build the complete HTML report.

    `fg_summary` is None whenever the run was recorded without `--profile`; every use of it
    below is guarded, because an unguarded `fg_summary.total_samples` in the template used to
    raise AttributeError for any run with no flamegraph.
    """
    meta = run_data.metadata

    # ARM Modernization tab is omitted entirely when already on Graviton — there is
    # nothing to modernize TO. `meta.architecture` is the same field the header itself
    # displays, so this can never disagree with what the report's own header shows.
    _already_graviton = meta.architecture == "aarch64"

    # Header "Language" value — shown ONLY when the user supplied it explicitly
    # (questionnaire answer or `app_context`). The process-name-based guess used to
    # fill this in too, with a confidence qualifier, but its needle table only covers
    # a handful of common runtimes and resolved to "unknown" for most real workload
    # process names — removed per user request rather than shown as unreliable filler.
    if language_was_explicit:
        _explicit_language = (
            app_context.get("language")
            or app_context.get("primary_language")
            or app_context.get("runtime")
        )
        _language_display = _esc(_explicit_language)
    else:
        _language_display = "unknown"

    # Customer name fallback. `meta.aperf_run_name` is aperf's OWN name for this capture
    # — read from `runs.js` when available, see `run_parser._parse_metadata` — which is
    # the name aperf's own report UI shows. `run_name` (this function's own parameter,
    # and `meta.run_name`) is instead the report DIRECTORY's name, which a caller looks
    # the run up by and which is frequently a different string (`vaultwarden_report`,
    # `aperf_report_2026-08-07_...`) than the capture's real name. Falling back to the
    # directory name here — as this used to — displayed a name aperf itself never used
    # whenever no `app_name`/`customer_name` override was supplied.
    customer_label = customer_name or app_context.get("app_name") or meta.aperf_run_name or run_name

    # No composite health SCORE. A single 0-100 number invited exactly the reading the
    # user flagged: it looks like a real, comparable measurement, but it is an arbitrary
    # point deduction (-15 here, -5 there) with no unit and no basis for comparing one
    # run's 72 against another's 68. The prose summary below carries the same underlying
    # facts (backend stalls, dependency blockers, anchored checks) without manufacturing
    # a number that implies more precision than the inputs support.
    health_summary = _build_health_summary(cpu_summary, mem_summary, dep_analysis, workload_profile)

    # System metrics grid
    metrics_html = _build_metrics_grid(cpu_summary, pmu_summary, mem_summary, meta, fg_summary)

    # Findings
    # The rule names aperf itself emitted. Both findings sources are gated on this: a raw
    # `aperf record` directory yields an empty set, and then nothing is reported rather than
    # advice derived purely from our own thresholds.
    _fired: set[str] = set()
    for _item in getattr(aperf_findings, "findings", aperf_findings) or ():
        _name = getattr(_item, "rule_name", _item)
        if isinstance(_name, str):
            _fired.add(_name)

    findings_html = _build_findings(
        pmu_summary, sys_health, has_playbook=bool(playbook_matches), aperf_fired=_fired
    )

    # Curated sysctl remediation, for the System tab. Same matched rules and same renderer
    # the Findings tab uses (`_build_playbook_section` -> `_render_os_block`), so the two
    # views cannot disagree about what a rule's os_remediation says. `_fired` drives the
    # gap-list reveal below it: only findings that ACTUALLY FIRED in this run, never a
    # hypothetical list of everything the corpus could ever mention.
    sysctl_html = _build_system_sysctl(playbook_matches, _fired, gap_finding_guidance)

    # Flamegraph hotspots and anomalies. Empty string when the run carries no profile, so the
    # section disappears rather than rendering an empty box.
    flamegraph_html = _build_flamegraph_section(fg_summary)

    # Recommendations / migration roadmap
    sizing_html = _build_sizing_section(sizing, meta, workload_profile, graviton_candidate)

    # Action plan
    action_html = _build_action_plan(
        recommendations,
        dep_analysis,
        sys_health,
        pmu_summary,
        playbook_matches,
        aperf_fired=_fired,
        graviton_candidate=graviton_candidate,
        sizing=sizing,
        measured_anomalies=measured_anomalies,
        worker_imbalance=worker_imbalance,
    )

    # Default tab. Composed from pieces the other tabs own, so a reader who opens the report
    # and reads nothing else still gets the verdict, what to do, and how healthy the box is.
    summary_html = _build_summary_tab(
        sizing=sizing,
        workload_profile=workload_profile,
        action_html=action_html,
        health_summary=health_summary,
        sys_health=sys_health,
        dep_analysis=dep_analysis,
        playbook_matches=playbook_matches,
        aperf_fired=_fired,
    )

    # Caveats banner at top. The Graviton-specific caveat (`recommendation_engine.py`'s
    # "Graviton recommendation is partial without a dependency file") relocates into the
    # ARM Modernization tab instead — it's about that tab's own subject, not a global
    # report-wide caveat every reader needs to see regardless of what they opened.
    _GRAVITON_CAVEAT_PREFIX = "**Graviton recommendation is partial"
    _global_caveats = [
        c for c in recommendations.caveats if not c.startswith(_GRAVITON_CAVEAT_PREFIX)
    ]
    _graviton_dep_caveat = next(
        (c for c in recommendations.caveats if c.startswith(_GRAVITON_CAVEAT_PREFIX)), None
    )
    caveat_banner = ""
    if _global_caveats:
        caveats = "".join(f"<li>{c}</li>" for c in _global_caveats)
        caveat_banner = f'<div class="warn-box"><strong>Important caveats for this report:</strong><ul style="margin-left:20px;margin-top:6px;">{caveats}</ul></div>'

    # Context-missing banner: surfaced at the very top of the report when the
    # required questionnaire fields weren't provided. Tells the reader the
    # report is in degraded fidelity and what to do about it. The dep_file-specific
    # wording relocates into the ARM Modernization tab (see `_dep_file_missing` below);
    # this banner still fires globally for ANY missing key, dep_file included, since a
    # reader who never opens the ARM tab still needs to know context is incomplete.
    context_banner = ""
    _ctx_status = app_context.get("_context_status", "complete")
    _missing: list[str] = []
    if _ctx_status in ("missing", "partial"):
        _missing = app_context.get("_context_missing_keys") or [
            k
            for k in ("app_name", "customer_priority", "capture_type", "dep_file")
            if not app_context.get(k)
        ]
        _label = "MISSING" if _ctx_status == "missing" else "PARTIAL"
        _items = ", ".join(f"<code>{k}</code>" for k in _missing)
        context_banner = (
            f'<div class="error-box" style="margin-bottom:12px;">'
            f"<strong>Application context {_label}.</strong> "
            f"This report ran without the questionnaire being completed. "
            f"Recommendations, Graviton analysis, and dependency-file resolution "
            f"are operating with limited information. Missing keys: {_items}. "
            f"Re-run with these provided in <code>app_context</code>, or set up "
            f"<code>hooks/aperf_context_hook.py</code> to capture them automatically."
            f"</div>"
        )
    _dep_file_missing = "dep_file" in _missing

    # ARM Modernization tab. Omitted entirely at the template level when already on
    # Graviton (see `_already_graviton` below) — computed regardless here since it's
    # cheap and the omission decision belongs in the template, not this function.
    arm_html = _build_arm_modernization_section(
        graviton_candidate,
        sizing,
        dep_analysis,
        dep_file_status,
        app_context,
        dep_file_missing=_dep_file_missing,
        graviton_dep_caveat=_graviton_dep_caveat,
    )

    # Pricing freshness banner
    from .. import __version__ as _mcp_version
    from . import pricing as _pricing

    # Freshness text used in the consolidated footer (banners removed from body)
    _p_status, _p_days = _pricing.pricing_freshness()
    _p_meta = _pricing.metadata()
    _p_pub = _p_meta.get("publication_date", "unknown")
    _p_count = _p_meta.get("instance_count", 0)
    _p_color = {"fresh": "var(--green)", "aging": "var(--orange)", "stale": "var(--red)"}.get(
        _p_status, "var(--text-muted)"
    )
    _pricing_footer_text = (
        (
            f'<span style="color:{_p_color};font-weight:600;">{_p_status}</span> '
            f"&middot; published {_p_pub} ({_p_days} days ago) &middot; {_p_count} instance types"
        )
        if _p_status != "missing"
        else '<span style="color:var(--red);">missing</span> &mdash; run scripts/refresh_pricing.py'
    )

    # Playbook section
    playbook_html = _build_playbook_section(playbook_matches or [], app_context)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>APerf Report — {customer_label}</title>
<style>{_CSS}{_TAB_CSS}</style>
</head>
<body>

<header class="page-header">
  <div class="label">APerf Performance Analysis</div>
  <h1>{customer_label}</h1>
  <div class="meta">
    <div class="meta-item"><span class="key">Instance</span><span class="val">{
        meta.instance_type or "unknown"
    }</span></div>
    <div class="meta-item"><span class="key">Architecture</span><span class="val">{
        meta.architecture or "x86_64"
    }</span></div>
    <div class="meta-item"><span class="key">vCPUs</span><span class="val">{
        meta.cpu_count or "?"
    }</span></div>
    <div class="meta-item"><span class="key">Kernel</span><span class="val">{
        meta.kernel_version or "unknown"
    }</span></div>
    <div class="meta-item"><span class="key">Capture</span><span class="val">{
        app_context.get("capture_type", "?")
    }</span></div>
    <div class="meta-item"><span class="key">Duration</span><span class="val">{
        int(meta.duration_seconds or 0)
    }s</span></div>
    <div class="meta-item"><span class="key">Recorded</span><span class="val">{
        meta.timestamp or "?"
    }</span></div>
    <div class="meta-item"><span class="key">Language</span><span class="val">{
        _language_display
    }</span></div>
    <div class="meta-item"><span class="key">Priority</span><span class="val">{
        app_context.get("customer_priority", "?")
    }</span></div>
    <div class="meta-item"><span class="key">MCP</span><span class="val">v{
        _mcp_version
    }</span></div>
  </div>
</header>

<div class="health-banner">
  <div class="health-summary">
    <p>{health_summary}</p>
  </div>
</div>

<main class="main">
{context_banner}
{caveat_banner}

<!-- CSS-only tabs. The radios come BEFORE the labels and panels so `:checked ~` can reach
     both. They are visually hidden rather than `hidden` so the native radio group keeps its
     keyboard behaviour (Tab into the group, arrows between tabs); `hidden` would remove them
     from the tab order and leave only labels, which are not keyboard-activatable. -->
<div class="tabs">
  <input type="radio" class="tab-radio" name="tab" id="tab-summary" checked aria-label="Summary">
  <input type="radio" class="tab-radio" name="tab" id="tab-sizing" aria-label="Right-sizing">
  <input type="radio" class="tab-radio" name="tab" id="tab-findings" aria-label="Findings">
  <input type="radio" class="tab-radio" name="tab" id="tab-system" aria-label="System">
  {
        ""
        if _already_graviton
        else '<input type="radio" class="tab-radio" name="tab" id="tab-arm" aria-label="ARM Modernization">'
    }

  <nav class="tab-bar" aria-hidden="true">
    <label class="tab-label" for="tab-summary">Summary</label>
    <label class="tab-label" for="tab-sizing">Right-sizing</label>
    <label class="tab-label" for="tab-findings">Findings</label>
    <label class="tab-label" for="tab-system">System</label>
    {
        ""
        if _already_graviton
        else '<label class="tab-label" for="tab-arm">ARM Modernization</label>'
    }
  </nav>

  <section class="tab-panel" id="panel-summary">
    <h2 class="print-only tab-print-title">Summary</h2>
    {summary_html}
  </section>

  <section class="tab-panel" id="panel-sizing">
    <h2 class="print-only tab-print-title">Right-sizing</h2>
    {sizing_html}
  </section>

  <section class="tab-panel" id="panel-findings">
    <h2 class="print-only tab-print-title">Findings</h2>
    <section class="section">
      <div class="section-title">Performance Findings</div>
      {findings_html}
    </section>
    {playbook_html}
    {flamegraph_html}
  </section>

  <section class="tab-panel" id="panel-system">
    <h2 class="print-only tab-print-title">System</h2>
    <section class="section">
      <div class="section-title">System Metrics</div>
      {metrics_html}
    </section>
    <section class="section">
      <div class="section-title">Sysctl / OS Remediation</div>
      {sysctl_html}
    </section>
  </section>

  {
        ""
        if _already_graviton
        else f'''<section class="tab-panel" id="panel-arm">
    <h2 class="print-only tab-print-title">ARM Modernization</h2>
    {arm_html}
  </section>'''
    }
</div>
</main>

<footer class="page-footer" style="text-align:left;padding:24px 32px;">
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;font-size:11px;">
    <div>
      <div style="font-weight:600;color:var(--text-secondary);text-transform:uppercase;letter-spacing:.06em;font-size:10px;margin-bottom:6px;">Run</div>
      <div>APerf run: <code>{run_name}</code></div>
      <div>App: <code>{app_context.get("app_name", "?")}</code></div>
      <div>Fingerprint: <code>{app_context.get("fingerprint_hash", "?")}</code></div>
      <div>Runs analyzed: {app_context.get("runs_analyzed", 1)}</div>
      <div>Generated by APerf Analyzer MCP <strong>v{_mcp_version}</strong></div>
    </div>
    <div>
      <div style="font-weight:600;color:var(--text-secondary);text-transform:uppercase;letter-spacing:.06em;font-size:10px;margin-bottom:6px;">Recording Tool</div>
      <div>Source: <a href="https://github.com/aws/aperf" target="_blank" rel="noopener" style="color:var(--accent);">aws/aperf</a></div>
      <div style="margin-top:4px;color:var(--text-muted);">Apache-2.0 licensed. This MCP analyzes recorded aperf data.</div>
      <div style="color:var(--text-muted);">For raw metric queries, also see aperf's built-in MCP: <code>aperf server --mcp</code></div>
    </div>
    <div>
      <div style="font-weight:600;color:var(--text-secondary);text-transform:uppercase;letter-spacing:.06em;font-size:10px;margin-bottom:6px;">EC2 Pricing</div>
      <div>{_pricing_footer_text}</div>
      <div style="margin-top:4px;color:var(--text-muted);">Source: AWS public pricing API (us-east-1, Linux/Shared/OnDemand)</div>
      <div style="color:var(--text-muted);">Refresh: <code>scripts/refresh_pricing.py</code></div>
    </div>
  </div>
  <div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border);font-size:10px;color:var(--text-muted);line-height:1.5;">
    <strong>Limitations:</strong> Right-sizing compares hardware capability, not your application. It cannot see local disk, accelerators or network fabric, and small differences in capability are not resolved. Every recommendation is a starting point that a real workload test must confirm before any production cutover. Pricing is a bundled snapshot &mdash; no AWS credentials required.
  </div>
</footer>

</body>
</html>"""


def _build_health_summary(cpu_summary, mem_summary, dep_analysis, workload_profile=None):
    """
    One-paragraph executive summary for the health banner.

    Classification comes from `workload_profile` — the same source the Summary tab renders.
    It used to come from `recommendations.workload_class`, a second classifier that decided
    "memory-bound" on a bare `backend_stall_pct > 40`, so the banner and the Summary tab
    routinely disagreed in the same report (observed: banner "memory-bound", tab "balanced").
    That threshold is also not vendor-comparable — aperf normalises the backend term
    differently across Intel and AMD — which is why the new classifier uses the
    backend/frontend ratio instead.
    """
    parts = []
    if cpu_summary:
        idle = 100 - cpu_summary.avg_total_utilization_pct
        parts.append(f"CPU is {idle:.0f}% idle on average")
    if mem_summary:
        parts.append(f"memory at {mem_summary.avg_used_pct:.0f}% utilization")
    if dep_analysis and dep_analysis.blockers:
        parts.append(f"{len(dep_analysis.blockers)} ARM64 blocker(s) found in dependencies")
    if dep_analysis and dep_analysis.degradeds:
        parts.append(
            f"{len(dep_analysis.degradeds)} dep(s) work on ARM64 with degraded performance"
        )

    cls = getattr(getattr(workload_profile, "classification", None), "value", "")
    if cls and cls != "balanced":
        conf = getattr(getattr(workload_profile, "confidence", None), "value", "")
        # Confidence is stated alongside the label: "memory-bound" from a run with no PMU
        # data is a very different claim from the same label backed by measurements.
        parts.append(f"workload classified as {cls}" + (f" ({conf} confidence)" if conf else ""))

    if not parts:
        return "Not enough collected data to summarise this run."
    return ". ".join(p.capitalize() if i == 0 else p for i, p in enumerate(parts)) + "."


def _build_metrics_grid(cpu_summary, pmu_summary, mem_summary, meta, fg_summary=None):
    """System metrics grid HTML.

    The flamegraph card renders `n/a` rather than being omitted when the run carries no profile:
    a missing card reads as "not measured" only to someone who knows the card exists.
    """
    cards = []

    # CPU idle
    if cpu_summary:
        idle = 100 - cpu_summary.avg_total_utilization_pct
        sub = (
            "Compute over-provisioned"
            if idle > 70
            else "Active utilization"
            if idle < 30
            else "Moderate utilization"
        )
        klass = "ok" if idle > 60 else "info" if idle > 30 else "warn"
        cards.append(
            f'<div class="metric-card {klass}"><div class="metric-label">CPU Idle</div><div class="metric-value">{idle:.1f}%</div><div class="metric-sub">{sub}</div></div>'
        )

        cards.append(
            f'<div class="metric-card info"><div class="metric-label">Active CPU</div><div class="metric-value">{cpu_summary.avg_total_utilization_pct:.1f}%</div><div class="metric-sub">User+system avg</div></div>'
        )

        if cpu_summary.cpu_imbalance_pct > 30:
            cards.append(
                f'<div class="metric-card warn"><div class="metric-label">CPU Imbalance</div><div class="metric-value">{cpu_summary.cpu_imbalance_pct:.0f}%</div><div class="metric-sub">Spread across cores</div></div>'
            )

    # PMU
    if pmu_summary:
        cards.append(
            f'<div class="metric-card info"><div class="metric-label">IPC</div><div class="metric-value">{pmu_summary.ipc:.2f}</div><div class="metric-sub">Instructions per cycle</div></div>'
        )

        be_class = (
            "crit"
            if pmu_summary.backend_stall_pct > 40
            else "warn"
            if pmu_summary.backend_stall_pct > 25
            else "ok"
        )
        cards.append(
            f'<div class="metric-card {be_class}"><div class="metric-label">Backend Stalls</div><div class="metric-value">{pmu_summary.backend_stall_pct:.1f}%</div><div class="metric-sub">Memory subsystem wait</div></div>'
        )

        fe_class = "warn" if pmu_summary.frontend_stall_pct > 20 else "ok"
        cards.append(
            f'<div class="metric-card {fe_class}"><div class="metric-label">Frontend Stalls</div><div class="metric-value">{pmu_summary.frontend_stall_pct:.1f}%</div><div class="metric-sub">Instruction fetch</div></div>'
        )

        dtlb_class = (
            "warn" if pmu_summary.dtlb_misses_per_1k_instructions >= FLOOR_DTLB_MPKI else "ok"
        )
        cards.append(
            f'<div class="metric-card {dtlb_class}"><div class="metric-label">DTLB Misses</div><div class="metric-value">{pmu_summary.dtlb_misses_per_1k_instructions:.1f}</div><div class="metric-sub">Per 1K instructions</div></div>'
        )

    # Memory
    if mem_summary:
        m_class = "warn" if mem_summary.avg_used_pct > 85 else "info"
        cards.append(
            f'<div class="metric-card {m_class}"><div class="metric-label">Memory Used</div><div class="metric-value">{mem_summary.avg_used_pct:.0f}%</div><div class="metric-sub">Avg utilization</div></div>'
        )

        sw_class = "ok" if mem_summary.swap_used_mb == 0 else "warn"
        cards.append(
            f'<div class="metric-card {sw_class}"><div class="metric-label">Swap Used</div><div class="metric-value">{mem_summary.swap_used_mb:.0f} MB</div><div class="metric-sub">Page-out activity</div></div>'
        )

    # Flamegraph samples. Abbreviated (K/M/B/T): aperf 1.3.0 weights samples by period, so
    # the raw count can run into the trillions and overflow the metric card's fixed-width
    # field — see `_fmt_samples`. The full literal value is kept in the `title` attribute.
    fg_value = _fmt_samples(fg_summary.total_samples) if fg_summary else "n/a"
    fg_title = f' title="{fg_summary.total_samples:,} samples"' if fg_summary else ""
    fg_sub = (
        f"{len(fg_summary.anomalies)} anomalies detected"
        if fg_summary
        else "Run recorded without --profile"
    )
    cards.append(
        f'<div class="metric-card info"><div class="metric-label">Flamegraph Samples</div><div class="metric-value"{fg_title}>{fg_value}</div><div class="metric-sub">{fg_sub}</div></div>'
    )

    return f'<div class="metrics-grid">{"".join(cards)}</div>'


def _sysctl_gap_list(fired: set[str], curated_anchors: set[str]) -> list[str]:
    """
    Fired findings with NO curated `os_remediation` whose upstream playbook mentions sysctl
    at all — i.e. the corpus has *something* relevant to hand an agent, even though it never
    rose to a curated, verified entry. Findings whose playbook says nothing sysctl-related
    are excluded: offering an AI-fallback path with no real context to assemble would be
    strictly worse than the note box already shown for "no curated remediation".

    Deliberately dynamic rather than a hardcoded list: the curated set changes as
    `anchored_playbooks.json` grows, and this must never show a stale gap for a finding that
    has since been curated, nor silently miss a newly-uncurated one.
    """
    from ..parsers.playbook_library import PlaybookNotFound, get_library

    gap = sorted(fired - curated_anchors)
    if not gap:
        return []

    library = get_library()
    result = []
    for rule_name in gap:
        try:
            document = library.for_rule(rule_name)
        except PlaybookNotFound:
            continue
        text = document.read().lower()
        if "sysctl" in text or "/proc/sys" in text:
            result.append(rule_name)
    return result


#: Cap on how many gap findings get a rendered playbook card per report — mirrors the
#: prior sampling cap's bound on card count, kept for the same reason: don't render
#: an unbounded number of cards. Not a silent cap: `_build_system_sysctl` names the
#: truncated remainder explicitly rather than dropping it without a trace.
GAP_SAMPLING_LIMIT = 5


async def gather_gap_finding_guidance(
    gap_findings: list[str], aperf_findings: Any, app_context: dict[str, Any] | None
) -> dict[str, dict[str, Any] | None]:
    """
    Deterministic playbook lookup for each gap finding, up to `GAP_SAMPLING_LIMIT`.

    Real MCP sampling (`sampling/createMessage`) needs the CONNECTED CLIENT to declare
    the `sampling` capability during the handshake — as of this codebase, no MCP client
    it has been tested against (Claude Code, Claude Desktop, Kiro) does, so every
    sampling attempt always degraded to `SAMPLING_NOT_ENABLED` in practice. Replaced with
    the same deterministic extraction `sysctl_ai_fallback.py`'s branch 2 already performs
    (`_playbook_recommendation`) — real, hand-authored guidance from
    `resources/findings/`, not an LLM call, so it needs no client capability and no API
    key. Returns `{rule_name: playbook_dict_or_None}`; `None` means the rule has no
    playbook either (same as `sysctl_ai_fallback.py`'s branch 3 gap).

    Kept as an `async def` — and computed OUTSIDE `_build_html`, which stays synchronous
    for its dozens of existing direct test call sites — purely to preserve the existing
    call shape in `generate_html_report_handler`; the work itself is synchronous.
    """
    from .sysctl_ai_fallback import _playbook_recommendation

    result: dict[str, dict[str, Any] | None] = {}
    for rule_name in gap_findings[:GAP_SAMPLING_LIMIT]:
        playbook = _playbook_recommendation(rule_name)
        result[rule_name] = playbook if playbook.get("playbook_available") else None
    return result


def _build_system_sysctl(
    playbook_matches: list[Any] | None,
    fired: set[str] | None = None,
    gap_finding_guidance: dict[str, dict[str, Any] | None] | None = None,
) -> str:
    """
    Curated OS/sysctl remediation, grouped for the System tab, plus real playbook
    guidance — looked up BEFORE this function runs (see `gather_gap_finding_guidance`)
    — for findings the curated database does not cover.

    A reader looking for "what should I tune at the OS level" opens the System tab, not the
    Findings tab — the only place curated content rendered before. Sourced from the SAME
    matched rules the Findings tab already uses, via the SAME `_render_os_block` renderer, so
    the two views can never disagree about what a rule's `os_remediation` says.

    No new curated content is added here. Of the 13 anchored playbook rules, only those whose
    `os_remediation` is non-empty have a real sysctl fix; the rest (branch mispredictions, code
    sparsity, exceptions, frontend stalls, atomics, concurrency, PREEMPT_LAZY) were checked
    against aperf's own upstream research corpus and correctly have none — their fixes are
    code/JVM/rebuild-level or a boot parameter, not sysctl.

    Gap findings render the finding's own hand-authored playbook guidance directly —
    the same deterministic extraction `sysctl_ai_fallback.py`'s branch 2 performs
    (`_playbook_recommendation`), not an LLM call. This used to attempt real MCP
    sampling first, but no MCP client this codebase has been tested against (Claude
    Code, Claude Desktop, Kiro) declares the `sampling` capability, so that path always
    degraded to `SAMPLING_NOT_ENABLED` in practice — replaced with real playbook text,
    which needs no client capability and no API key.
    """
    matches = playbook_matches or []
    with_sysctl = [m for m in matches if getattr(m, "os_remediation", None)]

    curated_anchors: set[str] = set()
    for m in matches:
        if getattr(m, "os_remediation", None):
            curated_anchors.update(getattr(m, "anchored_by", None) or ())
    gap_findings = _sysctl_gap_list(fired or set(), curated_anchors)

    guidance = gap_finding_guidance or {}
    gap_html = ""
    if gap_findings:
        shown_gaps = gap_findings[:GAP_SAMPLING_LIMIT]
        truncated_count = len(gap_findings) - len(shown_gaps)
        cards = []
        for rule_name in shown_gaps:
            playbook = guidance.get(rule_name)
            if playbook:
                body_parts = [
                    '<div class="warn-box"><strong>Playbook-derived guidance (not the '
                    "curated os_remediation schema — this finding has not been promoted "
                    "there yet):</strong>"
                ]
                if playbook.get("guidance"):
                    body_parts.append(
                        f"<div style='margin-top:8px;'>{_render_md(playbook['guidance'])}</div>"
                    )
                if playbook.get("decision_tree"):
                    body_parts.append(
                        "<div style='margin-top:8px;'><strong>Decision tree:</strong>"
                        f"{_render_md(playbook['decision_tree'])}</div>"
                    )
                body_parts.append("</div>")
                body = "".join(body_parts)
            else:
                body = (
                    '<div class="warn-box">No playbook exists for this rule name either — '
                    "call <code>sysctl_ai_fallback</code> manually for AI-assisted, "
                    "unverified guidance.</div>"
                )
            cards.append(f"""<div style="margin-bottom:10px;">
    <div style="font-size:12px;font-weight:600;margin-bottom:6px;">
      {_esc(rule_name)} fired &mdash; no curated os_remediation entry yet.
    </div>
    {body}
  </div>""")
        truncation_note = (
            f'<div class="note-box" style="margin-top:8px;">{truncated_count} more '
            "finding(s) have no curated guidance and were not looked up in this pass; "
            "call <code>sysctl_ai_fallback</code> manually for those.</div>"
            if truncated_count > 0
            else ""
        )
        gap_html = f"""<div style="margin-top:20px;">
  <div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--text-muted);margin-bottom:10px;">
    Fired findings with no curated sysctl entry
  </div>
  {"".join(cards)}
  {truncation_note}
</div>"""

    if not with_sysctl:
        empty = (
            '<div class="note-box">No curated sysctl remediation is anchored to this run\'s '
            "findings. A sysctl fix is only shown when a real aperf finding measured the "
            "symptom it addresses — see the Findings tab for what fired.</div>"
        )
        return empty + gap_html

    cards = []
    for m in with_sysctl:
        anchor_block = (
            f'<div style="margin-top:10px;font-size:11px;color:var(--text-muted);">'
            f"Anchored on aperf finding(s): <code>{_esc(', '.join(m.anchored_by))}</code></div>"
            if getattr(m, "anchored_by", None)
            else ""
        )
        cards.append(f"""<div class="finding medium" style="margin-bottom:12px;">
  <div class="finding-header">
    <div>
      <div class="finding-title">{_esc(m.title)}</div>
      <div class="finding-meta">{_esc(m.category.replace("_", " ").title())}</div>
    </div>
  </div>
  <div class="finding-body">
    <p style="margin:0 0 8px;font-size:13px;">{_esc(m.why)}</p>
    {_render_os_block(m.os_remediation)}
    {anchor_block}
  </div>
</div>""")

    return "".join(cards) + gap_html


def _anchor_fired(check: dict[str, Any], fired: set[str]) -> bool:
    """
    Whether a system_health check names a finding aperf actually emitted.

    Reads `anchor_rules`, the machine-readable list. The human-readable `anchor` field is
    deliberately NOT parsed: it is prose written for the reader — "High L3 / L2 / L1 Data
    Cache Misses, Backend-Dominated CPU Stalls" collapses three rule names into one
    slash-separated phrase that matches none of them as a substring. A check with no
    `anchor_rules` cannot be anchored, which is the safe default.
    """
    rules = check.get("anchor_rules") or ()
    return bool(set(rules) & fired)


def _build_findings(pmu_summary, sys_health, has_playbook=False, aperf_fired=None):
    """
    Build findings cards from PMU bottlenecks and system health checks.

    BOTH SOURCES ARE GATED ON APERF. `aperf_fired` is the set of rule names aperf itself
    emitted for this run; when it is empty, neither source renders.

    This was the last hole in the anchoring work. Both paths reached the report ungated:

      - `detect_bottlenecks` fires on its own PMU thresholds. On a raw `aperf record`
        directory — which carries NO findings at all — it still rendered "High data TLB
        misses" and "CPU backend stalled", verified on a real 128-vCPU capture where
        `parse_findings` raised because there was no report JS to read.
      - a system_health check's `anchor` field is a DESCRIPTIVE STRING naming the finding
        that *would* justify the check. Nothing ever confirmed that finding fired, so
        `bool(c.get("anchor"))` was true whenever the string was non-empty — which is
        always. Four checks rendered "Anchored on aperf finding(s): ..." on a run with zero
        findings.

    `has_playbook=True` still suppresses the prescriptive text here, because the playbook
    section is the authoritative source for fixes and would otherwise double-render.
    """
    cards = []
    fired = aperf_fired or set()

    # No measurement, no findings. Returning early rather than filtering per-item keeps the
    # rule obvious: this section describes what aperf found, and nothing else.
    if not fired:
        return (
            '<div class="note-box">No findings: this capture carries no aperf findings to '
            "anchor on. Findings are only written by <code>aperf report</code> — a raw "
            "<code>aperf record</code> directory has none. Re-run through "
            "<code>aperf report</code> to populate this section.</div>"
        )

    if pmu_summary:
        from ..parsers.pmu_parser import PmuParser

        bottlenecks = PmuParser().detect_bottlenecks(pmu_summary)
        for b in bottlenecks:
            if not (set(b.get("anchor_rules") or ()) & fired):
                continue
            sev = b.get("severity", "info")
            if has_playbook:
                recs_html = (
                    '<div style="margin-top:8px;font-size:12px;color:var(--text-muted);">'
                    "See the tuning sections below for prescriptive fixes.</div>"
                )
            else:
                recs = "".join(f"<li>{r}</li>" for r in b.get("recommendations", []))
                recs_html = (
                    f'<ul style="margin-top:8px;margin-left:20px;">{recs}</ul>' if recs else ""
                )
            cards.append(f"""<div class="finding {sev}">
  <div class="finding-header">
    <span class="badge {sev}" style="margin-top:2px;">{sev.upper()}</span>
    <div>
      <div class="finding-title">{b.get("description", "")}</div>
      <div class="finding-meta">{b.get("metric", "")}</div>
    </div>
  </div>
  <div class="finding-body">{b.get("description", "")}{recs_html}</div>
</div>""")

    # System health checks.
    #
    # Anchoring moved every check off `warning`: a raw setting value is not a problem
    # unless something aperf measured says it is. Filtering on warning/critical therefore
    # discarded all 14 checks, including the pswpin discriminator that decides whether
    # lowering swappiness helps or actively hurts. A check is now shown when it carries an
    # aperf anchor (measured), and skipped only when it is genuinely uninformative.
    for c in sys_health.get("checks", []):
        status = c.get("status", "info")
        if status in ("pass", "not_applicable"):
            continue
        # `anchor` is a DESCRIPTIVE string naming the finding that would justify this check —
        # it is not evidence that the finding fired. Testing `bool(...)` therefore marked
        # every check with a non-empty string as "anchored", which is all of them. The
        # names in it must intersect what aperf actually emitted.
        anchored = _anchor_fired(c, fired)
        # A check aperf did not implicate is a raw config reading, not a finding.
        if not anchored:
            continue

        sev = status if status in ("warning", "critical") else "medium"
        detail_rows = "".join(
            f'<div style="margin-top:6px;font-size:11px;color:#78350f;">'
            f"<strong>{label}:</strong> {_esc(c[key])}</div>"
            for label, key in (
                ("Check first", "check_first"),
                ("Risk", "risk"),
                ("Verify", "verify"),
                ("Why unknown", "why_unknown"),
                ("Anchored advice", "anchored_advice"),
            )
            if c.get(key)
        )
        fix = c.get("fix") or c.get("candidate_fix") or ""
        fix_label = "Fix" if c.get("fix") else "Candidate fix (verify the checks above first)"
        fix_html = (
            f'<div class="fix-block"><div class="fix-label">{fix_label}</div>'
            f"<pre>{_esc(fix)}</pre></div>"
            if fix
            else ""
        )
        target = c.get("recommended") or c.get("correct_target") or "see detail"
        anchor_html = (
            f'<div style="margin-top:8px;font-size:11px;color:var(--text-muted);">'
            f"Anchored on aperf finding(s): <code>{_esc(c['anchor'])}</code></div>"
            if anchored
            else ""
        )
        cards.append(f"""<div class="finding {sev}">
  <div class="finding-header">
    <span class="badge {sev}" style="margin-top:2px;">{sev.upper()}</span>
    <div>
      <div class="finding-title">{c.get("check", "").replace("_", " ").title()}</div>
      <div class="finding-meta">Current: {_esc(c.get("current", "?"))} → Target: {_esc(target)}</div>
    </div>
  </div>
  <div class="finding-body">{_esc(c.get("impact", ""))}{detail_rows}</div>
  {fix_html}
  {anchor_html}
</div>""")

    if not cards:
        return '<div class="note-box">No critical or warning findings detected from automated analysis.</div>'

    return "".join(cards)


def _build_flamegraph_section(fg_summary):
    """CPU hotspot bars and anomaly cards from the flamegraph, or "" when there is no profile.

    The percentages are *inclusive* frame widths, not self time — a frame's width includes its
    children — and the section says so, because a reader comparing them against a self-time
    profiler would otherwise find them inflated and not know why.
    """
    if not fg_summary or not fg_summary.total_samples:
        return ""

    cats = [
        ("DSL evaluation (filters_dsl)", fg_summary.filters_dsl_pct, "#dc2626"),
        ("pymongo driver", fg_summary.pymongo_pct, "#d97706"),
        ("botocore (AWS SDK)", fg_summary.aws_sdk_pct, "#d97706"),
        ("lmongo / BSON", fg_summary.bson_pct, "#f59e0b"),
        ("elasticapm overhead", fg_summary.apm_overhead_pct, "#f59e0b"),
        ("SSL/TLS context", fg_summary.ssl_tls_pct, "#2563eb"),
        ("JSON serialization", fg_summary.json_pct, "#2563eb"),
        ("network syscalls", fg_summary.network_syscall_pct, "#94a3b8"),
    ]

    bars = ""
    for label, pct, color in cats:
        if pct > 0.1:
            bar_w = min(pct * 4, 100)
            bars += f"""
      <div style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px">
          <span style="font-weight:500">{label}</span>
          <span style="font-variant-numeric:tabular-nums;font-weight:700">{pct}%</span>
        </div>
        <div style="height:8px;background:var(--border);border-radius:4px;overflow:hidden">
          <div style="height:100%;width:{bar_w}%;background:{color};border-radius:4px"></div>
        </div>
      </div>"""

    anomaly_cards = ""
    for anomaly in fg_summary.anomalies:
        sev = "critical" if anomaly["severity"] == "critical" else "warning"
        anomaly_cards += f"""<div class="finding {sev}">
  <div class="finding-header">
    <span class="badge {sev}" style="margin-top:2px;">{anomaly["severity"].upper()}</span>
    <div>
      <div class="finding-title">{anomaly["message"]} ({anomaly["pct"]}%)</div>
      <div class="finding-meta">Inclusive frame width, not self time</div>
    </div>
  </div>
  <div class="finding-body">{anomaly.get("fix", "")}</div>
</div>"""

    anomaly_html = (
        f"""
<section class="section">
  <div class="section-title">Flamegraph Anomalies</div>
  {anomaly_cards}
</section>"""
        if anomaly_cards
        else ""
    )

    return f"""
<section class="section">
  <div class="section-title">CPU Hotspots (Flamegraph)</div>
  <div class="note-box" style="margin-bottom:16px">
    {_fmt_samples(fg_summary.total_samples)} samples ({fg_summary.total_samples:,} exact).
    Percentages are inclusive frame widths — a frame's share includes its children — so
    they do not sum to 100% and are not self time.
  </div>
  {bars}
</section>{anomaly_html}"""


def _build_arm_modernization_section(
    graviton_candidate,
    sizing,
    dep_analysis,
    dep_file_status,
    app_context,
    dep_file_missing: bool,
    graviton_dep_caveat: str | None,
) -> str:
    """
    ARM Modernization tab: the Graviton right-sizing comparison FIRST, this tab's own
    local caveats about incomplete context second, and only then the dependency
    analysis — the customer's own explicit ordering ("only then you will show the
    dependencies"). Never rendered at all when the current instance is already Graviton
    (see `_already_graviton` in `_build_html`, which omits this tab's radio/label/panel
    at the template level entirely).
    """
    from . import pricing as _pricing_arm

    current_price = _pricing_arm.lookup(getattr(sizing, "current_instance", None) or "")

    if graviton_candidate is not None:
        candidate_html = f"""<section class="section">
  <div class="section-title">Graviton Candidate</div>
  {_render_candidate_card(graviton_candidate, current_price)}
</section>"""
    else:
        # Mirrors `sizing.no_recommendation_reason` when the base engine also found
        # nothing — the same underlying demand/eligibility math, so the same explanation
        # applies (already optimal, insufficient data, or no Graviton candidate clears
        # the workload's measured requirements).
        reason = getattr(sizing, "no_recommendation_reason", "") or (
            "No Graviton candidate meets this workload's measured requirements, so no "
            "modernization option is offered."
        )
        candidate_html = f"""<section class="section">
  <div class="section-title">Graviton Candidate</div>
  <div class="note-box">{_esc(reason)}</div>
</section>"""

    local_caveats = ""
    if dep_file_missing:
        local_caveats += (
            '<div class="warn-box" style="margin-bottom:12px;">'
            "<strong>Dependency file not provided.</strong> "
            "Re-run with <code>app_context.dep_file</code> set, or set up "
            "<code>hooks/aperf_context_hook.py</code> to capture it automatically."
            "</div>"
        )
    if graviton_dep_caveat:
        local_caveats += (
            f'<div class="warn-box" style="margin-bottom:12px;">{graviton_dep_caveat}</div>'
        )

    deps_html = _build_dep_section(dep_analysis, dep_file_status, app_context)

    return f"{candidate_html}\n{local_caveats}\n{deps_html}"


def _build_dep_section(dep_analysis, dep_file_status, app_context):
    """Dependency analysis HTML."""
    if not dep_analysis:
        # Explain what's missing and how to provide it
        from ..parsers.dep_analyzer import language_dep_instructions

        runtime = app_context.get("runtime_version", "").lower()
        lang = (
            "java"
            if "java" in runtime
            else "python"
            if "python" in runtime
            else "node"
            if "node" in runtime
            else "unknown"
        )
        instructions = language_dep_instructions(lang)
        return f"""<section class="section">
  <div class="section-title">Dependency Analysis</div>
  <div class="warn-box">
    <strong>Dependency analysis skipped — limited Graviton recommendation precision.</strong>
    <p style="margin-top:8px;">No dependency manifest was provided (status: <code>{dep_file_status}</code>).
    Without it, ARM64 native library compatibility cannot be verified, and Graviton migration recommendations
    are partial.</p>
    <p style="margin-top:8px;"><strong>To get a complete Graviton readiness analysis, provide your dep file:</strong></p>
    <p style="margin-top:6px;font-family:var(--font-mono);font-size:12px;">{instructions}</p>
    <p style="margin-top:8px;">Re-run with <code>app_context.dep_file = "/path/to/your/file"</code> or set <code>"auto"</code> to auto-detect alongside the run.</p>
  </div>
</section>"""

    rows = []
    # Severity order: BLOCKER -> DEGRADED -> VERIFY -> CLEAR
    for b in dep_analysis.blockers:
        verif = (
            f'<br><code style="font-size:10px;color:#666">{b.verification}</code>'
            if b.verification
            else ""
        )
        rows.append(
            f'<tr><td class="name">{b.name}</td><td>{b.version or "?"}</td><td><span class="badge blocker">BLOCKER</span></td><td>{b.reason}</td><td>{b.action}{verif}</td></tr>'
        )
    for d in dep_analysis.degradeds:
        verif = (
            f'<br><code style="font-size:10px;color:#666">{d.verification}</code>'
            if d.verification
            else ""
        )
        rows.append(
            f'<tr><td class="name">{d.name}</td><td>{d.version or "?"}</td><td><span class="badge degraded">DEGRADED</span></td><td>{d.reason}</td><td>{d.action}{verif}</td></tr>'
        )
    for v in dep_analysis.verifies:
        verif = (
            f'<br><code style="font-size:10px;color:#666">{v.verification}</code>'
            if v.verification
            else ""
        )
        rows.append(
            f'<tr><td class="name">{v.name}</td><td>{v.version or "?"}</td><td><span class="badge verify">VERIFY</span></td><td>{v.reason}</td><td>{v.action}{verif}</td></tr>'
        )

    # Show first 30 clear deps to keep table readable
    clears_shown = dep_analysis.clears[:30]
    for c in clears_shown:
        rows.append(
            f'<tr><td class="name">{c.name}</td><td>{c.version or "?"}</td><td><span class="badge clear">CLEAR</span></td><td>{c.reason[:80]}</td><td>{c.action}</td></tr>'
        )

    extra_note = ""
    if len(dep_analysis.clears) > 30:
        extra_note = f'<p style="font-size:11px;color:var(--text-muted);margin-top:8px;">Showing 30 of {len(dep_analysis.clears)} clear dependencies. Full list available in the dependency file.</p>'

    return f"""<section class="section">
  <div class="section-title">Dependency Analysis ({dep_analysis.language}, {dep_analysis.total_count} deps)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Dependency</th><th>Version</th><th>Status</th><th>Notes</th><th>Action</th></tr></thead>
      <tbody>{"".join(rows)}</tbody>
    </table>
  </div>
  {extra_note}
  <div class="note-box" style="margin-top:12px;">
    <strong>Summary:</strong> {len(dep_analysis.blockers)} BLOCKER, {len(dep_analysis.degradeds)} DEGRADED, {len(dep_analysis.verifies)} VERIFY, {len(dep_analysis.clears)} CLEAR. Source: <code>{dep_analysis.dep_file_path}</code>
  </div>
</section>"""


def _build_summary_tab(
    sizing: Any,
    workload_profile: Any,
    action_html: str,
    health_summary: str,
    sys_health: dict[str, Any] | None,
    dep_analysis: Any,
    playbook_matches: list[Any] | None,
    aperf_fired: set[str] | None = None,
) -> str:
    """
    The default tab: the sizing verdict, what to do, and how healthy the box is.

    This is the only tab many readers will open, so it has to be self-sufficient — but it
    restates rather than re-derives. The verdict comes from the sizing engine and the actions
    from the action plan, so this view can never disagree with the tab it summarises.

    Same rule as `_build_sizing_section`: no c-ray or STREAM figure, and no percentage
    derived from one, in customer-facing text.
    """
    verdict_value = getattr(getattr(sizing, "verdict", None), "value", "")
    headline = getattr(sizing, "headline", "") or ""
    tone = _VERDICT_TONE.get(verdict_value, _VERDICT_DEFAULT_TONE)

    candidates = getattr(sizing, "candidates", []) or []

    # Current instance's own on-demand rate, so each candidate row can show a real $/hr
    # and $/yr delta rather than an absolute price with nothing to compare it against.
    from . import pricing as _pricing_summary

    current_price = _pricing_summary.lookup(getattr(sizing, "current_instance", None) or "")

    # A "keep it" verdict can still carry an aggressive option: the engine emits one when the
    # sole surviving candidate is high risk, so that KEEP stays the recommendation instead of
    # a multi-step jump being dressed up as low risk. The lead has to say so — saying "no
    # change is recommended" above a table that lists an instance reads as a contradiction.
    keep_has_tradeoff = verdict_value in ("already_optimal", "no_better_option") and bool(
        candidates
    )

    # What the verdict means for the reader's next move. Spelled out because
    # "no_better_option" and "already_optimal" both mean "keep what you have" but for
    # different reasons, and a bare enum leaves the reader to guess which.
    if keep_has_tradeoff:
        lead = (
            "Keep your current instance type. It is the low-risk choice — the alternative "
            "below meets the measured requirements but carries higher risk, so it is a "
            "trade-off to weigh, not a recommendation."
        )
    else:
        lead = {
            "change_recommended": "A different instance type is worth evaluating.",
            "already_optimal": "Your current instance type is the right fit. No change is recommended.",
            "no_better_option": (
                "Your current instance type is the best available fit. Nothing in the "
                "evaluated pool improves on it without adding risk, so keep it."
            ),
            "insufficient_data": (
                "There is not enough measured data to make a sizing call. The gaps are "
                "listed on the Right-sizing tab."
            ),
        }.get(verdict_value, "")

    picks = ""
    if candidates:
        rows = "".join(
            f"<tr><td class='name'>{_esc(c.instance_type)}</td>"
            f"<td>{_esc(c.strategy)}</td>"
            f'<td><strong style="color:{"#b91c1c" if c.risk == "high" else "#047857"};">'
            f"{_esc(c.risk)}</strong></td>"
            f"<td>{c.vcpu} vCPU &middot; {c.memory_gb:.0f} GB &middot; {_esc(c.architecture)}</td>"
            f"<td>{f'${c.price_per_hour:.4f}/hr' if c.price_per_hour is not None else '&mdash;'}"
            f"{_cost_diff_html(current_price, c.price_per_hour)}</td>"
            f"</tr>"
            for c in candidates
        )
        header = "Trade-off to weigh" if keep_has_tradeoff else "Candidate"
        picks = f"""
  <div class="table-wrap" style="margin-top:12px;">
    <table>
      <thead><tr><th>{header}</th><th>Strategy</th><th>Risk</th><th>Shape</th><th>On-demand</th></tr></thead>
      <tbody>{rows}</tbody>
    </table>
  </div>
  <div style="margin-top:8px;font-size:11px;color:var(--text-secondary);">
    Full reasoning, caveats and what was not measured: <strong>Right-sizing</strong> tab.
  </div>"""

    verdict_block = f"""<section class="section">
  <div class="section-title">Verdict</div>
  <div style="border-left:4px solid {tone[0]};background:{tone[1]};padding:16px 20px;border-radius:6px;">
    <div style="font-size:11px;font-weight:700;letter-spacing:.06em;color:{tone[0]};text-transform:uppercase;">
      {_esc(verdict_value.replace("_", " ")) or "no verdict"}
    </div>
    <div style="font-size:15px;margin-top:8px;font-weight:600;">{_esc(lead)}</div>
    {f'<div style="font-size:13px;margin-top:6px;color:var(--text-secondary);">{_esc(headline)}</div>' if headline else ""}
  </div>
  {picks}
</section>"""

    # Workload shape, as pressure per dimension. `unknown` is rendered as "not measured"
    # rather than omitted: a missing card reads as "fine" to anyone who does not know the
    # card exists.
    profile_block = ""
    if workload_profile is not None:
        cells = ""
        for label, pressure in (
            ("CPU", getattr(getattr(workload_profile, "cpu_pressure", None), "value", "unknown")),
            (
                "Memory bandwidth",
                getattr(
                    getattr(workload_profile, "memory_bandwidth_pressure", None), "value", "unknown"
                ),
            ),
            (
                "Memory capacity",
                getattr(
                    getattr(workload_profile, "memory_capacity_pressure", None), "value", "unknown"
                ),
            ),
        ):
            klass = _PRESSURE_CLASS.get(pressure, "")
            shown = "not measured" if pressure == "unknown" else pressure
            cells += (
                f'<div class="metric-card {klass}"><div class="metric-label">{_esc(label)} pressure</div>'
                f'<div class="metric-value" style="font-size:16px;">{_esc(shown)}</div></div>'
            )
        cls = getattr(getattr(workload_profile, "classification", None), "value", "")
        conf = getattr(getattr(workload_profile, "confidence", None), "value", "")
        profile_block = f"""<section class="section">
  <div class="section-title">Workload shape</div>
  <div style="font-size:13px;margin-bottom:12px;">
    Classified as <strong>{_esc(cls)}</strong> at <strong>{_esc(conf)}</strong> confidence.
  </div>
  <div class="metrics-grid">{cells}</div>
</section>"""

    # Health: the same prose summary the banner shows, with counts alongside it so each
    # count is auditable rather than asserted.
    #
    # `anchor` is a DESCRIPTIVE STRING naming the finding that *would* justify a check —
    # it is non-empty on every anchored check regardless of whether that finding ever
    # fired in this run. Counting on `bool(c.get("anchor"))` alone reproduces the exact
    # bug `_build_findings` was already fixed for (see its docstring): a raw `aperf
    # record` capture with zero real findings still counted 4 "implicated" checks here
    # while the Findings tab correctly said "no findings" — the two disagreed on a run
    # this MCP server itself generated. Gating on `aperf_fired`, the same set the
    # Findings tab and action plan already use, keeps this count in agreement with them.
    _fired_set = aperf_fired or set()
    anchored = sum(
        1
        for c in (sys_health.get("checks", []) if sys_health else [])
        if c.get("anchor")
        and c.get("status") not in ("pass", "not_applicable")
        and set(c.get("anchor_rules") or ()) & _fired_set
    )
    counts = [
        (len(playbook_matches or []), "tuning action(s) with a measured trigger", "Findings"),
        (anchored, "system check(s) an aperf finding implicates", "Findings"),
        (
            len(dep_analysis.blockers) if dep_analysis else 0,
            "ARM64 dependency blocker(s)",
            "Dependencies",
        ),
        (
            len(dep_analysis.degradeds) if dep_analysis else 0,
            "dependency(ies) degraded on ARM64",
            "Dependencies",
        ),
    ]
    count_rows = "".join(
        f"<li style='margin-bottom:4px;'><strong>{n}</strong> {_esc(text)} "
        f"<span style='color:var(--text-muted);'>&mdash; {_esc(tab)} tab</span></li>"
        for n, text, tab in counts
        if n
    )
    health_block = f"""<section class="section">
  <div class="section-title">Health</div>
  <div style="font-size:13px;color:var(--text-secondary);max-width:900px;">{health_summary}</div>
  {f"<ul style='margin:14px 0 0 18px;font-size:12px;'>{count_rows}</ul>" if count_rows else "<div style='margin-top:12px;font-size:12px;color:var(--text-secondary);'>Nothing aperf measured points to a tuning change.</div>"}
</section>"""

    return f"{verdict_block}\n{profile_block}\n{action_html}\n{health_block}"


def _render_candidate_card(cand, current_price: float | None) -> str:
    """
    One `RightSizingCandidate` as a finding-style card. Shared by the Right-sizing tab
    (conservative/aggressive/modernization cards) and the ARM Modernization tab (the
    Graviton comparison card), so the two tabs render identical cards from ONE source —
    they cannot drift into showing different wording/formatting for the same candidate.
    """
    risk_tone = "#b91c1c" if cand.risk == "high" else "#047857"
    why = "".join(f"<li style='margin-bottom:4px;'>{_esc(w)}</li>" for w in cand.customer_summary)
    caveats = "".join(f"<li style='margin-bottom:3px;'>{_esc(c)}</li>" for c in cand.caveats)
    price = (
        f"${cand.price_per_hour:.4f}/hr"
        if cand.price_per_hour is not None
        else "price not in the bundled snapshot"
    )
    return f"""
  <div class="finding" style="margin-bottom:12px;border-left:4px solid {risk_tone};">
    <div class="finding-header">
      <div>
        <div class="finding-title">{_esc(cand.instance_type)}</div>
        <div class="finding-meta">
          {_esc(cand.strategy)} &mdash; <strong style="color:{risk_tone};">{_esc(cand.risk)} risk</strong>
          &middot; sizing {_esc(cand.direction)}
        </div>
      </div>
    </div>
    <div class="finding-body">
      <div style="font-size:12px;margin-bottom:8px;">
        <strong>{cand.vcpu} vCPU</strong> &middot; <strong>{cand.memory_gb:.0f} GB</strong>
        &middot; {_esc(cand.architecture)} &middot; {_esc(price)}
      </div>
      {_cost_diff_html(current_price, cand.price_per_hour)}
      {f"<ul style='margin:4px 0 0 18px;font-size:12px;'>{why}</ul>" if why else ""}
      {f"<div style='margin-top:8px;font-size:11px;color:#92400e;'><strong>Before you act:</strong><ul style='margin:4px 0 0 18px;'>{caveats}</ul></div>" if caveats else ""}
    </div>
  </div>"""


def _build_sizing_section(sizing, meta, workload_profile, graviton_candidate=None) -> str:
    """
    Right-sizing, expressed as a verdict plus prose candidates.

    NO BENCHMARK VALUE APPEARS HERE. Not the c-ray or STREAM figures, and not a headroom
    percentage either — a percentage is a ratio of the score and inverts to it as soon as a
    reader knows one absolute value. Capability is stated in words; the numbers a customer
    may see are the ones they can already look up: vCPU, memory, architecture, price.
    """
    verdict = getattr(sizing, "verdict", None)
    verdict_value = getattr(verdict, "value", str(verdict or ""))
    headline = getattr(sizing, "headline", "") or ""

    tone = _VERDICT_TONE.get(verdict_value, _VERDICT_DEFAULT_TONE)

    # Current instance's own on-demand rate, so every candidate card can show a real
    # $/hr and $/yr delta next to its own price rather than an absolute figure with
    # nothing to compare it against.
    from . import pricing as _pricing_sizing

    current_price = _pricing_sizing.lookup(getattr(sizing, "current_instance", None) or "")

    banner = f"""
  <div style="border-left:4px solid {tone[0]};background:{tone[1]};padding:14px 18px;border-radius:6px;margin-bottom:16px;">
    <div style="font-size:11px;font-weight:700;letter-spacing:.06em;color:{tone[0]};text-transform:uppercase;">
      {_esc(verdict_value.replace("_", " "))}
    </div>
    <div style="font-size:14px;margin-top:6px;">{_esc(headline)}</div>
  </div>"""

    # Why we concluded that: the measured classification, plus what was NOT measured.
    profile_block = ""
    if workload_profile is not None:
        ev = "".join(
            f"<li style='margin-bottom:3px;'>{_esc(e)}</li>"
            for e in getattr(workload_profile, "evidence", [])
        )
        gaps = "".join(
            f"<li style='margin-bottom:3px;'>{_esc(g)}</li>"
            for g in getattr(workload_profile, "gaps", [])
        )
        cls = getattr(getattr(workload_profile, "classification", None), "value", "")
        conf = getattr(getattr(workload_profile, "confidence", None), "value", "")
        profile_block = f"""
  <div style="margin-bottom:16px;font-size:12px;">
    <div><strong>Workload:</strong> {_esc(cls)} &mdash; confidence {_esc(conf)}</div>
    {f"<div style='margin-top:6px;'><strong>Measured:</strong><ul style='margin:4px 0 0 18px;'>{ev}</ul></div>" if ev else ""}
    {f"<div style='margin-top:6px;color:#92400e;'><strong>Not measured</strong> (limits how far this can be trusted):<ul style='margin:4px 0 0 18px;'>{gaps}</ul></div>" if gaps else ""}
  </div>"""

    # When the verdict is KEEP but a candidate survives, that candidate is a high-risk
    # trade-off the engine surfaced on purpose. Without this heading the card reads as the
    # recommendation, directly contradicting the banner above it.
    candidate_list = getattr(sizing, "candidates", []) or []
    keep_has_tradeoff = verdict_value in ("already_optimal", "no_better_option") and bool(
        candidate_list
    )
    cards_heading = ""
    if keep_has_tradeoff:
        cards_heading = (
            "<div style='font-size:12px;font-weight:600;margin-bottom:8px;'>"
            "Trade-off, not a recommendation</div>"
            "<div style='font-size:12px;color:var(--text-secondary);margin-bottom:10px;'>"
            "The option below meets the measured requirements but is rated high risk. "
            "Keeping your current instance type remains the recommendation.</div>"
        )

    cards = ""
    for cand in candidate_list:
        cards += _render_candidate_card(cand, current_price)

    # The Graviton modernization card: a distinct comparison option alongside
    # conservative/aggressive, skipped when it would just repeat an existing card (same
    # instance type already surfaced by the normal ranking) rather than showing the same
    # box twice under two different labels.
    if graviton_candidate is not None and not any(
        c.instance_type == graviton_candidate.instance_type for c in candidate_list
    ):
        cards += (
            "<div style='font-size:12px;font-weight:600;margin:16px 0 8px;'>"
            "Architecture modernization &mdash; compare against the options above</div>"
        )
        cards += _render_candidate_card(graviton_candidate, current_price)

    if not cards:
        reason = getattr(sizing, "no_recommendation_reason", "") or ""
        cards = f'<div class="note-box">{_esc(reason)}</div>' if reason else ""

    notes = "".join(
        f"<li style='margin-bottom:3px;'>{_esc(n)}</li>" for n in getattr(sizing, "notes", []) or []
    )
    notes_block = (
        f"<div style='margin-top:12px;font-size:11px;color:var(--text-secondary);'>"
        f"<strong>How the candidate pool was narrowed:</strong>"
        f"<ul style='margin:4px 0 0 18px;'>{notes}</ul></div>"
        if notes
        else ""
    )

    validate = getattr(sizing, "mandatory_caveat", "")
    return f"""<section class="section">
  <div class="section-title">Right-sizing</div>
  {banner}
  {profile_block}
  {cards_heading}
  {cards}
  {notes_block}
  <div style="margin-top:14px;padding:10px 14px;background:#fffbeb;border:1px solid #fed7aa;border-radius:6px;font-size:12px;">
    <strong>Validation required:</strong> {_esc(validate)}
  </div>
</section>"""


#: Qualifier key -> reader-facing label, for `_render_os_block`. Ordered so the blocking
#: checks (what to verify BEFORE acting) come before the fix's own caveats.
#:
#: An earlier version of this table lived inline and listed three keys by name while the
#: rules used seven, so `preconditions` — where "MULTI-NODE INSTANCES ONLY" lives — was
#: silently dropped and NUMA-pinning advice shipped without its gate. Kept as a single
#: module-level table (rather than redefined per call site) so the Findings tab and the
#: System tab render every qualifier the same way and cannot drift apart on coverage.
_OS_REMEDIATION_KEY_LABELS = {
    "mandatory_discriminator": "Check first",
    "preconditions": "Applies only when",
    "cannot_be_gated_on": "Cannot be detected from",
    "anchored_target": "Correct target",
    "correct_target": "Correct target",
    "rationale_correction": "Note",
    "risk": "Risk",
    "in_report_verify": "Verify",
}


def _render_os_block(osr: dict[str, Any]) -> str:
    """
    Render a rule's `os_remediation` dict as a self-contained HTML block, or "" if empty.

    A sysctl can never GATE a rule — aperf has no rule that reads sysctl values — but it is
    a legitimate fix for a symptom aperf measured. Rendered as its own block, with strength
    and risk, so it is never mistaken for a language-level setting.

    Single definition, called from both the Findings tab (`_build_playbook_section`) and the
    System tab (`_build_system_sysctl`): `tests/test_anchoring.py::
    test_every_os_remediation_qualifier_reaches_a_reader` greps this function for qualifier
    coverage, so a second inline copy could drift out of sync with the rules without either
    call site's tests noticing.
    """
    if not osr:
        return ""
    os_items = "".join(
        f"<li style='margin-bottom:4px;'><code>{_esc(a)}</code></li>"
        for a in osr.get("actions", [])
    )
    strength = osr.get("strength", "")
    block = f"""
          <div style="margin-top:12px;padding:8px 12px;background:#eff6ff;border-left:3px solid #3b82f6;border-radius:4px;">
            <div style="font-size:11px;font-weight:600;color:#1d4ed8;margin-bottom:4px;">
              OS / sysctl remediation{f" &mdash; {strength}" if strength else ""}
            </div>
            <ul style="margin:4px 0 0 18px;font-size:12px;">{os_items}</ul>"""
    for key, label_txt in _OS_REMEDIATION_KEY_LABELS.items():
        if osr.get(key):
            block += (
                f'<div style="margin-top:6px;font-size:11px;color:#78350f;">'
                f"<strong>{label_txt}:</strong> {_esc(osr[key])}</div>"
            )
    # Anything new added to a rule still surfaces rather than vanishing.
    for key, value in osr.items():
        if key in _OS_REMEDIATION_KEY_LABELS or key in ("actions", "strength") or not value:
            continue
        block += (
            f'<div style="margin-top:6px;font-size:11px;color:#78350f;">'
            f"<strong>{key.replace('_', ' ').title()}:</strong> {_esc(value)}</div>"
        )
    block += "\n          </div>"
    return block


def _build_playbook_section(matches: list[Any], app_context: dict[str, Any]) -> str:
    """
    Render matched diagnostic playbook rules as a report section.
    Groups by category, emits severity badges, language-specific commands,
    and collapsible detail blocks.
    """
    if not matches:
        return ""

    lang = (app_context.get("language") or app_context.get("primary_language") or "").lower()
    # Normalise to extension key
    _lang_map = {
        "java": "java",
        "kotlin": "java",
        "scala": "java",
        "python": "python",
        "python3": "python",
        "go": "go",
        "golang": "go",
        "node": "nodejs",
        "nodejs": "nodejs",
        "javascript": "nodejs",
        "typescript": "nodejs",
        "dotnet": "dotnet",
        ".net": "dotnet",
        "csharp": "dotnet",
        "rust": "rust",
        "c": "cpp",
        "c++": "cpp",
        "cpp": "cpp",
        "php": "php",
    }
    ext_key = _lang_map.get(lang, lang)

    _CATEGORY_LABELS = {
        "os_upgrade": ("OS & Kernel", "#7c3aed", "#f5f3ff"),
        "sysctl_tuning": ("Sysctl Tuning", "#0369a1", "#e0f2fe"),
        "jvm_tuning": ("JVM Tuning", "#b45309", "#fffbeb"),
        "memory_diagnostic": ("Memory Diagnostics", "#0f766e", "#f0fdfa"),
        "cpu_diagnostic": ("CPU Diagnostics", "#b91c1c", "#fef2f2"),
    }
    _SEVERITY_BADGE = {
        "high": "<span class='badge blocker'>HIGH</span>",
        "medium": "<span class='badge verify'>MED</span>",
        "low": "<span class='badge clear'>LOW</span>",
    }
    _CONFIDENCE_NOTE = {
        "high": "",
        "medium": " <span style='font-size:10px;color:#6b7280;'>(recommendation — validate for your workload)</span>",
        "exploratory": " <span style='font-size:10px;color:#9ca3af;'>(exploratory — consider if patterns persist)</span>",
    }

    # Group by category preserving severity order
    from collections import defaultdict

    grouped = defaultdict(list)
    for m in matches:
        grouped[m.category].append(m)

    sections = []
    for category, rules in grouped.items():
        label, accent, _bg = _CATEGORY_LABELS.get(
            category, (category.replace("_", " ").title(), "#374151", "#f9fafb")
        )
        rule_blocks = []
        for r in rules:
            badge = _SEVERITY_BADGE.get(r.severity, "")
            conf_note = _CONFIDENCE_NOTE.get(r.confidence, "")

            # Current → target line when available
            current_target = ""
            if r.current or r.target:
                cur = r.current or "unknown"
                tgt = r.target or ""
                current_target = f"""
          <div style="font-size:12px;margin-top:8px;display:flex;gap:16px;">
            <span><strong>Current:</strong> <code>{cur}</code></span>
            {"<span><strong>Target:</strong> <code>" + tgt + "</code></span>" if tgt else ""}
          </div>"""

            # Core steps
            steps = "".join(f"<li style='margin-bottom:4px;'><code>{s}</code></li>" for s in r.core)
            core_block = (
                f'<ol style="margin:8px 0 0 18px;font-size:12px;">{steps}</ol>' if steps else ""
            )

            # Language-specific extension.
            #
            # Schema 2.0 answers every runtime either with `actions` or with
            # `no_config_needed` + a reason. Rendering the second case is the point: "no
            # runtime knob responds to this" is a real answer, and leaving the cell blank
            # reads as "we have no opinion" when the truth is usually "no knob exists".
            # `advice_for` returns None when the rule is suppressed for that runtime,
            # meaning its threshold is invalid there rather than merely unactionable.
            ext_block = ""
            ext = (r.advice_for(ext_key) if ext_key else (r.extensions.get("generic") or {})) or {}

            if ext.get("no_config_needed"):
                ext_block += (
                    f'<div style="margin-top:12px;font-size:12px;color:var(--text-secondary);'
                    f"background:#f8f9fa;border-left:3px solid var(--text-muted);"
                    f'border-radius:4px;padding:8px 12px;">'
                    f"<strong>No {ext_key or 'runtime'}-specific configuration needed.</strong> "
                    f"{_esc(ext.get('reason', ''))}</div>"
                )
            elif ext.get("actions"):
                act_items = "".join(
                    f"<li style='margin-bottom:4px;'><code>{_esc(a)}</code></li>"
                    for a in ext["actions"]
                )
                ext_block += f"""
          <div style="margin-top:12px;">
            <div style="font-size:11px;font-weight:600;color:{accent};margin-bottom:4px;">
              {(ext_key or "generic").title()} configuration
            </div>
            <ul style="margin:4px 0 0 18px;font-size:12px;">{act_items}</ul>
          </div>"""
                for label_txt, key, tone in (
                    ("Note", "note", "#475569"),
                    ("Do NOT recommend", "explicitly_not_recommended", "#b91c1c"),
                ):
                    val = ext.get(key)
                    if not val:
                        continue
                    body = (
                        "".join(f"<li style='margin-bottom:3px;'>{_esc(v)}</li>" for v in val)
                        if isinstance(val, list)
                        else f"<li>{_esc(val)}</li>"
                    )
                    ext_block += (
                        f'<div style="margin-top:8px;font-size:11px;color:{tone};">'
                        f"<strong>{label_txt}:</strong>"
                        f'<ul style="margin:4px 0 0 18px;">{body}</ul></div>'
                    )

            # OS/sysctl remediation — shared with the System tab, see `_render_os_block`.
            os_block = _render_os_block(r.os_remediation)

            # Next steps — read-only diagnostics, deliberately separated from advice.
            next_block = ""
            if r.next_steps:
                ns = "".join(f"<li style='margin-bottom:3px;'>{_esc(s)}</li>" for s in r.next_steps)
                next_block = (
                    f'<div style="margin-top:10px;font-size:11px;color:var(--text-secondary);">'
                    f"<strong>Diagnostics to collect next (not recommendations):</strong>"
                    f'<ul style="margin:4px 0 0 18px;">{ns}</ul></div>'
                )

            # Anchor provenance — which aperf findings gated this, so a reader can tell
            # measured advice from inference.
            anchor_block = ""
            if r.anchored_by:
                anchor_block = (
                    f'<div style="margin-top:10px;font-size:11px;color:var(--text-muted);">'
                    f"Anchored on aperf finding(s): "
                    f"<code>{_esc(', '.join(r.anchored_by))}</code></div>"
                )

            # Caveats — conditions under which the finding means less than it appears to.
            caveat_block = ""
            if r.caveats:
                cv = "".join(f"<li style='margin-bottom:3px;'>{_esc(c)}</li>" for c in r.caveats)
                caveat_block = (
                    f'<div style="margin-top:10px;font-size:11px;color:#92400e;'
                    f'background:#fffbeb;border:1px solid #fed7aa;border-radius:6px;padding:8px 12px;">'
                    f'<strong>Caveats:</strong><ul style="margin:4px 0 0 18px;">{cv}</ul></div>'
                )

            # Verify command
            verify_block = ""
            if r.verify:
                verify_block = f'<div style="margin-top:8px;font-size:11px;color:var(--text-muted);">Verify: <code>{r.verify}</code></div>'

            rule_blocks.append(f"""
        <div class="finding medium" style="margin-bottom:12px;">
          <div class="finding-header">
            {badge}
            <div>
              <div class="finding-title">{r.title}{conf_note}</div>
              <div class="finding-meta">{r.category.replace("_", " ").title()}</div>
            </div>
          </div>
          <div class="finding-body">
            <p style="margin:0 0 8px;font-size:13px;">{r.why}</p>
            {current_target}
            {core_block}
            {ext_block}
            {os_block}
            {next_block}
            {caveat_block}
            {verify_block}
            {anchor_block}
          </div>
        </div>""")

        sections.append(f"""<section class="section">
  <div class="section-title" style="color:{accent};">{label}</div>
  {"".join(rule_blocks)}
</section>""")

    if not sections:
        return ""

    return "\n".join(sections)


def _build_action_plan(
    recommendations,
    dep_analysis,
    sys_health,
    pmu_summary,
    playbook_matches=None,
    aperf_fired=None,
    graviton_candidate=None,
    sizing=None,
    measured_anomalies=None,
    worker_imbalance=None,
):
    """
    Prioritized action plan table.

    The playbook engine is the authoritative source for the patterns it covers
    (kernel upgrade, THP+JVM, vm.max_map_count, ZGC switch, memory deep-dive,
    CPU profile hotpath). For every OTHER signal — system_health warnings
    that aren't covered by a playbook rule, PMU bottlenecks beyond what the
    playbook detects — we still surface them in the action plan so the
    customer sees the complete picture. Silent dropping of findings was a
    real bug in earlier versions.
    """
    rows = []
    fired = aperf_fired or set()
    _SEV_BADGE = {
        "high": "<span class='badge high'>HIGH</span>",
        "medium": "<span class='badge medium'>MED</span>",
        "low": "<span class='badge low'>LOW</span>",
    }

    # 1. Playbook engine rows (always emit when present)
    matched_check_names: set[str] = set()
    if playbook_matches:
        for m in playbook_matches:
            badge = _SEV_BADGE.get(m.severity, _SEV_BADGE["medium"])
            phase = m.category.replace("_", " ").title()
            action = m.title
            impact = (m.why[:120] + "...") if len(m.why) > 120 else m.why
            # Effort from what schema 2.0 actually carries. `target`/`verify` are schema-1.0
            # fields that no anchored rule sets, so reading them made every row read
            # "see playbook". Priority plus the kind of change is the useful summary: an OS
            # setting and a rebuild are very different amounts of work.
            kinds = []
            if m.os_remediation.get("actions"):
                kinds.append("OS setting")
            if any(
                (m.extensions.get(lang) or {}).get("actions")
                for lang in ("java", "python", "dotnet", "nodejs", "rust")
            ):
                kinds.append("runtime config")
            effort = " + ".join(kinds) or "diagnostic"
            if m.priority_default:
                effort = f"{m.priority_default} — {effort}"
            rows.append((badge, phase, action, impact, effort))
        # De-duplicate against the system_health checks a fired rule already covers.
        #
        # Derived from the rule's own anchors rather than a hardcoded id list. The
        # previous version keyed on schema-1.0 ids (`thp_enable_madvise_jvm` and
        # friends) that no longer exist, so the dedup silently stopped working and the
        # bare unanchored sysctl row below rendered alongside the anchored advice —
        # exactly the advice anchoring exists to suppress. Keying on anchors means a
        # renamed or added rule keeps working without touching this map.
        _anchor_to_check = {
            "Huge Page Disabled": "transparent_huge_pages",
            "Data TLB Misses": "transparent_huge_pages",
            "Data TLB Table Walks": "transparent_huge_pages",
            "Instruction TLB Misses": "transparent_huge_pages",
            "Instruction TLB Table Walks": "transparent_huge_pages",
        }
        for m in playbook_matches:
            for anchor_name in m.anchored_by:
                covered = _anchor_to_check.get(anchor_name)
                if covered:
                    matched_check_names.add(covered)

    # 2. PMU bottlenecks NOT covered by the playbook engine.
    # Anything the engine already surfaced with full context (risk, caveats, per-language
    # advice) must not be repeated here as a bare one-line sysctl.
    if pmu_summary:
        # `memory_translation` is the category the anchored THP/TLB rule uses; matching on
        # it rather than on ids means a future TLB rule is covered automatically.
        pmu_covered_by_playbook = any(
            m.category == "memory_translation" for m in (playbook_matches or [])
        )
        if (
            "Backend-Dominated CPU Stalls" in fired
            and pmu_summary.backend_stall_pct > 40
            and not pmu_covered_by_playbook
        ):
            rows.append(
                (
                    "<span class='badge high'>HIGH</span>",
                    "Memory bandwidth",
                    "Investigate memory access patterns; consider huge pages and prefetching",
                    f"Backend stalls at {pmu_summary.backend_stall_pct:.0f}% \u2014 memory subsystem is the bottleneck",
                    "JVM/code change",
                )
            )
        if (
            {"Data TLB Misses", "Data TLB Table Walks"} & fired
            and pmu_summary.dtlb_misses_per_1k_instructions >= FLOOR_DTLB_MPKI
            and not pmu_covered_by_playbook
        ):
            rows.append(
                (
                    "<span class='badge medium'>MED</span>",
                    "Memory translation",
                    "Enable Transparent Huge Pages: <code>echo madvise &gt; /sys/kernel/mm/transparent_hugepage/enabled</code>",
                    f"DTLB misses {pmu_summary.dtlb_misses_per_1k_instructions:.1f}/1K \u2014 reduce TLB pressure 5-10x",
                    "1 sysctl",
                )
            )
            # The PMU row already proposes THP; suppress the system_health
            # warning for transparent_huge_pages so we don't double-render.
            matched_check_names.add("transparent_huge_pages")
        if {"Instruction TLB Misses", "Instruction TLB Table Walks"} & fired and getattr(
            pmu_summary, "itlb_misses_per_1k_instructions", 0
        ) >= FLOOR_ITLB_MPKI:
            rows.append(
                (
                    "<span class='badge medium'>MED</span>",
                    "Code TLB pressure",
                    # Was `-XX:-TieredCompilation`, which aperf's own rule message argues
                    # AGAINST and which the findings library reads as "nobody has tuned JIT",
                    # not "misconfigured". Code-cache sizing is the JVM lever that actually
                    # responds to instruction-footprint pressure.
                    "Investigate JIT code footprint; size the code cache "
                    "(<code>-XX:ReservedCodeCacheSize</code>) for JVM",
                    f"ITLB misses {pmu_summary.itlb_misses_per_1k_instructions:.1f}/1K \u2014 instruction footprint exceeds TLB coverage",
                    "JVM flag",
                )
            )
        if (
            "High Branch Mispredictions" in fired
            and getattr(pmu_summary, "branch_misses_per_1k_instructions", 0) >= APERF_BRANCH_MPKI
        ):
            rows.append(
                (
                    "<span class='badge medium'>MED</span>",
                    "Branch prediction",
                    "Profile branch-heavy code paths; consider PGO (Profile-Guided Optimization)",
                    f"Branch misses {pmu_summary.branch_misses_per_1k_instructions:.1f}/1K \u2014 pipeline flush overhead",
                    "Code change",
                )
            )

    # 3. System health checks NOT already covered by a playbook rule.
    #
    # Anchored checks are included even at `info`: after anchoring, a raw setting value is
    # not a problem on its own, so nothing reaches `warning` any more. Filtering on
    # warning/critical dropped all 14, taking the swappiness pswpin discriminator and the
    # irqbalance-reverts risk with it. Unanchored hygiene observations stay out of the
    # action plan — they are not actions.
    for c in sys_health.get("checks", []):
        status = c.get("status", "info")
        if status in ("pass", "not_applicable"):
            continue
        if not _anchor_fired(c, fired):
            continue
        check_name = c.get("check", "")
        if check_name in matched_check_names:
            continue
        fix_cmd = c.get("fix") or c.get("candidate_fix", "")
        # The Action column must be prescriptive — render the actual fix command
        # in <code> when one exists. When no fix is registered, fall back to the
        # 'recommended' guidance with a clear note that no canonical command
        # is available yet.
        if fix_cmd:
            action_html = f"<code>{fix_cmd}</code>"
        else:
            action_html = (
                f"Set <strong>{check_name.replace('_', ' ')}</strong> to "
                f"<code>{_esc(c.get('recommended') or c.get('correct_target') or '?')}</code> "
                f"<span style='color:var(--text-muted);font-size:10px;'>"
                f"(no canonical command registered \u2014 see system_health.py)"
                f"</span>"
            )
        impact_text = c.get("impact", "")[:140]
        effort_text = (
            f"Current: <code>{_esc(c.get('current', '?'))}</code> "
            f"\u2192 Target: <code>{_esc(c.get('recommended') or c.get('correct_target') or '?')}</code>"
        )
        rows.append(
            (
                "<span class='badge medium'>MED</span>",
                check_name.replace("_", " "),
                action_html,
                impact_text,
                effort_text,
            )
        )

    # Instance-change rows from the OLDER recommender are deliberately NOT emitted here.
    #
    # `recommendations.instance_options` comes from the older template-based recommender,
    # which is a second sizing voice: it picks a family from a three-entry map, ignores the
    # purpose-built family classes, and knows nothing of the verdict. On a real i8g run it
    # emitted "Migrate to r8g.2xlarge" directly beneath a KEEP verdict — a family-class
    # violation contradicting the recommendation on the same screen. Sizing has one owner
    # now, the benchmark-backed engine, and its conservative/aggressive picks render on
    # the Right-sizing tab.
    #
    # The Graviton MODERNIZATION candidate is a different case: it comes from the SAME
    # benchmark-backed engine (`rightsizer.recommend_graviton_equivalent`) the Right-sizing
    # and ARM Modernization tabs already render, so surfacing it here is not reintroducing
    # a second, disagreeing voice — it was simply missing from the action plan even though
    # it's a real, actionable item a reader building a prioritized to-do list should see.
    # Skipped when it duplicates an existing conservative/aggressive pick, same rule the
    # Right-sizing tab's comparison card uses, so the SAME instance never appears as two
    # different action-plan rows under two different framings.
    if graviton_candidate is not None:
        _existing_types = {c.instance_type for c in (getattr(sizing, "candidates", []) or [])}
        if graviton_candidate.instance_type not in _existing_types:
            _badge = _SEV_BADGE["high"] if graviton_candidate.risk == "high" else _SEV_BADGE["low"]
            _price = (
                f"${graviton_candidate.price_per_hour:.4f}/hr"
                if graviton_candidate.price_per_hour is not None
                else "price not in the bundled snapshot"
            )
            _action_text = (
                f"Evaluate {graviton_candidate.instance_type} (aarch64) as a Graviton "
                "migration — see the ARM Modernization tab for the full comparison"
            )
            _impact_text = (
                f"{graviton_candidate.vcpu} vCPU, {graviton_candidate.memory_gb:.0f} GB, {_price}"
            )
            rows.append(
                (
                    _badge,
                    "Architecture modernization",
                    _action_text,
                    _impact_text,
                    "Architecture migration"
                    if graviton_candidate.risk == "high"
                    else "Confirm dependencies",
                )
            )

    # Measured anomalies — real numbers computed directly from this run's own CPU/
    # memory/disk summaries, but NOT anchored to a curated aperf finding (no playbook
    # rule fires on them). Labeled explicitly as MEASURED so a reader (or a calling
    # agent) can't mistake this for schema-curated, hand-vetted guidance — the same
    # distinction `_curated_entry_for`/`sysctl_ai_fallback.py` already draws between
    # playbook-derived and AI-generated guidance, applied here to measured-vs-curated.
    from .action_plan import measured_anomaly_recommendations

    for anomaly_text in measured_anomalies or []:
        code, _, detail = anomaly_text.partition(": ")
        recs = measured_anomaly_recommendations(anomaly_text)
        action_text = (
            "<ul style='margin:0 0 0 18px;padding:0;'>"
            + "".join(f"<li>{_esc(r)}</li>" for r in recs)
            + "</ul>"
            if recs
            else "No recommendation available for this anomaly code yet."
        )
        rows.append(
            (
                "<span class='badge measured'>MEASURED</span>",
                code.replace("_", " ").title(),
                action_text,
                detail,
                "Computed directly from this run's own CPU/memory/disk data — not a curated aperf finding.",
            )
        )
    if worker_imbalance:
        rows.append(
            (
                "<span class='badge measured'>MEASURED</span>",
                "Worker Load Imbalance",
                worker_imbalance["diagnosis"],
                "; ".join(worker_imbalance["resolution"]),
                "Investigate",
            )
        )

    # Dependency actions
    if dep_analysis:
        for b in dep_analysis.blockers:
            rows.append(
                (
                    "<span class='badge blocker'>BLOCKER</span>",
                    "Dependency",
                    f"{b.name} {b.version}",
                    b.reason[:120],
                    b.action,
                )
            )
        for d in dep_analysis.degradeds:
            rows.append(
                (
                    "<span class='badge degraded'>DEGRADED</span>",
                    "Dependency",
                    f"{d.name} {d.version}",
                    d.reason[:120],
                    d.action,
                )
            )

    if not rows:
        return ""

    # Real priority sort — the table header has always promised a "Priority" ordering,
    # but rows previously rendered in section-insertion order regardless of severity
    # (a HIGH playbook row could render below a MEDIUM PMU row purely because playbook
    # rows were appended first). This makes the visual order match the header. Shared
    # with `run_summary.py`'s own `action_plan` field so the two never disagree about
    # what "priority" means for the same underlying findings.
    from .action_plan import severity_rank

    rows.sort(key=lambda row: severity_rank(row[0]))

    table_rows = "".join(
        f"<tr><td>{p}</td><td><strong>{phase}</strong></td><td>{action}</td><td>{impact}</td><td>{effort}</td></tr>"
        for p, phase, action, impact, effort in rows
    )

    return f"""<section class="section">
  <div class="section-title">Prioritized Action Plan</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Priority</th><th>Phase</th><th>Action</th><th>Impact / Rationale</th><th>Effort</th></tr></thead>
      <tbody>{table_rows}</tbody>
    </table>
  </div>
</section>"""
