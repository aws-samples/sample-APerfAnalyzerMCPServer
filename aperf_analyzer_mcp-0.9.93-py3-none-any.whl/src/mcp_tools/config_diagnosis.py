# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: diagnose_config_errors

Detects common misconfiguration patterns from aperf data.
Maps system-level symptoms to known configuration issues.

Anchoring
---------
Every pattern carries an `anchor`. Three have real ones — `numa_misplacement`,
`connection_pool_exhaustion` and `thread_pool_oversized` — gated on cache-miss and
stall findings aperf actually emits. The other eight are `UNANCHORED` and say why in
`anchor.why_no_anchor`, because the data types they depend on carry no rules at all:

- `processes.rs`, `perf_profile.rs`, `interrupts.rs`, `numastat.rs` are empty impls, so
  no per-process, flamegraph-percentage, interrupt or NUMA finding exists.
- aperf collects **no context-switch metric**, so the `high_context_switches` gate was
  never evaluatable.
- aperf has **no GC rule**, so `periodic_cpu_dips` cannot distinguish a GC pause from an
  I/O block or a bursty workload.

Unanchored patterns are still worth keeping: the mechanisms are real and field-verified,
and their `resolution` steps are mostly read-only investigation. They are returned
labelled so a reader can tell a measured diagnosis from a plausible hypothesis. What
they must never do is read as though aperf measured them.

Note that `detection` is reference metadata only — nothing evaluates it, and the live
detectors below compute their own gates.
"""

import json
import os
from typing import Any

from mcp.types import Tool

CONFIG_DIAGNOSIS_TOOL = Tool(
    name="diagnose_config_errors",
    description=(
        "Detect common misconfiguration patterns from aperf data. "
        "Analyzes process distribution, CPU utilization patterns, and interrupt "
        "data to identify known anti-patterns like worker starvation, session "
        "affinity issues, NUMA misplacement, and connection pool exhaustion. "
        "Based on real-world customer cases."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "expected_workers": {
                "type": "integer",
                "description": "Expected number of application workers (if known)",
            },
            "load_balancer_type": {
                "type": "string",
                "enum": ["alb", "nlb", "nginx", "haproxy", "envoy", "unknown"],
                "description": "Type of load balancer in front (helps narrow diagnosis)",
                "default": "unknown",
            },
            "data_dir": {"type": "string"},
        },
        "required": ["run_name"],
    },
)


# Known misconfiguration patterns
CONFIG_PATTERNS = [
    {
        "id": "worker_starvation_session_affinity",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "processes.rs has ZERO rules. Underutilized CPU is aggregate-only and blind to per-core imbalance, so it is an entry condition at best. Per-process CV is computable, but the top-16-process truncation BIASES CV DOWNWARD and user_space_time drops its first sample, putting it off-by-one against iowait.",
        },
        "name": "Worker Starvation from Session Affinity",
        "description": (
            "Some workers receive disproportionate load while others are idle. "
            "Common when load balancer uses source-IP based session persistence "
            "and clients are behind NAT/proxy (sharing IPs)."
        ),
        "detection": {
            "trigger": "process_utilization_imbalance",
            "threshold": 0.4,  # 40%+ imbalance between workers
        },
        "symptoms_in_aperf": [
            "N workers configured but only subset shows CPU activity",
            "Per-process CPU shows bimodal distribution (some high, some near-zero)",
            "Overall system CPU is low despite reported high load",
            "Network interrupts may be uneven across CPUs",
        ],
        "root_causes": [
            "Load balancer using source_ip sticky sessions",
            "Clients behind corporate NAT (all share same source IP)",
            "IPv4-only session persistence (IPv6 would spread better)",
            "Hash-based routing with low entropy in source addresses",
        ],
        "resolution": [
            "Switch session persistence: source_ip → cookie-based (e.g., AWSALB cookie)",
            "Or disable session affinity entirely (if application is stateless)",
            "If sessions required: use shared session store (Redis/Memcached) + round-robin",
            "For nginx: change `ip_hash` to `least_conn` in upstream block",
            "For ALB: change stickiness from source-IP to application cookie",
            "For NLB: consider switching to ALB for L7 routing flexibility",
            "Verify with: check LB access logs for source IP distribution",
        ],
        "severity": "high",
        "affected_runtimes": ["php", "python", "nodejs", "ruby"],
    },
    {
        "id": "numa_misplacement",
        "anchor": {
            "aperf_rules": [
                "High L3 Cache Misses",
                "High L2 Cache Misses",
                "High L1 Data Cache Misses",
                "Backend-Dominated CPU Stalls",
                "Data TLB Table Walks",
            ],
            "strength": "PRIMARY",
            "check_first": "MULTI-NODE ONLY. Confirm numastat other_node / numa_foreign are non-zero — numastat.rs has no rules, so this is evidence you compute, not a finding.",
            "verify_in_report": "other_node decreasing AND stall-backend-pkc decreasing together",
        },
        "name": "NUMA Cross-Node Memory Access",
        "description": (
            "Application threads and their data are on different NUMA nodes, "
            "causing remote memory access penalties (2-3x latency)."
        ),
        "detection": {
            "trigger": "high_remote_numa_access",
            "threshold": 0.2,  # >20% remote access
        },
        "symptoms_in_aperf": [
            "High backend stalls despite moderate cache miss rates",
            "Memory latency higher than expected for instance type",
            "IPC lower than expected for the workload type",
            "CPU utilization varies across NUMA nodes",
        ],
        "root_causes": [
            "Process not pinned to NUMA node",
            "JVM/runtime allocating memory on wrong node at startup",
            "Kernel migrating threads across NUMA boundaries",
            "numa_balancing causing unnecessary migrations",
        ],
        "resolution": [
            (
                "FIRST — confirm remote access is actually happening: `numastat -p <pid>` and "
                "check other_node / numa_foreign are non-zero. numastat carries no aperf rules, "
                "so this is evidence you gather, not a finding. Single-socket instances are "
                "unaffected."
            ),
            "Pin application to NUMA node: `numactl --cpubind=0 --membind=0 ./app`",
            "For containers: set cpuset in cgroup to a single NUMA node",
            (
                "Disable auto-balancing only alongside explicit pinning: "
                "`sysctl -w kernel.numa_balancing=0` (bidirectional — it helps "
                "latency-sensitive workloads and can hurt batch ones)"
            ),
            "Verify the fix worked: other_node decreasing AND stall-backend-pkc decreasing together",
        ],
        "not_recommended": [
            (
                "-XX:+UseNUMA — EC2 instances below the metal tier are effectively "
                "single-socket, so this has nothing to balance across, and no aperf finding "
                "can evidence it."
            ),
        ],
        "severity": "high",
        "affected_runtimes": ["all"],
    },
    {
        "id": "gc_overprovisioned_heap",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "aperf has NO GC rule of any kind. java_profile.rs contains exactly 3 rules (Excessive Exceptions, Tiered Compilation Check, JVM Version Comparison), none about collectors or heap sizing. The periodic_cpu_dips gate cannot distinguish a GC pause from an I/O block or a bursty workload.",
        },
        "name": "GC Heap Overprovisioned (Long Pauses)",
        "description": (
            "Heap size too large → GC takes too long when it runs. "
            "Manifests as periodic deep CPU dips in aperf."
        ),
        "detection": {
            "trigger": "periodic_cpu_dips",
            "threshold": 0.3,  # Dips of 30%+ CPU
        },
        "symptoms_in_aperf": [
            "Periodic deep drops in CPU utilization (e.g., every 30-60 seconds)",
            "Dip duration > 100ms (long full-GC pauses)",
            "CPU goes to near-zero during dips (STW GC)",
            "Memory usage shows sawtooth pattern",
        ],
        "root_causes": [
            "Heap too large for GC algorithm (G1/CMS/Parallel scanning too much)",
            "-Xms much smaller than -Xmx (heap resizing triggers full GC)",
            "Too many tenured objects requiring full collection",
            "Explicit System.gc() calls in code",
        ],
        # CONFIRM GC IS THE CAUSE FIRST. aperf has no GC rule, so nothing here established
        # that the CPU dips are collections rather than an I/O block, a bursty workload or
        # a throttled container. These are steps to test that hypothesis, and only then to
        # act on it — deliberately not phrased as recommendations.
        "resolution": [
            (
                "FIRST — confirm the dips are GC at all: enable GC logging (-Xlog:gc for JVM, "
                "dotnet-counters for .NET) and check whether pauses line up with the dips. "
                "No aperf finding can tell you this."
            ),
            (
                "If confirmed, and pauses scale with heap size: evaluate a low-pause collector "
                "against your own latency measurements, not against this finding"
            ),
            (
                "If confirmed, and pauses coincide with heap growth: set -Xms == -Xmx so the "
                "heap is not repeatedly resized"
            ),
            (
                "If confirmed, and allocation rate is the driver: profile allocations to reduce "
                "object creation"
            ),
            "For .NET, DOTNET_GCgen0size raises the gen0 budget and reduces collection frequency",
        ],
        "severity": "medium",
        "affected_runtimes": ["java", "dotnet", "go"],
    },
    {
        "id": "connection_pool_exhaustion",
        "anchor": {
            "aperf_rules": ["Underutilized CPU"],
            "strength": "SECONDARY — entry condition only",
            "check_first": "Underutilized CPU is computed on the AGGREGATE series, so it cannot distinguish a pool bottleneck from an idle machine or an I/O block. There is no aperf system-time threshold rule, so the original low_cpu_high_system_time gate had no anchor.",
        },
        "name": "Connection Pool Exhaustion",
        "description": (
            "Application workers block waiting for database/service connections. "
            "Visible as low CPU but high latency."
        ),
        "detection": {
            "trigger": "low_cpu_high_system_time",
            "threshold": 0.15,  # CPU < 50% but system time > 15%
        },
        "symptoms_in_aperf": [
            "CPU utilization well below capacity despite reported high load",
            "Elevated system time (threads in futex/epoll_wait)",
            "Processes exist but show minimal CPU usage",
            "No I/O wait (ruling out disk bottleneck)",
        ],
        "root_causes": [
            "Database connection pool too small for worker count",
            "External service calls blocking without timeout",
            "Connection leak (pool never returns connections)",
            "DNS resolution blocking connection establishment",
        ],
        "resolution": [
            "Increase connection pool size (rule of thumb: workers * 1.5)",
            "Add connection timeout + circuit breaker pattern",
            "For Java: HikariCP with maximumPoolSize = workers + 5",
            "For Python: SQLAlchemy pool_size + max_overflow",
            "For PHP: PDO persistent connections or connection pooler (PgBouncer)",
            "Monitor with: connection pool metrics + aperf process state",
        ],
        "severity": "high",
        "affected_runtimes": ["all"],
    },
    {
        "id": "thread_pool_oversized",
        "anchor": {
            "aperf_rules": [
                "High L1 Data Cache Misses",
                "High L2 Cache Misses",
                "High L3 Cache Misses",
            ],
            "strength": "SECONDARY",
            "check_first": "The original high_context_switches gate is UNEVALUATABLE: aperf collects no context-switch metric at all (ctxt appears in zero rules) and interrupts.rs has no rules. Too many threads shows up as cache pressure from working-set multiplication, which is measurable; the switch count is not.",
        },
        "name": "Thread Pool Oversized (Excessive Context Switching)",
        "description": (
            "Too many threads competing for CPUs → excessive context switching, "
            "cache thrashing, and overhead."
        ),
        "detection": {
            "trigger": "high_context_switches",
            "threshold": 50000,  # > 50K cs/sec per CPU
        },
        "symptoms_in_aperf": [
            "High system time (from context switch overhead)",
            "High IPI/RES interrupts (scheduler rebalancing)",
            "Lower IPC than expected (cache thrashing from switches)",
            "High L1 cache miss rate (working sets don't fit)",
        ],
        "root_causes": [
            "Thread pool sized at request count instead of CPU count",
            "Multiple thread pools (HTTP, DB, async) stacking up",
            "Fork-join pool parallelism too high",
            "Go: GOMAXPROCS set too high (above CPU count)",
        ],
        "resolution": [
            "Size thread pools to physical CPU count (not vCPUs for compute-bound)",
            "For Java: ForkJoinPool parallelism = CPU count",
            "For compute-bound: threads = CPU count",
            "For I/O-bound: threads = CPU count * 2 (at most)",
            "Consolidate thread pools where possible",
            "For Go: let runtime manage (default GOMAXPROCS = CPU count)",
        ],
        "severity": "medium",
        "affected_runtimes": ["java", "dotnet", "cpp", "rust"],
    },
    {
        "id": "ipv4_session_routing_bias",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "processes.rs has ZERO rules; no aperf finding reports per-worker load distribution.",
        },
        "name": "IPv4 Session Routing Bias",
        "description": (
            "Load balancer hashing on IPv4 source creates uneven worker distribution. "
            "Clients behind shared NAT gateways all hash to same backend workers."
        ),
        "detection": {
            "trigger": "worker_load_skew",
            "threshold": 2.0,  # 2x difference between busiest/quietest worker
        },
        "symptoms_in_aperf": [
            "Process data shows workers with very different CPU time",
            "Some workers at 80%+ while others at 10-20%",
            "Network connection count uneven across worker processes",
            "System overall appears under-utilized",
        ],
        "root_causes": [
            "ALB/NLB using source IP hash for target group stickiness",
            "Corporate clients behind NAT gateway (1 IP → thousands of users)",
            "CDN/proxy forwarding all traffic from limited IP pool",
            "Kubernetes service using iptables-mode kube-proxy (random but persistent)",
        ],
        "resolution": [
            "Switch to cookie-based session affinity (ALB: enable stickiness with LB-generated cookie)",
            "For nginx: use `hash $request_uri consistent` instead of `ip_hash`",
            "For stateless apps: use `least_conn` or `round_robin`",
            "For K8s: use IPVS mode with least-connection scheduling",
            "Externalze session state to Redis/DynamoDB → enable stateless routing",
            "Consider: X-Forwarded-For based hashing (more entropy than source IP)",
        ],
        "severity": "high",
        "affected_runtimes": ["php", "python", "nodejs", "java"],
    },
    # -----------------------------------------------------------------------
    # New patterns derived from real EKS Python investigation
    # -----------------------------------------------------------------------
    {
        "id": "alb_envoy_connection_affinity",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "processes.rs has ZERO rules — same limitation as worker_starvation_session_affinity.",
        },
        "name": "ALB/Envoy Persistent Connection Affinity to Gunicorn Workers",
        "description": (
            "ALB and Envoy (Istio sidecar) maintain persistent keepalive connection pools "
            "to backend pods. With Gunicorn gthread workers, each persistent connection "
            "is accepted by one worker and all subsequent requests on that connection "
            "go to the same worker. This causes severe load imbalance: a few workers "
            "handle most requests while the rest sit idle, even with CPU headroom available."
        ),
        "detection": {
            "trigger": "process_utilization_imbalance",
            "threshold": 0.4,
            "context": "gunicorn or similar multi-worker WSGI behind ALB/Envoy",
        },
        "symptoms_in_aperf": [
            "3-4 of N Gunicorn workers show 30-80% CPU while the rest are <5%",
            "Overall node CPU is 20-30% despite reported high application load",
            "Network throughput is high but CPU is underutilized",
            "TCPHPHits and TCPDelivered are high but TW (TIME_WAIT) is low (persistent conns)",
        ],
        "root_causes": [
            "ALB maintains a small pool of persistent TCP connections to each target",
            "Envoy sidecar also maintains persistent upstream connection pools to localhost:port",
            "Gunicorn gthread workers bind one connection to one thread for its lifetime",
            "SO_REUSEPORT does not help: it only distributes new connections, not requests on existing ones",
        ],
        "resolution": [
            "Istio DestinationRule: set maxRequestsPerConnection: 1 to force per-request connections",
            "Istio DestinationRule: set loadBalancer.simple: LEAST_REQUEST",
            (
                "Example: kubectl apply -f - << EOF\\napiVersion: networking.istio.io/v1beta1\\n"
                "kind: DestinationRule\\nmetadata:\\n  name: your-app\\nspec:\\n  host: your-app\\n"
                "  trafficPolicy:\\n    connectionPool:\\n      http:\\n        maxRequestsPerConnection: 1\\n"
                "    loadBalancer:\\n      simple: LEAST_REQUEST\\nEOF"
            ),
            "Alternative: switch to gevent or uvicorn worker class (request-level not connection-level)",
            "Alternative: lean pod model with fewer workers — imbalance matters less with 2 workers vs 7",
        ],
        "severity": "high",
        "affected_runtimes": ["python", "php", "ruby"],
    },
    {
        "id": "inline_aws_sdk_hot_path",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "perf_profile.rs has ZERO rules, so no flamegraph-percentage gate can be anchored.",
        },
        "name": "AWS SDK Calls on the Request Hot Path",
        "description": (
            "botocore API calls (AppConfig, Secrets Manager, SSM Parameter Store, etc.) "
            "are being made synchronously on the request handling path. Each call involves "
            "SigV4 request signing (HMAC computation), TLS handshake if no connection reuse, "
            "and a network round-trip. At high request rates this compounds into significant "
            "latency and CPU overhead."
        ),
        "detection": {
            "trigger": "flamegraph_category",
            "category": "aws_sdk",
            "threshold_pct": 3.0,
        },
        "symptoms_in_aperf": [
            "botocore._make_api_call appears in flamegraph hot path (>3% CPU)",
            "SigV4Auth.add_auth visible in profile — HMAC computed per request",
            "Endpoint.make_request and Endpoint._send_request in hot path",
            "CPU > expected for workload volume (AWS calls add 5-50ms each)",
        ],
        "root_causes": [
            "AppConfig, Secrets Manager, or SSM Parameter Store fetched per-request",
            "No in-process caching with TTL — every request pays the full AWS API cost",
            "Dynamic configuration loaded lazily rather than at startup with periodic refresh",
        ],
        "resolution": [
            "Cache AWS API responses in-process with a TTL (60-300 seconds typical)",
            "Use aws-appconfig-agent sidecar for AppConfig — it caches locally",
            "For Secrets Manager: cache in a module-level dict, refresh on a timer",
            (
                "Example:\n"
                "  _cache = {}\n"
                "  def get_secret():\n"
                "      if 'val' not in _cache or time.time() - _cache['ts'] > 60:\n"
                "          _cache['val'] = boto3_client.get_secret_value(SecretId='...')\n"
                "          _cache['ts'] = time.time()\n"
                "      return _cache['val']"
            ),
        ],
        "severity": "critical",
        "affected_runtimes": ["python", "java", "nodejs"],
    },
    {
        "id": "apm_instrumentation_overhead",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "perf_profile.rs has ZERO rules.",
        },
        "name": "APM Instrumentation Stack Capture Overhead",
        "description": (
            "ElasticAPM (and similar APM agents) capture the full Python call stack on "
            "every span entry and exit. For fast operations (sub-millisecond DB queries, "
            "small function calls) the stack capture overhead exceeds the operation cost. "
            "At 100% transaction sampling with no minimum duration threshold, this adds "
            "3-8% CPU overhead across all request handling."
        ),
        "detection": {
            "trigger": "flamegraph_category",
            "category": "apm_instrumentation",
            "threshold_pct": 3.0,
        },
        "symptoms_in_aperf": [
            "elasticapm.traces.capture_span appears in flamegraph (>3% CPU)",
            "iter_stack_frames visible in profile — stack capture on every span",
            "PyMongoInstrumentation and PyMongoCursorInstrumentation in hot path",
            "CPU overhead unexplained by business logic",
        ],
        "root_causes": [
            "ELASTIC_APM_TRANSACTION_SAMPLE_RATE=1.0 (default) — 100% sampling",
            "ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION not set — captures stack for all spans",
            "Stack depth not limited — deep call stacks are expensive to capture",
        ],
        "resolution": [
            "Set ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION=50ms (skip stack capture for fast ops)",
            "Set ELASTIC_APM_TRANSACTION_SAMPLE_RATE=0.1 (10% sampling, adjustable)",
            "Set ELASTIC_APM_STACK_TRACE_LIMIT=50 (cap stack depth)",
            "These three env vars recover the full overhead with no code changes",
        ],
        "severity": "high",
        "affected_runtimes": ["python"],
    },
    {
        "id": "dsl_expression_rebuild",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "perf_profile.rs has ZERO rules.",
        },
        "name": "DSL/Filter Expression Tree Rebuilt on Every Request",
        "description": (
            "A rule engine or DSL evaluator is constructing new expression/AST objects "
            "on every request evaluation instead of compiling once and caching. "
            "This is visible as __init__ constructors for expression/filter classes "
            "appearing in the flamegraph hot path alongside the evaluation methods."
        ),
        "detection": {
            "trigger": "flamegraph_category",
            "category": "filters_dsl",
            "threshold_pct": 10.0,
        },
        "symptoms_in_aperf": [
            "DynamicFilter.evaluate or equivalent is top CPU consumer (>7%)",
            "Expression.__init__ visible in hot path — object construction per-request",
            "handle_conditionals and handle_lists show consistent CPU pressure",
            "Filter-related DB calls (transaction_count, is_new_device) inline in evaluation",
        ],
        "root_causes": [
            "Filter/rule objects constructed fresh on every request rather than cached",
            "No compiled expression tree cache keyed on rule version or hash",
            "Database lookups for context data (device info, transaction count) done inline",
        ],
        "resolution": [
            "Cache the compiled expression tree at object construction: self._compiled = Expression(rule)",
            "Use evaluate(event) as a pure function on the pre-compiled object",
            "Pre-fetch context data (device history, transaction counts) before evaluation begins",
            "Key the expression cache on rule version or content hash for invalidation",
            (
                "Example:\n"
                "  class DynamicFilter:\n"
                "      def __init__(self, rule_definition):\n"
                "          self._compiled = Expression(rule_definition)  # once\n"
                "      def evaluate(self, event):\n"
                "          return self._compiled.eval(event)  # fast path"
            ),
        ],
        "severity": "critical",
        "affected_runtimes": ["python"],
    },
    {
        "id": "odm_full_document_deserialization",
        "anchor": {
            "aperf_rules": [],
            "strength": "UNANCHORED — evidence-class observation, not a finding",
            "why_no_anchor": "perf_profile.rs has ZERO rules.",
        },
        "name": "ODM Deserializing Full Documents When Only Subset of Fields Needed",
        "description": (
            "An ODM (Object Document Mapper) like lmongo, MongoEngine, or similar is "
            "fetching complete documents from MongoDB and constructing full Python objects "
            "with per-field validation for every query result. When only a small subset "
            "of fields is used downstream, this wastes CPU on deserialization and "
            "memory on unused field objects."
        ),
        "detection": {
            "trigger": "flamegraph_category",
            "category": "bson_mongodb",
            "threshold_pct": 3.0,
        },
        "symptoms_in_aperf": [
            "Document.from_mongo or equivalent in top CPU consumers (>3%)",
            "Document.__setattr__ and Document.__init__ both visible in profile",
            "MongoDB response sizes are large relative to data actually used",
        ],
        "root_causes": [
            "MongoDB queries without projection — all fields fetched and deserialized",
            "ODM field validation on every __setattr__ call",
            "Large embedded documents or arrays deserialized in full",
        ],
        "resolution": [
            "Add projection to queries: collection.find({...}, projection={'field1': 1, 'field2': 1})",
            "Use .only('field1', 'field2') if ODM supports it",
            "For read-heavy paths consider raw pymongo queries instead of ODM layer",
            "Review top 5 most frequent queries and add projections to each",
        ],
        "severity": "high",
        "affected_runtimes": ["python"],
    },
]


import statistics as _stats

# Container/orchestration runtime processes are never an application's own worker pool —
# imbalance among them reflects container scheduling/placement, not something a
# --reuse-port or worker-class flag can address. Observed on a real capture: containerd-shim
# workers showed a 5x load ratio and received Gunicorn/gevent advice verbatim, which is
# nonsensical for a container runtime shim.
_INFRA_PROCESS_NAMES = frozenset(
    {
        "containerd-shim",
        "containerd",
        "dockerd",
        "docker-proxy",
        "kubelet",
        "kube-proxy",
        "kube-apiserver",
        "etcd",
        "systemd",
        "systemd-journald",
        "systemd-udevd",
        "runc",
        "runc-shim",
    }
)

# Language-specific accept()-bias resolution, keyed the same way
# `language_detector.PROCESS_NAME_LANGUAGE_NEEDLES` maps a process name to a language — one
# lookup table, reused here instead of a second hardcoded guess. Only languages whose worker
# model actually has a language-specific fix are listed; anything else falls back to the
# generic OS-level advice (SO_REUSEPORT, load-balancer scheduling), which applies regardless
# of runtime.
_WORKER_RESOLUTION_BY_LANGUAGE = {
    "python": [
        "Python (Gunicorn/uWSGI sync workers): add '--reuse-port' so each worker gets its "
        "own listen socket instead of sharing one via accept(), or switch worker class "
        "to gevent/uvicorn (async, no accept bias)",
    ],
    "nodejs": [
        "Node.js: if using the built-in 'cluster' module, its own round-robin scheduling "
        "(the default on Linux) already avoids accept() bias — check for cluster mode "
        "being disabled, or a manual accept()-sharing setup, before assuming an OS-level fix",
    ],
    "java": [
        "Java: check whether the app server (Tomcat/Jetty/Netty) uses SO_REUSEPORT or a "
        "shared boss/acceptor thread — most modern Java HTTP servers already distribute "
        "connections evenly; imbalance more often points at uneven request COST, not "
        "accept() bias",
    ],
}

_GENERIC_WORKER_RESOLUTION = [
    "If a load balancer is in front: switch from source-IP affinity to round-robin or least_conn",
    "If sessions are required: move session state to a shared store (e.g. Redis) and use "
    "stateless routing",
    "For Kubernetes: ensure kube-proxy is in IPVS mode with rr or lc scheduler",
]


def _match_worker_language(base_name: str) -> str:
    """`base_name` -> normalised language key, via the SAME needle table
    `language_detector.py` uses for process-name-based language detection — one source of
    truth, so this and that module can never disagree about what a process name implies."""
    from ..language_detector import PROCESS_NAME_LANGUAGE_NEEDLES

    lowered = base_name.lower()
    for needle, key in PROCESS_NAME_LANGUAGE_NEEDLES:
        if needle in lowered:
            return key
    return ""


def _detect_worker_imbalance(processes: dict[str, Any]) -> dict[str, Any] | None:
    """
    Detect imbalanced load across same-named worker processes.

    Groups processes by base name (strips leading PID), computes per-worker
    average user-space CPU time, and flags when the coefficient of variation
    exceeds 50% or when the max/min ratio exceeds 3x.

    Container/orchestration runtime process groups (`_INFRA_PROCESS_NAMES`) are skipped
    entirely — they are never an application's own worker pool, so no worker-model advice
    applies to them.
    """
    user_series = processes.get("user_space_time", {}).get("series", [])
    if not user_series:
        return None

    # Group by base process name (e.g. "gunicorn", "uwsgi", "node")
    from collections import defaultdict

    groups: dict[str, Any] = defaultdict(list)
    for s in user_series:
        name = s["series_name"]
        # Strip leading PID: "3922_gunicorn" -> "gunicorn"
        base = name.split("_", 1)[-1] if "_" in name else name
        vals = [v for v in s["values"] if v > 0]
        if vals:
            groups[base].append(
                {
                    "process": name,
                    "avg_ms": sum(vals) / len(vals),
                    "peak_ms": max(vals),
                }
            )

    for base_name, workers in groups.items():
        if len(workers) < 2:
            continue
        if base_name in _INFRA_PROCESS_NAMES:
            continue

        avgs = [w["avg_ms"] for w in workers]
        mean = sum(avgs) / len(avgs)
        if mean == 0:
            continue

        try:
            cv = _stats.stdev(avgs) / mean * 100
        except _stats.StatisticsError:
            # `stdev` needs two data points; `len(workers) < 2` is already skipped above, so this is
            # the belt to that braces. Narrow, because a TypeError here would be a real bug in the
            # `avgs` construction and should not be silently skipped.
            continue

        max_avg = max(avgs)
        min_avg = min(avgs)
        ratio = max_avg / min_avg if min_avg > 0 else float("inf")
        total = sum(avgs)

        workers_sorted = sorted(workers, key=lambda w: w["avg_ms"], reverse=True)
        top3_share = sum(w["avg_ms"] for w in workers_sorted[:3]) / total * 100 if total else 0

        if cv > 50 or ratio > 3.0:
            active = sum(1 for w in workers if w["avg_ms"] > mean * 0.5)
            severity = "high" if cv > 80 or ratio > 6 else "medium"

            return {
                "pattern": "worker_load_imbalance",
                "severity": severity,
                "confidence": "high",
                "unanchored": True,
                "anchor_note": (
                    "UNANCHORED. processes.rs has no rules, so no aperf finding reports per-worker "
                    "load. The CV below is computed here from raw process data. Two known biases: "
                    "only the top 16 processes by CPU are retained, which BIASES CV DOWNWARD, and "
                    "user_space_time drops its first sample, putting it off-by-one against iowait."
                ),
                "evidence": {
                    "process_group": base_name,
                    "worker_count": len(workers),
                    "actively_loaded_workers": active,
                    "max_avg_ms": round(max_avg, 1),
                    "min_avg_ms": round(min_avg, 1),
                    "mean_avg_ms": round(mean, 1),
                    "max_min_ratio": round(ratio, 1),
                    "coefficient_of_variation_pct": round(cv, 0),
                    "top3_load_share_pct": round(top3_share, 1),
                    "workers": workers_sorted,
                },
                "diagnosis": (
                    f"{len(workers)} {base_name} workers detected but load is uneven: "
                    f"top worker averages {max_avg:.1f}ms vs {min_avg:.1f}ms for the quietest "
                    f"({ratio:.1f}x ratio, CV={cv:.0f}%). "
                    f"Top 3 workers handle {top3_share:.0f}% of all work. "
                    f"This is consistent with accept() bias on a shared listen socket, "
                    f"source-IP session affinity, or a sticky load balancer routing repeat "
                    f"clients to the same backend."
                ),
                # Language-specific advice only when `base_name` matches a known language's
                # process-name signature (same table `language_detector.py` uses); otherwise
                # only the generic, runtime-agnostic OS/LB-level advice applies — no guess at
                # a worker model this process name gives no evidence for.
                "resolution": (
                    _WORKER_RESOLUTION_BY_LANGUAGE.get(_match_worker_language(base_name), [])
                    + _GENERIC_WORKER_RESOLUTION
                ),
            }

    return None


async def config_diagnosis_handler(arguments: dict[str, Any]) -> str:
    """Detect configuration errors from aperf data."""
    run_name = arguments["run_name"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))

    # `expected_workers` and `load_balancer_type` are declared in `inputSchema` above but nothing
    # here consumes them: the worker-imbalance detector derives the worker count from the process
    # data itself, and no branch narrows on the load-balancer type. They were read into locals and
    # dropped, which reads as "supported" to a caller and to ruff as two dead assignments. Left
    # advertised deliberately — the schema is the public interface and removing a documented input
    # is a breaking change — but no longer pretending to be read. Echoed back so a caller can at
    # least see what the tool received.
    echoed_inputs = {
        "expected_workers": arguments.get("expected_workers"),
        "load_balancer_type": arguments.get("load_balancer_type", "unknown"),
    }

    from pathlib import Path

    from ..parsers.cpu_parser import CpuUtilizationParser
    from ..parsers.run_parser import AperfRunParser

    parser = AperfRunParser(base_dir=data_dir)
    report_data = parser.get_report_data(Path(data_dir) / run_name)

    findings = []

    if not report_data:
        # Reference listing, not a diagnosis. Each pattern carries its anchor so a reader
        # can tell which ones aperf can actually evidence — eight of eleven cannot, because
        # the data types they need carry no rules.
        return json.dumps(
            {
                "status": "partial",
                "message": (
                    "No report data available. Returning all known patterns for MANUAL matching. "
                    "None of these is a detection: nothing was measured. Check `anchor` on each — "
                    "patterns with an empty `aperf_rules` have no finding that can evidence them."
                ),
                "known_patterns": [
                    {
                        "id": p["id"],
                        "name": p["name"],
                        "description": p["description"],
                        "symptoms": p["symptoms_in_aperf"],
                        "resolution": p["resolution"],
                        "severity": p["severity"],
                        "anchor": p.get("anchor", {}),
                        "unanchored": not p.get("anchor", {}).get("aperf_rules"),
                    }
                    for p in CONFIG_PATTERNS
                ],
            },
            indent=2,
        )

    # Analyze process distribution for worker imbalance
    processes = report_data.get("processes", {})
    if processes:
        worker_imbalance = _detect_worker_imbalance(processes)
        if worker_imbalance:
            findings.append(worker_imbalance)

    # Analyze CPU patterns for periodic GC dips
    cpu_data = report_data.get("cpu_utilization", {})
    if cpu_data and "aggregate" in cpu_data:
        idle_series = cpu_data["aggregate"].get("idle", [])
        if idle_series and len(idle_series) > 10:
            # Look for periodic spikes in idle (= CPU dips)
            avg_idle = sum(idle_series) / len(idle_series)
            dip_count = sum(1 for x in idle_series if x > avg_idle + 30)
            if dip_count >= 3:
                findings.append(
                    {
                        "pattern": "gc_overprovisioned_heap",
                        "confidence": "low",
                        "unanchored": True,
                        "anchor_note": (
                            "UNANCHORED, and the name overstates it. aperf has NO GC rule of any "
                            "kind, so nothing here establishes that the dips are GC. The identical "
                            "pattern is produced by any bursty workload, an I/O block, or a "
                            "throttled container. Confidence lowered from medium to low, and the GC "
                            "resolutions must be read as one hypothesis among several."
                        ),
                        "evidence": {
                            "cpu_dip_count": dip_count,
                            "avg_idle_pct": avg_idle,
                            "dip_threshold": avg_idle + 30,
                        },
                        "diagnosis": (
                            f"Detected {dip_count} periodic CPU utilization dips exceeding 30% "
                            "below average. Pattern consistent with stop-the-world GC pauses."
                        ),
                        "resolution": next(
                            p["resolution"]
                            for p in CONFIG_PATTERNS
                            if p["id"] == "gc_overprovisioned_heap"
                        ),
                    }
                )

    # Check for low CPU + high system time (connection pool exhaustion)
    cpu_parser = CpuUtilizationParser()
    cpu_summary = cpu_parser.parse_from_report_data(report_data)
    if cpu_summary and (
        cpu_summary.avg_total_utilization_pct < 50
        and cpu_summary.avg_system_pct > 15
        and cpu_summary.avg_iowait_pct < 5
    ):
        findings.append(
            {
                "pattern": "connection_pool_exhaustion",
                "confidence": "medium",
                "anchor_note": (
                    "PARTIAL ANCHOR: Underutilized CPU can serve as an entry condition, but it is "
                    "computed on the AGGREGATE series so it cannot separate a pool bottleneck from "
                    "an idle machine or an I/O block. aperf has no system-time threshold rule, so "
                    "the system_time component of this gate is unanchored."
                ),
                "evidence": {
                    "avg_cpu_pct": cpu_summary.avg_total_utilization_pct,
                    "system_time_pct": cpu_summary.avg_system_pct,
                    "iowait_pct": cpu_summary.avg_iowait_pct,
                },
                "diagnosis": (
                    f"Low CPU utilization ({cpu_summary.avg_total_utilization_pct:.0f}%) with "
                    f"elevated system time ({cpu_summary.avg_system_pct:.0f}%) and minimal I/O wait. "
                    "Threads are likely blocked on synchronization (connection pool, locks, or "
                    "external service calls)."
                ),
                "resolution": next(
                    p["resolution"]
                    for p in CONFIG_PATTERNS
                    if p["id"] == "connection_pool_exhaustion"
                ),
            }
        )

    # -----------------------------------------------------------------------
    # Dirty page writeback burst detection
    # nr_dirty sits well below the dirty_ratio threshold, so that threshold never fires;
    # dirty_expire_centisecs=3000 fires every 30s instead and flushes everything at once,
    # producing an iowait spike for 1-2 seconds at many times the normal write rate.
    # -----------------------------------------------------------------------
    vmstat = report_data.get("vmstat", {})
    nr_dirty_series: list[float] = []
    pgpgout_series: list[float] = []
    for rdata in vmstat.get("runs", {}).values():
        for metric, mdata in rdata.get("metrics", {}).items():
            if metric == "nr_dirty":
                nr_dirty_series = mdata.get("series", [{}])[0].get("values", [])
            elif metric == "pgpgout":
                pgpgout_series = mdata.get("series", [{}])[0].get("values", [])

    if nr_dirty_series and pgpgout_series and len(nr_dirty_series) > 5:
        avg_dirty_pages = sum(nr_dirty_series) / len(nr_dirty_series)
        avg_dirty_mb = round(avg_dirty_pages * 4 / 1024, 1)

        # Detect burst: pgpgout spikes >20x average in any single interval.
        avg_pgpgout = sum(pgpgout_series) / max(len(pgpgout_series), 1)
        burst_seconds = [
            (i, v)
            for i, v in enumerate(pgpgout_series)
            if avg_pgpgout > 0 and v > avg_pgpgout * 20 and v > 50000
        ]

        if burst_seconds:
            burst_t, burst_v = burst_seconds[0]
            # Correlate with iowait at that interval, if the series reaches that far.
            iowait_at_burst = 0.0
            for rdata in report_data.get("cpu_utilization", {}).get("runs", {}).values():
                for s in rdata.get("metrics", {}).get("iowait", {}).get("series", []):
                    if s.get("is_aggregate"):
                        vals = s.get("values", [])
                        if burst_t < len(vals):
                            iowait_at_burst = vals[burst_t]

            findings.append(
                {
                    "pattern": "dirty_page_writeback_burst",
                    "severity": "medium",
                    "confidence": "medium",
                    "unanchored": True,
                    "anchor_note": (
                        "UNANCHORED. Verified: no aperf rule reads pgpgout or nr_dirty — the four "
                        "vmstat rules cover only pgmajfault, pgminorfault and pgfault. The pgpgout "
                        "burst below is computed here from raw data. Severity and confidence "
                        "lowered from high, since no finding corroborates it."
                    ),
                    "evidence": {
                        "avg_dirty_mb": avg_dirty_mb,
                        "burst_second": burst_t,
                        "burst_pgpgout": burst_v,
                        "avg_pgpgout": round(avg_pgpgout, 1),
                        "burst_ratio": round(burst_v / max(avg_pgpgout, 1), 0),
                        "iowait_at_burst_pct": round(iowait_at_burst, 2),
                    },
                    "diagnosis": (
                        f"Dirty page writeback burst detected at t+{burst_t}s: "
                        f"{burst_v:,.0f} sectors/s written ({round(burst_v / avg_pgpgout, 0):.0f}x "
                        f"baseline of {avg_pgpgout:.0f}). "
                        f"iowait at burst second: {iowait_at_burst:.1f}%. "
                        f"Average dirty pages: {avg_dirty_mb}MB. "
                        "Root cause: vm.dirty_expire_centisecs=3000 (30s) fires and flushes all "
                        "aged dirty pages at once rather than continuously. "
                        "The dirty_ratio threshold is never reached because the expiry timer "
                        "fires first. This causes periodic 1-2 second iowait spikes that appear "
                        "as latency outliers in the application."
                    ),
                    "resolution": [
                        "# Smooth continuous flushing — apply via DaemonSet initContainer",
                        "sysctl -w vm.dirty_background_ratio=1    # flush at 1% of RAM, not 10%",
                        "sysctl -w vm.dirty_expire_centisecs=500   # expire pages in 5s not 30s",
                        "sysctl -w vm.dirty_writeback_centisecs=200 # writeback thread every 2s",
                        "sysctl -w vm.dirty_ratio=10               # hard limit at 10%",
                        "",
                        "# Also check fluent-bit disk buffering as a source of dirty pages:",
                        "# grep -i storage /fluent-bit/etc/fluent-bit.conf",
                        "# If storage.type=filesystem, change to storage.type=memory",
                        "",
                        "# For pods with log-heavy workloads, mount log staging on tmpfs:",
                        "# volumes: [{name: log-staging, emptyDir: {medium: Memory}}]",
                    ],
                    "field_case": (
                        "Observed on a production EKS workload: storage-optimized NVMe instance, "
                        "Python 3.12/Gunicorn. Fluent-bit disk buffering generated "
                        "574MB of dirty pages continuously. dirty_expire_centisecs=3000 caused "
                        "20% iowait for 1 second every 30 seconds. "
                        "Fix: dirty_background_ratio=1 + dirty_expire_centisecs=500 eliminated "
                        "the burst entirely by converting to continuous sub-1% iowait."
                    ),
                }
            )

    result = {
        "status": "success",
        "run_name": run_name,
        "findings_count": len(findings),
        "findings": findings,
        "inputs_not_used": echoed_inputs,
    }

    if not findings:
        result["message"] = (
            "No obvious configuration anti-patterns detected from available data. "
            "This doesn't mean config is optimal — just that known patterns weren't matched. "
            "Use get_run_summary and get_language_advisory for deeper analysis."
        )

    return json.dumps(result, indent=2, default=str)
