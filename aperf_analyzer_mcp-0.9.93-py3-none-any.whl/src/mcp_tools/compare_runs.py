# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: compare_runs

Side-by-side comparison of multiple aperf runs with delta analysis.
This is where aperf + AI really shines — automated regression detection
across complex multi-dimensional performance data.
"""

import json
import os
from typing import Any

from mcp.types import Tool

from ..parsers.cpu_parser import CpuUtilizationParser
from ..parsers.pmu_parser import PmuParser
from ..parsers.run_parser import AperfRunParser, RunData

COMPARE_RUNS_TOOL = Tool(
    name="compare_runs",
    description=(
        "Compare two or more aperf runs side-by-side. "
        "The first run is treated as the baseline. "
        "Returns deltas for all key metrics with improvement/regression indicators. "
        "Ideal for: before/after tuning, cross-instance comparison, "
        "kernel version comparison, JVM flag evaluation."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "baseline_run": {
                "type": "string",
                "description": "Name of the baseline (reference) run",
            },
            "candidate_runs": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Names of runs to compare against the baseline",
            },
            "data_dir": {
                "type": "string",
                "description": "Base directory containing aperf runs",
            },
            "report_dir": {
                "type": "string",
                "description": (
                    "Optional: a single aperf report directory (relative to data_dir) that "
                    "contains all the named runs, as produced by `aperf report -r a -r b`. "
                    "Without it, each run name must be its own directory under data_dir. "
                    "Use list_runs to see which runs a report holds."
                ),
            },
            "focus_areas": {
                "type": "array",
                "items": {
                    "type": "string",
                    "enum": ["cpu", "pmu", "memory", "interrupts", "disk", "all"],
                },
                "description": "Which metric areas to focus comparison on (default: all)",
            },
        },
        "required": ["baseline_run", "candidate_runs"],
    },
)


async def compare_runs_handler(arguments: dict[str, Any]) -> str:
    """Compare aperf runs and produce delta analysis."""
    baseline_name = arguments["baseline_run"]
    candidate_names = arguments["candidate_runs"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    focus = arguments.get("focus_areas", ["all"])

    parser = AperfRunParser(base_dir=data_dir)
    from pathlib import Path

    # A single report can hold both runs — `aperf report -r a -r b` is how aperf itself compares —
    # so a name may be either a directory under `data_dir` or a run inside `report_dir`. Without
    # this, the tool could only compare runs that had each been reported separately, which is not
    # how anyone using aperf's own comparison workflow has their data laid out.
    report_dir = arguments.get("report_dir")
    shared_report = Path(data_dir) / report_dir if report_dir else None

    def load_report(name: str) -> dict[str, Any] | None:
        if shared_report is not None:
            return parser.get_report_data(shared_report, run_key=name)
        return parser.get_report_data(Path(data_dir) / name)

    # Parse baseline
    baseline_data = parser.parse_run(baseline_name)
    if not baseline_data and shared_report is None:
        return json.dumps(
            {"status": "error", "message": f"Baseline run '{baseline_name}' not found"}
        )

    baseline_report = load_report(baseline_name)
    if baseline_report and baseline_report.get("_run_key_warning"):
        return json.dumps(
            {
                "status": "error",
                "message": baseline_report["_run_key_warning"],
                "runs_in_report": baseline_report.get("_runs_in_report", []),
            },
            indent=2,
        )

    comparisons = []
    for candidate_name in candidate_names:
        candidate_data = parser.parse_run(candidate_name)
        if not candidate_data and shared_report is None:
            comparisons.append(
                {
                    "candidate": candidate_name,
                    "status": "error",
                    "message": f"Run '{candidate_name}' not found",
                }
            )
            continue

        candidate_report = load_report(candidate_name)
        if candidate_report and candidate_report.get("_run_key_warning"):
            comparisons.append(
                {
                    "candidate": candidate_name,
                    "status": "error",
                    "message": candidate_report["_run_key_warning"],
                    "runs_in_report": candidate_report.get("_runs_in_report", []),
                }
            )
            continue

        # With `report_dir`, the runs live inside one report and have no directory of their own,
        # so there is no per-run metadata to diff.
        def meta(run_data: RunData | None, attr: str) -> Any:
            return getattr(run_data.metadata, attr) if run_data else None

        comparison = {
            "candidate": candidate_name,
            "status": "success",
            "metadata_diff": {
                "baseline_instance": meta(baseline_data, "instance_type"),
                "candidate_instance": meta(candidate_data, "instance_type"),
                "baseline_arch": meta(baseline_data, "architecture"),
                "candidate_arch": meta(candidate_data, "architecture"),
                "baseline_kernel": meta(baseline_data, "kernel_version"),
                "candidate_kernel": meta(candidate_data, "kernel_version"),
            },
            "deltas": {},
            "regressions": [],
            "improvements": [],
        }
        if shared_report is not None:
            comparison["source"] = f"both runs read from the report at {report_dir}"

        if baseline_report and candidate_report:
            # PMU comparison
            if "all" in focus or "pmu" in focus:
                pmu_parser = PmuParser()
                baseline_pmu = pmu_parser.parse_from_report_data(baseline_report)
                candidate_pmu = pmu_parser.parse_from_report_data(candidate_report)

                if baseline_pmu and candidate_pmu:
                    pmu_deltas = pmu_parser.compare(baseline_pmu, candidate_pmu)
                    comparison["deltas"]["pmu"] = pmu_deltas

                    for metric, delta in pmu_deltas.items():
                        # Skip what was never measured. Without this, a metric absent from the
                        # platform's pmu_config counted as neither improvement nor regression and
                        # so fed the `NO_SIGNIFICANT_CHANGE` verdict — a claim of no change made
                        # about data that was never read.
                        if not delta.get("available"):
                            comparison.setdefault("pmu_metrics_unavailable", []).append(metric)
                            continue
                        change = delta.get("change_pct")
                        if change is None:
                            continue
                        # A sub-threshold improvement is noise in the same way a sub-threshold
                        # regression is; the old code accepted any improvement however small.
                        if abs(change) <= 5:
                            continue
                        if delta.get("improved"):
                            comparison["improvements"].append(
                                f"{metric}: {abs(change):.1f}% improvement"
                            )
                        else:
                            comparison["regressions"].append(f"{metric}: {change:.1f}% regression")

            # CPU comparison
            if "all" in focus or "cpu" in focus:
                cpu_parser = CpuUtilizationParser()
                baseline_cpu = cpu_parser.parse_from_report_data(baseline_report)
                candidate_cpu = cpu_parser.parse_from_report_data(candidate_report)

                if baseline_cpu and candidate_cpu:
                    comparison["deltas"]["cpu"] = {
                        "utilization": {
                            "baseline": baseline_cpu.avg_total_utilization_pct,
                            "candidate": candidate_cpu.avg_total_utilization_pct,
                        },
                        "iowait": {
                            "baseline": baseline_cpu.avg_iowait_pct,
                            "candidate": candidate_cpu.avg_iowait_pct,
                        },
                        "system_time": {
                            "baseline": baseline_cpu.avg_system_pct,
                            "candidate": candidate_cpu.avg_system_pct,
                        },
                    }

                    # `iowait`/`system_time` feed `improvements`/`regressions` the same way
                    # PMU deltas already do (`PmuParser.compare`'s `lower_is_better` pattern),
                    # using the same >5% significance threshold. A real 0.61% -> 0.10% iowait
                    # drop used to be invisible to the verdict entirely — only PMU deltas were
                    # ever classified, so a genuine I/O-wait improvement between two runs
                    # produced `NO_SIGNIFICANT_CHANGE`. `utilization` is deliberately excluded:
                    # higher CPU utilization is not itself an improvement or a regression —
                    # it can mean "doing more real work" or "closer to saturation" — so
                    # classifying it either way would be a guess this data cannot support.
                    for label, old, new in (
                        ("iowait", baseline_cpu.avg_iowait_pct, candidate_cpu.avg_iowait_pct),
                        ("system_time", baseline_cpu.avg_system_pct, candidate_cpu.avg_system_pct),
                    ):
                        if old == 0:
                            continue
                        change_pct = ((new - old) / old) * 100
                        if abs(change_pct) <= 5:
                            continue
                        if new < old:
                            comparison["improvements"].append(
                                f"cpu.{label}: {abs(change_pct):.1f}% improvement"
                            )
                        else:
                            comparison["regressions"].append(
                                f"cpu.{label}: {change_pct:.1f}% regression"
                            )

        # Summary verdict
        n_improvements = len(comparison["improvements"])
        n_regressions = len(comparison["regressions"])
        if not comparison["deltas"]:
            # Nothing was compared, so nothing can be concluded. `NO_SIGNIFICANT_CHANGE` here read
            # as a clean bill of health for two runs whose data had not been read — the most
            # misleading output this tool could produce.
            comparison["verdict"] = "INSUFFICIENT_DATA"
            comparison["message"] = (
                "No metrics could be compared. Both runs need `aperf report` output — a raw "
                "`aperf record` directory holds bincode `.bin` files that nothing here decodes."
            )
        elif n_regressions == 0 and n_improvements > 0:
            comparison["verdict"] = "IMPROVED"
        elif n_regressions > n_improvements:
            comparison["verdict"] = "REGRESSED"
        elif n_regressions > 0:
            comparison["verdict"] = "MIXED"
        else:
            comparison["verdict"] = "NO_SIGNIFICANT_CHANGE"

        comparisons.append(comparison)

    return json.dumps(
        {
            "status": "success",
            "baseline": baseline_name,
            "comparisons": comparisons,
        },
        indent=2,
        default=str,
    )
