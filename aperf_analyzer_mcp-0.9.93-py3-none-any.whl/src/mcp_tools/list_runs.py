# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: list_runs

Lists all available aperf runs with basic metadata.
"""

import json
import os
from typing import Any

from mcp.types import Tool

from ..parsers.run_parser import AperfRunParser

LIST_RUNS_TOOL = Tool(
    name="list_runs",
    description=(
        "List all available aperf performance recording runs. "
        "Returns run names, timestamps, instance types, duration, and available data collectors. "
        "Use this to discover what data is available before diving deeper."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "data_dir": {
                "type": "string",
                "description": "Base directory containing aperf runs. Defaults to ./aperf_data",
            },
            "filter_instance_type": {
                "type": "string",
                "description": "Optional: filter runs by EC2 instance type (e.g., 'c7g.16xlarge')",
            },
        },
        "required": [],
    },
)


async def list_runs_handler(arguments: dict[str, Any]) -> str:
    """Handle list_runs tool calls."""
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    filter_instance = arguments.get("filter_instance_type")

    parser = AperfRunParser(base_dir=data_dir)
    runs = parser.discover_runs()

    if filter_instance:
        runs = [r for r in runs if r.instance_type and filter_instance in r.instance_type]

    if not runs:
        return json.dumps(
            {
                "status": "no_runs_found",
                "message": f"No aperf runs found in {data_dir}. "
                "Ensure the directory contains aperf recording outputs.",
                "data_dir": data_dir,
            },
            indent=2,
        )

    results = []
    for run in runs:
        results.append(
            {
                "run_name": run.run_name,
                "timestamp": run.timestamp,
                "instance_type": run.instance_type,
                "architecture": run.architecture,
                "cpu_count": run.cpu_count,
                "duration_seconds": run.duration_seconds,
                "interval_seconds": run.interval_seconds,
                "num_intervals": run.num_intervals,
                "collectors": run.collectors_available,
                "has_profile": run.has_profile,
                "has_java_profile": run.has_java_profile,
                "has_hotline": run.has_hotline,
                # Which aperf produced the run. The guidance in `analyze_findings` is pinned to one
                # aperf commit, so this is what tells a caller whether the two agree.
                "aperf_version": run.collector_version,
                "aperf_commit": run.collector_commit_sha,
            }
        )

    return json.dumps(
        {
            "status": "success",
            "count": len(results),
            "runs": results,
        },
        indent=2,
    )
