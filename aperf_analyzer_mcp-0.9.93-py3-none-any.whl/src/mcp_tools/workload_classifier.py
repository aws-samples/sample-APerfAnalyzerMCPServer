# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Workload classification for right-sizing.

Answers two separate questions that the previous implementation conflated:

  1. Is this workload CPU-bound, memory-bound, or balanced?
  2. How much PRESSURE is on each dimension, and how much do we trust that?

Both matter. "memory-bound at low pressure" and "memory-bound at high pressure" lead to
opposite recommendations — the first can shrink, the second must not.

Three defects in the previous classifier this one exists to avoid
-----------------------------------------------------------------
**Absent PMU was read as zero.** `recommendation_engine.classify_workload` gates on
`backend_stalls > 40 or dtlb_misses >= 2.0`. When the perf_stat collector did not run,
both read `0.0` and the workload was silently labelled "balanced" — a confident answer
built on no measurement. Here, a missing metric yields `UNKNOWN` and lowers confidence.

**`backend_stall_pct` is not vendor-comparable.** `PmuSummary.stall_denominator` records
that aperf normalises the backend term over issue slots on Intel ICL/SPR and slot-scales
it on AMD Genoa. A bare `> 40` therefore compares different quantities across exactly
the architectures a right-sizing decision has to weigh. This module uses the
backend/frontend RATIO, which is what aperf's own rule computes and is vendor-stable.

**Memory was never consulted at all.** `build_recommendations` accepts a `memory` dict
and reads nothing from it, so family selection could never reflect memory behaviour.

Capacity and bandwidth are tracked separately on purpose: a box can be 95% full and
completely unstressed on bandwidth, or half empty and bandwidth-bound. They call for
different instances.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..thresholds import (
    BACKEND_DOMINANCE_HIGH,
    BACKEND_DOMINANCE_MODERATE,
    CPU_PRESSURE_HIGH_PCT,
    CPU_PRESSURE_MODERATE_PCT,
    L3_MPKI_HIGH,
    L3_MPKI_MODERATE,
    MEMORY_CAPACITY_HIGH_PCT,
    MEMORY_CAPACITY_MODERATE_PCT,
    MIN_SAMPLES_FOR_SIZING,
)


class Pressure(str, Enum):
    NONE = "none"
    MODERATE = "moderate"
    HIGH = "high"
    UNKNOWN = "unknown"


class Classification(str, Enum):
    CPU_BOUND = "cpu-bound"
    MEMORY_BOUND = "memory-bound"
    BALANCED = "balanced"
    UNDETERMINED = "undetermined"


class Confidence(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass
class WorkloadProfile:
    """What we know about the workload, and what we do not."""

    classification: Classification
    cpu_pressure: Pressure
    memory_bandwidth_pressure: Pressure
    memory_capacity_pressure: Pressure
    confidence: Confidence
    #: Metrics that drove the verdict, phrased for an engineer reading an audit trail.
    evidence: list[str] = field(default_factory=list)
    #: Signals that were NOT available. Load-bearing: this is what stops a confident
    #: answer being built on absent data.
    gaps: list[str] = field(default_factory=list)
    #: Observed values the sizer needs, so it does not re-derive them.
    peak_cpu_pct: float | None = None
    peak_memory_pct: float | None = None

    @property
    def sizeable(self) -> bool:
        """
        Whether there is enough signal to propose a change at all.

        CPU pressure is the floor: without it there is no basis for any proposal, because
        every candidate comparison starts from observed CPU demand.
        """
        return self.cpu_pressure is not Pressure.UNKNOWN


def _band(value: float, high: float, moderate: float) -> Pressure:
    if value >= high:
        return Pressure.HIGH
    if value >= moderate:
        return Pressure.MODERATE
    return Pressure.NONE


def _has(pmu: Any, metric: str) -> bool:
    """
    Whether a PMU metric was actually collected.

    `PmuSummary.metrics_available` is the only way to tell a measured 0.0 from a metric
    the platform never reported — PMU counters are frequently unavailable in VMs and
    containers, and `perf_stat` may not have run at all.
    """
    available = getattr(pmu, "metrics_available", None)
    if not available:
        return False
    return metric in available


def classify(
    cpu_summary: Any = None,
    pmu_summary: Any = None,
    mem_summary: Any = None,
    aperf_findings: Any = None,
) -> WorkloadProfile:
    """
    Build a `WorkloadProfile` from the parser summaries.

    `aperf_findings` is accepted so a caller can pass the findings aperf itself emitted;
    when present they corroborate the metric bands and are cited in `evidence`.
    """
    evidence: list[str] = []
    gaps: list[str] = []

    fired: set[str] = set()
    if aperf_findings is not None:
        items = getattr(aperf_findings, "findings", aperf_findings)
        for item in items or ():
            name = getattr(item, "rule_name", item)
            if isinstance(name, str):
                fired.add(name)

    # ---------------- CPU pressure ----------------
    peak_cpu: float | None = None
    if cpu_summary is not None:
        peak_cpu = getattr(cpu_summary, "peak_utilization_pct", None)
        if not peak_cpu:
            peak_cpu = getattr(cpu_summary, "avg_total_utilization_pct", None)
            if peak_cpu:
                gaps.append("no peak CPU sample; using the average, which understates bursts")

    if peak_cpu is None:
        cpu_pressure = Pressure.UNKNOWN
        gaps.append("CPU utilisation not collected — cannot size without it")
    else:
        cpu_pressure = _band(peak_cpu, CPU_PRESSURE_HIGH_PCT, CPU_PRESSURE_MODERATE_PCT)
        evidence.append(f"peak CPU utilisation {peak_cpu:.1f}%")
        if "Underutilized CPU" in fired:
            evidence.append("aperf finding: Underutilized CPU")

    # The aggregate series hides per-core saturation: one hot core on 64 vCPU reads as
    # ~98% idle. A shrink recommendation from an aggregate figure can therefore remove
    # the very core that is saturated.
    imbalance = getattr(cpu_summary, "cpu_imbalance_pct", 0.0) or 0.0
    if imbalance > 30.0:
        gaps.append(
            f"per-core imbalance {imbalance:.0f}% — the aggregate figure understates "
            "load on the busiest core"
        )

    # ---------------- memory bandwidth pressure ----------------
    # Prefer the backend/frontend ratio over the absolute backend percentage; see the
    # module docstring for why the absolute value is not vendor-comparable.
    bandwidth_pressure = Pressure.UNKNOWN
    if pmu_summary is None:
        gaps.append("no PMU data — memory-bandwidth pressure is unknown, not zero")
    else:
        signals: list[Pressure] = []

        be = getattr(pmu_summary, "stall_backend_pkc", 0.0) or 0.0
        fe = getattr(pmu_summary, "stall_frontend_pkc", 0.0) or 0.0
        if _has(pmu_summary, "stall-backend-pkc") and fe > 0:
            ratio = be / fe
            band = _band(ratio, BACKEND_DOMINANCE_HIGH, BACKEND_DOMINANCE_MODERATE)
            signals.append(band)
            # Only cite it when it indicates something. A ratio below the margin means
            # the backend is NOT dominant, which is the absence of a finding rather than
            # evidence of one.
            if band is not Pressure.NONE:
                evidence.append(f"backend/frontend stall ratio {ratio:.2f}")
        elif not _has(pmu_summary, "stall-backend-pkc"):
            gaps.append("stall counters not collected on this platform")

        if _has(pmu_summary, "l3-mpki"):
            l3 = getattr(pmu_summary, "l3_mpki", 0.0) or 0.0
            band = _band(l3, L3_MPKI_HIGH, L3_MPKI_MODERATE)
            signals.append(band)
            if band is not Pressure.NONE:
                evidence.append(f"L3 misses {l3:.1f}/1K instructions")
        else:
            gaps.append("L3 miss rate not collected")

        if "Backend-Dominated CPU Stalls" in fired:
            evidence.append("aperf finding: Backend-Dominated CPU Stalls")
            signals.append(Pressure.MODERATE)
        if "High L3 Cache Misses" in fired:
            evidence.append("aperf finding: High L3 Cache Misses")
            signals.append(Pressure.MODERATE)

        if signals:
            # Worst signal wins: bandwidth starvation on any axis is real starvation.
            bandwidth_pressure = (
                Pressure.HIGH
                if Pressure.HIGH in signals
                else Pressure.MODERATE
                if Pressure.MODERATE in signals
                else Pressure.NONE
            )

    # ---------------- memory capacity pressure ----------------
    peak_mem: float | None = None
    capacity_pressure = Pressure.UNKNOWN
    if mem_summary is None:
        gaps.append("no memory data — capacity pressure is unknown")
    else:
        peak_mem = getattr(mem_summary, "peak_used_pct", None)
        samples = getattr(mem_summary, "samples", 0) or 0
        if peak_mem is None:
            gaps.append("memory utilisation not collected")
        else:
            capacity_pressure = _band(
                peak_mem, MEMORY_CAPACITY_HIGH_PCT, MEMORY_CAPACITY_MODERATE_PCT
            )
            evidence.append(f"peak memory used {peak_mem:.1f}%")

            # A raw `aperf record` directory yields a single memory sample, so
            # `is_flat_line` is always False and variance always 0.0 there. Trusting a
            # one-sample peak as the workload's true high-water mark is the mistake.
            if samples < MIN_SAMPLES_FOR_SIZING:
                gaps.append(
                    f"only {samples} memory sample(s) — the peak may not reflect the "
                    "workload's real high-water mark"
                )

        swap = getattr(mem_summary, "swap_used_mb", 0.0) or 0.0
        if swap > 100:
            capacity_pressure = Pressure.HIGH
            evidence.append(f"{swap:.0f} MB of swap in use")
        if "Major Page Faults Detected" in fired:
            evidence.append("aperf finding: Major Page Faults Detected")

    # ---------------- classification ----------------
    memory_pressure_max = max(
        (bandwidth_pressure, capacity_pressure),
        key=lambda p: ("unknown", "none", "moderate", "high").index(p.value),
    )

    if cpu_pressure is Pressure.UNKNOWN and memory_pressure_max is Pressure.UNKNOWN:
        classification = Classification.UNDETERMINED
    elif memory_pressure_max is Pressure.HIGH and cpu_pressure is not Pressure.HIGH:
        classification = Classification.MEMORY_BOUND
    elif cpu_pressure is Pressure.HIGH and memory_pressure_max is not Pressure.HIGH:
        classification = Classification.CPU_BOUND
    elif Pressure.UNKNOWN in (cpu_pressure, bandwidth_pressure):
        # One dimension measured, the other absent: name the measured one but do not
        # claim balance, which would assert something about the dimension we cannot see.
        classification = (
            Classification.CPU_BOUND
            if cpu_pressure in (Pressure.HIGH, Pressure.MODERATE)
            else Classification.UNDETERMINED
        )
    else:
        classification = Classification.BALANCED

    # ---------------- confidence ----------------
    unknowns = sum(
        1 for p in (cpu_pressure, bandwidth_pressure, capacity_pressure) if p is Pressure.UNKNOWN
    )
    if unknowns == 0 and not gaps:
        confidence = Confidence.HIGH
    elif unknowns >= 2:
        confidence = Confidence.LOW
    else:
        confidence = Confidence.MEDIUM

    return WorkloadProfile(
        classification=classification,
        cpu_pressure=cpu_pressure,
        memory_bandwidth_pressure=bandwidth_pressure,
        memory_capacity_pressure=capacity_pressure,
        confidence=confidence,
        evidence=evidence,
        gaps=gaps,
        peak_cpu_pct=peak_cpu,
        peak_memory_pct=peak_mem,
    )
