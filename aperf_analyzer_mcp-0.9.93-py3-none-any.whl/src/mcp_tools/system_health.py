# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: get_system_health

Quick system health check — is the system properly configured for performance?
"""

import json
import os
from typing import Any

from mcp.types import Tool

SYSTEM_HEALTH_TOOL = Tool(
    name="get_system_health",
    description=(
        "Quick system health assessment from aperf run data. "
        "Checks kernel parameters, sysctl settings, NUMA configuration, "
        "and common performance anti-patterns. "
        "Returns pass/fail for each check with remediation guidance."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "data_dir": {"type": "string"},
        },
        "required": ["run_name"],
    },
)


async def system_health_handler(arguments: dict[str, Any]) -> str:
    """Perform system health checks."""
    run_name = arguments["run_name"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))

    from pathlib import Path

    from ..parsers.run_parser import AperfRunParser

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)

    if not run_data:
        return json.dumps({"status": "error", "message": f"Run '{run_name}' not found"})

    checks = []
    sysinfo = run_data.metadata.system_info

    # Transparent Huge Pages — REPORTED AS UNKNOWN, NOT CHECKED.
    #
    # aperf collects only the compile-time CONFIG_TRANSPARENT_HUGEPAGE flag; runtime state
    # at /sys/kernel/mm/transparent_hugepage/enabled is never collected, and no parser
    # populates `transparent_hugepages`. This previously read the absent field, so it
    # emitted a warning on 100% of runs — and it passed only on `always` while warning on
    # `madvise`, which is both the Amazon Linux 2023 default and what the playbook
    # recommends. It was flagging the setting the tool itself advises.
    thp_status = sysinfo.get("transparent_hugepages")
    checks.append(
        {
            "check": "transparent_huge_pages",
            "status": "unknown"
            if not thp_status
            else ("pass" if thp_status in ("madvise", "always") else "warning"),
            "current": thp_status or "not collected by aperf",
            "recommended": "madvise",
            "impact": "THP reduces TLB pressure for large-footprint apps",
            "why_unknown": (
                "aperf reads the compile-time CONFIG_TRANSPARENT_HUGEPAGE flag, not runtime state. "
                "A kernel compiled with THP support can still be set to 'never' at runtime, which "
                "this cannot see. Check it directly."
            ),
            "verify": "cat /sys/kernel/mm/transparent_hugepage/enabled",
            "anchored_advice": (
                "THP guidance is gated on measured TLB pressure — see the thp_and_tlb_pressure "
                "playbook rule, which anchors on aperf's Data/Instruction TLB findings."
            ),
        }
    )

    # perf_event_paranoid — a COLLECTION ENABLER, not a performance setting.
    #
    # Reported as informational only. It was previously read from `sysinfo`, where the key
    # does not exist, so it always reported the hardcoded default 2 as though measured.
    paranoid = sysinfo.get("perf_event_paranoid")
    checks.append(
        {
            "check": "perf_event_paranoid",
            "status": "unknown" if paranoid is None else ("pass" if paranoid <= 0 else "info"),
            "current": "not collected" if paranoid is None else paranoid,
            "recommended": "0 or lower, only while recording",
            "impact": (
                "This is a precondition for COLLECTING PMU data, not a performance fix. When "
                "perf_stat data is absent all 14 perf_stat rules are inert and their absence "
                "proves nothing."
            ),
            "caveat": (
                "Lowering it is a SECURITY RELAXATION — do not persist it; revert after recording. "
                "Missing PMU data has at least three confounded causes (paranoid level, "
                "virtualization, containerization), so verify which applies before changing it. "
                "Recording as root is usually preferable."
            ),
            "fix": "sudo sysctl -w kernel.perf_event_paranoid=0  # revert after recording",
        }
    )

    # CPU governor — DROPPED as a check.
    #
    # aperf collects no frequency data and no governor value, and IPC is frequency-invariant
    # so no finding can reveal a governor effect. This previously reported the hardcoded
    # default "unknown" as if measured, producing a permanent spurious warning.
    checks.append(
        {
            "check": "cpu_governor",
            "status": "not_applicable",
            "current": "not collected by aperf",
            "impact": (
                "No aperf finding can support governor advice: no frequency data is collected, and "
                "IPC does not vary with clock speed. On non-metal instance types the setting is "
                "typically a no-op anyway."
            ),
        }
    )

    # kernel.numa_balancing — anchored on the cache-miss findings, but SECONDARY.
    numa_balancing = sysinfo.get("numa_balancing", "unknown")
    checks.append(
        {
            "check": "numa_balancing",
            "status": "info",
            "current": numa_balancing,
            "anchor": "High L3 / L2 / L1 Data Cache Misses, Backend-Dominated CPU Stalls",
            "anchor_rules": [
                "High L1 Data Cache Misses",
                "High L2 Cache Misses",
                "High L3 Cache Misses",
                "Backend-Dominated CPU Stalls",
            ],
            "impact": "Trades auto-migration overhead against memory locality.",
            "check_first": (
                "MULTI-NODE INSTANCES ONLY. Confirm numastat other_node / numa_foreign are non-zero "
                "first — numastat.rs has NO rules, so that is evidence you compute, not a finding. "
                "Explicit pinning (numactl --cpubind/--membind or a cgroup cpuset) is the PRIMARY "
                "fix; this setting is secondary and should never be changed alone."
            ),
            "candidate_fix": "sudo sysctl -w kernel.numa_balancing=0",
            "risk": (
                "Bidirectional — disabling HELPS latency-sensitive workloads and can HURT batch and "
                "parallel ones. Pinning halves available bandwidth and memory capacity if sized "
                "wrong, and kubelet reverts cpusets it manages."
            ),
            "verify": "other_node decreasing AND stall-backend-pkc decreasing together",
        }
    )

    # vm.swappiness — anchored on Major Page Faults Detected, but DIRECTION-DEPENDENT.
    #
    # Status is `info`, not `warning`: a high swappiness is only a problem if major faults
    # are actually being measured, and even then only on the swap-in branch. pgmajfault has
    # two disjoint causes and lowering swappiness helps one while making the other WORSE.
    swappiness = sysinfo.get("vm_swappiness")
    checks.append(
        {
            "check": "vm_swappiness",
            "status": "unknown" if swappiness is None else "info",
            "current": "not collected" if swappiness is None else swappiness,
            "anchor": "Major Page Faults Detected (vmstat) — do not act without it",
            "anchor_rules": ["Major Page Faults Detected"],
            "impact": "Biases reclaim between evicting anonymous memory (swap) and file pages (page cache).",
            "check_first": (
                "MANDATORY. Check SwapTotal first — if 0, the swap branch is excluded outright and "
                "this setting is irrelevant (the usual case on EKS). Then check pswpin: with "
                "pswpin > 0 the workload's own memory is being read back from swap and lowering "
                "swappiness is the PRIMARY fix. With pswpin == 0 and reclaim active, the faults are "
                "page-cache thrash and lowering swappiness makes it WORSE, because it tells the "
                "kernel to reclaim exactly the file cache that is thrashing. aperf has NO pswpin "
                "rule, so this check is manual."
            ),
            "candidate_fix": "sudo sysctl -w vm.swappiness=10  # only when pswpin > 0",
            "risk": (
                "vm.swappiness=1 approaches disabling swap under pressure, which converts swap-in "
                "stalls into OOM KILLS. Effects are gradual, so verify with a fresh recording after "
                "reclaim settles rather than an immediate re-read."
            ),
        }
    )

    # vm.max_map_count — reported, not recommended. No anchor.
    max_map = sysinfo.get("vm_max_map_count") or sysinfo.get("vm.max_map_count")
    if max_map is not None:
        try:
            max_map = int(max_map)
        except (ValueError, TypeError):
            max_map = None
    if max_map is not None:
        checks.append(
            {
                "check": "vm_max_map_count",
                "status": "info",
                "current": max_map,
                "is_kernel_default": max_map == 65530,
                "unanchored": True,
                "impact": (
                    "No aperf finding covers this — no VMA count is collected. Exhausting the limit "
                    "surfaces as an ENOMEM application error, not as a performance signal, so this "
                    "is a correctness precondition rather than a tuning opportunity. 65530 is the "
                    "Amazon Linux 2023 default, so a fixed 'warning' here fires on every stock host."
                ),
            }
        )

    # Check: IRQ affinity
    # (Would parse from interrupt data in a full implementation)
    checks.append(
        {
            "check": "irq_affinity",
            "status": "info",
            "current": "Check interrupt distribution in run data",
            "anchor": "PPS Exceeded Instance Allowance (ena_stat) — secondarily Inbound Bandwidth Exceeded",
            "anchor_rules": [
                "PPS Exceeded Instance Allowance",
                "Inbound Bandwidth Exceeded Instance Allowance",
            ],
            "impact": (
                "Each packet costs a fixed CPU tax in the softirq receive path. When NIC queue IRQs "
                "concentrate on one CPU, NAPI polling falls behind and packets drop BELOW the "
                "nominal allowance. Spreading IRQs raises the achievable rate — it does not raise "
                "the allowance, which is a hardware ceiling."
            ),
            "check_first": (
                "Rank the cheaper primaries first: MTU/fragmentation, TSO/GSO/GRO/LRO offloads, "
                "batching. Then look at ENA suspected_poll_starvation, whose own aperf description "
                "names misconfigured interrupt affinity as a cause. Note: do NOT gate this on "
                "Underutilized CPU — that finding is computed on the aggregate series and is blind "
                "to the per-core saturation that matters here."
            ),
            "risk": (
                "R3, the same tier as an instance resize. A bad affinity map degrades throughput "
                "broadly. irqbalance SILENTLY REVERTS manual smp_affinity writes unless stopped or "
                "the IRQ is banned, and on large/Graviton instances spreading IRQs across NUMA nodes "
                "puts RX buffers on remote memory."
            ),
        }
    )
    # Check: tcp_keepalive_time (Kubernetes/EKS critical — dead connections linger)
    # Read from sysctl data if available
    # `run_path` is a str on RunMetadata; get_report_data does path arithmetic on it, so every
    # other caller wraps it. Without the wrap this raised TypeError on every single call.
    report_data = parser.get_report_data(Path(run_data.metadata.run_path))
    sysctl_data = {}
    if report_data and "sysctl" in report_data:
        sysctl_data = report_data["sysctl"]

    # tcp_keepalive_time — the one network setting with a real aperf anchor.
    #
    # Target corrected to <300s. aperf's own optimization guide says "configure TCP keep
    # alives to be sent at intervals of less than 5 minutes to ensure connections stay open
    # and maintain their tracked state". The previous 60s target and the stale-Kubernetes-
    # connection rationale were not anchored to anything aperf measures.
    keepalive_time = int(sysctl_data.get("net.ipv4.tcp_keepalive_time", 7200))
    checks.append(
        {
            "check": "tcp_keepalive_time",
            "status": "pass" if keepalive_time < 300 else "info",
            "current": f"{keepalive_time}s",
            "recommended": "< 300s, and only when Connection Tracking Exceeded Instance Allowance fired",
            "fix": "sudo sysctl -w net.ipv4.tcp_keepalive_time=240",
            "anchor": "Connection Tracking Exceeded Instance Allowance (ena_stat)",
            "anchor_rules": ["Connection Tracking Exceeded Instance Allowance"],
            "impact": (
                "Connections idle beyond the tracking timeout lose their tracked state and must be "
                "re-established, consuming the instance's connection-tracking allowance. Keeping "
                "long-lived connections warm preserves that state."
            ),
            "caveat": (
                "Only affects sockets that enabled SO_KEEPALIVE — the most common reason this change "
                "appears to do nothing. Application-level connection POOLING ranks ahead of it. More "
                "frequent probes also generate more packets, which consumes PPS allowance."
            ),
        }
    )

    # tcp_keepalive_intvl / _probes — supporting settings, reported not recommended.
    #
    # These govern how fast a DEAD connection is detected, which is a different concern from
    # the connection-tracking allowance that anchors tcp_keepalive_time. Nothing aperf
    # measures says a given value is wrong, so they report `info`.
    keepalive_intvl = int(sysctl_data.get("net.ipv4.tcp_keepalive_intvl", 75))
    checks.append(
        {
            "check": "tcp_keepalive_intvl",
            "status": "info",
            "current": f"{keepalive_intvl}s",
            "unanchored": True,
            "impact": (
                "Interval between keepalive probes. Affects dead-connection DETECTION speed, not "
                "the tracked-state preservation that tcp_keepalive_time addresses. Only applies to "
                "sockets with SO_KEEPALIVE enabled."
            ),
        }
    )

    keepalive_probes = int(sysctl_data.get("net.ipv4.tcp_keepalive_probes", 9))
    checks.append(
        {
            "check": "tcp_keepalive_probes",
            "status": "info",
            "current": keepalive_probes,
            "unanchored": True,
            "impact": (
                "Probes before a connection is declared dead. Detection speed only; no aperf "
                "finding covers it. Only applies to sockets with SO_KEEPALIVE enabled."
            ),
        }
    )

    # tcp_max_syn_backlog — reported, not recommended.
    #
    # No anchor: ListenOverflows and TCPBacklogDrop are collected but no aperf rule reads
    # them. The previous check also assumed a default of 512 and asserted a drop mechanism
    # that does not obtain under the default tcp_syncookies=1, where SYN-queue overflow
    # produces syncookies rather than drops. It also conflated the SYN queue with the
    # accept queue (somaxconn / the listen() backlog).
    syn_backlog = sysctl_data.get("net.ipv4.tcp_max_syn_backlog")
    checks.append(
        {
            "check": "tcp_max_syn_backlog",
            "status": "info",
            "current": syn_backlog if syn_backlog is not None else "not collected",
            "unanchored": True,
            "impact": (
                "No aperf finding covers this. The default is memory-scaled and often already "
                "exceeds what a fixed recommendation would set. Under the default "
                "tcp_syncookies=1, SYN-queue pressure produces syncookies, not drops. The accept "
                "queue (somaxconn and the application's own listen() backlog) is a separate limit "
                "and usually the real one."
            ),
        }
    )

    # tcp_fin_timeout — reported, not recommended. Previous mechanism was factually wrong.
    fin_timeout = sysctl_data.get("net.ipv4.tcp_fin_timeout")
    checks.append(
        {
            "check": "tcp_fin_timeout",
            "status": "info",
            "current": f"{fin_timeout}s" if fin_timeout is not None else "not collected",
            "unanchored": True,
            "impact": (
                "No aperf finding covers this. Correction to earlier guidance: tcp_fin_timeout "
                "controls the FIN_WAIT_2 timeout, NOT TIME_WAIT. TIME_WAIT is hardcoded at 60s in "
                "the kernel and is not tunable via this or any sysctl, so the ephemeral-port "
                "rationale previously given here did not hold."
            ),
        }
    )

    # -----------------------------------------------------------------------
    # Dirty page writeback checks.
    #
    # These three interact: when dirty_background_ratio sits above the workload's actual dirty
    # accumulation, the background flusher never fires and dirty_expire_centisecs becomes the only
    # flush mechanism — which flushes everything at once, in a burst, on a timer.
    # -----------------------------------------------------------------------
    dirty_bg_ratio = int(sysctl_data.get("vm.dirty_background_ratio", 10))
    dirty_expire = int(sysctl_data.get("vm.dirty_expire_centisecs", 3000))
    dirty_writeback = int(sysctl_data.get("vm.dirty_writeback_centisecs", 500))

    # Status is `info`, never `warning`. These three are EVIDENCE-CLASS: the mechanism is
    # real and field-verified, but NO aperf rule reads pgpgout or nr_dirty (confirmed: zero
    # matches in src/analytics/), so nothing measured says this workload has the problem.
    # 10 and 3000 are the STOCK KERNEL DEFAULTS — warning on them, as this did, guaranteed
    # two spurious warnings on every unmodified host.
    _dirty_evidence = (
        "EVIDENCE-CLASS, not a finding. To establish this actually applies, check that nr_dirty "
        "stays far below nr_dirty_background_threshold, that pgpgout arrives in bursts, and that "
        "iowait spikes with those bursts. aperf collects none of these as a scored rule."
    )

    checks.append(
        {
            "check": "vm.dirty_background_ratio",
            "status": "info",
            "current": f"{dirty_bg_ratio}%",
            "is_kernel_default": dirty_bg_ratio == 10,
            "unanchored": True,
            "candidate_fix": "sudo sysctl -w vm.dirty_background_ratio=2",
            "impact": (
                f"Background dirty-page flushing triggers at {dirty_bg_ratio}% of RAM. On a 32GB "
                "node that is 3.2GB — above typical dirty accumulation (~100-600MB), so the "
                "background flusher may never trigger and flushing falls to the expiry timer, in "
                "bursts."
            ),
            "evidence_required": _dirty_evidence,
            "field_case": (
                "Field-tested on an EKS Python/Gunicorn workload: dirty_background_ratio=10% "
                "caused a 20% iowait burst every 30s. Reduced to 1%. Recorded as a real case, not "
                "as a general recommendation."
            ),
        }
    )

    checks.append(
        {
            "check": "vm.dirty_expire_centisecs",
            "status": "info",
            "current": f"{dirty_expire} ({dirty_expire // 100}s)",
            "is_kernel_default": dirty_expire == 3000,
            "unanchored": True,
            "candidate_fix": "sudo sysctl -w vm.dirty_expire_centisecs=500",
            "impact": (
                f"Pages dirty longer than {dirty_expire // 100}s are forcibly flushed. If "
                "dirty_background_ratio never triggers, this timer becomes the only flush "
                "mechanism and writes everything at once."
            ),
            "evidence_required": _dirty_evidence,
        }
    )

    checks.append(
        {
            "check": "vm.dirty_writeback_centisecs",
            "status": "info",
            "current": f"{dirty_writeback} ({dirty_writeback // 100}s)",
            "unanchored": True,
            "candidate_fix": "sudo sysctl -w vm.dirty_writeback_centisecs=200",
            "impact": "How often the writeback thread wakes. Lower means more frequent, smaller writes.",
            "evidence_required": _dirty_evidence,
        }
    )

    # Both tallies are computed here, after every check has been appended. `warnings` used to be
    # counted right after the IRQ check, which excluded the eight network and dirty-page checks
    # below it — a run with nine warnings reported four.
    passed = sum(1 for c in checks if c["status"] == "pass")
    warnings = sum(1 for c in checks if c["status"] == "warning")

    return json.dumps(
        {
            "status": "success",
            "run_name": run_name,
            "summary": f"{passed}/{len(checks)} checks passed, {warnings} warnings",
            "checks": checks,
            "system_info": {
                "transparent_hugepages": sysinfo.get("transparent_hugepages", "unknown"),
                "vm_max_map_count": max_map,
                "vm_swappiness": swappiness,
                "numa_balancing": sysinfo.get("numa_balancing"),
                "cpu_governor": sysinfo.get("cpu_governor", "unknown"),
                "kernel_version": sysinfo.get("kernel_version", ""),
                "perf_event_paranoid": sysinfo.get("perf_event_paranoid"),
            },
        },
        indent=2,
    )
