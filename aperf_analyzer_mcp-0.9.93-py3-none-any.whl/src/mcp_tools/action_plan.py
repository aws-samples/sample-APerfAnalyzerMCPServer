# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Shared severity ranking for action-plan rows.

Both `html_report.py`'s `_build_action_plan` (renders HTML) and `run_summary.py`'s
`action_plan` field (returns plain JSON) build a prioritized list of rows and must
agree on what "priority" means — a customer/agent reading the HTML report and one
calling `get_run_summary` directly must never see a different ordering for the same
underlying findings. One ranking function, imported by both, rather than two copies
that could drift.
"""

from __future__ import annotations

#: badge/severity keyword -> sort rank. Lower renders first. `degraded`/`measured`
#: share MEDIUM's rank: a dependency DEGRADED and a MEASURED (real-but-uncurated)
#: anomaly are both "worth doing, not urgent" in this ordering.
SEVERITY_RANK: dict[str, int] = {
    "blocker": 0,
    "high": 1,
    "critical": 1,
    "medium": 2,
    "degraded": 2,
    "measured": 2,
    "warning": 2,
    "low": 3,
    "info": 3,
}

#: Anything not in `SEVERITY_RANK` sorts last, after every recognised severity —
#: never silently mixed in among ranked rows.
_UNRANKED = 9


def severity_rank(severity_or_badge_text: str) -> int:
    """
    Rank a severity keyword OR a rendered badge string (e.g.
    `"<span class='badge measured'>MEASURED</span>"`) — callers differ in which they
    have on hand, and matching by substring on the lowercased text handles both
    without requiring two separate functions.
    """
    text = severity_or_badge_text.lower()
    for key, rank in SEVERITY_RANK.items():
        if key in text:
            return rank
    return _UNRANKED


#: anomaly CODE (the prefix before ": " in every `detect_anomalies()` string across
#: `cpu_parser.py`/`memory_parser.py`/`disk_parser.py`/`interrupt_parser.py`) ->
#: recommendation steps. Kept SEPARATE from those parsers' own `detect_anomalies`
#: (which stays `list[str]`, unchanged, so every existing caller keeps working) —
#: `html_report.py` and `run_summary.py` both look up a fired anomaly's code here when
#: building their action-plan rows, so the two can never show different advice for the
#: same measured anomaly.
#:
#: Every recommendation names a real OS-level lever this codebase can actually verify
#: (a sysctl, a scheduler/affinity command, a `perf`/`iostat` follow-up) — never a
#: vendor-specific product name or setting aperf cannot see (e.g. an EBS volume type),
#: the exact discipline the worker-imbalance fix already established.
MEASURED_ANOMALY_RECOMMENDATIONS: dict[str, list[str]] = {
    "HIGH_IOWAIT": [
        "Check `disk` in this same tool's output (or the Disk section of the HTML "
        "report) for the specific device and its utilization%/queue depth/await — "
        "iowait alone doesn't say WHICH device or how saturated it is",
        "If a specific device shows high queue depth, the workload is issuing more "
        "concurrent I/O than the device can sustain — reduce concurrency or spread "
        "I/O across more devices",
        "Confirm this isn't a burst: re-run and compare — a single busy interval "
        "during startup/warmup is not the same problem as sustained saturation",
    ],
    "HIGH_IRQ_LOAD": [
        "Check /proc/interrupts for which IRQs are firing most — network (ENA) and "
        "NVMe queues are the common sources on EC2",
        "If interrupts concentrate on a few CPUs: consider `irqbalance` (if not "
        "running) or manual IRQ-to-CPU affinity via /proc/irq/<N>/smp_affinity",
        "For network-heavy workloads: check if the ENA driver's queue count matches "
        "vCPU count (`ethtool -l <iface>`) — fewer queues than cores concentrates "
        "interrupt load on fewer CPUs than necessary",
    ],
    "CPU_IMBALANCE": [
        "Check per-CPU utilization (this run's own per-core breakdown) to identify "
        "which cores are hot vs idle — a single-threaded hot path pinned to one core "
        "looks like this even on an otherwise idle machine",
        "If the workload is genuinely single-threaded on its hot path, more vCPUs "
        "will not help — the fix is parallelizing the workload or running multiple "
        "instances, each on its own core (see the Right-sizing tab for a narrower "
        "instance recommendation)",
        "If threads should be spreading across cores but aren't, check CPU affinity "
        "settings (`taskset -pc <pid>`) and NUMA policy (`numactl --show`)",
    ],
    "BURSTY_WORKLOAD": [
        "Confirm the capture window covers real steady-state activity — a capture "
        "that includes startup/idle periods will show this even for a workload with "
        "sustained load during its busy periods",
        "If bursts are real: check whether peak bursts are hitting a hard ceiling "
        "(100% CPU, disk saturation) during those windows — that determines whether "
        "capacity needs to grow or whether the burst itself needs smoothing "
        "(e.g. request queuing/rate limiting)",
    ],
    "HIGH_KERNEL_TIME": [
        "Profile syscall activity (`perf trace` or `strace -c` on the hot process) to "
        "identify which syscalls dominate — high kernel time with no obvious I/O "
        "often points to excessive small read/write/mmap calls, TLB shootdowns, or "
        "lock contention resolved in-kernel",
        "If the workload does many small I/O operations: batching them (larger "
        "buffers, fewer syscalls) reduces kernel-time overhead directly",
    ],
    "MEMORY_PRESSURE": [
        "Check for swap activity (see SWAP_ACTIVE below) — real memory pressure with "
        "no swap means the OOM killer is one allocation spike away",
        "Identify the largest consumer via this run's process data, then decide "
        "whether it's a real growing working set (needs more memory) or a leak "
        "(needs investigation) by comparing against a longer or repeated capture",
    ],
    "SWAP_ACTIVE": [
        "Swap activity under real memory pressure means the instance's provisioned "
        "RAM is genuinely insufficient for this workload's working set — right-size "
        "up, don't just tune swappiness",
        "Check `vm.swappiness` (default 60) — lowering it (e.g. to 10) delays "
        "swapping in favor of reclaiming page cache first, but does not fix an "
        "actual RAM shortfall, only postpones symptoms",
    ],
    "MEMORY_OVER_PROVISIONED": [
        "See the Right-sizing tab / `get_right_sizing`/`graviton_readiness` tools for "
        "a benchmark-backed candidate that matches this run's actual measured "
        "working set instead of the currently provisioned RAM",
        "Confirm this isn't an artifact of a short/idle capture window before "
        "downsizing — re-run under representative load if this capture may not "
        "reflect peak usage",
    ],
    "MEMORY_FLAT_LINE": [
        "A static, flat memory profile with real headroom usually means the "
        "workload's actual working set is smaller than what's provisioned — same "
        "right-sizing tools as MEMORY_OVER_PROVISIONED apply",
        "If the flat line is unexpectedly LOW (near zero) rather than high, confirm "
        "the process is actually running and doing work during the capture window",
    ],
    "IPI_STORM": [
        "Check NUMA topology (`numactl --hardware`) — excessive cross-CPU IPIs often "
        "come from memory/thread placement that spans NUMA nodes unnecessarily",
        "Check kernel version and scheduler patches — some scheduler regressions are "
        "known to over-trigger IPIs for load-balancing; compare against a known-good "
        "kernel version if this is unexpected for the workload",
        "If TLB shootdowns are the driver, reducing unnecessary `mmap`/`munmap` churn "
        "or increasing use of huge pages (fewer, larger mappings) reduces IPI volume",
    ],
    "DISK_SATURATION": [
        "Identify the actual I/O pattern with `iostat -x 1` or by inspecting this "
        "run's own per-device diskstats — random small I/O saturates a device's IOPS "
        "ceiling well before its throughput ceiling, and the fix differs (IOPS "
        "provisioning vs. throughput) depending on which is the real limit",
        "Reduce concurrent I/O from the application side (fewer parallel writers, "
        "larger sequential writes instead of many small ones) if the workload's own "
        "concurrency exceeds what any single device can sustain",
        "If sustained (not a burst) and application-side changes aren't an option, "
        "this device needs more IOPS/throughput headroom than it currently has — "
        "verify against your actual provisioned capacity for this specific volume",
    ],
    "DISK_QUEUE_DEPTH_HIGH": [
        "A high average queue depth means requests are arriving faster than the "
        "device completes them — check whether concurrency can be reduced at the "
        "application level (fewer parallel I/O threads) before concluding the device "
        "itself needs more capacity",
        "Cross-check against DISK_SATURATION for the same device — a high queue depth "
        "with utilization well under 100% suggests occasional bursts, not sustained "
        "saturation",
    ],
    "HIGH_IO_LATENCY": [
        "Compare average vs. peak await for the busiest device (this run's own disk "
        "summary) — a high average driven by occasional large latency spikes has a "
        "different cause (and fix) than uniformly elevated latency",
        "Check whether latency correlates with queue depth (see DISK_QUEUE_DEPTH_HIGH) "
        "— queuing-driven latency is a capacity/concurrency problem, not a device "
        "health problem",
    ],
}


def measured_anomaly_recommendations(anomaly_text: str) -> list[str]:
    """
    `"HIGH_IOWAIT: Average I/O wait at 17.3%..."` -> the recommendation steps for
    `HIGH_IOWAIT`, or `[]` if the code isn't in the table (never raises — an
    unrecognised or future anomaly code degrades to no recommendation, not an error).
    """
    code, _, _ = anomaly_text.partition(": ")
    return MEASURED_ANOMALY_RECOMMENDATIONS.get(code, [])
