# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: pricing_status

Reports the freshness of the bundled EC2 pricing data and offers an explicit
refresh command for the user/agent to approve.

Behavior:
- Without `confirm`: returns freshness status + refresh command for approval
- With `confirm=true`: actually refreshes the data (see src/pricing_refresh.py)

This keeps refreshes user-approved (no silent network calls), and gives the
agent a clear command to surface in chat.

The refresh itself calls src/pricing_refresh.py's `refresh()` directly -- no subprocess. This
used to spawn `scripts/refresh_pricing.py` as a child process
(`asyncio.create_subprocess_exec(sys.executable, str(REFRESH_SCRIPT), ...)`), which is exactly
the "process-spawning call whose argument is not a literal string" shape a security scanner
flags as unauditable in general, correctly, even when the specific argument is in fact a fixed
constant (REFRESH_SCRIPT never varies). Calling the shared async function directly removes the
subprocess entirely rather than trying to make that specific call pass review.
"""

import asyncio
import json
from pathlib import Path

from mcp.types import Tool

from .. import pricing_refresh
from . import pricing as _pricing

PRICING_STATUS_TOOL = Tool(
    name="pricing_status",
    description=(
        "Check the freshness of bundled EC2 pricing data and offer a refresh command. "
        "Returns the current data age, freshness category (fresh/aging/stale/missing), "
        "and a refresh command the user can approve. "
        "Pass confirm=true to actually run the refresh (downloads ~30KB from AWS pricing API). "
        "Use this when starting an analysis session to ensure pricing recommendations are accurate, "
        "or when the report shows a yellow/red freshness banner."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "confirm": {
                "type": "boolean",
                "description": (
                    "Set to true to actually run the refresh. Without this flag, the tool only "
                    "reports status and returns the command for user approval. "
                    "Default: false (status-only, safe)."
                ),
                "default": False,
            },
        },
        "required": [],
    },
)


REPO_ROOT = Path(__file__).parent.parent.parent
_REFRESH_TIMEOUT_SECS = 120


async def pricing_status_handler(arguments: dict) -> str:
    """Handle pricing_status tool calls."""
    # `confirm` must be a real boolean, not merely truthy -- bool(arguments.get(...)) would treat
    # the string "false" (a caller's honest mistake, or a value round-tripped through something
    # that stringifies booleans) as True. isinstance is checked explicitly rather than coerced.
    confirm_raw = arguments.get("confirm", False)
    if not isinstance(confirm_raw, bool):
        return json.dumps(
            {
                "status": "error",
                "message": f"confirm must be a boolean, got {type(confirm_raw).__name__}",
            }
        )
    confirm = confirm_raw

    status, days = _pricing.pricing_freshness()
    metadata = _pricing.metadata()
    pub = metadata.get("publication_date", "unknown")
    instance_count = metadata.get("instance_count", 0)

    refresh_cmd = "python scripts/refresh_pricing.py"

    response = {
        "status": status,
        "days_old": days,
        "publication_date": pub,
        "instance_count": instance_count,
        "data_file": str(REPO_ROOT / "resources" / "ec2_pricing_us_east_1.json"),
        "refresh_command": refresh_cmd,
    }

    if not confirm:
        if status == "fresh":
            response["message"] = (
                f"Pricing data is current ({days} days old, published {pub}, "
                f"{instance_count} instances). No refresh needed."
            )
            response["recommended_action"] = "none"
        elif status == "aging":
            response["message"] = (
                f"Pricing data is aging ({days} days old, published {pub}). "
                f"Consider refreshing for the most accurate cost analysis. "
                f"To refresh, ask the user for approval and re-run this tool with confirm=true, "
                f"or run the command manually."
            )
            response["recommended_action"] = "ask_user_to_approve_refresh"
        elif status == "stale":
            response["message"] = (
                f"Pricing data is STALE ({days} days old, published {pub}). "
                f"Cost recommendations will be based on outdated data. "
                f"Strongly recommend refreshing before generating any reports. "
                f"To refresh, ask the user for approval and re-run this tool with confirm=true, "
                f"or run the command manually."
            )
            response["recommended_action"] = "ask_user_to_approve_refresh"
        else:
            response["message"] = (
                "No pricing data file found. Cost recommendations will use placeholders. "
                "To download pricing data, ask the user for approval and re-run this tool "
                "with confirm=true, or run the command manually."
            )
            response["recommended_action"] = "ask_user_to_approve_refresh"

        if status in ("aging", "stale", "missing"):
            response["agent_prompt"] = (
                f"Pricing data is {status} ({days} days old). "
                f"I'd like to refresh it from the AWS pricing API. "
                f"This will run: `{refresh_cmd}` and download ~30KB. "
                f"Approve refresh? (yes/no)"
            )

        return json.dumps(response, indent=2)

    try:
        # `asyncio.wait_for` cancels the `refresh()` coroutine on timeout. refresh() awaits the
        # network fetch (via asyncio.to_thread) BEFORE doing anything else, and only writes
        # OUTPUT_PATH after that await returns -- so a cancellation always lands before the write
        # step is ever reached; there is no code path where a timed-out refresh still writes the
        # file afterward.
        result = await asyncio.wait_for(
            pricing_refresh.refresh(dry_run=False), timeout=_REFRESH_TIMEOUT_SECS
        )
    except asyncio.TimeoutError:
        response["status"] = "error"
        response["message"] = (
            f"Refresh timed out after {_REFRESH_TIMEOUT_SECS} seconds. Network issue?"
        )
        return json.dumps(response, indent=2)
    except Exception as e:
        response["status"] = "error"
        response["message"] = f"Refresh failed: {type(e).__name__}: {e}"
        return json.dumps(response, indent=2)

    _pricing.reload()
    new_status, new_days = _pricing.pricing_freshness()
    new_meta = _pricing.metadata()

    response["status"] = "refreshed"
    response["days_old"] = new_days
    response["publication_date"] = new_meta.get("publication_date", "unknown")
    response["instance_count"] = new_meta.get("instance_count", 0)
    response["new_freshness"] = new_status
    response["message"] = (
        f"Pricing data refreshed successfully. "
        f"New data: {new_meta.get('instance_count', 0)} instances, "
        f"published {new_meta.get('publication_date', 'unknown')} ({new_status})."
    )
    response["added_count"] = result["added_count"]
    response["removed_count"] = result["removed_count"]
    response["changed_count"] = result["changed_count"]
    return json.dumps(response, indent=2)
