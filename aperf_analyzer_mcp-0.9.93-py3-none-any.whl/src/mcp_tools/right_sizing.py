# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: get_right_sizing

Classifies the workload from a run, then proposes instance candidates backed by
independent benchmark measurements.

The response is split in two on purpose. `customer` carries prose a customer may read;
`internal` carries the benchmark figures and is omitted unless explicitly requested.
`customer` states capability in words, never in numbers derived from a benchmark: a
synthetic score or a percentage of one reads as a performance promise for the customer's
own application, which it is not, and differences inside the ~10% noise band would read
as real.

Every response carries the same non-negotiable caveat: this is a starting point, and only
a real workload test on the candidate confirms it.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from mcp.types import Tool

RIGHT_SIZING_TOOL = Tool(
    name="get_right_sizing",
    description=(
        "Recommend EC2 right-sizing for an aperf run, backed by independent CPU and "
        "memory-bandwidth benchmarks. Classifies the workload as CPU-bound, memory-bound "
        "or balanced with a pressure level per dimension, then proposes a conservative "
        "(low risk, one size step) and an aggressive (high risk) candidate. "
        "Graviton-first: a workload already on Graviton is only offered Graviton unless "
        "nothing Graviton fits. Preserves instance variant suffixes (n/d/gn/...) because "
        "those encode storage and network capability the benchmarks do not measure. "
        "Returns no recommendation, with a reason, when the data cannot support one."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "data_dir": {"type": "string"},
            "strategy": {
                "type": "string",
                "enum": ["conservative", "aggressive", "both"],
                "description": "Which proposals to return (default: both)",
                "default": "both",
            },
            "include_internal": {
                "type": "boolean",
                "description": (
                    "Include raw benchmark figures and demand math for audit. NEVER pass "
                    "true when the output will be shown to a customer."
                ),
                "default": False,
            },
            "customer_priority": {
                "type": "string",
                "description": (
                    "The customer's stated priority, e.g. 'cost' or 'performance'. "
                    "Defaults to cost-first ranking when omitted: cost is the ordinary "
                    "reason someone asks about right-sizing, and ranking by anything else "
                    "when no priority was ever stated would be guessing. Pass a non-cost "
                    "value only when the customer has explicitly said performance matters "
                    "more than price, which relaxes the price-first tiebreak so bandwidth "
                    "may lead among candidates that already clear the demand floor."
                ),
            },
        },
        "required": ["run_name"],
    },
)


def _candidate_json(cand: Any, include_internal: bool) -> dict[str, Any]:
    out: dict[str, Any] = {
        "instance_type": cand.instance_type,
        "strategy": cand.strategy,
        "risk": cand.risk,
        "direction": cand.direction,
        "vcpu": cand.vcpu,
        "memory_gb": round(cand.memory_gb, 1),
        "architecture": cand.architecture,
        "price_per_hour_usd": cand.price_per_hour,
        "why": cand.customer_summary,
        "caveats": cand.caveats,
    }
    if include_internal:
        out["internal"] = cand.internal
    return out


async def right_sizing_handler(arguments: dict[str, Any]) -> str:
    run_name = arguments["run_name"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    strategy = arguments.get("strategy", "both")
    include_internal = bool(arguments.get("include_internal", False))
    # Cost leads unless the caller states otherwise — see `recommend`'s docstring for why
    # "not defined" is treated the same as "cost".
    from .rightsizer import is_cost_priority

    cost_priority = is_cost_priority(arguments.get("customer_priority"))

    from ..parsers.cpu_parser import CpuUtilizationParser
    from ..parsers.memory_parser import MemoryParser
    from ..parsers.pmu_parser import PmuParser
    from ..parsers.run_parser import AperfRunParser
    from .rightsizer import recommend, recommend_graviton_equivalent
    from .workload_classifier import classify

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)
    if not run_data:
        return json.dumps({"status": "error", "message": f"Run '{run_name}' not found"})

    # The resolved path, not a reconstruction: an archive run was extracted to a tempdir.
    run_path = Path(run_data.metadata.run_path)
    report_data = parser.get_report_data(run_path) or {}

    cpu_summary = CpuUtilizationParser().parse_from_report_data(report_data)
    pmu_summary = PmuParser().parse_from_report_data(report_data)
    mem_summary = MemoryParser().parse_from_report_data(report_data)

    aperf_findings = None
    try:
        from ..parsers.findings_parser import FindingsParseError, parse_findings

        aperf_findings = parse_findings(run_path)
    except (FindingsParseError, OSError, ValueError, TypeError, AttributeError):
        aperf_findings = None

    profile = classify(
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        mem_summary=mem_summary,
        aperf_findings=aperf_findings,
    )

    # Memory capacity demand is the current instance's OWN installed RAM, not a
    # peak-scaled fraction of it. There is no way to run this workload on less memory
    # than is already provisioned to it — a peak of 83.8% does not mean 83.8% of capacity
    # is the requirement; 100% of the current capacity is, because that is what the
    # workload has today. A 1.5x buffer on top of that invents headroom nothing asked
    # for and rules out reasonably-sized candidates, forcing jumps to oversized instances
    # that cost MORE than the current one on a workload whose real problem is underused
    # CPU. `_eligible`'s own 10% noise band is the only tolerance this needs.
    #
    # `total_mb` needs sanity-checking rather than trusting, because the two parser paths
    # disagree about units. The report path yields true kB, so `total_mb` is MB as named.
    # The flat-binary `aperf record` path yields BYTES in the same `mem_total_kb` field,
    # so `total_mb` comes out 1024x too large — observed on a real 256 GB r6g.8xlarge run
    # reporting `total_mb = 260794168`. Taken at face value that produced a 15,177 GB
    # capacity demand, which no instance on earth satisfies, so the tool silently returned
    # "no recommendation" for an idle machine. No EC2 instance has more than ~32 TB, so a
    # value above that is unambiguously the wrong unit.
    _MAX_PLAUSIBLE_MB = 32 * 1024 * 1024  # 32 TB, comfortably above any real instance
    capacity_gb: float | None = None
    total_mb = getattr(mem_summary, "total_mb", None) if mem_summary else None
    if total_mb:
        total_mb = float(total_mb)
        while total_mb > _MAX_PLAUSIBLE_MB:
            total_mb /= 1024.0
        capacity_gb = total_mb / 1024.0

    result = recommend(
        current_instance=run_data.metadata.instance_type,
        profile=profile,
        memory_capacity_gb=capacity_gb,
        strategy=strategy,
        cost_priority=cost_priority,
    )

    # Independent of the conservative/aggressive picks above — the ARM Modernization
    # report tab reads this same field, so the MCP tool and the HTML report can never
    # show a different Graviton candidate for the same run.
    graviton_equivalent = recommend_graviton_equivalent(
        current_instance=run_data.metadata.instance_type,
        profile=profile,
        memory_capacity_gb=capacity_gb,
        cost_priority=cost_priority,
    )

    response: dict[str, Any] = {
        "status": "success",
        "run_name": run_name,
        "current_instance": result.current_instance,
        # Stated, not inferred. An empty `recommendations` list is ambiguous on its own —
        # it can mean "already on the right instance" (a positive result) or "we could not
        # tell" (an absence of one). `verdict` and `headline` separate those so a report
        # never renders "you are correctly sized" as a failure to recommend.
        "verdict": result.verdict.value,
        "headline": result.headline,
        "workload": {
            "classification": profile.classification.value,
            "cpu_pressure": profile.cpu_pressure.value,
            "memory_bandwidth_pressure": profile.memory_bandwidth_pressure.value,
            "memory_capacity_pressure": profile.memory_capacity_pressure.value,
            "confidence": profile.confidence.value,
            "evidence": profile.evidence,
            # Surfaced deliberately: what was NOT measured is part of the answer, and the
            # previous engine's habit of treating absent PMU as zero is exactly the bug
            # this makes visible.
            "not_measured": profile.gaps,
        },
        "recommendations": [_candidate_json(c, include_internal) for c in result.candidates],
        # `None` when there's nothing to modernize to: already Graviton, no eligible
        # Graviton candidate, or insufficient data — see `recommend_graviton_equivalent`.
        "graviton_equivalent": (
            _candidate_json(graviton_equivalent, include_internal)
            if graviton_equivalent is not None
            else None
        ),
        "notes": result.notes,
        "must_validate": result.mandatory_caveat,
    }

    if result.no_recommendation_reason:
        response["no_recommendation_reason"] = result.no_recommendation_reason

    if include_internal and result.demand is not None:
        response["internal_demand"] = {
            "cpu_throughput": result.demand.cpu_throughput,
            "cpu_basis": result.demand.cpu_basis,
            "memory_capacity_gb": result.demand.memory_capacity_gb,
            "memory_bandwidth": result.demand.memory_bandwidth,
            "bandwidth_basis": result.demand.bandwidth_basis,
            "min_vcpu": result.demand.min_vcpu,
            "min_vcpu_basis": result.demand.min_vcpu_basis,
            "safety_buffer_pct": result.demand.safety_buffer_pct,
        }

    return json.dumps(response, indent=2, default=str)
