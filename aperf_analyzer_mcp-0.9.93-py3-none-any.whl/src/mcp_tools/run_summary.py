# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: get_run_summary

Comprehensive summary of a single aperf run — the "executive briefing" for a run.
Combines CPU, memory, PMU, interrupt, and disk data into a single digestible view.
"""

import json
import os
from typing import Any

from mcp.types import Tool

from ..parsers.cpu_parser import CpuUtilizationParser
from ..parsers.disk_parser import DiskParser
from ..parsers.interrupt_parser import InterruptParser
from ..parsers.memory_parser import MemoryParser
from ..parsers.pmu_parser import PmuParser
from ..parsers.run_parser import AperfRunParser
from .action_plan import measured_anomaly_recommendations, severity_rank

RUN_SUMMARY_TOOL = Tool(
    name="get_run_summary",
    description=(
        "Get a comprehensive performance summary for a specific aperf run. "
        "Includes CPU utilization, PMU metrics (IPC, branch misses, cache performance), "
        "memory usage, disk I/O saturation (utilization%, queue depth, await), "
        "interrupt patterns, and automated anomaly detection, plus a structured, "
        "severity-sorted `action_plan` covering the same real findings "
        "`generate_html_report`'s Prioritized Action Plan renders — read this instead "
        "of the HTML when you only need the findings, not the full report. "
        "This is the best starting point for analyzing a single run."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": "Name of the aperf run to analyze",
            },
            "data_dir": {
                "type": "string",
                "description": "Base directory containing aperf runs",
            },
            "include_raw_counters": {
                "type": "boolean",
                "description": "Include raw PMU counter values (default: false)",
                "default": False,
            },
        },
        "required": ["run_name"],
    },
)


async def run_summary_handler(arguments: dict[str, Any]) -> str:
    """Generate comprehensive run summary."""
    run_name = arguments["run_name"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    include_raw = arguments.get("include_raw_counters", False)

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)

    if not run_data:
        return json.dumps(
            {
                "status": "error",
                "message": f"Run '{run_name}' not found in {data_dir}",
            }
        )

    # Get report data if available
    from pathlib import Path

    report_data = parser.get_report_data(Path(data_dir) / run_name)

    summary = {
        "status": "success",
        "run_name": run_name,
        "metadata": {
            "instance_type": run_data.metadata.instance_type,
            "architecture": run_data.metadata.architecture,
            "cpu_count": run_data.metadata.cpu_count,
            "kernel_version": run_data.metadata.kernel_version,
            "duration_seconds": run_data.metadata.duration_seconds,
            "collectors": run_data.metadata.collectors_available,
        },
        "findings": [],
        "anomalies": [],
    }

    if report_data:
        # CPU analysis
        cpu_parser = CpuUtilizationParser()
        cpu_summary = cpu_parser.parse_from_report_data(report_data)
        if cpu_summary:
            summary["cpu"] = {
                "avg_utilization_pct": cpu_summary.avg_total_utilization_pct,
                "peak_utilization_pct": cpu_summary.peak_utilization_pct,
                "avg_user_pct": cpu_summary.avg_user_pct,
                "avg_system_pct": cpu_summary.avg_system_pct,
                "avg_iowait_pct": cpu_summary.avg_iowait_pct,
                "cpu_imbalance_pct": cpu_summary.cpu_imbalance_pct,
            }
            summary["anomalies"].extend(cpu_parser.detect_anomalies(cpu_summary))

        # PMU analysis
        pmu_parser = PmuParser()
        pmu_summary = pmu_parser.parse_from_report_data(report_data)
        if pmu_summary:
            # Only what was actually collected. Every field defaults to 0.0, and this used to emit
            # all of them unconditionally, so a platform whose pmu_config omits a metric reported
            # it as a measured zero — a perfect IPC of 0.00 and a 0% miss rate.
            available = set(pmu_summary.metrics_available)

            def if_measured(aperf_name: str, value: float) -> float | None:
                return value if (not available or aperf_name in available) else None

            summary["pmu"] = {
                "ipc": if_measured("ipc", pmu_summary.ipc),
                "branch_misses_per_1k_insns": if_measured(
                    "branch-mpki", pmu_summary.branch_misses_per_1k_instructions
                ),
                "itlb_misses_per_1k_insns": if_measured(
                    "inst-tlb-mpki", pmu_summary.itlb_misses_per_1k_instructions
                ),
                "dtlb_misses_per_1k_insns": if_measured(
                    "data-tlb-mpki", pmu_summary.dtlb_misses_per_1k_instructions
                ),
                "inst_l1_misses_per_1k_insns": if_measured(
                    "inst-l1-mpki", pmu_summary.inst_l1_mpki
                ),
                "data_l1_misses_per_1k_insns": if_measured(
                    "data-l1-mpki", pmu_summary.data_l1_mpki
                ),
                "l2_misses_per_1k_insns": if_measured("l2-mpki", pmu_summary.l2_mpki),
                "l3_misses_per_1k_insns": if_measured("l3-mpki", pmu_summary.l3_mpki),
                "frontend_stall_pct": if_measured(
                    "stall-frontend-pkc", pmu_summary.frontend_stall_pct
                ),
                "backend_stall_pct": if_measured(
                    "stall-backend-pkc", pmu_summary.backend_stall_pct
                ),
                "backend_stall_denominator": pmu_summary.stall_denominator,
                "counter_multiplexing_pct": pmu_summary.counter_schedule_rate_pct,
                "metrics_collected": pmu_summary.metrics_available,
                "units": (
                    "`mpki`/`per_1k_insns` are events per 1000 instructions. Stall percentages "
                    "are derived from aperf's per-1000-cycle metrics; the backend denominator is "
                    "issue slots on some platforms, hence `backend_stall_denominator`. `null` "
                    "means the metric is not in this platform's pmu_config, not zero."
                ),
            }
            if include_raw:
                # aperf publishes no raw counters in any version — it divides the events per
                # `pmu_config.json` and writes only the derived metrics. The four totals reported
                # here were always 0. The per-interval series is the rawest thing that exists.
                summary["pmu"]["raw"] = {
                    "note": "aperf does not publish raw PMU counters — no instruction or cycle "
                    "totals exist in a report. These are its derived per-interval "
                    "metrics, averaged over the run.",
                    "derived_metrics_collected": pmu_summary.metrics_available,
                    "stall_frontend_per_1k_cycles": pmu_summary.stall_frontend_pkc,
                    "stall_backend_per_1k_cycles": pmu_summary.stall_backend_pkc,
                    "inst_tlb_table_walks_per_1k_insns": pmu_summary.inst_tlb_tw_pki,
                    "data_tlb_table_walks_per_1k_insns": pmu_summary.data_tlb_tw_pki,
                    "code_sparsity": pmu_summary.code_sparsity,
                }
            bottlenecks = pmu_parser.detect_bottlenecks(pmu_summary)
            summary["findings"].extend(bottlenecks)

        # Memory analysis
        mem_parser = MemoryParser()
        mem_summary = mem_parser.parse_from_report_data(report_data)
        if mem_summary:
            summary["memory"] = {
                "avg_used_pct": mem_summary.avg_used_pct,
                "peak_used_pct": mem_summary.peak_used_pct,
                "swap_used_mb": mem_summary.swap_used_mb,
            }
            summary["anomalies"].extend(mem_parser.detect_anomalies(mem_summary))

        # Interrupt analysis
        int_parser = InterruptParser()
        int_summary = int_parser.parse_from_report_data(report_data)
        if int_summary:
            summary["interrupts"] = {
                "ipi_per_sec": int_summary.ipi_per_sec,
            }
            summary["anomalies"].extend(int_parser.detect_anomalies(int_summary))

        # Disk analysis — real per-device I/O saturation (utilization%, queue depth,
        # await), computed directly from aperf's own diskstats collector. The SAME
        # `DiskParser` `generate_html_report`'s action plan uses, so a caller reading
        # only this JSON sees the same disk-saturation evidence the HTML report shows.
        disk_parser = DiskParser()
        disk_summary = disk_parser.parse_from_report_data(report_data)
        if disk_summary:
            summary["disk"] = {
                "busiest_device": disk_summary.busiest_device,
                "avg_utilization_pct": disk_summary.avg_utilization_pct,
                "peak_utilization_pct": disk_summary.peak_utilization_pct,
                "avg_queue_depth": disk_summary.avg_queue_depth,
                "avg_await_ms": disk_summary.avg_await_ms,
                "avg_iops": disk_summary.avg_iops,
                "avg_read_mbps": disk_summary.avg_read_mbps,
                "avg_write_mbps": disk_summary.avg_write_mbps,
            }
            summary["anomalies"].extend(disk_parser.detect_anomalies(disk_summary))

    # Worker imbalance detection
    if report_data:
        from .config_diagnosis import _detect_worker_imbalance

        processes = report_data.get("processes", {})
        if processes:
            imbalance = _detect_worker_imbalance(processes)
            if imbalance:
                summary["worker_imbalance"] = imbalance
                summary["anomalies"].append(
                    f"WORKER_IMBALANCE: {imbalance['evidence']['process_group']} workers "
                    f"show {imbalance['evidence']['max_min_ratio']}x load ratio "
                    f"(CV={imbalance['evidence']['coefficient_of_variation_pct']:.0f}%) "
                    f"— top 3 of {imbalance['evidence']['worker_count']} workers carry "
                    f"{imbalance['evidence']['top3_load_share_pct']:.0f}% of total work"
                )

    # Prioritized action plan — a structured, severity-sorted equivalent of
    # `generate_html_report`'s Prioritized Action Plan table, so a caller reading only
    # this JSON (never opening the HTML) sees the same findings in the same order. Real
    # aperf findings (`summary["findings"]`, from `pmu_parser.detect_bottlenecks`) are
    # labeled CURATED; anomalies/worker imbalance (real numbers, not anchored to a
    # curated aperf finding) are labeled MEASURED — the same distinction the HTML
    # report's `_build_action_plan` draws via its `MEASURED` badge.
    action_plan: list[dict[str, Any]] = []
    for finding in summary["findings"]:
        action_plan.append(
            {
                "severity": finding.get("severity", "medium"),
                "source": "curated",
                "category": finding.get("category", ""),
                "description": finding.get("description", ""),
                "recommendations": finding.get("recommendations", []),
            }
        )
    for anomaly_text in summary["anomalies"]:
        # WORKER_IMBALANCE gets its own richer row below (with real resolution steps,
        # not just the one-line summary string) — skip it here to avoid a duplicate.
        if anomaly_text.startswith("WORKER_IMBALANCE:"):
            continue
        code, _, detail = anomaly_text.partition(": ")
        action_plan.append(
            {
                "severity": "medium",
                "source": "measured",
                "category": code.replace("_", " ").title(),
                "description": detail,
                "recommendations": measured_anomaly_recommendations(anomaly_text),
            }
        )
    if summary.get("worker_imbalance"):
        wi = summary["worker_imbalance"]
        action_plan.append(
            {
                "severity": wi.get("severity", "medium"),
                "source": "measured",
                "category": "Worker Load Imbalance",
                "description": wi["diagnosis"],
                "recommendations": wi["resolution"],
            }
        )
    action_plan.sort(key=lambda row: severity_rank(row["severity"]))
    summary["action_plan"] = action_plan

    # Overall health score (simple heuristic)
    score = 100
    score -= len(summary["anomalies"]) * 10
    score -= sum(5 for f in summary["findings"] if f.get("severity") == "warning")
    score -= sum(15 for f in summary["findings"] if f.get("severity") == "critical")
    summary["health_score"] = max(0, min(100, score))

    return json.dumps(summary, indent=2, default=str)
