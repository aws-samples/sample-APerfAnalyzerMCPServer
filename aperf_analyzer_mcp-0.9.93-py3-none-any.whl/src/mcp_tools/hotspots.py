# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: get_hotspots

Identifies the top performance hotspots in a run — where is time being spent?
"""

import json
import os
import re
from pathlib import Path
from typing import Any

from mcp.types import Tool

from ..parsers.run_parser import AperfRunParser

HOTSPOTS_TOOL = Tool(
    name="get_hotspots",
    description=(
        "Identify top performance hotspots from an aperf run. "
        "Categories: cpu_functions (from perf profile), processes (top CPU consumers), "
        "interrupts (hottest interrupt lines), memory_latency (from hotline data). "
        "Returns ranked list with percentages. Note: for richer flamegraph queries (regex filter, run-vs-run diff), consider aws/aperf MCP's `get_flamegraph` tool which is more capable for raw flamegraph analysis."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "category": {
                "type": "string",
                "enum": ["cpu_functions", "processes", "interrupts", "memory_latency", "all"],
                "description": "Category of hotspots to retrieve",
                "default": "all",
            },
            "top_n": {
                "type": "integer",
                "description": "Number of top entries to return (default: 10)",
                "default": 10,
            },
            "data_dir": {"type": "string", "description": "Base directory containing aperf runs"},
        },
        "required": ["run_name"],
    },
)


def _parse_perf_report_hotspots(run_path: Path, top_n: int) -> list[dict[str, Any]]:
    """Parse top functions from the perf report text (top_functions file or perf_profile.js)."""
    entries = []

    # Try top_functions file first (inside raw archive sibling)
    top_fn_path = run_path / "top_functions"
    if not top_fn_path.exists():
        # Try raw archive path
        archive_dir = run_path / "data" / "archive"
        if archive_dir.exists():
            import tarfile

            for gz in archive_dir.glob("*.tar.gz"):
                try:
                    with tarfile.open(gz, "r:gz") as tar:
                        for member in tar.getmembers():
                            if member.name.endswith("top_functions"):
                                f = tar.extractfile(member)
                                if f:
                                    text = f.read().decode("utf-8", errors="replace")
                                    entries = _parse_perf_text(text, top_n)
                                    return entries
                except (tarfile.TarError, OSError, UnicodeError):
                    # The tarball is optional and may be truncated or absent; the caller falls
                    # through to `perf_profile.js` below. Narrow, so a bug in `_parse_perf_text`
                    # surfaces instead of looking like a missing archive.
                    pass

    # Try perf_profile.js
    js_path = run_path / "data" / "js" / "perf_profile.js"
    if js_path.exists():
        from ..parsers.run_parser import AperfRunParser

        parser = AperfRunParser.__new__(AperfRunParser)
        raw = parser._parse_js_var(js_path.read_text())
        if raw:
            run_key = next(iter(raw.get("runs", {})), None)
            lines = raw.get("runs", {}).get(run_key, {}).get("lines", []) if run_key else []
            text = "\n".join(str(l) for l in lines)
            entries = _parse_perf_text(text, top_n)
            if not entries and raw.get("data_format") == "graph":
                entries = _parse_flamegraph_hotspots(run_path, raw, top_n)

    return entries


def _parse_flamegraph_hotspots(
    run_path: Path, raw: dict[str, Any], top_n: int
) -> list[dict[str, Any]]:
    """Hotspots from the flamegraph SVG, for aperf's `graph` profile format.

    aperf 1.3.0 replaced the text profile — `data_format: "text"` with a `lines` array of
    `perf report` output — with `data_format: "graph"`, which carries no symbol table at all:
    each run holds `graph_groups[].graphs[].graph_path` pointing at an SVG. The `perf report`
    text and the `top_functions` file are both gone from the record directory, so the SVG is now
    the only symbol source in a report.

    That loses the self/total split, since a flamegraph frame's width is inclusive time. The
    entries are marked `inclusive` and carry no `self_pct` rather than passing an inclusive
    number off as a self one — ranking by it would put `main` above every real hotspot.
    """
    from ..parsers.flamegraph_parser import FlamegraphParser

    candidates = []
    for group in (
        raw.get("runs", {}).get(next(iter(raw.get("runs", {})), ""), {}).get("graph_groups", [])
    ):
        # The `reverse` group is the same data inverted; taking both would double-count.
        if group.get("group_name") == "reverse":
            continue
        for graph in (group.get("graphs") or {}).values():
            path = graph.get("graph_path")
            if path:
                candidates.append(run_path / path)

    parser = FlamegraphParser()
    for svg in candidates:
        if not svg.exists():
            continue
        summary = parser.parse_file(svg)
        if not summary.top_functions:
            continue
        return [
            {
                "symbol": entry.function_name,
                "inclusive_pct": entry.pct,
                "samples": entry.samples,
                "is_kernel": entry.is_kernel,
                "measure": "inclusive",
                "source": f"flamegraph: {svg.name}",
            }
            for entry in summary.top_functions[:top_n]
        ]
    return []


def _parse_perf_text(text: str, top_n: int) -> list[dict[str, Any]]:
    """Extract self% entries from perf report text."""
    entries = []
    pattern = re.compile(r"\s+(\d+\.\d+)%\s+(\d+\.\d+)%\s+(\S+)\s+(\S+)\s+\[.\]\s+(.*)")
    for line in text.splitlines():
        m = pattern.match(line)
        if m:
            overhead = float(m.group(1))
            self_pct = float(m.group(2))
            if self_pct > 0:
                entries.append(
                    {
                        "overhead_pct": overhead,
                        "self_pct": self_pct,
                        "command": m.group(3),
                        "dso": m.group(4),
                        "symbol": m.group(5).strip(),
                    }
                )
    entries.sort(key=lambda x: x["self_pct"], reverse=True)
    return entries[:top_n]


def _parse_process_hotspots(processes: dict[str, Any], top_n: int) -> list[dict[str, Any]]:
    """Rank processes by peak user-space CPU time."""
    hotspots = []

    user_series = processes.get("user_space_time", {}).get("series", [])
    kernel_series = {
        s["series_name"]: s["values"]
        for s in processes.get("kernel_space_time", {}).get("series", [])
    }
    rss_series = {
        s["series_name"]: s["values"]
        for s in processes.get("resident_set_size", {}).get("series", [])
    }
    thread_series = {
        s["series_name"]: s["values"] for s in processes.get("number_threads", {}).get("series", [])
    }

    for s in user_series:
        name = s["series_name"]
        vals = [v for v in s["values"] if v > 0]
        if not vals:
            continue
        peak = max(vals)
        avg = sum(vals) / len(vals)
        k_vals = [v for v in kernel_series.get(name, []) if v > 0]
        rss = rss_series.get(name, [0])
        threads = thread_series.get(name, [0])
        hotspots.append(
            {
                "process": name,
                "peak_user_ms": peak,
                "avg_user_ms": round(avg, 1),
                "peak_kernel_ms": max(k_vals) if k_vals else 0,
                "avg_rss_mb": round(sum(rss) / len(rss) / 1024, 1) if rss else 0,
                "avg_threads": round(sum(threads) / len(threads)) if threads else 0,
            }
        )

    hotspots.sort(key=lambda x: x["peak_user_ms"], reverse=True)
    return hotspots[:top_n]


def _parse_interrupt_hotspots(interrupts: dict[str, Any], top_n: int) -> list[dict[str, Any]]:
    """Rank interrupt lines by total event count."""
    totals = []
    for irq_name, vals in interrupts.items():
        total = sum(vals)
        if total > 0:
            totals.append(
                {
                    "interrupt": irq_name,
                    "total_events": int(total),
                    "avg_per_sec": round(total / len(vals), 1) if vals else 0,
                }
            )
    totals.sort(key=lambda x: x["total_events"], reverse=True)
    return totals[:top_n]


async def hotspots_handler(arguments: dict[str, Any]) -> str:
    """Identify performance hotspots."""
    run_name = arguments["run_name"]
    category = arguments.get("category", "all")
    top_n = arguments.get("top_n", 10)
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))

    parser = AperfRunParser(base_dir=data_dir)
    run_path = Path(data_dir) / run_name
    report_data = parser.get_report_data(run_path)

    result = {
        "status": "success",
        "run_name": run_name,
        "hotspots": {},
    }

    if not report_data:
        result["status"] = "partial"
        result["message"] = "No report data found."
        return json.dumps(result, indent=2)

    if category in ("cpu_functions", "all"):
        functions = _parse_perf_report_hotspots(run_path, top_n)
        result["hotspots"]["cpu_functions"] = functions

    if category in ("processes", "all"):
        processes = report_data.get("processes", {})
        if processes:
            result["hotspots"]["processes"] = _parse_process_hotspots(processes, top_n)

    if category in ("interrupts", "all"):
        interrupts = report_data.get("interrupts", {})
        if interrupts:
            result["hotspots"]["interrupts"] = _parse_interrupt_hotspots(interrupts, top_n)

    if category in ("memory_latency", "all"):
        result["hotspots"]["memory_latency"] = []

    return json.dumps(result, indent=2)
