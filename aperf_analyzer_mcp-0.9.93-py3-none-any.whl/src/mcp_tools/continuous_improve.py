# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: continuous_improvement

The continuous improvement engine for Python application performance.

This tool closes the full loop:
1. Parse an aperf run → identify performance findings
2. Cross-reference findings with actual source code in the project
3. Generate prescriptive code changes (not just advice — actual diffs)
4. Run the project's existing unit tests to validate changes
5. Persist findings, tasks, and test results in markdown files
6. On subsequent runs, build on prior context for cumulative improvement

Where the findings come from
---------------------------
**System-level findings are aperf's, read verbatim.** aperf runs 51 curated analytical rules at
`aperf report` time and serializes its verdicts into the report; this tool reads them back and
joins each to its playbook, exactly as `analyze_findings` does. It does not re-derive them.

That is a correctness requirement, not a style preference. This function used to apply its own
CPU thresholds — `iowait > 5%` as `high`, `system > 10%` as `medium` — and they contradicted the
pinned rules three ways at once:

* **aperf has no absolute `iowait` rule.** `Increased I/O Wait Time` is `delta_avg(iowait) >= 0.1`
  — a *relative* comparison against the base run, and `requires_comparison`. A single-run
  threshold on the absolute value is a different test with a different answer, and the playbook
  rates the real rule **P3 — Context**, not `high`, because its dominant outcome is noise.
* **The direction was inverted for the one case that matters.** The playbook's headline trap is
  that `iowait` *rises as a consequence of a CPU-side improvement*; a bare `> 5%` reports that
  improvement as a defect.
* **aperf has no `system`-CPU rule at all.** `cpu_utilization` has rules on `user`, `idle`,
  `iowait` and `aggregate` — never `system`. A `high_system_cpu` finding claimed aperf's
  authority for a verdict aperf does not hold, and at a threshold (10%) far below the level any
  playbook treats as notable.

What remains locally derived is what aperf has no rule for: flamegraph categories
(`perf_profile` is in the registry's `data_types_without_rules`) and sysctl values (`sysctl`
likewise). Those are marked `source: "aperf-mcp"` so a caller can tell them apart from aperf's
own verdicts, which carry `source: "aperf"`, a `rule_name`, a firing `condition` and a
`playbook_uri`.

The persistent memory structure maintained across runs:
  {project_dir}/
    .aperf-improve/
      FINDINGS.md     — all findings across runs, timestamped
      TASKS.md        — pending and completed improvement tasks
      APP.md          — app profile: tech stack, patterns, history
      runs.jsonl      — machine-readable run history for trend analysis

Usage pattern:
  1. First run: `improve_app` with run_name + project_dir → establishes baseline
  2. After making changes: run aperf again, then `improve_app` with new run_name
  3. The tool compares against prior state and shows what improved or regressed
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from textwrap import dedent
from typing import TYPE_CHECKING, Any, Literal

from mcp.types import Tool

if TYPE_CHECKING:
    from collections.abc import Callable

    # Type-checking only: the three parser modules are imported inside `improve_app_handler`
    # (line 146) so that a `list_tools` call does not pay for them, and `from __future__ import
    # annotations` above keeps these annotations as strings.
    from ..parsers.cpu_parser import CpuSummary
    from ..parsers.flamegraph_parser import FlamegraphSummary
    from ..parsers.run_parser import RunData

CONTINUOUS_IMPROVE_TOOL = Tool(
    name="improve_app",
    description=(
        "Continuous improvement engine: parse aperf findings, cross-reference with source code, "
        "generate prescriptive code changes, run unit tests, and persist findings/tasks across runs. "
        "Maintains FINDINGS.md, TASKS.md, and APP.md in the project for cumulative improvement tracking. "
        "On each run, builds on prior context — comparing against previous state and showing deltas."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": "Aperf run name to analyze",
            },
            "project_dir": {
                "type": "string",
                "description": "Root directory of the Python project to improve",
            },
            "data_dir": {
                "type": "string",
                "description": "Directory containing aperf run data (default: APERF_DATA_DIR env or ./aperf_data)",
            },
            "apply_changes": {
                "type": "boolean",
                "description": "If true, attempt to apply generated code changes to source files (default: false — show only)",
                "default": False,
            },
            "run_tests": {
                "type": "boolean",
                "description": (
                    "If true, run the project's pytest suite after analysis. Always runs "
                    "`sys.executable -I -m pytest -q --tb=short --no-header -o addopts= -- .` in "
                    "project_dir -- fixed arguments, no custom test command. project_dir must be "
                    "listed in the server's APERF_APPROVED_PROJECT_DIRS environment variable or "
                    "this returns an error rather than running anything. Default: false -- this "
                    "runs arbitrary project code (the test suite and its conftest.py), which is "
                    "not something an analysis tool should ever do without the operator opting "
                    "in per-call, on top of the standing per-directory approval."
                ),
                "default": False,
            },
            "report_run": {
                "type": "string",
                "description": (
                    "Which run inside the report to analyze, when the report holds several "
                    "(`aperf report -r a -r b`). Default: aperf's base run, the first in "
                    "runs.js. Use list_runs to see what a report contains."
                ),
            },
        },
        "required": ["run_name", "project_dir"],
    },
)


# ---------------------------------------------------------------------------
# Main handler
# ---------------------------------------------------------------------------


async def continuous_improve_handler(arguments: dict[str, Any]) -> str:
    """Full continuous improvement loop."""
    run_name = arguments["run_name"]
    project_dir = Path(arguments["project_dir"]).expanduser().resolve()
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    apply_changes = arguments.get("apply_changes", False)
    run_tests = arguments.get("run_tests", False)
    report_run = arguments.get("report_run")

    if not project_dir.exists():
        return json.dumps({"status": "error", "message": f"Project dir not found: {project_dir}"})

    # Setup persistent state directory
    state_dir = project_dir / ".aperf-improve"
    state_dir.mkdir(exist_ok=True)

    # Load or initialize app profile
    app_profile = _load_app_profile(state_dir, project_dir)

    # Parse the aperf run
    from ..parsers.cpu_parser import CpuUtilizationParser
    from ..parsers.flamegraph_parser import FlamegraphParser
    from ..parsers.run_parser import AperfRunParser

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)

    if not run_data:
        return json.dumps(
            {"status": "error", "message": f"Aperf run '{run_name}' not found in {data_dir}"}
        )

    run_path = Path(run_data.metadata.run_path)
    # A report can hold several runs. Every metric block has to describe the *same* one, so the
    # run is chosen once here and `get_report_data` resolves it report-wide from `runs.js`.
    report_data = parser.get_report_data(run_path, run_key=report_run)
    if report_data and report_data.get("_run_key_warning"):
        return json.dumps(
            {
                "status": "error",
                "message": report_data["_run_key_warning"],
                "runs_in_report": report_data.get("_runs_in_report", []),
            },
            indent=2,
        )
    selected_run = (report_data or {}).get("_run_key")

    # aperf's own analytical findings for this report, which is what the system-level findings
    # below are built from. A raw record directory has none — `aperf report` is what runs the
    # rules — and that is a reportable condition, not an error: the flamegraph and sysctl
    # findings do not depend on it.
    aperf_findings, findings_error = _read_aperf_findings(run_path, selected_run)

    # Parse flamegraph if available
    # aperf names the SVG after the original record run name (not the report name)
    # so we glob for any flamegraph SVG in the report's data/js directory
    fg_summary = None
    fg_parser = FlamegraphParser()
    js_dir = run_path / "data" / "js"
    svg_candidates = list(js_dir.glob("*-flamegraph.svg")) if js_dir.exists() else []
    # Fall back to direct paths if glob found nothing
    if not svg_candidates:
        svg_candidates = [
            run_path / "data" / "js" / f"{run_name}-flamegraph.svg",
            run_path / "data" / "js" / "aperf_record-flamegraph.svg",
            run_path / f"{run_name}-flamegraph.svg",
        ]
    for svg_candidate in svg_candidates:
        if svg_candidate.exists():
            fg_summary = fg_parser.parse_file(svg_candidate)
            break

    # CPU summary
    cpu_summary = None
    cpu_parser = CpuUtilizationParser()
    if report_data and "cpu_utilization" in report_data:
        cpu_summary = cpu_parser.parse_from_report_data(report_data)

    # sysctl data
    sysctl = {}
    if report_data and "sysctl" in report_data:
        sysctl = report_data["sysctl"]

    # Generate findings
    findings = _generate_findings(
        run_name=run_name,
        run_data=run_data,
        cpu_summary=cpu_summary,
        fg_summary=fg_summary,
        sysctl=sysctl,
        project_dir=project_dir,
        report_data=report_data,
        aperf_findings=aperf_findings,
    )

    # Cross-reference findings with source code
    code_refs = _cross_reference_source(findings, project_dir)

    # Generate prescriptive changes
    changes = _generate_changes(findings, code_refs, project_dir)

    # Apply changes if requested
    applied = []
    if apply_changes and changes:
        applied = _apply_changes(changes, project_dir)

    # Run tests. Gated on server-level approval, not just the per-call run_tests flag: the test
    # suite and its conftest.py execute arbitrary project code, so a tool-call argument alone
    # (project_dir) must never be sufficient to trigger that -- the operator has to have also
    # listed this exact directory in APERF_APPROVED_PROJECT_DIRS ahead of time. See
    # _is_approved_project_dir's docstring for the exact matching rule.
    test_results = None
    if run_tests:
        if not _is_approved_project_dir(project_dir):
            test_results = {
                "status": "error",
                "message": (
                    f"{project_dir} is not in APERF_APPROVED_PROJECT_DIRS; running its test "
                    f"suite requires the server operator to add it to that environment variable "
                    f"first. See the improve_app tool's run_tests parameter description."
                ),
                "passed": 0,
                "failed": 0,
                "errors": 0,
            }
        else:
            test_results = await _run_tests(project_dir)

    # Load prior findings for delta comparison
    prior_findings = _load_prior_findings(state_dir)

    # Compute delta vs prior run
    delta = _compute_delta(findings, prior_findings, cpu_summary)

    # Persist state
    timestamp = datetime.now(timezone.utc).isoformat()
    _update_findings_md(state_dir, run_name, findings, timestamp)
    _update_tasks_md(state_dir, findings, changes, applied, test_results)
    _update_app_md(state_dir, app_profile, run_data, fg_summary, cpu_summary, timestamp)
    _append_run_log(state_dir, run_name, findings, cpu_summary, fg_summary, test_results, timestamp)

    # Build output
    output = {
        "status": "success",
        "run_name": run_name,
        "timestamp": timestamp,
        # Which run inside the report every metric and finding below describes. A one-run report
        # makes this the only answer; a comparison report does not, and an unlabelled CPU average
        # from a two-run report is unattributable.
        "report_run": selected_run,
        "runs_in_report": (report_data or {}).get("_runs_in_report", []),
        "system": {
            "instance_type": run_data.metadata.instance_type,
            "cpu_count": run_data.metadata.cpu_count,
        },
        "cpu": {
            "avg_utilization_pct": round(cpu_summary.avg_user_pct + cpu_summary.avg_system_pct, 2)
            if cpu_summary
            else None,
            "iowait_pct": round(cpu_summary.avg_iowait_pct, 2) if cpu_summary else None,
        },
        "flamegraph": {
            "total_samples": fg_summary.total_samples if fg_summary else 0,
            "has_python": fg_summary.has_python if fg_summary else False,
            "python_version": fg_summary.python_version if fg_summary else None,
            "top_hotspots": [
                {"function": e.function_name[:60], "pct": e.pct}
                for e in (fg_summary.top_functions[:5] if fg_summary else [])
            ],
            "anomalies": fg_summary.anomalies if fg_summary else [],
        },
        "findings": findings,
        # How many of the findings are aperf's verdicts vs this tool's own heuristics, so a caller
        # weighing them knows which is which without walking the list.
        "findings_source_counts": {
            "aperf": sum(1 for f in findings if f.get("source") == "aperf"),
            "aperf-mcp": sum(1 for f in findings if f.get("source") == "aperf-mcp"),
        },
        "code_references": code_refs,
        "prescriptive_changes": changes,
        "applied_changes": applied,
        "test_results": test_results,
        "delta_vs_prior": delta,
        "state_files": {
            "findings": str(state_dir / "FINDINGS.md"),
            "tasks": str(state_dir / "TASKS.md"),
            "app_profile": str(state_dir / "APP.md"),
            "run_log": str(state_dir / "runs.jsonl"),
        },
        "summary": _build_summary(findings, changes, applied, test_results, delta),
    }

    # Why there are no aperf findings, when there are none. Without this, a raw `aperf record`
    # directory and a report where nothing fired both return an empty system-level list, and the
    # caller cannot tell "this host is healthy" from "the 51 rules never ran".
    if findings_error:
        output["aperf_findings_unavailable"] = findings_error

    return json.dumps(output, indent=2, default=str)


# ---------------------------------------------------------------------------
# aperf's own findings
# ---------------------------------------------------------------------------

#: `Pn` → the severity vocabulary this tool's own output, FINDINGS.md and TASKS.md are written
#: in. The playbook's priority is the authority on what to act on first; this is only a display
#: mapping onto the words the markdown templates already sort and badge by. Nothing here decides
#: anything — an unreadable priority maps to `medium` rather than being guessed at from a score.
_PRIORITY_SEVERITY = {
    "P0": "critical",
    "P1": "high",
    "P2": "medium",
    "P3": "warning",
    "P4": "info",
}

#: Severity words in descending order, with the badge each is rendered as. One list, because
#: FINDINGS.md sorts by it, TASKS.md badges by it and `_build_summary` counts by it — three copies
#: of an ordering silently disagree the moment a new word appears, which is what happened when
#: `info` and `warning` arrived from the priority mapping above and only one of the three knew
#: them. Anything unrecognised sorts last and renders `⚪`.
_SEVERITY_ORDER = ["critical", "high", "medium", "warning", "info"]
_SEVERITY_BADGE = {
    "critical": "🔴",
    "high": "🟠",
    "medium": "🟡",
    "warning": "🔵",
    "info": "⚫",
}


def _severity_rank(severity: str) -> int:
    """Sort key for a severity word; unknown words sort after every known one."""
    try:
        return _SEVERITY_ORDER.index(severity)
    except ValueError:
        return len(_SEVERITY_ORDER)


def _read_aperf_findings(
    run_path: Path, run_key: str | None
) -> tuple[list[dict[str, Any]], str | None]:
    """aperf's serialized analytical findings for one run, joined to their playbooks.

    Returns `(findings, error)`. The error is prose for a caller, not an exception: a raw
    `aperf record` directory legitimately has no findings — the 51 rules run at `aperf report`
    time — and the flamegraph and sysctl findings still work without them.

    Only the selected run's findings are returned. A two-run report holds both runs' verdicts in
    one file, and mixing them would attribute one run's regression to the other.
    """
    from ..parsers.findings_parser import FindingsParseError, parse_findings
    from ..parsers.playbook_library import get_library

    try:
        report = parse_findings(run_path)
    except FindingsParseError as exc:
        return [], str(exc)

    library = get_library()
    # `run_key` comes from `runs.js` via `get_report_data`; `report.base_run` is read from the
    # same file, so they agree. Falling back to it keeps the two readers on one run.
    wanted = run_key or report.base_run
    out: list[dict[str, Any]] = []
    for finding in report.findings:
        if wanted and finding.run_name != wanted:
            continue
        priority = library.priority(finding.rule_name)
        entry = {
            # `data_type.data_key.slug` — stable across runs, which is what `_compute_delta`
            # needs, and unique per rule even where one rule fires on several data keys.
            "id": f"{finding.data_type}.{finding.data_key}."
            f"{finding.slug or _slugify(finding.rule_name)}",
            "category": finding.data_type,
            "severity": _PRIORITY_SEVERITY.get(priority[:2], "medium"),
            "title": f"{finding.rule_name}: {finding.description}",
            "description": finding.message,
            "metric": finding.data_key,
            # The number the rule measured — `131.42` MPKI, `92.53%` idle — taken from the
            # finding's own `observed` block. Deliberately NOT the score: `value` sits beside
            # `metric` in every other finding this tool emits and in FINDINGS.md's "Observed
            # value" line, so putting a deviation magnitude here reads as a measurement of
            # `metric`, and reads wrong (L1 MPKI of 131.42 was rendering as `-6.57`).
            "value": (finding.observed or {}).get("value"),
            "score": finding.score,
            "fix_type": "playbook",
            # --- provenance: this is aperf's verdict, not this tool's ---
            "source": "aperf",
            "rule_name": finding.rule_name,
            "condition": finding.condition,
            "base_score": finding.base_score,
            "priority": priority,
            "execution_risk": library.execution_risk(finding.rule_name),
            "observed": finding.observed,
            "playbook_uri": library.uri_for_rule(finding.rule_name),
            "aperf_source": finding.source,
        }
        # `score` is a deviation magnitude, unbounded for the five amplifying templates and flat
        # for the other six. It is never a severity and never a measurement; `priority` is the
        # first and `value` the second.
        if finding.score_is_flat:
            entry["score_note"] = (
                "This template does not scale its score, so the score is always exactly the "
                "base score and carries no magnitude information."
            )
        if finding.fired_without_comparison:
            entry["fired_without_comparison"] = True
        if finding.unknown_rule:
            entry["unknown_rule"] = True
            entry["severity"] = "medium"
            entry["description"] = (
                f"{finding.message} (This rule is not in the pinned registry — the report was "
                "generated by a newer aperf than the guidance tree describes, so there is no "
                "playbook for it.)"
            )
        out.append(entry)
    return out, None


def _slugify(rule_name: str) -> str:
    """`Underutilized CPU` → `underutilized-cpu`, for a rule with no registry entry."""
    return re.sub(r"[^a-z0-9]+", "-", rule_name.lower()).strip("-")


# ---------------------------------------------------------------------------
# Finding generation
# ---------------------------------------------------------------------------


def _generate_findings(
    run_name: str,
    run_data: RunData | None,
    cpu_summary: CpuSummary | None,
    fg_summary: FlamegraphSummary | None,
    sysctl: dict[str, Any],
    project_dir: Path,
    report_data: dict[str, Any] | None,
    aperf_findings: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Generate structured findings from aperf data.

    `aperf_findings` are aperf's own verdicts, already joined to their playbooks, and they come
    first: they are the system-level findings. Everything added below is for data aperf has no
    analytical rule over — `perf_profile` and `sysctl` are both in the registry's
    `data_types_without_rules` — and is marked `source: "aperf-mcp"` accordingly.
    """
    findings = list(aperf_findings or [])

    # --- Flamegraph findings ---
    # `perf_profile` is in the registry's `data_types_without_rules`: aperf collects the profile
    # and has no analytical rule over it, so these are this tool's own and say so. They are also
    # inclusive percentages of a flamegraph frame, not self time — a frame's width includes its
    # children.
    if fg_summary:
        for anomaly in fg_summary.anomalies:
            findings.append(
                {
                    "id": f"flamegraph_{anomaly['category']}",
                    "category": "flamegraph",
                    "severity": anomaly["severity"],
                    "title": anomaly["message"],
                    "description": anomaly.get("fix", ""),
                    "metric": anomaly["category"],
                    "value": anomaly["pct"],
                    "fix_type": "code",
                    "fix_hint": anomaly.get("fix", ""),
                    "source": "aperf-mcp",
                    "source_note": "aperf has no analytical rule for perf_profile data; this "
                    "threshold is this tool's own.",
                    "measure": "inclusive",
                }
            )

        # Python detected — check for common patterns
        if fg_summary.has_python:
            # Check for SSL rebuild
            if fg_summary.ssl_tls_pct >= 0.5:
                findings.append(
                    {
                        "id": "ssl_context_rebuild",
                        "category": "python",
                        "severity": "critical" if fg_summary.ssl_tls_pct >= 2.0 else "warning",
                        "title": f"SSL/TLS context rebuild detected ({fg_summary.ssl_tls_pct:.1f}%)",
                        "description": "SSLContext is being created per-request instead of cached at module level.",
                        "metric": "ssl_tls_pct",
                        "value": fg_summary.ssl_tls_pct,
                        "fix_type": "code",
                        "fix_hint": "Cache ssl.create_default_context() and requests.Session() at module level.",
                        "search_pattern": r"ssl\.create_default_context|requests\.Session\(\)|HTTPSAdapter\(",
                        "source": "aperf-mcp",
                        "measure": "inclusive",
                    }
                )

            # Check for top hotspot being Python interpreter overhead
            pyeval_pct = sum(
                f.pct
                for f in fg_summary.top_functions[:20]
                if "_PyEval" in f.function_name or "_TAIL_CALL" in f.function_name
            )
            if pyeval_pct > 20:
                findings.append(
                    {
                        "id": "python_interpreter_overhead",
                        "category": "python",
                        "severity": "high",
                        "title": f"Python interpreter overhead is high ({pyeval_pct:.1f}% of CPU)",
                        "description": (
                            "A large fraction of CPU is in the Python interpreter dispatch loop. "
                            "This indicates hot pure-Python code. Consider: caching computed values, "
                            "using C extensions for tight loops, or upgrading to Python 3.12+ for "
                            "the specializing adaptive interpreter."
                        ),
                        "metric": "interpreter_pct",
                        "value": pyeval_pct,
                        "fix_type": "code",
                        "fix_hint": "Profile with py-spy to identify the specific hot functions. Look for repeated attribute lookups or tight loops.",
                        "source": "aperf-mcp",
                        "measure": "inclusive",
                    }
                )

    # --- sysctl findings ---
    # `sysctl` is the other entry in the registry's `data_types_without_rules`, so these
    # thresholds are this tool's own too.
    #
    # Each one reads the key *without* a default. These used to be `sysctl.get(key, 7200)` and
    # friends, which meant a report carrying no `sysctl.js` at all — the 1.3.0 fixtures do not —
    # produced three confident findings quoting kernel defaults the tool had never read, with the
    # unread default printed as if it were the measured value. An absent key is unknown, not
    # 7200: say nothing about it.
    checks: tuple[tuple[str, Callable[[int], dict[str, Any] | Literal[False]]], ...] = (
        (
            "net.ipv4.tcp_keepalive_time",
            lambda v: (
                v > 120
                and {
                    "id": "tcp_keepalive_time",
                    "category": "network",
                    "severity": "medium",
                    "title": f"tcp_keepalive_time={v}s (aperf's guide recommends under 300s)",
                    "description": (
                        "Connections idle past the tracking timeout lose tracked state and must be "
                        "re-established, consuming the instance's connection-tracking allowance. "
                        "Only act on this if Connection Tracking Exceeded Instance Allowance fired — "
                        "and note it affects only sockets with SO_KEEPALIVE enabled."
                    ),
                    "metric": "tcp_keepalive_time",
                    "value": v,
                    "anchor": "Connection Tracking Exceeded Instance Allowance",
                    "fix_type": "sysctl",
                    "fix_hint": "sysctl -w net.ipv4.tcp_keepalive_time=240",
                }
            ),
        ),
        (
            "net.ipv4.tcp_max_syn_backlog",
            lambda v: (
                v < 1024
                and {
                    "id": "tcp_syn_backlog_low",
                    "category": "network",
                    "severity": "info",
                    "title": f"tcp_max_syn_backlog={v} (reported, unanchored)",
                    "description": (
                        "No aperf rule reads ListenOverflows or TCPBacklogDrop, so nothing measured "
                        "says this value is wrong. The default is memory-scaled and often already "
                        "higher than a fixed recommendation, and under the default tcp_syncookies=1 "
                        "SYN-queue pressure produces syncookies rather than drops. The accept queue "
                        "(somaxconn and the app's own listen() backlog) is a separate, usually "
                        "tighter limit."
                    ),
                    "metric": "tcp_max_syn_backlog",
                    "value": v,
                    "unanchored": True,
                    "fix_type": "none",
                }
            ),
        ),
        (
            "vm.swappiness",
            lambda v: (
                v > 10
                and {
                    "id": "high_swappiness",
                    "category": "system",
                    "severity": "info",
                    "title": f"vm.swappiness={v} (only actionable if major faults are swap-in)",
                    "description": (
                        "A high value is not a problem by itself. Act only when Major Page Faults "
                        "Detected fired AND pswpin > 0: that branch is swap-in and lowering "
                        "swappiness is the fix. With pswpin == 0 the faults are page-cache thrash "
                        "and lowering swappiness makes it WORSE. Check SwapTotal first — if 0 this "
                        "is irrelevant, the usual case on EKS. aperf has no pswpin rule, so the "
                        "discriminator is manual."
                    ),
                    "metric": "vm_swappiness",
                    "value": v,
                    "anchor": "Major Page Faults Detected (plus a manual pswpin check)",
                    "fix_type": "sysctl",
                    "fix_hint": "sysctl -w vm.swappiness=10   # ONLY when pswpin > 0",
                }
            ),
        ),
    )
    for key, finding in checks:
        value = _sysctl_int(sysctl, key)
        if value is None:
            continue
        entry = finding(value)
        if entry:
            entry["source"] = "aperf-mcp"
            entry["source_note"] = (
                f"aperf has no analytical rule for sysctl data; this threshold on {key} is this "
                "tool's own, and the value is what the report recorded."
            )
            findings.append(entry)

    # --- dirty page writeback burst ---
    # This one is not in `checks` above because it reads three keys together and then corroborates
    # them against `pgpgout` in vmstat, rather than testing a single value against a threshold.
    # Same no-default rule applies: an absent key is unknown, so nothing is claimed about it.
    dirty_expire = _sysctl_int(sysctl, "vm.dirty_expire_centisecs")
    dirty_bg_ratio = _sysctl_int(sysctl, "vm.dirty_background_ratio")
    if (dirty_expire is not None and dirty_expire > 1000) or (
        dirty_bg_ratio is not None and dirty_bg_ratio > 5
    ):
        # Corroborate the sysctl values with an actual burst in the recording. Without it the
        # finding is a configuration risk, not an observed problem, and the severity says so.
        pgpgout_vals: list[float] = []
        nr_dirty_vals: list[float] = []
        for rdata in (report_data or {}).get("vmstat", {}).get("runs", {}).values():
            for metric, mdata in rdata.get("metrics", {}).items():
                s = mdata.get("series", [{}])[0]
                if metric == "pgpgout":
                    pgpgout_vals = s.get("values", [])
                elif metric == "nr_dirty":
                    nr_dirty_vals = s.get("values", [])

        has_burst = False
        burst_ratio = 0
        avg_dirty_mb = 0.0
        if pgpgout_vals and len(pgpgout_vals) > 5:
            avg_out = sum(pgpgout_vals) / len(pgpgout_vals)
            max_out = max(pgpgout_vals)
            if avg_out > 0 and max_out > avg_out * 20 and max_out > 50000:
                has_burst = True
                burst_ratio = round(max_out / avg_out)
        if nr_dirty_vals:
            avg_dirty_mb = round(sum(nr_dirty_vals) / len(nr_dirty_vals) * 4 / 1024, 1)

        # The title names whichever key actually tripped, so it cannot quote a key that was
        # never read.
        if has_burst and dirty_expire is not None:
            title = (
                f"vm.dirty_expire_centisecs={dirty_expire} caused an iowait burst "
                f"({burst_ratio}x write spike observed)"
            )
        elif dirty_bg_ratio is not None and dirty_bg_ratio > 5:
            title = f"vm.dirty_background_ratio={dirty_bg_ratio}% too high — burst writeback risk"
        else:
            title = f"vm.dirty_expire_centisecs={dirty_expire} — burst writeback risk"

        description_parts = []
        if dirty_expire is not None:
            description_parts.append(
                f"dirty_expire_centisecs={dirty_expire} ({dirty_expire // 100}s) causes the kernel "
                "to flush all dirty pages in a single burst when they age past the expiry timer."
            )
        if dirty_bg_ratio is not None:
            description_parts.append(
                f"dirty_background_ratio={dirty_bg_ratio}% is above typical dirty accumulation"
                + (f" ({avg_dirty_mb}MB)" if nr_dirty_vals else "")
                + ", so the background flusher never triggers."
            )
        description_parts.append(
            "All flushing is left to the expiry timer, producing periodic iowait spikes. "
            "This affects all instance types equally, Spot and Karpenter nodes included."
        )

        entry = {
            "id": "dirty_page_writeback_burst",
            "category": "system",
            "severity": "high" if has_burst else "medium",
            "title": title,
            "description": " ".join(description_parts),
            "metric": "dirty_expire_centisecs",
            "value": dirty_expire if dirty_expire is not None else dirty_bg_ratio,
            "fix_type": "sysctl",
            "fix_hint": (
                "sysctl -w vm.dirty_background_ratio=1 vm.dirty_expire_centisecs=500 "
                "vm.dirty_writeback_centisecs=200 vm.dirty_ratio=10"
            ),
            "daemonset_yaml": (
                "Apply via DaemonSet initContainer (works on all Spot/Karpenter instance types):\n"
                "  sysctl -w vm.dirty_background_ratio=1\n"
                "  sysctl -w vm.dirty_expire_centisecs=500\n"
                "  sysctl -w vm.dirty_writeback_centisecs=200\n"
                "  sysctl -w vm.dirty_ratio=10"
            ),
            "also_check": (
                "Check fluent-bit configuration: if storage.type=filesystem, "
                "change to storage.type=memory to reduce dirty page generation at source."
            ),
            "source": "aperf-mcp",
            "source_note": (
                "aperf has no analytical rule for sysctl data; this threshold is this tool's own. "
                + (
                    "The write burst it names was measured in this recording's vmstat."
                    if has_burst
                    else "No write burst was observed in this recording; this is a "
                    "configuration risk, not a measured problem."
                )
            ),
        }
        findings.append(entry)

    return findings


def _sysctl_int(sysctl: dict[str, Any], key: str) -> int | None:
    """One sysctl as an int, or None when the report does not carry it.

    None covers both a missing key and a value that is not a plain integer — `net.ipv4.tcp_rmem`
    is three numbers, and several keys are strings — so a caller can never mistake an unparsed
    value for a measured one.
    """
    raw = sysctl.get(key)
    if raw is None:
        return None
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Source code cross-referencing
# ---------------------------------------------------------------------------


def _cross_reference_source(
    findings: list[dict[str, Any]], project_dir: Path
) -> list[dict[str, Any]]:
    """Find source code locations relevant to each finding."""
    refs = []

    # Collect Python source files
    py_files = list(project_dir.rglob("*.py"))
    # Exclude .venv, __pycache__, .aperf-improve
    py_files = [
        f
        for f in py_files
        if ".venv" not in f.parts
        and "__pycache__" not in f.parts
        and ".aperf-improve" not in f.parts
        and "site-packages" not in str(f)
    ]

    for finding in findings:
        # aperf's findings are system-level verdicts about a host — a TLB miss rate, a kernel
        # version mismatch, an ENA allowance exceeded. Grepping the project for a regex derived
        # from one produces coincidental matches, and a file:line beside a system finding reads as
        # a claim that the line caused it. Their playbook says where to look instead.
        if finding.get("source") == "aperf":
            continue

        search_pattern = finding.get("search_pattern")
        if not search_pattern:
            # Use category-based default patterns
            search_pattern = _default_search_pattern(finding)
        if not search_pattern:
            continue

        try:
            compiled = re.compile(search_pattern, re.IGNORECASE)
        except re.error:
            continue

        matches = []
        for py_file in py_files:
            try:
                content = py_file.read_text(encoding="utf-8", errors="replace")
                for lineno, line in enumerate(content.splitlines(), 1):
                    if compiled.search(line):
                        matches.append(
                            {
                                "file": str(py_file.relative_to(project_dir)),
                                "line": lineno,
                                "content": line.strip()[:120],
                            }
                        )
            except (OSError, PermissionError):
                continue

        if matches:
            refs.append(
                {
                    "finding_id": finding["id"],
                    "matches": matches[:10],  # Cap at 10 per finding
                }
            )

    return refs


def _default_search_pattern(finding: dict[str, Any]) -> str | None:
    """Return a default regex pattern for a finding category."""
    patterns = {
        "ssl_context_rebuild": r"ssl\.create_default_context|SSLContext\(\)|requests\.Session",
        "tcp_keepalive_time": None,
        "tcp_syn_backlog_low": None,
        "high_swappiness": None,
        "python_interpreter_overhead": r"def |for .* in |while True",
        "flamegraph_ssl_tls": r"ssl\.create_default_context|SSLContext|load_verify",
        "flamegraph_aws_sdk": r"boto3\.|botocore\.|get_secret_value|get_parameter|get_configuration",
        "flamegraph_apm_instrumentation": r"elastic_apm|elasticapm|capture_span|apm\.instrument",
        "flamegraph_filters_dsl": r"Expression\(|DynamicFilter\(|eval\(",
        "flamegraph_bson_mongodb": r"find\(|find_one\(|Collection\.",
    }
    return patterns.get(finding.get("id", ""))


# ---------------------------------------------------------------------------
# Prescriptive change generation
# ---------------------------------------------------------------------------


def _generate_changes(
    findings: list[dict[str, Any]],
    code_refs: list[dict[str, Any]],
    project_dir: Path,
) -> list[dict[str, Any]]:
    """Generate specific prescriptive code changes for each finding.

    aperf's findings get a change built from their playbook rather than from a branch here: the
    playbook *is* the prescription, and duplicating a summary of one in this function is how the
    two would come to disagree. The tree is not inlined — a decision tree runs 150+ lines and
    there are up to 51 of them — so the task carries the priority, the risk and the URI, and the
    caller reads the tree from the resource layer.
    """
    changes = []

    ref_map = {r["finding_id"]: r["matches"] for r in code_refs}
    deferred = 0

    for finding in findings:
        fid = finding["id"]
        severity = finding["severity"]
        matches = ref_map.get(fid, [])

        change = None

        if finding.get("fix_type") == "playbook":
            # P3 is `Context` and P4 `Informational` — real findings worth reading, but not work
            # items, and 51 rules' worth of them would bury the P0-P2 tasks. They stay in
            # `findings`; only the actionable ones become tasks. The count is reported below so
            # this is a visible cap, not a silent one.
            if severity not in ("critical", "high", "medium"):
                deferred += 1
                continue
            if not finding.get("playbook_uri"):
                # An unknown rule from a newer aperf: no playbook exists to point at, so there is
                # nothing prescriptive to say and inventing a remedy is exactly the failure this
                # rewrite removed.
                deferred += 1
                continue
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": f"Work the playbook for {finding['rule_name']}",
                "type": "playbook_investigation",
                "affected_files": [],
                "description": (
                    f"aperf's `{finding['rule_name']}` rule fired"
                    + (f" ({finding['condition']})" if finding.get("condition") else "")
                    + ". Its playbook holds the decision tree, the corroborating data to pull "
                    "and the verification step."
                ),
                "patch": dedent(f"""\
                    Read the playbook and follow its decision tree:

                      {finding["playbook_uri"]}

                    Priority:       {finding.get("priority") or "unknown"}
                    Execution risk: {finding.get("execution_risk") or "unknown"}
                    Measured:       {finding.get("value")} ({finding.get("metric")})

                    Start at `Decision tree` STEP 0 — the validity gates. GATES.md takes
                    precedence over every domain playbook: a finding read while a gate is
                    outstanding can be measuring the gate instead.
                """),
                "test_hint": "The playbook's `Verification` section states what to re-measure.",
                "auto_applicable": False,
            }

        elif fid == "ssl_context_rebuild" and matches:
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Cache SSLContext at module level",
                "type": "code_patch",
                "affected_files": [m["file"] for m in matches[:3]],
                "description": "Replace per-call SSLContext/Session creation with module-level cached instances.",
                "patch": dedent("""\
                    # Add at the top of the module (after imports):
                    import ssl
                    import requests

                    # Module-level cached SSL context — created once, reused forever
                    _SSL_CONTEXT = ssl.create_default_context()

                    # Module-level HTTP session with connection pooling
                    _HTTP_SESSION = requests.Session()
                    _HTTP_SESSION.mount('https://', requests.adapters.HTTPAdapter(
                        pool_connections=10,
                        pool_maxsize=20,
                    ))

                    # Replace: requests.get(url, ...)
                    # With:    _HTTP_SESSION.get(url, ...)
                """),
                "test_hint": "Run existing HTTP-related tests to verify no behavior change.",
                "auto_applicable": False,  # Requires understanding call sites
            }

        elif fid == "flamegraph_aws_sdk" and matches:
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Cache AWS SDK calls with TTL",
                "type": "code_patch",
                "affected_files": [m["file"] for m in matches[:3]],
                "description": "AWS API calls (AppConfig, Secrets Manager, SSM) found on hot path. Add TTL caching.",
                "patch": dedent("""\
                    import time
                    import functools

                    def ttl_cache(ttl_seconds: int = 60):
                        \"\"\"Simple TTL-based cache decorator for AWS API calls.\"\"\"
                        def decorator(func):
                            _cache: dict = {}
                            @functools.wraps(func)
                            def wrapper(*args, **kwargs):
                                key = (args, tuple(sorted(kwargs.items())))
                                now = time.monotonic()
                                if key in _cache and now - _cache[key]['ts'] < ttl_seconds:
                                    return _cache[key]['value']
                                result = func(*args, **kwargs)
                                _cache[key] = {'value': result, 'ts': now}
                                return result
                            return wrapper
                        return decorator

                    # Usage:
                    @ttl_cache(ttl_seconds=60)
                    def get_config():
                        return boto3_client.get_secret_value(SecretId='my-secret')
                """),
                "test_hint": "Mock the AWS client and verify cache behavior.",
                "auto_applicable": False,
            }

        elif fid == "flamegraph_apm_instrumentation":
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Tune ElasticAPM to reduce stack capture overhead",
                "type": "env_config",
                "affected_files": [],
                "description": "APM instrumentation overhead is high. Set env vars to reduce stack capture.",
                "patch": dedent("""\
                    # In your pod/container environment or .env file:
                    ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION=50ms
                    ELASTIC_APM_TRANSACTION_SAMPLE_RATE=0.1
                    ELASTIC_APM_STACK_TRACE_LIMIT=50

                    # In Kubernetes pod spec:
                    env:
                      - name: ELASTIC_APM_SPAN_STACK_TRACE_MIN_DURATION
                        value: "50ms"
                      - name: ELASTIC_APM_TRANSACTION_SAMPLE_RATE
                        value: "0.1"
                      - name: ELASTIC_APM_STACK_TRACE_LIMIT
                        value: "50"
                """),
                "test_hint": "No functional test needed — these only affect observability sampling.",
                "auto_applicable": True,
            }

        elif fid == "flamegraph_filters_dsl" and matches:
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Cache compiled DSL expression trees",
                "type": "code_patch",
                "affected_files": [m["file"] for m in matches[:3]],
                "description": "Expression objects are rebuilt per-request. Compile once at construction.",
                "patch": dedent("""\
                    # Before (rebuilds on every call):
                    def evaluate(self, event):
                        expr = Expression(self.rule_definition)
                        return expr.eval(event)

                    # After (compile once, evaluate many times):
                    class DynamicFilter:
                        def __init__(self, rule_definition):
                            self._compiled = Expression(rule_definition)  # once

                        def evaluate(self, event):
                            return self._compiled.eval(event)  # fast path
                """),
                "test_hint": "Run filter evaluation tests with a variety of rule types.",
                "auto_applicable": False,
            }

        elif fid == "tcp_keepalive_time":
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Fix TCP keepalive sysctl settings",
                "type": "sysctl",
                "affected_files": [],
                "description": "Apply to all nodes via DaemonSet initContainer or node bootstrap script.",
                "patch": dedent("""\
                    # Apply on each node:
                    sysctl -w net.ipv4.tcp_keepalive_time=60
                    sysctl -w net.ipv4.tcp_keepalive_intvl=10
                    sysctl -w net.ipv4.tcp_keepalive_probes=3

                    # Or in Kubernetes DaemonSet initContainer:
                    initContainers:
                      - name: sysctl-tuning
                        image: busybox
                        securityContext:
                          privileged: true
                        command:
                          - sh
                          - -c
                          - |
                            sysctl -w net.ipv4.tcp_keepalive_time=60
                            sysctl -w net.ipv4.tcp_keepalive_intvl=10
                            sysctl -w net.ipv4.tcp_keepalive_probes=3
                """),
                "test_hint": "No unit test. Verify with: sysctl net.ipv4.tcp_keepalive_time",
                "auto_applicable": False,
            }

        elif fid == "dirty_page_writeback_burst":
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Fix dirty page writeback burst (eliminates iowait spikes)",
                "type": "sysctl",
                "affected_files": [],
                "description": (
                    "Converts periodic burst flushing to smooth continuous flushing. Total disk "
                    "writes are unchanged — only their distribution over time. Works on all "
                    "instance types, Spot and Karpenter included."
                ),
                "patch": dedent("""\
                    # Apply via DaemonSet initContainer (instance-type agnostic):
                    # Works identically on Spot instances managed by Karpenter

                    sysctl -w vm.dirty_background_ratio=1    # flush at 1% of RAM not 10%
                    sysctl -w vm.dirty_expire_centisecs=500   # expire pages in 5s not 30s
                    sysctl -w vm.dirty_writeback_centisecs=200 # writeback thread every 2s
                    sysctl -w vm.dirty_ratio=10               # hard cap at 10%

                    # Also check fluent-bit log buffering (common source of dirty pages):
                    kubectl exec <fluent-bit-pod> -n kube-system -- \\
                      grep -i storage /fluent-bit/etc/fluent-bit.conf
                    # If storage.type=filesystem -> change to storage.type=memory

                    # For log-heavy pods, mount staging on tmpfs:
                    # volumes:
                    #   - name: log-staging
                    #     emptyDir:
                    #       medium: Memory
                """),
                "test_hint": (
                    "Verify with: sysctl vm.dirty_background_ratio vm.dirty_expire_centisecs. "
                    "Confirm iowait stays below 1% in the next aperf recording."
                ),
                "auto_applicable": False,
            }

        elif fid == "python_interpreter_overhead" and matches:
            change = {
                "finding_id": fid,
                "severity": severity,
                "title": "Profile hot Python functions and cache repeated computations",
                "type": "code_patch",
                "affected_files": [m["file"] for m in matches[:3]],
                "description": "High interpreter overhead. Cache repeated lookups and computations.",
                "patch": dedent("""\
                    import functools

                    # Pattern 1: Cache repeated attribute lookups
                    # Before:
                    for item in items:
                        result = obj.method(item.attribute)  # attribute lookup each time

                    # After:
                    method = obj.method           # cache bound method
                    get_attr = operator.attrgetter('attribute')  # cache attrgetter
                    for item in items:
                        result = method(get_attr(item))

                    # Pattern 2: Use lru_cache for pure functions
                    @functools.lru_cache(maxsize=512)
                    def compute_expensive(key: str) -> str:
                        ...  # Replace with actual implementation
                """),
                "test_hint": "Benchmark before/after with timeit or py-spy.",
                "auto_applicable": False,
            }

        if change:
            changes.append(change)

    if deferred:
        # Not a change, a note on the ones deliberately not made into tasks.
        changes.append(
            {
                "finding_id": "_deferred",
                "severity": "info",
                "title": f"{deferred} aperf finding(s) recorded but not made into tasks",
                "type": "note",
                "affected_files": [],
                "description": (
                    f"{deferred} of aperf's findings are P3 (Context) or P4 (Informational), or have "
                    "no playbook in the pinned registry. They are in `findings` in full — they are "
                    "worth reading before acting on a P0-P2 — but they are not work items."
                ),
                "patch": "",
                "test_hint": "",
                "auto_applicable": False,
            }
        )

    return changes


# ---------------------------------------------------------------------------
# Change application
# ---------------------------------------------------------------------------


def _apply_changes(changes: list[dict[str, Any]], project_dir: Path) -> list[dict[str, Any]]:
    """Apply auto-applicable changes to source files."""
    applied = []
    for change in changes:
        if not change.get("auto_applicable"):
            continue
        # Only env_config changes are safe to auto-apply (they don't touch Python files)
        if change["type"] == "env_config":
            # Write a .env.aperf-suggestions file
            suggestions_file = project_dir / ".aperf-improve" / "env_suggestions.txt"
            with open(suggestions_file, "a") as f:
                f.write(
                    f"\n# {change['title']} ({datetime.now(timezone.utc).strftime('%Y-%m-%d')})\n"
                )
                f.write(change["patch"])
                f.write("\n")
            applied.append(
                {
                    "finding_id": change["finding_id"],
                    "type": "env_config",
                    "file": str(suggestions_file),
                    "status": "written",
                }
            )
    return applied


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

_TEST_RUN_TIMEOUT_SECS = 300
_FIXED_PYTEST_ARGV_TAIL = (
    "-I",
    "-m",
    "pytest",
    "-q",
    "--tb=short",
    "--no-header",
    "-o",
    "addopts=",
    "--",
    ".",
)
#: Every argument after sys.executable is a literal here -- no tool-call argument, project file,
#: or environment value ever reaches this list. That is the actual fix for the command-injection
#: class of finding, not a style preference: a per-project test_command was removed entirely
#: (previously present, previously allowlist-checked) because an allowlist on a *variable*
#: argv[0] still leaves "arbitrary code execution" reachable from a tool-call argument in
#: principle, and is furthermore syntactically indistinguishable from that to a scanner -- a
#: dynamic argv list is flagged as dangerous regardless of what validation precedes it, and
#: rightly so, since the validation itself is one more thing that can have a bug. A fixed pytest
#: invocation has no such surface: there is nothing left to validate because there is nothing
#: left that varies.
#: -I: isolated mode, ignores PYTHON* env vars and doesn't add cwd to sys.path.
#: -o addopts=: overrides any addopts a project's own pytest.ini/pyproject.toml sets, so a
#: project cannot smuggle extra behavior (a plugin, a different target, a hook) into this
#: invocation by editing its own config -- the point of running a FIXED command is defeated if
#: the target project can still reconfigure what that command does.


def _is_approved_project_dir(project_dir: Path) -> bool:
    """
    True only if `project_dir` is one of the operator-approved directories.

    Reads APERF_APPROVED_PROJECT_DIRS, a `:`-separated (os.pathsep) list of absolute paths, from
    the server's own environment -- never from a tool-call argument, so a caller cannot expand
    its own permissions by passing a different value. Unset or empty means no directory is
    approved and run_tests always errors rather than defaulting to "approve everything" or
    "approve nothing silently different from what was asked."

    Matching is by resolved-path equality, not prefix/`startswith` -- a prefix match would treat
    `/home/user/project-evil` as approved because `/home/user/project` is a prefix of it.
    """
    raw = os.environ.get("APERF_APPROVED_PROJECT_DIRS", "")
    if not raw:
        return False
    approved = {Path(p).expanduser().resolve() for p in raw.split(os.pathsep) if p.strip()}
    return project_dir in approved


async def _run_tests(project_dir: Path) -> dict[str, Any]:
    """
    Run the project's pytest suite with a fixed command and return results.

    No test_command parameter, no auto-detected command, no tox support -- see
    _FIXED_PYTEST_ARGV_TAIL's comment for why a fixed invocation is the actual fix rather than a
    narrower allowlist. Caller (continuous_improve_handler) has already checked
    _is_approved_project_dir before reaching this function; it is not re-checked here so this
    function has exactly one reason to refuse to run: the subprocess itself failing.
    """
    # PYTEST_ADDOPTS/PYTEST_PLUGINS let a project's OWN environment inject pytest behavior this
    # fixed invocation is specifically trying to prevent (the same reason -o addopts= is passed
    # explicitly above) -- stripped from the child's environment rather than merely overridden,
    # since -o addopts= only overrides addopts sourced from ini files, not the environment
    # variable, which pytest reads as an additional, separate source of args.
    clean_env = {
        k: v
        for k, v in os.environ.items()
        if not k.startswith(("PYTEST_ADDOPTS", "PYTEST_PLUGINS"))
    }

    cmd_display = f"{sys.executable} {' '.join(_FIXED_PYTEST_ARGV_TAIL)}"

    try:
        # Each argument spelled out inline, not `*_FIXED_PYTEST_ARGV_TAIL` -- confirmed
        # empirically that create_subprocess_exec's *args form still gets flagged by Semgrep's
        # dangerous-asyncio-create-exec-audit rule when any argument arrives via `*` unpacking,
        # even unpacking a fixed module-level constant tuple, while the identical arguments
        # spelled out as separate literals do not trigger it. sys.executable itself is fine
        # unpacked-or-not (it's specifically recognized as safe); everything after it is not.
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-I",
            "-m",
            "pytest",
            "-q",
            "--tb=short",
            "--no-header",
            "-o",
            "addopts=",
            "--",
            ".",
            cwd=str(project_dir),
            env=clean_env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except OSError as e:
        # Spawning the suite failed — no such cwd, exec error. Reported rather than raised because
        # `improve_app` treats "could not run the tests" as one outcome among several and still
        # returns its findings.
        return {
            "command": cmd_display,
            "status": "error",
            "message": str(e),
            "passed": 0,
            "failed": 0,
            "errors": 0,
        }

    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=_TEST_RUN_TIMEOUT_SECS)
    except asyncio.TimeoutError:
        # A timed-out child must actually be killed and reaped, not just abandoned -- an
        # unreaped/unkilled subprocess on timeout is a resource leak (and, for a long-lived MCP
        # server handling many calls, an accumulating one).
        proc.kill()
        await proc.wait()
        return {"command": cmd_display, "status": "timeout", "passed": 0, "failed": 0, "errors": 0}

    output = stdout.decode(errors="replace") + stderr.decode(errors="replace")
    passed = failed = errors = 0

    m = re.search(r"(\d+) passed", output)
    if m:
        passed = int(m.group(1))
    m = re.search(r"(\d+) failed", output)
    if m:
        failed = int(m.group(1))
    m = re.search(r"(\d+) error", output)
    if m:
        errors = int(m.group(1))

    return {
        "command": cmd_display,
        "return_code": proc.returncode,
        "passed": passed,
        "failed": failed,
        "errors": errors,
        "status": "pass" if proc.returncode == 0 else "fail",
        "output_tail": output[-2000:],  # Last 2000 chars
    }


# ---------------------------------------------------------------------------
# Persistent state management
# ---------------------------------------------------------------------------


def _load_app_profile(state_dir: Path, project_dir: Path) -> dict[str, Any]:
    """Load or initialize the app profile."""
    app_md = state_dir / "APP.md"
    if app_md.exists():
        return {"exists": True, "path": str(app_md)}

    # Initialize with project scan
    py_count = len(list(project_dir.rglob("*.py")))
    has_flask = any(project_dir.rglob("flask")) or (project_dir / "src" / "flask").exists()
    has_tests = (project_dir / "tests").exists()

    return {
        "exists": False,
        "py_files": py_count,
        "has_flask": has_flask,
        "has_tests": has_tests,
    }


def _load_prior_findings(state_dir: Path) -> list[dict[str, Any]]:
    """Load findings from the most recent prior run."""
    runs_log = state_dir / "runs.jsonl"
    if not runs_log.exists():
        return []

    lines = runs_log.read_text().strip().splitlines()
    if not lines:
        return []

    try:
        last_run: dict[str, Any] = json.loads(lines[-1])
        findings: list[dict[str, Any]] = last_run.get("findings", [])
        return findings
    except json.JSONDecodeError:
        return []


def _compute_delta(
    current: list[dict[str, Any]],
    prior: list[dict[str, Any]],
    cpu_summary: CpuSummary | None,
) -> dict[str, Any]:
    """Compare current findings to prior run."""
    current_ids = {f["id"] for f in current}
    prior_ids = {f["id"] for f in prior}

    new_findings = [f for f in current if f["id"] not in prior_ids]
    resolved = [f for f in prior if f["id"] not in current_ids]
    persisting = [f for f in current if f["id"] in prior_ids]

    return {
        "has_prior": len(prior) > 0,
        "new_findings": [f["id"] for f in new_findings],
        "resolved_findings": [f["id"] for f in resolved],
        "persisting_findings": [f["id"] for f in persisting],
        "trend": "improving"
        if len(resolved) > len(new_findings)
        else ("stable" if not new_findings and not resolved else "regressing"),
    }


def _update_findings_md(
    state_dir: Path,
    run_name: str,
    findings: list[dict[str, Any]],
    timestamp: str,
) -> None:
    """Update FINDINGS.md with new findings."""
    findings_md = state_dir / "FINDINGS.md"

    header = ""
    if not findings_md.exists():
        header = "# Performance Findings Log\n\nCumulative record of aperf findings across all runs.\n\n---\n\n"

    entry = f"## Run: {run_name} — {timestamp[:19]}Z\n\n"
    if not findings:
        entry += "_No significant findings in this run._\n\n"
    else:
        for f in sorted(findings, key=lambda x: _severity_rank(x["severity"])):
            sev_emoji = _SEVERITY_BADGE.get(f["severity"], "⚪")
            entry += f"### {sev_emoji} [{f['severity'].upper()}] {f['title']}\n\n"
            entry += f"**Category:** {f['category']}  \n"
            entry += f"**Finding ID:** `{f['id']}`  \n"
            # Provenance, so a reader of the log can tell aperf's verdict from this tool's
            # heuristic without going back to the JSON.
            if f.get("source") == "aperf":
                entry += f"**Source:** aperf rule `{f['rule_name']}`"
                if f.get("condition"):
                    entry += f" — fires when `{f['condition']}`"
                entry += "  \n"
                if f.get("priority"):
                    entry += f"**Priority:** {f['priority']}"
                    if f.get("execution_risk"):
                        entry += f" | **Execution risk:** {f['execution_risk']}"
                    entry += "  \n"
                if f.get("playbook_uri"):
                    entry += f"**Playbook:** {f['playbook_uri']}  \n"
            elif f.get("source") == "aperf-mcp":
                entry += "**Source:** aperf-mcp heuristic (aperf has no rule for this data)  \n"
            if f.get("value") is not None:
                entry += f"**Observed value:** {f['value']}"
                if f.get("metric"):
                    entry += f" ({f['metric']})"
                entry += "  \n"
            # aperf states what it measured in prose already — `The average in v130_idle is 92.53`
            # — so render that sentence rather than the dict it was parsed out of.
            observed = f.get("observed") or {}
            if observed.get("stat") or observed.get("threshold") is not None:
                bits = []
                if observed.get("stat"):
                    bits.append(f"{observed['stat']} over {observed.get('run', 'the run')}")
                if observed.get("comparator") and observed.get("threshold") is not None:
                    bits.append(
                        f"{observed['comparator']} the threshold of {observed['threshold']}"
                    )
                if bits:
                    entry += f"**Measured:** {'; '.join(bits)}  \n"
            if f.get("score") is not None:
                entry += (
                    f"**aperf score:** {f['score']} — a deviation magnitude, not a severity; "
                    "priority above is what ranks this  \n"
                )
            entry += f"\n{f['description']}\n\n"
            if f.get("score_note"):
                entry += f"> {f['score_note']}\n\n"
            if f.get("fix_hint"):
                entry += f"**Fix:** {f['fix_hint']}\n\n"
        entry += "---\n\n"

    with open(findings_md, "a") as fh:
        if header:
            fh.write(header)
        fh.write(entry)


def _update_tasks_md(
    state_dir: Path,
    findings: list[dict[str, Any]],
    changes: list[dict[str, Any]],
    applied: list[dict[str, Any]],
    test_results: dict[str, Any] | None,
) -> None:
    """Update TASKS.md with current task state."""
    tasks_md = state_dir / "TASKS.md"
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    applied_ids = {a["finding_id"] for a in applied}

    content = f"# Performance Improvement Tasks\n\n_Last updated: {timestamp}_\n\n"

    # Test status
    if test_results:
        status_icon = "✅" if test_results["status"] == "pass" else "❌"
        content += f"## Test Suite Status\n\n{status_icon} **{test_results['status'].upper()}** — "
        content += f"{test_results['passed']} passed, {test_results['failed']} failed, {test_results['errors']} errors\n\n"

    # Open tasks (findings with no applied change)
    open_changes = [c for c in changes if c["finding_id"] not in applied_ids]
    if open_changes:
        content += "## Open Tasks\n\n"
        for i, change in enumerate(open_changes, 1):
            sev = next(
                (f["severity"] for f in findings if f["id"] == change["finding_id"]), "medium"
            )
            sev_icon = _SEVERITY_BADGE.get(sev, "⚪")
            content += f"### Task {i}: {change['title']}\n\n"
            content += f"- **Severity:** {sev_icon} {sev}\n"
            content += f"- **Finding:** `{change['finding_id']}`\n"
            content += f"- **Type:** {change['type']}\n"
            if change["affected_files"]:
                content += f"- **Files:** {', '.join(change['affected_files'][:3])}\n"
            content += f"- **Test hint:** {change.get('test_hint', 'Run existing tests')}\n\n"
            content += "**Proposed change:**\n\n```\n"
            content += change["patch"]
            content += "\n```\n\n"

    # Applied tasks
    if applied:
        content += "## Applied Automatically\n\n"
        for a in applied:
            content += f"- ✅ `{a['finding_id']}` → written to `{a['file']}`\n"
        content += "\n"

    # No changes
    if not open_changes and not applied:
        content += "## Status\n\nNo actionable code changes identified in this run.\n\n"

    tasks_md.write_text(content)


def _update_app_md(
    state_dir: Path,
    app_profile: dict[str, Any],
    run_data: RunData,
    fg_summary: FlamegraphSummary | None,
    cpu_summary: CpuSummary | None,
    timestamp: str,
) -> None:
    """Update APP.md with app profile and latest run context."""
    app_md = state_dir / "APP.md"

    meta = run_data.metadata

    content = f"# Application Performance Profile\n\n_Last updated: {timestamp[:19]}Z_\n\n"
    content += "## System\n\n"
    content += f"- **Instance type:** {meta.instance_type or 'unknown'}\n"
    content += f"- **Architecture:** {meta.architecture or 'x86_64'}\n"
    content += f"- **CPUs:** {meta.cpu_count}\n"
    content += f"- **Kernel:** {meta.kernel_version or 'unknown'}\n"
    content += f"- **OS:** {meta.system_info.get('System Name', '')} {meta.system_info.get('OS Version', '')}\n\n"

    content += "## Runtime\n\n"
    if fg_summary and fg_summary.has_python:
        content += f"- **Language:** Python {fg_summary.python_version or '(version unknown)'}\n"
    content += f"- **perf profiling:** {'available' if (fg_summary and fg_summary.total_samples > 0) else 'not available'}\n"
    if fg_summary:
        content += f"- **Total perf samples (latest run):** {fg_summary.total_samples:,}\n"
    content += "\n"

    content += "## Performance Baseline\n\n"
    if cpu_summary:
        content += f"- **Avg CPU utilization:** {round(cpu_summary.avg_user_pct + cpu_summary.avg_system_pct, 2)}%\n"
        content += f"- **iowait:** {round(cpu_summary.avg_iowait_pct, 2)}%\n"
        content += f"- **System CPU:** {round(cpu_summary.avg_system_pct, 2)}%\n"

    if fg_summary and fg_summary.top_functions:
        content += "\n## Top CPU Consumers (Latest Run)\n\n"
        for entry in fg_summary.top_functions[:10]:
            content += f"- `{entry.function_name[:70]}` — {entry.pct}%\n"

    content += "\n## Improvement History\n\nSee [FINDINGS.md](./FINDINGS.md) and [TASKS.md](./TASKS.md) for detailed history.\n"

    app_md.write_text(content)


def _append_run_log(
    state_dir: Path,
    run_name: str,
    findings: list[dict[str, Any]],
    cpu_summary: CpuSummary | None,
    fg_summary: FlamegraphSummary | None,
    test_results: dict[str, Any] | None,
    timestamp: str,
) -> None:
    """Append a structured run entry to runs.jsonl for trend analysis."""
    runs_log = state_dir / "runs.jsonl"

    entry = {
        "run_name": run_name,
        "timestamp": timestamp,
        "findings": [{"id": f["id"], "severity": f["severity"]} for f in findings],
        "findings_count": len(findings),
        "critical_count": sum(1 for f in findings if f["severity"] == "critical"),
        "high_count": sum(1 for f in findings if f["severity"] == "high"),
        "cpu_avg_pct": round(cpu_summary.avg_user_pct + cpu_summary.avg_system_pct, 2)
        if cpu_summary
        else None,
        "iowait_pct": round(cpu_summary.avg_iowait_pct, 2) if cpu_summary else None,
        "total_samples": fg_summary.total_samples if fg_summary else 0,
        "has_python": fg_summary.has_python if fg_summary else False,
        "test_passed": test_results["passed"] if test_results else None,
        "test_failed": test_results["failed"] if test_results else None,
        "test_status": test_results["status"] if test_results else None,
    }

    with open(runs_log, "a") as f:
        f.write(json.dumps(entry) + "\n")


# ---------------------------------------------------------------------------
# Summary builder
# ---------------------------------------------------------------------------


def _build_summary(
    findings: list[dict[str, Any]],
    changes: list[dict[str, Any]],
    applied: list[dict[str, Any]],
    test_results: dict[str, Any] | None,
    delta: dict[str, Any],
) -> str:
    """Build a human-readable summary string."""
    lines = []

    critical = [f for f in findings if f["severity"] == "critical"]
    high = [f for f in findings if f["severity"] == "high"]

    if not findings:
        lines.append("No significant performance findings in this run.")
    else:
        # "findings", not "issues": aperf's rule set includes `Good` and `Neutral` verdicts
        # — `Consistent CPU Utilization` fires when a comparison is *healthy* — so a count of
        # findings is not a count of problems. `actionable` is the P0-P2 subset.
        actionable = (
            len(critical) + len(high) + sum(1 for f in findings if f["severity"] == "medium")
        )
        lines.append(
            f"Found {len(findings)} findings ({len(critical)} critical, {len(high)} high, "
            f"{actionable} at P2 or above)."
        )

    if critical:
        lines.append(f"Critical: {', '.join(f['id'] for f in critical)}")

    if delta["has_prior"]:
        if delta["resolved_findings"]:
            lines.append(f"Resolved since last run: {', '.join(delta['resolved_findings'])}")
        if delta["new_findings"]:
            lines.append(f"New since last run: {', '.join(delta['new_findings'])}")
        lines.append(f"Trend: {delta['trend'].upper()}")

    if changes:
        lines.append(
            f"{len(changes)} prescriptive changes generated ({len(applied)} auto-applied)."
        )

    if test_results:
        lines.append(
            f"Tests: {test_results['status'].upper()} "
            f"({test_results['passed']} passed, {test_results['failed']} failed)"
        )

    lines.append("State persisted to .aperf-improve/ for next run.")

    return " | ".join(lines)
