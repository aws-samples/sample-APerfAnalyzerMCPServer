# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: graviton_readiness

The Graviton modernization path plus real ARM64 dependency-compatibility analysis, as
a standalone answer — without generating a full HTML report or asking the caller to
also pick a general right-sizing strategy.

Two pieces, both real, never a template guess:
  1. `graviton_candidate` — from `rightsizer.recommend_graviton_equivalent`, the SAME
     benchmark-backed function `generate_html_report`'s ARM Modernization tab and
     `get_right_sizing`'s `graviton_equivalent` field use. `None` when there is nothing
     to modernize to (already Graviton, no eligible candidate, or insufficient data).
  2. `dependency_analysis` — from `parsers.dep_analyzer.analyze_dep_file` (the ARM64-
     blocker-aware analyzer `generate_html_report` feeds into `arm64_blocker_count`) —
     NOT `dependency_analyzer.py`'s `analyze_app_context` tool, which has no Graviton/
     ARM64 logic at all and answers a different question (framework/container tuning).
     When no `dep_file` is supplied, this tool says so explicitly and returns
     instructions for obtaining one, rather than silently omitting the section.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from mcp.types import Tool

GRAVITON_READINESS_TOOL = Tool(
    name="graviton_readiness",
    description=(
        "Report the Graviton (ARM64) modernization path for an aperf run: the "
        "benchmark-backed candidate instance (same engine as get_right_sizing's "
        "graviton_equivalent field and generate_html_report's ARM Modernization tab), "
        "plus real dependency-compatibility analysis if a dep_file is provided "
        "(pom.xml, requirements.txt, package.json, Cargo.toml, go.mod, composer.json, "
        "Gemfile) — BLOCKER/DEGRADED/VERIFY/CLEAR per dependency, not a guess. If no "
        "dep_file is given, states that explicitly and returns instructions for "
        "obtaining one, rather than silently skipping ARM64 compatibility. Returns "
        "graviton_candidate=null when the workload is already on Graviton or no "
        "eligible candidate exists."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "data_dir": {"type": "string"},
            "dep_file": {
                "type": "string",
                "description": (
                    "Path to a dependency manifest (pom.xml, requirements.txt, "
                    "package.json, Cargo.toml, go.mod, composer.json, Gemfile) for "
                    "real ARM64 blocker/degraded/verify analysis. Omit to get the "
                    "Graviton candidate only, with an explicit note that dependency "
                    "compatibility was not checked."
                ),
            },
            "customer_priority": {
                "type": "string",
                "description": (
                    "The customer's stated priority, e.g. 'cost' or 'performance'. "
                    "Defaults to cost-first ranking when omitted — see get_right_sizing "
                    "for the same default."
                ),
            },
        },
        "required": ["run_name"],
    },
)


def _dependency_analysis_json(dep_file: str) -> dict[str, Any]:
    from ..parsers.dep_analyzer import analyze_dep_file

    try:
        analysis = analyze_dep_file(Path(dep_file))
    except Exception as e:
        return {
            "status": "parse_error",
            "message": f"Could not analyze {dep_file!r}: {e}",
        }

    if analysis.parse_errors:
        return {
            "status": "parse_error",
            "message": "; ".join(analysis.parse_errors),
        }

    def _entries(entries: list[Any]) -> list[dict[str, Any]]:
        return [
            {
                "name": e.name,
                "version": e.version,
                "reason": e.reason,
                "action": e.action,
                "verification": e.verification,
            }
            for e in entries
        ]

    return {
        "status": "analyzed",
        "language": analysis.language,
        "dep_file_format": analysis.dep_file_format,
        "total_count": analysis.total_count,
        "blockers": _entries(analysis.blockers),
        "degradeds": _entries(analysis.degradeds),
        "verifies": _entries(analysis.verifies),
        # Clears are the bulk of a real manifest and carry no actionable content beyond
        # "checked, fine" — counted, not enumerated, to keep this response proportionate
        # to what a caller actually needs to act on.
        "clears_count": len(analysis.clears),
    }


async def graviton_readiness_handler(arguments: dict[str, Any]) -> str:
    run_name = arguments["run_name"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    dep_file = arguments.get("dep_file")

    from .rightsizer import is_cost_priority

    cost_priority = is_cost_priority(arguments.get("customer_priority"))

    from ..instance_types import is_graviton as _is_graviton
    from ..language_detector import detect_primary_language
    from ..parsers.cpu_parser import CpuUtilizationParser
    from ..parsers.dep_analyzer import language_dep_instructions
    from ..parsers.memory_parser import MemoryParser
    from ..parsers.pmu_parser import PmuParser
    from ..parsers.run_parser import AperfRunParser
    from .rightsizer import recommend_graviton_equivalent
    from .workload_classifier import classify

    parser = AperfRunParser(base_dir=data_dir)
    run_data = parser.parse_run(run_name)
    if not run_data:
        return json.dumps({"status": "error", "message": f"Run '{run_name}' not found"})

    run_path = Path(run_data.metadata.run_path)
    report_data = parser.get_report_data(run_path) or {}

    cpu_summary = CpuUtilizationParser().parse_from_report_data(report_data)
    pmu_summary = PmuParser().parse_from_report_data(report_data)
    mem_summary = MemoryParser().parse_from_report_data(report_data)

    aperf_findings = None
    try:
        from ..parsers.findings_parser import FindingsParseError, parse_findings

        aperf_findings = parse_findings(run_path)
    except (FindingsParseError, OSError, ValueError, TypeError, AttributeError):
        aperf_findings = None

    profile = classify(
        cpu_summary=cpu_summary,
        pmu_summary=pmu_summary,
        mem_summary=mem_summary,
        aperf_findings=aperf_findings,
    )

    # Same unit-sanity guard `get_right_sizing`/`generate_html_report` both apply —
    # see their own comments for the real 256 GB r6g.8xlarge case that motivated it.
    _MAX_PLAUSIBLE_MB = 32 * 1024 * 1024
    capacity_gb: float | None = None
    total_mb = getattr(mem_summary, "total_mb", None) if mem_summary else None
    if total_mb:
        total_mb = float(total_mb)
        while total_mb > _MAX_PLAUSIBLE_MB:
            total_mb /= 1024.0
        capacity_gb = total_mb / 1024.0

    # Dependency analysis first, so its blocker count feeds the candidate's own risk/
    # caveat wording — same ordering `generate_html_report` uses.
    dependency_analysis: dict[str, Any]
    arm64_blocker_count = 0
    if dep_file:
        dependency_analysis = _dependency_analysis_json(dep_file)
        arm64_blocker_count = len(dependency_analysis.get("blockers", []))
    else:
        language_guess = detect_primary_language(report_data)
        dependency_analysis = {
            "status": "not_provided",
            "message": (
                "No dep_file was provided, so ARM64 dependency compatibility was not "
                "checked. The Graviton candidate below reflects hardware capability "
                "only — native library compatibility is unverified."
            ),
            "how_to_provide": language_dep_instructions(language_guess.language or "unknown"),
            "detected_language": language_guess.language or None,
            "detected_language_confidence": language_guess.confidence,
        }

    graviton_candidate = recommend_graviton_equivalent(
        current_instance=run_data.metadata.instance_type,
        profile=profile,
        memory_capacity_gb=capacity_gb,
        cost_priority=cost_priority,
        arm64_blocker_count=arm64_blocker_count,
    )

    response: dict[str, Any] = {
        "status": "success",
        "run_name": run_name,
        "current_instance": run_data.metadata.instance_type,
        "graviton_candidate": (
            {
                "instance_type": graviton_candidate.instance_type,
                "vcpu": graviton_candidate.vcpu,
                "memory_gb": round(graviton_candidate.memory_gb, 1),
                "risk": graviton_candidate.risk,
                "direction": graviton_candidate.direction,
                "price_per_hour_usd": graviton_candidate.price_per_hour,
                "why": graviton_candidate.customer_summary,
                "caveats": graviton_candidate.caveats,
            }
            if graviton_candidate is not None
            else None
        ),
        "graviton_candidate_reason": (
            None
            if graviton_candidate is not None
            else (
                "Already on Graviton — nothing to modernize to."
                if _is_graviton(run_data.metadata.instance_type)
                else "No eligible Graviton candidate meets this workload's measured "
                "requirements, or the data could not support an assessment."
            )
        ),
        "dependency_analysis": dependency_analysis,
        "must_validate": (
            "This is a starting point based on hardware capability, not a prediction "
            "of your application's behaviour. Only a real workload test on the "
            "candidate instance will show whether it performs acceptably."
        ),
    }
    return json.dumps(response, indent=2, default=str)
