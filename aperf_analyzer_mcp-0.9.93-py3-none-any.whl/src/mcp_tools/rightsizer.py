# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Right-sizing engine — benchmark-backed, conservative by default.

Takes a `WorkloadProfile` plus the current instance and proposes candidates from the
independent benchmark data (`src/bench_data.py`). Two strategies:

  **conservative (low risk)** — ONE step on the size ladder, up or down.
  **aggressive (high risk)**  — the best fit regardless of distance.

Why conservative is one step, not "whatever the utilisation math allows"
-----------------------------------------------------------------------
Worked against a real case: `c5a.24xlarge` observed at 10% peak CPU. Utilisation math
(10% of capacity, plus a 50% safety buffer) permits a machine **6.7x slower**. The
defensible answer is `c5.9xlarge`, which is **2.59x slower**. Utilisation alone is
therefore not a sufficient gate — an aperf capture is a window, not a year, and a low
peak may simply mean the capture missed the busy hour. One step keeps the move
verifiable and repeatable: re-measure, then step again.

Growing matters as much as shrinking. When demand exceeds current capacity the
conservative proposal is one step UP.

CPU eligibility: projected utilization, not a fixed buffer
------------------------------------------------------------
A candidate is eligible on CPU when the observed peak, PROJECTED onto that candidate's
own c-ray score, stays under the configurable ceiling (`thresholds.max_projected_utilization_pct()`,
default 50%, overridable via `APERF_MAX_PROJECTED_UTILIZATION_PCT`). "Projected"
means: what would this exact peak become if the workload ran on the candidate instead,
scaled by the two instances' relative throughput. Replaced a fixed multiplicative floor
(`current throughput * peak * 1.5x buffer`) after it excluded `i7i.xlarge` for a
Gunicorn workload at 34.6% peak by about 6% — the floor said "not enough throughput";
the ceiling says the more legible thing, "would put you at 71% utilization", which is
also the number the buffer-based floor could not directly report.

Selection order
---------------
1. Hard demand filters (CPU, memory bandwidth, memory capacity) with a noise band.
2. Graviton-first — already on Graviton means Graviton-only unless nothing fits.
3. Variant affinity — an `n`/`d`/`gn`/... suffix encodes hardware the benchmark cannot
   see, so it is preserved where possible.
4. Memory-pressure branch — under real bandwidth pressure, bandwidth outranks price.
5. Price — cheapest survivor.

Returning nothing is a valid answer. The user's instruction: it is OK to provide no
option, it is worse to provide a bad one.

INTERNAL/CUSTOMER SPLIT: benchmark values live only in `RightSizingCandidate.internal`.
`customer_summary` is prose with no number that could be inverted into a score.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .. import bench_data as bench
from ..instance_types import InstanceType, parse
from ..thresholds import SIZING_SAFETY_BUFFER_PCT, max_projected_utilization_pct
from . import pricing
from .workload_classifier import Confidence, Pressure, WorkloadProfile

#: Must beat a demand by more than the documented run-to-run spread to count.
_NOISE = bench.NOISE_BAND_PCT / 100.0

#: Family classes that are PURPOSE-BUILT and may never be swapped for a general family,
#: in either direction. Keyed by the leading letters of the family name.
#:
#: The general-purpose classes — `c` (compute), `m` (balanced), `r` (memory), `t`
#: (burstable) — are interchangeable when the measured demands are met, because they
#: differ in the CPU:memory ratio the benchmark can see. These do not:
#:
#:   i, im, is  local NVMe storage — the entire reason the family exists. `i8g` is not a
#:              cheaper `r8g`; it is a storage instance whose local disks a replacement
#:              without them silently removes.
#:   x, u       very-high-memory / in-memory-database platforms, with capacity ratios and
#:              pricing structures that make them non-substitutable both ways.
#:   hpc        cluster-networking-optimised, sold for tightly-coupled MPI workloads.
#:   g, p, inf, trn, dl, f, vt
#:              accelerator families (GPU, Inferentia, Trainium, FPGA, video). Neither
#:              c-ray nor STREAM measures the accelerator at all, so a benchmark
#:              comparison says nothing about whether a swap is viable.
#:
#: Neither benchmark can see local disks, an accelerator, or a cluster fabric, so the
#: engine has no basis on which to trade them away. A cross-class proposal is exactly the
#: "bad option" that is worse than returning nothing.
_SPECIAL_CLASSES = ("im", "is", "i", "x", "u", "hpc", "inf", "trn", "dl", "vt", "g", "p", "f")


def is_cost_priority(customer_priority: str | None) -> bool:
    """
    Whether a customer's stated `app_context["customer_priority"]` should drive
    cost-first ranking (see `_rank`'s docstring for what this flips).

    Not a bare `== "cost"` check: `hooks/aperf_context_hook.py`'s own questionnaire
    suggests the example answer `"cost-reduction"` for this field, and an exact-match
    comparison against `"cost"` alone treated that real, hook-suggested answer as a
    NON-cost priority — flipping the tiebreak to bandwidth-first and recommending an
    oversized, expensive candidate (`m8g.48xlarge` at $8.62/hr, 192 vCPU) to a customer
    who had explicitly said they wanted to reduce cost. Verified against a real capture
    where `customer_priority="cost-reduction"` changed the Graviton pick from
    `c9g.xlarge` ($0.17/hr) to `m8g.48xlarge` purely because of this string mismatch.
    Absent priority still defaults to cost-first, per `recommend`'s own docstring.
    """
    priority = (customer_priority or "cost").strip().lower()
    return "cost" in priority or priority in ("migration-readiness",)


def _family_class(letters: str) -> str:
    """
    The purpose class of a family, or `"general"`.

    Longest prefix wins so `im`/`is` are not mistaken for `i`, and so `hpc` is not read as
    a general `h`. `g`/`p`/`f` are checked last because they are single letters that would
    otherwise shadow longer names.
    """
    for prefix in _SPECIAL_CLASSES:
        if letters == prefix:
            return prefix
    return "general"


@dataclass
class Demand:
    """What the observed workload requires, before any candidate is considered."""

    cpu_throughput: float | None
    cpu_basis: str
    memory_capacity_gb: float | None
    memory_bandwidth: float | None
    bandwidth_basis: str
    safety_buffer_pct: float
    memory_capacity_basis: str = ""
    #: The current instance's own c-ray score and observed peak, carried forward so a
    #: candidate's eligibility can be judged by PROJECTED utilization — what this exact
    #: peak would become on that candidate — rather than by a fixed multiplicative floor.
    #: A floor of "beat X units of throughput" cannot distinguish a candidate that would
    #: land the workload at 55% from one that would land it at 71%; projecting the peak
    #: onto each candidate can.
    current_cpu_score: float | None = None
    peak_cpu_pct: float | None = None
    #: Minimum vCPU count. Throughput alone is not enough, because c-ray measures
    #: aggregate work over a fixed job and a narrow-but-fast instance can beat a
    #: wide-but-slow one on that single number while offering half the concurrency.
    #: Observed: `i8g.large` (2 vCPU Graviton3) benchmarks 1.9x faster than
    #: `c5.xlarge` (4 vCPU gen-5 Xeon), so a saturated c5.xlarge would otherwise be
    #: "right-sized" onto half the threads.
    min_vcpu: int | None = None
    min_vcpu_basis: str = ""

    @property
    def resolvable(self) -> bool:
        return self.cpu_throughput is not None


@dataclass
class RightSizingCandidate:
    instance_type: str
    strategy: str  # "conservative" | "aggressive" | "modernization"
    risk: str  # "low" | "high"
    direction: str  # "down" | "up" | "same"
    vcpu: int
    memory_gb: float
    architecture: str
    price_per_hour: float | None
    #: Prose only. No benchmark value, no derived ratio.
    customer_summary: list[str] = field(default_factory=list)
    #: Raw figures for audit. Never surfaced without an explicit opt-in.
    internal: dict[str, Any] = field(default_factory=dict)
    caveats: list[str] = field(default_factory=list)


class Verdict(str, Enum):
    """
    The outcome, stated rather than inferred.

    An empty candidate list is ambiguous on its own: it can mean "you are already on the
    right instance" (a positive result) or "we could not tell" (an absence of one). A
    caller reading only `candidates == []` cannot distinguish those, and the report would
    render both as a failure to recommend. Hence an explicit verdict.
    """

    CHANGE_RECOMMENDED = "change_recommended"
    #: The current instance is the best available fit — a real answer, not a shortfall.
    ALREADY_OPTIMAL = "already_optimal"
    #: Nothing in the dataset qualifies, so staying put is the safe action by default.
    NO_BETTER_OPTION = "no_better_option"
    #: The data cannot support any verdict; say so rather than implying the box is fine.
    INSUFFICIENT_DATA = "insufficient_data"


@dataclass
class RightSizingResult:
    current_instance: str | None
    profile: WorkloadProfile
    demand: Demand | None
    verdict: Verdict = Verdict.INSUFFICIENT_DATA
    #: One sentence a human can act on, present for every verdict.
    headline: str = ""
    candidates: list[RightSizingCandidate] = field(default_factory=list)
    #: Why no candidate was returned, when that happens. Always populated in that case.
    no_recommendation_reason: str | None = None
    notes: list[str] = field(default_factory=list)
    #: Non-negotiable. Present on every result, whatever the outcome.
    mandatory_caveat: str = (
        "This is a starting point based on hardware capability, not a prediction of your "
        "application's behaviour. Only a real workload test on the candidate instance "
        "will show whether it performs acceptably. Validate before committing."
    )


def _price(instance_type: str) -> float | None:
    """
    On-demand $/hr, or None when the pricing snapshot does not carry this type.

    None is a normal outcome, not an error: every unpriced row in the benchmark dataset
    is a `.metal` size. An unpriced candidate is ranked last rather than dropped, so a
    missing price can never silently remove the only viable option.
    """
    return pricing.lookup(instance_type)


def compute_demand(
    current: str,
    profile: WorkloadProfile,
    memory_capacity_gb: float | None = None,
    safety_buffer_pct: float = SIZING_SAFETY_BUFFER_PCT,
) -> Demand:
    """
    Translate observed pressure into required capability.

    `cpu_throughput`/`cpu_basis` (buffer-based) are kept for `resolvable` and for the
    internal-only debug payload, but no longer gate CPU eligibility — see
    `_projected_utilization_pct` and `thresholds.max_projected_utilization_pct()` in
    `_eligible`, which use `current_cpu_score`/`peak_cpu_pct` from this Demand instead.

    Bandwidth demand only becomes a hard floor when bandwidth pressure is real;
    otherwise the requirement is "do not regress materially", because a workload that is
    not bandwidth-bound gains nothing from paying for bandwidth.
    """
    buffer = 1.0 + safety_buffer_pct / 100.0

    cpu_score = bench.cpu_throughput(current)
    cpu_demand: float | None = None
    # Surfaced to the customer via `no_recommendation_reason` on the unresolvable path, so
    # it is worded without reference to the underlying dataset.
    cpu_basis = "capability data for the current instance is not available"
    if cpu_score.value is not None and profile.peak_cpu_pct is not None:
        cpu_demand = cpu_score.value * (profile.peak_cpu_pct / 100.0) * buffer
        cpu_basis = (
            f"{profile.peak_cpu_pct:.0f}% observed peak plus a "
            f"{safety_buffer_pct:.0f}% safety buffer"
        )

    # Memory capacity demand. "Must not regress below current installed RAM" is only the
    # right floor for a workload that is actually using that memory — a memory-heavy
    # workload, per the measured capacity PRESSURE, not merely per what happens to be
    # installed today. Observed on a real Gunicorn capture: 9% peak memory usage on a
    # workload's current instance, held as a hard "at least current capacity" floor,
    # ruled out every narrower and every cross-architecture candidate for a shortfall
    # that was never real — the workload was using a eleventh of what it had. HIGH or
    # MODERATE capacity pressure both count as "memory heavy" for this purpose (a 65%+
    # peak is real usage, not idle headroom); only NONE relaxes to measured usage plus
    # the same safety buffer CPU demand uses, instead of the full current install.
    if memory_capacity_gb is not None and profile.memory_capacity_pressure in (
        Pressure.HIGH,
        Pressure.MODERATE,
    ):
        capacity_demand: float | None = memory_capacity_gb
        capacity_basis = (
            "high memory-capacity pressure — candidate must not regress below the "
            "current instance's installed RAM"
        )
    elif memory_capacity_gb is not None and profile.peak_memory_pct is not None:
        capacity_demand = memory_capacity_gb * (profile.peak_memory_pct / 100.0) * buffer
        capacity_basis = (
            f"{profile.peak_memory_pct:.0f}% observed peak memory usage plus a "
            f"{safety_buffer_pct:.0f}% safety buffer — not the full current capacity, "
            "because memory is not under pressure"
        )
    else:
        capacity_demand = memory_capacity_gb
        capacity_basis = (
            "memory usage was not measured — falling back to the current instance's "
            "installed RAM as a conservative floor"
        )

    bw_score = bench.memory_bandwidth(current)
    bw_demand: float | None = None
    # Only HIGH bandwidth pressure becomes a hard floor. MODERATE is a preference, applied
    # through ranking instead.
    #
    # A moderate reading can sit a hair over the margin — observed 1.15 against a 1.1
    # threshold, on a single-sample run — and as a hard floor that thin signal excluded
    # every general-purpose Graviton instance (none beats r6g.8xlarge's bandwidth by the
    # 10% noise band), which pushed an idle Graviton box onto Intel x86. Changing
    # architecture on a marginal, one-sample signal is not a defensible trade.
    if profile.memory_bandwidth_pressure is Pressure.HIGH:
        if bw_score.trustworthy:
            # Under real pressure the workload needs at least what it has today.
            bw_demand = bw_score.value
            bandwidth_basis = "measured bandwidth pressure — candidate must not regress"
        else:
            bandwidth_basis = (
                "bandwidth pressure detected but the current instance's benchmark figure "
                f"is not reliable ({bw_score.confidence.value}); treating bandwidth as a "
                "preference rather than a hard floor"
            )
    elif profile.memory_bandwidth_pressure is Pressure.MODERATE:
        bandwidth_basis = (
            "moderate bandwidth pressure — bandwidth is preferred in ranking but not "
            "required, because a marginal signal is not enough to force an architecture "
            "or family change"
        )
    else:
        bandwidth_basis = "no measured bandwidth pressure — bandwidth is not a constraint"

    # Concurrency floor. A workload that is saturating its cores needs THREADS, and no
    # amount of per-thread speed substitutes for them: if every core is busy, removing
    # cores removes work capacity regardless of how fast the survivors are.
    current_vcpu = bench.vcpu(current) or 0
    min_vcpu: int | None = None
    min_vcpu_basis = ""
    if profile.cpu_pressure is Pressure.HIGH:
        min_vcpu = current_vcpu
        min_vcpu_basis = (
            "CPU is at high pressure, so the candidate must not have fewer vCPUs than "
            "today — narrowing a saturated instance removes capacity even if each "
            "remaining core is faster"
        )
    elif profile.cpu_pressure is Pressure.MODERATE:
        # Allow one halving at most; a moderately loaded box has some slack but not
        # unlimited slack.
        min_vcpu = max(1, current_vcpu // 2)
        min_vcpu_basis = (
            "CPU is at moderate pressure, so the candidate keeps at least half the "
            "current vCPU count"
        )

    return Demand(
        cpu_throughput=cpu_demand,
        cpu_basis=cpu_basis,
        memory_capacity_gb=capacity_demand,
        memory_capacity_basis=capacity_basis,
        memory_bandwidth=bw_demand,
        bandwidth_basis=bandwidth_basis,
        safety_buffer_pct=safety_buffer_pct,
        current_cpu_score=cpu_score.value,
        peak_cpu_pct=profile.peak_cpu_pct,
        min_vcpu=min_vcpu,
        min_vcpu_basis=min_vcpu_basis,
    )


def _projected_utilization_pct(demand: Demand, candidate_score: float | None) -> float | None:
    """
    What the observed peak would become on `candidate_score`, or None if unknown.

    `cpu_throughput` values are `1/seconds` (see `bench_data.cpu_throughput`), so a
    SMALLER throughput is a SLOWER machine. Projecting the peak scales it by how much
    slower (or faster) the candidate is: `peak * (current_throughput / candidate_throughput)`.
    A candidate half as fast doubles the projected utilization for the same absolute work.
    """
    if demand.current_cpu_score is None or demand.peak_cpu_pct is None:
        return None
    if not candidate_score:
        return None
    return demand.peak_cpu_pct * (demand.current_cpu_score / candidate_score)


def _clears(value: float | None, target: float | None) -> bool:
    """
    Whether `value` meets `target`, tolerating the measurement noise band on `value`'s
    side rather than inflating `target`.

    Used for "do not regress below current" floors (memory bandwidth), where the correct
    bar is "at least as good as the current instance," not "at least 10% better than it."
    `target * (1 + _NOISE)` demanded a candidate genuinely exceed current by a real
    margin — which excluded `r8a.16xlarge` (313,621 MB/s against a 309,154 floor: MORE
    bandwidth than current, just not 10% more) as if it had regressed. `target * (1 -
    _NOISE)` instead forgives run-to-run measurement noise on the comparison, which is
    what the noise band is documented to mean everywhere else in this module.
    """
    if target is None:
        return True
    if value is None:
        return False
    return value >= target * (1 - _NOISE)


def _ladder(candidates: list[str]) -> list[str]:
    """Candidates ordered by vCPU count — the ladder, derived not hardcoded."""
    return sorted(candidates, key=lambda t: (bench.size_rank(t) or 0, t))


def _eligible(
    current_parsed: InstanceType,
    demand: Demand,
    profile: WorkloadProfile,
) -> tuple[list[str], list[str]]:
    """
    Everything that satisfies every hard demand. Returns (eligible, rejection_notes).
    """
    eligible: list[str] = []
    notes: list[str] = []
    bw_unusable = 0
    burstable_skipped = 0
    class_skipped = 0
    older_gen_skipped = 0
    current_class = _family_class(current_parsed.letters)

    # Burstable (t-family) instances are excluded once there is any sustained load,
    # because their benchmark figures are not what a customer would experience. The
    # harness ran them with `CpuCredits=unlimited` specifically to measure silicon
    # rather than the credit throttle (see the report's `method.burstable CPUs`). On
    # default `standard` credits a sustained workload is throttled to the baseline, so
    # the score overstates real capability. Only a genuinely idle workload may land here.
    allow_burstable = profile.cpu_pressure is Pressure.NONE

    for rec in bench.iter_candidates():
        itype = rec.get("instance_type")
        if not itype:
            continue
        parsed_c = parse(itype)
        if parsed_c is None:
            continue

        if rec.get("burstable") and not allow_burstable:
            burstable_skipped += 1
            continue

        # Family class is a HARD FILTER, both directions.
        #
        # A purpose-built family may not be swapped for a general one, nor a general one
        # for a purpose-built one. Previously this was only a ranking preference, and only
        # guarded `i` -> non-`i`, which left the reverse wide open: a real run proposed
        # `r6g.8xlarge` -> `i8g.4xlarge`, offering a storage instance to replace a memory
        # instance. Neither c-ray nor STREAM measures local NVMe, an accelerator or a
        # cluster fabric, so there is no measurement on which to trade them away.
        if _family_class(parsed_c.letters) != current_class:
            class_skipped += 1
            continue

        # A strictly older generation is never proposed, regardless of price. Pure
        # price-minimisation has no reason to prefer newer silicon once a demand floor is
        # cleared, and generation 5 hardware routinely undercuts generation 8 on price —
        # observed proposing `r5a.24xlarge` to replace `r8a.16xlarge`, an instance both
        # OLDER and, per its own memory-bandwidth score, SLOWER than the one the customer
        # is already running. A customer already on newer silicon is not sized backwards.
        if parsed_c.generation < current_parsed.generation:
            older_gen_skipped += 1
            continue

        # CPU eligibility: project the observed peak onto this candidate and require it
        # to stay under the ceiling. Replaces a fixed multiplicative floor
        # (`current throughput * peak * 1.5x buffer`), which on a real capture excluded
        # `i7i.xlarge` for missing that floor by ~6% even though its projected
        # utilization (71%) was the more legible reason to reject it — the floor and the
        # ceiling are two views of the same comparison, and the ceiling states it in
        # units the reader already has (a percentage) rather than an opaque throughput
        # score.
        cpu = bench.cpu_throughput(itype)
        projected = _projected_utilization_pct(demand, cpu.value)
        if projected is None or projected > max_projected_utilization_pct():
            continue

        # Concurrency floor, checked separately from throughput. See Demand.min_vcpu.
        if demand.min_vcpu is not None and (bench.vcpu(itype) or 0) < demand.min_vcpu:
            continue

        # Capacity floor. `demand.memory_capacity_gb` is current install-size ONLY when
        # capacity pressure is genuinely HIGH (see `compute_demand`); otherwise it is
        # measured usage plus a safety buffer, so a workload using a fraction of what it
        # has today is not held to the full current install as a floor. The noise band
        # here forgives measurement/rounding on the CANDIDATE's reported figure (`r8a.
        # 16xlarge` reports 494 GB against a 496 GB demand — the same physical memory
        # config read slightly differently, not a real 2 GB shortfall), so it is applied
        # to shrink the bar, not to inflate it. `* (1 + _NOISE)` previously demanded 10%
        # MORE than the floor, excluding real matches like `r8a.16xlarge` (494 GB)
        # and `r8g.16xlarge` (495 GB) for a difference that is measurement noise, not a
        # real capacity shortfall.
        cap = bench.memory_gb(itype)
        if demand.memory_capacity_gb is not None and (
            cap is None or cap < demand.memory_capacity_gb * (1 - _NOISE)
        ):
            continue

        if demand.memory_bandwidth is not None:
            bw = bench.memory_bandwidth(itype)
            if not bw.usable:
                bw_unusable += 1
                continue
            if not _clears(bw.value, demand.memory_bandwidth):
                continue

        eligible.append(itype)

    if bw_unusable:
        notes.append(
            f"{bw_unusable} candidate(s) excluded because their memory-bandwidth figure "
            "is missing or not reliable enough to compare under measured pressure"
        )
    if class_skipped:
        notes.append(
            f"{class_skipped} candidate(s) excluded because they belong to a different "
            f"family class than the current instance ({current_class}). Purpose-built "
            "families — local-NVMe storage, high-memory, accelerator and cluster-network "
            "instances — are not interchangeable with general-purpose families in either "
            "direction, because the hardware that distinguishes them is not comparable."
        )
    if burstable_skipped:
        notes.append(
            f"{burstable_skipped} burstable (t-family) candidate(s) excluded: this "
            "workload shows sustained load, and burstable instances throttle to a baseline "
            "once CPU credits are exhausted"
        )
    if older_gen_skipped:
        notes.append(
            f"{older_gen_skipped} candidate(s) excluded for being an older hardware "
            f"generation than the current instance (gen {current_parsed.generation}). A "
            "cheaper older generation is not a right-sizing move."
        )
    return eligible, notes


def _apply_graviton_policy(
    eligible: list[str], current: InstanceType
) -> tuple[list[str], list[str]]:
    """
    Graviton-first. Already on Graviton means Graviton-only, unless nothing fits.
    """
    notes: list[str] = []
    if not current.is_graviton:
        return eligible, notes

    graviton = [t for t in eligible if parse(t) and parse(t).is_graviton]  # type: ignore[union-attr]
    if graviton:
        return graviton, notes

    notes.append(
        "No Graviton instance meets this workload's measured requirements, so non-Graviton "
        "options are shown. Moving off Graviton changes architecture — confirm your "
        "dependencies before acting."
    )
    return eligible, notes


def _rank(eligible: list[str], current: InstanceType, cost_priority: bool = True) -> list[str]:
    """
    Order survivors: architecture affinity, then capability-suffix affinity, then
    price/bandwidth — whichever `cost_priority` says leads.

    Architecture outranks capability. A same-architecture candidate with a different
    capability suffix (`m6i` -> `m6in`, added network optimisation) ranks ABOVE a
    cross-architecture candidate with a matching one (`m6i` -> `r8g`, an architecture
    change with no added capability), because an architecture change is the bigger
    decision: it needs a dependency and native-code audit that a same-architecture resize
    does not. A Graviton move is still possible when nothing same-architecture survives —
    that is what makes this a preference, ordered by cost of the decision, not a second
    hard filter alongside `_apply_graviton_policy`.

    Grouped by ARCHITECTURE (`InstanceType.is_graviton`), not by `vendor` letter.
    `vendor` is `""` for both a base family with no letter (`t3`, `c5`) and a specialised
    variant that also carries no vendor letter (`m5zn`'s "zn", `c5n`'s "n") — grouping by
    that empty string treated `m5zn` as "same vendor" as `t3.medium` and let it win a
    same-width tie over real Graviton/Intel/AMD candidates that had a genuine (non-empty)
    vendor letter and therefore lost the vendor-tier comparison outright. It also split
    plain x86 candidates (`c8i` vs `c8a`) into separate tiers on the SAME architecture,
    so an early Intel-only pool could dead-end into `wider` before a same-width AMD or
    Intel candidate elsewhere in the same architecture was ever considered — observed
    losing `c8i.xlarge`/`c8g.large` this way on a real `c5.xlarge` capture. Architecture
    is the real fault line for a dependency/native-code audit; Intel vs. AMD on the same
    architecture is not. `capability_suffix` (below) still separates `m5zn`/`c5n` from a
    plain sibling regardless of architecture.

    With `cost_priority` (the default — see `recommend`'s docstring for why it is also the
    default when no priority was ever stated), price leads once affinity is settled, not
    bandwidth. `_eligible` already enforces the memory-bandwidth FLOOR under real pressure
    (see `_clears` in that function) — every survivor here already has enough bandwidth.
    Ranking further by "even more bandwidth" on top of an already-cleared floor has no
    basis in the measured demand and only serves to justify a pricier candidate: observed
    picking `r8gn.24xlarge` ($8.74/hr, a network-optimised variant the customer never asked
    for) over its plain `r8g.24xlarge` sibling ($5.66/hr, functionally identical for this
    workload) purely because `r8gn` measured somewhat higher bandwidth past the floor both
    already cleared. Without `cost_priority` (an explicit non-cost customer priority),
    bandwidth leads instead, for a customer who has said performance matters more than the
    bill.

    Within a price band of `bench.NOISE_BAND_PCT` (10%) above the cheapest priced candidate
    IN THE SAME affinity tier, the newest hardware generation wins instead of the absolute
    cheapest. Cost optimisation is the stated priority, so this is a tiebreak among
    near-equally-priced options, not a reason to pay materially more: `r8a.16xlarge`
    ($5.11/hr) beats `r6a.16xlarge` ($3.63/hr) only when both are candidates AND the premium
    is within band — a +41% premium is not "close enough" and the cheaper, older-but-still
    -no-older-than-current generation wins instead.
    """

    # Per-affinity-tier price floor, computed once so each candidate's "is this close
    # enough to the cheapest option in its own tier to let generation decide" question has
    # an answer to compare against. Tiers, not the whole pool: a same-architecture
    # candidate should not be held to a cross-architecture cheaper price it was never
    # competing against.
    def _tier(itype: str) -> tuple[int, int]:
        parsed_c = parse(itype)
        assert parsed_c is not None
        arch_rank = 0 if parsed_c.is_graviton == current.is_graviton else 1
        suffix_rank = 0 if parsed_c.capability_suffix == current.capability_suffix else 1
        return (arch_rank, suffix_rank)

    tier_floor: dict[tuple[int, int], float] = {}
    for t in eligible:
        price = _price(t)
        if price is None:
            continue
        tier = _tier(t)
        if tier not in tier_floor or price < tier_floor[tier]:
            tier_floor[tier] = price

    def key(itype: str) -> tuple[Any, ...]:
        parsed_c = parse(itype)
        assert parsed_c is not None
        arch_rank, suffix_rank = _tier(itype)

        price = _price(itype)
        # An unpriced candidate cannot lead a cost-driven recommendation, and every
        # unpriced row in this dataset is a `.metal` size — a very different operational
        # proposition from a virtualised instance. Sorted behind everything priced rather
        # than dropped, so it can still surface when nothing else qualifies.
        unpriced_key = 0 if price is not None else 1
        # Rounded to the cent: on-demand rates do not carry more precision than that, and
        # without rounding a fractional-cent difference could win a tiebreak price was
        # never meant to settle.
        price_key = round(price, 2) if price is not None else float("inf")

        floor = tier_floor.get((arch_rank, suffix_rank))
        within_band = price is not None and floor is not None and price <= floor * (1 + _NOISE)
        # Descending generation among in-band candidates, so the newest wins the tiebreak;
        # everything else (out of band, or unpriced) falls back to price alone.
        gen_key = -parsed_c.generation if within_band else 0

        bw = bench.memory_bandwidth(itype)
        bw_key = -(bw.value or 0.0)
        measured_key = 0 if bench.is_measured(itype) else 1
        cost_tier = (
            (unpriced_key, gen_key, price_key, bw_key)
            if cost_priority
            else (bw_key, unpriced_key, gen_key, price_key)
        )
        return (
            arch_rank,
            suffix_rank,
            *cost_tier,
            measured_key,
            itype,
        )

    return sorted(eligible, key=key)


def _describe(
    itype: str,
    current: InstanceType,
    profile: WorkloadProfile,
    demand: Demand,
) -> list[str]:
    """
    Customer-facing prose. Deliberately contains no benchmark value and no ratio.

    A synthetic score, or a percentage of one, would read as a performance promise for the
    customer's own application, so capability is stated in words only.
    """
    lines: list[str] = []
    cur_cpu = bench.cpu_throughput(current.raw).value
    new_cpu = bench.cpu_throughput(itype).value

    if cur_cpu and new_cpu:
        if new_cpu >= cur_cpu:
            lines.append(
                "Equal or greater CPU capability than your current instance, with "
                "headroom above the peak observed in this capture."
            )
        else:
            lines.append(
                "Lower CPU capability than your current instance, but still above the "
                "peak observed in this capture plus a safety margin."
            )

    cur_bw = bench.memory_bandwidth(current.raw)
    new_bw = bench.memory_bandwidth(itype)
    if cur_bw.trustworthy and new_bw.trustworthy and cur_bw.value and new_bw.value:
        if new_bw.value > cur_bw.value * (1 + _NOISE):
            lines.append("Higher sustained memory bandwidth than your current instance.")
        elif new_bw.value < cur_bw.value * (1 - _NOISE):
            lines.append(
                "Lower sustained memory bandwidth than your current instance — acceptable "
                "here because no memory-bandwidth pressure was measured, but worth "
                "confirming under load."
            )
        else:
            lines.append("Comparable sustained memory bandwidth to your current instance.")

    cap = bench.memory_gb(itype)
    if cap is not None:
        lines.append(f"{cap:.0f} GB of usable memory.")

    if profile.memory_bandwidth_pressure is Pressure.HIGH:
        lines.append(
            "Selected with memory bandwidth prioritised over cost, because this workload "
            "showed measured memory-bandwidth pressure."
        )
    return lines


def recommend(
    current_instance: str | None,
    profile: WorkloadProfile,
    memory_capacity_gb: float | None = None,
    strategy: str = "both",
    cost_priority: bool = True,
    arm64_blocker_count: int = 0,
) -> RightSizingResult:
    """
    Propose right-sizing candidates, or explain why none can be proposed.

    `arm64_blocker_count` is the number of dependencies a real scan (`dep_analyzer.py`)
    found with NO working ARM64 path — not a guess about Graviton risk in general. When a
    candidate changes architecture AND this is above zero, the caveat states the exact
    count and the change is described as a migration with real blockers, not merely
    "confirm your dependencies" — the generic wording a customer with zero blockers and a
    customer with five blockers both received before this parameter existed, even though
    those are very different amounts of work.

    `cost_priority` defaults to True: price leads the ranking once affinity is settled,
    which is also the correct default when the caller never captured a customer priority
    at all — cost is the ordinary reason someone asks about right-sizing, and a report
    that silently optimises for something else when priority was never stated would be
    guessing. Pass `cost_priority=False` only when the customer has explicitly stated a
    non-cost priority (e.g. `app_context["customer_priority"]` is something other than
    "cost"), which relaxes the price-first tiebreak so bandwidth may lead among
    candidates that already clear the demand floor.
    """
    current = parse(current_instance)

    if current is None:
        return RightSizingResult(
            current_instance=current_instance,
            profile=profile,
            demand=None,
            verdict=Verdict.INSUFFICIENT_DATA,
            headline="Cannot assess: the instance type for this run is unknown.",
            no_recommendation_reason=(
                "The instance type for this run could not be determined, so there is no "
                "baseline to size against. Re-run aperf where instance metadata is "
                "available, or pass the instance type explicitly."
            ),
        )

    if not profile.sizeable:
        return RightSizingResult(
            current_instance=current.raw,
            profile=profile,
            demand=None,
            verdict=Verdict.INSUFFICIENT_DATA,
            headline=(
                "Cannot assess: CPU utilisation was not collected, so there is no measured "
                "basis for sizing."
            ),
            no_recommendation_reason=(
                "CPU utilisation was not collected for this run, so there is no measured "
                "basis for a sizing recommendation. " + "; ".join(profile.gaps)
            ),
        )

    if bench.get(current.raw) is None:
        return RightSizingResult(
            current_instance=current.raw,
            profile=profile,
            demand=None,
            verdict=Verdict.INSUFFICIENT_DATA,
            headline=(
                f"Cannot assess: capability data for {current.raw} is not available, so "
                "there is nothing to compare candidates against."
            ),
            no_recommendation_reason=(
                f"Capability data for {current.raw} is not available, so it cannot be "
                "compared against candidates. No guidance is offered rather than an "
                "estimate."
            ),
        )

    demand = compute_demand(current.raw, profile, memory_capacity_gb)
    if not demand.resolvable:
        return RightSizingResult(
            current_instance=current.raw,
            profile=profile,
            demand=demand,
            verdict=Verdict.INSUFFICIENT_DATA,
            headline="Cannot assess: CPU demand for this workload could not be established.",
            no_recommendation_reason=(
                "Could not establish CPU demand for this workload: " + demand.cpu_basis
            ),
        )

    eligible, notes = _eligible(current, demand, profile)
    eligible, graviton_notes = _apply_graviton_policy(eligible, current)
    notes.extend(graviton_notes)

    if not eligible:
        return RightSizingResult(
            current_instance=current.raw,
            profile=profile,
            demand=demand,
            verdict=Verdict.NO_BETTER_OPTION,
            headline=(
                f"KEEP {current.raw}. No other instance type is a better fit for this "
                "workload's measured requirements, so no change is recommended."
            ),
            no_recommendation_reason=(
                "No other instance type satisfies this workload's measured requirements "
                "with a safe margin better than the current instance. Staying on the "
                "current instance is the correct action."
            ),
            notes=notes,
        )

    ranked = _rank(eligible, current, cost_priority)
    current_rank = bench.size_rank(current.raw) or 0

    candidates: list[RightSizingCandidate] = []
    wanted = ("conservative", "aggressive") if strategy == "both" else (strategy,)

    for strat in wanted:
        pick: str | None = None

        if strat == "conservative":
            # One step = the SMALLEST REAL MOVE, not the biggest safe one.
            #
            # Shrinking: the widest eligible candidate strictly narrower than current.
            # Growing: the narrowest eligible candidate strictly wider than current.
            #
            # Strictly, deliberately. An earlier version let the current width satisfy
            # "one step", which returned a same-width instance from another family and
            # called it right-sizing — a family swap dressed up as a step.
            #
            # Affinity outranks tier precision, and each pool decides its OWN direction
            # instead of inheriting a globally-decided one. The prior version picked a
            # single "needs_growth" verdict from the full cross-vendor pool and then
            # applied it inside the same-vendor pool too — so when a DIFFERENT vendor
            # happened to have a narrower survivor, the same-vendor pool's own WIDER
            # survivor was never even considered, even though staying on the same
            # architecture was the whole point of trying that pool first. Observed: an
            # `r8a.16xlarge` customer whose same-vendor pool had a perfectly good wider
            # option (`r8a.24xlarge`) was offered a cross-architecture Graviton move
            # instead, because the untried direction gate said "shrink" before the
            # same-vendor pool was ever consulted.
            #
            # Tried most specific first. Same EXACT capability suffix on the same
            # ARCHITECTURE (`c5n` -> `c5n`, `c5.xlarge` -> `c8i.xlarge`) beats same
            # architecture alone: grouping by `vendor` letter instead of by
            # `is_graviton` used to split `c5.xlarge`'s own architecture into
            # per-vendor-letter pools (`i` vs `a` vs `""`), so a narrow `""`-only pool
            # (e.g. plain `c5`/`m5`/`r5` siblings) could dead-end into `wider` before the
            # real same-width `c8i.xlarge`/`c7a.xlarge` — same architecture, different
            # vendor letter — were ever consulted. It also let `vendor == ""` wrongly
            # match a specialised suffix-bearing type with no vendor letter of its own
            # (`m5zn`) to a plain base family (`t3`, `c5`) that also has none, treating an
            # unrelated specialisation as "same vendor". Same architecture regardless of
            # suffix (no dependency/native-code audit needed) comes next, then same
            # capability suffix regardless of architecture, then anything eligible.
            same_capability_and_arch = [
                t
                for t in ranked
                if (p := parse(t)) is not None
                and p.capability_suffix == current.capability_suffix
                and p.is_graviton == current.is_graviton
            ]
            same_arch = [
                t
                for t in ranked
                if (p := parse(t)) is not None and p.is_graviton == current.is_graviton
            ]
            same_capability = [
                t
                for t in ranked
                if (p := parse(t)) is not None and p.capability_suffix == current.capability_suffix
            ]
            # Held when a pool's only same-width survivor is the current instance
            # itself with nothing else to weigh it against — not a decision to stop on
            # by itself, since a later, less specific pool may still hold a REAL
            # narrower or same-width option this narrow pool simply doesn't contain
            # (e.g. `same_capability_and_arch` for `c5.9xlarge` has nothing but
            # `c5.9xlarge` at this width, while `same_capability`/`ranked` hold real
            # narrower Graviton survivors). If no pool ever produces a real option, this
            # fallback is the answer: staying put.
            self_fallback: str | None = None
            for pool in (same_capability_and_arch, same_arch, same_capability, ranked):
                if not pool:
                    continue
                narrower = [t for t in pool if (bench.size_rank(t) or 0) < current_rank]
                wider = [t for t in pool if (bench.size_rank(t) or 0) > current_rank]
                same = [t for t in pool if (bench.size_rank(t) or 0) == current_rank]
                if narrower:
                    step = max(bench.size_rank(t) or 0 for t in narrower)
                    pick = next(t for t in pool if (bench.size_rank(t) or 0) == step)
                elif same:
                    if same[0] == current.raw:
                        # This pool's best same-width answer is the current instance
                        # itself — hold it, keep searching, rather than terminating
                        # here, since a less specific pool may still hold a real
                        # narrower survivor this one doesn't contain (self ranks first
                        # within its own narrow affinity pool purely for lack of
                        # competition, not because it beat a real alternative).
                        self_fallback = self_fallback or same[0]
                        pick = None
                    else:
                        # A same-width candidate — which `_rank` already ranked ahead
                        # of any wider one, whether or not that winner is self — is the
                        # smallest real move there is: no move at all, optionally on
                        # better silicon. Growing when you are already fine is never
                        # conservative. Coarse-grained families (each size step
                        # ~doubles vCPU AND memory together, e.g. i7i/i8g) routinely
                        # have no narrower survivor anywhere even when the workload is
                        # nowhere near either ceiling — that gap must fall through to
                        # "stay", not to "grow", or a genuinely idle workload (e.g. 34%
                        # CPU / 9% memory peak) gets offered an upsize for no reason
                        # tied to its actual demand.
                        pick = same[0]
                elif wider:
                    step = min(bench.size_rank(t) or 0 for t in wider)
                    pick = next(t for t in pool if (bench.size_rank(t) or 0) == step)
                if pick is not None:
                    break
            else:
                pick = self_fallback
        else:
            # Aggressive still has a ceiling: the narrowest eligible candidate that
            # clears every demand, never simply the single "best" one by whatever `_rank`
            # sorts first. Without a cap, ranked[0] could be a candidate many times wider
            # than anything the workload asked for — observed proposing `c8i.96xlarge`
            # (384 vCPU, 744 GB) for a workload whose own demand math needed a small
            # fraction of that, purely because it happened to rank first on capability
            # affinity and bandwidth among the survivors. "High risk" describes moving
            # more than one size step, not moving to an arbitrarily oversized instance.
            #
            # Narrowest WIDTH first, but `_rank`'s own order (price/vendor/generation)
            # decides among ties at that width — not alphabetical. Sorting the whole
            # pool by `(size_rank, itype)` broke a real Graviton downsize on a genuine
            # EMR capture: the current instance itself tied on width with two real,
            # cheaper alternatives `_rank` had already placed ahead of it on price, and
            # the current instance's own type name happened to sort alphabetically
            # first among the tie — which then got discarded below as a self-proposal,
            # silently losing the cheaper option instead of falling through to it.
            narrowest_width = min((bench.size_rank(t) or 0 for t in ranked), default=None)
            same_width_by_rank = [t for t in ranked if (bench.size_rank(t) or 0) == narrowest_width]
            real_same_width = [t for t in same_width_by_rank if t != current.raw]
            pick = (
                real_same_width[0]
                if real_same_width
                else (same_width_by_rank[0] if same_width_by_rank else None)
            )

        if pick is None or any(c.instance_type == pick for c in candidates):
            continue

        pick_rank = bench.size_rank(pick) or 0
        direction = (
            "down" if pick_rank < current_rank else "up" if pick_rank > current_rank else "same"
        )
        parsed_pick = parse(pick)
        assert parsed_pick is not None

        # An architecture change with real, scanned ARM64 blockers is not a low-risk move
        # regardless of strategy — a conservative SIZE step is still a high-risk MIGRATION
        # when dependencies are known to break. Checked before `risk` is set so the field
        # itself states the real risk, not just a caveat sitting below a "low risk" label.
        _changes_arch = parsed_pick.is_graviton != current.is_graviton
        _risk = (
            "high"
            if strat == "aggressive" or (_changes_arch and arm64_blocker_count > 0)
            else "low"
        )

        cand = RightSizingCandidate(
            instance_type=pick,
            strategy=strat,
            risk=_risk,
            direction=direction,
            vcpu=bench.vcpu(pick) or 0,
            memory_gb=bench.memory_gb(pick) or 0.0,
            architecture="aarch64" if parsed_pick.is_graviton else "x86_64",
            price_per_hour=_price(pick),
            customer_summary=_describe(pick, current, profile, demand),
            internal={
                "cpu_throughput": bench.cpu_throughput(pick).value,
                "cpu_confidence": bench.cpu_throughput(pick).confidence.value,
                "memory_bandwidth": bench.memory_bandwidth(pick).value,
                "memory_bandwidth_confidence": bench.memory_bandwidth(pick).confidence.value,
                "cpu_demand": demand.cpu_throughput,
                "bandwidth_demand": demand.memory_bandwidth,
                "capacity_demand_gb": demand.memory_capacity_gb,
                "measured": bench.is_measured(pick),
                "size_rank": pick_rank,
                "current_size_rank": current_rank,
            },
        )
        if not bench.is_measured(pick):
            cand.caveats.append(
                "This instance's capability is inferred from the same size of its base "
                "family, which differs only in storage or networking. Confirm the storage "
                "and network characteristics you rely on."
            )
        if strat == "aggressive":
            cand.caveats.append(
                "High risk: this moves more than one size step. Validate under real load "
                "before committing."
            )
        if _changes_arch:
            # Architecture change, not a storage/network suffix change. `variant` for a
            # base x86 family is the vendor letter (i/a for m6i/m6a) and for Graviton is
            # "g" — comparing them raw produced a caveat that read "variant differs (i ->
            # g)" on an m6i -> r8g move, which describes an Intel/AMD/Graviton change as
            # if it were a storage suffix. Handled first and separately so the two never
            # both fire for the same reason.
            #
            # Wording branches on `arm64_blocker_count` because a real scan finding zero
            # blockers and one finding five are not the same amount of remaining work, and
            # "confirm your dependencies" read identically for both before this existed.
            if arm64_blocker_count > 0:
                cand.caveats.append(
                    f"This is a MIGRATION, not just a resize: {arm64_blocker_count} "
                    "dependency/dependencies scanned with no working ARM64 path stand "
                    "between here and a working deployment "
                    f"({'x86_64' if not current.is_graviton else 'aarch64'} -> "
                    f"{'aarch64' if parsed_pick.is_graviton else 'x86_64'}). Treat as a "
                    "separate project with its own timeline, not part of this sizing change."
                )
            else:
                cand.caveats.append(
                    "Changes CPU architecture "
                    f"({'x86_64' if not current.is_graviton else 'aarch64'} -> "
                    f"{'aarch64' if parsed_pick.is_graviton else 'x86_64'}). Confirm your "
                    "dependencies and any native code target the new architecture before "
                    "acting."
                )
        elif parsed_pick.variant != current.variant:
            cand.caveats.append(
                f"Variant differs from your current instance ({current.variant or 'base'} "
                f"-> {parsed_pick.variant or 'base'}). Suffixes encode local storage and "
                "network capability that this analysis does not evaluate."
            )
        if profile.confidence is Confidence.LOW:
            cand.caveats.append(
                "Classification confidence is low because key signals were not collected; "
                "treat this as directional only."
            )
        candidates.append(cand)

    # Drop any "proposal" that is the instance the customer is already running.
    #
    # The same-width fallback can select the current instance when nothing narrower or
    # wider qualifies. Returning it as a recommendation invites a migration that changes
    # nothing, so it is removed and reported as a verdict instead: the current instance
    # being the best available fit is a real, positive answer.
    self_proposals = [c for c in candidates if c.instance_type == current.raw]
    candidates = [c for c in candidates if c.instance_type != current.raw]

    conservative = next((c for c in candidates if c.strategy == "conservative"), None)

    # Staging advice is added here, not where the candidate is built, because it depends on
    # the FINAL list. The conservative candidate can be built and then dropped just above as
    # a self-proposal, which is exactly what happened on a real i8g.2xlarge capture: the
    # surviving aggressive option still advised staging through a conservative option that
    # was no longer in the result.
    if conservative is not None:
        for cand in candidates:
            if cand.strategy == "aggressive":
                cand.caveats.append(
                    f"Consider {conservative.instance_type} as a lower-risk intermediate stage."
                )

    if conservative is not None:
        verdict = Verdict.CHANGE_RECOMMENDED
        # `conservative.direction` is one of "down"/"up"/"same" (relative vCPU rank).
        # Treating anything non-"down" as "larger" mislabelled a same-width candidate —
        # observed proposing `t3.medium` -> `t3.micro` (same 2 vCPUs, 4 GB -> 1 GB
        # memory: a real downsize) and calling it "larger" in the headline text, the
        # opposite of what the candidate actually is.
        direction = (
            "smaller"
            if conservative.direction == "down"
            else "larger"
            if conservative.direction == "up"
            else "same-size"
        )
        headline = (
            f"CHANGE recommended: {current.raw} -> {conservative.instance_type} "
            f"({direction}, low risk). Validate under real load before committing."
        )
    elif candidates:
        # Only a high-risk option survives. The safe recommendation is therefore to KEEP
        # the current instance, with the aggressive option offered as an explicit
        # trade-off. Describing the sole remaining candidate as the recommendation would
        # label a multi-step move "low risk" — observed proposing i8g.2xlarge ->
        # i8g.48xlarge, a 24x jump, in the conservative slot.
        verdict = Verdict.ALREADY_OPTIMAL
        risky = candidates[0]
        headline = (
            f"KEEP {current.raw} as the low-risk choice. The only alternative that meets "
            f"this workload's measured requirements is {risky.instance_type}, which is "
            f"{'an' if risky.direction == 'up' else 'a'} {risky.direction}-size move rated "
            "high risk — offered as a deliberate trade-off, not a recommendation."
        )
    elif self_proposals:
        verdict = Verdict.ALREADY_OPTIMAL
        headline = (
            f"KEEP {current.raw}. It is the best fit for this workload — every alternative "
            "that meets the measured requirements is either the same width on comparable "
            "silicon, or a worse fit. No change recommended."
        )
    else:
        verdict = Verdict.NO_BETTER_OPTION
        headline = (
            f"KEEP {current.raw}. No alternative improves on it for this workload's "
            "measured requirements. No change recommended."
        )

    result = RightSizingResult(
        current_instance=current.raw,
        profile=profile,
        demand=demand,
        verdict=verdict,
        headline=headline,
        candidates=candidates,
        notes=notes,
    )
    if verdict is not Verdict.CHANGE_RECOMMENDED:
        result.no_recommendation_reason = (
            f"{current.raw} is already the appropriate size for the workload measured in "
            "this capture. Keeping it is the recommendation, not a gap in the analysis."
        )
    return result


def recommend_graviton_equivalent(
    current_instance: str | None,
    profile: WorkloadProfile,
    memory_capacity_gb: float | None = None,
    cost_priority: bool = True,
    arm64_blocker_count: int = 0,
) -> RightSizingCandidate | None:
    """
    The best Graviton candidate matching current capability, independent of the
    conservative/aggressive picks — for the ARM Modernization tab and the Right-sizing
    tab's comparison card.

    Returns `None` when there's nothing to modernize to: the current instance is already
    Graviton (nothing to move TO), no eligible Graviton candidate exists, or the instance
    type/profile can't be resolved at all — the same preconditions `recommend()` checks,
    reused via the same `_eligible`/`_rank`/`compute_demand` building blocks so this never
    drifts from what the main sizing engine considers eligible.

    Deliberately prefers a SAME-WIDTH survivor over a narrower/wider one: modernizing
    architecture should hold capability constant so the comparison is apples-to-apples,
    not also fold in an unrelated resize decision the customer didn't ask this function
    for.
    """
    current = parse(current_instance)
    if current is None or current.is_graviton or not profile.sizeable:
        return None
    if bench.get(current.raw) is None:
        return None

    demand = compute_demand(current.raw, profile, memory_capacity_gb)
    if not demand.resolvable:
        return None

    eligible, _notes = _eligible(current, demand, profile)
    graviton_eligible = [t for t in eligible if (p := parse(t)) is not None and p.is_graviton]
    if not graviton_eligible:
        return None

    ranked = _rank(graviton_eligible, current, cost_priority)
    if not ranked:
        return None

    current_rank = bench.size_rank(current.raw) or 0
    same_width = [t for t in ranked if (bench.size_rank(t) or 0) == current_rank]
    pick = same_width[0] if same_width else ranked[0]

    pick_rank = bench.size_rank(pick) or 0
    direction = "down" if pick_rank < current_rank else "up" if pick_rank > current_rank else "same"
    parsed_pick = parse(pick)
    assert parsed_pick is not None

    cand = RightSizingCandidate(
        instance_type=pick,
        strategy="modernization",
        # A real scan finding zero blockers and one finding several are not the same
        # amount of remaining work — mirrors `recommend()`'s own risk rule for an
        # architecture-changing candidate (see its `_changes_arch` branch).
        risk="high" if arm64_blocker_count > 0 else "low",
        direction=direction,
        vcpu=bench.vcpu(pick) or 0,
        memory_gb=bench.memory_gb(pick) or 0.0,
        architecture="aarch64",
        price_per_hour=_price(pick),
        customer_summary=_describe(pick, current, profile, demand),
        internal={
            "cpu_throughput": bench.cpu_throughput(pick).value,
            "cpu_confidence": bench.cpu_throughput(pick).confidence.value,
            "memory_bandwidth": bench.memory_bandwidth(pick).value,
            "memory_bandwidth_confidence": bench.memory_bandwidth(pick).confidence.value,
            "cpu_demand": demand.cpu_throughput,
            "bandwidth_demand": demand.memory_bandwidth,
            "capacity_demand_gb": demand.memory_capacity_gb,
            "measured": bench.is_measured(pick),
            "size_rank": pick_rank,
            "current_size_rank": current_rank,
        },
    )
    if not bench.is_measured(pick):
        cand.caveats.append(
            "This instance's capability is inferred from the same size of its base "
            "family, which differs only in storage or networking. Confirm the storage "
            "and network characteristics you rely on."
        )
    # Same wording `recommend()` uses for its own architecture-changing candidates —
    # kept byte-for-byte identical so the ARM tab and the Right-sizing tab's comparison
    # card never say something different about the same kind of move.
    if arm64_blocker_count > 0:
        cand.caveats.append(
            f"This is a MIGRATION, not just a resize: {arm64_blocker_count} "
            "dependency/dependencies scanned with no working ARM64 path stand "
            "between here and a working deployment (x86_64 -> aarch64). Treat as a "
            "separate project with its own timeline, not part of this sizing change."
        )
    else:
        cand.caveats.append(
            "Changes CPU architecture (x86_64 -> aarch64). Confirm your dependencies "
            "and any native code target the new architecture before acting."
        )
    if profile.confidence is Confidence.LOW:
        cand.caveats.append(
            "Classification confidence is low because key signals were not collected; "
            "treat this as directional only."
        )
    return cand
