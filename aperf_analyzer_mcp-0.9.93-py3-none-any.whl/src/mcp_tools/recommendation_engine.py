# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Recommendation engine for aperf analysis.

Generates structured instance migration recommendations based on:
- PMU data (CPU pressure, backend stalls, IPC)
- Memory utilization
- Customer priority (cost / latency / throughput / migration-readiness)
- Capture type (steady-state / peak / incident / benchmark)
- Application context (dep file presence, runtime, etc.)

Output is structured for embedding in HTML reports. Pricing is left as
placeholders ({{PRICE_FROM}}, {{PRICE_TO_X}}) for the agent to fill via
AWS Pricing MCP.

Rules (per user agreement):
- capture=peak AND idle>50%: right-size DOWN + modernize family
- capture=peak AND idle<30%: keep or grow vCPU + modernize family
- capture=steady-state AND idle>85%: right-size DOWN + modernize family
- capture=steady-state otherwise: modernize family, same shape
- capture=incident: modernize family only, no resize
- When modernizing: always to NEWEST generation available
- Graviton path triggered when arch=x86_64 AND priority=cost-reduction
- Graviton requires phased: Step 1 (safe x86 newer-gen) -> Step 2 (Graviton)
- Workload classifier:
    backend_stall>40% AND dtlb_misses>=FLOOR_DTLB_MPKI: memory-bound -> r-family
    ipc>1.5 AND cpu_pressure: compute-bound -> c-family
    otherwise: balanced -> m-family
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..thresholds import FLOOR_DTLB_MPKI


@dataclass
class InstanceRec:
    """A single instance recommendation."""

    label: str  # "Step 1a — Safe Modernization", "Step 2 — Graviton Target", etc.
    instance_type: str  # placeholder family.size, agent fills in newest gen
    family: str  # e.g. "m" / "c" / "r"
    architecture: str  # x86_64 | aarch64
    vcpu: int
    memory_gb: int
    rationale: str
    risk_level: str  # low | medium | high
    requires_validation: list[str] = field(default_factory=list)
    estimated_savings_pct: int | None = None  # null = pricing-dependent


@dataclass
class Recommendations:
    """Full recommendation set."""

    workload_class: str  # memory-bound | compute-bound | balanced
    workload_signals: list[str] = field(default_factory=list)
    cpu_sizing_decision: str = ""  # downsize | keep | grow
    cpu_sizing_rationale: str = ""
    instance_options: list[InstanceRec] = field(default_factory=list)
    graviton_recommended: bool = False
    graviton_blockers: list[str] = field(default_factory=list)
    graviton_degradeds: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    caveats: list[str] = field(default_factory=list)


def classify_workload(pmu: dict, cpu: dict) -> tuple[str, list[str]]:
    """
    Classify the workload based on PMU and CPU signals.
    Returns (class, signals) where class is memory-bound | compute-bound | balanced.
    """
    signals = []
    backend_stalls = pmu.get("backend_stall_pct", 0) if pmu else 0
    frontend_stalls = pmu.get("frontend_stall_pct", 0) if pmu else 0
    dtlb_misses = pmu.get("dtlb_misses_per_1k_insns", 0) if pmu else 0
    ipc = pmu.get("ipc", 0) if pmu else 0
    avg_util = cpu.get("avg_utilization_pct", 0) if cpu else 0

    # Memory-bound signals
    if backend_stalls > 40:
        signals.append(f"Backend stalls at {backend_stalls:.1f}% (memory subsystem waiting)")
    if dtlb_misses >= FLOOR_DTLB_MPKI:
        signals.append(
            f"DTLB misses at {dtlb_misses:.1f}/1K instructions (data footprint exceeds TLB)"
        )

    # Compute-bound signals
    if ipc > 1.5 and avg_util > 50:
        signals.append(f"High IPC ({ipc:.2f}) with active CPU utilization ({avg_util:.0f}%)")
    if frontend_stalls > 20:
        signals.append(f"Frontend stalls at {frontend_stalls:.1f}% (instruction cache pressure)")

    # Decision logic
    if backend_stalls > 40 or dtlb_misses >= FLOOR_DTLB_MPKI:
        return ("memory-bound", signals)
    if ipc > 1.5 and avg_util > 50:
        return ("compute-bound", signals)
    return ("balanced", signals)


def decide_cpu_sizing(
    capture_type: str, idle_pct: float, peak_pct: float | None = None
) -> tuple[str, str]:
    """
    Decide whether to right-size DOWN, KEEP, or GROW vCPU count.

    Returns (decision, rationale).
    """
    capture_type = (capture_type or "steady-state").lower().strip()

    # Peak captures with low idle: workload is real, keep or grow
    if "peak" in capture_type:
        if idle_pct < 30:
            return (
                "keep_or_grow",
                (
                    f"Peak capture shows {100 - idle_pct:.0f}% CPU active — vCPU count is being "
                    "consumed. Keep current shape; consider compute-optimized variant if work "
                    "is CPU-bound."
                ),
            )
        elif idle_pct > 50:
            return (
                "downsize",
                (
                    f"Customer reports peak load but {idle_pct:.0f}% CPU is idle. "
                    "Right-size to fewer vCPUs and modernize the family. "
                    "Validate by checking CloudWatch 99th-percentile CPU on the current "
                    "instance for the past 30 days."
                ),
            )
        else:
            return (
                "keep",
                (
                    f"Peak capture at {100 - idle_pct:.0f}% utilization — neither low enough to "
                    "downsize nor high enough to require growth. Modernize family at current "
                    "shape."
                ),
            )

    # Steady-state with very high idle: aggressive right-sizing candidate
    if "steady-state" in capture_type or "steady" in capture_type:
        if idle_pct > 85:
            return (
                "downsize",
                (
                    f"Steady-state at {idle_pct:.0f}% idle — significant over-provisioning. "
                    "Right-size to half the vCPUs and modernize the family. "
                    "Confirm by checking peak CPU over the last 30 days does not exceed 40% "
                    "on the current shape."
                ),
            )
        elif idle_pct > 60:
            return (
                "keep_with_caveat",
                (
                    f"Steady-state at {idle_pct:.0f}% idle — modernize family at current "
                    "shape. Consider right-sizing if peak CPU stays below 40%."
                ),
            )
        else:
            return (
                "keep",
                (
                    f"Steady-state at {100 - idle_pct:.0f}% utilization — current shape is "
                    "appropriate. Modernize family for newer hardware benefits."
                ),
            )

    # Incident: don't right-size, the data is an outlier
    if "incident" in capture_type:
        return (
            "keep",
            (
                "Incident captures are outliers; do not change instance shape based on this "
                "data alone. Modernize family only if cost is the priority."
            ),
        )

    # Default
    return ("keep", f"Capture type '{capture_type}' — keeping current shape, modernizing family.")


# Instance family mapping based on workload class
# These are family LETTERS (m/c/r). The MCP doesn't hardcode generation numbers
# — the agent fills in newest available via AWS MCP.

FAMILY_BY_WORKLOAD = {
    "memory-bound": "r",  # memory-optimized
    "compute-bound": "c",  # compute-optimized
    "balanced": "m",  # general-purpose
}


def _adjust_size(current_size: str, decision: str) -> str:
    """
    Halve or keep the instance size based on decision.
    e.g. "32xlarge" -> "16xlarge" when downsizing.
    """
    size_map = {
        "metal": "metal",
        "32xlarge": "16xlarge",
        "24xlarge": "12xlarge",
        "16xlarge": "8xlarge",
        "12xlarge": "6xlarge",
        "9xlarge": "4xlarge",
        "8xlarge": "4xlarge",
        "6xlarge": "3xlarge",
        "4xlarge": "2xlarge",
        "3xlarge": "2xlarge",
        "2xlarge": "xlarge",
        "xlarge": "large",
        "large": "medium",
    }
    if decision == "downsize":
        return size_map.get(current_size, current_size)
    return current_size


def _parse_instance(instance_type: str) -> tuple[str, str, str]:
    """
    Parse 'm6i.32xlarge' -> ('m', '6i', '32xlarge').
    """
    if not instance_type or "." not in instance_type:
        return ("m", "5", "xlarge")

    family_full, size = instance_type.split(".", 1)

    # Split letter prefix from numeric+suffix
    # e.g. "m6i" -> "m", "6i"
    # e.g. "r8a" -> "r", "8a"
    # e.g. "c8g" -> "c", "8g"
    # e.g. "x2idn" -> "x", "2idn"
    import re

    m = re.match(r"^([a-z]+)(\d+[a-z]*)$", family_full)
    if m:
        return (m.group(1)[0], m.group(2), size)
    return (family_full[0], "5", size)


def build_recommendations(
    pmu: dict,
    cpu: dict,
    memory: dict,
    metadata: dict,
    app_context: dict,
    dep_analysis: dict | None = None,
) -> Recommendations:
    """
    Main recommendation builder.
    """
    rec = Recommendations(workload_class="balanced")

    # Extract context
    arch = (metadata.get("architecture") or "x86_64").lower()
    instance_type = metadata.get("instance_type") or ""
    capture_type = (app_context.get("capture_type") or "steady-state").lower()
    priority = (app_context.get("customer_priority") or "").lower()

    idle_pct = 100 - (cpu.get("avg_utilization_pct", 0) if cpu else 0)
    peak_pct = cpu.get("peak_utilization_pct", 0) if cpu else 0

    # 1. Workload classification
    rec.workload_class, rec.workload_signals = classify_workload(pmu, cpu)

    # 2. CPU sizing decision
    rec.cpu_sizing_decision, rec.cpu_sizing_rationale = decide_cpu_sizing(
        capture_type, idle_pct, peak_pct
    )

    # 3. Determine target family letter
    target_family = FAMILY_BY_WORKLOAD.get(rec.workload_class, "m")
    _, _, current_size = _parse_instance(instance_type)
    target_size = (
        _adjust_size(current_size, rec.cpu_sizing_decision)
        if rec.cpu_sizing_decision == "downsize"
        else current_size
    )

    # 4. Build instance options
    # Step 1: Modernize family on the same architecture (x86 if currently x86)
    # The agent fills in the newest generation via AWS MCP — we use {{NEWEST}} placeholder.
    if arch == "x86_64":
        # Step 1a: AMD newest (low risk)
        rec.instance_options.append(
            InstanceRec(
                label="Step 1 — Modernize (Same x86 ISA)",
                instance_type=f"{target_family}{{{{NEWEST_X86_AMD_GEN}}}}a.{target_size}",
                family=target_family,
                architecture="x86_64",
                vcpu=0,  # filled by agent based on size
                memory_gb=0,
                rationale=(
                    f"Newest AMD-based generation in the {target_family}-family at "
                    f"{'reduced' if rec.cpu_sizing_decision == 'downsize' else 'same'} shape. "
                    f"Zero application changes (same x86_64 ISA). "
                    f"AMD EPYC offers the largest IPC improvement vs older Intel generations."
                ),
                risk_level="low",
                requires_validation=[],  # filled by html_report sizing pass when needed
            )
        )

        # Step 1b: Intel newest (alternative)
        rec.instance_options.append(
            InstanceRec(
                label="Step 1 alt — Modernize (Intel)",
                instance_type=f"{target_family}{{{{NEWEST_X86_INTEL_GEN}}}}i.{target_size}",
                family=target_family,
                architecture="x86_64",
                vcpu=0,
                memory_gb=0,
                rationale=(
                    "Newest Intel-based generation. Choose this over AMD if your application "
                    "depends on Intel-specific features (AVX-512, AMX) or has known issues on AMD."
                ),
                risk_level="low",
                requires_validation=[],  # filled by html_report sizing pass when needed
            )
        )

    # 5. Graviton recommendation
    cost_priority = "cost" in priority or priority in ("cost-reduction", "migration-readiness")
    if cost_priority and arch == "x86_64":
        rec.graviton_recommended = True

        # Check dep analysis for blockers and degradeds
        if dep_analysis:
            blockers = dep_analysis.get("blockers", [])
            for b in blockers:
                if isinstance(b, dict):
                    rec.graviton_blockers.append(
                        f"{b.get('name', '?')}:{b.get('version', '?')} — {b.get('action', 'verify')}"
                    )
            degradeds = dep_analysis.get("degradeds", [])
            for d in degradeds:
                if isinstance(d, dict):
                    rec.graviton_degradeds.append(
                        f"{d.get('name', '?')}:{d.get('version', '?')} — {d.get('action', 'upgrade')}"
                    )

        # Add Graviton step
        rec.instance_options.append(
            InstanceRec(
                label="Step 2 — Graviton Target",
                instance_type=f"{target_family}{{{{NEWEST_GRAVITON_GEN}}}}g.{target_size}",
                family=target_family,
                architecture="aarch64",
                vcpu=0,
                memory_gb=0,
                rationale=(
                    f"Newest Graviton generation in the {target_family}-family. "
                    f"Highest cost-efficiency for {rec.workload_class} workloads. "
                    f"Requires resolving any ARM64 dependency blockers before deployment. "
                    f"OS upgrade may be required (Ubuntu 22.04+ / Amazon Linux 2023)."
                ),
                risk_level="medium" if rec.graviton_blockers else "low",
                requires_validation=[
                    "Resolve ARM64 dependency blockers (see dependency analysis)",
                    "Upgrade OS if kernel < 6.0 (for full Graviton4 LSE atomics support)",
                    "Run application smoke test before production cutover",
                ],  # peak-CPU caveat added by html_report sizing pass when needed
            )
        )

    elif arch == "aarch64":
        # Already on Graviton — recommend newest Graviton
        rec.instance_options.append(
            InstanceRec(
                label="Step 1 — Newer Graviton",
                instance_type=f"{target_family}{{{{NEWEST_GRAVITON_GEN}}}}g.{target_size}",
                family=target_family,
                architecture="aarch64",
                vcpu=0,
                memory_gb=0,
                rationale="Newer Graviton generation. Re-test against current arch.",
                risk_level="low",
            )
        )

    # 6. Notes and caveats
    if rec.workload_class != "balanced":
        rec.notes.append(
            f"Workload classified as **{rec.workload_class}** — recommending {target_family}-family. "
            f"Signals: {'; '.join(rec.workload_signals)}"
        )

    # No right-sizing caveat here. This engine no longer sizes anything the report renders:
    # the benchmark-backed engine owns that, and it carries its own mandatory validation
    # caveat. The text that used to live here told the reader to "take Step 1 at the current
    # shape instead of the downsized shape" — Steps that the report stopped rendering, so the
    # instruction pointed at nothing.

    if rec.graviton_recommended and not dep_analysis:
        rec.caveats.append(
            "**Graviton recommendation is partial without a dependency file.** "
            "Native libraries cannot be verified for ARM64 compatibility. "
            "Provide `pom.xml`, `requirements.txt`, `package.json`, etc. for a complete migration plan."
        )

    return rec
