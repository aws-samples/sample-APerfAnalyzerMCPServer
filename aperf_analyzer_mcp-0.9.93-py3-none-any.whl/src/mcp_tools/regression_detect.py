# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: detect_regressions

Automated regression detection between runs using statistical thresholds.
"""

import json
import os
from typing import Any

from mcp.types import Tool

REGRESSION_DETECT_TOOL = Tool(
    name="detect_regressions",
    description=(
        "Automatically detect performance regressions between a baseline and candidate run. "
        "Uses configurable thresholds for each metric category. "
        "Returns a structured list of regressions with severity and suggested next steps."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "baseline_run": {"type": "string", "description": "Baseline run name"},
            "candidate_run": {
                "type": "string",
                "description": "Candidate run to check for regressions",
            },
            "thresholds": {
                "type": "object",
                "description": "Custom thresholds (metric_name → pct_change that counts as regression)",
                "properties": {
                    "ipc_drop_pct": {"type": "number", "default": 5},
                    "branch_miss_increase_pct": {"type": "number", "default": 10},
                    "tlb_miss_increase_pct": {"type": "number", "default": 15},
                    "cache_miss_increase_pct": {"type": "number", "default": 15},
                    "stall_increase_pct": {"type": "number", "default": 15},
                    "cpu_util_increase_pct": {"type": "number", "default": 10},
                },
            },
            "data_dir": {"type": "string"},
            "report_dir": {
                "type": "string",
                "description": (
                    "Optional: a single aperf report directory (relative to data_dir) containing "
                    "both runs, as produced by `aperf report -r a -r b`. Without it, each run "
                    "name must be its own directory under data_dir."
                ),
            },
        },
        "required": ["baseline_run", "candidate_run"],
    },
)


async def regression_detect_handler(arguments: dict[str, Any]) -> str:
    """Detect regressions between two runs."""
    baseline_name = arguments["baseline_run"]
    candidate_name = arguments["candidate_run"]
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))
    thresholds = arguments.get(
        "thresholds",
        {
            "ipc_drop_pct": 5,
            "branch_miss_increase_pct": 10,
            "tlb_miss_increase_pct": 15,
            "cpu_util_increase_pct": 10,
        },
    )

    from pathlib import Path

    from ..parsers.pmu_parser import PmuParser
    from ..parsers.run_parser import AperfRunParser

    parser = AperfRunParser(base_dir=data_dir)
    # Both runs may live inside one report — that is what `aperf report -r a -r b` produces.
    report_dir = arguments.get("report_dir")
    if report_dir:
        shared = Path(data_dir) / report_dir
        baseline_report = parser.get_report_data(shared, run_key=baseline_name)
        candidate_report = parser.get_report_data(shared, run_key=candidate_name)
        for report in (baseline_report, candidate_report):
            if report and report.get("_run_key_warning"):
                return json.dumps(
                    {
                        "status": "error",
                        "message": report["_run_key_warning"],
                        "runs_in_report": report.get("_runs_in_report", []),
                    },
                    indent=2,
                )
    else:
        baseline_report = parser.get_report_data(Path(data_dir) / baseline_name)
        candidate_report = parser.get_report_data(Path(data_dir) / candidate_name)

    if not baseline_report or not candidate_report:
        missing = [
            name
            for name, report in (
                (baseline_name, baseline_report),
                (candidate_name, candidate_report),
            )
            if not report
        ]
        return json.dumps(
            {
                "status": "error",
                "message": f"No report data for {', '.join(missing)}. `aperf report` output is "
                "required — a raw `aperf record` directory holds bincode `.bin` files "
                "that nothing here decodes. Run `aperf report -r <dir> -n <name>` first.",
                "runs_missing_report_data": missing,
            },
            indent=2,
        )

    regressions = []
    unavailable = []

    # PMU regressions
    pmu_parser = PmuParser()
    baseline_pmu = pmu_parser.parse_from_report_data(baseline_report)
    candidate_pmu = pmu_parser.parse_from_report_data(candidate_report)

    #: (delta key, threshold key, default threshold, critical threshold, label, next steps).
    #: All of these are "higher is worse" except IPC, which `compare` already normalises into an
    #: `improved` flag, so the sign of `change_pct` is read against `improved` rather than assumed.
    _CHECKS = [
        (
            "ipc",
            "ipc_drop_pct",
            5,
            15,
            "IPC",
            [
                "Check branch prediction and cache metrics",
                "Compare compiler flags and optimization levels",
                "Look for new code paths or workload changes",
            ],
        ),
        (
            "branch_misses_per_1k",
            "branch_miss_increase_pct",
            10,
            30,
            "branch misses/1K insns",
            [
                "New indirect branches or virtual dispatch introduced?",
                "Check for JIT compilation changes",
                "Compare code sparsity metrics",
            ],
        ),
        (
            "itlb_misses_per_1k",
            "tlb_miss_increase_pct",
            15,
            40,
            "ITLB misses/1K insns",
            [
                "Code footprint grew past TLB coverage — check for new dependencies",
                "Enable huge pages for the text segment",
            ],
        ),
        (
            "dtlb_misses_per_1k",
            "tlb_miss_increase_pct",
            15,
            40,
            "DTLB misses/1K insns",
            [
                "Data footprint grew — check allocation sizes and access patterns",
                "Use huge pages for large allocations",
            ],
        ),
        (
            "l2_mpki",
            "cache_miss_increase_pct",
            15,
            40,
            "L2 misses/1K insns",
            [
                "Working set grew past L2 — check for larger buffers or more threads per core",
            ],
        ),
        (
            "l3_mpki",
            "cache_miss_increase_pct",
            15,
            40,
            "LLC-to-DRAM fills/1K insns",
            [
                "More traffic is reaching DRAM — check data locality and NUMA placement",
            ],
        ),
        (
            "backend_stalls_pct",
            "stall_increase_pct",
            15,
            40,
            "backend stalls",
            [
                "Memory-bound: correlate with the cache and TLB deltas above",
            ],
        ),
        (
            "frontend_stalls_pct",
            "stall_increase_pct",
            15,
            40,
            "frontend stalls",
            [
                "Instruction-fetch-bound: correlate with inst-l1-mpki and inst-tlb-mpki",
            ],
        ),
    ]

    multiplexing = 0.0
    if baseline_pmu and candidate_pmu:
        deltas = pmu_parser.compare(baseline_pmu, candidate_pmu)
        multiplexing = max(
            baseline_pmu.counter_schedule_rate_pct, candidate_pmu.counter_schedule_rate_pct
        )

        for key, thresh_key, default, critical, label, next_steps in _CHECKS:
            delta = deltas.get(key, {})
            # A metric this platform does not collect is reported, not silently counted as clean.
            if not delta.get("available"):
                unavailable.append(key)
                continue
            change = delta.get("change_pct")
            if change is None or delta.get("improved"):
                continue
            magnitude = abs(change)
            if magnitude <= thresholds.get(thresh_key, default):
                continue
            regression = {
                "metric": key,
                "severity": "critical" if magnitude > critical else "warning",
                "baseline_value": delta["baseline"],
                "candidate_value": delta["candidate"],
                "change_pct": change,
                "description": f"{label} worsened by {magnitude:.1f}%",
                "next_steps": next_steps,
            }
            # Under multiplexing every value is extrapolated from part of the interval, so a delta
            # of that order is not distinguishable from sampling artefact.
            if multiplexing > 0 and magnitude < multiplexing:
                regression["severity"] = "info"
                regression["caveat"] = (
                    f"Change ({magnitude:.1f}%) is smaller than the counter multiplexing rate "
                    f"({multiplexing:.1f}%), so it may be a measurement artefact rather than real."
                )
            regressions.append(regression)

    result = {
        "status": "success",
        "baseline": baseline_name,
        "candidate": candidate_name,
        "regressions_found": len(regressions),
        "regressions": regressions,
        "verdict": "REGRESSION_DETECTED" if regressions else "NO_REGRESSION",
    }
    if unavailable:
        # Without this, "NO_REGRESSION" over a platform that collects two of the eight metrics
        # looked identical to a clean result over all eight.
        result["metrics_not_collected"] = unavailable
        result["coverage_note"] = (
            f"{len(unavailable)} of {len(_CHECKS)} PMU checks could not run: the metric is absent "
            "from at least one run. A verdict of NO_REGRESSION covers only the checks that ran."
        )
    if multiplexing > 0:
        result["counter_multiplexing_pct"] = round(multiplexing, 2)

    return json.dumps(result, indent=2)
