# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
Tool: get_profile_summary

Summarizes profiling data (perf profile or Java async-profiler).
"""

import json
import os
import re
from typing import Any

from mcp.types import Tool

PROFILE_SUMMARY_TOOL = Tool(
    name="get_profile_summary",
    description=(
        "Get a summarized view of profiling data from an aperf run. "
        "Supports perf profile (native) and async-profiler (JVM). "
        "Returns top functions by self%, hot modules/DSOs, and call-chain summaries. Note: aws/aperf MCP's `get_flamegraph` provides regex filtering and diff modes; use this tool for the synthesized summary, that one for raw exploration."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "run_name": {"type": "string", "description": "Name of the aperf run"},
            "profile_type": {
                "type": "string",
                "enum": ["perf", "java", "auto"],
                "description": "Type of profile to summarize (auto-detects if auto)",
                "default": "auto",
            },
            "top_n": {"type": "integer", "default": 20},
            "data_dir": {"type": "string"},
        },
        "required": ["run_name"],
    },
)


def _parse_perf_text(text: str) -> list[dict[str, Any]]:
    """Parse perf report text into structured entries."""
    entries = []
    pattern = re.compile(r"\s+(\d+\.\d+)%\s+(\d+\.\d+)%\s+(\S+)\s+(\S+)\s+\[.\]\s+(.*)")
    for line in text.splitlines():
        m = pattern.match(line)
        if m:
            entries.append(
                {
                    "overhead_pct": float(m.group(1)),
                    "self_pct": float(m.group(2)),
                    "command": m.group(3),
                    "dso": m.group(4),
                    "symbol": m.group(5).strip(),
                }
            )
    return entries


def _parse_collapse_stacks(text: str, top_n: int) -> tuple[list[dict[str, Any]], int]:
    """Parse collapsed stack format (used for flamegraphs) to get top leaf functions."""
    func_counts: dict[str, int] = {}
    total = 0
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.rsplit(" ", 1)
        if len(parts) == 2:
            try:
                count = int(parts[1])
                stack = parts[0]
                leaf = stack.split(";")[-1].strip()
                func_counts[leaf] = func_counts.get(leaf, 0) + count
                total += count
            except ValueError:
                continue
    entries = []
    for func, count in sorted(func_counts.items(), key=lambda x: x[1], reverse=True)[:top_n]:
        entries.append(
            {
                "symbol": func,
                "samples": count,
                "pct": round(count / total * 100, 2) if total else 0,
            }
        )
    return entries, total


async def profile_summary_handler(arguments: dict[str, Any]) -> str:
    """Summarize profiling data."""
    run_name = arguments["run_name"]
    profile_type = arguments.get("profile_type", "auto")
    top_n = arguments.get("top_n", 20)
    data_dir = arguments.get("data_dir", os.environ.get("APERF_DATA_DIR", "./aperf_data"))

    from pathlib import Path

    from ..parsers.run_parser import AperfRunParser

    parser = AperfRunParser(base_dir=data_dir)
    run_path = Path(data_dir) / run_name
    metadata = parser._parse_metadata(run_path)

    if not metadata:
        return json.dumps({"status": "error", "message": f"Run '{run_name}' not found"})

    if profile_type == "auto":
        if metadata.has_profile:
            profile_type = "perf"
        elif metadata.has_java_profile:
            profile_type = "java"
        else:
            return json.dumps(
                {
                    "status": "no_profile",
                    "message": "No profiling data available.",
                }
            )

    result = {
        "status": "success",
        "run_name": run_name,
        "profile_type": profile_type,
        "top_functions": [],
        "hot_modules": [],
        "total_samples": 0,
    }

    # 1. Try top_functions / perf report text from raw archive
    archive_dir = run_path / "data" / "archive"
    perf_text = None
    collapse_text = None

    if archive_dir.exists():
        import tarfile

        for gz in archive_dir.glob("*.tar.gz"):
            try:
                with tarfile.open(gz, "r:gz") as tar:
                    for member in tar.getmembers():
                        if member.name.endswith("top_functions") and perf_text is None:
                            f = tar.extractfile(member)
                            if f:
                                perf_text = f.read().decode("utf-8", errors="replace")
                        if member.name.endswith("collapse.out") and collapse_text is None:
                            f = tar.extractfile(member)
                            if f:
                                collapse_text = f.read().decode("utf-8", errors="replace")
            except (tarfile.TarError, OSError, UnicodeError):
                # Optional archive: `perf_text`/`collapse_text` stay None and the code falls back to
                # `perf_profile.js` below. Narrow for the same reason as `hotspots.py`.
                pass

    # 2. Fall back to perf_profile.js
    graph_profile = None
    if perf_text is None:
        js_path = run_path / "data" / "js" / "perf_profile.js"
        if js_path.exists():
            raw = parser._parse_js_var(js_path.read_text())
            if raw:
                run_key = next(iter(raw.get("runs", {})), None)
                lines = raw.get("runs", {}).get(run_key, {}).get("lines", []) if run_key else []
                perf_text = "\n".join(str(l) for l in lines)
                # aperf 1.3.0 emits `data_format: "graph"` — no `lines`, no symbol table, just
                # SVG paths. Without this the tool reported `partial: could not be parsed` for
                # every profiled 1.3.0 run.
                if not perf_text and raw.get("data_format") == "graph":
                    graph_profile = raw

    # Parse perf report text (self% entries)
    if perf_text:
        entries = _parse_perf_text(perf_text)
        self_entries = [e for e in entries if e["self_pct"] > 0]
        self_entries.sort(key=lambda x: x["self_pct"], reverse=True)
        result["top_functions"] = self_entries[:top_n]
        result["total_samples"] = len(entries)

        # Hot modules (DSOs) by cumulative self%
        dso_totals: dict[str, float] = {}
        for e in self_entries:
            dso_totals[e["dso"]] = dso_totals.get(e["dso"], 0) + e["self_pct"]
        result["hot_modules"] = [
            {"dso": dso, "self_pct_total": round(pct, 2)}
            for dso, pct in sorted(dso_totals.items(), key=lambda x: x[1], reverse=True)[:10]
        ]

    # If we have collapse stacks, also provide flamegraph leaf summary
    if collapse_text:
        flame_entries, flame_total = _parse_collapse_stacks(collapse_text, top_n)
        result["flamegraph_top_leaves"] = flame_entries
        result["flamegraph_total_samples"] = flame_total

    if graph_profile and not result["top_functions"]:
        from ..mcp_tools.hotspots import _parse_flamegraph_hotspots

        frames = _parse_flamegraph_hotspots(run_path, graph_profile, top_n)
        if frames:
            result["top_frames_inclusive"] = frames
            result["measure_note"] = (
                "aperf's `graph` profile format carries no symbol table — only flamegraph SVGs — "
                "so these are INCLUSIVE percentages read from the flamegraph, not self time. A "
                "frame high in this list may simply be an ancestor of the real hotspot. Read the "
                "deepest frames with high percentages, or re-record with a version that emits "
                "`perf report` text."
            )

    if (
        not result["top_functions"]
        and not result.get("flamegraph_top_leaves")
        and not result.get("top_frames_inclusive")
    ):
        result["status"] = "partial"
        result["message"] = "Profile data present but could not be parsed."

    return json.dumps(result, indent=2)
