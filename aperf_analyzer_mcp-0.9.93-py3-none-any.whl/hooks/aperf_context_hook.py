#!/usr/bin/env python3
# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
"""
APerf Context Hook — PreToolUse intercept for aperf MCP tools.

Behaviour:
  1. First run on a new application:
     - Extracts fingerprint from binary data (instance type, process, memory tier)
     - Blocks the tool call and returns a structured questionnaire
     - On next call with answers provided, saves context and approves
  2. Known application (fingerprint matches):
     - Checks for drift (instance type changed, memory tier changed, new process)
     - If no drift: injects saved context into tool arguments as app_context, approves
     - If drift detected: warns with diff and asks whether to update
  3. Unknown application but answers provided in arguments:
     - Saves context, approves

Context store: ~/.aperf-contexts/<fingerprint_hash>.json

Called as: python aperf_context_hook.py
Receives JSON on stdin (Claude Code PreToolUse hook payload).
Exit codes: 0 = approve, 1 = warn, 2 = block
"""

import hashlib
import json
import os
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CONTEXT_STORE = Path.home() / ".aperf-contexts"
WATCHED_TOOLS = {"get_run_summary", "generate_html_report", "get_language_advisory"}

QUESTIONS = [
    {
        "key": "app_name",
        "label": "Application name / service identifier",
        "example": "ml-search-backend",
        "required": True,
    },
    {
        "key": "app_description",
        "label": "What does this service do? (one sentence)",
        "example": "Search backend serving the product catalog API",
        "required": True,
    },
    {
        "key": "capture_type",
        "label": "Capture type",
        "example": "steady-state | peak | incident | benchmark",
        "required": True,
    },
    {
        "key": "customer_priority",
        "label": "Primary objective for this analysis",
        "example": "cost-reduction | latency | throughput | migration-readiness",
        "required": True,
    },
    {
        "key": "dep_file",
        "label": "Path to dependency manifest (or 'auto' to auto-detect, 'none' to skip)",
        "example": "/Users/x/project/pom.xml or 'auto' or 'none'",
        "required": True,
    },
    {
        "key": "runtime_version",
        "label": "Runtime version (Java/Python/Node version)",
        "example": "Java 17.0.8 (OpenJDK Corretto)",
        "required": False,
    },
    {
        "key": "runtime_flags",
        "label": "Runtime/GC flags (JVM flags, gunicorn config, etc.)",
        "example": "-Xmx400g -XX:+UseG1GC -XX:MaxGCPauseMillis=200",
        "required": False,
    },
    {
        "key": "sla_constraints",
        "label": "Known SLA constraints (latency targets, traffic patterns)",
        "example": "p99 < 250ms, peak QPS 8k, business hours only",
        "required": False,
    },
]

# ---------------------------------------------------------------------------
# Fingerprint extraction
# ---------------------------------------------------------------------------

def _strings_from_bin(path: Path) -> str:
    """Extract printable ASCII strings from a binary file."""
    data = path.read_bytes()
    matches = re.findall(rb"[\x09\x0a\x0d\x20-\x7e]{4,}", data)
    return "\n".join(m.decode("ascii", errors="replace") for m in matches)


def _instance_family(instance_type: str) -> str:
    """Normalise instance type to family, e.g. m6i.32xlarge -> m6i."""
    if not instance_type:
        return "unknown"
    return instance_type.split(".")[0]


def _memory_tier(mem_total_kb: int) -> str:
    gb = mem_total_kb / (1024 * 1024)
    if gb < 64:
        return "small"       # < 64 GB
    elif gb < 256:
        return "medium"      # 64-256 GB
    elif gb < 768:
        return "large"       # 256-768 GB
    else:
        return "xlarge"      # > 768 GB


def _bins_for(run_path: Path, collector: str) -> list:
    """Match BOTH 'collector_<ts>.bin' (older) and 'collector.bin' (newer) layouts."""
    files = list(run_path.glob(f"{collector}_*.bin"))
    single = run_path / f"{collector}.bin"
    if single.exists():
        files.append(single)
    return sorted(files)


def extract_fingerprint(run_path: Path) -> dict:
    """
    Extract a stable fingerprint from an aperf run directory.
    Supports:
    - Old JSON format (system_info.json)
    - New flat binary format (systeminfo.bin or systeminfo_*.bin)
    - Report format (data/js/systeminfo.js)
    """
    fp = {
        "instance_type": None,
        "instance_family": None,
        "architecture": "x86_64",
        "kernel": None,
        "os": None,
        "primary_process": None,
        "all_processes": [],
        "memory_tier": "unknown",
        "memory_total_kb": 0,
        "cpu_count": None,
    }

    # --- system info: JSON format ---
    sysinfo_json = run_path / "system_info.json"
    if sysinfo_json.exists():
        try:
            si = json.loads(sysinfo_json.read_text())
            fp["instance_type"] = si.get("ec2", {}).get("instance_type")
            fp["architecture"] = si.get("architecture", "x86_64")
            fp["kernel"] = si.get("kernel_version")
            fp["os"] = si.get("os_name")
            fp["cpu_count"] = si.get("cpu_count")
        except Exception:
            pass

    # --- system info: report JS format (data/js/systeminfo.js) ---
    if not fp["instance_type"]:
        for js_candidate in [
            run_path / "data" / "js" / "systeminfo.js",
            run_path / "aperf_record_report" / "data" / "js" / "systeminfo.js",
        ]:
            if js_candidate.exists():
                try:
                    content = js_candidate.read_text()
                    decoder = __import__("json").JSONDecoder()
                    m = __import__("re").search(r"(\w+)\s*=\s*(\{)", content)
                    if m:
                        obj, _ = decoder.raw_decode(content, m.start(2))
                        run_key = next(iter(obj.get("runs", {})), None)
                        if run_key:
                            kvs = (obj["runs"][run_key]
                                   .get("key_value_groups", {})
                                   .get("", {})
                                   .get("key_values", {}))
                            fp["instance_type"] = kvs.get("Instance Type")
                            fp["architecture"] = kvs.get("Architecture", "x86_64")
                            fp["kernel"] = kvs.get("Kernel Version")
                            fp["os"] = kvs.get("OS")
                            raw_cpus = kvs.get("CPUs")
                            if raw_cpus:
                                fp["cpu_count"] = int(raw_cpus)
                    break
                except Exception:
                    pass

    # --- system info: flat binary format ---
    if not fp["instance_type"]:
        sysinfo_bins = _bins_for(run_path, "systeminfo")
        if sysinfo_bins:
            try:
                raw = _strings_from_bin(sysinfo_bins[0])
                lines = [l.strip() for l in raw.splitlines() if l.strip()]
                if lines:
                    fp["instance_type"] = lines[-1]
                if len(lines) >= 3:
                    fp["kernel"] = lines[2]
                if len(lines) >= 2:
                    fp["os"] = lines[1]
            except Exception:
                pass
        # CPU count from /proc/stat
        cpu_bins = _bins_for(run_path, "cpu_utilization")
        if cpu_bins:
            try:
                raw = _strings_from_bin(cpu_bins[0])
                cpu_ids = set(re.findall(r"^cpu(\d+)", raw, re.MULTILINE))
                if cpu_ids:
                    fp["cpu_count"] = len(cpu_ids)
            except Exception:
                pass

    if fp["instance_type"]:
        fp["instance_family"] = _instance_family(fp["instance_type"])
        # Graviton detection: any family ending in 'g' (optionally followed by
        # variant letters like 'd' or 'n'). Pattern: <letter><digit>+g[a-z]*
        # Examples: c7g, m8g, r8g, i8g, c7gn, m6gd, x8g, hpc7g.
        # Excludes 'a' (AMD) and 'i' (Intel) suffixes.
        import re as _re_arch
        family = fp["instance_family"] or ""
        if _re_arch.match(r"^[a-z]+\d+g[a-z]*$", family):
            fp["architecture"] = "aarch64"

    # --- memory: flat binary ---
    meminfo_bins = _bins_for(run_path, "meminfo")
    if meminfo_bins:
        try:
            raw = _strings_from_bin(meminfo_bins[0])
            m = re.search(r"MemTotal:\s+(\d+)", raw)
            if m:
                fp["memory_total_kb"] = int(m.group(1))
                fp["memory_tier"] = _memory_tier(fp["memory_total_kb"])
        except Exception:
            pass

    # --- memory: report JS format ---
    if fp["memory_total_kb"] == 0:
        for js_candidate in [
            run_path / "data" / "js" / "meminfo.js",
            run_path / "aperf_record_report" / "data" / "js" / "meminfo.js",
        ]:
            if js_candidate.exists():
                try:
                    content = js_candidate.read_text()
                    m = re.search(r'"MemTotal".*?"values":\s*\[([^\]]+)\]', content)
                    if m:
                        vals = [float(v.strip()) for v in m.group(1).split(",") if v.strip()]
                        if vals:
                            avg_bytes = sum(vals) / len(vals)
                            # JS report stores values in bytes; convert to kB
                            fp["memory_total_kb"] = int(avg_bytes / 1024)
                            fp["memory_tier"] = _memory_tier(fp["memory_total_kb"])
                    break
                except Exception:
                    pass

    # --- primary process: jps-map.json ---
    jps_maps = list(run_path.glob("*-jps-map.json"))
    if jps_maps:
        try:
            jps = json.loads(jps_maps[0].read_text())
            names = []
            for pid, name_list in jps.items():
                if isinstance(name_list, list):
                    names.extend(name_list)
                elif isinstance(name_list, str):
                    names.append(name_list)
            app_names = [n for n in names if n not in ("sun.tools.jps.Jps",) and n]
            fp["all_processes"] = app_names
            if app_names:
                fp["primary_process"] = app_names[0]
        except Exception:
            pass

    # --- primary process: flat binary processes ---
    if not fp["primary_process"]:
        proc_bins = _bins_for(run_path, "processes")
        if proc_bins:
            try:
                raw = _strings_from_bin(proc_bins[0])
                matches = re.findall(
                    r"^(\d+)\s+\(([^)]+)\)\s+\S+\s+\d+\s+\d+\s+\d+\s+\d+\s+[-\d]+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+\d+\s+(\d+)\s+(\d+)",
                    raw, re.MULTILINE
                )
                if matches:
                    user_procs = [
                        (m[1], int(m[2]) + int(m[3]))
                        for m in matches
                        if not m[1].startswith("k") and m[1] not in ("systemd", "init", "sh", "bash")
                    ]
                    if user_procs:
                        user_procs.sort(key=lambda x: x[1], reverse=True)
                        fp["primary_process"] = user_procs[0][0]
                        fp["all_processes"] = [p[0] for p in user_procs[:5]]
            except Exception:
                pass

    # --- primary process: report JS processes ---
    if not fp["primary_process"]:
        for js_candidate in [
            run_path / "data" / "js" / "processes.js",
            run_path / "aperf_record_report" / "data" / "js" / "processes.js",
        ]:
            if js_candidate.exists():
                try:
                    content = js_candidate.read_text()
                    # Look for process names in the JS data
                    names = re.findall(r'"series_name":\s*"([^"]+)"', content)
                    app_names = [
                        n for n in names
                        if n not in ("Aggregate",) and not n.startswith("CPU") and n
                    ]
                    if app_names:
                        fp["all_processes"] = list(dict.fromkeys(app_names))[:5]
                        fp["primary_process"] = fp["all_processes"][0]
                    break
                except Exception:
                    pass

    return fp


def fingerprint_hash(fp: dict) -> str:
    """Stable hash of the application identity (not the run specifics)."""
    key = "|".join([
        fp.get("instance_family") or "unknown",
        fp.get("primary_process") or "unknown",
        fp.get("memory_tier") or "unknown",
        fp.get("architecture") or "x86_64",
    ])
    return hashlib.sha256(key.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Context store
# ---------------------------------------------------------------------------

def load_context(fp_hash: str) -> dict | None:
    path = CONTEXT_STORE / f"{fp_hash}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def save_context(fp_hash: str, context: dict) -> None:
    CONTEXT_STORE.mkdir(parents=True, exist_ok=True)
    path = CONTEXT_STORE / f"{fp_hash}.json"
    path.write_text(json.dumps(context, indent=2))


def list_all_contexts() -> list[dict]:
    if not CONTEXT_STORE.exists():
        return []
    contexts = []
    for f in sorted(CONTEXT_STORE.glob("*.json")):
        try:
            ctx = json.loads(f.read_text())
            contexts.append(ctx)
        except Exception:
            pass
    return contexts


# ---------------------------------------------------------------------------
# Drift detection
# ---------------------------------------------------------------------------

DRIFT_FIELDS = [
    ("fingerprint.instance_type", "Instance type"),
    ("fingerprint.memory_tier", "Memory tier"),
    ("fingerprint.cpu_count", "CPU count"),
    ("fingerprint.kernel", "Kernel version"),
    ("fingerprint.primary_process", "Primary process"),
]


def detect_drift(stored_fp: dict, current_fp: dict) -> list[dict]:
    """Compare stored fingerprint with current run. Returns list of drift items."""
    drifts = []
    for key, label in DRIFT_FIELDS:
        field = key.split(".")[-1]
        old_val = stored_fp.get(field)
        new_val = current_fp.get(field)
        if old_val and new_val and old_val != new_val:
            drifts.append({"field": field, "label": label, "old": old_val, "new": new_val})
    return drifts


# ---------------------------------------------------------------------------
# Question renderer
# ---------------------------------------------------------------------------

def render_questionnaire(fp: dict, fp_hash: str, existing_contexts: list[dict]) -> str:
    """Render the pre-flight questionnaire as a structured message."""
    lines = [
        "## APerf Context Required",
        "",
        "This is the first time I've seen this application. I need a few details before running analysis so the report is meaningful.",
        "",
        f"**Detected fingerprint:** `{fp_hash}`",
        f"- Instance: `{fp.get('instance_type', 'unknown')}` ({fp.get('architecture', 'x86_64')}, {fp.get('cpu_count', '?')} vCPU)",
        f"- Memory tier: {fp.get('memory_tier', 'unknown')} ({fp.get('memory_total_kb', 0) // 1024 // 1024:.0f} GB)",
        f"- Primary process: `{fp.get('primary_process', 'unknown')}`",
        f"- Kernel: `{fp.get('kernel', 'unknown')}`",
        "",
    ]

    if existing_contexts:
        lines.append("**Known applications I can learn from:**")
        for ctx in existing_contexts[:3]:
            app = ctx.get("app_name", "unnamed")
            desc = ctx.get("app_description", "")
            inst = ctx.get("fingerprint", {}).get("instance_type", "?")
            proc = ctx.get("fingerprint", {}).get("primary_process", "?")
            lines.append(f"- `{app}`: {desc[:60]} ({inst}, {proc})")
        lines.append("")

    lines.append("**Please answer these questions (add your answers after each colon):**")
    lines.append("")
    for i, q in enumerate(QUESTIONS, 1):
        lines.append(f"{i}. **{q['label']}:**")
        lines.append(f"   _(e.g. {q['example']})_")
        lines.append("")

    lines += [
        "---",
        "Once you've answered, re-run the same command and I'll save this context for all future runs of this application.",
        "",
        f"To pass answers, add `app_context` to your tool call as:",
        "```json",
        '{',
        '  "app_name": "your-service-name",',
        '  "app_description": "...",',
        '  "capture_type": "steady-state",',
        '  "customer_priority": "cost-reduction"',
        '}',
        "```",
    ]
    return "\n".join(lines)


def render_drift_warning(stored: dict, drifts: list[dict], fp_hash: str) -> str:
    app_name = stored.get("app_name", "this application")
    lines = [
        f"## Change Detected: {app_name}",
        "",
        "The current run looks different from the stored profile:",
        "",
    ]
    for d in drifts:
        lines.append(f"- **{d['label']}**: `{d['old']}` → `{d['new']}`")
    lines += [
        "",
        "Proceeding with analysis using the existing context. To update the stored profile, add `update_context: true` to your tool call.",
        "",
        "**Stored context:**",
        f"- App: {stored.get('app_name', 'unknown')}",
        f"- Priority: {stored.get('customer_priority', 'unknown')}",
    ]
    return "\n".join(lines)


def render_context_injected(stored: dict) -> str:
    app_name = stored.get("app_name", "unknown")
    return f"Context loaded for **{app_name}** — proceeding with analysis."


# ---------------------------------------------------------------------------
# Main hook logic
# ---------------------------------------------------------------------------

def resolve_run_path(arguments: dict) -> Path | None:
    """Resolve the aperf run directory from tool arguments."""
    data_dir = arguments.get("data_dir") or os.environ.get("APERF_DATA_DIR", "./aperf_data")
    run_name = arguments.get("run_name")
    if not run_name:
        return None
    run_path = Path(data_dir) / run_name
    if run_path.exists():
        return run_path
    return None


def main() -> None:
    try:
        payload = json.loads(sys.stdin.read())
    except Exception:
        sys.exit(0)  # Malformed payload — approve silently

    tool_name = payload.get("tool_name") or payload.get("tool", {}).get("name", "")
    if tool_name not in WATCHED_TOOLS:
        sys.exit(0)  # Not a watched tool — approve

    arguments = payload.get("tool_input") or payload.get("arguments") or {}

    # If caller explicitly passes app_context, they're answering the questionnaire
    app_context_answers = arguments.get("app_context")

    run_path = resolve_run_path(arguments)
    if not run_path:
        # Can't locate run, approve and let the tool handle the error
        sys.exit(0)

    # Extract fingerprint from this run
    fp = extract_fingerprint(run_path)
    fp_hash = fingerprint_hash(fp)

    # Load existing context if any
    stored = load_context(fp_hash)

    # --- Case 1: Caller is providing answers now ---
    if app_context_answers and isinstance(app_context_answers, dict):
        # Only required fields must be present
        required_keys = [q["key"] for q in QUESTIONS if q.get("required", True)]
        missing = [k for k in required_keys if not app_context_answers.get(k)]
        if missing:
            msg = f"Missing required fields: {', '.join(missing)}. Please provide all answers."
            output = {"type": "block", "message": msg}
            print(json.dumps(output))
            sys.exit(2)

        # Resolve dep_file: 'auto' -> auto-detect, 'none' -> null, else path
        dep_file_input = app_context_answers.get("dep_file", "").strip().lower()
        resolved_dep_file = None
        dep_file_status = "skipped"
        if dep_file_input == "auto":
            try:
                # Lazy import to avoid hard dep
                sys.path.insert(0, str(Path(__file__).parent.parent))
                from src.parsers.dep_analyzer import auto_detect_dep_file
                detected = auto_detect_dep_file(run_path)
                if detected:
                    resolved_dep_file = str(detected)
                    dep_file_status = "auto-detected"
                else:
                    dep_file_status = "auto-detect-failed"
            except Exception:
                dep_file_status = "auto-detect-error"
        elif dep_file_input in ("none", "skip", "n/a", ""):
            dep_file_status = "skipped-by-user"
        else:
            # Treat as a path
            candidate = Path(app_context_answers["dep_file"])
            if candidate.exists():
                resolved_dep_file = str(candidate)
                dep_file_status = "user-provided"
            else:
                dep_file_status = f"path-not-found:{app_context_answers['dep_file']}"

        # Save context with fingerprint embedded
        context = dict(app_context_answers)
        context["dep_file_resolved"] = resolved_dep_file
        context["dep_file_status"] = dep_file_status
        context["fingerprint"] = fp
        context["fingerprint_hash"] = fp_hash
        context["first_seen_run"] = run_path.name
        context["runs_analyzed"] = 1

        if stored:
            context["runs_analyzed"] = stored.get("runs_analyzed", 0) + 1

        save_context(fp_hash, context)

        approval_msg = f"Context saved for **{context.get('app_name', 'application')}** (`{fp_hash}`). "
        if dep_file_status == "auto-detected":
            approval_msg += f"Dep file auto-detected: `{resolved_dep_file}`. "
        elif dep_file_status == "skipped-by-user":
            approval_msg += "Dep file skipped — Graviton recommendations will note this limitation. "
        elif dep_file_status.startswith("path-not-found"):
            approval_msg += f"⚠️ Dep file path not found. "
        elif dep_file_status == "auto-detect-failed":
            approval_msg += "⚠️ Auto-detect found no dep file in the run directory. "
        approval_msg += "Proceeding with analysis."

        output = {
            "type": "approve",
            "message": approval_msg,
        }
        print(json.dumps(output))
        sys.exit(0)

    # --- Case 2: No stored context — first time seeing this application ---
    if not stored:
        existing = list_all_contexts()
        msg = render_questionnaire(fp, fp_hash, existing)
        output = {
            "type": "block",
            "message": msg,
        }
        print(json.dumps(output))
        sys.exit(2)

    # --- Case 3: Stored context exists — check for drift ---
    stored_fp = stored.get("fingerprint", {})
    drifts = detect_drift(stored_fp, fp)

    # Update run count
    stored["runs_analyzed"] = stored.get("runs_analyzed", 0) + 1
    stored["last_run"] = run_path.name

    # Check if caller wants to force update
    if arguments.get("update_context") and drifts:
        stored["fingerprint"] = fp
        save_context(fp_hash, stored)
        output = {
            "type": "warn",
            "message": f"Context updated for **{stored.get('app_name', 'application')}**. Drift resolved.",
            "app_context": stored,
        }
        print(json.dumps(output))
        sys.exit(1)

    save_context(fp_hash, stored)

    if drifts:
        msg = render_drift_warning(stored, drifts, fp_hash)
        output = {
            "type": "warn",
            "message": msg,
            "app_context": stored,
        }
        print(json.dumps(output))
        sys.exit(1)  # Warn but don't block

    # --- Case 4: Clean match — inject context and approve ---
    msg = render_context_injected(stored)
    output = {
        "type": "approve",
        "message": msg,
        "app_context": stored,
    }
    print(json.dumps(output))
    sys.exit(0)


if __name__ == "__main__":
    main()
